#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2951[8];
void O2951_init () {
	{long i; for (i = 0; i < 2; i++) O2951[i] = 0;}
	O2951[2] = + _LNGOFF_5_3_0_0_;
	O2951[3] = + _LNGOFF_4_3_0_0_;
	O2951[4] = + _PTROFF_5_3_0_7_0_0_;
	O2951[5] = 0;
	O2951[6] = + _LNGOFF_5_4_0_0_;
	O2951[7] = 0;
}

long O2960[8];
void O2960_init () {
	O2960[0] = + _LNGOFF_7_3_0_0_;
	O2960[1] = + _LNGOFF_6_3_0_0_;
	O2960[2] = + _LNGOFF_5_3_0_1_;
	O2960[3] = + _LNGOFF_4_3_0_1_;
	O2960[4] = + _LNGOFF_5_3_0_0_;
	O2960[5] = + _LNGOFF_7_4_0_0_;
	O2960[6] = + _LNGOFF_5_4_0_1_;
	O2960[7] = + _LNGOFF_9_3_0_0_;
}

long O2987[8];
void O2987_init () {
	{long i; for (i = 0; i < 2; i++) O2987[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 5; i++) O2987[i] = 0;}
	O2987[5] =  + _REFACS_1_;
	O2987[6] = 0;
	O2987[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y2987_pgtype0[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype1[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype2[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype3[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype4[] = {693,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype5[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype6[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2987_pgtype7[] = {684,0,0xFFFF};
EIF_TYPE_INDEX *Y2987_gen_type [8];
EIF_TYPE_INDEX Y2987 [8];
void Y2987_init (void)
{
	egc_routines_types [2987] = Y2987;
	egc_routines_gen_types [2987] = Y2987_gen_type;
	egc_routines_offset [2987] = 672;
	Y2987_gen_type [0] = Y2987_pgtype0;
	Y2987_gen_type [1] = Y2987_pgtype1;
	Y2987_gen_type [2] = Y2987_pgtype2;
	Y2987_gen_type [3] = Y2987_pgtype3;
	Y2987_gen_type [4] = Y2987_pgtype4;
	Y2987_gen_type [5] = Y2987_pgtype5;
	Y2987_gen_type [6] = Y2987_pgtype6;
	Y2987_gen_type [7] = Y2987_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y2987[i] = 684;};
	{long i; for (i = 2; i < 4; i++) Y2987[i] = 686;};
	Y2987[4] = 693;
	Y2987[5] = 684;
	Y2987[6] = 686;
	Y2987[7] = 684;
}

long O2988[8];
void O2988_init () {
	{long i; for (i = 0; i < 2; i++) O2988[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 5; i++) O2988[i] =  + _REFACS_1_;}
	O2988[5] =  + _REFACS_2_;
	O2988[6] =  + _REFACS_1_;
	O2988[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y2988_pgtype0[] = {684,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype1[] = {686,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype2[] = {684,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype3[] = {686,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype4[] = {684,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype5[] = {684,889,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype6[] = {684,889,0xFFFF};
static EIF_TYPE_INDEX Y2988_pgtype7[] = {684,894,0xFFFF};
EIF_TYPE_INDEX *Y2988_gen_type [8];
EIF_TYPE_INDEX Y2988 [8];
void Y2988_init (void)
{
	egc_routines_types [2988] = Y2988;
	egc_routines_gen_types [2988] = Y2988_gen_type;
	egc_routines_offset [2988] = 672;
	Y2988_gen_type [0] = Y2988_pgtype0;
	Y2988_gen_type [1] = Y2988_pgtype1;
	Y2988_gen_type [2] = Y2988_pgtype2;
	Y2988_gen_type [3] = Y2988_pgtype3;
	Y2988_gen_type [4] = Y2988_pgtype4;
	Y2988_gen_type [5] = Y2988_pgtype5;
	Y2988_gen_type [6] = Y2988_pgtype6;
	Y2988_gen_type [7] = Y2988_pgtype7;
	Y2988[0] = 684;
	Y2988[1] = 686;
	Y2988[2] = 684;
	Y2988[3] = 686;
	{long i; for (i = 4; i < 8; i++) Y2988[i] = 684;};
}

long O2989[8];
void O2989_init () {
	{long i; for (i = 0; i < 2; i++) O2989[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 5; i++) O2989[i] =  + _REFACS_2_;}
	O2989[5] =  + _REFACS_3_;
	O2989[6] =  + _REFACS_2_;
	O2989[7] =  + _REFACS_3_;
}

long O2990[8];
void O2990_init () {
	{long i; for (i = 0; i < 2; i++) O2990[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 5; i++) O2990[i] =  + _REFACS_3_;}
	O2990[5] =  + _REFACS_4_;
	O2990[6] =  + _REFACS_3_;
	O2990[7] =  + _REFACS_4_;
}

long O2991[8];
void O2991_init () {
	O2991[0] = + _LNGOFF_7_3_0_1_;
	O2991[1] = + _LNGOFF_6_3_0_1_;
	O2991[2] = + _LNGOFF_5_3_0_2_;
	O2991[3] = + _LNGOFF_4_3_0_2_;
	O2991[4] = + _LNGOFF_5_3_0_1_;
	O2991[5] = + _LNGOFF_7_4_0_1_;
	O2991[6] = + _LNGOFF_5_4_0_2_;
	O2991[7] = + _LNGOFF_9_3_0_1_;
}

long O2992[8];
void O2992_init () {
	O2992[0] = + _CHROFF_7_2_;
	O2992[1] = + _CHROFF_6_2_;
	O2992[2] = + _CHROFF_5_2_;
	O2992[3] = + _CHROFF_4_2_;
	O2992[4] = + _CHROFF_5_2_;
	O2992[5] = + _CHROFF_7_2_;
	O2992[6] = + _CHROFF_5_2_;
	O2992[7] = + _CHROFF_9_2_;
}

long O2993[8];
void O2993_init () {
	O2993[0] = + _LNGOFF_7_3_0_2_;
	O2993[1] = + _LNGOFF_6_3_0_2_;
	O2993[2] = + _LNGOFF_5_3_0_3_;
	O2993[3] = + _LNGOFF_4_3_0_3_;
	O2993[4] = + _LNGOFF_5_3_0_2_;
	O2993[5] = + _LNGOFF_7_4_0_2_;
	O2993[6] = + _LNGOFF_5_4_0_3_;
	O2993[7] = + _LNGOFF_9_3_0_2_;
}

long O2996[8];
void O2996_init () {
	O2996[0] = + _LNGOFF_7_3_0_3_;
	O2996[1] = + _LNGOFF_6_3_0_3_;
	O2996[2] = + _LNGOFF_5_3_0_4_;
	O2996[3] = + _LNGOFF_4_3_0_4_;
	O2996[4] = + _LNGOFF_5_3_0_3_;
	O2996[5] = + _LNGOFF_7_4_0_3_;
	O2996[6] = + _LNGOFF_5_4_0_4_;
	O2996[7] = + _LNGOFF_9_3_0_3_;
}

long O2997[8];
void O2997_init () {
	O2997[0] = + _LNGOFF_7_3_0_4_;
	O2997[1] = + _LNGOFF_6_3_0_4_;
	O2997[2] = + _LNGOFF_5_3_0_5_;
	O2997[3] = + _LNGOFF_4_3_0_5_;
	O2997[4] = + _LNGOFF_5_3_0_4_;
	O2997[5] = + _LNGOFF_7_4_0_4_;
	O2997[6] = + _LNGOFF_5_4_0_5_;
	O2997[7] = + _LNGOFF_9_3_0_4_;
}

long O3001[8];
void O3001_init () {
	O3001[0] = + _LNGOFF_7_3_0_5_;
	O3001[1] = + _LNGOFF_6_3_0_5_;
	O3001[2] = + _LNGOFF_5_3_0_6_;
	O3001[3] = + _LNGOFF_4_3_0_6_;
	O3001[4] = + _LNGOFF_5_3_0_5_;
	O3001[5] = + _LNGOFF_7_4_0_5_;
	O3001[6] = + _LNGOFF_5_4_0_6_;
	O3001[7] = + _LNGOFF_9_3_0_5_;
}

long O3002[8];
void O3002_init () {
	{long i; for (i = 0; i < 2; i++) O3002[i] =  + _REFACS_5_;}
	O3002[2] = + _LNGOFF_5_3_0_7_;
	O3002[3] = + _LNGOFF_4_3_0_7_;
	O3002[4] = + _PTROFF_5_3_0_7_0_1_;
	O3002[5] =  + _REFACS_5_;
	O3002[6] = + _LNGOFF_5_4_0_7_;
	O3002[7] =  + _REFACS_5_;
}

long O3003[8];
void O3003_init () {
	O3003[0] =  + _REFACS_6_;
	O3003[1] = + _LNGOFF_6_3_0_6_;
	O3003[2] =  + _REFACS_4_;
	O3003[3] = + _LNGOFF_4_3_0_8_;
	O3003[4] =  + _REFACS_4_;
	O3003[5] =  + _REFACS_6_;
	O3003[6] =  + _REFACS_4_;
	O3003[7] =  + _REFACS_6_;
}

long O3037[8];
void O3037_init () {
	O3037[0] = + _LNGOFF_7_3_0_6_;
	O3037[1] = + _LNGOFF_6_3_0_7_;
	O3037[2] = + _LNGOFF_5_3_0_8_;
	O3037[3] = + _LNGOFF_4_3_0_9_;
	O3037[4] = + _LNGOFF_5_3_0_6_;
	O3037[5] = + _LNGOFF_7_4_0_6_;
	O3037[6] = + _LNGOFF_5_4_0_8_;
	O3037[7] = + _LNGOFF_9_3_0_6_;
}

long O3040[2];
void O3040_init () {
	O3040[0] = + _CHROFF_7_3_;
	O3040[1] = + _CHROFF_5_3_;
}

long O4293[10];
void O4293_init () {
	{long i; for (i = 0; i < 3; i++) O4293[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O4293[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O4293[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O4293[i] = + _LNGOFF_1_0_0_0_;}
	O4293[9] = + _LNGOFF_1_1_0_0_;
}

long O4294[10];
void O4294_init () {
	{long i; for (i = 0; i < 3; i++) O4294[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O4294[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O4294[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O4294[i] = + _LNGOFF_1_0_0_1_;}
	O4294[9] = + _LNGOFF_1_1_0_1_;
}

long O4363[4];
void O4363_init () {
	{long i; for (i = 0; i < 2; i++) O4363[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4363[i] = + _LNGOFF_1_1_0_2_;}
}

long O4451[3];
void O4451_init () {
	{long i; for (i = 0; i < 2; i++) O4451[i] = + _LNGOFF_1_0_0_2_;}
	O4451[2] = + _LNGOFF_1_1_0_2_;
}

long O4965[5];
void O4965_init () {
	{long i; for (i = 0; i < 3; i++) O4965[i] = + _CHROFF_6_1_;}
	{long i; for (i = 3; i < 5; i++) O4965[i] = + _CHROFF_7_1_;}
}

long O4966[5];
void O4966_init () {
	{long i; for (i = 0; i < 3; i++) O4966[i] = + _CHROFF_6_2_;}
	{long i; for (i = 3; i < 5; i++) O4966[i] = + _CHROFF_7_2_;}
}

long O4983[5];
void O4983_init () {
	{long i; for (i = 0; i < 3; i++) O4983[i] = + _CHROFF_6_0_;}
	{long i; for (i = 3; i < 5; i++) O4983[i] = + _CHROFF_7_0_;}
}


#ifdef __cplusplus
}
#endif
