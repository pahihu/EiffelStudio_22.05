#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O599[7];
void O599_init () {
	O599[0] = 0;
	O599[1] = + _LNGOFF_0_0_0_0_;
	O599[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O599[3] = + _LNGOFF_0_0_0_0_;
	O599[4] = 0;
	O599[5] = + _LNGOFF_1_0_0_0_;
	O599[6] = 0;
}

long O603[3];
void O603_init () {
	O603[0] =  + _REFACS_1_;
	O603[1] = 0;
	O603[2] =  + _REFACS_1_;
}

long O719[725];
void O719_init () {
	O719[0] = + _LNGOFF_6_0_0_0_;
	{long i; for (i = 1; i < 3; i++) O719[i] = + _LNGOFF_7_1_0_0_;}
	O719[3] = + _LNGOFF_6_0_0_0_;
	O719[4] = + _LNGOFF_8_1_0_0_;
	O719[5] = + _LNGOFF_6_1_0_0_;
	O719[6] = + _LNGOFF_7_1_0_0_;
	{long i; for (i = 7; i < 9; i++) O719[i] = + _LNGOFF_7_2_0_0_;}
	O719[9] = + _LNGOFF_6_1_0_0_;
	O719[10] = + _LNGOFF_7_2_0_0_;
	O719[11] = + _LNGOFF_8_1_0_0_;
	O719[12] = + _LNGOFF_7_1_0_0_;
	O719[13] = + _LNGOFF_7_2_0_0_;
	O719[48] = + _LNGOFF_7_2_0_0_;
	O719[125] = + _LNGOFF_7_4_0_0_;
	O719[598] = + _LNGOFF_8_1_0_0_;
	O719[599] = + _LNGOFF_7_2_0_0_;
	O719[600] = + _LNGOFF_8_2_0_0_;
	O719[601] = + _LNGOFF_7_1_0_0_;
	O719[602] = + _LNGOFF_8_1_0_0_;
	O719[692] = + _LNGOFF_10_2_0_0_;
	O719[693] = + _LNGOFF_7_2_0_0_;
	O719[694] = + _LNGOFF_8_2_0_0_;
	{long i; for (i = 695; i < 698; i++) O719[i] = + _LNGOFF_6_2_0_0_;}
	O719[698] = + _LNGOFF_8_2_0_0_;
	{long i; for (i = 700; i < 702; i++) O719[i] = + _LNGOFF_8_1_0_0_;}
	{long i; for (i = 704; i < 713; i++) O719[i] = + _LNGOFF_9_2_0_0_;}
	{long i; for (i = 713; i < 717; i++) O719[i] = + _LNGOFF_7_2_0_0_;}
	O719[717] = + _LNGOFF_10_3_0_0_;
	{long i; for (i = 718; i < 724; i++) O719[i] = + _LNGOFF_7_2_0_0_;}
	O719[724] = + _LNGOFF_9_2_0_0_;
}

long O760[712];
void O760_init () {
	O760[0] = + _CHROFF_7_0_;
	O760[680] = + _CHROFF_7_0_;
	O760[703] = + _CHROFF_7_0_;
	O760[704] = + _CHROFF_10_0_;
	{long i; for (i = 705; i < 711; i++) O760[i] = + _CHROFF_7_0_;}
	O760[711] = + _CHROFF_9_0_;
}

long O761[712];
void O761_init () {
	O761[0] = + _CHROFF_7_1_;
	O761[680] = + _CHROFF_7_1_;
	O761[703] = + _CHROFF_7_1_;
	O761[704] = + _CHROFF_10_1_;
	{long i; for (i = 705; i < 711; i++) O761[i] = + _CHROFF_7_1_;}
	O761[711] = + _CHROFF_9_1_;
}

long O867[849];
void O867_init () {
	O867[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 842; i < 844; i++) O867[i] = + _LNGOFF_0_0_0_0_;}
	O867[846] = + _LNGOFF_0_0_0_0_;
	O867[847] = + _LNGOFF_5_1_0_0_;
	O867[848] = + _LNGOFF_2_0_0_0_;
}

EIF_TYPE_INDEX *Y899_gen_type [846];
EIF_TYPE_INDEX Y899 [846];
void Y899_init (void)
{
	egc_routines_types [899] = Y899;
	egc_routines_gen_types [899] = Y899_gen_type;
	egc_routines_offset [899] = 76;
	Y899[0] = 73;
	Y899[845] = 916;
}

long O1086[4];
void O1086_init () {
	O1086[0] = + _CHROFF_2_0_;
	O1086[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1086[i] = + _CHROFF_2_0_;}
}

long O1087[4];
void O1087_init () {
	O1087[0] = + _CHROFF_2_1_;
	O1087[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1087[i] = + _CHROFF_2_1_;}
}

long O1261[2];
void O1261_init () {
	O1261[0] = + _CHROFF_5_0_;
	O1261[1] = + _CHROFF_7_0_;
}

long O1265[2];
void O1265_init () {
	O1265[0] = + _CHROFF_5_1_;
	O1265[1] = + _CHROFF_7_1_;
}

long O1266[2];
void O1266_init () {
	O1266[0] = + _CHROFF_5_2_;
	O1266[1] = + _CHROFF_7_2_;
}

long O1267[2];
void O1267_init () {
	O1267[0] = + _CHROFF_5_3_;
	O1267[1] = + _CHROFF_7_3_;
}

long O1268[2];
void O1268_init () {
	O1268[0] = + _CHROFF_5_4_;
	O1268[1] = + _CHROFF_7_4_;
}

long O1269[2];
void O1269_init () {
	O1269[0] = + _CHROFF_5_5_;
	O1269[1] = + _CHROFF_7_5_;
}

long O1270[2];
void O1270_init () {
	O1270[0] = + _CHROFF_5_6_;
	O1270[1] = + _CHROFF_7_6_;
}

long O1271[2];
void O1271_init () {
	O1271[0] = + _CHROFF_5_7_;
	O1271[1] = + _CHROFF_7_7_;
}

long O1272[2];
void O1272_init () {
	O1272[0] = + _CHROFF_5_8_;
	O1272[1] = + _CHROFF_7_8_;
}

long O1277[2];
void O1277_init () {
	O1277[0] = + _CHROFF_5_9_;
	O1277[1] = + _CHROFF_7_9_;
}

long O1455[596];
void O1455_init () {
	{long i; for (i = 0; i < 3; i++) O1455[i] = + _CHROFF_1_0_;}
	O1455[22] = + _CHROFF_2_0_;
	O1455[595] = + _CHROFF_1_0_;
}

long O1571[3];
void O1571_init () {
	O1571[0] = + _LNGOFF_1_0_0_0_;
	O1571[1] = + _LNGOFF_2_0_0_0_;
	O1571[2] = + _LNGOFF_1_0_0_0_;
}

long O1742[718];
void O1742_init () {
	O1742[0] = + _CHROFF_1_0_;
	O1742[374] = + _CHROFF_3_0_;
	O1742[375] = + _CHROFF_4_0_;
	O1742[376] = + _CHROFF_5_0_;
	O1742[717] = + _CHROFF_5_0_;
}

long O1744[718];
void O1744_init () {
	O1744[0] = + _LNGOFF_1_3_2_1_;
	O1744[374] = + _LNGOFF_3_6_2_1_;
	O1744[375] = + _LNGOFF_4_6_2_1_;
	O1744[376] = + _LNGOFF_5_7_2_1_;
	O1744[717] = + _LNGOFF_5_7_2_1_;
}

long O1754[718];
void O1754_init () {
	O1754[0] = + _R32OFF_1_3_2_3_0_;
	O1754[374] = + _R32OFF_3_6_2_4_0_;
	O1754[375] = + _R32OFF_4_6_2_4_0_;
	O1754[376] = + _R32OFF_5_7_2_4_0_;
	O1754[717] = + _R32OFF_5_7_2_4_0_;
}

long O1756[718];
void O1756_init () {
	O1756[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O1756[374] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O1756[375] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O1756[376] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O1756[717] = + _R64OFF_5_7_2_4_1_1_2_0_;
}

static EIF_TYPE_INDEX Y2108_pgtype0[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype1[] = {685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype2[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype3[] = {687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype4[] = {688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype5[] = {689,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype6[] = {690,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype7[] = {691,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype8[] = {692,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype9[] = {693,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype10[] = {694,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype11[] = {695,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype12[] = {689,820,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype13[] = {689,820,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype14[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype15[] = {685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype16[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype17[] = {687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype18[] = {688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype19[] = {689,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype20[] = {690,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype21[] = {691,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype22[] = {692,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype23[] = {693,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype24[] = {694,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype25[] = {695,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype26[] = {684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype27[] = {685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype28[] = {686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype29[] = {687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype30[] = {688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype31[] = {689,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype32[] = {690,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype33[] = {691,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype34[] = {692,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype35[] = {693,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype36[] = {694,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype37[] = {695,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype38[] = {688,832,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype39[] = {688,832,0xFFFF};
static EIF_TYPE_INDEX Y2108_pgtype40[] = {687,829,0xFFFF};
EIF_TYPE_INDEX *Y2108_gen_type [708];
EIF_TYPE_INDEX Y2108 [708];
void Y2108_init (void)
{
	egc_routines_types [2108] = Y2108;
	egc_routines_gen_types [2108] = Y2108_gen_type;
	egc_routines_offset [2108] = 191;
	Y2108_gen_type [0] = Y2108_pgtype0;
	Y2108_gen_type [1] = Y2108_pgtype1;
	Y2108_gen_type [2] = Y2108_pgtype2;
	Y2108_gen_type [3] = Y2108_pgtype3;
	Y2108_gen_type [4] = Y2108_pgtype4;
	Y2108_gen_type [5] = Y2108_pgtype5;
	Y2108_gen_type [6] = Y2108_pgtype6;
	Y2108_gen_type [7] = Y2108_pgtype7;
	Y2108_gen_type [8] = Y2108_pgtype8;
	Y2108_gen_type [9] = Y2108_pgtype9;
	Y2108_gen_type [10] = Y2108_pgtype10;
	Y2108_gen_type [11] = Y2108_pgtype11;
	Y2108_gen_type [15] = Y2108_pgtype12;
	Y2108_gen_type [16] = Y2108_pgtype13;
	Y2108_gen_type [393] = Y2108_pgtype14;
	Y2108_gen_type [394] = Y2108_pgtype15;
	Y2108_gen_type [395] = Y2108_pgtype16;
	Y2108_gen_type [396] = Y2108_pgtype17;
	Y2108_gen_type [397] = Y2108_pgtype18;
	Y2108_gen_type [398] = Y2108_pgtype19;
	Y2108_gen_type [399] = Y2108_pgtype20;
	Y2108_gen_type [400] = Y2108_pgtype21;
	Y2108_gen_type [401] = Y2108_pgtype22;
	Y2108_gen_type [402] = Y2108_pgtype23;
	Y2108_gen_type [403] = Y2108_pgtype24;
	Y2108_gen_type [404] = Y2108_pgtype25;
	Y2108_gen_type [468] = Y2108_pgtype26;
	Y2108_gen_type [469] = Y2108_pgtype27;
	Y2108_gen_type [470] = Y2108_pgtype28;
	Y2108_gen_type [471] = Y2108_pgtype29;
	Y2108_gen_type [472] = Y2108_pgtype30;
	Y2108_gen_type [473] = Y2108_pgtype31;
	Y2108_gen_type [474] = Y2108_pgtype32;
	Y2108_gen_type [475] = Y2108_pgtype33;
	Y2108_gen_type [476] = Y2108_pgtype34;
	Y2108_gen_type [477] = Y2108_pgtype35;
	Y2108_gen_type [478] = Y2108_pgtype36;
	Y2108_gen_type [479] = Y2108_pgtype37;
	Y2108_gen_type [703] = Y2108_pgtype38;
	Y2108_gen_type [704] = Y2108_pgtype39;
	Y2108_gen_type [707] = Y2108_pgtype40;
	Y2108[0] = 684;
	Y2108[1] = 685;
	Y2108[2] = 686;
	Y2108[3] = 687;
	Y2108[4] = 688;
	Y2108[5] = 689;
	Y2108[6] = 690;
	Y2108[7] = 691;
	Y2108[8] = 692;
	Y2108[9] = 693;
	Y2108[10] = 694;
	Y2108[11] = 695;
	{long i; for (i = 15; i < 17; i++) Y2108[i] = 689;};
	Y2108[393] = 684;
	Y2108[394] = 685;
	Y2108[395] = 686;
	Y2108[396] = 687;
	Y2108[397] = 688;
	Y2108[398] = 689;
	Y2108[399] = 690;
	Y2108[400] = 691;
	Y2108[401] = 692;
	Y2108[402] = 693;
	Y2108[403] = 694;
	Y2108[404] = 695;
	Y2108[468] = 684;
	Y2108[469] = 685;
	Y2108[470] = 686;
	Y2108[471] = 687;
	Y2108[472] = 688;
	Y2108[473] = 689;
	Y2108[474] = 690;
	Y2108[475] = 691;
	Y2108[476] = 692;
	Y2108[477] = 693;
	Y2108[478] = 694;
	Y2108[479] = 695;
	{long i; for (i = 703; i < 705; i++) Y2108[i] = 688;};
	Y2108[707] = 687;
}

long O2470[20];
void O2470_init () {
	{long i; for (i = 0; i < 17; i++) O2470[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 17; i < 20; i++) O2470[i] = + _LNGOFF_2_1_0_0_;}
}

long O2474[20];
void O2474_init () {
	{long i; for (i = 0; i < 17; i++) O2474[i] = + _CHROFF_1_0_;}
	{long i; for (i = 17; i < 20; i++) O2474[i] = + _CHROFF_2_0_;}
}

long O2475[20];
void O2475_init () {
	{long i; for (i = 0; i < 17; i++) O2475[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 17; i < 20; i++) O2475[i] = + _LNGOFF_2_1_0_1_;}
}

long O2476[20];
void O2476_init () {
	{long i; for (i = 0; i < 17; i++) O2476[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 17; i < 20; i++) O2476[i] = + _LNGOFF_2_1_0_2_;}
}

long O2477[20];
void O2477_init () {
	{long i; for (i = 0; i < 17; i++) O2477[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 17; i < 20; i++) O2477[i] = + _LNGOFF_2_1_0_3_;}
}

long O2478[20];
void O2478_init () {
	{long i; for (i = 0; i < 17; i++) O2478[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 17; i < 20; i++) O2478[i] = + _LNGOFF_2_1_0_4_;}
}

long O2499[549];
void O2499_init () {
	{long i; for (i = 0; i < 205; i++) O2499[i] = + _CHROFF_0_0_;}
	O2499[205] = + _CHROFF_3_2_;
	O2499[206] = + _CHROFF_4_2_;
	O2499[207] = + _CHROFF_5_2_;
	{long i; for (i = 220; i < 233; i++) O2499[i] = + _CHROFF_0_0_;}
	{long i; for (i = 233; i < 245; i++) O2499[i] = + _CHROFF_1_0_;}
	{long i; for (i = 245; i < 295; i++) O2499[i] = + _CHROFF_0_0_;}
	{long i; for (i = 295; i < 297; i++) O2499[i] = + _CHROFF_2_0_;}
	{long i; for (i = 297; i < 299; i++) O2499[i] = + _CHROFF_4_0_;}
	{long i; for (i = 307; i < 320; i++) O2499[i] = + _CHROFF_1_0_;}
	O2499[321] = + _CHROFF_7_0_;
	O2499[322] = + _CHROFF_6_0_;
	O2499[323] = + _CHROFF_5_0_;
	O2499[324] = + _CHROFF_4_0_;
	O2499[325] = + _CHROFF_5_0_;
	O2499[326] = + _CHROFF_7_0_;
	O2499[327] = + _CHROFF_5_0_;
	O2499[328] = + _CHROFF_9_0_;
	{long i; for (i = 543; i < 545; i++) O2499[i] = + _CHROFF_1_0_;}
	O2499[547] = + _CHROFF_1_0_;
	O2499[548] = + _CHROFF_5_2_;
}

long O2588[344];
void O2588_init () {
	O2588[0] = + _PTROFF_3_6_2_4_1_0_;
	O2588[1] = + _PTROFF_4_6_2_4_1_0_;
	O2588[2] = + _PTROFF_5_7_2_4_1_0_;
	O2588[343] = + _PTROFF_5_7_2_4_1_0_;
}

long O2727[344];
void O2727_init () {
	O2727[0] = + _LNGOFF_3_6_2_3_;
	O2727[1] = + _LNGOFF_4_6_2_3_;
	O2727[2] = + _LNGOFF_5_7_2_3_;
	O2727[343] = + _LNGOFF_5_7_2_3_;
}

long O2736[344];
void O2736_init () {
	O2736[0] = + _CHROFF_3_3_;
	O2736[1] = + _CHROFF_4_3_;
	O2736[2] = + _CHROFF_5_3_;
	O2736[343] = + _CHROFF_5_3_;
}

long O2868[4];
void O2868_init () {
	{long i; for (i = 0; i < 2; i++) O2868[i] = + _CHROFF_2_1_;}
	{long i; for (i = 2; i < 4; i++) O2868[i] = + _CHROFF_4_1_;}
}

long O2869[4];
void O2869_init () {
	{long i; for (i = 0; i < 2; i++) O2869[i] = + _CHROFF_2_2_;}
	{long i; for (i = 2; i < 4; i++) O2869[i] = + _CHROFF_4_2_;}
}

long O2870[4];
void O2870_init () {
	{long i; for (i = 0; i < 2; i++) O2870[i] = + _LNGOFF_2_3_0_0_;}
	{long i; for (i = 2; i < 4; i++) O2870[i] = + _LNGOFF_4_3_0_0_;}
}

EIF_TYPE_INDEX *Y2921_gen_type [1];
EIF_TYPE_INDEX Y2921 [1];
void Y2921_init (void)
{
	egc_routines_types [2921] = Y2921;
	egc_routines_gen_types [2921] = Y2921_gen_type;
	egc_routines_offset [2921] = 658;
	Y2921[0] = 844;
}

long O2937[251];
void O2937_init () {
	O2937[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 246; i < 248; i++) O2937[i] = + _LNGOFF_0_0_0_0_;}
	O2937[248] = + _LNGOFF_0_0_0_1_;
	O2937[249] = + _LNGOFF_5_1_0_1_;
	O2937[250] = + _LNGOFF_2_0_0_1_;
}


#ifdef __cplusplus
}
#endif
