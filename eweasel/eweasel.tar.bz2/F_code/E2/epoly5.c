#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2541[407])();
void R2541_init () {
	R2541[0] = (char *(*)()) F493_2899_2541_1;
	{long i; for (i = 64; i < 66; i++) R2541[i] = (char *(*)()) F557_2966_2541_1;}
	R2541[153] = (char *(*)()) F647_3464;
	R2541[154] = (char *(*)()) F648_3464_2541_1;
	R2541[156] = (char *(*)()) F647_3464;
	R2541[166] = (char *(*)()) F660_3624;
	R2541[167] = (char *(*)()) F661_3624_2541_1;
	R2541[168] = (char *(*)()) F662_3624_2541_1;
	R2541[169] = (char *(*)()) F663_3624_2541_1;
	R2541[170] = (char *(*)()) F664_3624_2541_1;
	R2541[171] = (char *(*)()) F665_3624_2541_1;
	R2541[172] = (char *(*)()) F666_3624_2541_1;
	R2541[173] = (char *(*)()) F667_3624_2541_1;
	R2541[174] = (char *(*)()) F668_3624_2541_1;
	R2541[175] = (char *(*)()) F669_3624_2541_1;
	R2541[176] = (char *(*)()) F670_3624_2541_1;
	R2541[177] = (char *(*)()) F671_3624_2541_1;
	R2541[402] = (char *(*)()) F896_5833_2541_1;
	R2541[406] = (char *(*)()) F557_2966_2541_1;
}
static EIF_REFERENCE F493_2899_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F493_2899(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_2966_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F557_2966(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F648_3464_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F648_3464(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3624_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_5833_2541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F896_5833(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y2541_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2541_pgtype105[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y2541_gen_type [446];
EIF_TYPE_INDEX Y2541 [446];
void Y2541_init (void)
{
	egc_routines_types [2541] = Y2541;
	egc_routines_gen_types [2541] = Y2541_gen_type;
	egc_routines_offset [2541] = 454;
	Y2541_gen_type [0] = Y2541_pgtype0;
	Y2541_gen_type [1] = Y2541_pgtype1;
	Y2541_gen_type [2] = Y2541_pgtype2;
	Y2541_gen_type [3] = Y2541_pgtype3;
	Y2541_gen_type [4] = Y2541_pgtype4;
	Y2541_gen_type [5] = Y2541_pgtype5;
	Y2541_gen_type [6] = Y2541_pgtype6;
	Y2541_gen_type [7] = Y2541_pgtype7;
	Y2541_gen_type [8] = Y2541_pgtype8;
	Y2541_gen_type [9] = Y2541_pgtype9;
	Y2541_gen_type [10] = Y2541_pgtype10;
	Y2541_gen_type [11] = Y2541_pgtype11;
	Y2541_gen_type [12] = Y2541_pgtype12;
	Y2541_gen_type [13] = Y2541_pgtype13;
	Y2541_gen_type [14] = Y2541_pgtype14;
	Y2541_gen_type [15] = Y2541_pgtype15;
	Y2541_gen_type [16] = Y2541_pgtype16;
	Y2541_gen_type [17] = Y2541_pgtype17;
	Y2541_gen_type [18] = Y2541_pgtype18;
	Y2541_gen_type [19] = Y2541_pgtype19;
	Y2541_gen_type [20] = Y2541_pgtype20;
	Y2541_gen_type [21] = Y2541_pgtype21;
	Y2541_gen_type [22] = Y2541_pgtype22;
	Y2541_gen_type [23] = Y2541_pgtype23;
	Y2541_gen_type [38] = Y2541_pgtype24;
	Y2541_gen_type [52] = Y2541_pgtype25;
	Y2541_gen_type [53] = Y2541_pgtype26;
	Y2541_gen_type [90] = Y2541_pgtype27;
	Y2541_gen_type [91] = Y2541_pgtype28;
	Y2541_gen_type [92] = Y2541_pgtype29;
	Y2541_gen_type [93] = Y2541_pgtype30;
	Y2541_gen_type [94] = Y2541_pgtype31;
	Y2541_gen_type [95] = Y2541_pgtype32;
	Y2541_gen_type [96] = Y2541_pgtype33;
	Y2541_gen_type [97] = Y2541_pgtype34;
	Y2541_gen_type [98] = Y2541_pgtype35;
	Y2541_gen_type [99] = Y2541_pgtype36;
	Y2541_gen_type [100] = Y2541_pgtype37;
	Y2541_gen_type [101] = Y2541_pgtype38;
	Y2541_gen_type [142] = Y2541_pgtype39;
	Y2541_gen_type [143] = Y2541_pgtype40;
	Y2541_gen_type [144] = Y2541_pgtype41;
	Y2541_gen_type [145] = Y2541_pgtype42;
	Y2541_gen_type [146] = Y2541_pgtype43;
	Y2541_gen_type [147] = Y2541_pgtype44;
	Y2541_gen_type [148] = Y2541_pgtype45;
	Y2541_gen_type [149] = Y2541_pgtype46;
	Y2541_gen_type [150] = Y2541_pgtype47;
	Y2541_gen_type [151] = Y2541_pgtype48;
	Y2541_gen_type [152] = Y2541_pgtype49;
	Y2541_gen_type [153] = Y2541_pgtype50;
	Y2541_gen_type [154] = Y2541_pgtype51;
	Y2541_gen_type [155] = Y2541_pgtype52;
	Y2541_gen_type [156] = Y2541_pgtype53;
	Y2541_gen_type [157] = Y2541_pgtype54;
	Y2541_gen_type [158] = Y2541_pgtype55;
	Y2541_gen_type [159] = Y2541_pgtype56;
	Y2541_gen_type [160] = Y2541_pgtype57;
	Y2541_gen_type [161] = Y2541_pgtype58;
	Y2541_gen_type [162] = Y2541_pgtype59;
	Y2541_gen_type [163] = Y2541_pgtype60;
	Y2541_gen_type [164] = Y2541_pgtype61;
	Y2541_gen_type [165] = Y2541_pgtype62;
	Y2541_gen_type [166] = Y2541_pgtype63;
	Y2541_gen_type [167] = Y2541_pgtype64;
	Y2541_gen_type [168] = Y2541_pgtype65;
	Y2541_gen_type [169] = Y2541_pgtype66;
	Y2541_gen_type [170] = Y2541_pgtype67;
	Y2541_gen_type [171] = Y2541_pgtype68;
	Y2541_gen_type [172] = Y2541_pgtype69;
	Y2541_gen_type [173] = Y2541_pgtype70;
	Y2541_gen_type [174] = Y2541_pgtype71;
	Y2541_gen_type [175] = Y2541_pgtype72;
	Y2541_gen_type [176] = Y2541_pgtype73;
	Y2541_gen_type [177] = Y2541_pgtype74;
	Y2541_gen_type [178] = Y2541_pgtype75;
	Y2541_gen_type [179] = Y2541_pgtype76;
	Y2541_gen_type [180] = Y2541_pgtype77;
	Y2541_gen_type [181] = Y2541_pgtype78;
	Y2541_gen_type [182] = Y2541_pgtype79;
	Y2541_gen_type [183] = Y2541_pgtype80;
	Y2541_gen_type [184] = Y2541_pgtype81;
	Y2541_gen_type [185] = Y2541_pgtype82;
	Y2541_gen_type [186] = Y2541_pgtype83;
	Y2541_gen_type [187] = Y2541_pgtype84;
	Y2541_gen_type [188] = Y2541_pgtype85;
	Y2541_gen_type [189] = Y2541_pgtype86;
	Y2541_gen_type [190] = Y2541_pgtype87;
	Y2541_gen_type [191] = Y2541_pgtype88;
	Y2541_gen_type [192] = Y2541_pgtype89;
	Y2541_gen_type [193] = Y2541_pgtype90;
	Y2541_gen_type [194] = Y2541_pgtype91;
	Y2541_gen_type [195] = Y2541_pgtype92;
	Y2541_gen_type [204] = Y2541_pgtype93;
	Y2541_gen_type [205] = Y2541_pgtype94;
	Y2541_gen_type [206] = Y2541_pgtype95;
	Y2541_gen_type [207] = Y2541_pgtype96;
	Y2541_gen_type [208] = Y2541_pgtype97;
	Y2541_gen_type [209] = Y2541_pgtype98;
	Y2541_gen_type [210] = Y2541_pgtype99;
	Y2541_gen_type [211] = Y2541_pgtype100;
	Y2541_gen_type [212] = Y2541_pgtype101;
	Y2541_gen_type [213] = Y2541_pgtype102;
	Y2541_gen_type [214] = Y2541_pgtype103;
	Y2541_gen_type [215] = Y2541_pgtype104;
	Y2541_gen_type [216] = Y2541_pgtype105;
	Y2541[39] = 844;
	{long i; for (i = 102; i < 105; i++) Y2541[i] = 832;};
	Y2541[441] = 832;
	Y2541[445] = 832;
}

char *(*R2547[25])();
void R2547_init () {
	R2547[0] = (char *(*)()) F647_3468;
	R2547[1] = (char *(*)()) F648_3468;
	R2547[3] = (char *(*)()) F649_3511;
	R2547[13] = (char *(*)()) F660_3630;
	R2547[14] = (char *(*)()) F661_3630;
	R2547[15] = (char *(*)()) F662_3630;
	R2547[16] = (char *(*)()) F663_3630;
	R2547[17] = (char *(*)()) F664_3630;
	R2547[18] = (char *(*)()) F665_3630;
	R2547[19] = (char *(*)()) F666_3630;
	R2547[20] = (char *(*)()) F667_3630;
	R2547[21] = (char *(*)()) F668_3630;
	R2547[22] = (char *(*)()) F669_3630;
	R2547[23] = (char *(*)()) F670_3630;
	R2547[24] = (char *(*)()) F671_3630;
}

static EIF_TYPE_INDEX Y2547_pgtype0[] = {112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2547_pgtype1[] = {113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2547_pgtype2[] = {114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2547_pgtype3[] = {114,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y2547_gen_type [205];
EIF_TYPE_INDEX Y2547 [205];
void Y2547_init (void)
{
	egc_routines_types [2547] = Y2547;
	egc_routines_gen_types [2547] = Y2547_gen_type;
	egc_routines_offset [2547] = 466;
	Y2547_gen_type [180] = Y2547_pgtype0;
	Y2547_gen_type [181] = Y2547_pgtype1;
	Y2547_gen_type [182] = Y2547_pgtype2;
	Y2547_gen_type [183] = Y2547_pgtype3;
	{long i; for (i = 0; i < 12; i++) Y2547[i] = 109;};
	{long i; for (i = 130; i < 180; i++) Y2547[i] = 109;};
	Y2547[180] = 112;
	Y2547[181] = 113;
	{long i; for (i = 182; i < 184; i++) Y2547[i] = 114;};
	{long i; for (i = 193; i < 205; i++) Y2547[i] = 111;};
}

char *(*R2549[25])();
void R2549_init () {
	R2549[0] = (char *(*)()) F647_3487;
	R2549[1] = (char *(*)()) F648_3487;
	R2549[3] = (char *(*)()) F647_3487;
	R2549[13] = (char *(*)()) F660_3655;
	R2549[14] = (char *(*)()) F661_3655;
	R2549[15] = (char *(*)()) F662_3655;
	R2549[16] = (char *(*)()) F663_3655;
	R2549[17] = (char *(*)()) F664_3655;
	R2549[18] = (char *(*)()) F665_3655;
	R2549[19] = (char *(*)()) F666_3655;
	R2549[20] = (char *(*)()) F667_3655;
	R2549[21] = (char *(*)()) F668_3655;
	R2549[22] = (char *(*)()) F669_3655;
	R2549[23] = (char *(*)()) F670_3655;
	R2549[24] = (char *(*)()) F671_3655;
}

char *(*R2561[343])();
void R2561_init () {
	{long i; for (i = 0; i < 2; i++) R2561[i] = (char *(*)()) F557_2984;}
	R2561[27] = (char *(*)()) F585_3357;
	R2561[28] = (char *(*)()) F586_3357;
	R2561[29] = (char *(*)()) F587_3357;
	R2561[30] = (char *(*)()) F588_3357;
	R2561[31] = (char *(*)()) F589_3357;
	R2561[32] = (char *(*)()) F590_3357;
	R2561[33] = (char *(*)()) F591_3357;
	R2561[34] = (char *(*)()) F592_3357;
	R2561[35] = (char *(*)()) F593_3357;
	R2561[36] = (char *(*)()) F594_3357;
	R2561[37] = (char *(*)()) F595_3357;
	R2561[38] = (char *(*)()) F596_3357;
	R2561[89] = (char *(*)()) F647_3471;
	R2561[90] = (char *(*)()) F648_3471;
	R2561[92] = (char *(*)()) F647_3471;
	R2561[102] = (char *(*)()) F660_3640;
	R2561[103] = (char *(*)()) F661_3640;
	R2561[104] = (char *(*)()) F662_3640;
	R2561[105] = (char *(*)()) F663_3640;
	R2561[106] = (char *(*)()) F664_3640;
	R2561[107] = (char *(*)()) F665_3640;
	R2561[108] = (char *(*)()) F666_3640;
	R2561[109] = (char *(*)()) F667_3640;
	R2561[110] = (char *(*)()) F668_3640;
	R2561[111] = (char *(*)()) F669_3640;
	R2561[112] = (char *(*)()) F670_3640;
	R2561[113] = (char *(*)()) F671_3640;
	R2561[115] = (char *(*)()) F673_3721;
	R2561[116] = (char *(*)()) F674_3721;
	R2561[117] = (char *(*)()) F675_3721;
	R2561[118] = (char *(*)()) F676_3721;
	R2561[119] = (char *(*)()) F677_3721;
	R2561[120] = (char *(*)()) F673_3721;
	R2561[121] = (char *(*)()) F675_3721;
	R2561[122] = (char *(*)()) F673_3721;
	{long i; for (i = 337; i < 339; i++) R2561[i] = (char *(*)()) F893_5685;}
	R2561[341] = (char *(*)()) F897_5882;
	R2561[342] = (char *(*)()) F900_6035;
}

char *(*R2564[315])();
void R2564_init () {
	R2564[0] = (char *(*)()) F585_3358;
	R2564[1] = (char *(*)()) F586_3358;
	R2564[2] = (char *(*)()) F587_3358;
	R2564[3] = (char *(*)()) F588_3358;
	R2564[4] = (char *(*)()) F589_3358;
	R2564[5] = (char *(*)()) F590_3358;
	R2564[6] = (char *(*)()) F591_3358;
	R2564[7] = (char *(*)()) F592_3358;
	R2564[8] = (char *(*)()) F593_3358;
	R2564[9] = (char *(*)()) F594_3358;
	R2564[10] = (char *(*)()) F595_3358;
	R2564[11] = (char *(*)()) F596_3358;
	R2564[75] = (char *(*)()) F660_3641;
	R2564[76] = (char *(*)()) F661_3641;
	R2564[77] = (char *(*)()) F662_3641;
	R2564[78] = (char *(*)()) F663_3641;
	R2564[79] = (char *(*)()) F664_3641;
	R2564[80] = (char *(*)()) F665_3641;
	R2564[81] = (char *(*)()) F666_3641;
	R2564[82] = (char *(*)()) F667_3641;
	R2564[83] = (char *(*)()) F668_3641;
	R2564[84] = (char *(*)()) F669_3641;
	R2564[85] = (char *(*)()) F670_3641;
	R2564[86] = (char *(*)()) F671_3641;
	{long i; for (i = 310; i < 312; i++) R2564[i] = (char *(*)()) F893_5684;}
	R2564[314] = (char *(*)()) F897_5881;
}

char *(*R2568[315])();
void R2568_init () {
	R2568[0] = (char *(*)()) F521_2941;
	R2568[1] = (char *(*)()) F522_2941;
	R2568[2] = (char *(*)()) F523_2941;
	R2568[3] = (char *(*)()) F524_2941;
	R2568[4] = (char *(*)()) F525_2941;
	R2568[5] = (char *(*)()) F526_2941;
	R2568[6] = (char *(*)()) F527_2941;
	R2568[7] = (char *(*)()) F528_2941;
	R2568[8] = (char *(*)()) F529_2941;
	R2568[9] = (char *(*)()) F530_2941;
	R2568[10] = (char *(*)()) F531_2941;
	R2568[11] = (char *(*)()) F532_2941;
	R2568[75] = (char *(*)()) F521_2941;
	R2568[76] = (char *(*)()) F522_2941;
	R2568[77] = (char *(*)()) F523_2941;
	R2568[78] = (char *(*)()) F524_2941;
	R2568[79] = (char *(*)()) F525_2941;
	R2568[80] = (char *(*)()) F526_2941;
	R2568[81] = (char *(*)()) F527_2941;
	R2568[82] = (char *(*)()) F528_2941;
	R2568[83] = (char *(*)()) F529_2941;
	R2568[84] = (char *(*)()) F530_2941;
	R2568[85] = (char *(*)()) F531_2941;
	R2568[86] = (char *(*)()) F532_2941;
	{long i; for (i = 310; i < 312; i++) R2568[i] = (char *(*)()) F525_2941;}
	R2568[314] = (char *(*)()) F524_2941;
}

char *(*R2570[315])();
void R2570_init () {
	R2570[0] = (char *(*)()) F585_3388;
	R2570[1] = (char *(*)()) F586_3388;
	R2570[2] = (char *(*)()) F587_3388;
	R2570[3] = (char *(*)()) F588_3388;
	R2570[4] = (char *(*)()) F589_3388;
	R2570[5] = (char *(*)()) F590_3388;
	R2570[6] = (char *(*)()) F591_3388;
	R2570[7] = (char *(*)()) F592_3388;
	R2570[8] = (char *(*)()) F593_3388;
	R2570[9] = (char *(*)()) F594_3388;
	R2570[10] = (char *(*)()) F595_3388;
	R2570[11] = (char *(*)()) F596_3388;
	R2570[75] = (char *(*)()) F660_3667;
	R2570[76] = (char *(*)()) F661_3667;
	R2570[77] = (char *(*)()) F662_3667;
	R2570[78] = (char *(*)()) F663_3667;
	R2570[79] = (char *(*)()) F664_3667;
	R2570[80] = (char *(*)()) F665_3667;
	R2570[81] = (char *(*)()) F666_3667;
	R2570[82] = (char *(*)()) F667_3667;
	R2570[83] = (char *(*)()) F668_3667;
	R2570[84] = (char *(*)()) F669_3667;
	R2570[85] = (char *(*)()) F670_3667;
	R2570[86] = (char *(*)()) F671_3667;
	{long i; for (i = 310; i < 312; i++) R2570[i] = (char *(*)()) F895_5809;}
	R2570[314] = (char *(*)()) F899_6009;
}

char *(*R2575[343])();
void R2575_init () {
	R2575[0] = (char *(*)()) F557_2954;
	R2575[1] = (char *(*)()) F559_3235;
	R2575[342] = (char *(*)()) F559_3235;
}

char *(*R2600[343])();
void R2600_init () {
	{long i; for (i = 0; i < 2; i++) R2600[i] = (char *(*)()) F557_2988;}
	R2600[342] = (char *(*)()) F900_6033;
}

char *(*R2669[343])();
void R2669_init () {
	R2669[0] = (char *(*)()) F558_3229;
	R2669[1] = (char *(*)()) F557_3112;
	R2669[342] = (char *(*)()) F557_3112;
}

char *(*R2670[343])();
void R2670_init () {
	{long i; for (i = 0; i < 2; i++) R2670[i] = (char *(*)()) F557_3113;}
	R2670[342] = (char *(*)()) F900_6089;
}

char *(*R2685[343])();
void R2685_init () {
	R2685[0] = (char *(*)()) F558_3230;
	R2685[1] = (char *(*)()) F557_3128;
	R2685[342] = (char *(*)()) F557_3128;
}

char *(*R2771[315])();
void R2771_init () {
	R2771[0] = (char *(*)()) F585_3350;
	R2771[1] = (char *(*)()) F586_3350_2771_26;
	R2771[2] = (char *(*)()) F587_3350_2771_26;
	R2771[3] = (char *(*)()) F588_3350_2771_26;
	R2771[4] = (char *(*)()) F589_3350_2771_26;
	R2771[5] = (char *(*)()) F590_3350_2771_26;
	R2771[6] = (char *(*)()) F591_3350_2771_26;
	R2771[7] = (char *(*)()) F592_3350_2771_26;
	R2771[8] = (char *(*)()) F593_3350_2771_26;
	R2771[9] = (char *(*)()) F594_3350_2771_26;
	R2771[10] = (char *(*)()) F595_3350_2771_26;
	R2771[11] = (char *(*)()) F596_3350_2771_26;
	R2771[62] = (char *(*)()) F597_3407;
	R2771[63] = (char *(*)()) F599_3407_2771_26;
	R2771[65] = (char *(*)()) F597_3407;
	R2771[75] = (char *(*)()) F660_3625;
	R2771[76] = (char *(*)()) F661_3625_2771_26;
	R2771[77] = (char *(*)()) F662_3625_2771_26;
	R2771[78] = (char *(*)()) F663_3625_2771_26;
	R2771[79] = (char *(*)()) F664_3625_2771_26;
	R2771[80] = (char *(*)()) F665_3625_2771_26;
	R2771[81] = (char *(*)()) F666_3625_2771_26;
	R2771[82] = (char *(*)()) F667_3625_2771_26;
	R2771[83] = (char *(*)()) F668_3625_2771_26;
	R2771[84] = (char *(*)()) F669_3625_2771_26;
	R2771[85] = (char *(*)()) F670_3625_2771_26;
	R2771[86] = (char *(*)()) F671_3625_2771_26;
	R2771[88] = (char *(*)()) F673_3719;
	R2771[89] = (char *(*)()) F674_3719;
	R2771[90] = (char *(*)()) F675_3719_2771_26;
	R2771[91] = (char *(*)()) F676_3719_2771_26;
	R2771[92] = (char *(*)()) F677_3719_2771_26;
	R2771[93] = (char *(*)()) F673_3719;
	R2771[94] = (char *(*)()) F675_3719_2771_26;
	R2771[95] = (char *(*)()) F673_3719;
	R2771[100] = (char *(*)()) F685_3935;
	R2771[101] = (char *(*)()) F686_3935_2771_26;
	R2771[102] = (char *(*)()) F687_3935_2771_26;
	R2771[103] = (char *(*)()) F688_3935_2771_26;
	R2771[104] = (char *(*)()) F689_3935_2771_26;
	R2771[105] = (char *(*)()) F690_3935_2771_26;
	R2771[106] = (char *(*)()) F691_3935_2771_26;
	R2771[107] = (char *(*)()) F692_3935_2771_26;
	R2771[108] = (char *(*)()) F693_3935_2771_26;
	R2771[109] = (char *(*)()) F694_3935_2771_26;
	R2771[110] = (char *(*)()) F695_3935_2771_26;
	R2771[111] = (char *(*)()) F696_3935_2771_26;
	R2771[227] = (char *(*)()) F812_4300;
	R2771[309] = (char *(*)()) F894_5720_2771_26;
	{long i; for (i = 310; i < 312; i++) R2771[i] = (char *(*)()) F895_5742_2771_26;}
	R2771[313] = (char *(*)()) F898_5920_2771_26;
	R2771[314] = (char *(*)()) F899_5943_2771_26;
}
static EIF_REFERENCE F586_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F586_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F587_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F588_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F589_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F591_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F592_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F593_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F594_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_3350_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_3350(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F599_3407_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F599_3407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3625_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3625(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3719_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F675_3719(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3719_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F676_3719(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3719_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F677_3719(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F686_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F686_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F687_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F688_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F689_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F690_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F691_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F692_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F693_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F694_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F695_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_3935_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F696_3935(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_5720_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F894_5720(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_5742_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F895_5742(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_5920_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F898_5920(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_5943_2771_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F899_5943(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R2772[315])();
void R2772_init () {
	R2772[0] = (char *(*)()) F585_3355;
	R2772[1] = (char *(*)()) F586_3355;
	R2772[2] = (char *(*)()) F587_3355;
	R2772[3] = (char *(*)()) F588_3355;
	R2772[4] = (char *(*)()) F589_3355;
	R2772[5] = (char *(*)()) F590_3355;
	R2772[6] = (char *(*)()) F591_3355;
	R2772[7] = (char *(*)()) F592_3355;
	R2772[8] = (char *(*)()) F593_3355;
	R2772[9] = (char *(*)()) F594_3355;
	R2772[10] = (char *(*)()) F595_3355;
	R2772[11] = (char *(*)()) F596_3355;
	R2772[62] = (char *(*)()) F597_3410;
	R2772[63] = (char *(*)()) F599_3410;
	R2772[65] = (char *(*)()) F597_3410;
	R2772[75] = (char *(*)()) F597_3410;
	R2772[76] = (char *(*)()) F598_3410;
	R2772[77] = (char *(*)()) F599_3410;
	R2772[78] = (char *(*)()) F600_3410;
	R2772[79] = (char *(*)()) F601_3410;
	R2772[80] = (char *(*)()) F602_3410;
	R2772[81] = (char *(*)()) F603_3410;
	R2772[82] = (char *(*)()) F604_3410;
	R2772[83] = (char *(*)()) F605_3410;
	R2772[84] = (char *(*)()) F606_3410;
	R2772[85] = (char *(*)()) F607_3410;
	R2772[86] = (char *(*)()) F608_3410;
	R2772[88] = (char *(*)()) F673_3724;
	R2772[89] = (char *(*)()) F674_3724;
	R2772[90] = (char *(*)()) F675_3724;
	R2772[91] = (char *(*)()) F676_3724;
	R2772[92] = (char *(*)()) F677_3724;
	R2772[93] = (char *(*)()) F673_3724;
	R2772[94] = (char *(*)()) F675_3724;
	R2772[95] = (char *(*)()) F673_3724;
	R2772[100] = (char *(*)()) F685_3943;
	R2772[101] = (char *(*)()) F686_3943;
	R2772[102] = (char *(*)()) F687_3943;
	R2772[103] = (char *(*)()) F688_3943;
	R2772[104] = (char *(*)()) F689_3943;
	R2772[105] = (char *(*)()) F690_3943;
	R2772[106] = (char *(*)()) F691_3943;
	R2772[107] = (char *(*)()) F692_3943;
	R2772[108] = (char *(*)()) F693_3943;
	R2772[109] = (char *(*)()) F694_3943;
	R2772[110] = (char *(*)()) F695_3943;
	R2772[111] = (char *(*)()) F696_3943;
	R2772[227] = (char *(*)()) F812_4330;
	{long i; for (i = 309; i < 312; i++) R2772[i] = (char *(*)()) F893_5687;}
	{long i; for (i = 313; i < 315; i++) R2772[i] = (char *(*)()) F897_5884;}
}

EIF_TYPE_INDEX *Y2772_gen_type [340];
EIF_TYPE_INDEX Y2772 [340];
void Y2772_init (void)
{
	egc_routines_types [2772] = Y2772;
	egc_routines_gen_types [2772] = Y2772_gen_type;
	egc_routines_offset [2772] = 559;
	{long i; for (i = 0; i < 91; i++) Y2772[i] = 844;};
	{long i; for (i = 100; i < 112; i++) Y2772[i] = 844;};
	{long i; for (i = 113; i < 121; i++) Y2772[i] = 844;};
	{long i; for (i = 125; i < 137; i++) Y2772[i] = 844;};
	Y2772[252] = 844;
	{long i; for (i = 333; i < 340; i++) Y2772[i] = 844;};
}

char *(*R2773[315])();
void R2773_init () {
	R2773[0] = (char *(*)()) F585_3356;
	R2773[1] = (char *(*)()) F586_3356;
	R2773[2] = (char *(*)()) F587_3356;
	R2773[3] = (char *(*)()) F588_3356;
	R2773[4] = (char *(*)()) F589_3356;
	R2773[5] = (char *(*)()) F590_3356;
	R2773[6] = (char *(*)()) F591_3356;
	R2773[7] = (char *(*)()) F592_3356;
	R2773[8] = (char *(*)()) F593_3356;
	R2773[9] = (char *(*)()) F594_3356;
	R2773[10] = (char *(*)()) F595_3356;
	R2773[11] = (char *(*)()) F596_3356;
	R2773[62] = (char *(*)()) F647_3471;
	R2773[63] = (char *(*)()) F648_3471;
	R2773[65] = (char *(*)()) F647_3471;
	R2773[75] = (char *(*)()) F660_3640;
	R2773[76] = (char *(*)()) F661_3640;
	R2773[77] = (char *(*)()) F662_3640;
	R2773[78] = (char *(*)()) F663_3640;
	R2773[79] = (char *(*)()) F664_3640;
	R2773[80] = (char *(*)()) F665_3640;
	R2773[81] = (char *(*)()) F666_3640;
	R2773[82] = (char *(*)()) F667_3640;
	R2773[83] = (char *(*)()) F668_3640;
	R2773[84] = (char *(*)()) F669_3640;
	R2773[85] = (char *(*)()) F670_3640;
	R2773[86] = (char *(*)()) F671_3640;
	R2773[88] = (char *(*)()) F673_3725;
	R2773[89] = (char *(*)()) F674_3725;
	R2773[90] = (char *(*)()) F675_3725;
	R2773[91] = (char *(*)()) F676_3725;
	R2773[92] = (char *(*)()) F677_3725;
	R2773[93] = (char *(*)()) F673_3725;
	R2773[94] = (char *(*)()) F675_3725;
	R2773[95] = (char *(*)()) F673_3725;
	R2773[100] = (char *(*)()) F685_3944;
	R2773[101] = (char *(*)()) F686_3944;
	R2773[102] = (char *(*)()) F687_3944;
	R2773[103] = (char *(*)()) F688_3944;
	R2773[104] = (char *(*)()) F689_3944;
	R2773[105] = (char *(*)()) F690_3944;
	R2773[106] = (char *(*)()) F691_3944;
	R2773[107] = (char *(*)()) F692_3944;
	R2773[108] = (char *(*)()) F693_3944;
	R2773[109] = (char *(*)()) F694_3944;
	R2773[110] = (char *(*)()) F695_3944;
	R2773[111] = (char *(*)()) F696_3944;
	R2773[227] = (char *(*)()) F812_4329;
	{long i; for (i = 309; i < 312; i++) R2773[i] = (char *(*)()) F893_5685;}
	{long i; for (i = 313; i < 315; i++) R2773[i] = (char *(*)()) F897_5882;}
}

char *(*R2775[315])();
void R2775_init () {
	R2775[0] = (char *(*)()) F585_3365;
	R2775[1] = (char *(*)()) F586_3365;
	R2775[2] = (char *(*)()) F587_3365;
	R2775[3] = (char *(*)()) F588_3365;
	R2775[4] = (char *(*)()) F589_3365;
	R2775[5] = (char *(*)()) F590_3365;
	R2775[6] = (char *(*)()) F591_3365;
	R2775[7] = (char *(*)()) F592_3365;
	R2775[8] = (char *(*)()) F593_3365;
	R2775[9] = (char *(*)()) F594_3365;
	R2775[10] = (char *(*)()) F595_3365;
	R2775[11] = (char *(*)()) F596_3365;
	R2775[62] = (char *(*)()) F597_3415;
	R2775[63] = (char *(*)()) F599_3415;
	R2775[65] = (char *(*)()) F597_3415;
	R2775[75] = (char *(*)()) F660_3646;
	R2775[76] = (char *(*)()) F661_3646;
	R2775[77] = (char *(*)()) F662_3646;
	R2775[78] = (char *(*)()) F663_3646;
	R2775[79] = (char *(*)()) F664_3646;
	R2775[80] = (char *(*)()) F665_3646;
	R2775[81] = (char *(*)()) F666_3646;
	R2775[82] = (char *(*)()) F667_3646;
	R2775[83] = (char *(*)()) F668_3646;
	R2775[84] = (char *(*)()) F669_3646;
	R2775[85] = (char *(*)()) F670_3646;
	R2775[86] = (char *(*)()) F671_3646;
	R2775[88] = (char *(*)()) F673_3741;
	R2775[89] = (char *(*)()) F674_3741;
	R2775[90] = (char *(*)()) F675_3741;
	R2775[91] = (char *(*)()) F676_3741;
	R2775[92] = (char *(*)()) F677_3741;
	R2775[93] = (char *(*)()) F673_3741;
	R2775[94] = (char *(*)()) F675_3741;
	R2775[95] = (char *(*)()) F673_3741;
	R2775[100] = (char *(*)()) F685_3949;
	R2775[101] = (char *(*)()) F686_3949;
	R2775[102] = (char *(*)()) F687_3949;
	R2775[103] = (char *(*)()) F688_3949;
	R2775[104] = (char *(*)()) F689_3949;
	R2775[105] = (char *(*)()) F690_3949;
	R2775[106] = (char *(*)()) F691_3949;
	R2775[107] = (char *(*)()) F692_3949;
	R2775[108] = (char *(*)()) F693_3949;
	R2775[109] = (char *(*)()) F694_3949;
	R2775[110] = (char *(*)()) F695_3949;
	R2775[111] = (char *(*)()) F696_3949;
	R2775[227] = (char *(*)()) F812_4327;
	{long i; for (i = 309; i < 312; i++) R2775[i] = (char *(*)()) F890_5545;}
	{long i; for (i = 313; i < 315; i++) R2775[i] = (char *(*)()) F890_5545;}
}

char *(*R2799[12])();
void R2799_init () {
	R2799[0] = (char *(*)()) F585_3348;
	R2799[1] = (char *(*)()) F586_3348;
	R2799[2] = (char *(*)()) F587_3348;
	R2799[3] = (char *(*)()) F588_3348;
	R2799[4] = (char *(*)()) F589_3348;
	R2799[5] = (char *(*)()) F590_3348;
	R2799[6] = (char *(*)()) F591_3348;
	R2799[7] = (char *(*)()) F592_3348;
	R2799[8] = (char *(*)()) F593_3348;
	R2799[9] = (char *(*)()) F594_3348;
	R2799[10] = (char *(*)()) F595_3348;
	R2799[11] = (char *(*)()) F596_3348;
}

char *(*R2823[12])();
void R2823_init () {
	R2823[0] = (char *(*)()) F585_3390;
	R2823[1] = (char *(*)()) F586_3390_2823_125;
	R2823[2] = (char *(*)()) F587_3390_2823_125;
	R2823[3] = (char *(*)()) F588_3390_2823_125;
	R2823[4] = (char *(*)()) F589_3390_2823_125;
	R2823[5] = (char *(*)()) F590_3390_2823_125;
	R2823[6] = (char *(*)()) F591_3390_2823_125;
	R2823[7] = (char *(*)()) F592_3390_2823_125;
	R2823[8] = (char *(*)()) F593_3390_2823_125;
	R2823[9] = (char *(*)()) F594_3390_2823_125;
	R2823[10] = (char *(*)()) F595_3390_2823_125;
	R2823[11] = (char *(*)()) F596_3390_2823_125;
}
static void F586_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F586_3390(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F587_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F587_3390(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F588_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F588_3390(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F589_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F589_3390(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F590_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F590_3390(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F591_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F591_3390(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F592_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F592_3390(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F593_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F593_3390(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F594_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F594_3390(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F595_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F595_3390(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F596_3390_2823_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F596_3390(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R2830[12])();
void R2830_init () {
	R2830[0] = (char *(*)()) F585_3402;
	R2830[1] = (char *(*)()) F586_3402;
	R2830[2] = (char *(*)()) F587_3402;
	R2830[3] = (char *(*)()) F588_3402;
	R2830[4] = (char *(*)()) F589_3402;
	R2830[5] = (char *(*)()) F590_3402;
	R2830[6] = (char *(*)()) F591_3402;
	R2830[7] = (char *(*)()) F592_3402;
	R2830[8] = (char *(*)()) F593_3402;
	R2830[9] = (char *(*)()) F594_3402;
	R2830[10] = (char *(*)()) F595_3402;
	R2830[11] = (char *(*)()) F596_3402;
}

char *(*R2833[25])();
void R2833_init () {
	R2833[0] = (char *(*)()) F647_3465;
	R2833[1] = (char *(*)()) F648_3465_2833_1;
	R2833[3] = (char *(*)()) F647_3465;
	R2833[13] = (char *(*)()) F660_3627;
	R2833[14] = (char *(*)()) F661_3627_2833_1;
	R2833[15] = (char *(*)()) F662_3627_2833_1;
	R2833[16] = (char *(*)()) F663_3627_2833_1;
	R2833[17] = (char *(*)()) F664_3627_2833_1;
	R2833[18] = (char *(*)()) F665_3627_2833_1;
	R2833[19] = (char *(*)()) F666_3627_2833_1;
	R2833[20] = (char *(*)()) F667_3627_2833_1;
	R2833[21] = (char *(*)()) F668_3627_2833_1;
	R2833[22] = (char *(*)()) F669_3627_2833_1;
	R2833[23] = (char *(*)()) F670_3627_2833_1;
	R2833[24] = (char *(*)()) F671_3627_2833_1;
}
static EIF_REFERENCE F648_3465_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F648_3465(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3627_2833_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3627(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R2834[25])();
void R2834_init () {
	R2834[0] = (char *(*)()) F647_3466;
	R2834[1] = (char *(*)()) F648_3466_2834_1;
	R2834[3] = (char *(*)()) F647_3466;
	R2834[13] = (char *(*)()) F660_3628;
	R2834[14] = (char *(*)()) F661_3628_2834_1;
	R2834[15] = (char *(*)()) F662_3628_2834_1;
	R2834[16] = (char *(*)()) F663_3628_2834_1;
	R2834[17] = (char *(*)()) F664_3628_2834_1;
	R2834[18] = (char *(*)()) F665_3628_2834_1;
	R2834[19] = (char *(*)()) F666_3628_2834_1;
	R2834[20] = (char *(*)()) F667_3628_2834_1;
	R2834[21] = (char *(*)()) F668_3628_2834_1;
	R2834[22] = (char *(*)()) F669_3628_2834_1;
	R2834[23] = (char *(*)()) F670_3628_2834_1;
	R2834[24] = (char *(*)()) F671_3628_2834_1;
}
static EIF_REFERENCE F648_3466_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F648_3466(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3628_2834_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3628(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R2835[4])();
void R2835_init () {
	R2835[0] = (char *(*)()) F647_3485;
	R2835[1] = (char *(*)()) F648_3485;
	R2835[3] = (char *(*)()) F649_3517;
}

char *(*R2836[25])();
void R2836_init () {
	R2836[0] = (char *(*)()) F647_3486;
	R2836[1] = (char *(*)()) F648_3486;
	R2836[3] = (char *(*)()) F647_3486;
	R2836[13] = (char *(*)()) F660_3654;
	R2836[14] = (char *(*)()) F661_3654;
	R2836[15] = (char *(*)()) F662_3654;
	R2836[16] = (char *(*)()) F663_3654;
	R2836[17] = (char *(*)()) F664_3654;
	R2836[18] = (char *(*)()) F665_3654;
	R2836[19] = (char *(*)()) F666_3654;
	R2836[20] = (char *(*)()) F667_3654;
	R2836[21] = (char *(*)()) F668_3654;
	R2836[22] = (char *(*)()) F669_3654;
	R2836[23] = (char *(*)()) F670_3654;
	R2836[24] = (char *(*)()) F671_3654;
}

char *(*R2838[25])();
void R2838_init () {
	R2838[0] = (char *(*)()) F647_3477;
	R2838[1] = (char *(*)()) F648_3477;
	R2838[3] = (char *(*)()) F649_3513;
	R2838[13] = (char *(*)()) F597_3417;
	R2838[14] = (char *(*)()) F598_3417;
	R2838[15] = (char *(*)()) F599_3417;
	R2838[16] = (char *(*)()) F600_3417;
	R2838[17] = (char *(*)()) F601_3417;
	R2838[18] = (char *(*)()) F602_3417;
	R2838[19] = (char *(*)()) F603_3417;
	R2838[20] = (char *(*)()) F604_3417;
	R2838[21] = (char *(*)()) F605_3417;
	R2838[22] = (char *(*)()) F606_3417;
	R2838[23] = (char *(*)()) F607_3417;
	R2838[24] = (char *(*)()) F608_3417;
}

char *(*R2847[25])();
void R2847_init () {
	R2847[0] = (char *(*)()) F647_3494;
	R2847[1] = (char *(*)()) F648_3494;
	R2847[3] = (char *(*)()) F649_3523;
	R2847[13] = (char *(*)()) F660_3665;
	R2847[14] = (char *(*)()) F661_3665;
	R2847[15] = (char *(*)()) F662_3665;
	R2847[16] = (char *(*)()) F663_3665;
	R2847[17] = (char *(*)()) F664_3665;
	R2847[18] = (char *(*)()) F665_3665;
	R2847[19] = (char *(*)()) F666_3665;
	R2847[20] = (char *(*)()) F667_3665;
	R2847[21] = (char *(*)()) F668_3665;
	R2847[22] = (char *(*)()) F669_3665;
	R2847[23] = (char *(*)()) F670_3665;
	R2847[24] = (char *(*)()) F671_3665;
}

char *(*R2861[4])();
void R2861_init () {
	R2861[0] = (char *(*)()) F647_3501;
	R2861[1] = (char *(*)()) F648_3501_2861_5;
	R2861[3] = (char *(*)()) F649_3532;
}
static EIF_REFERENCE F648_3501_2861_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F648_3501(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2865[4])();
void R2865_init () {
	R2865[0] = (char *(*)()) F647_3505;
	R2865[1] = (char *(*)()) F648_3505;
	R2865[3] = (char *(*)()) F649_3509;
}

char *(*R2867[4])();
void R2867_init () {
	R2867[0] = (char *(*)()) F647_3507;
	R2867[1] = (char *(*)()) F648_3507;
	R2867[3] = (char *(*)()) F647_3507;
}

char *(*R2910[263])();
void R2910_init () {
	R2910[0] = (char *(*)()) F660_3680;
	R2910[1] = (char *(*)()) F661_3680;
	R2910[2] = (char *(*)()) F662_3680;
	R2910[3] = (char *(*)()) F663_3680;
	R2910[4] = (char *(*)()) F664_3680;
	R2910[5] = (char *(*)()) F665_3680;
	R2910[6] = (char *(*)()) F666_3680;
	R2910[7] = (char *(*)()) F667_3680;
	R2910[8] = (char *(*)()) F668_3680;
	R2910[9] = (char *(*)()) F669_3680;
	R2910[10] = (char *(*)()) F670_3680;
	R2910[11] = (char *(*)()) F671_3680;
	R2910[13] = (char *(*)()) F673_3762;
	R2910[14] = (char *(*)()) F674_3762;
	R2910[15] = (char *(*)()) F675_3762;
	R2910[16] = (char *(*)()) F676_3762;
	R2910[17] = (char *(*)()) F677_3762;
	R2910[18] = (char *(*)()) F673_3762;
	R2910[19] = (char *(*)()) F675_3762;
	R2910[20] = (char *(*)()) F673_3762;
	R2910[152] = (char *(*)()) F812_4408;
	{long i; for (i = 235; i < 237; i++) R2910[i] = (char *(*)()) F895_5826;}
	R2910[238] = (char *(*)()) F898_5936;
	R2910[239] = (char *(*)()) F899_6027;
	R2910[259] = (char *(*)()) F672_3694;
	R2910[262] = (char *(*)()) F672_3694;
}

char *(*R2926[12])();
void R2926_init () {
	R2926[0] = (char *(*)()) F660_3623;
	R2926[1] = (char *(*)()) F661_3623;
	R2926[2] = (char *(*)()) F662_3623;
	R2926[3] = (char *(*)()) F663_3623;
	R2926[4] = (char *(*)()) F664_3623;
	R2926[5] = (char *(*)()) F665_3623;
	R2926[6] = (char *(*)()) F666_3623;
	R2926[7] = (char *(*)()) F667_3623;
	R2926[8] = (char *(*)()) F668_3623;
	R2926[9] = (char *(*)()) F669_3623;
	R2926[10] = (char *(*)()) F670_3623;
	R2926[11] = (char *(*)()) F671_3623;
}

char *(*R2930[12])();
void R2930_init () {
	R2930[0] = (char *(*)()) F660_3642;
	R2930[1] = (char *(*)()) F661_3642;
	R2930[2] = (char *(*)()) F662_3642;
	R2930[3] = (char *(*)()) F663_3642;
	R2930[4] = (char *(*)()) F664_3642;
	R2930[5] = (char *(*)()) F665_3642;
	R2930[6] = (char *(*)()) F666_3642;
	R2930[7] = (char *(*)()) F667_3642;
	R2930[8] = (char *(*)()) F668_3642;
	R2930[9] = (char *(*)()) F669_3642;
	R2930[10] = (char *(*)()) F670_3642;
	R2930[11] = (char *(*)()) F671_3642;
}

char *(*R2947[8])();
void R2947_init () {
	R2947[0] = (char *(*)()) F673_3703;
	R2947[1] = (char *(*)()) F674_3703;
	R2947[2] = (char *(*)()) F675_3703;
	R2947[3] = (char *(*)()) F676_3703;
	R2947[4] = (char *(*)()) F677_3703;
	R2947[5] = (char *(*)()) F673_3703;
	R2947[6] = (char *(*)()) F675_3703;
	R2947[7] = (char *(*)()) F673_3703;
}

char *(*R2950[8])();
void R2950_init () {
	R2950[0] = (char *(*)()) F673_3706;
	R2950[1] = (char *(*)()) F674_3706;
	R2950[2] = (char *(*)()) F675_3706;
	R2950[3] = (char *(*)()) F676_3706;
	R2950[4] = (char *(*)()) F677_3706;
	R2950[5] = (char *(*)()) F673_3706;
	R2950[6] = (char *(*)()) F675_3706;
	R2950[7] = (char *(*)()) F673_3706;
}

char *(*R2951[8])();
void R2951_init () {
	R2951[0] = (char *(*)()) F673_3707;
	R2951[1] = (char *(*)()) F674_3707;
	R2951[2] = (char *(*)()) F675_3707_2951_1;
	R2951[3] = (char *(*)()) F676_3707_2951_1;
	R2951[4] = (char *(*)()) F677_3707_2951_1;
	R2951[5] = (char *(*)()) F673_3707;
	R2951[6] = (char *(*)()) F675_3707_2951_1;
	R2951[7] = (char *(*)()) F673_3707;
}
static EIF_REFERENCE F675_3707_2951_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F675_3707(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3707_2951_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F676_3707(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3707_2951_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F677_3707(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R2959[8])();
void R2959_init () {
	R2959[0] = (char *(*)()) F673_3720;
	R2959[1] = (char *(*)()) F674_3720_2959_18;
	R2959[2] = (char *(*)()) F675_3720;
	R2959[3] = (char *(*)()) F676_3720_2959_18;
	R2959[4] = (char *(*)()) F677_3720;
	R2959[5] = (char *(*)()) F678_3817;
	R2959[6] = (char *(*)()) F679_3817;
	R2959[7] = (char *(*)()) F673_3720;
}
static EIF_INTEGER_32 F674_3720_2959_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F674_3720(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F676_3720_2959_18 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F676_3720(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2961[8])();
void R2961_init () {
	R2961[0] = (char *(*)()) F673_3727;
	R2961[1] = (char *(*)()) F674_3727_2961_3;
	R2961[2] = (char *(*)()) F675_3727;
	R2961[3] = (char *(*)()) F676_3727_2961_3;
	R2961[4] = (char *(*)()) F677_3727;
	R2961[5] = (char *(*)()) F678_3819;
	R2961[6] = (char *(*)()) F679_3819;
	R2961[7] = (char *(*)()) F673_3727;
}
static EIF_BOOLEAN F674_3727_2961_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F674_3727(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F676_3727_2961_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F676_3727(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2967[8])();
void R2967_init () {
	R2967[0] = (char *(*)()) F673_3735;
	R2967[1] = (char *(*)()) F674_3735;
	R2967[2] = (char *(*)()) F675_3735;
	R2967[3] = (char *(*)()) F676_3735;
	R2967[4] = (char *(*)()) F677_3735;
	R2967[5] = (char *(*)()) F673_3735;
	R2967[6] = (char *(*)()) F675_3735;
	R2967[7] = (char *(*)()) F673_3735;
}

char *(*R2968[8])();
void R2968_init () {
	R2968[0] = (char *(*)()) F673_3736;
	R2968[1] = (char *(*)()) F674_3736;
	R2968[2] = (char *(*)()) F675_3736;
	R2968[3] = (char *(*)()) F676_3736;
	R2968[4] = (char *(*)()) F677_3736;
	R2968[5] = (char *(*)()) F673_3736;
	R2968[6] = (char *(*)()) F675_3736;
	R2968[7] = (char *(*)()) F673_3736;
}

char *(*R2974[8])();
void R2974_init () {
	R2974[0] = (char *(*)()) F673_3743;
	R2974[1] = (char *(*)()) F674_3743;
	R2974[2] = (char *(*)()) F675_3743;
	R2974[3] = (char *(*)()) F676_3743;
	R2974[4] = (char *(*)()) F677_3743;
	R2974[5] = (char *(*)()) F673_3743;
	R2974[6] = (char *(*)()) F675_3743;
	R2974[7] = (char *(*)()) F673_3743;
}

char *(*R2976[8])();
void R2976_init () {
	R2976[0] = (char *(*)()) F673_3745;
	R2976[1] = (char *(*)()) F674_3745_2976_4;
	R2976[2] = (char *(*)()) F675_3745;
	R2976[3] = (char *(*)()) F676_3745_2976_4;
	R2976[4] = (char *(*)()) F677_3745;
	R2976[5] = (char *(*)()) F673_3745;
	R2976[6] = (char *(*)()) F675_3745;
	R2976[7] = (char *(*)()) F673_3745;
}
static void F674_3745_2976_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3745(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F676_3745_2976_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F676_3745(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2978[8])();
void R2978_init () {
	R2978[0] = (char *(*)()) F673_3747;
	R2978[1] = (char *(*)()) F674_3747;
	R2978[2] = (char *(*)()) F675_3747;
	R2978[3] = (char *(*)()) F676_3747;
	R2978[4] = (char *(*)()) F677_3747;
	R2978[5] = (char *(*)()) F673_3747;
	R2978[6] = (char *(*)()) F675_3747;
	R2978[7] = (char *(*)()) F673_3747;
}

char *(*R2979[8])();
void R2979_init () {
	R2979[0] = (char *(*)()) F673_3748;
	R2979[1] = (char *(*)()) F674_3748;
	R2979[2] = (char *(*)()) F675_3748;
	R2979[3] = (char *(*)()) F676_3748;
	R2979[4] = (char *(*)()) F677_3748;
	R2979[5] = (char *(*)()) F673_3748;
	R2979[6] = (char *(*)()) F675_3748;
	R2979[7] = (char *(*)()) F673_3748;
}

char *(*R2985[8])();
void R2985_init () {
	R2985[0] = (char *(*)()) F673_3761;
	R2985[1] = (char *(*)()) F674_3761;
	R2985[2] = (char *(*)()) F675_3761;
	R2985[3] = (char *(*)()) F676_3761;
	R2985[4] = (char *(*)()) F677_3761;
	R2985[5] = (char *(*)()) F678_3821;
	R2985[6] = (char *(*)()) F679_3821;
	R2985[7] = (char *(*)()) F673_3761;
}

char *(*R2994[8])();
void R2994_init () {
	R2994[0] = (char *(*)()) F673_3771;
	R2994[1] = (char *(*)()) F674_3771;
	R2994[2] = (char *(*)()) F675_3771;
	R2994[3] = (char *(*)()) F676_3771;
	R2994[4] = (char *(*)()) F677_3771;
	R2994[5] = (char *(*)()) F673_3771;
	R2994[6] = (char *(*)()) F675_3771;
	R2994[7] = (char *(*)()) F673_3771;
}

char *(*R2995[8])();
void R2995_init () {
	R2995[0] = (char *(*)()) F673_3772;
	R2995[1] = (char *(*)()) F674_3772;
	R2995[2] = (char *(*)()) F675_3772;
	R2995[3] = (char *(*)()) F676_3772;
	R2995[4] = (char *(*)()) F677_3772;
	R2995[5] = (char *(*)()) F673_3772;
	R2995[6] = (char *(*)()) F675_3772;
	R2995[7] = (char *(*)()) F673_3772;
}

char *(*R3002[8])();
void R3002_init () {
	R3002[0] = (char *(*)()) F673_3779;
	R3002[1] = (char *(*)()) F674_3779;
	R3002[2] = (char *(*)()) F675_3779_3002_1;
	R3002[3] = (char *(*)()) F676_3779_3002_1;
	R3002[4] = (char *(*)()) F677_3779_3002_1;
	R3002[5] = (char *(*)()) F673_3779;
	R3002[6] = (char *(*)()) F675_3779_3002_1;
	R3002[7] = (char *(*)()) F673_3779;
}
static EIF_REFERENCE F675_3779_3002_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F675_3779(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3779_3002_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F676_3779(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3779_3002_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F677_3779(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3003[8])();
void R3003_init () {
	R3003[0] = (char *(*)()) F673_3780;
	R3003[1] = (char *(*)()) F674_3780_3003_1;
	R3003[2] = (char *(*)()) F675_3780;
	R3003[3] = (char *(*)()) F676_3780_3003_1;
	R3003[4] = (char *(*)()) F677_3780;
	R3003[5] = (char *(*)()) F673_3780;
	R3003[6] = (char *(*)()) F675_3780;
	R3003[7] = (char *(*)()) F673_3780;
}
static EIF_REFERENCE F674_3780_3003_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F674_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3780_3003_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F676_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3004[8])();
void R3004_init () {
	R3004[0] = (char *(*)()) F673_3781;
	R3004[1] = (char *(*)()) F674_3781;
	R3004[2] = (char *(*)()) F675_3781;
	R3004[3] = (char *(*)()) F676_3781;
	R3004[4] = (char *(*)()) F677_3781;
	R3004[5] = (char *(*)()) F673_3781;
	R3004[6] = (char *(*)()) F675_3781;
	R3004[7] = (char *(*)()) F673_3781;
}

char *(*R3005[8])();
void R3005_init () {
	R3005[0] = (char *(*)()) F673_3782;
	R3005[1] = (char *(*)()) F674_3782;
	R3005[2] = (char *(*)()) F675_3782;
	R3005[3] = (char *(*)()) F676_3782;
	R3005[4] = (char *(*)()) F677_3782;
	R3005[5] = (char *(*)()) F673_3782;
	R3005[6] = (char *(*)()) F675_3782;
	R3005[7] = (char *(*)()) F673_3782;
}

char *(*R3006[8])();
void R3006_init () {
	R3006[0] = (char *(*)()) F673_3783;
	R3006[1] = (char *(*)()) F674_3783;
	R3006[2] = (char *(*)()) F675_3783;
	R3006[3] = (char *(*)()) F676_3783;
	R3006[4] = (char *(*)()) F677_3783;
	R3006[5] = (char *(*)()) F673_3783;
	R3006[6] = (char *(*)()) F675_3783;
	R3006[7] = (char *(*)()) F673_3783;
}

char *(*R3008[8])();
void R3008_init () {
	R3008[0] = (char *(*)()) F673_3785;
	R3008[1] = (char *(*)()) F674_3785;
	R3008[2] = (char *(*)()) F675_3785;
	R3008[3] = (char *(*)()) F676_3785;
	R3008[4] = (char *(*)()) F677_3785;
	R3008[5] = (char *(*)()) F673_3785;
	R3008[6] = (char *(*)()) F675_3785;
	R3008[7] = (char *(*)()) F673_3785;
}

char *(*R3010[8])();
void R3010_init () {
	R3010[0] = (char *(*)()) F673_3787;
	R3010[1] = (char *(*)()) F674_3787;
	R3010[2] = (char *(*)()) F675_3787;
	R3010[3] = (char *(*)()) F676_3787;
	R3010[4] = (char *(*)()) F677_3787;
	R3010[5] = (char *(*)()) F673_3787;
	R3010[6] = (char *(*)()) F675_3787;
	R3010[7] = (char *(*)()) F673_3787;
}

char *(*R3011[8])();
void R3011_init () {
	R3011[0] = (char *(*)()) F673_3788;
	R3011[1] = (char *(*)()) F674_3788;
	R3011[2] = (char *(*)()) F675_3788;
	R3011[3] = (char *(*)()) F676_3788;
	R3011[4] = (char *(*)()) F677_3788;
	R3011[5] = (char *(*)()) F673_3788;
	R3011[6] = (char *(*)()) F675_3788;
	R3011[7] = (char *(*)()) F673_3788;
}

char *(*R3012[8])();
void R3012_init () {
	R3012[0] = (char *(*)()) F673_3789;
	R3012[1] = (char *(*)()) F674_3789;
	R3012[2] = (char *(*)()) F675_3789;
	R3012[3] = (char *(*)()) F676_3789;
	R3012[4] = (char *(*)()) F677_3789;
	R3012[5] = (char *(*)()) F673_3789;
	R3012[6] = (char *(*)()) F675_3789;
	R3012[7] = (char *(*)()) F673_3789;
}

char *(*R3016[8])();
void R3016_init () {
	R3016[0] = (char *(*)()) F673_3793;
	R3016[1] = (char *(*)()) F674_3793_3016_4;
	R3016[2] = (char *(*)()) F675_3793;
	R3016[3] = (char *(*)()) F676_3793_3016_4;
	R3016[4] = (char *(*)()) F677_3793;
	R3016[5] = (char *(*)()) F673_3793;
	R3016[6] = (char *(*)()) F675_3793;
	R3016[7] = (char *(*)()) F673_3793;
}
static void F674_3793_3016_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3793(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F676_3793_3016_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F676_3793(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3022[8])();
void R3022_init () {
	R3022[0] = (char *(*)()) F673_3799;
	R3022[1] = (char *(*)()) F674_3799;
	R3022[2] = (char *(*)()) F675_3799;
	R3022[3] = (char *(*)()) F676_3799;
	R3022[4] = (char *(*)()) F677_3799;
	R3022[5] = (char *(*)()) F673_3799;
	R3022[6] = (char *(*)()) F675_3799;
	R3022[7] = (char *(*)()) F673_3799;
}

char *(*R3035[8])();
void R3035_init () {
	R3035[0] = (char *(*)()) F673_3812;
	R3035[1] = (char *(*)()) F674_3812;
	R3035[2] = (char *(*)()) F675_3812;
	R3035[3] = (char *(*)()) F676_3812;
	R3035[4] = (char *(*)()) F677_3812;
	R3035[5] = (char *(*)()) F673_3812;
	R3035[6] = (char *(*)()) F675_3812;
	R3035[7] = (char *(*)()) F673_3812;
}

char *(*R3038[2])();
void R3038_init () {
	R3038[0] = (char *(*)()) F678_3815;
	R3038[1] = (char *(*)()) F679_3815;
}

char *(*R3143[12])();
void R3143_init () {
	R3143[0] = (char *(*)()) F685_3945;
	R3143[1] = (char *(*)()) F686_3945;
	R3143[2] = (char *(*)()) F687_3945;
	R3143[3] = (char *(*)()) F688_3945;
	R3143[4] = (char *(*)()) F689_3945;
	R3143[5] = (char *(*)()) F690_3945;
	R3143[6] = (char *(*)()) F691_3945;
	R3143[7] = (char *(*)()) F692_3945;
	R3143[8] = (char *(*)()) F693_3945;
	R3143[9] = (char *(*)()) F694_3945;
	R3143[10] = (char *(*)()) F695_3945;
	R3143[11] = (char *(*)()) F696_3945;
}

char *(*R3144[12])();
void R3144_init () {
	R3144[0] = (char *(*)()) F685_3946;
	R3144[1] = (char *(*)()) F686_3946;
	R3144[2] = (char *(*)()) F687_3946;
	R3144[3] = (char *(*)()) F688_3946;
	R3144[4] = (char *(*)()) F689_3946;
	R3144[5] = (char *(*)()) F690_3946;
	R3144[6] = (char *(*)()) F691_3946;
	R3144[7] = (char *(*)()) F692_3946;
	R3144[8] = (char *(*)()) F693_3946;
	R3144[9] = (char *(*)()) F694_3946;
	R3144[10] = (char *(*)()) F695_3946;
	R3144[11] = (char *(*)()) F696_3946;
}

char *(*R3146[12])();
void R3146_init () {
	R3146[0] = (char *(*)()) F685_3932;
	R3146[1] = (char *(*)()) F686_3932;
	R3146[2] = (char *(*)()) F687_3932;
	R3146[3] = (char *(*)()) F688_3932;
	R3146[4] = (char *(*)()) F689_3932;
	R3146[5] = (char *(*)()) F690_3932;
	R3146[6] = (char *(*)()) F691_3932;
	R3146[7] = (char *(*)()) F692_3932;
	R3146[8] = (char *(*)()) F693_3932;
	R3146[9] = (char *(*)()) F694_3932;
	R3146[10] = (char *(*)()) F695_3932;
	R3146[11] = (char *(*)()) F696_3932;
}

char *(*R3147[12])();
void R3147_init () {
	R3147[0] = (char *(*)()) F685_3933;
	R3147[1] = (char *(*)()) F686_3933_3147_121;
	R3147[2] = (char *(*)()) F687_3933_3147_121;
	R3147[3] = (char *(*)()) F688_3933_3147_121;
	R3147[4] = (char *(*)()) F689_3933_3147_121;
	R3147[5] = (char *(*)()) F690_3933_3147_121;
	R3147[6] = (char *(*)()) F691_3933_3147_121;
	R3147[7] = (char *(*)()) F692_3933_3147_121;
	R3147[8] = (char *(*)()) F693_3933_3147_121;
	R3147[9] = (char *(*)()) F694_3933_3147_121;
	R3147[10] = (char *(*)()) F695_3933_3147_121;
	R3147[11] = (char *(*)()) F696_3933_3147_121;
}
static void F686_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3933(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F687_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3933(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F688_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3933(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F689_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F689_3933(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F690_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F690_3933(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F691_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F691_3933(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F692_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F692_3933(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F693_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F693_3933(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F694_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F694_3933(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F695_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F695_3933(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F696_3933_3147_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F696_3933(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3156[12])();
void R3156_init () {
	R3156[0] = (char *(*)()) F685_3948;
	R3156[1] = (char *(*)()) F686_3948;
	R3156[2] = (char *(*)()) F687_3948;
	R3156[3] = (char *(*)()) F688_3948;
	R3156[4] = (char *(*)()) F689_3948;
	R3156[5] = (char *(*)()) F690_3948;
	R3156[6] = (char *(*)()) F691_3948;
	R3156[7] = (char *(*)()) F692_3948;
	R3156[8] = (char *(*)()) F693_3948;
	R3156[9] = (char *(*)()) F694_3948;
	R3156[10] = (char *(*)()) F695_3948;
	R3156[11] = (char *(*)()) F696_3948;
}

char *(*R3157[12])();
void R3157_init () {
	R3157[0] = (char *(*)()) F685_3950;
	R3157[1] = (char *(*)()) F686_3950_3157_121;
	R3157[2] = (char *(*)()) F687_3950_3157_121;
	R3157[3] = (char *(*)()) F688_3950_3157_121;
	R3157[4] = (char *(*)()) F689_3950_3157_121;
	R3157[5] = (char *(*)()) F690_3950_3157_121;
	R3157[6] = (char *(*)()) F691_3950_3157_121;
	R3157[7] = (char *(*)()) F692_3950_3157_121;
	R3157[8] = (char *(*)()) F693_3950_3157_121;
	R3157[9] = (char *(*)()) F694_3950_3157_121;
	R3157[10] = (char *(*)()) F695_3950_3157_121;
	R3157[11] = (char *(*)()) F696_3950_3157_121;
}
static void F686_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3950(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F687_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3950(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F688_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3950(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F689_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F689_3950(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F690_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F690_3950(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F691_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F691_3950(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F692_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F692_3950(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F693_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F693_3950(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F694_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F694_3950(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F695_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F695_3950(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F696_3950_3157_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F696_3950(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3158[12])();
void R3158_init () {
	R3158[0] = (char *(*)()) F685_3951;
	R3158[1] = (char *(*)()) F686_3951_3158_121;
	R3158[2] = (char *(*)()) F687_3951_3158_121;
	R3158[3] = (char *(*)()) F688_3951_3158_121;
	R3158[4] = (char *(*)()) F689_3951_3158_121;
	R3158[5] = (char *(*)()) F690_3951_3158_121;
	R3158[6] = (char *(*)()) F691_3951_3158_121;
	R3158[7] = (char *(*)()) F692_3951_3158_121;
	R3158[8] = (char *(*)()) F693_3951_3158_121;
	R3158[9] = (char *(*)()) F694_3951_3158_121;
	R3158[10] = (char *(*)()) F695_3951_3158_121;
	R3158[11] = (char *(*)()) F696_3951_3158_121;
}
static void F686_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3951(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F687_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3951(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F688_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3951(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F689_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F689_3951(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F690_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F690_3951(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F691_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F691_3951(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F692_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F692_3951(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F693_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F693_3951(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F694_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F694_3951(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F695_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F695_3951(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F696_3951_3158_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F696_3951(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3159[12])();
void R3159_init () {
	R3159[0] = (char *(*)()) F685_3952;
	R3159[1] = (char *(*)()) F686_3952_3159_4;
	R3159[2] = (char *(*)()) F687_3952_3159_4;
	R3159[3] = (char *(*)()) F688_3952_3159_4;
	R3159[4] = (char *(*)()) F689_3952_3159_4;
	R3159[5] = (char *(*)()) F690_3952_3159_4;
	R3159[6] = (char *(*)()) F691_3952_3159_4;
	R3159[7] = (char *(*)()) F692_3952_3159_4;
	R3159[8] = (char *(*)()) F693_3952_3159_4;
	R3159[9] = (char *(*)()) F694_3952_3159_4;
	R3159[10] = (char *(*)()) F695_3952_3159_4;
	R3159[11] = (char *(*)()) F696_3952_3159_4;
}
static void F686_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F686_3952(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F687_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F687_3952(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F688_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F688_3952(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F689_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F689_3952(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F690_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_3952(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F691_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F691_3952(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F692_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F692_3952(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F693_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F693_3952(Current, *(EIF_BOOLEAN *)arg1);
}
static void F694_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F694_3952(Current, *(EIF_POINTER *)arg1);
}
static void F695_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F695_3952(Current, *(EIF_REAL_32 *)arg1);
}
static void F696_3952_3159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F696_3952(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3161[12])();
void R3161_init () {
	R3161[0] = (char *(*)()) F685_3954;
	R3161[1] = (char *(*)()) F686_3954_3161_125;
	R3161[2] = (char *(*)()) F687_3954_3161_125;
	R3161[3] = (char *(*)()) F688_3954_3161_125;
	R3161[4] = (char *(*)()) F689_3954_3161_125;
	R3161[5] = (char *(*)()) F690_3954_3161_125;
	R3161[6] = (char *(*)()) F691_3954_3161_125;
	R3161[7] = (char *(*)()) F692_3954_3161_125;
	R3161[8] = (char *(*)()) F693_3954_3161_125;
	R3161[9] = (char *(*)()) F694_3954_3161_125;
	R3161[10] = (char *(*)()) F695_3954_3161_125;
	R3161[11] = (char *(*)()) F696_3954_3161_125;
}
static void F686_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F686_3954(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F687_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F687_3954(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F688_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F688_3954(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F689_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F689_3954(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F690_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F690_3954(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F691_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F691_3954(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F692_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F692_3954(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F693_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F693_3954(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F694_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F694_3954(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F695_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F695_3954(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F696_3954_3161_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F696_3954(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3163[12])();
void R3163_init () {
	R3163[0] = (char *(*)()) F685_3956;
	R3163[1] = (char *(*)()) F686_3956;
	R3163[2] = (char *(*)()) F687_3956;
	R3163[3] = (char *(*)()) F688_3956;
	R3163[4] = (char *(*)()) F689_3956;
	R3163[5] = (char *(*)()) F690_3956;
	R3163[6] = (char *(*)()) F691_3956;
	R3163[7] = (char *(*)()) F692_3956;
	R3163[8] = (char *(*)()) F693_3956;
	R3163[9] = (char *(*)()) F694_3956;
	R3163[10] = (char *(*)()) F695_3956;
	R3163[11] = (char *(*)()) F696_3956;
}

char *(*R3164[12])();
void R3164_init () {
	R3164[0] = (char *(*)()) F685_3957;
	R3164[1] = (char *(*)()) F686_3957;
	R3164[2] = (char *(*)()) F687_3957;
	R3164[3] = (char *(*)()) F688_3957;
	R3164[4] = (char *(*)()) F689_3957;
	R3164[5] = (char *(*)()) F690_3957;
	R3164[6] = (char *(*)()) F691_3957;
	R3164[7] = (char *(*)()) F692_3957;
	R3164[8] = (char *(*)()) F693_3957;
	R3164[9] = (char *(*)()) F694_3957;
	R3164[10] = (char *(*)()) F695_3957;
	R3164[11] = (char *(*)()) F696_3957;
}

char *(*R3165[12])();
void R3165_init () {
	R3165[0] = (char *(*)()) F685_3958;
	R3165[1] = (char *(*)()) F686_3958;
	R3165[2] = (char *(*)()) F687_3958;
	R3165[3] = (char *(*)()) F688_3958;
	R3165[4] = (char *(*)()) F689_3958;
	R3165[5] = (char *(*)()) F690_3958;
	R3165[6] = (char *(*)()) F691_3958;
	R3165[7] = (char *(*)()) F692_3958;
	R3165[8] = (char *(*)()) F693_3958;
	R3165[9] = (char *(*)()) F694_3958;
	R3165[10] = (char *(*)()) F695_3958;
	R3165[11] = (char *(*)()) F696_3958;
}

char *(*R3166[12])();
void R3166_init () {
	R3166[0] = (char *(*)()) F685_3959;
	R3166[1] = (char *(*)()) F686_3959;
	R3166[2] = (char *(*)()) F687_3959;
	R3166[3] = (char *(*)()) F688_3959;
	R3166[4] = (char *(*)()) F689_3959;
	R3166[5] = (char *(*)()) F690_3959;
	R3166[6] = (char *(*)()) F691_3959;
	R3166[7] = (char *(*)()) F692_3959;
	R3166[8] = (char *(*)()) F693_3959;
	R3166[9] = (char *(*)()) F694_3959;
	R3166[10] = (char *(*)()) F695_3959;
	R3166[11] = (char *(*)()) F696_3959;
}

char *(*R3167[12])();
void R3167_init () {
	R3167[0] = (char *(*)()) F685_3960;
	R3167[1] = (char *(*)()) F686_3960;
	R3167[2] = (char *(*)()) F687_3960;
	R3167[3] = (char *(*)()) F688_3960;
	R3167[4] = (char *(*)()) F689_3960;
	R3167[5] = (char *(*)()) F690_3960;
	R3167[6] = (char *(*)()) F691_3960;
	R3167[7] = (char *(*)()) F692_3960;
	R3167[8] = (char *(*)()) F693_3960;
	R3167[9] = (char *(*)()) F694_3960;
	R3167[10] = (char *(*)()) F695_3960;
	R3167[11] = (char *(*)()) F696_3960;
}

char *(*R3168[12])();
void R3168_init () {
	R3168[0] = (char *(*)()) F685_3961;
	R3168[1] = (char *(*)()) F686_3961;
	R3168[2] = (char *(*)()) F687_3961;
	R3168[3] = (char *(*)()) F688_3961;
	R3168[4] = (char *(*)()) F689_3961;
	R3168[5] = (char *(*)()) F690_3961;
	R3168[6] = (char *(*)()) F691_3961;
	R3168[7] = (char *(*)()) F692_3961;
	R3168[8] = (char *(*)()) F693_3961;
	R3168[9] = (char *(*)()) F694_3961;
	R3168[10] = (char *(*)()) F695_3961;
	R3168[11] = (char *(*)()) F696_3961;
}

char *(*R3171[12])();
void R3171_init () {
	R3171[0] = (char *(*)()) F685_3964;
	R3171[1] = (char *(*)()) F686_3964;
	R3171[2] = (char *(*)()) F687_3964;
	R3171[3] = (char *(*)()) F688_3964;
	R3171[4] = (char *(*)()) F689_3964;
	R3171[5] = (char *(*)()) F690_3964;
	R3171[6] = (char *(*)()) F691_3964;
	R3171[7] = (char *(*)()) F692_3964;
	R3171[8] = (char *(*)()) F693_3964;
	R3171[9] = (char *(*)()) F694_3964;
	R3171[10] = (char *(*)()) F695_3964;
	R3171[11] = (char *(*)()) F696_3964;
}

char *(*R3174[12])();
void R3174_init () {
	R3174[0] = (char *(*)()) F685_3967;
	R3174[1] = (char *(*)()) F686_3967;
	R3174[2] = (char *(*)()) F687_3967;
	R3174[3] = (char *(*)()) F688_3967;
	R3174[4] = (char *(*)()) F689_3967;
	R3174[5] = (char *(*)()) F690_3967;
	R3174[6] = (char *(*)()) F691_3967;
	R3174[7] = (char *(*)()) F692_3967;
	R3174[8] = (char *(*)()) F693_3967;
	R3174[9] = (char *(*)()) F694_3967;
	R3174[10] = (char *(*)()) F695_3967;
	R3174[11] = (char *(*)()) F696_3967;
}

char *(*R3175[12])();
void R3175_init () {
	R3175[0] = (char *(*)()) F685_3968;
	R3175[1] = (char *(*)()) F686_3968_3175_104;
	R3175[2] = (char *(*)()) F687_3968_3175_104;
	R3175[3] = (char *(*)()) F688_3968_3175_104;
	R3175[4] = (char *(*)()) F689_3968_3175_104;
	R3175[5] = (char *(*)()) F690_3968_3175_104;
	R3175[6] = (char *(*)()) F691_3968_3175_104;
	R3175[7] = (char *(*)()) F692_3968_3175_104;
	R3175[8] = (char *(*)()) F693_3968_3175_104;
	R3175[9] = (char *(*)()) F694_3968_3175_104;
	R3175[10] = (char *(*)()) F695_3968_3175_104;
	R3175[11] = (char *(*)()) F696_3968_3175_104;
}
static EIF_REFERENCE F686_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F686_3968(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F687_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F687_3968(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F688_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F688_3968(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F689_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F689_3968(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F690_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F690_3968(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F691_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F691_3968(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F692_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F692_3968(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F693_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F693_3968(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F694_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F694_3968(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F695_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F695_3968(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F696_3968_3175_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F696_3968(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3177[12])();
void R3177_init () {
	R3177[0] = (char *(*)()) F685_3970;
	R3177[1] = (char *(*)()) F686_3970;
	R3177[2] = (char *(*)()) F687_3970;
	R3177[3] = (char *(*)()) F688_3970;
	R3177[4] = (char *(*)()) F689_3970;
	R3177[5] = (char *(*)()) F690_3970;
	R3177[6] = (char *(*)()) F691_3970;
	R3177[7] = (char *(*)()) F692_3970;
	R3177[8] = (char *(*)()) F693_3970;
	R3177[9] = (char *(*)()) F694_3970;
	R3177[10] = (char *(*)()) F695_3970;
	R3177[11] = (char *(*)()) F696_3970;
}

char *(*R3186[12])();
void R3186_init () {
	R3186[0] = (char *(*)()) F685_3980;
	R3186[1] = (char *(*)()) F686_3980;
	R3186[2] = (char *(*)()) F687_3980;
	R3186[3] = (char *(*)()) F688_3980;
	R3186[4] = (char *(*)()) F689_3980;
	R3186[5] = (char *(*)()) F690_3980;
	R3186[6] = (char *(*)()) F691_3980;
	R3186[7] = (char *(*)()) F692_3980;
	R3186[8] = (char *(*)()) F693_3980;
	R3186[9] = (char *(*)()) F694_3980;
	R3186[10] = (char *(*)()) F695_3980;
	R3186[11] = (char *(*)()) F696_3980;
}

char *(*R3233[26])();
void R3233_init () {
	R3233[0] = (char *(*)()) F823_4773_3233_1;
	R3233[1] = (char *(*)()) F824_4773_3233_1;
	R3233[3] = (char *(*)()) F826_4839_3233_1;
	R3233[4] = (char *(*)()) F827_4839_3233_1;
	R3233[15] = (char *(*)()) F838_5036_3233_1;
	R3233[16] = (char *(*)()) F839_5036_3233_1;
	R3233[18] = (char *(*)()) F841_5134_3233_1;
	R3233[19] = (char *(*)()) F842_5134_3233_1;
	R3233[21] = (char *(*)()) F844_5233_3233_1;
	R3233[22] = (char *(*)()) F845_5233_3233_1;
	R3233[24] = (char *(*)()) F847_5332_3233_1;
	R3233[25] = (char *(*)()) F848_5332_3233_1;
}
static EIF_REFERENCE F823_4773_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F823_4773(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F824_4773_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F824_4773(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4839_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F826_4839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F827_4839_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F827_4839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_5036_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F838_5036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_5036_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F839_5036(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_5134_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F841_5134(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_5134_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F842_5134(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_5233_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_5233(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_5233_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_5233(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_5332_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F847_5332(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_5332_3233_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F848_5332(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}

char *(*R3297[2])();
void R3297_init () {
	R3297[0] = (char *(*)()) F759_4141;
	R3297[1] = (char *(*)()) F760_4142;
}

char *(*R3302[5])();
void R3302_init () {
	{long i; for (i = 0; i < 2; i++) R3302[i] = (char *(*)()) F762_4158;}
	R3302[3] = (char *(*)()) F765_4163;
	R3302[4] = (char *(*)()) F766_4164;
}

char *(*R3305[5])();
void R3305_init () {
	{long i; for (i = 0; i < 2; i++) R3305[i] = (char *(*)()) F762_4159;}
	{long i; for (i = 3; i < 5; i++) R3305[i] = (char *(*)()) F761_4152;}
}

char *(*R3309[5])();
void R3309_init () {
	{long i; for (i = 0; i < 2; i++) R3309[i] = (char *(*)()) F762_4160;}
	{long i; for (i = 3; i < 5; i++) R3309[i] = (char *(*)()) F764_4162;}
}

char *(*R3310[5])();
void R3310_init () {
	R3310[0] = (char *(*)()) F761_4157;
	R3310[1] = (char *(*)()) F763_4161;
	{long i; for (i = 3; i < 5; i++) R3310[i] = (char *(*)()) F761_4157;}
}

char *(*R3314[2])();
void R3314_init () {
	R3314[0] = (char *(*)()) F768_4171;
	R3314[1] = (char *(*)()) F769_4172;
}

char *(*R3317[8])();
void R3317_init () {
	R3317[0] = (char *(*)()) F771_4178;
	R3317[1] = (char *(*)()) F772_4194;
	R3317[2] = (char *(*)()) F773_4195;
	R3317[3] = (char *(*)()) F774_4196;
	R3317[4] = (char *(*)()) F775_4197;
	R3317[5] = (char *(*)()) F776_4198;
	R3317[6] = (char *(*)()) F777_4199;
	R3317[7] = (char *(*)()) F778_4202;
}

EIF_TYPE_INDEX *Y3318_gen_type [9];
EIF_TYPE_INDEX Y3318 [9];
void Y3318_init (void)
{
	egc_routines_types [3318] = Y3318;
	egc_routines_gen_types [3318] = Y3318_gen_type;
	egc_routines_offset [3318] = 769;
	Y3318[0] = 926;
	Y3318[1] = 927;
	{long i; for (i = 2; i < 9; i++) Y3318[i] = 926;};
}

char *(*R3319[8])();
void R3319_init () {
	{long i; for (i = 0; i < 7; i++) R3319[i] = (char *(*)()) F770_4176;}
	R3319[7] = (char *(*)()) F778_4201;
}

char *(*R3335[120])();
void R3335_init () {
	R3335[0] = (char *(*)()) F780_4232;
	R3335[1] = (char *(*)()) F781_4274;
	R3335[2] = (char *(*)()) F782_4274;
	R3335[3] = (char *(*)()) F783_4274;
	R3335[4] = (char *(*)()) F784_4274;
	R3335[5] = (char *(*)()) F785_4274;
	R3335[6] = (char *(*)()) F786_4274;
	R3335[7] = (char *(*)()) F787_4274;
	R3335[8] = (char *(*)()) F788_4274;
	R3335[9] = (char *(*)()) F789_4274;
	R3335[10] = (char *(*)()) F790_4274;
	R3335[11] = (char *(*)()) F791_4274;
	R3335[12] = (char *(*)()) F792_4274;
	R3335[13] = (char *(*)()) F793_4274;
	R3335[14] = (char *(*)()) F794_4274;
	R3335[15] = (char *(*)()) F795_4274;
	R3335[16] = (char *(*)()) F796_4274;
	R3335[17] = (char *(*)()) F797_4274;
	R3335[18] = (char *(*)()) F798_4274;
	R3335[19] = (char *(*)()) F799_4274;
	R3335[20] = (char *(*)()) F800_4274;
	R3335[21] = (char *(*)()) F801_4274;
	R3335[22] = (char *(*)()) F802_4274;
	R3335[23] = (char *(*)()) F803_4274;
	R3335[24] = (char *(*)()) F804_4274;
	R3335[25] = (char *(*)()) F805_4274;
	R3335[26] = (char *(*)()) F806_4274;
	R3335[27] = (char *(*)()) F807_4274;
	R3335[28] = (char *(*)()) F808_4274;
	R3335[29] = (char *(*)()) F809_4274;
	R3335[30] = (char *(*)()) F810_4274;
	R3335[31] = (char *(*)()) F811_4274;
	R3335[32] = (char *(*)()) F812_4326;
	{long i; for (i = 34; i < 36; i++) R3335[i] = (char *(*)()) F813_4433;}
	{long i; for (i = 37; i < 39; i++) R3335[i] = (char *(*)()) F816_4527;}
	{long i; for (i = 40; i < 42; i++) R3335[i] = (char *(*)()) F819_4622;}
	{long i; for (i = 43; i < 45; i++) R3335[i] = (char *(*)()) F822_4717;}
	{long i; for (i = 46; i < 48; i++) R3335[i] = (char *(*)()) F825_4783;}
	{long i; for (i = 49; i < 51; i++) R3335[i] = (char *(*)()) F828_4850;}
	{long i; for (i = 52; i < 54; i++) R3335[i] = (char *(*)()) F831_4891;}
	{long i; for (i = 55; i < 57; i++) R3335[i] = (char *(*)()) F834_4939;}
	{long i; for (i = 58; i < 60; i++) R3335[i] = (char *(*)()) F837_4960;}
	{long i; for (i = 61; i < 63; i++) R3335[i] = (char *(*)()) F840_5059;}
	{long i; for (i = 64; i < 66; i++) R3335[i] = (char *(*)()) F843_5157;}
	{long i; for (i = 67; i < 69; i++) R3335[i] = (char *(*)()) F846_5256;}
	{long i; for (i = 70; i < 72; i++) R3335[i] = (char *(*)()) F849_5355;}
	{long i; for (i = 73; i < 103; i++) R3335[i] = (char *(*)()) F852_5449;}
	R3335[103] = (char *(*)()) F883_5475;
	R3335[104] = (char *(*)()) F884_5475;
	{long i; for (i = 114; i < 117; i++) R3335[i] = (char *(*)()) F890_5542;}
	{long i; for (i = 118; i < 120; i++) R3335[i] = (char *(*)()) F890_5542;}
}

char *(*R3393[31])();
void R3393_init () {
	R3393[0] = (char *(*)()) F781_4270;
	R3393[1] = (char *(*)()) F782_4270;
	R3393[2] = (char *(*)()) F783_4270;
	R3393[3] = (char *(*)()) F784_4270;
	R3393[4] = (char *(*)()) F785_4270;
	R3393[5] = (char *(*)()) F786_4270;
	R3393[6] = (char *(*)()) F787_4270;
	R3393[7] = (char *(*)()) F788_4270;
	R3393[8] = (char *(*)()) F789_4270;
	R3393[9] = (char *(*)()) F790_4270;
	R3393[10] = (char *(*)()) F791_4270;
	R3393[11] = (char *(*)()) F792_4270;
	R3393[12] = (char *(*)()) F793_4270;
	R3393[13] = (char *(*)()) F794_4270;
	R3393[14] = (char *(*)()) F795_4270;
	R3393[15] = (char *(*)()) F796_4270;
	R3393[16] = (char *(*)()) F797_4270;
	R3393[17] = (char *(*)()) F798_4270;
	R3393[18] = (char *(*)()) F799_4270;
	R3393[19] = (char *(*)()) F800_4270;
	R3393[20] = (char *(*)()) F801_4270;
	R3393[21] = (char *(*)()) F802_4270;
	R3393[22] = (char *(*)()) F803_4270;
	R3393[23] = (char *(*)()) F804_4270;
	R3393[24] = (char *(*)()) F805_4270;
	R3393[25] = (char *(*)()) F806_4270;
	R3393[26] = (char *(*)()) F807_4270;
	R3393[27] = (char *(*)()) F808_4270;
	R3393[28] = (char *(*)()) F809_4270;
	R3393[29] = (char *(*)()) F810_4270;
	R3393[30] = (char *(*)()) F811_4270;
}

char *(*R3396[31])();
void R3396_init () {
	R3396[0] = (char *(*)()) F781_4273;
	R3396[1] = (char *(*)()) F782_4273;
	R3396[2] = (char *(*)()) F783_4273;
	R3396[3] = (char *(*)()) F784_4273;
	R3396[4] = (char *(*)()) F785_4273;
	R3396[5] = (char *(*)()) F786_4273;
	R3396[6] = (char *(*)()) F787_4273;
	R3396[7] = (char *(*)()) F788_4273;
	R3396[8] = (char *(*)()) F789_4273;
	R3396[9] = (char *(*)()) F790_4273;
	R3396[10] = (char *(*)()) F791_4273;
	R3396[11] = (char *(*)()) F792_4273;
	R3396[12] = (char *(*)()) F793_4273;
	R3396[13] = (char *(*)()) F794_4273;
	R3396[14] = (char *(*)()) F795_4273;
	R3396[15] = (char *(*)()) F796_4273;
	R3396[16] = (char *(*)()) F797_4273;
	R3396[17] = (char *(*)()) F798_4273;
	R3396[18] = (char *(*)()) F799_4273;
	R3396[19] = (char *(*)()) F800_4273;
	R3396[20] = (char *(*)()) F801_4273;
	R3396[21] = (char *(*)()) F802_4273;
	R3396[22] = (char *(*)()) F803_4273;
	R3396[23] = (char *(*)()) F804_4273;
	R3396[24] = (char *(*)()) F805_4273;
	R3396[25] = (char *(*)()) F806_4273;
	R3396[26] = (char *(*)()) F807_4273;
	R3396[27] = (char *(*)()) F808_4273;
	R3396[28] = (char *(*)()) F809_4273;
	R3396[29] = (char *(*)()) F810_4273;
	R3396[30] = (char *(*)()) F811_4273;
}

char *(*R3401[31])();
void R3401_init () {
	R3401[0] = (char *(*)()) F781_4279;
	R3401[1] = (char *(*)()) F782_4279;
	R3401[2] = (char *(*)()) F783_4279;
	R3401[3] = (char *(*)()) F784_4279;
	R3401[4] = (char *(*)()) F785_4279;
	R3401[5] = (char *(*)()) F786_4279;
	R3401[6] = (char *(*)()) F787_4279;
	R3401[7] = (char *(*)()) F788_4279;
	R3401[8] = (char *(*)()) F789_4279;
	R3401[9] = (char *(*)()) F790_4279;
	R3401[10] = (char *(*)()) F791_4279;
	R3401[11] = (char *(*)()) F792_4279;
	R3401[12] = (char *(*)()) F793_4279;
	R3401[13] = (char *(*)()) F794_4279;
	R3401[14] = (char *(*)()) F795_4279;
	R3401[15] = (char *(*)()) F796_4279;
	R3401[16] = (char *(*)()) F797_4279;
	R3401[17] = (char *(*)()) F798_4279;
	R3401[18] = (char *(*)()) F799_4279;
	R3401[19] = (char *(*)()) F800_4279;
	R3401[20] = (char *(*)()) F801_4279;
	R3401[21] = (char *(*)()) F802_4279;
	R3401[22] = (char *(*)()) F803_4279;
	R3401[23] = (char *(*)()) F804_4279;
	R3401[24] = (char *(*)()) F805_4279;
	R3401[25] = (char *(*)()) F806_4279;
	R3401[26] = (char *(*)()) F807_4279;
	R3401[27] = (char *(*)()) F808_4279;
	R3401[28] = (char *(*)()) F809_4279;
	R3401[29] = (char *(*)()) F810_4279;
	R3401[30] = (char *(*)()) F811_4279;
}

char *(*R3406[31])();
void R3406_init () {
	R3406[0] = (char *(*)()) F781_4287;
	R3406[1] = (char *(*)()) F782_4287_3406_1;
	R3406[2] = (char *(*)()) F783_4287_3406_1;
	R3406[3] = (char *(*)()) F784_4287_3406_1;
	R3406[4] = (char *(*)()) F785_4287_3406_1;
	R3406[5] = (char *(*)()) F786_4287_3406_1;
	R3406[6] = (char *(*)()) F787_4287_3406_1;
	R3406[7] = (char *(*)()) F788_4287_3406_1;
	R3406[8] = (char *(*)()) F789_4287_3406_1;
	R3406[9] = (char *(*)()) F790_4287_3406_1;
	R3406[10] = (char *(*)()) F791_4287_3406_1;
	R3406[11] = (char *(*)()) F792_4287_3406_1;
	R3406[12] = (char *(*)()) F793_4287_3406_1;
	R3406[13] = (char *(*)()) F794_4287_3406_1;
	R3406[14] = (char *(*)()) F795_4287_3406_1;
	R3406[15] = (char *(*)()) F796_4287_3406_1;
	R3406[16] = (char *(*)()) F797_4287;
	R3406[17] = (char *(*)()) F798_4287_3406_1;
	R3406[18] = (char *(*)()) F799_4287_3406_1;
	R3406[19] = (char *(*)()) F800_4287_3406_1;
	R3406[20] = (char *(*)()) F801_4287_3406_1;
	R3406[21] = (char *(*)()) F802_4287_3406_1;
	R3406[22] = (char *(*)()) F803_4287_3406_1;
	R3406[23] = (char *(*)()) F804_4287_3406_1;
	R3406[24] = (char *(*)()) F805_4287_3406_1;
	R3406[25] = (char *(*)()) F806_4287_3406_1;
	R3406[26] = (char *(*)()) F807_4287_3406_1;
	R3406[27] = (char *(*)()) F808_4287_3406_1;
	R3406[28] = (char *(*)()) F809_4287_3406_1;
	R3406[29] = (char *(*)()) F810_4287_3406_1;
	R3406[30] = (char *(*)()) F811_4287_3406_1;
}
static EIF_REFERENCE F782_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F782_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {853,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 853, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F783_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F784_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F785_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F786_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F787_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F788_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F789_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F790_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F791_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F791_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F792_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F792_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F793_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F793_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F794_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F794_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F795_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F796_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F798_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {855,847,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 855, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F799_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {857,829,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 857, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F800_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {859,835,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 859, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F801_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {861,883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 861, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F802_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {863,817,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 863, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F803_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {865,844,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 865, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F804_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {867,841,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 867, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F805_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {869,832,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 869, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F806_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F806_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {871,823,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 871, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F807_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F807_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {873,820,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 873, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F808_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F808_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {875,814,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 875, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F809_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {877,838,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 877, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F810_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {879,850,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 879, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_4287_3406_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F811_4287(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {881,826,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 881, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}

char *(*R3416[31])();
void R3416_init () {
	R3416[0] = (char *(*)()) F781_4299;
	R3416[1] = (char *(*)()) F782_4299;
	R3416[2] = (char *(*)()) F783_4299;
	R3416[3] = (char *(*)()) F784_4299;
	R3416[4] = (char *(*)()) F785_4299;
	R3416[5] = (char *(*)()) F786_4299;
	R3416[6] = (char *(*)()) F787_4299;
	R3416[7] = (char *(*)()) F788_4299;
	R3416[8] = (char *(*)()) F789_4299;
	R3416[9] = (char *(*)()) F790_4299;
	R3416[10] = (char *(*)()) F791_4299;
	R3416[11] = (char *(*)()) F792_4299;
	R3416[12] = (char *(*)()) F793_4299;
	R3416[13] = (char *(*)()) F794_4299;
	R3416[14] = (char *(*)()) F795_4299;
	R3416[15] = (char *(*)()) F796_4299;
	R3416[16] = (char *(*)()) F797_4299;
	R3416[17] = (char *(*)()) F798_4299;
	R3416[18] = (char *(*)()) F799_4299;
	R3416[19] = (char *(*)()) F800_4299;
	R3416[20] = (char *(*)()) F801_4299;
	R3416[21] = (char *(*)()) F802_4299;
	R3416[22] = (char *(*)()) F803_4299;
	R3416[23] = (char *(*)()) F804_4299;
	R3416[24] = (char *(*)()) F805_4299;
	R3416[25] = (char *(*)()) F806_4299;
	R3416[26] = (char *(*)()) F807_4299;
	R3416[27] = (char *(*)()) F808_4299;
	R3416[28] = (char *(*)()) F809_4299;
	R3416[29] = (char *(*)()) F810_4299;
	R3416[30] = (char *(*)()) F811_4299;
}

char *(*R3558[2])();
void R3558_init () {
	R3558[0] = (char *(*)()) F814_4508;
	R3558[1] = (char *(*)()) F815_4508;
}

char *(*R3559[2])();
void R3559_init () {
	R3559[0] = (char *(*)()) F814_4509;
	R3559[1] = (char *(*)()) F815_4509;
}

char *(*R3561[2])();
void R3561_init () {
	R3561[0] = (char *(*)()) F814_4511;
	R3561[1] = (char *(*)()) F815_4511;
}

char *(*R3564[2])();
void R3564_init () {
	R3564[0] = (char *(*)()) F814_4514;
	R3564[1] = (char *(*)()) F815_4514;
}

char *(*R3565[2])();
void R3565_init () {
	R3565[0] = (char *(*)()) F814_4515;
	R3565[1] = (char *(*)()) F815_4515;
}

char *(*R3613[2])();
void R3613_init () {
	R3613[0] = (char *(*)()) F817_4605;
	R3613[1] = (char *(*)()) F818_4605;
}

char *(*R3614[2])();
void R3614_init () {
	R3614[0] = (char *(*)()) F817_4606;
	R3614[1] = (char *(*)()) F818_4606;
}

char *(*R3617[2])();
void R3617_init () {
	R3617[0] = (char *(*)()) F817_4609;
	R3617[1] = (char *(*)()) F818_4609;
}

char *(*R3665[2])();
void R3665_init () {
	R3665[0] = (char *(*)()) F820_4699;
	R3665[1] = (char *(*)()) F821_4699;
}

char *(*R3666[2])();
void R3666_init () {
	R3666[0] = (char *(*)()) F820_4700;
	R3666[1] = (char *(*)()) F821_4700;
}

char *(*R3667[2])();
void R3667_init () {
	R3667[0] = (char *(*)()) F820_4701;
	R3667[1] = (char *(*)()) F821_4701;
}

char *(*R3668[2])();
void R3668_init () {
	R3668[0] = (char *(*)()) F820_4702;
	R3668[1] = (char *(*)()) F821_4702;
}

char *(*R3670[2])();
void R3670_init () {
	R3670[0] = (char *(*)()) F820_4704;
	R3670[1] = (char *(*)()) F821_4704;
}

char *(*R3716[2])();
void R3716_init () {
	R3716[0] = (char *(*)()) F823_4762;
	R3716[1] = (char *(*)()) F824_4762;
}

char *(*R3723[2])();
void R3723_init () {
	R3723[0] = (char *(*)()) F823_4766;
	R3723[1] = (char *(*)()) F824_4766;
}

char *(*R3750[2])();
void R3750_init () {
	R3750[0] = (char *(*)()) F826_4828;
	R3750[1] = (char *(*)()) F827_4828;
}

char *(*R3757[2])();
void R3757_init () {
	R3757[0] = (char *(*)()) F826_4832;
	R3757[1] = (char *(*)()) F827_4832;
}

char *(*R3771[2])();
void R3771_init () {
	R3771[0] = (char *(*)()) F829_4886;
	R3771[1] = (char *(*)()) F830_4886;
}

char *(*R3875[2])();
void R3875_init () {
	R3875[0] = (char *(*)()) F838_5040;
	R3875[1] = (char *(*)()) F839_5040;
}

char *(*R3878[2])();
void R3878_init () {
	R3878[0] = (char *(*)()) F838_5043;
	R3878[1] = (char *(*)()) F839_5043;
}

char *(*R3881[2])();
void R3881_init () {
	R3881[0] = (char *(*)()) F838_5046;
	R3881[1] = (char *(*)()) F839_5046;
}

char *(*R3933[2])();
void R3933_init () {
	R3933[0] = (char *(*)()) F841_5141;
	R3933[1] = (char *(*)()) F842_5141;
}

char *(*R3936[2])();
void R3936_init () {
	R3936[0] = (char *(*)()) F841_5144;
	R3936[1] = (char *(*)()) F842_5144;
}

char *(*R3988[2])();
void R3988_init () {
	R3988[0] = (char *(*)()) F844_5239;
	R3988[1] = (char *(*)()) F845_5239;
}

char *(*R3989[2])();
void R3989_init () {
	R3989[0] = (char *(*)()) F844_5240;
	R3989[1] = (char *(*)()) F845_5240;
}

char *(*R3993[2])();
void R3993_init () {
	R3993[0] = (char *(*)()) F844_5244;
	R3993[1] = (char *(*)()) F845_5244;
}

char *(*R4045[2])();
void R4045_init () {
	R4045[0] = (char *(*)()) F847_5339;
	R4045[1] = (char *(*)()) F848_5339;
}

char *(*R4048[2])();
void R4048_init () {
	R4048[0] = (char *(*)()) F847_5342;
	R4048[1] = (char *(*)()) F848_5342;
}

char *(*R4102[2])();
void R4102_init () {
	R4102[0] = (char *(*)()) F850_5436;
	R4102[1] = (char *(*)()) F851_5436;
}

char *(*R4201[6])();
void R4201_init () {
	{long i; for (i = 0; i < 3; i++) R4201[i] = (char *(*)()) F893_5663;}
	{long i; for (i = 4; i < 6; i++) R4201[i] = (char *(*)()) F897_5861;}
}

char *(*R4203[6])();
void R4203_init () {
	R4203[0] = (char *(*)()) F894_5723;
	{long i; for (i = 1; i < 3; i++) R4203[i] = (char *(*)()) F895_5745;}
	R4203[4] = (char *(*)()) F898_5922;
	R4203[5] = (char *(*)()) F899_5945;
}

char *(*R4204[6])();
void R4204_init () {
	R4204[0] = (char *(*)()) F894_5722;
	{long i; for (i = 1; i < 3; i++) R4204[i] = (char *(*)()) F895_5744;}
	R4204[4] = (char *(*)()) F898_5920;
	R4204[5] = (char *(*)()) F899_5943;
}

char *(*R4205[6])();
void R4205_init () {
	{long i; for (i = 0; i < 3; i++) R4205[i] = (char *(*)()) F890_5536;}
	{long i; for (i = 4; i < 6; i++) R4205[i] = (char *(*)()) F897_5873;}
}

char *(*R4218[6])();
void R4218_init () {
	R4218[0] = (char *(*)()) F894_5732;
	{long i; for (i = 1; i < 3; i++) R4218[i] = (char *(*)()) F499_2928;}
	R4218[4] = (char *(*)()) F898_5932;
	R4218[5] = (char *(*)()) F498_2928;
}

char *(*R4240[6])();
void R4240_init () {
	{long i; for (i = 0; i < 3; i++) R4240[i] = (char *(*)()) F893_5685;}
	{long i; for (i = 4; i < 6; i++) R4240[i] = (char *(*)()) F897_5882;}
}

char *(*R4241[6])();
void R4241_init () {
	{long i; for (i = 0; i < 3; i++) R4241[i] = (char *(*)()) F893_5684;}
	{long i; for (i = 4; i < 6; i++) R4241[i] = (char *(*)()) F897_5881;}
}

char *(*R4262[6])();
void R4262_init () {
	R4262[0] = (char *(*)()) F894_5728;
	{long i; for (i = 1; i < 3; i++) R4262[i] = (char *(*)()) F895_5811;}
	R4262[4] = (char *(*)()) F898_5927;
	R4262[5] = (char *(*)()) F899_6011;
}

char *(*R4281[6])();
void R4281_init () {
	R4281[0] = (char *(*)()) F894_5730;
	{long i; for (i = 1; i < 3; i++) R4281[i] = (char *(*)()) F895_5823;}
	R4281[4] = (char *(*)()) F898_5929;
	R4281[5] = (char *(*)()) F899_6023;
}

char *(*R4285[6])();
void R4285_init () {
	R4285[0] = (char *(*)()) F894_5734;
	{long i; for (i = 1; i < 3; i++) R4285[i] = (char *(*)()) F895_5827;}
	R4285[4] = (char *(*)()) F898_5933;
	R4285[5] = (char *(*)()) F899_6026;
}

char *(*R4296[5])();
void R4296_init () {
	{long i; for (i = 0; i < 2; i++) R4296[i] = (char *(*)()) F895_5825;}
	R4296[4] = (char *(*)()) F899_6025;
}

char *(*R4299[5])();
void R4299_init () {
	{long i; for (i = 0; i < 2; i++) R4299[i] = (char *(*)()) F895_5764;}
	R4299[4] = (char *(*)()) F899_5964;
}

char *(*R4321[5])();
void R4321_init () {
	{long i; for (i = 0; i < 2; i++) R4321[i] = (char *(*)()) F895_5760;}
	R4321[4] = (char *(*)()) F899_5960;
}

char *(*R4322[5])();
void R4322_init () {
	{long i; for (i = 0; i < 2; i++) R4322[i] = (char *(*)()) F895_5761;}
	R4322[4] = (char *(*)()) F899_5961;
}

char *(*R4329[5])();
void R4329_init () {
	{long i; for (i = 0; i < 2; i++) R4329[i] = (char *(*)()) F895_5808;}
	R4329[4] = (char *(*)()) F899_6008;
}

char *(*R4361[3])();
void R4361_init () {
	R4361[0] = (char *(*)()) F894_5736;
	{long i; for (i = 1; i < 3; i++) R4361[i] = (char *(*)()) F893_5715;}
}

char *(*R4443[2])();
void R4443_init () {
	R4443[0] = (char *(*)()) F898_5926;
	R4443[1] = (char *(*)()) F899_6021;
}

char *(*R4449[2])();
void R4449_init () {
	R4449[0] = (char *(*)()) F898_5935;
	R4449[1] = (char *(*)()) F897_5912;
}

char *(*R4968[4])();
void R4968_init () {
	{long i; for (i = 0; i < 2; i++) R4968[i] = (char *(*)()) F924_6575;}
	{long i; for (i = 2; i < 4; i++) R4968[i] = (char *(*)()) F927_6604;}
}

EIF_TYPE_INDEX *Y4970_gen_type [5];
EIF_TYPE_INDEX Y4970 [5];
void Y4970_init (void)
{
	egc_routines_types [4970] = Y4970;
	egc_routines_gen_types [4970] = Y4970_gen_type;
	egc_routines_offset [4970] = 923;
	Y4970[0] = 102;
	Y4970[1] = 103;
	Y4970[2] = 104;
	Y4970[3] = 105;
	Y4970[4] = 106;
}

char *(*R4971[4])();
void R4971_init () {
	{long i; for (i = 0; i < 2; i++) R4971[i] = (char *(*)()) F924_6578;}
	R4971[2] = (char *(*)()) F927_6600;
	R4971[3] = (char *(*)()) F928_6608;
}

char *(*R4980[4])();
void R4980_init () {
	{long i; for (i = 0; i < 2; i++) R4980[i] = (char *(*)()) F924_6587;}
	{long i; for (i = 2; i < 4; i++) R4980[i] = (char *(*)()) F927_6605;}
}
char *(*R2[928])();
void R2_init () {}
char *(*R6[928])();
void R6_init () {}

char *(*R3[928])();
void R3_init () {
	R3[181] = (char *(*)()) F182_1964;
	R3[205] = (char *(*)()) F206_2415;
	R3[211] = (char *(*)()) F184_2091;
	{long i; for (i = 557; i < 559; i++) R3[i] = (char *(*)()) F183_2004;}
	R3[899] = (char *(*)()) F900_6036;
	R3[912] = (char *(*)()) F913_6326;
}

char *(*R4[928])();
void R4_init () {
	R4[2] = (char *(*)()) F1_15;
	R4[7] = (char *(*)()) F1_15;
	{long i; for (i = 9; i < 11; i++) R4[i] = (char *(*)()) F1_15;}
	R4[13] = (char *(*)()) F1_15;
	{long i; for (i = 26; i < 28; i++) R4[i] = (char *(*)()) F1_15;}
	R4[29] = (char *(*)()) F1_15;
	R4[38] = (char *(*)()) F1_15;
	{long i; for (i = 41; i < 51; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 54; i < 66; i++) R4[i] = (char *(*)()) F1_15;}
	R4[67] = (char *(*)()) F1_15;
	R4[74] = (char *(*)()) F1_15;
	R4[88] = (char *(*)()) F1_15;
	{long i; for (i = 90; i < 92; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 93; i < 95; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 97; i < 99; i++) R4[i] = (char *(*)()) F1_15;}
	R4[101] = (char *(*)()) F1_15;
	{long i; for (i = 103; i < 107; i++) R4[i] = (char *(*)()) F1_15;}
	R4[108] = (char *(*)()) F1_15;
	{long i; for (i = 111; i < 115; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 116; i < 119; i++) R4[i] = (char *(*)()) F1_15;}
	R4[122] = (char *(*)()) F1_15;
	{long i; for (i = 124; i < 127; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 128; i < 131; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 132; i < 134; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 136; i < 138; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 139; i < 142; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 143; i < 147; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 148; i < 150; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 151; i < 157; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 158; i < 160; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 161; i < 165; i++) R4[i] = (char *(*)()) F1_15;}
	R4[170] = (char *(*)()) F1_15;
	R4[172] = (char *(*)()) F1_15;
	{long i; for (i = 174; i < 176; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 178; i < 180; i++) R4[i] = (char *(*)()) F1_15;}
	R4[181] = (char *(*)()) F182_1883;
	R4[186] = (char *(*)()) F1_15;
	{long i; for (i = 204; i < 206; i++) R4[i] = (char *(*)()) F1_15;}
	R4[206] = (char *(*)()) F207_2483;
	R4[208] = (char *(*)()) F1_15;
	{long i; for (i = 210; i < 212; i++) R4[i] = (char *(*)()) F1_15;}
	R4[232] = (char *(*)()) F1_15;
	{long i; for (i = 234; i < 236; i++) R4[i] = (char *(*)()) F1_15;}
	R4[250] = (char *(*)()) F1_15;
	{long i; for (i = 293; i < 301; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 313; i < 325; i++) R4[i] = (char *(*)()) F1_15;}
	R4[493] = (char *(*)()) F1_15;
	{long i; for (i = 557; i < 559; i++) R4[i] = (char *(*)()) F1_15;}
	R4[584] = (char *(*)()) F585_3398;
	R4[585] = (char *(*)()) F586_3398;
	R4[586] = (char *(*)()) F587_3398;
	R4[587] = (char *(*)()) F588_3398;
	R4[588] = (char *(*)()) F589_3398;
	R4[589] = (char *(*)()) F590_3398;
	R4[590] = (char *(*)()) F591_3398;
	R4[591] = (char *(*)()) F592_3398;
	R4[592] = (char *(*)()) F593_3398;
	R4[593] = (char *(*)()) F594_3398;
	R4[594] = (char *(*)()) F595_3398;
	R4[595] = (char *(*)()) F596_3398;
	R4[646] = (char *(*)()) F647_3499;
	R4[647] = (char *(*)()) F648_3499;
	R4[649] = (char *(*)()) F647_3499;
	{long i; for (i = 651; i < 657; i++) R4[i] = (char *(*)()) F1_15;}
	R4[659] = (char *(*)()) F660_3670;
	R4[660] = (char *(*)()) F661_3670;
	R4[661] = (char *(*)()) F662_3670;
	R4[662] = (char *(*)()) F663_3670;
	R4[663] = (char *(*)()) F664_3670;
	R4[664] = (char *(*)()) F665_3670;
	R4[665] = (char *(*)()) F666_3670;
	R4[666] = (char *(*)()) F667_3670;
	R4[667] = (char *(*)()) F668_3670;
	R4[668] = (char *(*)()) F669_3670;
	R4[669] = (char *(*)()) F670_3670;
	R4[670] = (char *(*)()) F671_3670;
	R4[672] = (char *(*)()) F673_3760;
	R4[673] = (char *(*)()) F674_3760;
	R4[674] = (char *(*)()) F675_3760;
	R4[675] = (char *(*)()) F676_3760;
	R4[676] = (char *(*)()) F677_3760;
	R4[677] = (char *(*)()) F673_3760;
	R4[678] = (char *(*)()) F675_3760;
	R4[679] = (char *(*)()) F673_3760;
	R4[681] = (char *(*)()) F1_15;
	{long i; for (i = 684; i < 696; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 745; i < 755; i++) R4[i] = (char *(*)()) F1_15;}
	R4[756] = (char *(*)()) F1_15;
	{long i; for (i = 758; i < 760; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 761; i < 763; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 764; i < 766; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 767; i < 769; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 770; i < 778; i++) R4[i] = (char *(*)()) F1_15;}
	R4[779] = (char *(*)()) F780_4246;
	{long i; for (i = 780; i < 812; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 813; i < 815; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 816; i < 818; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 819; i < 821; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 822; i < 824; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 825; i < 827; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 828; i < 830; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 831; i < 833; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 834; i < 836; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 837; i < 839; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 840; i < 842; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 843; i < 845; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 846; i < 848; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 849; i < 851; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 852; i < 884; i++) R4[i] = (char *(*)()) F1_15;}
	R4[893] = (char *(*)()) F894_5719;
	{long i; for (i = 894; i < 896; i++) R4[i] = (char *(*)()) F893_5703;}
	R4[897] = (char *(*)()) F898_5919;
	R4[898] = (char *(*)()) F897_5900;
	R4[899] = (char *(*)()) F1_15;
	R4[901] = (char *(*)()) F1_15;
	{long i; for (i = 906; i < 908; i++) R4[i] = (char *(*)()) F1_15;}
	R4[909] = (char *(*)()) F1_15;
	{long i; for (i = 912; i < 914; i++) R4[i] = (char *(*)()) F1_15;}
	R4[916] = (char *(*)()) F1_15;
	R4[918] = (char *(*)()) F1_15;
	R4[921] = (char *(*)()) F922_6535;
	R4[922] = (char *(*)()) F1_15;
	{long i; for (i = 924; i < 928; i++) R4[i] = (char *(*)()) F1_15;}
}

char *(*R5[928])();
void R5_init () {
	R5[2] = (char *(*)()) F1_8;
	R5[7] = (char *(*)()) F1_8;
	{long i; for (i = 9; i < 11; i++) R5[i] = (char *(*)()) F1_8;}
	R5[13] = (char *(*)()) F1_8;
	{long i; for (i = 26; i < 28; i++) R5[i] = (char *(*)()) F1_8;}
	R5[29] = (char *(*)()) F1_8;
	R5[38] = (char *(*)()) F1_8;
	{long i; for (i = 41; i < 51; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 54; i < 66; i++) R5[i] = (char *(*)()) F1_8;}
	R5[67] = (char *(*)()) F1_8;
	R5[74] = (char *(*)()) F1_8;
	R5[88] = (char *(*)()) F1_8;
	{long i; for (i = 90; i < 92; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 93; i < 95; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 97; i < 99; i++) R5[i] = (char *(*)()) F1_8;}
	R5[101] = (char *(*)()) F1_8;
	{long i; for (i = 103; i < 107; i++) R5[i] = (char *(*)()) F1_8;}
	R5[108] = (char *(*)()) F1_8;
	{long i; for (i = 111; i < 115; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 116; i < 119; i++) R5[i] = (char *(*)()) F1_8;}
	R5[122] = (char *(*)()) F1_8;
	{long i; for (i = 124; i < 127; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 128; i < 131; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 132; i < 134; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 136; i < 138; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 139; i < 142; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 143; i < 147; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 148; i < 150; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 151; i < 157; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 158; i < 160; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 161; i < 165; i++) R5[i] = (char *(*)()) F1_8;}
	R5[170] = (char *(*)()) F171_1746;
	R5[172] = (char *(*)()) F173_1786;
	R5[174] = (char *(*)()) F175_1803;
	R5[175] = (char *(*)()) F174_1795;
	{long i; for (i = 178; i < 180; i++) R5[i] = (char *(*)()) F1_8;}
	R5[181] = (char *(*)()) F182_1882;
	R5[186] = (char *(*)()) F1_8;
	R5[204] = (char *(*)()) F205_2374;
	R5[205] = (char *(*)()) F1_8;
	R5[206] = (char *(*)()) F207_2482;
	R5[208] = (char *(*)()) F1_8;
	{long i; for (i = 210; i < 212; i++) R5[i] = (char *(*)()) F1_8;}
	R5[232] = (char *(*)()) F1_8;
	{long i; for (i = 234; i < 236; i++) R5[i] = (char *(*)()) F1_8;}
	R5[250] = (char *(*)()) F1_8;
	{long i; for (i = 293; i < 301; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 313; i < 325; i++) R5[i] = (char *(*)()) F1_8;}
	R5[493] = (char *(*)()) F1_8;
	{long i; for (i = 557; i < 559; i++) R5[i] = (char *(*)()) F1_8;}
	R5[584] = (char *(*)()) F585_3360;
	R5[585] = (char *(*)()) F586_3360;
	R5[586] = (char *(*)()) F587_3360;
	R5[587] = (char *(*)()) F588_3360;
	R5[588] = (char *(*)()) F589_3360;
	R5[589] = (char *(*)()) F590_3360;
	R5[590] = (char *(*)()) F591_3360;
	R5[591] = (char *(*)()) F592_3360;
	R5[592] = (char *(*)()) F593_3360;
	R5[593] = (char *(*)()) F594_3360;
	R5[594] = (char *(*)()) F595_3360;
	R5[595] = (char *(*)()) F596_3360;
	R5[646] = (char *(*)()) F621_3441;
	R5[647] = (char *(*)()) F623_3441;
	R5[649] = (char *(*)()) F621_3441;
	{long i; for (i = 651; i < 657; i++) R5[i] = (char *(*)()) F1_8;}
	R5[659] = (char *(*)()) F660_3643;
	R5[660] = (char *(*)()) F661_3643;
	R5[661] = (char *(*)()) F662_3643;
	R5[662] = (char *(*)()) F663_3643;
	R5[663] = (char *(*)()) F664_3643;
	R5[664] = (char *(*)()) F665_3643;
	R5[665] = (char *(*)()) F666_3643;
	R5[666] = (char *(*)()) F667_3643;
	R5[667] = (char *(*)()) F668_3643;
	R5[668] = (char *(*)()) F669_3643;
	R5[669] = (char *(*)()) F670_3643;
	R5[670] = (char *(*)()) F671_3643;
	R5[672] = (char *(*)()) F673_3726;
	R5[673] = (char *(*)()) F674_3726;
	R5[674] = (char *(*)()) F675_3726;
	R5[675] = (char *(*)()) F676_3726;
	R5[676] = (char *(*)()) F677_3726;
	R5[677] = (char *(*)()) F678_3820;
	R5[678] = (char *(*)()) F679_3820;
	R5[679] = (char *(*)()) F673_3726;
	R5[681] = (char *(*)()) F1_8;
	{long i; for (i = 684; i < 696; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 745; i < 755; i++) R5[i] = (char *(*)()) F1_8;}
	R5[756] = (char *(*)()) F1_8;
	{long i; for (i = 758; i < 760; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 761; i < 763; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 764; i < 766; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 767; i < 769; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 770; i < 778; i++) R5[i] = (char *(*)()) F1_8;}
	R5[779] = (char *(*)()) F780_4243;
	R5[780] = (char *(*)()) F781_4280;
	R5[781] = (char *(*)()) F782_4280;
	R5[782] = (char *(*)()) F783_4280;
	R5[783] = (char *(*)()) F784_4280;
	R5[784] = (char *(*)()) F785_4280;
	R5[785] = (char *(*)()) F786_4280;
	R5[786] = (char *(*)()) F787_4280;
	R5[787] = (char *(*)()) F788_4280;
	R5[788] = (char *(*)()) F789_4280;
	R5[789] = (char *(*)()) F790_4280;
	R5[790] = (char *(*)()) F791_4280;
	R5[791] = (char *(*)()) F792_4280;
	R5[792] = (char *(*)()) F793_4280;
	R5[793] = (char *(*)()) F794_4280;
	R5[794] = (char *(*)()) F795_4280;
	R5[795] = (char *(*)()) F796_4280;
	R5[796] = (char *(*)()) F797_4280;
	R5[797] = (char *(*)()) F798_4280;
	R5[798] = (char *(*)()) F799_4280;
	R5[799] = (char *(*)()) F800_4280;
	R5[800] = (char *(*)()) F801_4280;
	R5[801] = (char *(*)()) F802_4280;
	R5[802] = (char *(*)()) F803_4280;
	R5[803] = (char *(*)()) F804_4280;
	R5[804] = (char *(*)()) F805_4280;
	R5[805] = (char *(*)()) F806_4280;
	R5[806] = (char *(*)()) F807_4280;
	R5[807] = (char *(*)()) F808_4280;
	R5[808] = (char *(*)()) F809_4280;
	R5[809] = (char *(*)()) F810_4280;
	R5[810] = (char *(*)()) F811_4280;
	R5[811] = (char *(*)()) F812_4323;
	{long i; for (i = 813; i < 815; i++) R5[i] = (char *(*)()) F813_4441;}
	{long i; for (i = 816; i < 818; i++) R5[i] = (char *(*)()) F816_4535;}
	{long i; for (i = 819; i < 821; i++) R5[i] = (char *(*)()) F819_4630;}
	{long i; for (i = 822; i < 824; i++) R5[i] = (char *(*)()) F822_4729;}
	{long i; for (i = 825; i < 827; i++) R5[i] = (char *(*)()) F825_4795;}
	{long i; for (i = 828; i < 830; i++) R5[i] = (char *(*)()) F828_4856;}
	{long i; for (i = 831; i < 833; i++) R5[i] = (char *(*)()) F831_4896;}
	{long i; for (i = 834; i < 836; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 837; i < 839; i++) R5[i] = (char *(*)()) F837_4968;}
	{long i; for (i = 840; i < 842; i++) R5[i] = (char *(*)()) F840_5067;}
	{long i; for (i = 843; i < 845; i++) R5[i] = (char *(*)()) F843_5165;}
	{long i; for (i = 846; i < 848; i++) R5[i] = (char *(*)()) F846_5264;}
	{long i; for (i = 849; i < 851; i++) R5[i] = (char *(*)()) F849_5363;}
	{long i; for (i = 852; i < 884; i++) R5[i] = (char *(*)()) F852_5451;}
	{long i; for (i = 893; i < 896; i++) R5[i] = (char *(*)()) F893_5688;}
	{long i; for (i = 897; i < 899; i++) R5[i] = (char *(*)()) F897_5885;}
	R5[899] = (char *(*)()) F1_8;
	R5[901] = (char *(*)()) F1_8;
	{long i; for (i = 906; i < 908; i++) R5[i] = (char *(*)()) F1_8;}
	R5[909] = (char *(*)()) F1_8;
	{long i; for (i = 912; i < 914; i++) R5[i] = (char *(*)()) F1_8;}
	R5[916] = (char *(*)()) F172_1768;
	R5[918] = (char *(*)()) F172_1768;
	R5[921] = (char *(*)()) F922_6531;
	R5[922] = (char *(*)()) F1_8;
	{long i; for (i = 924; i < 928; i++) R5[i] = (char *(*)()) F1_8;}
}


#ifdef __cplusplus
}
#endif
