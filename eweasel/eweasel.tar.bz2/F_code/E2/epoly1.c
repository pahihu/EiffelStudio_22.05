#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[926])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	R11[5] = (char *(*)()) F1_8;
	{long i; for (i = 7; i < 9; i++) R11[i] = (char *(*)()) F1_8;}
	R11[11] = (char *(*)()) F1_8;
	{long i; for (i = 24; i < 26; i++) R11[i] = (char *(*)()) F1_8;}
	R11[27] = (char *(*)()) F1_8;
	R11[36] = (char *(*)()) F1_8;
	{long i; for (i = 39; i < 49; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 52; i < 64; i++) R11[i] = (char *(*)()) F1_8;}
	R11[65] = (char *(*)()) F1_8;
	R11[72] = (char *(*)()) F1_8;
	R11[86] = (char *(*)()) F1_8;
	{long i; for (i = 88; i < 90; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 91; i < 93; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 95; i < 97; i++) R11[i] = (char *(*)()) F1_8;}
	R11[99] = (char *(*)()) F1_8;
	{long i; for (i = 101; i < 105; i++) R11[i] = (char *(*)()) F1_8;}
	R11[106] = (char *(*)()) F1_8;
	{long i; for (i = 109; i < 113; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 114; i < 117; i++) R11[i] = (char *(*)()) F1_8;}
	R11[120] = (char *(*)()) F1_8;
	{long i; for (i = 122; i < 125; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 126; i < 129; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 130; i < 132; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 134; i < 136; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 137; i < 140; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 145; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 146; i < 148; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 149; i < 155; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 156; i < 158; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 159; i < 163; i++) R11[i] = (char *(*)()) F1_8;}
	R11[168] = (char *(*)()) F171_1746;
	R11[170] = (char *(*)()) F173_1786;
	R11[172] = (char *(*)()) F175_1803;
	R11[173] = (char *(*)()) F174_1795;
	{long i; for (i = 176; i < 178; i++) R11[i] = (char *(*)()) F1_8;}
	R11[179] = (char *(*)()) F182_1882;
	R11[184] = (char *(*)()) F1_8;
	R11[202] = (char *(*)()) F205_2374;
	R11[203] = (char *(*)()) F1_8;
	R11[204] = (char *(*)()) F207_2482;
	R11[206] = (char *(*)()) F1_8;
	{long i; for (i = 208; i < 210; i++) R11[i] = (char *(*)()) F1_8;}
	R11[230] = (char *(*)()) F1_8;
	{long i; for (i = 232; i < 234; i++) R11[i] = (char *(*)()) F1_8;}
	R11[248] = (char *(*)()) F1_8;
	{long i; for (i = 291; i < 299; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 311; i < 323; i++) R11[i] = (char *(*)()) F1_8;}
	R11[491] = (char *(*)()) F1_8;
	{long i; for (i = 555; i < 557; i++) R11[i] = (char *(*)()) F1_8;}
	R11[582] = (char *(*)()) F585_3360;
	R11[583] = (char *(*)()) F586_3360;
	R11[584] = (char *(*)()) F587_3360;
	R11[585] = (char *(*)()) F588_3360;
	R11[586] = (char *(*)()) F589_3360;
	R11[587] = (char *(*)()) F590_3360;
	R11[588] = (char *(*)()) F591_3360;
	R11[589] = (char *(*)()) F592_3360;
	R11[590] = (char *(*)()) F593_3360;
	R11[591] = (char *(*)()) F594_3360;
	R11[592] = (char *(*)()) F595_3360;
	R11[593] = (char *(*)()) F596_3360;
	R11[644] = (char *(*)()) F621_3441;
	R11[645] = (char *(*)()) F623_3441;
	R11[647] = (char *(*)()) F621_3441;
	{long i; for (i = 649; i < 655; i++) R11[i] = (char *(*)()) F1_8;}
	R11[657] = (char *(*)()) F660_3643;
	R11[658] = (char *(*)()) F661_3643;
	R11[659] = (char *(*)()) F662_3643;
	R11[660] = (char *(*)()) F663_3643;
	R11[661] = (char *(*)()) F664_3643;
	R11[662] = (char *(*)()) F665_3643;
	R11[663] = (char *(*)()) F666_3643;
	R11[664] = (char *(*)()) F667_3643;
	R11[665] = (char *(*)()) F668_3643;
	R11[666] = (char *(*)()) F669_3643;
	R11[667] = (char *(*)()) F670_3643;
	R11[668] = (char *(*)()) F671_3643;
	R11[670] = (char *(*)()) F673_3726;
	R11[671] = (char *(*)()) F674_3726;
	R11[672] = (char *(*)()) F675_3726;
	R11[673] = (char *(*)()) F676_3726;
	R11[674] = (char *(*)()) F677_3726;
	R11[675] = (char *(*)()) F678_3820;
	R11[676] = (char *(*)()) F679_3820;
	R11[677] = (char *(*)()) F673_3726;
	R11[679] = (char *(*)()) F1_8;
	{long i; for (i = 682; i < 694; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 743; i < 753; i++) R11[i] = (char *(*)()) F1_8;}
	R11[754] = (char *(*)()) F1_8;
	{long i; for (i = 756; i < 758; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 759; i < 761; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 762; i < 764; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 765; i < 767; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 768; i < 776; i++) R11[i] = (char *(*)()) F1_8;}
	R11[777] = (char *(*)()) F780_4243;
	R11[778] = (char *(*)()) F781_4280;
	R11[779] = (char *(*)()) F782_4280;
	R11[780] = (char *(*)()) F783_4280;
	R11[781] = (char *(*)()) F784_4280;
	R11[782] = (char *(*)()) F785_4280;
	R11[783] = (char *(*)()) F786_4280;
	R11[784] = (char *(*)()) F787_4280;
	R11[785] = (char *(*)()) F788_4280;
	R11[786] = (char *(*)()) F789_4280;
	R11[787] = (char *(*)()) F790_4280;
	R11[788] = (char *(*)()) F791_4280;
	R11[789] = (char *(*)()) F792_4280;
	R11[790] = (char *(*)()) F793_4280;
	R11[791] = (char *(*)()) F794_4280;
	R11[792] = (char *(*)()) F795_4280;
	R11[793] = (char *(*)()) F796_4280;
	R11[794] = (char *(*)()) F797_4280;
	R11[795] = (char *(*)()) F798_4280;
	R11[796] = (char *(*)()) F799_4280;
	R11[797] = (char *(*)()) F800_4280;
	R11[798] = (char *(*)()) F801_4280;
	R11[799] = (char *(*)()) F802_4280;
	R11[800] = (char *(*)()) F803_4280;
	R11[801] = (char *(*)()) F804_4280;
	R11[802] = (char *(*)()) F805_4280;
	R11[803] = (char *(*)()) F806_4280;
	R11[804] = (char *(*)()) F807_4280;
	R11[805] = (char *(*)()) F808_4280;
	R11[806] = (char *(*)()) F809_4280;
	R11[807] = (char *(*)()) F810_4280;
	R11[808] = (char *(*)()) F811_4280;
	R11[809] = (char *(*)()) F812_4323;
	{long i; for (i = 811; i < 813; i++) R11[i] = (char *(*)()) F813_4441;}
	{long i; for (i = 814; i < 816; i++) R11[i] = (char *(*)()) F816_4535;}
	{long i; for (i = 817; i < 819; i++) R11[i] = (char *(*)()) F819_4630;}
	{long i; for (i = 820; i < 822; i++) R11[i] = (char *(*)()) F822_4729;}
	{long i; for (i = 823; i < 825; i++) R11[i] = (char *(*)()) F825_4795;}
	{long i; for (i = 826; i < 828; i++) R11[i] = (char *(*)()) F828_4856;}
	{long i; for (i = 829; i < 831; i++) R11[i] = (char *(*)()) F831_4896;}
	{long i; for (i = 832; i < 834; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 835; i < 837; i++) R11[i] = (char *(*)()) F837_4968;}
	{long i; for (i = 838; i < 840; i++) R11[i] = (char *(*)()) F840_5067;}
	{long i; for (i = 841; i < 843; i++) R11[i] = (char *(*)()) F843_5165;}
	{long i; for (i = 844; i < 846; i++) R11[i] = (char *(*)()) F846_5264;}
	{long i; for (i = 847; i < 849; i++) R11[i] = (char *(*)()) F849_5363;}
	{long i; for (i = 850; i < 882; i++) R11[i] = (char *(*)()) F852_5451;}
	{long i; for (i = 891; i < 894; i++) R11[i] = (char *(*)()) F893_5688;}
	{long i; for (i = 895; i < 897; i++) R11[i] = (char *(*)()) F897_5885;}
	R11[897] = (char *(*)()) F1_8;
	R11[899] = (char *(*)()) F1_8;
	{long i; for (i = 904; i < 906; i++) R11[i] = (char *(*)()) F1_8;}
	R11[907] = (char *(*)()) F1_8;
	{long i; for (i = 910; i < 912; i++) R11[i] = (char *(*)()) F1_8;}
	R11[914] = (char *(*)()) F172_1768;
	R11[916] = (char *(*)()) F172_1768;
	R11[919] = (char *(*)()) F922_6531;
	R11[920] = (char *(*)()) F1_8;
	{long i; for (i = 922; i < 926; i++) R11[i] = (char *(*)()) F1_8;}
}

char *(*R599[7])();
void R599_init () {
	R599[0] = (char *(*)()) F43_616;
	R599[1] = (char *(*)()) F44_616_599_1;
	R599[2] = (char *(*)()) F45_616_599_1;
	R599[3] = (char *(*)()) F46_616_599_1;
	R599[4] = (char *(*)()) F43_616;
	R599[5] = (char *(*)()) F44_616_599_1;
	R599[6] = (char *(*)()) F43_616;
}
static EIF_REFERENCE F44_616_599_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F44_616(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F45_616_599_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F45_616(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F46_616_599_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F46_616(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R600[7])();
void R600_init () {
	R600[0] = (char *(*)()) F43_617;
	R600[1] = (char *(*)()) F44_617_600_4;
	R600[2] = (char *(*)()) F45_617_600_4;
	R600[3] = (char *(*)()) F46_617_600_4;
	R600[4] = (char *(*)()) F43_617;
	R600[5] = (char *(*)()) F44_617_600_4;
	R600[6] = (char *(*)()) F43_617;
}
static void F44_617_600_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F44_617(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F45_617_600_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F45_617(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F46_617_600_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F46_617(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R604[3])();
void R604_init () {
	R604[0] = (char *(*)()) F47_620;
	R604[1] = (char *(*)()) F48_620;
	R604[2] = (char *(*)()) F49_623;
}

char *(*R706[724])();
void R706_init () {
	R706[0] = (char *(*)()) F55_740;
	R706[1] = (char *(*)()) F56_745;
	R706[2] = (char *(*)()) F57_750;
	R706[3] = (char *(*)()) F58_754;
	R706[4] = (char *(*)()) F59_760;
	R706[5] = (char *(*)()) F60_765;
	R706[6] = (char *(*)()) F61_770;
	R706[7] = (char *(*)()) F62_786;
	R706[8] = (char *(*)()) F63_791;
	R706[9] = (char *(*)()) F64_796;
	R706[10] = (char *(*)()) F65_801;
	R706[11] = (char *(*)()) F66_807;
	R706[47] = (char *(*)()) F102_1322;
	R706[124] = (char *(*)()) F179_1861;
	R706[597] = (char *(*)()) F652_3543;
	R706[598] = (char *(*)()) F653_3549;
	R706[599] = (char *(*)()) F654_3554;
	R706[600] = (char *(*)()) F655_3560;
	R706[601] = (char *(*)()) F656_3565;
	R706[691] = (char *(*)()) F746_4063;
	R706[692] = (char *(*)()) F67_812;
	R706[693] = (char *(*)()) F748_4073;
	R706[694] = (char *(*)()) F749_4080;
	R706[695] = (char *(*)()) F750_4085;
	R706[696] = (char *(*)()) F751_4089;
	R706[697] = (char *(*)()) F752_4093;
	R706[699] = (char *(*)()) F754_4100;
	R706[700] = (char *(*)()) F755_4107;
	{long i; for (i = 704; i < 706; i++) R706[i] = (char *(*)()) F758_4132;}
	{long i; for (i = 707; i < 709; i++) R706[i] = (char *(*)()) F761_4143;}
	{long i; for (i = 710; i < 712; i++) R706[i] = (char *(*)()) F761_4143;}
	{long i; for (i = 713; i < 715; i++) R706[i] = (char *(*)()) F767_4165;}
	R706[716] = (char *(*)()) F771_4177;
	{long i; for (i = 717; i < 723; i++) R706[i] = (char *(*)()) F67_812;}
	R706[723] = (char *(*)()) F778_4200;
}

char *(*R707[724])();
void R707_init () {
	R707[0] = (char *(*)()) F55_741;
	R707[1] = (char *(*)()) F56_746;
	R707[2] = (char *(*)()) F57_751;
	R707[3] = (char *(*)()) F58_755;
	R707[4] = (char *(*)()) F59_761;
	R707[5] = (char *(*)()) F60_766;
	R707[6] = (char *(*)()) F61_771;
	R707[7] = (char *(*)()) F62_787;
	R707[8] = (char *(*)()) F63_792;
	R707[9] = (char *(*)()) F64_797;
	R707[10] = (char *(*)()) F65_802;
	R707[11] = (char *(*)()) F66_808;
	R707[47] = (char *(*)()) F102_1323;
	R707[124] = (char *(*)()) F179_1862;
	R707[597] = (char *(*)()) F652_3544;
	R707[598] = (char *(*)()) F653_3550;
	R707[599] = (char *(*)()) F654_3555;
	R707[600] = (char *(*)()) F655_3561;
	R707[601] = (char *(*)()) F656_3566;
	R707[691] = (char *(*)()) F746_4064;
	R707[692] = (char *(*)()) F747_4072;
	R707[693] = (char *(*)()) F748_4074;
	R707[694] = (char *(*)()) F749_4081;
	R707[695] = (char *(*)()) F750_4086;
	R707[696] = (char *(*)()) F751_4090;
	R707[697] = (char *(*)()) F752_4094;
	R707[699] = (char *(*)()) F754_4101;
	R707[700] = (char *(*)()) F755_4108;
	{long i; for (i = 704; i < 706; i++) R707[i] = (char *(*)()) F758_4133;}
	{long i; for (i = 707; i < 709; i++) R707[i] = (char *(*)()) F761_4145;}
	{long i; for (i = 710; i < 712; i++) R707[i] = (char *(*)()) F761_4145;}
	{long i; for (i = 713; i < 715; i++) R707[i] = (char *(*)()) F767_4166;}
	R707[716] = (char *(*)()) F771_4180;
	{long i; for (i = 717; i < 723; i++) R707[i] = (char *(*)()) F770_4173;}
	R707[723] = (char *(*)()) F778_4203;
}

char *(*R708[724])();
void R708_init () {
	R708[0] = (char *(*)()) F55_742;
	R708[1] = (char *(*)()) F56_747;
	R708[2] = (char *(*)()) F57_752;
	R708[3] = (char *(*)()) F58_756;
	R708[4] = (char *(*)()) F59_762;
	R708[5] = (char *(*)()) F60_767;
	R708[6] = (char *(*)()) F61_772;
	R708[7] = (char *(*)()) F62_788;
	R708[8] = (char *(*)()) F63_793;
	R708[9] = (char *(*)()) F64_798;
	R708[10] = (char *(*)()) F65_803;
	R708[11] = (char *(*)()) F66_809;
	R708[47] = (char *(*)()) F102_1324;
	R708[124] = (char *(*)()) F179_1863;
	R708[597] = (char *(*)()) F652_3545;
	R708[598] = (char *(*)()) F653_3551;
	R708[599] = (char *(*)()) F654_3556;
	R708[600] = (char *(*)()) F655_3562;
	R708[601] = (char *(*)()) F656_3567;
	R708[691] = (char *(*)()) F746_4065;
	R708[692] = (char *(*)()) F67_814;
	R708[693] = (char *(*)()) F748_4075;
	R708[694] = (char *(*)()) F749_4082;
	R708[695] = (char *(*)()) F750_4087;
	R708[696] = (char *(*)()) F751_4091;
	R708[697] = (char *(*)()) F752_4095;
	R708[699] = (char *(*)()) F754_4102;
	R708[700] = (char *(*)()) F755_4109;
	{long i; for (i = 704; i < 706; i++) R708[i] = (char *(*)()) F758_4134;}
	{long i; for (i = 707; i < 709; i++) R708[i] = (char *(*)()) F761_4147;}
	{long i; for (i = 710; i < 712; i++) R708[i] = (char *(*)()) F761_4147;}
	{long i; for (i = 713; i < 715; i++) R708[i] = (char *(*)()) F767_4167;}
	{long i; for (i = 716; i < 724; i++) R708[i] = (char *(*)()) F67_814;}
}

char *(*R709[724])();
void R709_init () {
	R709[0] = (char *(*)()) F55_743;
	R709[1] = (char *(*)()) F56_748;
	R709[2] = (char *(*)()) F57_753;
	R709[3] = (char *(*)()) F58_757;
	R709[4] = (char *(*)()) F59_763;
	R709[5] = (char *(*)()) F60_768;
	R709[6] = (char *(*)()) F61_773;
	R709[7] = (char *(*)()) F62_789;
	R709[8] = (char *(*)()) F63_794;
	R709[9] = (char *(*)()) F64_799;
	R709[10] = (char *(*)()) F65_804;
	R709[11] = (char *(*)()) F66_810;
	R709[47] = (char *(*)()) F102_1325;
	R709[124] = (char *(*)()) F179_1864;
	R709[597] = (char *(*)()) F652_3546;
	R709[598] = (char *(*)()) F653_3552;
	R709[599] = (char *(*)()) F654_3557;
	R709[600] = (char *(*)()) F655_3563;
	R709[601] = (char *(*)()) F656_3568;
	R709[691] = (char *(*)()) F746_4066;
	R709[692] = (char *(*)()) F67_815;
	R709[693] = (char *(*)()) F748_4076;
	R709[694] = (char *(*)()) F749_4083;
	R709[695] = (char *(*)()) F750_4088;
	R709[696] = (char *(*)()) F751_4092;
	R709[697] = (char *(*)()) F752_4096;
	R709[699] = (char *(*)()) F754_4103;
	R709[700] = (char *(*)()) F755_4110;
	{long i; for (i = 704; i < 706; i++) R709[i] = (char *(*)()) F758_4135;}
	{long i; for (i = 707; i < 709; i++) R709[i] = (char *(*)()) F761_4148;}
	{long i; for (i = 710; i < 712; i++) R709[i] = (char *(*)()) F761_4148;}
	{long i; for (i = 713; i < 715; i++) R709[i] = (char *(*)()) F767_4168;}
	{long i; for (i = 716; i < 724; i++) R709[i] = (char *(*)()) F67_815;}
}

char *(*R710[724])();
void R710_init () {
	{long i; for (i = 0; i < 4; i++) R710[i] = (char *(*)()) F54_728;}
	R710[4] = (char *(*)()) F59_764;
	{long i; for (i = 5; i < 12; i++) R710[i] = (char *(*)()) F54_728;}
	R710[47] = (char *(*)()) F54_728;
	R710[124] = (char *(*)()) F179_1865;
	{long i; for (i = 597; i < 602; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 691; i < 698; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 699; i < 701; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 704; i < 706; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 707; i < 709; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 710; i < 712; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 713; i < 715; i++) R710[i] = (char *(*)()) F54_728;}
	{long i; for (i = 716; i < 724; i++) R710[i] = (char *(*)()) F54_728;}
}

char *(*R1237[4])();
void R1237_init () {
	R1237[0] = (char *(*)()) F104_1346;
	R1237[1] = (char *(*)()) F105_1357;
	R1237[2] = (char *(*)()) F106_1380;
	R1237[3] = (char *(*)()) F107_1413;
}

char *(*R1274[2])();
void R1274_init () {
	R1274[0] = (char *(*)()) F106_1377;
	R1274[1] = (char *(*)()) F107_1409;
}

char *(*R1276[2])();
void R1276_init () {
	R1276[0] = (char *(*)()) F106_1379;
	R1276[1] = (char *(*)()) F107_1412;
}

char *(*R1284[2])();
void R1284_init () {
	R1284[0] = (char *(*)()) F106_1388;
	R1284[1] = (char *(*)()) F107_1420;
}

char *(*R1285[2])();
void R1285_init () {
	R1285[0] = (char *(*)()) F106_1389;
	R1285[1] = (char *(*)()) F107_1421;
}

char *(*R1356[3])();
void R1356_init () {
	R1356[0] = (char *(*)()) F113_1465;
	R1356[1] = (char *(*)()) F114_1465;
	R1356[2] = (char *(*)()) F113_1465;
}

char *(*R1395[40])();
void R1395_init () {
	R1395[0] = (char *(*)()) F118_1504;
	R1395[1] = (char *(*)()) F119_1528;
	R1395[5] = (char *(*)()) F123_1531;
	R1395[7] = (char *(*)()) F125_1533;
	R1395[8] = (char *(*)()) F126_1539;
	R1395[9] = (char *(*)()) F127_1556;
	R1395[11] = (char *(*)()) F129_1560;
	R1395[12] = (char *(*)()) F130_1562;
	R1395[13] = (char *(*)()) F131_1564;
	R1395[15] = (char *(*)()) F133_1566;
	R1395[16] = (char *(*)()) F134_1570;
	R1395[19] = (char *(*)()) F137_1572;
	R1395[20] = (char *(*)()) F138_1574;
	R1395[22] = (char *(*)()) F140_1578;
	R1395[23] = (char *(*)()) F141_1580;
	R1395[24] = (char *(*)()) F142_1586;
	R1395[26] = (char *(*)()) F144_1588;
	R1395[27] = (char *(*)()) F145_1590;
	R1395[28] = (char *(*)()) F146_1594;
	R1395[29] = (char *(*)()) F147_1598;
	R1395[31] = (char *(*)()) F149_1600;
	R1395[32] = (char *(*)()) F150_1602;
	R1395[34] = (char *(*)()) F152_1604;
	R1395[35] = (char *(*)()) F153_1606;
	R1395[36] = (char *(*)()) F154_1608;
	R1395[37] = (char *(*)()) F155_1610;
	R1395[38] = (char *(*)()) F156_1614;
	R1395[39] = (char *(*)()) F157_1616;
}

char *(*R1454[595])();
void R1454_init () {
	R1454[0] = (char *(*)()) F159_1621;
	R1454[1] = (char *(*)()) F160_1622;
	R1454[21] = (char *(*)()) F180_1868;
	R1454[594] = (char *(*)()) F753_4099;
}

char *(*R1457[4])();
void R1457_init () {
	R1457[0] = (char *(*)()) F162_1625;
	R1457[1] = (char *(*)()) F163_1628;
	R1457[2] = (char *(*)()) F164_1631;
	R1457[3] = (char *(*)()) F165_1633;
}

char *(*R1464[752])();
void R1464_init () {
	R1464[0] = (char *(*)()) F171_1745;
	R1464[2] = (char *(*)()) F173_1787;
	R1464[4] = (char *(*)()) F175_1804;
	R1464[5] = (char *(*)()) F174_1796;
	R1464[609] = (char *(*)()) F780_4242;
	R1464[610] = (char *(*)()) F781_4281;
	R1464[611] = (char *(*)()) F782_4281;
	R1464[612] = (char *(*)()) F783_4281;
	R1464[613] = (char *(*)()) F784_4281;
	R1464[614] = (char *(*)()) F785_4281;
	R1464[615] = (char *(*)()) F786_4281;
	R1464[616] = (char *(*)()) F787_4281;
	R1464[617] = (char *(*)()) F788_4281;
	R1464[618] = (char *(*)()) F789_4281;
	R1464[619] = (char *(*)()) F790_4281;
	R1464[620] = (char *(*)()) F791_4281;
	R1464[621] = (char *(*)()) F792_4281;
	R1464[622] = (char *(*)()) F793_4281;
	R1464[623] = (char *(*)()) F794_4281;
	R1464[624] = (char *(*)()) F795_4281;
	R1464[625] = (char *(*)()) F796_4281;
	R1464[626] = (char *(*)()) F797_4281;
	R1464[627] = (char *(*)()) F798_4281;
	R1464[628] = (char *(*)()) F799_4281;
	R1464[629] = (char *(*)()) F800_4281;
	R1464[630] = (char *(*)()) F801_4281;
	R1464[631] = (char *(*)()) F802_4281;
	R1464[632] = (char *(*)()) F803_4281;
	R1464[633] = (char *(*)()) F804_4281;
	R1464[634] = (char *(*)()) F805_4281;
	R1464[635] = (char *(*)()) F806_4281;
	R1464[636] = (char *(*)()) F807_4281;
	R1464[637] = (char *(*)()) F808_4281;
	R1464[638] = (char *(*)()) F809_4281;
	R1464[639] = (char *(*)()) F810_4281;
	R1464[640] = (char *(*)()) F811_4281;
	R1464[643] = (char *(*)()) F814_4499_1464_2;
	R1464[644] = (char *(*)()) F815_4499_1464_2;
	R1464[646] = (char *(*)()) F817_4594_1464_2;
	R1464[647] = (char *(*)()) F818_4594_1464_2;
	R1464[649] = (char *(*)()) F820_4689_1464_2;
	R1464[650] = (char *(*)()) F821_4689_1464_2;
	R1464[652] = (char *(*)()) F823_4758_1464_2;
	R1464[653] = (char *(*)()) F824_4758_1464_2;
	R1464[655] = (char *(*)()) F826_4824_1464_2;
	R1464[656] = (char *(*)()) F827_4824_1464_2;
	{long i; for (i = 658; i < 660; i++) R1464[i] = (char *(*)()) F828_4855;}
	{long i; for (i = 661; i < 663; i++) R1464[i] = (char *(*)()) F831_4895;}
	R1464[667] = (char *(*)()) F838_5030_1464_2;
	R1464[668] = (char *(*)()) F839_5030_1464_2;
	R1464[670] = (char *(*)()) F841_5128_1464_2;
	R1464[671] = (char *(*)()) F842_5128_1464_2;
	R1464[673] = (char *(*)()) F844_5227_1464_2;
	R1464[674] = (char *(*)()) F845_5227_1464_2;
	R1464[676] = (char *(*)()) F847_5326_1464_2;
	R1464[677] = (char *(*)()) F848_5326_1464_2;
	R1464[679] = (char *(*)()) F850_5421_1464_2;
	R1464[680] = (char *(*)()) F851_5421_1464_2;
	{long i; for (i = 723; i < 726; i++) R1464[i] = (char *(*)()) F893_5693;}
	{long i; for (i = 727; i < 729; i++) R1464[i] = (char *(*)()) F897_5890;}
	R1464[746] = (char *(*)()) F917_6411;
	R1464[748] = (char *(*)()) F919_6449;
	R1464[751] = (char *(*)()) F922_6530;
}
static EIF_BOOLEAN F814_4499_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F814_4499(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F815_4499_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F815_4499(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F817_4594_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F817_4594(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F818_4594_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F818_4594(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F820_4689_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F820_4689(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F821_4689_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F821_4689(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F823_4758_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F823_4758(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F824_4758_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F824_4758(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F826_4824_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F826_4824(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F827_4824_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F827_4824(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F838_5030_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F838_5030(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F839_5030_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F839_5030(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F841_5128_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F841_5128(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F842_5128_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F842_5128(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F844_5227_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_5227(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F845_5227_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F845_5227(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F847_5326_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F847_5326(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F848_5326_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F848_5326(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F850_5421_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F850_5421(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F851_5421_1464_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F851_5421(Current, *(EIF_NATURAL_64 *)arg1);
}

char *(*R1465[752])();
void R1465_init () {
	R1465[0] = (char *(*)()) F166_1635;
	R1465[2] = (char *(*)()) F172_1765;
	{long i; for (i = 4; i < 6; i++) R1465[i] = (char *(*)()) F172_1765;}
	R1465[609] = (char *(*)()) F172_1765;
	R1465[610] = (char *(*)()) F781_4282;
	R1465[611] = (char *(*)()) F782_4282;
	R1465[612] = (char *(*)()) F783_4282;
	R1465[613] = (char *(*)()) F784_4282;
	R1465[614] = (char *(*)()) F785_4282;
	R1465[615] = (char *(*)()) F786_4282;
	R1465[616] = (char *(*)()) F787_4282;
	R1465[617] = (char *(*)()) F788_4282;
	R1465[618] = (char *(*)()) F789_4282;
	R1465[619] = (char *(*)()) F790_4282;
	R1465[620] = (char *(*)()) F791_4282;
	R1465[621] = (char *(*)()) F792_4282;
	R1465[622] = (char *(*)()) F793_4282;
	R1465[623] = (char *(*)()) F794_4282;
	R1465[624] = (char *(*)()) F795_4282;
	R1465[625] = (char *(*)()) F796_4282;
	R1465[626] = (char *(*)()) F797_4282;
	R1465[627] = (char *(*)()) F798_4282;
	R1465[628] = (char *(*)()) F799_4282;
	R1465[629] = (char *(*)()) F800_4282;
	R1465[630] = (char *(*)()) F801_4282;
	R1465[631] = (char *(*)()) F802_4282;
	R1465[632] = (char *(*)()) F803_4282;
	R1465[633] = (char *(*)()) F804_4282;
	R1465[634] = (char *(*)()) F805_4282;
	R1465[635] = (char *(*)()) F806_4282;
	R1465[636] = (char *(*)()) F807_4282;
	R1465[637] = (char *(*)()) F808_4282;
	R1465[638] = (char *(*)()) F809_4282;
	R1465[639] = (char *(*)()) F810_4282;
	R1465[640] = (char *(*)()) F811_4282;
	{long i; for (i = 643; i < 645; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 646; i < 648; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 649; i < 651; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 652; i < 654; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 655; i < 657; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 658; i < 660; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 661; i < 663; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 667; i < 669; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 670; i < 672; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 673; i < 675; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 676; i < 678; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 679; i < 681; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 723; i < 726; i++) R1465[i] = (char *(*)()) F172_1765;}
	{long i; for (i = 727; i < 729; i++) R1465[i] = (char *(*)()) F172_1765;}
	R1465[746] = (char *(*)()) F172_1765;
	R1465[748] = (char *(*)()) F172_1765;
	R1465[751] = (char *(*)()) F172_1765;
}

char *(*R1575[2])();
void R1575_init () {
	R1575[0] = (char *(*)()) F175_1805;
	R1575[1] = (char *(*)()) F174_1797;
}

char *(*R1759[343])();
void R1759_init () {
	{long i; for (i = 0; i < 2; i++) R1759[i] = (char *(*)()) F557_2989;}
	R1759[342] = (char *(*)()) F900_6034;
}

char *(*R1770[343])();
void R1770_init () {
	{long i; for (i = 0; i < 2; i++) R1770[i] = (char *(*)()) F557_3068;}
	R1770[342] = (char *(*)()) F900_6065;
}

char *(*R1771[343])();
void R1771_init () {
	{long i; for (i = 0; i < 2; i++) R1771[i] = (char *(*)()) F557_3069;}
	R1771[342] = (char *(*)()) F900_6066;
}

char *(*R1772[343])();
void R1772_init () {
	{long i; for (i = 0; i < 2; i++) R1772[i] = (char *(*)()) F557_3063;}
	R1772[342] = (char *(*)()) F900_6057;
}

char *(*R1774[343])();
void R1774_init () {
	{long i; for (i = 0; i < 2; i++) R1774[i] = (char *(*)()) F557_3066;}
	R1774[342] = (char *(*)()) F900_6055;
}

char *(*R1802[343])();
void R1802_init () {
	{long i; for (i = 0; i < 2; i++) R1802[i] = (char *(*)()) F557_3096;}
	R1802[342] = (char *(*)()) F900_6052;
}

char *(*R1815[343])();
void R1815_init () {
	{long i; for (i = 0; i < 2; i++) R1815[i] = (char *(*)()) F557_3103;}
	R1815[342] = (char *(*)()) F900_6046;
}

char *(*R1818[343])();
void R1818_init () {
	{long i; for (i = 0; i < 2; i++) R1818[i] = (char *(*)()) F557_3100;}
	R1818[342] = (char *(*)()) F900_6043;
}

char *(*R2106[693])();
void R2106_init () {
	R2106[0] = (char *(*)()) F197_2350;
	R2106[378] = (char *(*)()) F192_2350;
	R2106[379] = (char *(*)()) F193_2350;
	R2106[380] = (char *(*)()) F194_2350;
	R2106[381] = (char *(*)()) F195_2350;
	R2106[382] = (char *(*)()) F196_2350;
	R2106[383] = (char *(*)()) F197_2350;
	R2106[384] = (char *(*)()) F198_2350;
	R2106[385] = (char *(*)()) F199_2350;
	R2106[386] = (char *(*)()) F200_2350;
	R2106[387] = (char *(*)()) F201_2350;
	R2106[388] = (char *(*)()) F202_2350;
	R2106[389] = (char *(*)()) F203_2350;
	R2106[453] = (char *(*)()) F192_2350;
	R2106[454] = (char *(*)()) F193_2350;
	R2106[455] = (char *(*)()) F194_2350;
	R2106[456] = (char *(*)()) F195_2350;
	R2106[457] = (char *(*)()) F196_2350;
	R2106[458] = (char *(*)()) F197_2350;
	R2106[459] = (char *(*)()) F198_2350;
	R2106[460] = (char *(*)()) F199_2350;
	R2106[461] = (char *(*)()) F200_2350;
	R2106[462] = (char *(*)()) F201_2350;
	R2106[463] = (char *(*)()) F202_2350;
	R2106[464] = (char *(*)()) F203_2350;
	{long i; for (i = 688; i < 690; i++) R2106[i] = (char *(*)()) F196_2350;}
	R2106[692] = (char *(*)()) F195_2350;
}


#ifdef __cplusplus
}
#endif
