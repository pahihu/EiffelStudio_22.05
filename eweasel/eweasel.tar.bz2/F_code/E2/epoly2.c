#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2107[693])();
void R2107_init () {
	R2107[0] = (char *(*)()) F197_2351_2107_121;
	R2107[378] = (char *(*)()) F192_2351;
	R2107[379] = (char *(*)()) F193_2351_2107_121;
	R2107[380] = (char *(*)()) F194_2351_2107_121;
	R2107[381] = (char *(*)()) F195_2351_2107_121;
	R2107[382] = (char *(*)()) F196_2351_2107_121;
	R2107[383] = (char *(*)()) F197_2351_2107_121;
	R2107[384] = (char *(*)()) F198_2351_2107_121;
	R2107[385] = (char *(*)()) F199_2351_2107_121;
	R2107[386] = (char *(*)()) F200_2351_2107_121;
	R2107[387] = (char *(*)()) F201_2351_2107_121;
	R2107[388] = (char *(*)()) F202_2351_2107_121;
	R2107[389] = (char *(*)()) F203_2351_2107_121;
	R2107[453] = (char *(*)()) F192_2351;
	R2107[454] = (char *(*)()) F193_2351_2107_121;
	R2107[455] = (char *(*)()) F194_2351_2107_121;
	R2107[456] = (char *(*)()) F195_2351_2107_121;
	R2107[457] = (char *(*)()) F196_2351_2107_121;
	R2107[458] = (char *(*)()) F197_2351_2107_121;
	R2107[459] = (char *(*)()) F198_2351_2107_121;
	R2107[460] = (char *(*)()) F199_2351_2107_121;
	R2107[461] = (char *(*)()) F200_2351_2107_121;
	R2107[462] = (char *(*)()) F201_2351_2107_121;
	R2107[463] = (char *(*)()) F202_2351_2107_121;
	R2107[464] = (char *(*)()) F203_2351_2107_121;
	{long i; for (i = 688; i < 690; i++) R2107[i] = (char *(*)()) F196_2351_2107_121;}
	R2107[692] = (char *(*)()) F195_2351_2107_121;
}
static void F197_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F197_2351(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F193_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F193_2351(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F194_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F194_2351(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F195_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F195_2351(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F196_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F196_2351(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F198_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F198_2351(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F199_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F199_2351(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F200_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F200_2351(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F201_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F201_2351(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F202_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F202_2351(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F203_2351_2107_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F203_2351(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2113[693])();
void R2113_init () {
	R2113[0] = (char *(*)()) F197_2357;
	R2113[378] = (char *(*)()) F192_2357;
	R2113[379] = (char *(*)()) F193_2357;
	R2113[380] = (char *(*)()) F194_2357;
	R2113[381] = (char *(*)()) F195_2357;
	R2113[382] = (char *(*)()) F196_2357;
	R2113[383] = (char *(*)()) F197_2357;
	R2113[384] = (char *(*)()) F198_2357;
	R2113[385] = (char *(*)()) F199_2357;
	R2113[386] = (char *(*)()) F200_2357;
	R2113[387] = (char *(*)()) F201_2357;
	R2113[388] = (char *(*)()) F202_2357;
	R2113[389] = (char *(*)()) F203_2357;
	R2113[453] = (char *(*)()) F192_2357;
	R2113[454] = (char *(*)()) F193_2357;
	R2113[455] = (char *(*)()) F194_2357;
	R2113[456] = (char *(*)()) F195_2357;
	R2113[457] = (char *(*)()) F196_2357;
	R2113[458] = (char *(*)()) F197_2357;
	R2113[459] = (char *(*)()) F198_2357;
	R2113[460] = (char *(*)()) F199_2357;
	R2113[461] = (char *(*)()) F200_2357;
	R2113[462] = (char *(*)()) F201_2357;
	R2113[463] = (char *(*)()) F202_2357;
	R2113[464] = (char *(*)()) F203_2357;
	{long i; for (i = 688; i < 690; i++) R2113[i] = (char *(*)()) F196_2357;}
	R2113[692] = (char *(*)()) F195_2357;
}

static EIF_TYPE_INDEX Y2114_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype12[] = {820,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype13[] = {820,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype38[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype39[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2114_pgtype40[] = {829,0xFFFF};
EIF_TYPE_INDEX *Y2114_gen_type [708];
EIF_TYPE_INDEX Y2114 [708];
void Y2114_init (void)
{
	egc_routines_types [2114] = Y2114;
	egc_routines_gen_types [2114] = Y2114_gen_type;
	egc_routines_offset [2114] = 191;
	Y2114_gen_type [0] = Y2114_pgtype0;
	Y2114_gen_type [1] = Y2114_pgtype1;
	Y2114_gen_type [2] = Y2114_pgtype2;
	Y2114_gen_type [3] = Y2114_pgtype3;
	Y2114_gen_type [4] = Y2114_pgtype4;
	Y2114_gen_type [5] = Y2114_pgtype5;
	Y2114_gen_type [6] = Y2114_pgtype6;
	Y2114_gen_type [7] = Y2114_pgtype7;
	Y2114_gen_type [8] = Y2114_pgtype8;
	Y2114_gen_type [9] = Y2114_pgtype9;
	Y2114_gen_type [10] = Y2114_pgtype10;
	Y2114_gen_type [11] = Y2114_pgtype11;
	Y2114_gen_type [15] = Y2114_pgtype12;
	Y2114_gen_type [16] = Y2114_pgtype13;
	Y2114_gen_type [393] = Y2114_pgtype14;
	Y2114_gen_type [394] = Y2114_pgtype15;
	Y2114_gen_type [395] = Y2114_pgtype16;
	Y2114_gen_type [396] = Y2114_pgtype17;
	Y2114_gen_type [397] = Y2114_pgtype18;
	Y2114_gen_type [398] = Y2114_pgtype19;
	Y2114_gen_type [399] = Y2114_pgtype20;
	Y2114_gen_type [400] = Y2114_pgtype21;
	Y2114_gen_type [401] = Y2114_pgtype22;
	Y2114_gen_type [402] = Y2114_pgtype23;
	Y2114_gen_type [403] = Y2114_pgtype24;
	Y2114_gen_type [404] = Y2114_pgtype25;
	Y2114_gen_type [468] = Y2114_pgtype26;
	Y2114_gen_type [469] = Y2114_pgtype27;
	Y2114_gen_type [470] = Y2114_pgtype28;
	Y2114_gen_type [471] = Y2114_pgtype29;
	Y2114_gen_type [472] = Y2114_pgtype30;
	Y2114_gen_type [473] = Y2114_pgtype31;
	Y2114_gen_type [474] = Y2114_pgtype32;
	Y2114_gen_type [475] = Y2114_pgtype33;
	Y2114_gen_type [476] = Y2114_pgtype34;
	Y2114_gen_type [477] = Y2114_pgtype35;
	Y2114_gen_type [478] = Y2114_pgtype36;
	Y2114_gen_type [479] = Y2114_pgtype37;
	Y2114_gen_type [703] = Y2114_pgtype38;
	Y2114_gen_type [704] = Y2114_pgtype39;
	Y2114_gen_type [707] = Y2114_pgtype40;
	{long i; for (i = 15; i < 17; i++) Y2114[i] = 820;};
	{long i; for (i = 703; i < 705; i++) Y2114[i] = 832;};
	Y2114[707] = 829;
}

char *(*R2360[201])();
void R2360_init () {
	R2360[0] = (char *(*)()) F294_2759;
	R2360[1] = (char *(*)()) F295_2759;
	R2360[2] = (char *(*)()) F296_2759_2360_1;
	R2360[3] = (char *(*)()) F297_2759_2360_1;
	R2360[4] = (char *(*)()) F298_2759_2360_1;
	R2360[5] = (char *(*)()) F299_2765;
	R2360[6] = (char *(*)()) F300_2765_2360_1;
	R2360[7] = (char *(*)()) F301_2771;
	R2360[20] = (char *(*)()) F302_2777;
	R2360[21] = (char *(*)()) F303_2777_2360_1;
	R2360[22] = (char *(*)()) F304_2777_2360_1;
	R2360[23] = (char *(*)()) F305_2777_2360_1;
	R2360[24] = (char *(*)()) F306_2777_2360_1;
	R2360[25] = (char *(*)()) F307_2777_2360_1;
	R2360[26] = (char *(*)()) F308_2777_2360_1;
	R2360[27] = (char *(*)()) F309_2777_2360_1;
	R2360[28] = (char *(*)()) F310_2777_2360_1;
	R2360[29] = (char *(*)()) F311_2777_2360_1;
	R2360[30] = (char *(*)()) F312_2777_2360_1;
	R2360[31] = (char *(*)()) F313_2777_2360_1;
	R2360[200] = (char *(*)()) F493_2899_2360_1;
}
static EIF_REFERENCE F296_2759_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F296_2759(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F297_2759_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F297_2759(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F298_2759_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F298_2759(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F300_2765_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F300_2765(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F303_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F303_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F304_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F304_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F305_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F305_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F306_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F306_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F307_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F307_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F308_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F308_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F309_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F309_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F310_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F310_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F311_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F311_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F312_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F312_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F313_2777_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F313_2777(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F493_2899_2360_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F493_2899(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2361[201])();
void R2361_init () {
	R2361[0] = (char *(*)()) F294_2762;
	R2361[1] = (char *(*)()) F295_2762;
	R2361[2] = (char *(*)()) F296_2762;
	R2361[3] = (char *(*)()) F297_2762;
	R2361[4] = (char *(*)()) F298_2762;
	R2361[5] = (char *(*)()) F299_2766;
	R2361[6] = (char *(*)()) F300_2766;
	R2361[7] = (char *(*)()) F301_2772;
	R2361[20] = (char *(*)()) F302_2786;
	R2361[21] = (char *(*)()) F303_2786;
	R2361[22] = (char *(*)()) F304_2786;
	R2361[23] = (char *(*)()) F305_2786;
	R2361[24] = (char *(*)()) F306_2786;
	R2361[25] = (char *(*)()) F307_2786;
	R2361[26] = (char *(*)()) F308_2786;
	R2361[27] = (char *(*)()) F309_2786;
	R2361[28] = (char *(*)()) F310_2786;
	R2361[29] = (char *(*)()) F311_2786;
	R2361[30] = (char *(*)()) F312_2786;
	R2361[31] = (char *(*)()) F313_2786;
	R2361[200] = (char *(*)()) F493_2900;
}

char *(*R2362[201])();
void R2362_init () {
	R2362[0] = (char *(*)()) F294_2763;
	R2362[1] = (char *(*)()) F295_2763;
	R2362[2] = (char *(*)()) F296_2763;
	R2362[3] = (char *(*)()) F297_2763;
	R2362[4] = (char *(*)()) F298_2763;
	R2362[5] = (char *(*)()) F299_2768;
	R2362[6] = (char *(*)()) F300_2768;
	R2362[7] = (char *(*)()) F301_2774;
	R2362[20] = (char *(*)()) F302_2792;
	R2362[21] = (char *(*)()) F303_2792;
	R2362[22] = (char *(*)()) F304_2792;
	R2362[23] = (char *(*)()) F305_2792;
	R2362[24] = (char *(*)()) F306_2792;
	R2362[25] = (char *(*)()) F307_2792;
	R2362[26] = (char *(*)()) F308_2792;
	R2362[27] = (char *(*)()) F309_2792;
	R2362[28] = (char *(*)()) F310_2792;
	R2362[29] = (char *(*)()) F311_2792;
	R2362[30] = (char *(*)()) F312_2792;
	R2362[31] = (char *(*)()) F313_2792;
	R2362[200] = (char *(*)()) F493_2906;
}

char *(*R2373[5])();
void R2373_init () {
	R2373[0] = (char *(*)()) F294_2760;
	R2373[1] = (char *(*)()) F295_2760_2373_1;
	R2373[2] = (char *(*)()) F296_2760;
	R2373[3] = (char *(*)()) F297_2760_2373_1;
	R2373[4] = (char *(*)()) F298_2760;
}
static EIF_REFERENCE F295_2760_2373_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F295_2760(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F297_2760_2373_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F297_2760(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2385[2])();
void R2385_init () {
	R2385[0] = (char *(*)()) F235_2648;
	R2385[1] = (char *(*)()) F236_2649;
}

char *(*R2400[34])();
void R2400_init () {
	R2400[0] = (char *(*)()) F647_3469;
	R2400[1] = (char *(*)()) F648_3469;
	R2400[3] = (char *(*)()) F649_3512;
	R2400[13] = (char *(*)()) F660_3633;
	R2400[14] = (char *(*)()) F661_3633;
	R2400[15] = (char *(*)()) F662_3633;
	R2400[16] = (char *(*)()) F663_3633;
	R2400[17] = (char *(*)()) F664_3633;
	R2400[18] = (char *(*)()) F665_3633;
	R2400[19] = (char *(*)()) F666_3633;
	R2400[20] = (char *(*)()) F667_3633;
	R2400[21] = (char *(*)()) F668_3633;
	R2400[22] = (char *(*)()) F669_3633;
	R2400[23] = (char *(*)()) F670_3633;
	R2400[24] = (char *(*)()) F671_3633;
	R2400[26] = (char *(*)()) F673_3718;
	R2400[27] = (char *(*)()) F674_3718;
	R2400[28] = (char *(*)()) F675_3718;
	R2400[29] = (char *(*)()) F676_3718;
	R2400[30] = (char *(*)()) F677_3718;
	R2400[31] = (char *(*)()) F673_3718;
	R2400[32] = (char *(*)()) F675_3718;
	R2400[33] = (char *(*)()) F673_3718;
}

static EIF_TYPE_INDEX Y2401_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype12[] = {894,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype13[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype14[] = {829,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype88[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype89[] = {829,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype256[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype319[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype320[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype321[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype346[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype433[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype446[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype447[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype448[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype449[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype450[] = {832,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype451[] = {829,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype452[] = {829,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype453[] = {829,0xFFFF};
static EIF_TYPE_INDEX Y2401_pgtype454[] = {832,0xFFFF};
EIF_TYPE_INDEX *Y2401_gen_type [663];
EIF_TYPE_INDEX Y2401 [663];
void Y2401_init (void)
{
	egc_routines_types [2401] = Y2401;
	egc_routines_gen_types [2401] = Y2401_gen_type;
	egc_routines_offset [2401] = 237;
	Y2401_gen_type [0] = Y2401_pgtype0;
	Y2401_gen_type [1] = Y2401_pgtype1;
	Y2401_gen_type [2] = Y2401_pgtype2;
	Y2401_gen_type [3] = Y2401_pgtype3;
	Y2401_gen_type [4] = Y2401_pgtype4;
	Y2401_gen_type [5] = Y2401_pgtype5;
	Y2401_gen_type [6] = Y2401_pgtype6;
	Y2401_gen_type [7] = Y2401_pgtype7;
	Y2401_gen_type [8] = Y2401_pgtype8;
	Y2401_gen_type [9] = Y2401_pgtype9;
	Y2401_gen_type [10] = Y2401_pgtype10;
	Y2401_gen_type [11] = Y2401_pgtype11;
	Y2401_gen_type [12] = Y2401_pgtype12;
	Y2401_gen_type [13] = Y2401_pgtype13;
	Y2401_gen_type [14] = Y2401_pgtype14;
	Y2401_gen_type [15] = Y2401_pgtype15;
	Y2401_gen_type [16] = Y2401_pgtype16;
	Y2401_gen_type [17] = Y2401_pgtype17;
	Y2401_gen_type [18] = Y2401_pgtype18;
	Y2401_gen_type [19] = Y2401_pgtype19;
	Y2401_gen_type [20] = Y2401_pgtype20;
	Y2401_gen_type [21] = Y2401_pgtype21;
	Y2401_gen_type [22] = Y2401_pgtype22;
	Y2401_gen_type [23] = Y2401_pgtype23;
	Y2401_gen_type [24] = Y2401_pgtype24;
	Y2401_gen_type [25] = Y2401_pgtype25;
	Y2401_gen_type [26] = Y2401_pgtype26;
	Y2401_gen_type [27] = Y2401_pgtype27;
	Y2401_gen_type [28] = Y2401_pgtype28;
	Y2401_gen_type [29] = Y2401_pgtype29;
	Y2401_gen_type [30] = Y2401_pgtype30;
	Y2401_gen_type [31] = Y2401_pgtype31;
	Y2401_gen_type [32] = Y2401_pgtype32;
	Y2401_gen_type [33] = Y2401_pgtype33;
	Y2401_gen_type [34] = Y2401_pgtype34;
	Y2401_gen_type [35] = Y2401_pgtype35;
	Y2401_gen_type [36] = Y2401_pgtype36;
	Y2401_gen_type [37] = Y2401_pgtype37;
	Y2401_gen_type [38] = Y2401_pgtype38;
	Y2401_gen_type [39] = Y2401_pgtype39;
	Y2401_gen_type [40] = Y2401_pgtype40;
	Y2401_gen_type [41] = Y2401_pgtype41;
	Y2401_gen_type [42] = Y2401_pgtype42;
	Y2401_gen_type [43] = Y2401_pgtype43;
	Y2401_gen_type [44] = Y2401_pgtype44;
	Y2401_gen_type [45] = Y2401_pgtype45;
	Y2401_gen_type [46] = Y2401_pgtype46;
	Y2401_gen_type [47] = Y2401_pgtype47;
	Y2401_gen_type [48] = Y2401_pgtype48;
	Y2401_gen_type [49] = Y2401_pgtype49;
	Y2401_gen_type [50] = Y2401_pgtype50;
	Y2401_gen_type [51] = Y2401_pgtype51;
	Y2401_gen_type [52] = Y2401_pgtype52;
	Y2401_gen_type [53] = Y2401_pgtype53;
	Y2401_gen_type [54] = Y2401_pgtype54;
	Y2401_gen_type [55] = Y2401_pgtype55;
	Y2401_gen_type [56] = Y2401_pgtype56;
	Y2401_gen_type [57] = Y2401_pgtype57;
	Y2401_gen_type [58] = Y2401_pgtype58;
	Y2401_gen_type [59] = Y2401_pgtype59;
	Y2401_gen_type [60] = Y2401_pgtype60;
	Y2401_gen_type [61] = Y2401_pgtype61;
	Y2401_gen_type [62] = Y2401_pgtype62;
	Y2401_gen_type [63] = Y2401_pgtype63;
	Y2401_gen_type [64] = Y2401_pgtype64;
	Y2401_gen_type [65] = Y2401_pgtype65;
	Y2401_gen_type [66] = Y2401_pgtype66;
	Y2401_gen_type [67] = Y2401_pgtype67;
	Y2401_gen_type [68] = Y2401_pgtype68;
	Y2401_gen_type [69] = Y2401_pgtype69;
	Y2401_gen_type [70] = Y2401_pgtype70;
	Y2401_gen_type [71] = Y2401_pgtype71;
	Y2401_gen_type [72] = Y2401_pgtype72;
	Y2401_gen_type [73] = Y2401_pgtype73;
	Y2401_gen_type [74] = Y2401_pgtype74;
	Y2401_gen_type [75] = Y2401_pgtype75;
	Y2401_gen_type [76] = Y2401_pgtype76;
	Y2401_gen_type [77] = Y2401_pgtype77;
	Y2401_gen_type [78] = Y2401_pgtype78;
	Y2401_gen_type [79] = Y2401_pgtype79;
	Y2401_gen_type [80] = Y2401_pgtype80;
	Y2401_gen_type [81] = Y2401_pgtype81;
	Y2401_gen_type [82] = Y2401_pgtype82;
	Y2401_gen_type [83] = Y2401_pgtype83;
	Y2401_gen_type [84] = Y2401_pgtype84;
	Y2401_gen_type [85] = Y2401_pgtype85;
	Y2401_gen_type [86] = Y2401_pgtype86;
	Y2401_gen_type [87] = Y2401_pgtype87;
	Y2401_gen_type [88] = Y2401_pgtype88;
	Y2401_gen_type [89] = Y2401_pgtype89;
	Y2401_gen_type [90] = Y2401_pgtype90;
	Y2401_gen_type [91] = Y2401_pgtype91;
	Y2401_gen_type [92] = Y2401_pgtype92;
	Y2401_gen_type [93] = Y2401_pgtype93;
	Y2401_gen_type [94] = Y2401_pgtype94;
	Y2401_gen_type [95] = Y2401_pgtype95;
	Y2401_gen_type [96] = Y2401_pgtype96;
	Y2401_gen_type [97] = Y2401_pgtype97;
	Y2401_gen_type [98] = Y2401_pgtype98;
	Y2401_gen_type [99] = Y2401_pgtype99;
	Y2401_gen_type [100] = Y2401_pgtype100;
	Y2401_gen_type [101] = Y2401_pgtype101;
	Y2401_gen_type [102] = Y2401_pgtype102;
	Y2401_gen_type [103] = Y2401_pgtype103;
	Y2401_gen_type [104] = Y2401_pgtype104;
	Y2401_gen_type [105] = Y2401_pgtype105;
	Y2401_gen_type [106] = Y2401_pgtype106;
	Y2401_gen_type [107] = Y2401_pgtype107;
	Y2401_gen_type [108] = Y2401_pgtype108;
	Y2401_gen_type [109] = Y2401_pgtype109;
	Y2401_gen_type [110] = Y2401_pgtype110;
	Y2401_gen_type [111] = Y2401_pgtype111;
	Y2401_gen_type [112] = Y2401_pgtype112;
	Y2401_gen_type [113] = Y2401_pgtype113;
	Y2401_gen_type [114] = Y2401_pgtype114;
	Y2401_gen_type [115] = Y2401_pgtype115;
	Y2401_gen_type [116] = Y2401_pgtype116;
	Y2401_gen_type [117] = Y2401_pgtype117;
	Y2401_gen_type [118] = Y2401_pgtype118;
	Y2401_gen_type [119] = Y2401_pgtype119;
	Y2401_gen_type [120] = Y2401_pgtype120;
	Y2401_gen_type [121] = Y2401_pgtype121;
	Y2401_gen_type [122] = Y2401_pgtype122;
	Y2401_gen_type [123] = Y2401_pgtype123;
	Y2401_gen_type [124] = Y2401_pgtype124;
	Y2401_gen_type [125] = Y2401_pgtype125;
	Y2401_gen_type [126] = Y2401_pgtype126;
	Y2401_gen_type [127] = Y2401_pgtype127;
	Y2401_gen_type [128] = Y2401_pgtype128;
	Y2401_gen_type [129] = Y2401_pgtype129;
	Y2401_gen_type [130] = Y2401_pgtype130;
	Y2401_gen_type [131] = Y2401_pgtype131;
	Y2401_gen_type [132] = Y2401_pgtype132;
	Y2401_gen_type [133] = Y2401_pgtype133;
	Y2401_gen_type [134] = Y2401_pgtype134;
	Y2401_gen_type [135] = Y2401_pgtype135;
	Y2401_gen_type [136] = Y2401_pgtype136;
	Y2401_gen_type [137] = Y2401_pgtype137;
	Y2401_gen_type [138] = Y2401_pgtype138;
	Y2401_gen_type [139] = Y2401_pgtype139;
	Y2401_gen_type [140] = Y2401_pgtype140;
	Y2401_gen_type [141] = Y2401_pgtype141;
	Y2401_gen_type [142] = Y2401_pgtype142;
	Y2401_gen_type [143] = Y2401_pgtype143;
	Y2401_gen_type [144] = Y2401_pgtype144;
	Y2401_gen_type [145] = Y2401_pgtype145;
	Y2401_gen_type [146] = Y2401_pgtype146;
	Y2401_gen_type [147] = Y2401_pgtype147;
	Y2401_gen_type [148] = Y2401_pgtype148;
	Y2401_gen_type [149] = Y2401_pgtype149;
	Y2401_gen_type [150] = Y2401_pgtype150;
	Y2401_gen_type [151] = Y2401_pgtype151;
	Y2401_gen_type [152] = Y2401_pgtype152;
	Y2401_gen_type [153] = Y2401_pgtype153;
	Y2401_gen_type [154] = Y2401_pgtype154;
	Y2401_gen_type [155] = Y2401_pgtype155;
	Y2401_gen_type [156] = Y2401_pgtype156;
	Y2401_gen_type [157] = Y2401_pgtype157;
	Y2401_gen_type [158] = Y2401_pgtype158;
	Y2401_gen_type [159] = Y2401_pgtype159;
	Y2401_gen_type [160] = Y2401_pgtype160;
	Y2401_gen_type [161] = Y2401_pgtype161;
	Y2401_gen_type [162] = Y2401_pgtype162;
	Y2401_gen_type [163] = Y2401_pgtype163;
	Y2401_gen_type [164] = Y2401_pgtype164;
	Y2401_gen_type [165] = Y2401_pgtype165;
	Y2401_gen_type [166] = Y2401_pgtype166;
	Y2401_gen_type [167] = Y2401_pgtype167;
	Y2401_gen_type [168] = Y2401_pgtype168;
	Y2401_gen_type [169] = Y2401_pgtype169;
	Y2401_gen_type [170] = Y2401_pgtype170;
	Y2401_gen_type [171] = Y2401_pgtype171;
	Y2401_gen_type [172] = Y2401_pgtype172;
	Y2401_gen_type [173] = Y2401_pgtype173;
	Y2401_gen_type [174] = Y2401_pgtype174;
	Y2401_gen_type [175] = Y2401_pgtype175;
	Y2401_gen_type [176] = Y2401_pgtype176;
	Y2401_gen_type [177] = Y2401_pgtype177;
	Y2401_gen_type [178] = Y2401_pgtype178;
	Y2401_gen_type [179] = Y2401_pgtype179;
	Y2401_gen_type [180] = Y2401_pgtype180;
	Y2401_gen_type [181] = Y2401_pgtype181;
	Y2401_gen_type [182] = Y2401_pgtype182;
	Y2401_gen_type [183] = Y2401_pgtype183;
	Y2401_gen_type [184] = Y2401_pgtype184;
	Y2401_gen_type [185] = Y2401_pgtype185;
	Y2401_gen_type [186] = Y2401_pgtype186;
	Y2401_gen_type [187] = Y2401_pgtype187;
	Y2401_gen_type [188] = Y2401_pgtype188;
	Y2401_gen_type [189] = Y2401_pgtype189;
	Y2401_gen_type [190] = Y2401_pgtype190;
	Y2401_gen_type [191] = Y2401_pgtype191;
	Y2401_gen_type [192] = Y2401_pgtype192;
	Y2401_gen_type [193] = Y2401_pgtype193;
	Y2401_gen_type [194] = Y2401_pgtype194;
	Y2401_gen_type [195] = Y2401_pgtype195;
	Y2401_gen_type [196] = Y2401_pgtype196;
	Y2401_gen_type [197] = Y2401_pgtype197;
	Y2401_gen_type [198] = Y2401_pgtype198;
	Y2401_gen_type [199] = Y2401_pgtype199;
	Y2401_gen_type [200] = Y2401_pgtype200;
	Y2401_gen_type [201] = Y2401_pgtype201;
	Y2401_gen_type [202] = Y2401_pgtype202;
	Y2401_gen_type [203] = Y2401_pgtype203;
	Y2401_gen_type [204] = Y2401_pgtype204;
	Y2401_gen_type [205] = Y2401_pgtype205;
	Y2401_gen_type [206] = Y2401_pgtype206;
	Y2401_gen_type [207] = Y2401_pgtype207;
	Y2401_gen_type [208] = Y2401_pgtype208;
	Y2401_gen_type [209] = Y2401_pgtype209;
	Y2401_gen_type [210] = Y2401_pgtype210;
	Y2401_gen_type [211] = Y2401_pgtype211;
	Y2401_gen_type [212] = Y2401_pgtype212;
	Y2401_gen_type [213] = Y2401_pgtype213;
	Y2401_gen_type [214] = Y2401_pgtype214;
	Y2401_gen_type [215] = Y2401_pgtype215;
	Y2401_gen_type [216] = Y2401_pgtype216;
	Y2401_gen_type [217] = Y2401_pgtype217;
	Y2401_gen_type [218] = Y2401_pgtype218;
	Y2401_gen_type [219] = Y2401_pgtype219;
	Y2401_gen_type [220] = Y2401_pgtype220;
	Y2401_gen_type [221] = Y2401_pgtype221;
	Y2401_gen_type [222] = Y2401_pgtype222;
	Y2401_gen_type [223] = Y2401_pgtype223;
	Y2401_gen_type [224] = Y2401_pgtype224;
	Y2401_gen_type [225] = Y2401_pgtype225;
	Y2401_gen_type [226] = Y2401_pgtype226;
	Y2401_gen_type [227] = Y2401_pgtype227;
	Y2401_gen_type [228] = Y2401_pgtype228;
	Y2401_gen_type [229] = Y2401_pgtype229;
	Y2401_gen_type [230] = Y2401_pgtype230;
	Y2401_gen_type [231] = Y2401_pgtype231;
	Y2401_gen_type [232] = Y2401_pgtype232;
	Y2401_gen_type [233] = Y2401_pgtype233;
	Y2401_gen_type [234] = Y2401_pgtype234;
	Y2401_gen_type [235] = Y2401_pgtype235;
	Y2401_gen_type [236] = Y2401_pgtype236;
	Y2401_gen_type [237] = Y2401_pgtype237;
	Y2401_gen_type [238] = Y2401_pgtype238;
	Y2401_gen_type [239] = Y2401_pgtype239;
	Y2401_gen_type [240] = Y2401_pgtype240;
	Y2401_gen_type [241] = Y2401_pgtype241;
	Y2401_gen_type [242] = Y2401_pgtype242;
	Y2401_gen_type [243] = Y2401_pgtype243;
	Y2401_gen_type [244] = Y2401_pgtype244;
	Y2401_gen_type [245] = Y2401_pgtype245;
	Y2401_gen_type [246] = Y2401_pgtype246;
	Y2401_gen_type [247] = Y2401_pgtype247;
	Y2401_gen_type [248] = Y2401_pgtype248;
	Y2401_gen_type [249] = Y2401_pgtype249;
	Y2401_gen_type [250] = Y2401_pgtype250;
	Y2401_gen_type [251] = Y2401_pgtype251;
	Y2401_gen_type [252] = Y2401_pgtype252;
	Y2401_gen_type [253] = Y2401_pgtype253;
	Y2401_gen_type [254] = Y2401_pgtype254;
	Y2401_gen_type [255] = Y2401_pgtype255;
	Y2401_gen_type [256] = Y2401_pgtype256;
	Y2401_gen_type [257] = Y2401_pgtype257;
	Y2401_gen_type [258] = Y2401_pgtype258;
	Y2401_gen_type [259] = Y2401_pgtype259;
	Y2401_gen_type [260] = Y2401_pgtype260;
	Y2401_gen_type [261] = Y2401_pgtype261;
	Y2401_gen_type [262] = Y2401_pgtype262;
	Y2401_gen_type [263] = Y2401_pgtype263;
	Y2401_gen_type [264] = Y2401_pgtype264;
	Y2401_gen_type [265] = Y2401_pgtype265;
	Y2401_gen_type [266] = Y2401_pgtype266;
	Y2401_gen_type [267] = Y2401_pgtype267;
	Y2401_gen_type [268] = Y2401_pgtype268;
	Y2401_gen_type [269] = Y2401_pgtype269;
	Y2401_gen_type [270] = Y2401_pgtype270;
	Y2401_gen_type [271] = Y2401_pgtype271;
	Y2401_gen_type [272] = Y2401_pgtype272;
	Y2401_gen_type [273] = Y2401_pgtype273;
	Y2401_gen_type [274] = Y2401_pgtype274;
	Y2401_gen_type [275] = Y2401_pgtype275;
	Y2401_gen_type [276] = Y2401_pgtype276;
	Y2401_gen_type [277] = Y2401_pgtype277;
	Y2401_gen_type [278] = Y2401_pgtype278;
	Y2401_gen_type [279] = Y2401_pgtype279;
	Y2401_gen_type [280] = Y2401_pgtype280;
	Y2401_gen_type [281] = Y2401_pgtype281;
	Y2401_gen_type [282] = Y2401_pgtype282;
	Y2401_gen_type [283] = Y2401_pgtype283;
	Y2401_gen_type [284] = Y2401_pgtype284;
	Y2401_gen_type [285] = Y2401_pgtype285;
	Y2401_gen_type [286] = Y2401_pgtype286;
	Y2401_gen_type [287] = Y2401_pgtype287;
	Y2401_gen_type [288] = Y2401_pgtype288;
	Y2401_gen_type [289] = Y2401_pgtype289;
	Y2401_gen_type [290] = Y2401_pgtype290;
	Y2401_gen_type [291] = Y2401_pgtype291;
	Y2401_gen_type [292] = Y2401_pgtype292;
	Y2401_gen_type [293] = Y2401_pgtype293;
	Y2401_gen_type [294] = Y2401_pgtype294;
	Y2401_gen_type [295] = Y2401_pgtype295;
	Y2401_gen_type [296] = Y2401_pgtype296;
	Y2401_gen_type [297] = Y2401_pgtype297;
	Y2401_gen_type [298] = Y2401_pgtype298;
	Y2401_gen_type [299] = Y2401_pgtype299;
	Y2401_gen_type [300] = Y2401_pgtype300;
	Y2401_gen_type [301] = Y2401_pgtype301;
	Y2401_gen_type [302] = Y2401_pgtype302;
	Y2401_gen_type [303] = Y2401_pgtype303;
	Y2401_gen_type [304] = Y2401_pgtype304;
	Y2401_gen_type [305] = Y2401_pgtype305;
	Y2401_gen_type [306] = Y2401_pgtype306;
	Y2401_gen_type [307] = Y2401_pgtype307;
	Y2401_gen_type [308] = Y2401_pgtype308;
	Y2401_gen_type [309] = Y2401_pgtype309;
	Y2401_gen_type [310] = Y2401_pgtype310;
	Y2401_gen_type [311] = Y2401_pgtype311;
	Y2401_gen_type [312] = Y2401_pgtype312;
	Y2401_gen_type [313] = Y2401_pgtype313;
	Y2401_gen_type [314] = Y2401_pgtype314;
	Y2401_gen_type [315] = Y2401_pgtype315;
	Y2401_gen_type [316] = Y2401_pgtype316;
	Y2401_gen_type [317] = Y2401_pgtype317;
	Y2401_gen_type [318] = Y2401_pgtype318;
	Y2401_gen_type [319] = Y2401_pgtype319;
	Y2401_gen_type [320] = Y2401_pgtype320;
	Y2401_gen_type [321] = Y2401_pgtype321;
	Y2401_gen_type [322] = Y2401_pgtype322;
	Y2401_gen_type [323] = Y2401_pgtype323;
	Y2401_gen_type [324] = Y2401_pgtype324;
	Y2401_gen_type [325] = Y2401_pgtype325;
	Y2401_gen_type [326] = Y2401_pgtype326;
	Y2401_gen_type [327] = Y2401_pgtype327;
	Y2401_gen_type [328] = Y2401_pgtype328;
	Y2401_gen_type [329] = Y2401_pgtype329;
	Y2401_gen_type [330] = Y2401_pgtype330;
	Y2401_gen_type [331] = Y2401_pgtype331;
	Y2401_gen_type [332] = Y2401_pgtype332;
	Y2401_gen_type [333] = Y2401_pgtype333;
	Y2401_gen_type [334] = Y2401_pgtype334;
	Y2401_gen_type [335] = Y2401_pgtype335;
	Y2401_gen_type [336] = Y2401_pgtype336;
	Y2401_gen_type [337] = Y2401_pgtype337;
	Y2401_gen_type [338] = Y2401_pgtype338;
	Y2401_gen_type [339] = Y2401_pgtype339;
	Y2401_gen_type [340] = Y2401_pgtype340;
	Y2401_gen_type [341] = Y2401_pgtype341;
	Y2401_gen_type [342] = Y2401_pgtype342;
	Y2401_gen_type [343] = Y2401_pgtype343;
	Y2401_gen_type [344] = Y2401_pgtype344;
	Y2401_gen_type [345] = Y2401_pgtype345;
	Y2401_gen_type [346] = Y2401_pgtype346;
	Y2401_gen_type [347] = Y2401_pgtype347;
	Y2401_gen_type [348] = Y2401_pgtype348;
	Y2401_gen_type [349] = Y2401_pgtype349;
	Y2401_gen_type [350] = Y2401_pgtype350;
	Y2401_gen_type [351] = Y2401_pgtype351;
	Y2401_gen_type [352] = Y2401_pgtype352;
	Y2401_gen_type [353] = Y2401_pgtype353;
	Y2401_gen_type [354] = Y2401_pgtype354;
	Y2401_gen_type [355] = Y2401_pgtype355;
	Y2401_gen_type [356] = Y2401_pgtype356;
	Y2401_gen_type [357] = Y2401_pgtype357;
	Y2401_gen_type [358] = Y2401_pgtype358;
	Y2401_gen_type [359] = Y2401_pgtype359;
	Y2401_gen_type [360] = Y2401_pgtype360;
	Y2401_gen_type [361] = Y2401_pgtype361;
	Y2401_gen_type [362] = Y2401_pgtype362;
	Y2401_gen_type [363] = Y2401_pgtype363;
	Y2401_gen_type [364] = Y2401_pgtype364;
	Y2401_gen_type [365] = Y2401_pgtype365;
	Y2401_gen_type [366] = Y2401_pgtype366;
	Y2401_gen_type [367] = Y2401_pgtype367;
	Y2401_gen_type [368] = Y2401_pgtype368;
	Y2401_gen_type [369] = Y2401_pgtype369;
	Y2401_gen_type [370] = Y2401_pgtype370;
	Y2401_gen_type [371] = Y2401_pgtype371;
	Y2401_gen_type [372] = Y2401_pgtype372;
	Y2401_gen_type [373] = Y2401_pgtype373;
	Y2401_gen_type [374] = Y2401_pgtype374;
	Y2401_gen_type [375] = Y2401_pgtype375;
	Y2401_gen_type [376] = Y2401_pgtype376;
	Y2401_gen_type [377] = Y2401_pgtype377;
	Y2401_gen_type [378] = Y2401_pgtype378;
	Y2401_gen_type [379] = Y2401_pgtype379;
	Y2401_gen_type [380] = Y2401_pgtype380;
	Y2401_gen_type [381] = Y2401_pgtype381;
	Y2401_gen_type [382] = Y2401_pgtype382;
	Y2401_gen_type [383] = Y2401_pgtype383;
	Y2401_gen_type [384] = Y2401_pgtype384;
	Y2401_gen_type [385] = Y2401_pgtype385;
	Y2401_gen_type [386] = Y2401_pgtype386;
	Y2401_gen_type [387] = Y2401_pgtype387;
	Y2401_gen_type [388] = Y2401_pgtype388;
	Y2401_gen_type [389] = Y2401_pgtype389;
	Y2401_gen_type [390] = Y2401_pgtype390;
	Y2401_gen_type [391] = Y2401_pgtype391;
	Y2401_gen_type [392] = Y2401_pgtype392;
	Y2401_gen_type [393] = Y2401_pgtype393;
	Y2401_gen_type [394] = Y2401_pgtype394;
	Y2401_gen_type [395] = Y2401_pgtype395;
	Y2401_gen_type [396] = Y2401_pgtype396;
	Y2401_gen_type [397] = Y2401_pgtype397;
	Y2401_gen_type [398] = Y2401_pgtype398;
	Y2401_gen_type [399] = Y2401_pgtype399;
	Y2401_gen_type [400] = Y2401_pgtype400;
	Y2401_gen_type [401] = Y2401_pgtype401;
	Y2401_gen_type [402] = Y2401_pgtype402;
	Y2401_gen_type [403] = Y2401_pgtype403;
	Y2401_gen_type [404] = Y2401_pgtype404;
	Y2401_gen_type [405] = Y2401_pgtype405;
	Y2401_gen_type [406] = Y2401_pgtype406;
	Y2401_gen_type [407] = Y2401_pgtype407;
	Y2401_gen_type [408] = Y2401_pgtype408;
	Y2401_gen_type [409] = Y2401_pgtype409;
	Y2401_gen_type [410] = Y2401_pgtype410;
	Y2401_gen_type [411] = Y2401_pgtype411;
	Y2401_gen_type [412] = Y2401_pgtype412;
	Y2401_gen_type [421] = Y2401_pgtype413;
	Y2401_gen_type [422] = Y2401_pgtype414;
	Y2401_gen_type [423] = Y2401_pgtype415;
	Y2401_gen_type [424] = Y2401_pgtype416;
	Y2401_gen_type [425] = Y2401_pgtype417;
	Y2401_gen_type [426] = Y2401_pgtype418;
	Y2401_gen_type [427] = Y2401_pgtype419;
	Y2401_gen_type [428] = Y2401_pgtype420;
	Y2401_gen_type [429] = Y2401_pgtype421;
	Y2401_gen_type [430] = Y2401_pgtype422;
	Y2401_gen_type [431] = Y2401_pgtype423;
	Y2401_gen_type [432] = Y2401_pgtype424;
	Y2401_gen_type [433] = Y2401_pgtype425;
	Y2401_gen_type [435] = Y2401_pgtype426;
	Y2401_gen_type [436] = Y2401_pgtype427;
	Y2401_gen_type [437] = Y2401_pgtype428;
	Y2401_gen_type [438] = Y2401_pgtype429;
	Y2401_gen_type [439] = Y2401_pgtype430;
	Y2401_gen_type [440] = Y2401_pgtype431;
	Y2401_gen_type [441] = Y2401_pgtype432;
	Y2401_gen_type [442] = Y2401_pgtype433;
	Y2401_gen_type [447] = Y2401_pgtype434;
	Y2401_gen_type [448] = Y2401_pgtype435;
	Y2401_gen_type [449] = Y2401_pgtype436;
	Y2401_gen_type [450] = Y2401_pgtype437;
	Y2401_gen_type [451] = Y2401_pgtype438;
	Y2401_gen_type [452] = Y2401_pgtype439;
	Y2401_gen_type [453] = Y2401_pgtype440;
	Y2401_gen_type [454] = Y2401_pgtype441;
	Y2401_gen_type [455] = Y2401_pgtype442;
	Y2401_gen_type [456] = Y2401_pgtype443;
	Y2401_gen_type [457] = Y2401_pgtype444;
	Y2401_gen_type [458] = Y2401_pgtype445;
	Y2401_gen_type [574] = Y2401_pgtype446;
	Y2401_gen_type [655] = Y2401_pgtype447;
	Y2401_gen_type [656] = Y2401_pgtype448;
	Y2401_gen_type [657] = Y2401_pgtype449;
	Y2401_gen_type [658] = Y2401_pgtype450;
	Y2401_gen_type [659] = Y2401_pgtype451;
	Y2401_gen_type [660] = Y2401_pgtype452;
	Y2401_gen_type [661] = Y2401_pgtype453;
	Y2401_gen_type [662] = Y2401_pgtype454;
	Y2401[12] = 894;
	Y2401[13] = 897;
	Y2401[14] = 829;
	Y2401[88] = 832;
	Y2401[89] = 829;
	Y2401[256] = 844;
	{long i; for (i = 319; i < 322; i++) Y2401[i] = 832;};
	Y2401[346] = 844;
	Y2401[442] = 0;
	Y2401[574] = 0;
	{long i; for (i = 655; i < 659; i++) Y2401[i] = 832;};
	{long i; for (i = 659; i < 662; i++) Y2401[i] = 829;};
	Y2401[662] = 832;
}

char *(*R2454[32])();
void R2454_init () {
	{long i; for (i = 0; i < 2; i++) R2454[i] = (char *(*)()) F282_2739;}
	{long i; for (i = 2; i < 4; i++) R2454[i] = (char *(*)()) F283_2739;}
	R2454[4] = (char *(*)()) F291_2739;
	R2454[5] = (char *(*)()) F282_2739;
	R2454[6] = (char *(*)()) F283_2739;
	R2454[7] = (char *(*)()) F282_2739;
	R2454[20] = (char *(*)()) F302_2779;
	R2454[21] = (char *(*)()) F303_2779;
	R2454[22] = (char *(*)()) F304_2779;
	R2454[23] = (char *(*)()) F305_2779;
	R2454[24] = (char *(*)()) F306_2779;
	R2454[25] = (char *(*)()) F307_2779;
	R2454[26] = (char *(*)()) F308_2779;
	R2454[27] = (char *(*)()) F309_2779;
	R2454[28] = (char *(*)()) F310_2779;
	R2454[29] = (char *(*)()) F311_2779;
	R2454[30] = (char *(*)()) F312_2779;
	R2454[31] = (char *(*)()) F313_2779;
}

char *(*R2455[32])();
void R2455_init () {
	{long i; for (i = 0; i < 2; i++) R2455[i] = (char *(*)()) F282_2740;}
	{long i; for (i = 2; i < 4; i++) R2455[i] = (char *(*)()) F283_2740;}
	R2455[4] = (char *(*)()) F291_2740;
	R2455[5] = (char *(*)()) F282_2740;
	R2455[6] = (char *(*)()) F283_2740;
	R2455[7] = (char *(*)()) F282_2740;
	R2455[20] = (char *(*)()) F314_2798;
	R2455[21] = (char *(*)()) F315_2798;
	R2455[22] = (char *(*)()) F316_2798;
	R2455[23] = (char *(*)()) F317_2798;
	R2455[24] = (char *(*)()) F318_2798;
	R2455[25] = (char *(*)()) F319_2798;
	R2455[26] = (char *(*)()) F320_2798;
	R2455[27] = (char *(*)()) F321_2798;
	R2455[28] = (char *(*)()) F322_2798;
	R2455[29] = (char *(*)()) F323_2798;
	R2455[30] = (char *(*)()) F324_2798;
	R2455[31] = (char *(*)()) F325_2798;
}

char *(*R2463[8])();
void R2463_init () {
	{long i; for (i = 0; i < 2; i++) R2463[i] = (char *(*)()) F282_2751;}
	{long i; for (i = 2; i < 4; i++) R2463[i] = (char *(*)()) F283_2751;}
	R2463[4] = (char *(*)()) F291_2751;
	R2463[5] = (char *(*)()) F282_2751;
	R2463[6] = (char *(*)()) F283_2751;
	R2463[7] = (char *(*)()) F282_2751;
}

char *(*R2464[32])();
void R2464_init () {
	{long i; for (i = 0; i < 2; i++) R2464[i] = (char *(*)()) F282_2752;}
	{long i; for (i = 2; i < 4; i++) R2464[i] = (char *(*)()) F283_2752;}
	R2464[4] = (char *(*)()) F291_2752;
	R2464[5] = (char *(*)()) F282_2752;
	R2464[6] = (char *(*)()) F283_2752;
	R2464[7] = (char *(*)()) F282_2752;
	R2464[20] = (char *(*)()) F302_2789;
	R2464[21] = (char *(*)()) F303_2789;
	R2464[22] = (char *(*)()) F304_2789;
	R2464[23] = (char *(*)()) F305_2789;
	R2464[24] = (char *(*)()) F306_2789;
	R2464[25] = (char *(*)()) F307_2789;
	R2464[26] = (char *(*)()) F308_2789;
	R2464[27] = (char *(*)()) F309_2789;
	R2464[28] = (char *(*)()) F310_2789;
	R2464[29] = (char *(*)()) F311_2789;
	R2464[30] = (char *(*)()) F312_2789;
	R2464[31] = (char *(*)()) F313_2789;
}

char *(*R2466[8])();
void R2466_init () {
	{long i; for (i = 0; i < 2; i++) R2466[i] = (char *(*)()) F282_2756;}
	{long i; for (i = 2; i < 4; i++) R2466[i] = (char *(*)()) F283_2756;}
	R2466[4] = (char *(*)()) F291_2756;
	R2466[5] = (char *(*)()) F299_2767;
	R2466[6] = (char *(*)()) F300_2767;
	R2466[7] = (char *(*)()) F301_2773;
}

char *(*R2467[32])();
void R2467_init () {
	R2467[0] = (char *(*)()) F294_2764;
	R2467[1] = (char *(*)()) F295_2764;
	R2467[2] = (char *(*)()) F296_2764;
	R2467[3] = (char *(*)()) F297_2764;
	R2467[4] = (char *(*)()) F298_2764;
	R2467[5] = (char *(*)()) F299_2769;
	R2467[6] = (char *(*)()) F300_2769;
	R2467[7] = (char *(*)()) F301_2775;
	R2467[20] = (char *(*)()) F314_2801;
	R2467[21] = (char *(*)()) F315_2801;
	R2467[22] = (char *(*)()) F316_2801;
	R2467[23] = (char *(*)()) F317_2801;
	R2467[24] = (char *(*)()) F318_2801;
	R2467[25] = (char *(*)()) F319_2801;
	R2467[26] = (char *(*)()) F320_2801;
	R2467[27] = (char *(*)()) F321_2801;
	R2467[28] = (char *(*)()) F322_2801;
	R2467[29] = (char *(*)()) F323_2801;
	R2467[30] = (char *(*)()) F324_2801;
	R2467[31] = (char *(*)()) F325_2801;
}

char *(*R2469[8])();
void R2469_init () {
	{long i; for (i = 0; i < 2; i++) R2469[i] = (char *(*)()) F282_2737;}
	{long i; for (i = 2; i < 4; i++) R2469[i] = (char *(*)()) F283_2737;}
	R2469[4] = (char *(*)()) F291_2737;
	R2469[5] = (char *(*)()) F282_2737;
	R2469[6] = (char *(*)()) F283_2737;
	R2469[7] = (char *(*)()) F282_2737;
}

char *(*R2482[12])();
void R2482_init () {
	R2482[0] = (char *(*)()) F314_2802;
	R2482[1] = (char *(*)()) F315_2802;
	R2482[2] = (char *(*)()) F316_2802;
	R2482[3] = (char *(*)()) F317_2802;
	R2482[4] = (char *(*)()) F318_2802;
	R2482[5] = (char *(*)()) F319_2802;
	R2482[6] = (char *(*)()) F320_2802;
	R2482[7] = (char *(*)()) F321_2802;
	R2482[8] = (char *(*)()) F322_2802;
	R2482[9] = (char *(*)()) F323_2802;
	R2482[10] = (char *(*)()) F324_2802;
	R2482[11] = (char *(*)()) F325_2802;
}

char *(*R2484[12])();
void R2484_init () {
	R2484[0] = (char *(*)()) F314_2797;
	R2484[1] = (char *(*)()) F315_2797;
	R2484[2] = (char *(*)()) F316_2797;
	R2484[3] = (char *(*)()) F317_2797;
	R2484[4] = (char *(*)()) F318_2797;
	R2484[5] = (char *(*)()) F319_2797;
	R2484[6] = (char *(*)()) F320_2797;
	R2484[7] = (char *(*)()) F321_2797;
	R2484[8] = (char *(*)()) F322_2797;
	R2484[9] = (char *(*)()) F323_2797;
	R2484[10] = (char *(*)()) F324_2797;
	R2484[11] = (char *(*)()) F325_2797;
}

char *(*R2496[406])();
void R2496_init () {
	R2496[0] = (char *(*)()) F494_2921_2496_2;
	R2496[401] = (char *(*)()) F893_5698_2496_2;
	R2496[402] = (char *(*)()) F896_5836_2496_2;
	R2496[405] = (char *(*)()) F897_5895_2496_2;
}
static EIF_BOOLEAN F494_2921_2496_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F494_2921(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F893_5698_2496_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F893_5698(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F896_5836_2496_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F896_5836(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F897_5895_2496_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F897_5895(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R2497[407])();
void R2497_init () {
	R2497[0] = (char *(*)()) F491_2895;
	{long i; for (i = 64; i < 66; i++) R2497[i] = (char *(*)()) F499_2928;}
	R2497[91] = (char *(*)()) F495_2928;
	R2497[92] = (char *(*)()) F497_2928;
	R2497[93] = (char *(*)()) F496_2928;
	R2497[94] = (char *(*)()) F498_2928;
	R2497[95] = (char *(*)()) F499_2928;
	R2497[96] = (char *(*)()) F500_2928;
	R2497[97] = (char *(*)()) F501_2928;
	R2497[98] = (char *(*)()) F502_2928;
	R2497[99] = (char *(*)()) F503_2928;
	R2497[100] = (char *(*)()) F504_2928;
	R2497[101] = (char *(*)()) F505_2928;
	R2497[102] = (char *(*)()) F506_2928;
	R2497[153] = (char *(*)()) F495_2928;
	R2497[154] = (char *(*)()) F496_2928;
	R2497[156] = (char *(*)()) F495_2928;
	R2497[166] = (char *(*)()) F495_2928;
	R2497[167] = (char *(*)()) F497_2928;
	R2497[168] = (char *(*)()) F496_2928;
	R2497[169] = (char *(*)()) F498_2928;
	R2497[170] = (char *(*)()) F499_2928;
	R2497[171] = (char *(*)()) F500_2928;
	R2497[172] = (char *(*)()) F501_2928;
	R2497[173] = (char *(*)()) F502_2928;
	R2497[174] = (char *(*)()) F503_2928;
	R2497[175] = (char *(*)()) F504_2928;
	R2497[176] = (char *(*)()) F505_2928;
	R2497[177] = (char *(*)()) F506_2928;
	{long i; for (i = 179; i < 181; i++) R2497[i] = (char *(*)()) F495_2928;}
	{long i; for (i = 181; i < 183; i++) R2497[i] = (char *(*)()) F496_2928;}
	R2497[183] = (char *(*)()) F504_2928;
	R2497[184] = (char *(*)()) F495_2928;
	R2497[185] = (char *(*)()) F496_2928;
	R2497[186] = (char *(*)()) F495_2928;
	{long i; for (i = 401; i < 403; i++) R2497[i] = (char *(*)()) F499_2928;}
	R2497[405] = (char *(*)()) F498_2928;
	R2497[406] = (char *(*)()) F900_6067;
}

char *(*R2501[407])();
void R2501_init () {
	R2501[0] = (char *(*)()) F353_2830;
	{long i; for (i = 64; i < 66; i++) R2501[i] = (char *(*)()) F356_2830;}
	R2501[91] = (char *(*)()) F352_2830;
	R2501[92] = (char *(*)()) F354_2830;
	R2501[93] = (char *(*)()) F353_2830;
	R2501[94] = (char *(*)()) F355_2830;
	R2501[95] = (char *(*)()) F356_2830;
	R2501[96] = (char *(*)()) F357_2830;
	R2501[97] = (char *(*)()) F358_2830;
	R2501[98] = (char *(*)()) F359_2830;
	R2501[99] = (char *(*)()) F360_2830;
	R2501[100] = (char *(*)()) F361_2830;
	R2501[101] = (char *(*)()) F362_2830;
	R2501[102] = (char *(*)()) F363_2830;
	R2501[153] = (char *(*)()) F352_2830;
	R2501[154] = (char *(*)()) F353_2830;
	R2501[156] = (char *(*)()) F352_2830;
	R2501[166] = (char *(*)()) F352_2830;
	R2501[167] = (char *(*)()) F354_2830;
	R2501[168] = (char *(*)()) F353_2830;
	R2501[169] = (char *(*)()) F355_2830;
	R2501[170] = (char *(*)()) F356_2830;
	R2501[171] = (char *(*)()) F357_2830;
	R2501[172] = (char *(*)()) F358_2830;
	R2501[173] = (char *(*)()) F359_2830;
	R2501[174] = (char *(*)()) F360_2830;
	R2501[175] = (char *(*)()) F361_2830;
	R2501[176] = (char *(*)()) F362_2830;
	R2501[177] = (char *(*)()) F363_2830;
	{long i; for (i = 179; i < 181; i++) R2501[i] = (char *(*)()) F352_2830;}
	{long i; for (i = 181; i < 183; i++) R2501[i] = (char *(*)()) F353_2830;}
	R2501[183] = (char *(*)()) F361_2830;
	R2501[184] = (char *(*)()) F352_2830;
	R2501[185] = (char *(*)()) F353_2830;
	R2501[186] = (char *(*)()) F352_2830;
	{long i; for (i = 401; i < 403; i++) R2501[i] = (char *(*)()) F356_2830;}
	R2501[405] = (char *(*)()) F355_2830;
	R2501[406] = (char *(*)()) F356_2830;
}

char *(*R2505[407])();
void R2505_init () {
	R2505[0] = (char *(*)()) F493_2899_2505_1;
	{long i; for (i = 64; i < 66; i++) R2505[i] = (char *(*)()) F557_2966_2505_1;}
	R2505[153] = (char *(*)()) F647_3464;
	R2505[154] = (char *(*)()) F648_3464_2505_1;
	R2505[156] = (char *(*)()) F647_3464;
	R2505[166] = (char *(*)()) F660_3624;
	R2505[167] = (char *(*)()) F661_3624_2505_1;
	R2505[168] = (char *(*)()) F662_3624_2505_1;
	R2505[169] = (char *(*)()) F663_3624_2505_1;
	R2505[170] = (char *(*)()) F664_3624_2505_1;
	R2505[171] = (char *(*)()) F665_3624_2505_1;
	R2505[172] = (char *(*)()) F666_3624_2505_1;
	R2505[173] = (char *(*)()) F667_3624_2505_1;
	R2505[174] = (char *(*)()) F668_3624_2505_1;
	R2505[175] = (char *(*)()) F669_3624_2505_1;
	R2505[176] = (char *(*)()) F670_3624_2505_1;
	R2505[177] = (char *(*)()) F671_3624_2505_1;
	R2505[402] = (char *(*)()) F896_5833_2505_1;
	R2505[406] = (char *(*)()) F557_2966_2505_1;
}
static EIF_REFERENCE F493_2899_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F493_2899(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_2966_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F557_2966(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F648_3464_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F648_3464(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3624_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3624(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_5833_2505_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F896_5833(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2506[407])();
void R2506_init () {
	R2506[0] = (char *(*)()) F377_2849;
	{long i; for (i = 64; i < 66; i++) R2506[i] = (char *(*)()) F557_2987;}
	R2506[153] = (char *(*)()) F647_3475;
	R2506[154] = (char *(*)()) F648_3475;
	R2506[156] = (char *(*)()) F647_3475;
	R2506[166] = (char *(*)()) F597_3418;
	R2506[167] = (char *(*)()) F598_3418;
	R2506[168] = (char *(*)()) F599_3418;
	R2506[169] = (char *(*)()) F600_3418;
	R2506[170] = (char *(*)()) F601_3418;
	R2506[171] = (char *(*)()) F602_3418;
	R2506[172] = (char *(*)()) F603_3418;
	R2506[173] = (char *(*)()) F604_3418;
	R2506[174] = (char *(*)()) F605_3418;
	R2506[175] = (char *(*)()) F606_3418;
	R2506[176] = (char *(*)()) F607_3418;
	R2506[177] = (char *(*)()) F608_3418;
	R2506[402] = (char *(*)()) F392_2857;
	R2506[406] = (char *(*)()) F557_2987;
}

char *(*R2507[343])();
void R2507_init () {
	{long i; for (i = 0; i < 2; i++) R2507[i] = (char *(*)()) F557_3042;}
	R2507[89] = (char *(*)()) F647_3481;
	R2507[90] = (char *(*)()) F648_3481;
	R2507[92] = (char *(*)()) F647_3481;
	R2507[102] = (char *(*)()) F660_3650;
	R2507[103] = (char *(*)()) F661_3650;
	R2507[104] = (char *(*)()) F662_3650;
	R2507[105] = (char *(*)()) F663_3650;
	R2507[106] = (char *(*)()) F664_3650;
	R2507[107] = (char *(*)()) F665_3650;
	R2507[108] = (char *(*)()) F666_3650;
	R2507[109] = (char *(*)()) F667_3650;
	R2507[110] = (char *(*)()) F668_3650;
	R2507[111] = (char *(*)()) F669_3650;
	R2507[112] = (char *(*)()) F670_3650;
	R2507[113] = (char *(*)()) F671_3650;
	R2507[338] = (char *(*)()) F896_5839;
	R2507[342] = (char *(*)()) F557_3042;
}

char *(*R2513[407])();
void R2513_init () {
	R2513[0] = (char *(*)()) F377_2843_2513_4;
	{long i; for (i = 64; i < 66; i++) R2513[i] = (char *(*)()) F392_2860_2513_4;}
	R2513[153] = (char *(*)()) F388_2860;
	R2513[154] = (char *(*)()) F390_2860_2513_4;
	R2513[156] = (char *(*)()) F388_2860;
	R2513[166] = (char *(*)()) F660_3656;
	R2513[167] = (char *(*)()) F661_3656_2513_4;
	R2513[168] = (char *(*)()) F662_3656_2513_4;
	R2513[169] = (char *(*)()) F663_3656_2513_4;
	R2513[170] = (char *(*)()) F664_3656_2513_4;
	R2513[171] = (char *(*)()) F665_3656_2513_4;
	R2513[172] = (char *(*)()) F666_3656_2513_4;
	R2513[173] = (char *(*)()) F667_3656_2513_4;
	R2513[174] = (char *(*)()) F668_3656_2513_4;
	R2513[175] = (char *(*)()) F669_3656_2513_4;
	R2513[176] = (char *(*)()) F670_3656_2513_4;
	R2513[177] = (char *(*)()) F671_3656_2513_4;
	R2513[402] = (char *(*)()) F392_2860_2513_4;
	R2513[406] = (char *(*)()) F392_2860_2513_4;
}
static void F377_2843_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F377_2843(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F392_2860_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F392_2860(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F390_2860_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F390_2860(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F661_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_3656(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_3656(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F663_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_3656(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F664_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_3656(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F665_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_3656(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F666_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_3656(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F667_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_3656(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F668_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_3656(Current, *(EIF_BOOLEAN *)arg1);
}
static void F669_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_3656(Current, *(EIF_POINTER *)arg1);
}
static void F670_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_3656(Current, *(EIF_REAL_32 *)arg1);
}
static void F671_3656_2513_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_3656(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2514[407])();
void R2514_init () {
	R2514[0] = (char *(*)()) F493_2898;
	{long i; for (i = 64; i < 66; i++) R2514[i] = (char *(*)()) F557_2967;}
	R2514[153] = (char *(*)()) F647_3467;
	R2514[154] = (char *(*)()) F648_3467;
	R2514[156] = (char *(*)()) F647_3467;
	R2514[166] = (char *(*)()) F660_3629;
	R2514[167] = (char *(*)()) F661_3629;
	R2514[168] = (char *(*)()) F662_3629;
	R2514[169] = (char *(*)()) F663_3629;
	R2514[170] = (char *(*)()) F664_3629;
	R2514[171] = (char *(*)()) F665_3629;
	R2514[172] = (char *(*)()) F666_3629;
	R2514[173] = (char *(*)()) F667_3629;
	R2514[174] = (char *(*)()) F668_3629;
	R2514[175] = (char *(*)()) F669_3629;
	R2514[176] = (char *(*)()) F670_3629;
	R2514[177] = (char *(*)()) F671_3629;
	R2514[402] = (char *(*)()) F896_5834;
	R2514[406] = (char *(*)()) F557_2967;
}

char *(*R2517[407])();
void R2517_init () {
	R2517[0] = (char *(*)()) F377_2847;
	{long i; for (i = 64; i < 66; i++) R2517[i] = (char *(*)()) F380_2847;}
	R2517[153] = (char *(*)()) F376_2847;
	R2517[154] = (char *(*)()) F377_2847;
	R2517[156] = (char *(*)()) F376_2847;
	R2517[166] = (char *(*)()) F376_2847;
	R2517[167] = (char *(*)()) F378_2847;
	R2517[168] = (char *(*)()) F377_2847;
	R2517[169] = (char *(*)()) F379_2847;
	R2517[170] = (char *(*)()) F380_2847;
	R2517[171] = (char *(*)()) F381_2847;
	R2517[172] = (char *(*)()) F382_2847;
	R2517[173] = (char *(*)()) F383_2847;
	R2517[174] = (char *(*)()) F384_2847;
	R2517[175] = (char *(*)()) F385_2847;
	R2517[176] = (char *(*)()) F386_2847;
	R2517[177] = (char *(*)()) F387_2847;
	R2517[402] = (char *(*)()) F380_2847;
	R2517[406] = (char *(*)()) F380_2847;
}

char *(*R2518[407])();
void R2518_init () {
	R2518[0] = (char *(*)()) F493_2900;
	{long i; for (i = 64; i < 66; i++) R2518[i] = (char *(*)()) F557_2985;}
	R2518[153] = (char *(*)()) F647_3473;
	R2518[154] = (char *(*)()) F648_3473;
	R2518[156] = (char *(*)()) F647_3473;
	R2518[166] = (char *(*)()) F621_3442;
	R2518[167] = (char *(*)()) F622_3442;
	R2518[168] = (char *(*)()) F623_3442;
	R2518[169] = (char *(*)()) F624_3442;
	R2518[170] = (char *(*)()) F625_3442;
	R2518[171] = (char *(*)()) F626_3442;
	R2518[172] = (char *(*)()) F627_3442;
	R2518[173] = (char *(*)()) F628_3442;
	R2518[174] = (char *(*)()) F629_3442;
	R2518[175] = (char *(*)()) F630_3442;
	R2518[176] = (char *(*)()) F631_3442;
	R2518[177] = (char *(*)()) F632_3442;
	R2518[402] = (char *(*)()) F896_5838;
	R2518[406] = (char *(*)()) F557_2985;
}

char *(*R2519[25])();
void R2519_init () {
	R2519[0] = (char *(*)()) F647_3482;
	R2519[1] = (char *(*)()) F648_3482;
	R2519[3] = (char *(*)()) F649_3516;
	R2519[13] = (char *(*)()) F660_3651;
	R2519[14] = (char *(*)()) F661_3651;
	R2519[15] = (char *(*)()) F662_3651;
	R2519[16] = (char *(*)()) F663_3651;
	R2519[17] = (char *(*)()) F664_3651;
	R2519[18] = (char *(*)()) F665_3651;
	R2519[19] = (char *(*)()) F666_3651;
	R2519[20] = (char *(*)()) F667_3651;
	R2519[21] = (char *(*)()) F668_3651;
	R2519[22] = (char *(*)()) F669_3651;
	R2519[23] = (char *(*)()) F670_3651;
	R2519[24] = (char *(*)()) F671_3651;
}

char *(*R2520[407])();
void R2520_init () {
	R2520[0] = (char *(*)()) F493_2906;
	{long i; for (i = 64; i < 66; i++) R2520[i] = (char *(*)()) F557_3044;}
	R2520[153] = (char *(*)()) F647_3483;
	R2520[154] = (char *(*)()) F648_3483;
	R2520[156] = (char *(*)()) F649_3514;
	R2520[166] = (char *(*)()) F660_3652;
	R2520[167] = (char *(*)()) F661_3652;
	R2520[168] = (char *(*)()) F662_3652;
	R2520[169] = (char *(*)()) F663_3652;
	R2520[170] = (char *(*)()) F664_3652;
	R2520[171] = (char *(*)()) F665_3652;
	R2520[172] = (char *(*)()) F666_3652;
	R2520[173] = (char *(*)()) F667_3652;
	R2520[174] = (char *(*)()) F668_3652;
	R2520[175] = (char *(*)()) F669_3652;
	R2520[176] = (char *(*)()) F670_3652;
	R2520[177] = (char *(*)()) F671_3652;
	R2520[402] = (char *(*)()) F896_5842;
	R2520[406] = (char *(*)()) F557_3044;
}

char *(*R2521[343])();
void R2521_init () {
	{long i; for (i = 0; i < 2; i++) R2521[i] = (char *(*)()) F557_2986;}
	R2521[89] = (char *(*)()) F647_3474;
	R2521[90] = (char *(*)()) F648_3474;
	R2521[92] = (char *(*)()) F647_3474;
	R2521[102] = (char *(*)()) F621_3443;
	R2521[103] = (char *(*)()) F622_3443;
	R2521[104] = (char *(*)()) F623_3443;
	R2521[105] = (char *(*)()) F624_3443;
	R2521[106] = (char *(*)()) F625_3443;
	R2521[107] = (char *(*)()) F626_3443;
	R2521[108] = (char *(*)()) F627_3443;
	R2521[109] = (char *(*)()) F628_3443;
	R2521[110] = (char *(*)()) F629_3443;
	R2521[111] = (char *(*)()) F630_3443;
	R2521[112] = (char *(*)()) F631_3443;
	R2521[113] = (char *(*)()) F632_3443;
	R2521[338] = (char *(*)()) F896_5837;
	R2521[342] = (char *(*)()) F557_2986;
}

char *(*R2522[343])();
void R2522_init () {
	{long i; for (i = 0; i < 2; i++) R2522[i] = (char *(*)()) F557_3045;}
	R2522[92] = (char *(*)()) F649_3515;
	R2522[342] = (char *(*)()) F900_6037;
}

char *(*R2527[253])();
void R2527_init () {
	R2527[0] = (char *(*)()) F647_3489;
	R2527[1] = (char *(*)()) F648_3489_2527_4;
	R2527[3] = (char *(*)()) F650_3534;
	R2527[13] = (char *(*)()) F660_3660;
	R2527[14] = (char *(*)()) F661_3660_2527_4;
	R2527[15] = (char *(*)()) F662_3660_2527_4;
	R2527[16] = (char *(*)()) F663_3660_2527_4;
	R2527[17] = (char *(*)()) F664_3660_2527_4;
	R2527[18] = (char *(*)()) F665_3660_2527_4;
	R2527[19] = (char *(*)()) F666_3660_2527_4;
	R2527[20] = (char *(*)()) F667_3660_2527_4;
	R2527[21] = (char *(*)()) F668_3660_2527_4;
	R2527[22] = (char *(*)()) F669_3660_2527_4;
	R2527[23] = (char *(*)()) F670_3660_2527_4;
	R2527[24] = (char *(*)()) F671_3660_2527_4;
	{long i; for (i = 248; i < 250; i++) R2527[i] = (char *(*)()) F895_5790_2527_4;}
	R2527[252] = (char *(*)()) F899_5990_2527_4;
}
static void F648_3489_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F648_3489(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F661_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_3660(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F662_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_3660(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F663_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_3660(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F664_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_3660(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F665_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_3660(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F666_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_3660(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F667_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_3660(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F668_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_3660(Current, *(EIF_BOOLEAN *)arg1);
}
static void F669_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_3660(Current, *(EIF_POINTER *)arg1);
}
static void F670_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_3660(Current, *(EIF_REAL_32 *)arg1);
}
static void F671_3660_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_3660(Current, *(EIF_REAL_64 *)arg1);
}
static void F895_5790_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_5790(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F899_5990_2527_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_5990(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R2531[249])();
void R2531_init () {
	R2531[0] = (char *(*)()) F647_3498;
	R2531[1] = (char *(*)()) F648_3498;
	R2531[3] = (char *(*)()) F649_3527;
	R2531[13] = (char *(*)()) F660_3678;
	R2531[14] = (char *(*)()) F661_3678;
	R2531[15] = (char *(*)()) F662_3678;
	R2531[16] = (char *(*)()) F663_3678;
	R2531[17] = (char *(*)()) F664_3678;
	R2531[18] = (char *(*)()) F665_3678;
	R2531[19] = (char *(*)()) F666_3678;
	R2531[20] = (char *(*)()) F667_3678;
	R2531[21] = (char *(*)()) F668_3678;
	R2531[22] = (char *(*)()) F669_3678;
	R2531[23] = (char *(*)()) F670_3678;
	R2531[24] = (char *(*)()) F671_3678;
	R2531[26] = (char *(*)()) F673_3757;
	R2531[27] = (char *(*)()) F674_3757;
	R2531[28] = (char *(*)()) F675_3757;
	R2531[29] = (char *(*)()) F676_3757;
	R2531[30] = (char *(*)()) F677_3757;
	R2531[31] = (char *(*)()) F673_3757;
	R2531[32] = (char *(*)()) F675_3757;
	R2531[33] = (char *(*)()) F673_3757;
	R2531[248] = (char *(*)()) F895_5805;
}

char *(*R2534[315])();
void R2534_init () {
	R2534[0] = (char *(*)()) F585_3350_2534_5;
	R2534[1] = (char *(*)()) F586_3350_2534_5;
	R2534[2] = (char *(*)()) F587_3350_2534_5;
	R2534[3] = (char *(*)()) F588_3350_2534_5;
	R2534[4] = (char *(*)()) F589_3350_2534_5;
	R2534[5] = (char *(*)()) F590_3350_2534_5;
	R2534[6] = (char *(*)()) F591_3350_2534_5;
	R2534[7] = (char *(*)()) F592_3350_2534_5;
	R2534[8] = (char *(*)()) F593_3350_2534_5;
	R2534[9] = (char *(*)()) F594_3350_2534_5;
	R2534[10] = (char *(*)()) F595_3350_2534_5;
	R2534[11] = (char *(*)()) F596_3350_2534_5;
	R2534[62] = (char *(*)()) F597_3407_2534_5;
	R2534[63] = (char *(*)()) F599_3407_2534_5;
	R2534[65] = (char *(*)()) F597_3407_2534_5;
	R2534[75] = (char *(*)()) F660_3625_2534_5;
	R2534[76] = (char *(*)()) F661_3625_2534_5;
	R2534[77] = (char *(*)()) F662_3625_2534_5;
	R2534[78] = (char *(*)()) F663_3625_2534_5;
	R2534[79] = (char *(*)()) F664_3625_2534_5;
	R2534[80] = (char *(*)()) F665_3625_2534_5;
	R2534[81] = (char *(*)()) F666_3625_2534_5;
	R2534[82] = (char *(*)()) F667_3625_2534_5;
	R2534[83] = (char *(*)()) F668_3625_2534_5;
	R2534[84] = (char *(*)()) F669_3625_2534_5;
	R2534[85] = (char *(*)()) F670_3625_2534_5;
	R2534[86] = (char *(*)()) F671_3625_2534_5;
	{long i; for (i = 310; i < 312; i++) R2534[i] = (char *(*)()) F895_5742_2534_5;}
	R2534[314] = (char *(*)()) F899_5943_2534_5;
}
static EIF_REFERENCE F585_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_3350(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F586_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F586_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F587_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F588_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F589_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F591_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F592_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F593_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F594_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_3350_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_3350(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_3407_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F597_3407(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F599_3407_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F599_3407(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_3625(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F661_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(850, 0x00).id, 850, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F663_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F664_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F666_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F667_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F669_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F670_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3625_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F671_3625(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_5742_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F895_5742(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_5943_2534_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F899_5943(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R2537[312])();
void R2537_init () {
	R2537[0] = (char *(*)()) F585_3369_2537_9;
	R2537[1] = (char *(*)()) F586_3369_2537_9;
	R2537[2] = (char *(*)()) F587_3369_2537_9;
	R2537[3] = (char *(*)()) F588_3369_2537_9;
	R2537[4] = (char *(*)()) F589_3369_2537_9;
	R2537[5] = (char *(*)()) F590_3369_2537_9;
	R2537[6] = (char *(*)()) F591_3369_2537_9;
	R2537[7] = (char *(*)()) F592_3369_2537_9;
	R2537[8] = (char *(*)()) F593_3369_2537_9;
	R2537[9] = (char *(*)()) F594_3369_2537_9;
	R2537[10] = (char *(*)()) F595_3369_2537_9;
	R2537[11] = (char *(*)()) F596_3369_2537_9;
	R2537[88] = (char *(*)()) F673_3749;
	R2537[89] = (char *(*)()) F674_3749_2537_9;
	R2537[90] = (char *(*)()) F675_3749_2537_9;
	R2537[91] = (char *(*)()) F676_3749_2537_9;
	R2537[92] = (char *(*)()) F677_3749_2537_9;
	R2537[93] = (char *(*)()) F673_3749;
	R2537[94] = (char *(*)()) F675_3749_2537_9;
	R2537[95] = (char *(*)()) F673_3749;
	{long i; for (i = 310; i < 312; i++) R2537[i] = (char *(*)()) F895_5763_2537_9;}
}
static void F585_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_3369(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_3369(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_3369(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_3369(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_3369(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F590_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F590_3369(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F591_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F591_3369(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F592_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F592_3369(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F593_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F593_3369(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F594_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F594_3369(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F595_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F595_3369(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F596_3369_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F596_3369(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F674_3749_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F674_3749(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F675_3749_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F675_3749(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F676_3749_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F676_3749(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F677_3749_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F677_3749(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F895_5763_2537_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_5763(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2539_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype30[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype31[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype32[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype33[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype34[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype35[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype36[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype37[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype38[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype39[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype40[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype41[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype42[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype43[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype44[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype45[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype46[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype47[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype48[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype49[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype50[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype51[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype52[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype53[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype54[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype55[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype56[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype57[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype58[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype59[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype60[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype61[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype62[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype63[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype64[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype65[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype66[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype67[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype68[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype69[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype70[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype71[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype72[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype73[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype74[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype75[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype76[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype77[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype78[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype79[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype80[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype81[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype82[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype83[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype84[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype85[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype86[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype87[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype88[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype89[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype90[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype91[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype92[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype93[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype94[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype95[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype96[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype97[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype98[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype99[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype100[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype101[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype102[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype103[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype104[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype105[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype106[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype107[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype108[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype109[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype110[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype111[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype112[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype113[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype114[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype115[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype116[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype117[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype118[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype119[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype120[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype126[] = {889,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype127[] = {889,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype128[] = {894,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype129[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype130[] = {844,0xFFFF};
static EIF_TYPE_INDEX Y2539_pgtype131[] = {844,0xFFFF};
EIF_TYPE_INDEX *Y2539_gen_type [475];
EIF_TYPE_INDEX Y2539 [475];
void Y2539_init (void)
{
	egc_routines_types [2539] = Y2539;
	egc_routines_gen_types [2539] = Y2539_gen_type;
	egc_routines_offset [2539] = 424;
	Y2539_gen_type [0] = Y2539_pgtype0;
	Y2539_gen_type [1] = Y2539_pgtype1;
	Y2539_gen_type [2] = Y2539_pgtype2;
	Y2539_gen_type [3] = Y2539_pgtype3;
	Y2539_gen_type [4] = Y2539_pgtype4;
	Y2539_gen_type [5] = Y2539_pgtype5;
	Y2539_gen_type [6] = Y2539_pgtype6;
	Y2539_gen_type [7] = Y2539_pgtype7;
	Y2539_gen_type [8] = Y2539_pgtype8;
	Y2539_gen_type [9] = Y2539_pgtype9;
	Y2539_gen_type [10] = Y2539_pgtype10;
	Y2539_gen_type [11] = Y2539_pgtype11;
	Y2539_gen_type [12] = Y2539_pgtype12;
	Y2539_gen_type [13] = Y2539_pgtype13;
	Y2539_gen_type [14] = Y2539_pgtype14;
	Y2539_gen_type [15] = Y2539_pgtype15;
	Y2539_gen_type [16] = Y2539_pgtype16;
	Y2539_gen_type [17] = Y2539_pgtype17;
	Y2539_gen_type [18] = Y2539_pgtype18;
	Y2539_gen_type [19] = Y2539_pgtype19;
	Y2539_gen_type [20] = Y2539_pgtype20;
	Y2539_gen_type [21] = Y2539_pgtype21;
	Y2539_gen_type [22] = Y2539_pgtype22;
	Y2539_gen_type [23] = Y2539_pgtype23;
	Y2539_gen_type [24] = Y2539_pgtype24;
	Y2539_gen_type [25] = Y2539_pgtype25;
	Y2539_gen_type [26] = Y2539_pgtype26;
	Y2539_gen_type [27] = Y2539_pgtype27;
	Y2539_gen_type [28] = Y2539_pgtype28;
	Y2539_gen_type [29] = Y2539_pgtype29;
	Y2539_gen_type [147] = Y2539_pgtype30;
	Y2539_gen_type [148] = Y2539_pgtype31;
	Y2539_gen_type [149] = Y2539_pgtype32;
	Y2539_gen_type [150] = Y2539_pgtype33;
	Y2539_gen_type [151] = Y2539_pgtype34;
	Y2539_gen_type [152] = Y2539_pgtype35;
	Y2539_gen_type [153] = Y2539_pgtype36;
	Y2539_gen_type [154] = Y2539_pgtype37;
	Y2539_gen_type [155] = Y2539_pgtype38;
	Y2539_gen_type [156] = Y2539_pgtype39;
	Y2539_gen_type [157] = Y2539_pgtype40;
	Y2539_gen_type [158] = Y2539_pgtype41;
	Y2539_gen_type [159] = Y2539_pgtype42;
	Y2539_gen_type [160] = Y2539_pgtype43;
	Y2539_gen_type [161] = Y2539_pgtype44;
	Y2539_gen_type [162] = Y2539_pgtype45;
	Y2539_gen_type [163] = Y2539_pgtype46;
	Y2539_gen_type [164] = Y2539_pgtype47;
	Y2539_gen_type [165] = Y2539_pgtype48;
	Y2539_gen_type [166] = Y2539_pgtype49;
	Y2539_gen_type [167] = Y2539_pgtype50;
	Y2539_gen_type [168] = Y2539_pgtype51;
	Y2539_gen_type [169] = Y2539_pgtype52;
	Y2539_gen_type [170] = Y2539_pgtype53;
	Y2539_gen_type [171] = Y2539_pgtype54;
	Y2539_gen_type [172] = Y2539_pgtype55;
	Y2539_gen_type [173] = Y2539_pgtype56;
	Y2539_gen_type [174] = Y2539_pgtype57;
	Y2539_gen_type [175] = Y2539_pgtype58;
	Y2539_gen_type [176] = Y2539_pgtype59;
	Y2539_gen_type [177] = Y2539_pgtype60;
	Y2539_gen_type [178] = Y2539_pgtype61;
	Y2539_gen_type [179] = Y2539_pgtype62;
	Y2539_gen_type [180] = Y2539_pgtype63;
	Y2539_gen_type [181] = Y2539_pgtype64;
	Y2539_gen_type [182] = Y2539_pgtype65;
	Y2539_gen_type [183] = Y2539_pgtype66;
	Y2539_gen_type [184] = Y2539_pgtype67;
	Y2539_gen_type [185] = Y2539_pgtype68;
	Y2539_gen_type [186] = Y2539_pgtype69;
	Y2539_gen_type [187] = Y2539_pgtype70;
	Y2539_gen_type [188] = Y2539_pgtype71;
	Y2539_gen_type [189] = Y2539_pgtype72;
	Y2539_gen_type [190] = Y2539_pgtype73;
	Y2539_gen_type [191] = Y2539_pgtype74;
	Y2539_gen_type [192] = Y2539_pgtype75;
	Y2539_gen_type [193] = Y2539_pgtype76;
	Y2539_gen_type [194] = Y2539_pgtype77;
	Y2539_gen_type [195] = Y2539_pgtype78;
	Y2539_gen_type [196] = Y2539_pgtype79;
	Y2539_gen_type [197] = Y2539_pgtype80;
	Y2539_gen_type [198] = Y2539_pgtype81;
	Y2539_gen_type [199] = Y2539_pgtype82;
	Y2539_gen_type [200] = Y2539_pgtype83;
	Y2539_gen_type [201] = Y2539_pgtype84;
	Y2539_gen_type [202] = Y2539_pgtype85;
	Y2539_gen_type [203] = Y2539_pgtype86;
	Y2539_gen_type [204] = Y2539_pgtype87;
	Y2539_gen_type [205] = Y2539_pgtype88;
	Y2539_gen_type [206] = Y2539_pgtype89;
	Y2539_gen_type [207] = Y2539_pgtype90;
	Y2539_gen_type [208] = Y2539_pgtype91;
	Y2539_gen_type [209] = Y2539_pgtype92;
	Y2539_gen_type [210] = Y2539_pgtype93;
	Y2539_gen_type [211] = Y2539_pgtype94;
	Y2539_gen_type [212] = Y2539_pgtype95;
	Y2539_gen_type [213] = Y2539_pgtype96;
	Y2539_gen_type [214] = Y2539_pgtype97;
	Y2539_gen_type [215] = Y2539_pgtype98;
	Y2539_gen_type [216] = Y2539_pgtype99;
	Y2539_gen_type [217] = Y2539_pgtype100;
	Y2539_gen_type [218] = Y2539_pgtype101;
	Y2539_gen_type [219] = Y2539_pgtype102;
	Y2539_gen_type [220] = Y2539_pgtype103;
	Y2539_gen_type [221] = Y2539_pgtype104;
	Y2539_gen_type [222] = Y2539_pgtype105;
	Y2539_gen_type [223] = Y2539_pgtype106;
	Y2539_gen_type [224] = Y2539_pgtype107;
	Y2539_gen_type [225] = Y2539_pgtype108;
	Y2539_gen_type [235] = Y2539_pgtype109;
	Y2539_gen_type [236] = Y2539_pgtype110;
	Y2539_gen_type [237] = Y2539_pgtype111;
	Y2539_gen_type [238] = Y2539_pgtype112;
	Y2539_gen_type [239] = Y2539_pgtype113;
	Y2539_gen_type [240] = Y2539_pgtype114;
	Y2539_gen_type [241] = Y2539_pgtype115;
	Y2539_gen_type [242] = Y2539_pgtype116;
	Y2539_gen_type [243] = Y2539_pgtype117;
	Y2539_gen_type [244] = Y2539_pgtype118;
	Y2539_gen_type [245] = Y2539_pgtype119;
	Y2539_gen_type [246] = Y2539_pgtype120;
	Y2539_gen_type [248] = Y2539_pgtype121;
	Y2539_gen_type [249] = Y2539_pgtype122;
	Y2539_gen_type [250] = Y2539_pgtype123;
	Y2539_gen_type [251] = Y2539_pgtype124;
	Y2539_gen_type [252] = Y2539_pgtype125;
	Y2539_gen_type [253] = Y2539_pgtype126;
	Y2539_gen_type [254] = Y2539_pgtype127;
	Y2539_gen_type [255] = Y2539_pgtype128;
	Y2539_gen_type [470] = Y2539_pgtype129;
	Y2539_gen_type [471] = Y2539_pgtype130;
	Y2539_gen_type [474] = Y2539_pgtype131;
	{long i; for (i = 147; i < 226; i++) Y2539[i] = 844;};
	{long i; for (i = 235; i < 247; i++) Y2539[i] = 844;};
	{long i; for (i = 253; i < 255; i++) Y2539[i] = 889;};
	Y2539[255] = 894;
	{long i; for (i = 470; i < 472; i++) Y2539[i] = 844;};
	Y2539[474] = 844;
}


#ifdef __cplusplus
}
#endif
