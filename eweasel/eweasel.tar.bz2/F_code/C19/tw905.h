
#ifndef _C19_tw905_
#define _C19_tw905_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F301_2771(EIF_REFERENCE);
extern EIF_BOOLEAN F301_2772(EIF_REFERENCE);
extern void F301_2773(EIF_REFERENCE);
extern void F301_2774(EIF_REFERENCE);
extern EIF_REFERENCE F301_2775(EIF_REFERENCE);
extern void EIF_Minit905(void);
extern EIF_BOOLEAN F282_2751(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
