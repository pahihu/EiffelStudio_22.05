
#ifndef _C19_pa911_
#define _C19_pa911_

#ifdef __cplusplus
extern "C" {
#endif

extern void F633_3446(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit911(void);
extern EIF_REFERENCE F647_3464(EIF_REFERENCE);
extern void F649_3514(EIF_REFERENCE);
extern void F647_3481(EIF_REFERENCE);
extern char *(*R1465[])();
extern long O2869[];

#ifdef __cplusplus
}
#endif

#endif
