/*
 * Code for class TWO_WAY_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "tw906.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TWO_WAY_LIST}.last_element */
EIF_REFERENCE F649_3509 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {TWO_WAY_LIST}.cursor */
EIF_REFERENCE F649_3511 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("cursor", 648, Current, 0, 0, 5884);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {114,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y2401,Y2401_gen_type,Dftype(Current),237);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 114, _OBJSIZ_1_2_0_0_0_0_0_0_);
	}
	F113_1465(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_), *(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {TWO_WAY_LIST}.new_cursor */
EIF_REFERENCE F649_3512 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 648, Current, 0, 0, 5885);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {300,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y2401,Y2401_gen_type,Dftype(Current),237);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 300, _OBJSIZ_2_1_0_5_0_0_0_0_);
	}
	F282_2737(RTCW(Result), Current);
	RTHOOK(2);
	F301_2773(RTCW(Result));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {TWO_WAY_LIST}.islast */
EIF_BOOLEAN F649_3513 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("islast", 648, Current, 0, 0, 5886);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == *(EIF_REFERENCE *)(Current + _REFACS_3_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_));
}

/* {TWO_WAY_LIST}.forth */
void F649_3514 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("forth", 648, Current, 1, 0, 5887);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		if (F495_2928(Current)) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		RTHOOK(5);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			loc1 = (EIF_REFERENCE) tr1;
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				RTHOOK(10);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(11);
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.back */
void F649_3515 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("back", 648, Current, 1, 0, 5888);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		if (F495_2928(Current)) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		RTHOOK(5);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
			loc1 = (EIF_REFERENCE) tr1;
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				RTHOOK(10);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(11);
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.finish */
void F649_3516 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("finish", 648, Current, 0, 0, 5889);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F495_2928(Current)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.move */
void F649_3517 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("move", 648, Current, 2, 1, 5890);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		F647_3485(Current, arg1);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) {
				RTHOOK(5);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(6);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			}
			RTHOOK(7);
			loc2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg1) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
				loc2 = (EIF_REFERENCE) tr1;
				RTHOOK(10);
				loc1--;
			}
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(12);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(13);
				tr1 = *(EIF_REFERENCE *)(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			} else {
				RTHOOK(14);
				RTAR(Current, loc2);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc2;
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.put_left */
void F649_3520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("put_left", 648, Current, 2, 1, 5893);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	loc1 = F649_3532(Current, tr1);
	RTHOOK(2);
	if (F495_2928(Current)) {
		RTHOOK(3);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(7);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) {
			RTHOOK(8);
			F49_624(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
			RTHOOK(9);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
			RTHOOK(10);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		} else {
			RTHOOK(11);
			if (F647_3476(Current)) {
				RTHOOK(12);
				F49_623(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
				RTHOOK(13);
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
			} else {
				RTHOOK(14);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(16);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
					F49_624(RTCW(loc1), tr1);
				}
				RTHOOK(17);
				F49_623(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
			}
		}
	}
	RTHOOK(18);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_))++;
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.merge_right */
void F649_3523 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("merge_right", 648, Current, 0, 1, 5896);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	if (!F495_2928(Current)) {
		tb1 = F649_3513(Current);
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	F647_3494(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.remove */
void F649_3524 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTEAA("remove", 648, Current, 4, 0, 5897);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if (F647_3476(Current)) {
		RTHOOK(3);
		loc4 = *(EIF_REFERENCE *)(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			RTHOOK(6);
			F49_625(RTCW(loc4));
		}
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(8);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_) == ((EIF_INTEGER_32) 1L))) {
			
			RTHOOK(10);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(11);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		}
	} else {
		RTHOOK(12);
		if (F649_3513(Current)) {
			RTHOOK(13);
			loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			RTHOOK(14);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				RTHOOK(16);
				F49_626(RTCW(loc4));
			}
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			RTHOOK(18);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(19);
			loc4 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			RTHOOK(20);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTHOOK(21);
				loc2 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
				RTHOOK(22);
				loc1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			}
			RTHOOK(23);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
				RTHOOK(24);
				F49_625(RTCW(loc2));
				RTHOOK(25);
				F49_626(RTCW(loc1));
				RTHOOK(26);
				F49_623(RTCW(loc2), loc1);
			}
			RTHOOK(27);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(28);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_))--;
	RTHOOK(29);
	{
		/* INLINED CODE (LINKED_LIST.cleanup_after_remove) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(30);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.wipe_out */
void F649_3527 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wipe_out", 648, Current, 0, 0, 5900);
	RTGC;
	RTHOOK(1);
	F647_3498(Current);
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {TWO_WAY_LIST}.new_cell */
EIF_REFERENCE F649_3532 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("new_cell", 648, Current, 0, 1, 5905);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {48,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y2401,Y2401_gen_type,Dftype(Current),237);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 48, _OBJSIZ_3_0_0_0_0_0_0_0_);
	}
	tr1 = RTCCL(arg1);
	F43_617(RTCW(Result), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit906 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
