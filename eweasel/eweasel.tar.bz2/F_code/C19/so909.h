
#ifndef _C19_so909_
#define _C19_so909_

#ifdef __cplusplus
extern "C" {
#endif

extern void F650_3534(EIF_REFERENCE, EIF_REFERENCE);
extern void F650_3536(EIF_REFERENCE);
extern void EIF_Minit909(void);
extern void F43_617(EIF_REFERENCE, EIF_REFERENCE);
extern void F647_3486(EIF_REFERENCE, EIF_INTEGER_32);
extern void F649_3520(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_3515(EIF_REFERENCE);
extern void F633_3446(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F495_2928(EIF_REFERENCE);
extern char *(*R1464[])();

#ifdef __cplusplus
}
#endif

#endif
