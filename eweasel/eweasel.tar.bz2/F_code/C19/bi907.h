
#ifndef _C19_bi907_
#define _C19_bi907_

#ifdef __cplusplus
extern "C" {
#endif

extern void F49_623(EIF_REFERENCE, EIF_REFERENCE);
extern void F49_624(EIF_REFERENCE, EIF_REFERENCE);
extern void F49_625(EIF_REFERENCE);
extern void F49_626(EIF_REFERENCE);
extern void F49_627(EIF_REFERENCE, EIF_REFERENCE);
extern void F49_628(EIF_REFERENCE, EIF_REFERENCE);
extern void F49_629(EIF_REFERENCE);
extern void F49_630(EIF_REFERENCE);
extern void EIF_Minit907(void);

#ifdef __cplusplus
}
#endif

#endif
