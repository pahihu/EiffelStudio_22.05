/*
 * Code for class PART_SORTED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa911.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PART_SORTED_LIST}.search_after */
void F633_3446 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("search_after", 632, Current, 0, 1, 5733);
	RTGC;
	RTHOOK(1);
	F647_3481(Current);
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current + O2869[Dtype(Current)-646])) {
			tr1 = F647_3464(Current);
			tr2 = RTCCL(tr1);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1465[Dtype(RTCW(arg1))-170])(arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(3);
		F649_3514(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit911 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
