
#ifndef _C19_ha900_
#define _C19_ha900_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F298_2759(EIF_REFERENCE);
extern EIF_REFERENCE F298_2760(EIF_REFERENCE);
extern EIF_BOOLEAN F298_2762(EIF_REFERENCE);
extern void F298_2763(EIF_REFERENCE);
extern EIF_REFERENCE F298_2764(EIF_REFERENCE);
extern void EIF_Minit900(void);
extern EIF_INTEGER_32 F677_3748(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F677_3747(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F291_2751(EIF_REFERENCE);
extern char *(*R3143[])();
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
