
#ifndef _C10_ge460_
#define _C10_ge460_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F304_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F304_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F304_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F304_2789(EIF_REFERENCE);
extern void F304_2792(EIF_REFERENCE);
extern void EIF_Minit460(void);

#ifdef __cplusplus
}
#endif

#endif
