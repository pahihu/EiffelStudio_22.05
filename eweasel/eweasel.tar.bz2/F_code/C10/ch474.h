
#ifndef _C10_ch474_
#define _C10_ch474_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F599_3407(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F599_3410(EIF_REFERENCE);
extern EIF_BOOLEAN F599_3415(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F599_3417(EIF_REFERENCE);
extern EIF_BOOLEAN F599_3418(EIF_REFERENCE);
extern void F599_3422(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit474(void);
extern EIF_BOOLEAN F377_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F496_2928(EIF_REFERENCE);
extern char *(*R2541[])();
extern char *(*R2547[])();
extern char *(*R2549[])();
extern char *(*R2507[])();
extern char *(*R2514[])();
extern char *(*R2519[])();
extern char *(*R2561[])();
extern char *(*R2520[])();
extern char *(*R2836[])();
extern char *(*R2527[])();

#ifdef __cplusplus
}
#endif

#endif
