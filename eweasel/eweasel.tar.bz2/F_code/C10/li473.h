
#ifndef _C10_li473_
#define _C10_li473_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F623_3441(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F623_3442(EIF_REFERENCE);
extern EIF_BOOLEAN F623_3443(EIF_REFERENCE);
extern void EIF_Minit473(void);
extern EIF_BOOLEAN F496_2928(EIF_REFERENCE);
extern char *(*R2541[])();
extern char *(*R2547[])();
extern char *(*R2549[])();
extern char *(*R2507[])();
extern char *(*R2514[])();
extern char *(*R2518[])();
extern char *(*R2561[])();
extern char *(*R2520[])();
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
