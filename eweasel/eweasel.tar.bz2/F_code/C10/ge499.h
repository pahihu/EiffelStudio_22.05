
#ifndef _C10_ge499_
#define _C10_ge499_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F305_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F305_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F305_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F305_2789(EIF_REFERENCE);
extern void F305_2792(EIF_REFERENCE);
extern void EIF_Minit499(void);

#ifdef __cplusplus
}
#endif

#endif
