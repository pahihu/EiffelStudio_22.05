
#ifndef _C10_to496_
#define _C10_to496_

#ifdef __cplusplus
extern "C" {
#endif

extern void F195_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F195_2351(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F195_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit496(void);
extern void F688_3933(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
