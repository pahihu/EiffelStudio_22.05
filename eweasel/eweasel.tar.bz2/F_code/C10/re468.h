
#ifndef _C10_re468_
#define _C10_re468_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F523_2941(EIF_REFERENCE);
extern void F523_2943(EIF_REFERENCE);
extern void EIF_Minit468(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
