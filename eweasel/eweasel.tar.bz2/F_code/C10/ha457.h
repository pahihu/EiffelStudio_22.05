
#ifndef _C10_ha457_
#define _C10_ha457_

#ifdef __cplusplus
extern "C" {
#endif

extern void F674_3703(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3706(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F674_3707(EIF_REFERENCE);
extern EIF_REFERENCE F674_3709(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F674_3711(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F674_3718(EIF_REFERENCE);
extern EIF_REFERENCE F674_3719(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F674_3720(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F674_3721(EIF_REFERENCE);
extern EIF_INTEGER_32 F674_3724(EIF_REFERENCE);
extern EIF_INTEGER_32 F674_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F674_3726(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F674_3727(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F674_3735(EIF_REFERENCE);
extern EIF_BOOLEAN F674_3736(EIF_REFERENCE);
extern EIF_BOOLEAN F674_3741(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3743(EIF_REFERENCE);
extern void F674_3745(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F674_3747(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F674_3748(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3749(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3750(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3757(EIF_REFERENCE);
extern void F674_3760(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F674_3761(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3762(EIF_REFERENCE);
extern EIF_INTEGER_32 F674_3771(EIF_REFERENCE);
extern EIF_BOOLEAN F674_3772(EIF_REFERENCE);
extern EIF_REFERENCE F674_3779(EIF_REFERENCE);
extern EIF_INTEGER_32 F674_3780(EIF_REFERENCE);
extern EIF_INTEGER_32 F674_3781(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F674_3782(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F674_3783(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3785(EIF_REFERENCE, EIF_REFERENCE);
extern void F674_3787(EIF_REFERENCE, EIF_REFERENCE);
extern void F674_3788(EIF_REFERENCE, EIF_REFERENCE);
extern void F674_3789(EIF_REFERENCE, EIF_REFERENCE);
extern void F674_3793(EIF_REFERENCE, EIF_INTEGER_32);
extern void F674_3799(EIF_REFERENCE);
extern void F674_3812(EIF_REFERENCE);
extern void EIF_Minit457(void);
extern void F693_3951(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F687_3964(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F494_2918(EIF_REFERENCE, EIF_INTEGER_32);
extern void F658_3585(EIF_REFERENCE);
extern void F693_3954(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F693_3944(EIF_REFERENCE);
extern void F687_3951(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F693_3933(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F658_3586(EIF_REFERENCE);
extern void F687_3933(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F673_3709(EIF_REFERENCE, EIF_REFERENCE);
extern void F687_3970(EIF_REFERENCE);
extern EIF_BOOLEAN F673_3711(EIF_REFERENCE, EIF_REFERENCE);
extern void F687_3954(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,3586)
extern char *(*R3177[])();
extern char *(*R2947[])();
extern char *(*R2967[])();
extern char *(*R2466[])();
extern char *(*R2968[])();
extern char *(*R2950[])();
extern char *(*R2469[])();
extern char *(*R2974[])();
extern char *(*R3004[])();
extern char *(*R3005[])();
extern char *(*R3006[])();
extern char *(*R2978[])();
extern char *(*R3008[])();
extern char *(*R3010[])();
extern char *(*R3011[])();
extern char *(*R3012[])();
extern char *(*R3157[])();
extern char *(*R2985[])();
extern char *(*R3016[])();
extern char *(*R2360[])();
extern char *(*R2361[])();
extern char *(*R2362[])();
extern char *(*R2994[])();
extern char *(*R2400[])();
extern char *(*R2995[])();
extern char *(*R3022[])();
extern char *(*R2951[])();
extern char *(*R2979[])();
extern char *(*R3143[])();
extern char *(*R3144[])();
extern char *(*R2373[])();
extern char *(*R2959[])();
extern char *(*R2501[])();
extern char *(*R3171[])();
extern char *(*R2961[])();
extern char *(*R3035[])();
extern char *(*R2537[])();
extern char *(*R2976[])();
extern char *(*R2771[])();
extern char *(*R3158[])();
extern long O2996[];
extern long O2997[];
extern long O2499[];
extern long O2960[];
extern long O3037[];
extern long O3001[];
extern long O3002[];
extern long O3003[];
extern long O2987[];
extern long O2988[];
extern long O2989[];
extern long O2990[];
extern long O2991[];
extern long O2992[];
extern long O2993[];
extern long O2951[];
extern EIF_TYPE_INDEX Y2401[];
extern EIF_TYPE_INDEX *Y2401_gen_type [];
extern EIF_TYPE_INDEX Y2539[];
extern EIF_TYPE_INDEX *Y2539_gen_type [];
extern EIF_TYPE_INDEX Y2987[];
extern EIF_TYPE_INDEX *Y2987_gen_type [];
extern EIF_TYPE_INDEX Y2988[];
extern EIF_TYPE_INDEX *Y2988_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
