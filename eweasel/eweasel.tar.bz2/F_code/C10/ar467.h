
#ifndef _C10_ar467_
#define _C10_ar467_

#ifdef __cplusplus
extern "C" {
#endif

extern void F316_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F316_2798(EIF_REFERENCE);
extern EIF_REFERENCE F316_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F316_2802(EIF_REFERENCE);
extern void EIF_Minit467(void);
extern EIF_INTEGER_32 F662_3642(EIF_REFERENCE);
extern EIF_REFERENCE F662_3623(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
