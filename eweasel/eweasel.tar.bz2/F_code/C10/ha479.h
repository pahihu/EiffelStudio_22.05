
#ifndef _C10_ha479_
#define _C10_ha479_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F295_2759(EIF_REFERENCE);
extern EIF_INTEGER_32 F295_2760(EIF_REFERENCE);
extern EIF_BOOLEAN F295_2762(EIF_REFERENCE);
extern void F295_2763(EIF_REFERENCE);
extern EIF_REFERENCE F295_2764(EIF_REFERENCE);
extern void EIF_Minit479(void);
extern char *(*R2463[])();
extern char *(*R2978[])();
extern char *(*R2979[])();
extern char *(*R2771[])();
extern long O2987[];
extern long O2988[];

#ifdef __cplusplus
}
#endif

#endif
