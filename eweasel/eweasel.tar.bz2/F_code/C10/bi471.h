
#ifndef _C10_bi471_
#define _C10_bi471_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F390_2857(EIF_REFERENCE);
extern void F390_2860(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit471(void);
extern void F377_2843(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F496_2928(EIF_REFERENCE);
extern char *(*R2518[])();
extern char *(*R2520[])();
extern char *(*R2521[])();

#ifdef __cplusplus
}
#endif

#endif
