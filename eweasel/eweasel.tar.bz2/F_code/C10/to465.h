
#ifndef _C10_to465_
#define _C10_to465_

#ifdef __cplusplus
extern "C" {
#endif

extern void F194_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F194_2351(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F194_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit465(void);
extern void F687_3933(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
