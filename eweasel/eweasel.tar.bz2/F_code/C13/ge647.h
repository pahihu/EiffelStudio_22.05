
#ifndef _C13_ge647_
#define _C13_ge647_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F307_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F307_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F307_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F307_2789(EIF_REFERENCE);
extern void F307_2792(EIF_REFERENCE);
extern void EIF_Minit647(void);

#ifdef __cplusplus
}
#endif

#endif
