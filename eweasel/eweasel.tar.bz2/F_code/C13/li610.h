
#ifndef _C13_li610_
#define _C13_li610_

#ifdef __cplusplus
extern "C" {
#endif

extern void F113_1465(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit610(void);

#ifdef __cplusplus
}
#endif

#endif
