
#ifndef _C13_ce621_
#define _C13_ce621_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F46_616(EIF_REFERENCE);
extern void F46_617(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit621(void);

#ifdef __cplusplus
}
#endif

#endif
