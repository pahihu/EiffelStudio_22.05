
#ifndef _C13_ty643_
#define _C13_ty643_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F275_2731(EIF_REFERENCE);
extern void EIF_Minit643(void);
extern EIF_INTEGER_32 F307_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
