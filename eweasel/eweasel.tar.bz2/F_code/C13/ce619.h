
#ifndef _C13_ce619_
#define _C13_ce619_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F44_616(EIF_REFERENCE);
extern void F44_617(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit619(void);
extern long O599[];

#ifdef __cplusplus
}
#endif

#endif
