
#ifndef _C11_li503_
#define _C11_li503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F379_2843(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_BOOLEAN F379_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F379_2849(EIF_REFERENCE);
extern void EIF_Minit503(void);
extern EIF_CHARACTER_32 F663_3624(EIF_REFERENCE);
extern EIF_BOOLEAN F624_3442(EIF_REFERENCE);
extern void F663_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F600_3418(EIF_REFERENCE);
extern EIF_BOOLEAN F498_2928(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
