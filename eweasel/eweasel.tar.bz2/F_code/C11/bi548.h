
#ifndef _C11_bi548_
#define _C11_bi548_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F392_2857(EIF_REFERENCE);
extern void F392_2860(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit548(void);
extern void F380_2843(EIF_REFERENCE, EIF_CHARACTER_8);
extern char *(*R2518[])();
extern char *(*R2520[])();
extern char *(*R2521[])();
extern char *(*R2497[])();

#ifdef __cplusplus
}
#endif

#endif
