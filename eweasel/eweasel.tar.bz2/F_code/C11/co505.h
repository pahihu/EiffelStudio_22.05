
#ifndef _C11_co505_
#define _C11_co505_

#ifdef __cplusplus
extern "C" {
#endif

extern void F355_2830(EIF_REFERENCE);
extern void EIF_Minit505(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
