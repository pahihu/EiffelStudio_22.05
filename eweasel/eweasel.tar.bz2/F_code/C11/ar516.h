
#ifndef _C11_ar516_
#define _C11_ar516_

#ifdef __cplusplus
extern "C" {
#endif

extern void F317_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F317_2798(EIF_REFERENCE);
extern EIF_REFERENCE F317_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F317_2802(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern EIF_REFERENCE F663_3623(EIF_REFERENCE);
extern EIF_INTEGER_32 F663_3642(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
