
#ifndef _C11_co535_
#define _C11_co535_

#ifdef __cplusplus
extern "C" {
#endif

extern void F356_2830(EIF_REFERENCE);
extern void EIF_Minit535(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
