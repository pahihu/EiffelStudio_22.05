
#ifndef _C11_re514_
#define _C11_re514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F524_2941(EIF_REFERENCE);
extern void F524_2943(EIF_REFERENCE);
extern void EIF_Minit514(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
