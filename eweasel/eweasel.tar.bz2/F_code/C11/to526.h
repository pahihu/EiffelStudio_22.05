
#ifndef _C11_to526_
#define _C11_to526_

#ifdef __cplusplus
extern "C" {
#endif

extern void F196_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F196_2351(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F196_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit526(void);
extern void F689_3933(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
