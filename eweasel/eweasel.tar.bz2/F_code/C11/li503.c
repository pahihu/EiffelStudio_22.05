/*
 * Code for class LINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.search */
void F379_2843 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 378, Current, 0, 1, 3722);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O2499[Dtype(Current)-351])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F379_2847(Current)) {
				tb1 = (arg1 == F663_3624(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F663_3652(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F379_2847(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F663_3624(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F663_3652(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F379_2847 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 378, Current, 0, 0, 3725);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F600_3418(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F379_2849 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 378, Current, 0, 0, 3726);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F498_2928(Current)) {
		Result = F624_3442(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
