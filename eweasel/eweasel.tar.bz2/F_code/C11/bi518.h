
#ifndef _C11_bi518_
#define _C11_bi518_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F391_2857(EIF_REFERENCE);
extern void F391_2860(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit518(void);
extern void F379_2843(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F663_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F624_3443(EIF_REFERENCE);
extern EIF_BOOLEAN F498_2928(EIF_REFERENCE);
extern EIF_BOOLEAN F624_3442(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
