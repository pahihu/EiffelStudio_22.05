
#ifndef _C11_fi506_
#define _C11_fi506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F498_2928(EIF_REFERENCE);
extern void EIF_Minit506(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
