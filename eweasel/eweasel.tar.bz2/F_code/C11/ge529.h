
#ifndef _C11_ge529_
#define _C11_ge529_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F306_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F306_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F306_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F306_2789(EIF_REFERENCE);
extern void F306_2792(EIF_REFERENCE);
extern void EIF_Minit529(void);

#ifdef __cplusplus
}
#endif

#endif
