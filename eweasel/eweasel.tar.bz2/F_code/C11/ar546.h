
#ifndef _C11_ar546_
#define _C11_ar546_

#ifdef __cplusplus
extern "C" {
#endif

extern void F318_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2798(EIF_REFERENCE);
extern EIF_REFERENCE F318_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2802(EIF_REFERENCE);
extern void EIF_Minit546(void);
extern EIF_INTEGER_32 F664_3642(EIF_REFERENCE);
extern EIF_REFERENCE F664_3623(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
