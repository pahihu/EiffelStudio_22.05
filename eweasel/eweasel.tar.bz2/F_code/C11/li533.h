
#ifndef _C11_li533_
#define _C11_li533_

#ifdef __cplusplus
extern "C" {
#endif

extern void F380_2843(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_BOOLEAN F380_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F380_2849(EIF_REFERENCE);
extern void EIF_Minit533(void);
extern char *(*R2505[])();
extern char *(*R2506[])();
extern char *(*R2518[])();
extern char *(*R2520[])();
extern char *(*R2497[])();
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
