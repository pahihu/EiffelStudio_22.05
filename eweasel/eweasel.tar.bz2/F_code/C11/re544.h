
#ifndef _C11_re544_
#define _C11_re544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F525_2941(EIF_REFERENCE);
extern void F525_2943(EIF_REFERENCE);
extern void EIF_Minit544(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
