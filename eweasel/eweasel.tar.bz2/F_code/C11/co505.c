/*
 * Code for class CONTAINER [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F355_2830 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 354, Current, 0, 0, 3564);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2499[Dtype(Current)-351]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
