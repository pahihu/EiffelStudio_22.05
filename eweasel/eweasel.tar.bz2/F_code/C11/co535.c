/*
 * Code for class CONTAINER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F356_2830 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 355, Current, 0, 0, 3570);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2499[Dtype(Current)-351]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
