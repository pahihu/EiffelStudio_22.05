
#ifndef _C11_fi536_
#define _C11_fi536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F499_2928(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
