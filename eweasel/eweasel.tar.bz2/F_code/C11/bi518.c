/*
 * Code for class BILINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F391_2857 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 390, Current, 0, 0, 3840);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F624_3443(Current)) {
		Result = F624_3442(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F391_2860 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 390, Current, 0, 1, 3841);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F624_3443(Current)) {
		tb1 = (EIF_BOOLEAN) !F498_2928(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F663_3652(Current);
	}
	RTHOOK(3);
	F379_2843(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
