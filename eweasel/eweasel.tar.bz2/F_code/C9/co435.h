
#ifndef _C9_co435_
#define _C9_co435_

#ifdef __cplusplus
extern "C" {
#endif

extern void F354_2830(EIF_REFERENCE);
extern void EIF_Minit435(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
