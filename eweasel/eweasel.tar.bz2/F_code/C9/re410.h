
#ifndef _C9_re410_
#define _C9_re410_

#ifdef __cplusplus
extern "C" {
#endif

extern void F284_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2752(EIF_REFERENCE);
extern void F284_2754(EIF_REFERENCE);
extern void F284_2756(EIF_REFERENCE);
extern void F284_2757(EIF_REFERENCE);
extern void EIF_Minit410(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
