
#ifndef _C9_li402_
#define _C9_li402_

#ifdef __cplusplus
extern "C" {
#endif

extern void F377_2843(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F377_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F377_2849(EIF_REFERENCE);
extern void EIF_Minit402(void);
extern char *(*R2505[])();
extern char *(*R2506[])();
extern char *(*R2518[])();
extern char *(*R2520[])();
extern char *(*R2497[])();
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
