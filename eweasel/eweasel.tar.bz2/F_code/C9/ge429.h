
#ifndef _C9_ge429_
#define _C9_ge429_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F303_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F303_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F303_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F303_2789(EIF_REFERENCE);
extern void F303_2792(EIF_REFERENCE);
extern void EIF_Minit429(void);

#ifdef __cplusplus
}
#endif

#endif
