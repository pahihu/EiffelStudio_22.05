
#ifndef _C9_re446_
#define _C9_re446_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F522_2941(EIF_REFERENCE);
extern void F522_2943(EIF_REFERENCE);
extern void EIF_Minit446(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
