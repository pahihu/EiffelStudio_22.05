
#ifndef _C9_fi400_
#define _C9_fi400_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F496_2928(EIF_REFERENCE);
extern void EIF_Minit400(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
