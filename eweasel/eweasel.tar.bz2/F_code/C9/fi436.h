
#ifndef _C9_fi436_
#define _C9_fi436_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F497_2928(EIF_REFERENCE);
extern void EIF_Minit436(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
