
#ifndef _C9_li433_
#define _C9_li433_

#ifdef __cplusplus
extern "C" {
#endif

extern void F378_2843(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F378_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F378_2849(EIF_REFERENCE);
extern void EIF_Minit433(void);
extern EIF_BOOLEAN F598_3418(EIF_REFERENCE);
extern EIF_BOOLEAN F497_2928(EIF_REFERENCE);
extern void F661_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F622_3442(EIF_REFERENCE);
extern EIF_NATURAL_64 F661_3624(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
