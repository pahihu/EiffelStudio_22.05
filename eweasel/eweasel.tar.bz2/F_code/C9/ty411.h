
#ifndef _C9_ty411_
#define _C9_ty411_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F272_2731(EIF_REFERENCE);
extern void EIF_Minit411(void);
extern EIF_INTEGER_32 F306_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
