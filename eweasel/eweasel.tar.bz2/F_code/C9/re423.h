
#ifndef _C9_re423_
#define _C9_re423_

#ifdef __cplusplus
extern "C" {
#endif

extern void F286_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2752(EIF_REFERENCE);
extern void F286_2754(EIF_REFERENCE);
extern void F286_2756(EIF_REFERENCE);
extern void F286_2757(EIF_REFERENCE);
extern void EIF_Minit423(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
