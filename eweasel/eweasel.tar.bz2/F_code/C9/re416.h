
#ifndef _C9_re416_
#define _C9_re416_

#ifdef __cplusplus
extern "C" {
#endif

extern void F285_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2752(EIF_REFERENCE);
extern void F285_2754(EIF_REFERENCE);
extern void F285_2756(EIF_REFERENCE);
extern void F285_2757(EIF_REFERENCE);
extern void EIF_Minit416(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
