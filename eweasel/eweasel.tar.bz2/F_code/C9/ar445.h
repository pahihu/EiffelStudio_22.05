
#ifndef _C9_ar445_
#define _C9_ar445_

#ifdef __cplusplus
extern "C" {
#endif

extern void F315_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F315_2798(EIF_REFERENCE);
extern EIF_REFERENCE F315_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F315_2802(EIF_REFERENCE);
extern void EIF_Minit445(void);
extern EIF_REFERENCE F661_3623(EIF_REFERENCE);
extern EIF_INTEGER_32 F661_3642(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
