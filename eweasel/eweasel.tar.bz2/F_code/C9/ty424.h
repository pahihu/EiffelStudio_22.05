
#ifndef _C9_ty424_
#define _C9_ty424_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F274_2731(EIF_REFERENCE);
extern void EIF_Minit424(void);
extern EIF_INTEGER_32 F303_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
