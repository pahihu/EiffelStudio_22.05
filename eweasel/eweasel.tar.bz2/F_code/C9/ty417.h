
#ifndef _C9_ty417_
#define _C9_ty417_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F273_2731(EIF_REFERENCE);
extern void EIF_Minit417(void);
extern EIF_INTEGER_32 F305_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
