/*
 * Code for class TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_64, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty424.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPED_INDEXABLE_ITERATION_CURSOR}.item */
EIF_NATURAL_64 F274_2731 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item", 273, Current, 0, 0, 2791);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = F303_2779(Current);
	Result = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2771[Dtype(RTCW(tr1))-584])(tr1, ti4_1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit424 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
