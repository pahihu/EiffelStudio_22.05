
#ifndef _C9_bi449_
#define _C9_bi449_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F389_2857(EIF_REFERENCE);
extern void F389_2860(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit449(void);
extern void F378_2843(EIF_REFERENCE, EIF_NATURAL_64);
extern void F661_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F622_3443(EIF_REFERENCE);
extern EIF_BOOLEAN F497_2928(EIF_REFERENCE);
extern EIF_BOOLEAN F622_3442(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
