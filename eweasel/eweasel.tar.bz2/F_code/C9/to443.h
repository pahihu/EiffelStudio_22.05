
#ifndef _C9_to443_
#define _C9_to443_

#ifdef __cplusplus
extern "C" {
#endif

extern void F193_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F193_2351(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F193_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit443(void);
extern void F686_3933(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
