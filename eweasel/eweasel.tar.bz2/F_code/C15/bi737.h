
#ifndef _C15_bi737_
#define _C15_bi737_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F395_2857(EIF_REFERENCE);
extern void F395_2860(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit737(void);
extern EIF_BOOLEAN F502_2928(EIF_REFERENCE);
extern void F383_2843(EIF_REFERENCE, EIF_NATURAL_16);
extern void F667_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F628_3443(EIF_REFERENCE);
extern EIF_BOOLEAN F628_3442(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
