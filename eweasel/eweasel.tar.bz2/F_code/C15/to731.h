
#ifndef _C15_to731_
#define _C15_to731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F199_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F199_2351(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F199_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit731(void);
extern void F692_3933(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
