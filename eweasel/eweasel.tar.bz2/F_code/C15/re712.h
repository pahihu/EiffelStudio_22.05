
#ifndef _C15_re712_
#define _C15_re712_

#ifdef __cplusplus
extern "C" {
#endif

extern void F289_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2752(EIF_REFERENCE);
extern void F289_2754(EIF_REFERENCE);
extern void F289_2756(EIF_REFERENCE);
extern void F289_2757(EIF_REFERENCE);
extern void EIF_Minit712(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
