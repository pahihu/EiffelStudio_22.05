
#ifndef _C15_re734_
#define _C15_re734_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F528_2941(EIF_REFERENCE);
extern void F528_2943(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
