
#ifndef _C15_fi724_
#define _C15_fi724_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F502_2928(EIF_REFERENCE);
extern void EIF_Minit724(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
