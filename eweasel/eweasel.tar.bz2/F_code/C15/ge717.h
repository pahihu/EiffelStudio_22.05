
#ifndef _C15_ge717_
#define _C15_ge717_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F309_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F309_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F309_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F309_2789(EIF_REFERENCE);
extern void F309_2792(EIF_REFERENCE);
extern void EIF_Minit717(void);

#ifdef __cplusplus
}
#endif

#endif
