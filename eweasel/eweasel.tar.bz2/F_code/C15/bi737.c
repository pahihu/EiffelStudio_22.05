/*
 * Code for class BILINEAR [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi737.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F395_2857 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 394, Current, 0, 0, 3852);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F628_3443(Current)) {
		Result = F628_3442(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F395_2860 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 394, Current, 0, 1, 3853);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F628_3443(Current)) {
		tb1 = (EIF_BOOLEAN) !F502_2928(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F667_3652(Current);
	}
	RTHOOK(3);
	F383_2843(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit737 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
