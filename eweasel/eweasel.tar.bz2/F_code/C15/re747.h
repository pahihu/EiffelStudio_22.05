
#ifndef _C15_re747_
#define _C15_re747_

#ifdef __cplusplus
extern "C" {
#endif

extern void F290_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F290_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F290_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F290_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F290_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F290_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F290_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F290_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F290_2752(EIF_REFERENCE);
extern void F290_2754(EIF_REFERENCE);
extern void F290_2756(EIF_REFERENCE);
extern void F290_2757(EIF_REFERENCE);
extern void EIF_Minit747(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
