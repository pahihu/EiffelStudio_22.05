/*
 * Code for class GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_16, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge717.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.item */
EIF_NATURAL_16 F309_2777 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_NATURAL_16 tu2_2;
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item", 308, Current, 0, 0, 3250);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	/* INLINED CODE (SPECIAL.item) */
	tu2_2 = *((EIF_NATURAL_16 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_)));
	/* END INLINED CODE */
	Result = tu2_2;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.target_index */
EIF_INTEGER_32 F309_2779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("target_index", 308, Current, 0, 0, 3252);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) + ((EIF_INTEGER_32) 1L)) - ((EIF_INTEGER_32) 0L));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.after */
EIF_BOOLEAN F309_2786 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("after", 308, Current, 0, 0, 3259);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.is_first */
EIF_BOOLEAN F309_2789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_first", 308, Current, 0, 0, 3262);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) 0L));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.forth */
void F309_2792 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("forth", 308, Current, 0, 0, 3246);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))++;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit717 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
