
#ifndef _C15_li721_
#define _C15_li721_

#ifdef __cplusplus
extern "C" {
#endif

extern void F383_2843(EIF_REFERENCE, EIF_NATURAL_16);
extern EIF_BOOLEAN F383_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F383_2849(EIF_REFERENCE);
extern void EIF_Minit721(void);
extern EIF_BOOLEAN F502_2928(EIF_REFERENCE);
extern void F667_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F604_3418(EIF_REFERENCE);
extern EIF_BOOLEAN F628_3442(EIF_REFERENCE);
extern EIF_NATURAL_16 F667_3624(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
