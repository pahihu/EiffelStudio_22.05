/*
 * Code for class CHAIN [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch705.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHAIN}.i_th */
EIF_NATURAL_32 F603_3407 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("i_th", 602, Current, 1, 1, 5489);
	RTGC;
	RTHOOK(1);
	loc1 = F666_3630(Current);
	RTHOOK(2);
	F666_3654(Current, arg1);
	RTHOOK(3);
	Result = F666_3624(Current);
	RTHOOK(4);
	F666_3655(Current, loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.lower */
EIF_INTEGER_32 F603_3410 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {CHAIN}.valid_index */
EIF_BOOLEAN F603_3415 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("valid_index", 602, Current, 0, 1, 5473);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1L))) {
		Result = (EIF_BOOLEAN) (arg1 <= F666_3640(Current));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.islast */
EIF_BOOLEAN F603_3417 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("islast", 602, Current, 0, 0, 5475);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F501_2928(Current)) {
		Result = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == F666_3640(Current));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.off */
EIF_BOOLEAN F603_3418 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 602, Current, 0, 0, 5476);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == (EIF_INTEGER_32) (F666_3640(Current) + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.append */
void F603_3422 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("append", 602, Current, 2, 1, 5480);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Current);
	}
	RTHOOK(4);
	loc2 = F666_3630(Current);
	RTHOOK(5);
	F666_3650(RTCW(loc1));
	for (;;) {
		RTHOOK(6);
		tb1 = F382_2847(RTCW(loc1));
		if (tb1) break;
		RTHOOK(7);
		tu4_1 = F666_3624(RTCW(loc1));
		F666_3660(Current, tu4_1);
		RTHOOK(8);
		F666_3651(Current);
		RTHOOK(9);
		F666_3652(RTCW(loc1));
	}
	RTHOOK(10);
	F666_3655(Current, loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
}

void EIF_Minit705 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
