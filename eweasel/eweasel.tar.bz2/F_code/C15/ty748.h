
#ifndef _C15_ty748_
#define _C15_ty748_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F278_2731(EIF_REFERENCE);
extern void EIF_Minit748(void);
extern EIF_INTEGER_32 F310_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
