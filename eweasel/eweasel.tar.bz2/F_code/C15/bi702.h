
#ifndef _C15_bi702_
#define _C15_bi702_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F394_2857(EIF_REFERENCE);
extern void F394_2860(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit702(void);
extern EIF_BOOLEAN F501_2928(EIF_REFERENCE);
extern void F666_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F627_3443(EIF_REFERENCE);
extern void F382_2843(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F627_3442(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
