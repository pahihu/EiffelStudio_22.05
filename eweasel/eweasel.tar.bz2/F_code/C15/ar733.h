
#ifndef _C15_ar733_
#define _C15_ar733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F321_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2798(EIF_REFERENCE);
extern EIF_REFERENCE F321_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2802(EIF_REFERENCE);
extern void EIF_Minit733(void);
extern EIF_REFERENCE F667_3623(EIF_REFERENCE);
extern EIF_INTEGER_32 F667_3642(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
