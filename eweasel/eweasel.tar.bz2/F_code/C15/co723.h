
#ifndef _C15_co723_
#define _C15_co723_

#ifdef __cplusplus
extern "C" {
#endif

extern void F359_2830(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
