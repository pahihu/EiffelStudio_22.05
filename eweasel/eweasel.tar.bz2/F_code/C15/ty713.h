
#ifndef _C15_ty713_
#define _C15_ty713_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F277_2731(EIF_REFERENCE);
extern void EIF_Minit713(void);
extern EIF_INTEGER_32 F309_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
