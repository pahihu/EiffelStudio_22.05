
#ifndef _C1_ew8_
#define _C1_ew8_

#ifdef __cplusplus
extern "C" {
#endif

extern void F8_106(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);

#ifdef __cplusplus
}
#endif

#endif
