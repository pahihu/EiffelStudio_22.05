
#ifndef _C1_ew47_
#define _C1_ew47_

#ifdef __cplusplus
extern "C" {
#endif

extern void F66_807(EIF_REFERENCE, EIF_REFERENCE);
extern void F66_808(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F66_809(EIF_REFERENCE);
extern EIF_BOOLEAN F66_810(EIF_REFERENCE);
extern void EIF_Minit47(void);
extern EIF_INTEGER_32 F52_705(EIF_REFERENCE, EIF_REFERENCE);
extern void F907_6201(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
