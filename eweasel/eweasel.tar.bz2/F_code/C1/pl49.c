/*
 * Code for class PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pl49.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PLATFORM}.is_windows */
EIF_BOOLEAN F68_820 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_windows", 67, Current, 0, 0, 911);
	Result = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PLATFORM}.pointer_bytes */
EIF_INTEGER_32 F68_840 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pointer_bytes", 67, Current, 0, 0, 931);
	Result = (EIF_INTEGER_32) eif_builtin_PLATFORM_pointer_bytes__i4;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
