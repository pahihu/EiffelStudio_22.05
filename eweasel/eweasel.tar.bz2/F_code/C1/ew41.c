/*
 * Code for class EW_SYSTEM_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew41.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_SYSTEM_INST}.inst_initialize */
void F60_765 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 59, Current, 0, 1, 841);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4218[Dtype(RTCW(arg1))-893])(arg1);
	if (!tb2) {
		tb1 = (EIF_BOOLEAN) (F52_705(Current, arg1) > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		tr1 = RTMS32_EX_H("z\000\000\000e\000\000\000r\000\000\000o\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000m\000\000\000o\000\000\000r\000\000\000e\000\000\000 \000\000\000t\000\000\000h\000\000\000a\000\000\000n\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000s\000\000\000y\000\000\000s\000\000\000t\000\000\000e\000\000\000m\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000l\000\000\000i\000\000\000e\000\000\000d\000\000\000",42,908027748);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(5);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_SYSTEM_INST}.execute */
void F60_766 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 59, Current, 0, 1, 842);
	RTHOOK(1);
	F907_6200(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	RTEE;
}

/* {EW_SYSTEM_INST}.init_ok */
EIF_BOOLEAN F60_767 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_);
}


/* {EW_SYSTEM_INST}.execute_ok */
EIF_BOOLEAN F60_768 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
