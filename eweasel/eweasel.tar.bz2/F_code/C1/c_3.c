/*
 * Code for class C_DATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "c_3.h"
#include <string.h>
#include <time.h>
#include "eif_time.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F3_58
static void inline_F3_58 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
    			static const uint64_t EPOCH = ((uint64_t) 116444736000000000ULL);

				SYSTEMTIME  system_time;
				FILETIME    file_time;
				uint64_t    time;
				struct timeval *tp = (struct timeval *) arg1;

				GetSystemTime (&system_time );
				SystemTimeToFileTime (&system_time, &file_time );
				time = ((uint64_t) file_time.dwLowDateTime );
				time += ((uint64_t) file_time.dwHighDateTime) << 32;

				tp->tv_sec  = (long) ((time - EPOCH) / 10000000L);
				tp->tv_usec = (long) (system_time.wMilliseconds * 1000);
			#else
				gettimeofday((struct timeval *) arg1, NULL);
			#endif
	;
}
#define INLINE_F3_58
#endif
#ifndef INLINE_F3_62
static void inline_F3_62 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	*(time_t *) arg2 = (((struct timeval *)arg1)->tv_sec);
	;
}
#define INLINE_F3_62
#endif
#ifndef INLINE_F3_66
static EIF_POINTER inline_F3_66 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gmtime ((time_t *) arg1))
	;
}
#define INLINE_F3_66
#endif
#ifndef INLINE_F3_65
static EIF_POINTER inline_F3_65 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (localtime ((time_t *) arg1))
	;
}
#define INLINE_F3_65
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {C_DATE}.default_create */
void F3_46 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 2, Current, 0, 0, 46);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	F3_49(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {C_DATE}.make_utc */
void F3_47 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_utc", 2, Current, 0, 0, 47);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F3_49(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {C_DATE}.update */
void F3_49 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update", 2, Current, 4, 0, 49);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(struct timeval);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) sizeof(time_t);
	tp1 = malloc((size_t)ti4_1);
	loc3 = (EIF_POINTER) tp1;
	RTHOOK(3);
	inline_F3_58(loc1);
	RTHOOK(4);
	inline_F3_62(loc1, loc3);
	RTHOOK(5);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTHOOK(6);
		loc2 = inline_F3_66(loc3);
	} else {
		RTHOOK(7);
		loc2 = inline_F3_65(loc3);
	}
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(181, 0).id);
	ti4_1 = (EIF_INTEGER_32) sizeof(struct tm);
	F182_1875(RTCW(tr1), loc2, ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	loc4 = (EIF_INTEGER_32) (((struct timeval *)loc1)->tv_usec);
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 999999L)))) {
		RTHOOK(11);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(12);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc4;
	}
	RTHOOK(13);
	free(loc3);
	RTHOOK(14);
	free(loc1);
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {C_DATE}.year_now */
EIF_INTEGER_32 F3_50 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("year_now", 2, Current, 0, 0, 50);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_year);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1900L) + Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.month_now */
EIF_INTEGER_32 F3_51 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("month_now", 2, Current, 0, 0, 51);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_mon);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.day_now */
EIF_INTEGER_32 F3_52 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("day_now", 2, Current, 0, 0, 52);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_mday);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.gettimeofday */
void F3_58 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gettimeofday", 2, Current, 0, 1, 58);
	inline_F3_58 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {C_DATE}.timeval_structure_size */
EIF_INTEGER_32 F3_59 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("timeval_structure_size", 2, Current, 0, 0, 59);
	Result = (EIF_INTEGER_32) sizeof(struct timeval);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.time_t_structure_size */
EIF_INTEGER_32 F3_60 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("time_t_structure_size", 2, Current, 0, 0, 60);
	Result = (EIF_INTEGER_32) sizeof(time_t);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.tm_structure_size */
EIF_INTEGER_32 F3_61 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("tm_structure_size", 2, Current, 0, 0, 61);
	Result = (EIF_INTEGER_32) sizeof(struct tm);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_time */
void F3_62 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_time", 2, Current, 0, 2, 62);
	inline_F3_62 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {C_DATE}.get_micro */
EIF_INTEGER_32 F3_63 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_micro", 2, Current, 0, 1, 63);Result = (EIF_INTEGER_32) (((struct timeval *)arg1)->tv_usec);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.localtime */
EIF_POINTER F3_65 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("localtime", 2, Current, 0, 1, 65);
	Result = inline_F3_65 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.gmtime */
EIF_POINTER F3_66 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gmtime", 2, Current, 0, 1, 66);
	Result = inline_F3_66 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_year */
EIF_INTEGER_32 F3_67 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_year", 2, Current, 0, 1, 67);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_year);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_mon */
EIF_INTEGER_32 F3_68 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_mon", 2, Current, 0, 1, 68);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_mon);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_mday */
EIF_INTEGER_32 F3_69 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_mday", 2, Current, 0, 1, 69);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_mday);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
