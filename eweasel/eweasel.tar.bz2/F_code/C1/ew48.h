
#ifndef _C1_ew48_
#define _C1_ew48_

#ifdef __cplusplus
extern "C" {
#endif

extern void F67_812(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F67_814(EIF_REFERENCE);
extern EIF_BOOLEAN F67_815(EIF_REFERENCE);
extern void EIF_Minit48(void);
extern EIF_REFERENCE F52_709(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2561[])();
extern char *(*R2833[])();
extern long O760[];
extern long O761[];

#ifdef __cplusplus
}
#endif

#endif
