
#ifndef _C1_st15_
#define _C1_st15_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,384)
static EIF_REFERENCE F27_384_body(EIF_REFERENCE);
extern EIF_REFERENCE F27_384(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,385)
static EIF_REFERENCE F27_385_body(EIF_REFERENCE);
extern EIF_REFERENCE F27_385(EIF_REFERENCE);
extern EIF_REFERENCE F27_387(EIF_REFERENCE);
extern void F27_411(EIF_REFERENCE);
extern void F27_412(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F27_414(EIF_REFERENCE, EIF_REFERENCE);
extern void F27_437(EIF_REFERENCE);
extern void EIF_Minit15(void);
extern void F900_6030(EIF_REFERENCE, EIF_REFERENCE);
extern void F900_6029(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1770[])();
extern char *(*R1772[])();
extern char *(*R1774[])();

#ifdef __cplusplus
}
#endif

#endif
