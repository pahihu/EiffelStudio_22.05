
#ifndef _C1_ew40_
#define _C1_ew40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F59_760(EIF_REFERENCE, EIF_REFERENCE);
extern void F59_761(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F59_762(EIF_REFERENCE);
extern EIF_BOOLEAN F59_763(EIF_REFERENCE);
extern EIF_BOOLEAN F59_764(EIF_REFERENCE);
extern void EIF_Minit40(void);
extern void F924_6576(EIF_REFERENCE);
extern void F927_6603(EIF_REFERENCE);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
