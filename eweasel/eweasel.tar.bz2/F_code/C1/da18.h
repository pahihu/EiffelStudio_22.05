
#ifndef _C1_da18_
#define _C1_da18_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,491)
static EIF_REFERENCE F30_491_body(EIF_REFERENCE);
extern EIF_REFERENCE F30_491(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,492)
static EIF_REFERENCE F30_492_body(EIF_REFERENCE);
extern EIF_REFERENCE F30_492(EIF_REFERENCE);
extern void EIF_Minit18(void);
extern EIF_REFERENCE F685_3941(EIF_REFERENCE);
extern void F352_2830(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
