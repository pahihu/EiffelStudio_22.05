
#ifndef _C1_ew44_
#define _C1_ew44_

#ifdef __cplusplus
extern "C" {
#endif

extern void F63_791(EIF_REFERENCE, EIF_REFERENCE);
extern void F63_792(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F63_793(EIF_REFERENCE);
extern EIF_BOOLEAN F63_794(EIF_REFERENCE);
extern void EIF_Minit44(void);
extern EIF_BOOLEAN F890_5564(EIF_REFERENCE);
extern EIF_INTEGER_32 F890_5598(EIF_REFERENCE);
extern EIF_INTEGER_32 F52_705(EIF_REFERENCE, EIF_REFERENCE);
extern void F907_6204(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
