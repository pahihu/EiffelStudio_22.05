
#ifndef _C1_ew36_
#define _C1_ew36_

#ifdef __cplusplus
extern "C" {
#endif

extern void F55_740(EIF_REFERENCE, EIF_REFERENCE);
extern void F55_741(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F55_742(EIF_REFERENCE);
extern EIF_BOOLEAN F55_743(EIF_REFERENCE);
extern void EIF_Minit36(void);
extern void F907_6199(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
