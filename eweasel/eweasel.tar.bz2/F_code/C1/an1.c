/*
 * Code for class ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "an1.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ANY}.generating_type */
EIF_REFERENCE F1_5 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("generating_type", 0, Current, 0, 0, 1);
	Result = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.same_type */
EIF_BOOLEAN F1_7 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("same_type", 0, Current, 0, 1, 3);
	Result = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (Current, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.is_equal */
EIF_BOOLEAN F1_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 0, Current, 0, 1, 4);
	Result = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.equal */
EIF_BOOLEAN F1_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("equal", 0, Current, 0, 2, 6);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(arg2 == NULL);
	} else {
		RTHOOK(4);
		Result = '\0';
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tr1 = RTCCL(arg2);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(arg1))-2])(arg1, tr1);
			Result = tb1;
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.twin */
EIF_REFERENCE F1_14 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("twin", 0, Current, 0, 0, 10);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Current);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.copy */
void F1_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("copy", 0, Current, 0, 1, 11);
	eif_builtin_ANY_copy__o_ (Current, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {ANY}.standard_copy */
void F1_16 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("standard_copy", 0, Current, 0, 1, 12);
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {ANY}.deep_twin */
EIF_REFERENCE F1_20 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("deep_twin", 0, Current, 0, 0, 16);
	Result = (EIF_REFERENCE) eif_builtin_ANY_deep_twin__o (Current);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ANY}.internal_correct_mismatch */
void F1_23 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("internal_correct_mismatch", 0, Current, 3, 0, 19);
	RTGC;
	RTHOOK(1);
	loc3 = RTCCL(Current);
	loc3 = RTRV(eif_new_type(657, 0x00),loc3);
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2910[Dtype(loc3)-659])(loc3);
	} else {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = F890_5592(RTMS_EX_H("Mismatch: ",10,1538098208));
		F897_5863(RTCW(loc1), tr1);
		RTHOOK(4);
		loc2 = RTLNS(eif_new_type(116, 0x00).id, 116, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(5);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3393[Dtype(RTCW(tr1))-780])(tr1);
		F899_5976(RTCW(loc1), tr1);
		RTHOOK(6);
		F117_1490(RTCW(loc2), loc1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {ANY}.io */
static EIF_REFERENCE F1_24_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("io", 0, Current, 0, 0, 20);
	RTGC;
	RTOSP (24);
#define Result RTOSR(24)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(26, 0x00).id, 26, _OBJSIZ_1_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F27_411(RTCW(Result));
	RTOSE (24);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1_24 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(24,F1_24_body,(Current));
}

/* {ANY}.default_create */
void F1_29 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 0, Current, 0, 0, 25);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {ANY}.default_rescue */
void F1_30 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_rescue", 0, Current, 0, 0, 26);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {ANY}.do_nothing */
void F1_31 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("do_nothing", 0, Current, 0, 0, 27);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {ANY}.default_pointer */
EIF_POINTER F1_33 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_pointer", 0, Current, 0, 0, 29);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_POINTER) 0;
}

void EIF_Minit1 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
