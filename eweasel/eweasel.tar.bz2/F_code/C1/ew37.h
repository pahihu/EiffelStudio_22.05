
#ifndef _C1_ew37_
#define _C1_ew37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F56_745(EIF_REFERENCE, EIF_REFERENCE);
extern void F56_746(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F56_747(EIF_REFERENCE);
extern EIF_BOOLEAN F56_748(EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F907_6198(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
