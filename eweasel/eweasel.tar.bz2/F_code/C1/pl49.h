
#ifndef _C1_pl49_
#define _C1_pl49_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F68_820(EIF_REFERENCE);
extern EIF_INTEGER_32 F68_840(EIF_REFERENCE);
extern void EIF_Minit49(void);

#ifdef __cplusplus
}
#endif

#endif
