
#ifndef _C1_ew46_
#define _C1_ew46_

#ifdef __cplusplus
extern "C" {
#endif

extern void F65_801(EIF_REFERENCE, EIF_REFERENCE);
extern void F65_802(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F65_803(EIF_REFERENCE);
extern EIF_BOOLEAN F65_804(EIF_REFERENCE);
extern void EIF_Minit46(void);
extern void F907_6202(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F52_709(EIF_REFERENCE, EIF_REFERENCE);
extern void F907_6201(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2561[])();
extern char *(*R2534[])();

#ifdef __cplusplus
}
#endif

#endif
