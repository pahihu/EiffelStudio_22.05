
#ifndef _C1_ew16_
#define _C1_ew16_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_463(EIF_REFERENCE);
extern void F28_473(EIF_REFERENCE);
extern void F28_474(EIF_REFERENCE);
extern void F28_475(EIF_REFERENCE);
extern void F28_476(EIF_REFERENCE, EIF_BOOLEAN);
extern void F28_477(EIF_REFERENCE, EIF_REFERENCE);
extern void F28_478(EIF_REFERENCE, EIF_INTEGER_32);
extern void F28_479(EIF_REFERENCE, EIF_INTEGER_32);
extern void F28_480(EIF_REFERENCE, EIF_BOOLEAN);
extern void F28_481(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
