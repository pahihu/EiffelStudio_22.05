
#ifndef _C1_is14_
#define _C1_is14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F14_279(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F14_281(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F14_289(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit14(void);

#ifdef __cplusplus
}
#endif

#endif
