
#ifndef _C1_ew41_
#define _C1_ew41_

#ifdef __cplusplus
extern "C" {
#endif

extern void F60_765(EIF_REFERENCE, EIF_REFERENCE);
extern void F60_766(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F60_767(EIF_REFERENCE);
extern EIF_BOOLEAN F60_768(EIF_REFERENCE);
extern void EIF_Minit41(void);
extern void F907_6200(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F52_705(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4218[])();

#ifdef __cplusplus
}
#endif

#endif
