
#ifndef _C1_ew39_
#define _C1_ew39_

#ifdef __cplusplus
extern "C" {
#endif

extern void F58_754(EIF_REFERENCE, EIF_REFERENCE);
extern void F58_755(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F58_756(EIF_REFERENCE);
extern EIF_BOOLEAN F58_757(EIF_REFERENCE);
extern void EIF_Minit39(void);
extern EIF_REFERENCE F52_711(EIF_REFERENCE, EIF_REFERENCE);
extern void F907_6203(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2561[])();
extern char *(*R2534[])();

#ifdef __cplusplus
}
#endif

#endif
