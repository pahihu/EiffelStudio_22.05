
#ifndef _C1_ew34_
#define _C1_ew34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F53_718(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit34(void);
extern EIF_REFERENCE F52_709(EIF_REFERENCE, EIF_REFERENCE);
extern void F163_1627(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F897_5888(EIF_REFERENCE, EIF_REFERENCE);
extern void F162_1624(EIF_REFERENCE, EIF_REFERENCE);
extern void F164_1630(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4262[])();
extern char *(*R2561[])();
extern char *(*R2833[])();
extern char *(*R2534[])();

#ifdef __cplusplus
}
#endif

#endif
