
#ifndef _C1_do27_
#define _C1_do27_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F39_560(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
