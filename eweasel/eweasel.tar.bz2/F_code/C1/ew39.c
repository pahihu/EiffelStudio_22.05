/*
 * Code for class EW_PREFERENCE_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew39.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_PREFERENCE_INST}.inst_initialize */
void F58_754 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("inst_initialize", 57, Current, 1, 1, 830);
	RTGC;
	RTHOOK(1);
	loc1 = F52_711(Current, arg1);
	RTHOOK(2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2561[Dtype(RTCW(loc1))-557])(loc1);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		ti4_1 = ((EIF_INTEGER_32) 1L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2534[Dtype(RTCW(loc1))-584])(loc1, (EIF_REFERENCE) &ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		ti4_1 = ((EIF_INTEGER_32) 2L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2534[Dtype(RTCW(loc1))-584])(loc1, (EIF_REFERENCE) &ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(7);
		tr1 = RTMS32_EX_H("p\000\000\000r\000\000\000e\000\000\000f\000\000\000e\000\000\000r\000\000\000e\000\000\000n\000\000\000c\000\000\000e\000\000\000 \000\000\000s\000\000\000h\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000h\000\000\000a\000\000\000v\000\000\000e\000\000\000 \000\000\000t\000\000\000w\000\000\000o\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000s\000\000\000:\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000a\000\000\000n\000\000\000d\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000",52,385982565);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EW_PREFERENCE_INST}.execute */
void F58_755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 57, Current, 0, 1, 831);
	RTHOOK(1);
	F907_6203(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_6_), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(2);
	RTEE;
}

/* {EW_PREFERENCE_INST}.init_ok */
EIF_BOOLEAN F58_756 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_);
}


/* {EW_PREFERENCE_INST}.execute_ok */
EIF_BOOLEAN F58_757 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit39 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
