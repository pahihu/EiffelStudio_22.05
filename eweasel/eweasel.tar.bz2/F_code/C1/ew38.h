
#ifndef _C1_ew38_
#define _C1_ew38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F57_750(EIF_REFERENCE, EIF_REFERENCE);
extern void F57_751(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F57_752(EIF_REFERENCE);
extern EIF_BOOLEAN F57_753(EIF_REFERENCE);
extern void EIF_Minit38(void);
extern EIF_REFERENCE F899_5995(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F890_5592(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
