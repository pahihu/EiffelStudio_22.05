/*
 * Code for class EW_EWEASEL_OUTPUT_CONTROL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_OUTPUT_CONTROL}.make */
void F11_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 10, Current, 0, 1, 249);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.flush */
void F11_252 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("flush", 10, Current, 0, 0, 251);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(384,F27_384, (RTCV(RTOSCF(24,F1_24, (Current)))));
	F557_3052(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.update */
void F11_253 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("update", 10, Current, 0, 0, 252);
	RTHOOK(1);
	F11_252(Current);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append */
void F11_254 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("append", 10, Current, 0, 2, 253);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(24,F1_24, (Current));
	F27_414(RTCW(tr1), arg1);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		F27_437(RTCV(RTOSCF(24,F1_24, (Current))));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_32 */
void F11_255 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	struct eif_ex_30 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(50, 0x00).id);
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("append_32", 10, Current, 1, 2, 254);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F51_640(RTCW(loc1), arg1);
	F27_414(RTCW(tr1), tr2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		F27_437(RTCV(RTOSCF(24,F1_24, (Current))));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_error */
void F11_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("append_error", 10, Current, 0, 2, 255);
	RTHOOK(1);
	F11_254(Current, arg1, arg2);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_error_32 */
void F11_257 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("append_error_32", 10, Current, 0, 2, 256);
	RTHOOK(1);
	F11_255(Current, arg1, arg2);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_new_line */
void F11_258 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("append_new_line", 10, Current, 0, 0, 257);
	RTGC;
	RTHOOK(1);
	F27_437(RTCV(RTOSCF(24,F1_24, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
