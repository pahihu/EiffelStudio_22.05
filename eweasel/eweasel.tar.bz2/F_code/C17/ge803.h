
#ifndef _C17_ge803_
#define _C17_ge803_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F311_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F311_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F311_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F311_2789(EIF_REFERENCE);
extern void F311_2792(EIF_REFERENCE);
extern void EIF_Minit803(void);

#ifdef __cplusplus
}
#endif

#endif
