
#ifndef _C17_re843_
#define _C17_re843_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F531_2941(EIF_REFERENCE);
extern void F531_2943(EIF_REFERENCE);
extern void EIF_Minit843(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
