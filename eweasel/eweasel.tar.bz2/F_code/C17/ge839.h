
#ifndef _C17_ge839_
#define _C17_ge839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F312_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F312_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F312_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F312_2789(EIF_REFERENCE);
extern void F312_2792(EIF_REFERENCE);
extern void EIF_Minit839(void);

#ifdef __cplusplus
}
#endif

#endif
