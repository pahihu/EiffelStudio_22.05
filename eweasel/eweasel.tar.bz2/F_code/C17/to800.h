
#ifndef _C17_to800_
#define _C17_to800_

#ifdef __cplusplus
extern "C" {
#endif

extern void F201_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F201_2351(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F201_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit800(void);
extern void F694_3933(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
