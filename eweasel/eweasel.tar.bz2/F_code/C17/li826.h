
#ifndef _C17_li826_
#define _C17_li826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F386_2843(EIF_REFERENCE, EIF_REAL_32);
extern EIF_BOOLEAN F386_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F386_2849(EIF_REFERENCE);
extern void EIF_Minit826(void);
extern EIF_REAL_32 F670_3624(EIF_REFERENCE);
extern EIF_BOOLEAN F505_2928(EIF_REFERENCE);
extern EIF_BOOLEAN F631_3442(EIF_REFERENCE);
extern void F670_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F607_3418(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
