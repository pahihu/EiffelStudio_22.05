
#ifndef _C17_co828_
#define _C17_co828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F362_2830(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
