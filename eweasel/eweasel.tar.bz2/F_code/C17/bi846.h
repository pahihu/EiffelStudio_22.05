
#ifndef _C17_bi846_
#define _C17_bi846_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F398_2857(EIF_REFERENCE);
extern void F398_2860(EIF_REFERENCE, EIF_REAL_32);
extern void EIF_Minit846(void);
extern EIF_BOOLEAN F631_3443(EIF_REFERENCE);
extern EIF_BOOLEAN F631_3442(EIF_REFERENCE);
extern void F386_2843(EIF_REFERENCE, EIF_REAL_32);
extern EIF_BOOLEAN F505_2928(EIF_REFERENCE);
extern void F670_3652(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
