
#ifndef _C17_re807_
#define _C17_re807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F530_2941(EIF_REFERENCE);
extern void F530_2943(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
