/*
 * Code for class RESIZABLE [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re807.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RESIZABLE}.additional_space */
EIF_INTEGER_32 F530_2941 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("additional_space", 529, Current, 0, 0, 4099);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2564[Dtype(Current)-584])(Current);
	Result = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 5L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RESIZABLE}.automatic_grow */
void F530_2943 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("automatic_grow", 529, Current, 0, 0, 4101);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2564[dtype-584])(Current);
	ti4_2 = F530_2941(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2570[dtype-584])(Current, (EIF_INTEGER_32) (ti4_1 + ti4_2));
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
