
#ifndef _C17_ar806_
#define _C17_ar806_

#ifdef __cplusplus
extern "C" {
#endif

extern void F323_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F323_2798(EIF_REFERENCE);
extern EIF_REFERENCE F323_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F323_2802(EIF_REFERENCE);
extern void EIF_Minit806(void);
extern EIF_INTEGER_32 F669_3642(EIF_REFERENCE);
extern EIF_REFERENCE F669_3623(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
