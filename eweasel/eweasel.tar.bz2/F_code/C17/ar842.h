
#ifndef _C17_ar842_
#define _C17_ar842_

#ifdef __cplusplus
extern "C" {
#endif

extern void F324_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F324_2798(EIF_REFERENCE);
extern EIF_REFERENCE F324_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F324_2802(EIF_REFERENCE);
extern void EIF_Minit842(void);
extern EIF_REFERENCE F670_3623(EIF_REFERENCE);
extern EIF_INTEGER_32 F670_3642(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
