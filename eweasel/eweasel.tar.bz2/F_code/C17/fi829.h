
#ifndef _C17_fi829_
#define _C17_fi829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F505_2928(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
