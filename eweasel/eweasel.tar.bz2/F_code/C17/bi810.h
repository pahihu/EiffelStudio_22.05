
#ifndef _C17_bi810_
#define _C17_bi810_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F397_2857(EIF_REFERENCE);
extern void F397_2860(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit810(void);
extern EIF_BOOLEAN F504_2928(EIF_REFERENCE);
extern EIF_BOOLEAN F630_3443(EIF_REFERENCE);
extern void F385_2843(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F630_3442(EIF_REFERENCE);
extern void F669_3652(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
