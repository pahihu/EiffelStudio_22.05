
#ifndef _C17_to836_
#define _C17_to836_

#ifdef __cplusplus
extern "C" {
#endif

extern void F202_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F202_2351(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern void F202_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit836(void);
extern void F695_3933(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
