
#ifndef _C17_re823_
#define _C17_re823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F292_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F292_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F292_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F292_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F292_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F292_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F292_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F292_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F292_2752(EIF_REFERENCE);
extern void F292_2754(EIF_REFERENCE);
extern void F292_2756(EIF_REFERENCE);
extern void F292_2757(EIF_REFERENCE);
extern void EIF_Minit823(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
