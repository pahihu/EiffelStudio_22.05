
#ifndef _C17_ty824_
#define _C17_ty824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F280_2731(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern EIF_INTEGER_32 F312_2779(EIF_REFERENCE);
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
