
#ifndef _C7_ti318_
#define _C7_ti318_

#ifdef __cplusplus
extern "C" {
#endif

extern void F917_6401(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F917_6411(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit318(void);
extern void F74_930(EIF_REFERENCE, EIF_INTEGER_32);
extern void F74_932(EIF_REFERENCE, EIF_INTEGER_32);
extern void F74_931(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
