/*
 * Code for class EW_EIFFEL_COMPILATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew328.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EIFFEL_COMPILATION}.make */
void F927_6598 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 926, Current, 0, 4, 12528);
	RTHOOK(1);
	F924_6571(Current, arg1, arg2, arg3, NULL, NULL, arg4);
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.next_compile_result_type */
EIF_REFERENCE F927_6599 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_compile_result_type", 926, Current, 0, 0, 12529);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_EIFFEL_COMPILATION}.next_compile_result */
EIF_REFERENCE F927_6600 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_compile_result", 926, Current, 0, 0, 12530);
	RTGC;
	RTHOOK(1);
	Result = F924_6578(Current);
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1274[Dtype(RTCW(Result))-105])(Result);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = F924_6584(Current);
		F106_1387(RTCW(Result), tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_COMPILATION}.resume */
void F927_6601 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("resume", 926, Current, 0, 0, 12531);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("\012",1,10);
	F924_6574(Current, tr1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.quit */
void F927_6602 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("quit", 926, Current, 0, 0, 12532);
	RTGC;
	RTHOOK(1);
	F924_6574(Current, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.abort */
void F927_6603 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("abort", 926, Current, 0, 0, 12524);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
		RTHOOK(2);
		F927_6602(Current);
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4971[Dtype(Current)-924])(Current);
		{
			/* INLINED CODE (ANY.do_nothing) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	F924_6576(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.terminate */
void F927_6604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("terminate", 926, Current, 0, 0, 12525);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
		RTHOOK(2);
		F927_6602(Current);
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4971[Dtype(Current)-924])(Current);
		{
			/* INLINED CODE (ANY.do_nothing) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	F924_6575(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.read_chunk */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F927_6605 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 EIF_VOLATILE loc7 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEAA("read_chunk", 926, Current, 7, 0, 12526);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5663(RTCW(tr1), ((EIF_INTEGER_32) 128L));
		loc5 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == (EIF_CHARACTER_8) '\012') || *(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) || loc2)) break;
			RTHOOK(5);
			F924_6588(Current);
			RTHOOK(6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
				RTHOOK(7);
				loc7 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_7_0_);
				RTHOOK(8);
				if ((EIF_BOOLEAN)(loc7 != (EIF_CHARACTER_8) '\015')) {
					RTHOOK(9);
					F895_5790(RTCW(loc5), loc7);
					RTHOOK(10);
					loc6++;
					RTHOOK(11);
					loc3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(991,F81_991, (Current)))+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc6 == ti4_1)) {
						tr1 = RTOSCF(991,F81_991, (Current));
						tb1 = F893_5691(RTCW(loc5), tr1);
						loc3 = tb1;
					}
					RTHOOK(12);
					loc4 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(992,F81_992, (Current)))+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc6 == ti4_1)) {
						tr1 = RTOSCF(992,F81_992, (Current));
						tb1 = F893_5691(RTCW(loc5), tr1);
						loc4 = tb1;
					}
					RTHOOK(13);
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || loc4);
				}
			}
		}
	}
	RTHOOK(14);
	if (loc2) {
		RTHOOK(15);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(16);
		if (loc3) {
			RTHOOK(17);
			tr1 = RTMS_EX_H("q\012",2,28938);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(18);
			tr1 = RTMS_EX_H("n\012",2,28170);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(19);
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc5;
	RTE_E
	RTXSC;
	RTHOOK(20);
	if ((EIF_BOOLEAN)(F117_1481(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(21);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(22);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(23);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(24);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
