/*
 * Code for class EW_EIFFEL_EWEASEL_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew308.h"
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F82_1014
static EIF_INTEGER_32 inline_F82_1014 (void)
{
	time_t current_time;

  				current_time = time(&current_time);
  				if (current_time == (time_t) -1) {
    					eraise("time() call failed", EN_PROG);
  				}
  				return (EIF_INTEGER) current_time;
	;
}
#define INLINE_F82_1014
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EIFFEL_EWEASEL_TEST}.make */
void F907_6169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 906, Current, 0, 1, 12135);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F907_6178(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.execute */
void F907_6171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTEAA("execute", 906, Current, 5, 1, 12137);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2507[Dtype(RTCW(tr1))-557])(tr1);
	for (;;) {
		RTHOOK(5);
		tb1 = '\01';
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2518[Dtype(RTCW(tr1))-493])(tr1);
		if (!tb3) {
			tb2 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_);
		}
		if (!tb2) {
			tb1 = loc5;
		}
		if (tb1) break;
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2541[Dtype(RTCW(tr1))-493])(tr1);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R707[Dtype(RTCW(loc1))-54])(loc1, Current);
		RTHOOK(8);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R709[Dtype(RTCW(loc1))-54])(loc1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) tb2;
		RTHOOK(9);
		loc5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R710[Dtype(RTCW(loc1))-54])(loc1);
		RTHOOK(10);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2520[Dtype(RTCW(tr1))-493])(tr1);
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_)) {
		RTHOOK(12);
		if ((EIF_BOOLEAN) !loc5) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2519[Dtype(RTCW(tr1))-646])(tr1);
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2541[Dtype(RTCW(tr1))-493])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R707[Dtype(RTCW(tr1))-54])(tr1, Current);
		}
		RTHOOK(15);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(16);
			RTCT0("from_loop_invariant", EX_CHECK);
				RTCF0;
		}
		RTHOOK(17);
		loc3 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F890_5533(RTCW(loc3));
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		F899_5976(RTCW(loc3), tr1);
		RTHOOK(19);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F899_5990(RTCW(loc3), tw1);
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		F899_5976(RTCW(loc3), tr1);
		RTHOOK(21);
		loc4 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F890_5533(RTCW(loc4));
		RTHOOK(22);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		tr1 = F890_5592(RTCW(tr1));
		F899_5976(RTCW(loc4), tr1);
		RTHOOK(23);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F899_5990(RTCW(loc4), tw1);
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
		F899_5976(RTCW(loc4), tr1);
		RTHOOK(25);
		loc2 = RTLNS(eif_new_type(234, 0x00).id, 234, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O719[Dtype(loc1)-53]);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F234_2639(RTCW(loc2), tr1, ti4_1, loc3, loc4, tr2);
		RTHOOK(26);
		F907_6217(Current, loc2);
	}
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.copy_wait_required */
EIF_BOOLEAN F907_6175 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("copy_wait_required", 906, Current, 0, 0, 12141);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_)) {
		ti4_1 = inline_F82_1014();
		Result = (EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_2_));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.unset_copy_wait */
void F907_6176 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unset_copy_wait", 906, Current, 0, 0, 12142);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_defaults */
void F907_6178 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_defaults", 906, Current, 0, 0, 12092);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {677,896,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F673_3703(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(2651,F237_2651, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTOSCF(2650,F237_2650, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.e_compile_output_name */
EIF_REFERENCE F907_6190 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("e_compile_output_name", 906, Current, 0, 0, 12104);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F897_5861(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOSCF(6218,F907_6218, (Current));
	F899_5976(RTCW(Result), tr1);
	RTHOOK(3);
	F899_5979(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_1_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.c_compile_output_name */
EIF_REFERENCE F907_6191 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("c_compile_output_name", 906, Current, 0, 0, 12105);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F897_5861(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOSCF(6219,F907_6219, (Current));
	F899_5976(RTCW(Result), tr1);
	RTHOOK(3);
	F899_5979(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_3_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.execution_output_name */
EIF_REFERENCE F907_6192 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("execution_output_name", 906, Current, 0, 0, 12106);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F897_5861(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOSCF(6220,F907_6220, (Current));
	F899_5976(RTCW(Result), tr1);
	RTHOOK(3);
	F899_5979(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_4_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_test_name */
void F907_6198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_test_name", 906, Current, 0, 1, 12112);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_test_description */
void F907_6199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_test_description", 906, Current, 0, 1, 12113);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_system_name */
void F907_6200 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_system_name", 906, Current, 0, 1, 12114);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_ace_name */
void F907_6201 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_ace_name", 906, Current, 0, 1, 12115);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_target_name */
void F907_6202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTEAA("set_target_name", 906, Current, 1, 1, 12116);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(4053,F744_4053, (Current));
	loc1 = F657_3579(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = RTOSCF(4062,F745_4062, (Current));
	tr2 = RTOSCF(2653,F237_2653, (Current));
	tr1 = F211_2545(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTOSCF(4062,F745_4062, (Current));
	tr1 = F211_2545(RTCW(tr1), loc1, arg1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(4056,F744_4056, (Current));
	tr3 = RTOSCF(4062,F745_4062, (Current));
	tr4 = RTOSCF(2654,F237_2654, (Current));
	tr3 = F211_2545(RTCW(tr3), loc1, tr4);
	F657_3572(RTCW(tr1), tr2, tr3);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(4057,F744_4057, (Current));
	tr3 = RTOSCF(4062,F745_4062, (Current));
	tr4 = RTOSCF(2655,F237_2655, (Current));
	tr3 = F211_2545(RTCW(tr3), loc1, tr4);
	F657_3572(RTCW(tr1), tr2, tr3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_preference */
void F907_6203 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("set_preference", 906, Current, 0, 2, 12117);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F673_3750(RTCW(tr1), arg2, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_cpu_limit */
void F907_6204 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_cpu_limit", 906, Current, 0, 1, 12118);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compilation */
void F907_6205 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_e_compilation", 906, Current, 0, 1, 12119);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compile_start_time */
void F907_6206 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_e_compile_start_time", 906, Current, 0, 1, 12120);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_c_compilation */
void F907_6207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_c_compilation", 906, Current, 0, 1, 12121);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compilation_result */
void F907_6208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_e_compilation_result", 906, Current, 0, 1, 12122);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_c_compilation_result */
void F907_6209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_c_compilation_result", 906, Current, 0, 1, 12123);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_execution_result */
void F907_6210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_execution_result", 906, Current, 0, 1, 12124);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_instructions */
void F907_6211 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_instructions", 906, Current, 0, 1, 12125);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_e_compile_count */
void F907_6212 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_e_compile_count", 906, Current, 0, 0, 12126);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_1_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_c_compile_count */
void F907_6213 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_c_compile_count", 906, Current, 0, 0, 12127);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_3_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_execution_count */
void F907_6214 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_execution_count", 906, Current, 0, 0, 12128);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_4_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.add_error */
void F907_6217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_error", 906, Current, 0, 1, 12131);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(232, 0).id);
		F233_2633(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2634(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.eiffel_compile_output_prefix */

EIF_REFERENCE F907_6218 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6218,RTMS32_EX_H("e\000\000\000_\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000i\000\000\000l\000\000\000e\000\000\000",9,2077996133));
}

/* {EW_EIFFEL_EWEASEL_TEST}.c_compile_output_prefix */

EIF_REFERENCE F907_6219 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6219,RTMS32_EX_H("c\000\000\000_\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000i\000\000\000l\000\000\000e\000\000\000",9,1960031333));
}

/* {EW_EIFFEL_EWEASEL_TEST}.execution_output_prefix */

EIF_REFERENCE F907_6220 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6220,RTMS32_EX_H("e\000\000\000x\000\000\000e\000\000\000c\000\000\000u\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",9,986487406));
}

void EIF_Minit308 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
