
#ifndef _C7_ty338_
#define _C7_ty338_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F270_2731(EIF_REFERENCE);
extern void EIF_Minit338(void);
extern char *(*R2467[])();
extern char *(*R2454[])();
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
