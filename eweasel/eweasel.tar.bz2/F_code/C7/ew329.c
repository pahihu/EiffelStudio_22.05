/*
 * Code for class EW_CODE_ANALYSIS_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew329.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_CODE_ANALYSIS_PROCESS}.next_analysis_result_type */
EIF_REFERENCE F928_6607 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_analysis_result_type", 927, Current, 0, 0, 12533);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_CODE_ANALYSIS_PROCESS}.next_analysis_result */
EIF_REFERENCE F928_6608 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_analysis_result", 927, Current, 0, 0, 12534);
	RTGC;
	RTHOOK(1);
	Result = F927_6600(Current);
	RTHOOK(2);
	tb1 = F107_1409(RTCW(Result));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = F924_6584(Current);
		F106_1387(RTCW(Result), tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
