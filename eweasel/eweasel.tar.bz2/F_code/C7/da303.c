/*
 * Code for class DATE_TIME_CODE_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "da303.h"
#include <math.h>
#include "eif_built_in.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DATE_TIME_CODE_STRING}.make */
void F902_6094 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,arg1);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTEAA("make", 901, Current, 7, 1, 12032);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {673,681,844,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F674_3703(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc4 = RTLNS(eif_new_type(74, 0x00).id, 74, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(4);
	tr1 = F75_947(RTCW(loc4));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = F75_948(RTCW(loc4));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(7);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4363[Dtype(arg1)-892]);
		if ((EIF_BOOLEAN) (loc2 >= ti4_1)) break;
		RTHOOK(8);
		loc3 = F901_6091(Current, arg1, loc2);
		RTHOOK(9);
		loc5 = F901_6092(Current, arg1, loc2, loc3);
		RTHOOK(10);
		ti4_2 = eif_abs_int32 (loc3);
		loc3 = (EIF_INTEGER_32) ti4_2;
		RTHOOK(11);
		loc6 = eif_boxed_item(loc5,1);
		RTHOOK(12);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O4363[Dtype(loc6)-892]);
		if ((EIF_BOOLEAN) (ti4_2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTLNS(eif_new_type(681, 0x00).id, 681, _OBJSIZ_2_2_0_5_0_0_0_0_);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4262[Dtype(RTCW(loc6))-893])(loc6);
			F682_3835(RTCW(tr2), tr3);
			F674_3749(RTCW(tr1), tr2, loc1);
			RTHOOK(14);
			loc1++;
		}
		RTHOOK(15);
		loc7 = eif_boxed_item(loc5,2);
		RTHOOK(16);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O4363[Dtype(loc7)-892]);
		if ((EIF_BOOLEAN) (ti4_2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTLNS(eif_new_type(681, 0x00).id, 681, _OBJSIZ_2_2_0_5_0_0_0_0_);
			F682_3835(RTCW(tr2), loc7);
			F674_3749(RTCW(tr1), tr2, loc1);
			RTHOOK(18);
			loc1++;
			RTHOOK(19);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(20);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(21);
	tr1 = RTLNS(eif_new_type(2, 0x00).id, 2, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F3_46(RTCW(tr1));
	ti4_2 = F3_50(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 100L)) * ((EIF_INTEGER_32) -100L));
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {DATE_TIME_CODE_STRING}.create_string */
EIF_REFERENCE F902_6105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc7);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTEAA("create_string", 901, Current, 7, 1, 12043);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F893_5663(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTHOOK(3);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(4);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc7 = F674_3709(RTCW(tr1), loc4);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc7 == NULL)) break;
		RTHOOK(7);
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_4_);
		RTHOOK(8);
		switch (loc5) {
			case 1L:
				RTHOOK(9);
				ti4_1 = F672_3685(RTCW(loc1));
				tr1 = eif_out__i4_s1(ti4_1);
				F895_5776(RTCW(Result), tr1);
				break;
			case 2L:
				RTHOOK(10);
				loc3 = F672_3685(RTCW(loc1));
				RTHOOK(11);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
					RTHOOK(12);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(13);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 3L:
				RTHOOK(14);
				loc3 = F919_6457(RTCW(loc1));
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F585_3350(RTCW(tr1), loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 4L:
				RTHOOK(16);
				ti4_1 = F672_3687(RTCW(loc1));
				loc6 = eif_out__i4_s1(ti4_1);
				RTHOOK(17);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
					RTHOOK(18);
					F895_5776(RTCW(Result), loc6);
				} else {
					RTHOOK(19);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(20);
						tr1 = RTMS_EX_H("000",3,3158064);
						F895_5776(RTCW(Result), tr1);
						RTHOOK(21);
						F895_5776(RTCW(Result), loc6);
					} else {
						RTHOOK(22);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
							RTHOOK(23);
							tr1 = RTMS_EX_H("00",2,12336);
							F895_5776(RTCW(Result), tr1);
							RTHOOK(24);
							F895_5776(RTCW(Result), loc6);
						} else {
							RTHOOK(25);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
								RTHOOK(26);
								tr1 = RTMS_EX_H("0",1,48);
								F895_5776(RTCW(Result), tr1);
								RTHOOK(27);
								F895_5776(RTCW(Result), loc6);
							}
						}
					}
				}
				break;
			case 5L:
				RTHOOK(28);
				ti4_1 = F672_3687(RTCW(loc1));
				loc6 = eif_out__i4_s1(ti4_1);
				RTHOOK(29);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
					RTHOOK(30);
					F895_5759(RTCW(loc6), ((EIF_INTEGER_32) 2L));
				} else {
					RTHOOK(31);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(32);
						F895_5789(RTCW(Result), (EIF_CHARACTER_8) '0');
					}
				}
				RTHOOK(33);
				F895_5776(RTCW(Result), loc6);
				break;
			case 6L:
				RTHOOK(34);
				ti4_1 = F672_3686(RTCW(loc1));
				tr1 = eif_out__i4_s1(ti4_1);
				F895_5776(RTCW(Result), tr1);
				break;
			case 7L:
				RTHOOK(35);
				loc3 = F672_3686(RTCW(loc1));
				RTHOOK(36);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
					RTHOOK(37);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(38);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 8L:
				RTHOOK(39);
				loc3 = F672_3686(RTCW(loc1));
				RTHOOK(40);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F585_3350(RTCW(tr1), loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 9L:
				RTHOOK(41);
				ti4_1 = F74_921(RTCW(loc2));
				tr1 = eif_out__i4_s1(ti4_1);
				F895_5776(RTCW(Result), tr1);
				break;
			case 10L:
				RTHOOK(42);
				loc3 = F74_921(RTCW(loc2));
				RTHOOK(43);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
					RTHOOK(44);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(45);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 11L:
			case 12L:
				RTHOOK(46);
				loc3 = F74_921(RTCW(loc2));
				RTHOOK(47);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 12L))) {
					RTHOOK(48);
					if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
						RTHOOK(49);
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
					}
				} else {
					RTHOOK(50);
					if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 12L))) {
						RTHOOK(51);
						loc3 -= ((EIF_INTEGER_32) 12L);
					}
				}
				RTHOOK(52);
				tb1 = '\0';
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_8) 12U);
				if ((EIF_BOOLEAN)(loc5 == ti4_1)) {
					tb1 = (EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L));
				}
				if (tb1) {
					RTHOOK(53);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(54);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 13L:
				RTHOOK(55);
				ti4_1 = F74_922(RTCW(loc2));
				tr1 = eif_out__i4_s1(ti4_1);
				F895_5776(RTCW(Result), tr1);
				break;
			case 14L:
				RTHOOK(56);
				loc3 = F74_922(RTCW(loc2));
				RTHOOK(57);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
					RTHOOK(58);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(59);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 15L:
				RTHOOK(60);
				ti4_1 = F74_923(RTCW(loc2));
				tr1 = eif_out__i4_s1(ti4_1);
				F895_5776(RTCW(Result), tr1);
				break;
			case 16L:
				RTHOOK(61);
				loc3 = F74_923(RTCW(loc2));
				RTHOOK(62);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
					RTHOOK(63);
					tr1 = RTMS_EX_H("0",1,48);
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(64);
				tr1 = eif_out__i4_s1(loc3);
				F895_5776(RTCW(Result), tr1);
				break;
			case 17L:
				RTHOOK(65);
				tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_0_0_0_1_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
				tr8_2 = (EIF_REAL_64) (ti4_1);
				tr1 = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_0_0_0_0_1_);
				*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (tr8_1 * (EIF_REAL_64) pow ((EIF_REAL_64) (((EIF_INTEGER_32) 10L)), (EIF_REAL_64) (tr8_2)));
				loc3 = F825_4810(RTCW(tr1));
				RTHOOK(66);
				loc6 = eif_out__i4_s1(loc3);
				RTHOOK(67);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
				if ((EIF_BOOLEAN) (ti4_1 < ti4_2)) {
					RTHOOK(68);
					tr1 = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					F893_5664(RTCW(tr1), (EIF_CHARACTER_8) '0', (EIF_INTEGER_32) (ti4_1 - ti4_2));
					F895_5776(RTCW(Result), tr1);
				}
				RTHOOK(69);
				F895_5776(RTCW(Result), loc6);
				break;
			case 24L:
				RTHOOK(70);
				loc3 = F74_921(RTCW(loc2));
				RTHOOK(71);
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 12L))) {
					RTHOOK(72);
					tr1 = RTMS_EX_H("AM",2,16717);
					F895_5776(RTCW(Result), tr1);
				} else {
					RTHOOK(73);
					tr1 = RTMS_EX_H("PM",2,20557);
					F895_5776(RTCW(Result), tr1);
				}
				break;
			default:
				RTHOOK(74);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
				F895_5776(RTCW(Result), tr1);
				break;
		}
		RTHOOK(75);
		loc4++;
		RTHOOK(76);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc7 = F674_3709(RTCW(tr1), loc4);
	}
	RTHOOK(79);
	RTLE;
	RTEE;
	return Result;
}

/* {DATE_TIME_CODE_STRING}.create_date_string */
EIF_REFERENCE F902_6106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("create_date_string", 901, Current, 0, 1, 12044);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_2_0_0_2_0_0_0_1_);
	F922_6515(RTCW(tr1), arg1);
	Result = F902_6105(Current, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit303 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
