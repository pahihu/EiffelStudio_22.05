/*
 * Code for class CONTAINER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F352_2830 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 351, Current, 0, 0, 3546);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2499[Dtype(Current)-351]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
