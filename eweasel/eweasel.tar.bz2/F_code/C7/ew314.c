/*
 * Code for class EW_UNIX_PIPE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew314.h"
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F82_1010
static void inline_F82_1010 (EIF_INTEGER_32 arg1)
{
	int rc;
rc = close(arg1);
if (rc != 0) {
	xraise(EN_SYS);
}
	;
}
#define INLINE_F82_1010
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_UNIX_PIPE}.make */
void F913_6319 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 912, Current, 0, 2, 12244);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg2;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_UNIX_PIPE}.close_read_descriptor */
void F913_6322 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close_read_descriptor", 912, Current, 0, 0, 12247);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) != ((EIF_INTEGER_32) -1L))) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
		inline_F82_1010(ti4_1);
		RTHOOK(3);
		F913_6324(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_UNIX_PIPE}.close_write_descriptor */
void F913_6323 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close_write_descriptor", 912, Current, 0, 0, 12248);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) != ((EIF_INTEGER_32) -1L))) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_);
		inline_F82_1010(ti4_1);
		RTHOOK(3);
		F913_6325(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_UNIX_PIPE}.erase_read_descriptor */
void F913_6324 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("erase_read_descriptor", 912, Current, 0, 0, 12241);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	RTEE;
}

/* {EW_UNIX_PIPE}.erase_write_descriptor */
void F913_6325 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("erase_write_descriptor", 912, Current, 0, 0, 12242);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	RTEE;
}

/* {EW_UNIX_PIPE}.dispose */
void F913_6326 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 912, Current, 0, 0, 12243);
	RTGC;
	RTHOOK(1);
	F913_6322(Current);
	RTHOOK(2);
	F913_6323(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
