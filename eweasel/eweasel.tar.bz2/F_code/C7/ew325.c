/*
 * Code for class EW_EWEASEL_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew325.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_PROCESS}.make */
void F924_6571 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,arg6);
	RTLIU(9);
	
	RTEAA("make", 923, Current, 3, 6, 12517);
	RTGC;
	RTHOOK(1);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2561[Dtype(RTCW(arg2))-557])(arg2);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {584,896,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F585_3345(RTCW(loc1), NULL, ((EIF_INTEGER_32) 1L), loc3);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2507[Dtype(RTCW(arg2))-557])(arg2);
	RTHOOK(4);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2518[Dtype(RTCW(arg2))-493])(arg2);
		if (tb1) break;
		RTHOOK(6);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2541[Dtype(RTCW(arg2))-493])(arg2);
		F585_3369(RTCW(loc1), tr1, loc2);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2520[Dtype(RTCW(arg2))-493])(arg2);
		RTHOOK(8);
		loc2++;
	}
	RTHOOK(9);
	tr1 = RTLNSMART(eif_new_type(211, 0).id);
	F212_2553(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current);
	F212_2577(RTCW(tr1), loc1);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current);
	F212_2578(RTCW(tr1), arg3);
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current);
	F212_2579(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTHOOK(13);
	if ((EIF_BOOLEAN)(arg4 == NULL)) {
		RTHOOK(14);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2583(RTCW(tr1));
	} else {
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2580(RTCW(tr1), arg4);
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN)(arg5 == NULL)) {
		RTHOOK(17);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2584(RTCW(tr1));
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2586(RTCW(tr1));
	} else {
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2581(RTCW(tr1), arg5);
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2586(RTCW(tr1));
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current);
	F212_2587(RTCW(tr1));
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_17_2_);
	if (tb2) {
		RTHOOK(23);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F212_2574(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(24);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(25);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_17_1_);
	if (tb2) {
		RTHOOK(26);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F212_2575(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(27);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(28);
	if ((EIF_BOOLEAN)(arg6 != NULL)) {
		RTHOOK(29);
		tr1 = RTLNSMART(eif_new_type(557, 0).id);
		F557_2957(RTCW(tr1), arg6);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(30);
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg6;
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.put_string */
void F924_6574 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string", 923, Current, 0, 1, 12498);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F557_3063(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F557_3052(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.terminate */
void F924_6575 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("terminate", 923, Current, 0, 0, 12499);
	RTGC;
	RTHOOK(1);
	F924_6585(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2588(RTCW(tr1));
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current + O4965[Dtype(Current)-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.abort */
void F924_6576 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("abort", 923, Current, 0, 0, 12500);
	RTGC;
	RTHOOK(1);
	F924_6585(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		RTHOOK(3);
		F924_6586(Current);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2588(RTCW(tr1));
		RTHOOK(5);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current + O4965[Dtype(Current)-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.next_result */
EIF_REFERENCE F924_6578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_result", 923, Current, 1, 0, 12502);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(eif_final_id(Y4970,Y4970_gen_type,Dftype(Current),923).id);
	F1_29(RTCW(Result));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4980[dtype-924])(Current);
	for (;;) {
		RTHOOK(3);
		if (loc1) break;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F557_3063(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F557_3052(RTCW(tr1));
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1237[Dtype(RTCW(Result))-103])(Result, *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(7);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O4966[dtype-923]) || *(EIF_BOOLEAN *)(Current + O4965[dtype-923]))) {
			RTHOOK(8);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4980[dtype-924])(Current);
		}
	}
	RTHOOK(10);
	if (*(EIF_BOOLEAN *)(Current + O4966[dtype-923])) {
		RTHOOK(11);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4968[dtype-924])(Current);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EWEASEL_PROCESS}.savefile_contents */
EIF_REFERENCE F924_6584 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("savefile_contents", 923, Current, 1, 0, 12508);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(557, 0x00).id, 557, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F557_2956(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F893_5663(RTCW(Result), ((EIF_INTEGER_32) 100L));
	for (;;) {
		RTHOOK(3);
		tb1 = F557_2988(RTCW(loc1));
		if (tb1) break;
		RTHOOK(4);
		F557_3103(RTCW(loc1), ((EIF_INTEGER_32) 4096L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		F895_5776(RTCW(Result), tr1);
	}
	RTHOOK(6);
	F557_3041(RTCW(loc1));
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EWEASEL_PROCESS}.close */
void F924_6585 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("close", 923, Current, 0, 0, 12509);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb2 = F557_3013(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F557_3041(RTCW(tr1));
	}
	RTHOOK(3);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb2 = F557_3013(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F557_3041(RTCW(tr1));
	}
	RTHOOK(5);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = F557_3013(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F557_3041(RTCW(tr1));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.try_to_terminate */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F924_6586 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("try_to_terminate", 923, Current, 1, 0, 12510);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F212_2590(RTCW(tr1));
	}
	RTE_E
	RTXSC;
	RTHOOK(3);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(5);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EW_EWEASEL_PROCESS}.read_chunk */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F924_6587 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("read_chunk", 923, Current, 1, 0, 12511);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F557_3105(RTCW(tr1), ((EIF_INTEGER_32) 4096L));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F557_2988(RTCW(tr1));
		if (tb1) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current + O4966[dtype-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(F117_1481(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(7);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current + O4966[dtype-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		RTHOOK(10);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(11);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EW_EWEASEL_PROCESS}.read_character */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F924_6588 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_CHARACTER_8  EIF_VOLATILE tc1;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("read_character", 923, Current, 1, 0, 12512);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F557_3096(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F557_2988(RTCW(tr1));
		if (tb1) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current + O4966[dtype-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(tr1)+ _CHROFF_4_0_);
		*(EIF_CHARACTER_8 *)(Current + O4983[dtype-923]) = (EIF_CHARACTER_8) tc1;
	}
	RTE_E
	RTXSC;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(F117_1481(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(7);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current + O4966[dtype-923]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		*(EIF_CHARACTER_8 *)(Current + O4983[dtype-923]) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
		RTHOOK(10);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(11);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit325 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
