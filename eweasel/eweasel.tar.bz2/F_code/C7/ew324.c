/*
 * Code for class EW_TEST_CATALOG_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew324.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_CATALOG_FILE}.make */
void F923_6548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 922, Current, 0, 1, 12473);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.parse */
void F923_6553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("parse", 922, Current, 1, 1, 12478);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(557, 0x00).id, 557, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F557_2955(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(4);
	tb1 = F557_2989(RTCW(loc1));
	if (tb1) {
		RTHOOK(5);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
		RTHOOK(6);
		F923_6555(Current, loc1);
	} else {
		RTHOOK(7);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(8);
		tr1 = RTLNS(eif_new_type(235, 0x00).id, 235, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr2 = RTMS32_EX_H("F\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000o\000\000\000u\000\000\000n\000\000\000d\000\000\000:\000\000\000 \000\000\000",16,1014623520);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr3 = F780_4249(RTCW(tr3));
		tr2 = F899_5995(tr2, tr3);
		F234_2638(RTCW(tr1), tr2);
		F923_6557(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.parse_existing_file */
void F923_6555 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("parse_existing_file", 922, Current, 3, 1, 12480);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F557_3024(RTCW(arg1));
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {646,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F647_3462(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	for (;;) {
		RTHOOK(5);
		tb1 = '\01';
		tb2 = F557_2988(RTCW(arg1));
		if (!tb2) {
			tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_);
		}
		if (tb1) break;
		RTHOOK(6);
		F557_3100(RTCW(arg1));
		RTHOOK(7);
		tb2 = F557_2988(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(8);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_))++;
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc1 = F52_716(Current, tr1);
			RTHOOK(10);
			tr1 = F890_5592(RTCW(loc1));
			F923_6556(Current, tr1);
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc3 = tr1;
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) && EIF_TEST(loc3))) {
				RTHOOK(12);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(tr1))-646])(tr1, loc3);
			}
		}
	}
	RTHOOK(13);
	F557_3041(RTCW(arg1));
	RTHOOK(14);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_)) {
		RTHOOK(15);
		loc2 = RTLNS(eif_new_type(235, 0x00).id, 235, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F780_4249(RTCW(tr1));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F657_3578(RTCW(tr2), loc1);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		F234_2639(RTCW(loc2), tr1, ti4_1, loc1, tr2, tr3);
		RTHOOK(16);
		F923_6557(Current, loc2);
		RTHOOK(17);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(18);
		tr1 = RTLNSMART(eif_new_type(7, 0).id);
		F8_106(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(19);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.parse_line */
void F923_6556 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("parse_line", 922, Current, 4, 1, 12481);
	RTGC;
	RTHOOK(1);
	F892_5656(RTCW(arg1));
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	tb1 = '\01';
	tb2 = F498_2928(RTCW(arg1));
	if (!tb2) {
		tr1 = RTOSCF(6558,F923_6558, (Current));
		tb2 = F897_5896(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(5);
		loc1 = F52_705(Current, arg1);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc2 = (EIF_REFERENCE) arg1;
			RTHOOK(8);
			loc3 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F890_5533(RTCW(loc3));
		} else {
			RTHOOK(9);
			loc2 = F899_6023(RTCW(arg1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(10);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc3 = F899_6023(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		}
		RTHOOK(11);
		F899_6017(RTCW(loc2));
		RTHOOK(12);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc2;
		RTHOOK(13);
		tr1 = RTOSCF(6168,F906_6168, (Current));
		tb1 = F673_3711(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(14);
			loc2 = RTOSCF(1859,F178_1859, (Current));
		}
		
		RTHOOK(16);
		tr1 = RTOSCF(6168,F906_6168, (Current));
		tr1 = F673_3709(RTCW(tr1), loc2);
		loc4 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTHOOK(17);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc3;
		RTHOOK(18);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1454[Dtype(RTCW(loc4))-158])(loc4, Current);
		RTHOOK(19);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4) + O1455[Dtype(loc4)-157]);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
		RTHOOK(20);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_)) {
			RTHOOK(21);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.add_error */
void F923_6557 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_error", 922, Current, 0, 1, 12482);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(232, 0).id);
		F233_2633(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F233_2634(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.comment_start */

EIF_REFERENCE F923_6558 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6558,RTMS32_EX_H("-\000\000\000-\000\000\000",2,11565));
}

/* {EW_TEST_CATALOG_FILE}.set_command */
void F923_6559 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_command", 922, Current, 0, 1, 12484);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.set_arguments */
void F923_6560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_arguments", 922, Current, 0, 1, 12485);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.set_source_path */
void F923_6561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_source_path", 922, Current, 0, 1, 12486);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_CATALOG_FILE}.set_last_test */
void F923_6562 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_last_test", 922, Current, 0, 1, 12487);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit324 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
