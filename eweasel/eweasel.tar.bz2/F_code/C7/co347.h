
#ifndef _C7_co347_
#define _C7_co347_

#ifdef __cplusplus
extern "C" {
#endif

extern void F352_2830(EIF_REFERENCE);
extern void EIF_Minit347(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
