
#ifndef _C7_re337_
#define _C7_re337_

#ifdef __cplusplus
extern "C" {
#endif

extern void F282_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F282_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F282_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F282_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F282_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F282_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F282_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F282_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F282_2752(EIF_REFERENCE);
extern void F282_2754(EIF_REFERENCE);
extern void F282_2756(EIF_REFERENCE);
extern void F282_2757(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern char *(*R2775[])();
extern char *(*R2463[])();
extern char *(*R2772[])();
extern char *(*R2773[])();
extern long O2470[];
extern long O2474[];
extern long O2475[];
extern long O2476[];
extern long O2477[];
extern long O2478[];

#ifdef __cplusplus
}
#endif

#endif
