
#ifndef _C7_ew311_
#define _C7_ew311_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F910_6257(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit311(void);
extern void F756_4114(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
