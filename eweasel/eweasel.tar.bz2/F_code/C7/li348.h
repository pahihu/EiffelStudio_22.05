
#ifndef _C7_li348_
#define _C7_li348_

#ifdef __cplusplus
extern "C" {
#endif

extern void F376_2843(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F376_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F376_2849(EIF_REFERENCE);
extern void EIF_Minit348(void);
extern char *(*R2505[])();
extern char *(*R2506[])();
extern char *(*R2517[])();
extern char *(*R2518[])();
extern char *(*R2520[])();
extern char *(*R2497[])();
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
