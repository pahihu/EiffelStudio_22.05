/*
 * Code for class EW_NAMED_EIFFEL_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew309.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_NAMED_EIFFEL_TEST}.make */
void F908_6221 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLIU(6);
	
	RTEAA("make", 907, Current, 0, 5, 12151);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTHOOK(4);
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg4;
	RTHOOK(5);
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg5;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_NAMED_EIFFEL_TEST}.execute */
void F908_6222 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("execute", 907, Current, 1, 1, 12152);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(4052,F744_4052, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F657_3572(RTCW(arg1), tr1, tr2);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_10_4_0_1_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOSCF(6166,F906_6166, (Current));
	F914_6327(RTCW(loc1), tr1, NULL, tr2, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	F914_6332(RTCW(loc1), arg1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_10_0_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) tb1;
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_NAMED_EIFFEL_TEST}.has_keyword */
EIF_BOOLEAN F908_6231 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_keyword", 907, Current, 0, 1, 12143);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F352_2830(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2507[Dtype(RTCW(tr1))-557])(tr1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2513[Dtype(RTCW(tr1))-493])(tr1, arg1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	Result = F376_2847(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_NAMED_EIFFEL_TEST}.manual_execution_required */
EIF_BOOLEAN F908_6234 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("manual_execution_required", 907, Current, 0, 0, 12146);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(6237,F908_6237, (Current));
	Result = F908_6231(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_NAMED_EIFFEL_TEST}.skip_requested */
EIF_BOOLEAN F908_6235 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("skip_requested", 907, Current, 0, 0, 12147);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(6238,F908_6238, (Current));
	Result = F908_6231(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_NAMED_EIFFEL_TEST}.execution_allowed */
EIF_BOOLEAN F908_6236 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("execution_allowed", 907, Current, 0, 0, 12148);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F908_6234(Current)) {
		Result = (EIF_BOOLEAN) !F908_6235(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_NAMED_EIFFEL_TEST}.manual_keyword */

EIF_REFERENCE F908_6237 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6237,RTMS32_EX_H("m\000\000\000a\000\000\000n\000\000\000u\000\000\000a\000\000\000l\000\000\000",6,2068234092));
}

/* {EW_NAMED_EIFFEL_TEST}.skip_keyword */

EIF_REFERENCE F908_6238 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6238,RTMS32_EX_H("s\000\000\000k\000\000\000i\000\000\000p\000\000\000",4,1936419184));
}

void EIF_Minit309 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
