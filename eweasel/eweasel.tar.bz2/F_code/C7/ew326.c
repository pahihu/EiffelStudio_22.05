/*
 * Code for class EW_SYSTEM_EXECUTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew326.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_SYSTEM_EXECUTION}.make */
void F925_6592 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_REFERENCE arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg4);
	RTLR(4,arg5);
	RTLR(5,arg1);
	RTLR(6,arg2);
	RTLR(7,arg3);
	RTLR(8,arg6);
	RTLR(9,arg7);
	RTLR(10,arg8);
	RTLIU(11);
	
	RTEAA("make", 924, Current, 1, 8, 12518);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {646,896,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 646, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F647_3462(RTCW(loc1));
	RTHOOK(2);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("/\000\000\000c\000\000\000",2,12131);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, tr1);
	}
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, arg4);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, arg5);
	RTHOOK(6);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, arg1);
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2519[Dtype(RTCW(loc1))-646])(loc1);
	RTHOOK(8);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2847[Dtype(RTCW(loc1))-646])(loc1, arg2);
	RTHOOK(9);
	tr1 = RTOSCF(6594,F925_6594, (Current));
	F924_6571(Current, tr1, loc1, arg3, arg6, arg7, arg8);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EW_SYSTEM_EXECUTION}.next_execution_result_type */
EIF_REFERENCE F925_6593 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_execution_result_type", 924, Current, 0, 0, 12519);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_SYSTEM_EXECUTION}.shell_command */
static EIF_REFERENCE F925_6594_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("shell_command", 924, Current, 0, 0, 12520);
	RTGC;
	RTOSP (6594);
#define Result RTOSR(6594)
	RTOC_NEW(Result);
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(208, 0x00).id, 208, _OBJSIZ_0_0_0_1_0_0_0_0_);
		tr2 = RTMS_EX_H("COMSPEC",7,916208451);
		Result = F209_2505(RTCW(tr1), tr2);
		RTHOOK(3);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(4);
			Result = RTMS32_EX_H("c\000\000\000m\000\000\000d\000\000\000.\000\000\000e\000\000\000x\000\000\000e\000\000\000",7,1429768549);
		}
	} else {
		RTHOOK(5);
		Result = RTMS32_EX_H("/\000\000\000b\000\000\000i\000\000\000n\000\000\000/\000\000\000s\000\000\000h\000\000\000",7,2075682408);
	}
	RTOSE (6594);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F925_6594 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6594,F925_6594_body,(Current));
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
