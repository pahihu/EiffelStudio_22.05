/*
 * Code for class EW_EWEASEL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew310.h"
#include "eif_except.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL}.make */
void F909_6239 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("make", 908, Current, 0, 1, 12161);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(10, 0x00).id, 10, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(24,F1_24, (Current));
	F11_250(RTCW(tr1), tr2);
	RTOSCP(2631,F232_2631, (Current, tr1));
	RTHOOK(3);
	F909_6245(Current, arg1);
	RTHOOK(4);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(5);
		F909_6249(Current);
	} else {
		RTHOOK(6);
		F909_6246(Current);
		RTHOOK(7);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
			RTHOOK(8);
			F909_6247(Current);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.make_and_execute */
void F909_6240 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_and_execute", 908, Current, 0, 0, 12162);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = F251_2683(RTCV(RTOSCF(2499,F209_2499, (Current))));
	F909_6239(Current, tr1);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(4);
		F909_6241(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.execute */
void F909_6241 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("execute", 908, Current, 0, 0, 12163);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		RTHOOK(2);
		F909_6251(Current);
	}
	RTHOOK(3);
	F909_6248(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.parse_arguments */
void F909_6245 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,tr3);
	RTLR(6,loc5);
	RTLR(7,loc8);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTEAA("parse_arguments", 908, Current, 8, 1, 12167);
	RTGC;
	RTHOOK(1);
	loc2 = F585_3357(RTCW(arg1));
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(656, 0).id);
	F657_3571(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(27, 0).id);
	F28_463(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {659,779,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3619(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_))) break;
		RTHOOK(8);
		tr1 = F585_3350(RTCW(arg1), loc1);
		tr2 = RTMS_EX_H("-",1,45);
		tb1 = F890_5580(RTCW(tr1), tr2);
		if (tb1) {
			RTHOOK(9);
			tr1 = F585_3350(RTCW(arg1), loc1);
			tr2 = F585_3350(RTCW(arg1), loc1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O4451[Dtype(tr2)-896]);
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4281[Dtype(RTCW(tr1))-893])(tr1, ((EIF_INTEGER_32) 2L), ti4_1);
			RTHOOK(10);
			tr1 = RTMS_EX_H("define",6,1915569253);
			tb1 = F890_5578(RTCW(loc4), tr1);
			if (tb1) {
				RTHOOK(11);
				if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)))) {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					tr3 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
					F657_3572(RTCW(tr1), tr2, tr3);
					RTHOOK(13);
					loc1 += ((EIF_INTEGER_32) 3L);
				} else {
					RTHOOK(14);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				RTHOOK(15);
				tr1 = RTMS_EX_H("keep",4,1801807216);
				tb1 = F890_5578(RTCW(loc4), tr1);
				if (tb1) {
					RTHOOK(16);
					if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
						RTHOOK(17);
						loc1++;
						RTHOOK(18);
						loc5 = F585_3350(RTCW(arg1), loc1);
						RTHOOK(19);
						tr1 = RTMS_EX_H("-",1,45);
						tb1 = F890_5580(RTCW(loc5), tr1);
						if (tb1) {
							RTHOOK(20);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							F28_473(RTCW(tr1));
							RTHOOK(21);
							loc1--;
						} else {
							RTHOOK(22);
							tr1 = RTMS_EX_H("all",3,6384748);
							tb1 = F890_5578(RTCW(loc5), tr1);
							if (tb1) {
								RTHOOK(23);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								F28_473(RTCW(tr1));
							} else {
								RTHOOK(24);
								tr1 = RTMS_EX_H("passed",6,10408548);
								tb1 = F890_5578(RTCW(loc5), tr1);
								if (tb1) {
									RTHOOK(25);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
									F28_474(RTCW(tr1));
								} else {
									RTHOOK(26);
									tr1 = RTMS_EX_H("failed",6,1969996644);
									tb1 = F890_5578(RTCW(loc5), tr1);
									if (tb1) {
										RTHOOK(27);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										F28_475(RTCW(tr1));
									} else {
										RTHOOK(28);
										*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									}
								}
							}
						}
					} else {
						RTHOOK(29);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						F28_473(RTCW(tr1));
					}
					RTHOOK(30);
					loc1++;
				} else {
					RTHOOK(31);
					tr1 = RTMS_EX_H("clean",5,1819343726);
					tb1 = F890_5578(RTCW(loc4), tr1);
					if (tb1) {
						RTHOOK(32);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						F28_476(RTCW(tr1), (EIF_BOOLEAN) 1);
						RTHOOK(33);
						loc1++;
					} else {
						RTHOOK(34);
						tr1 = RTMS_EX_H("noclean",7,1567916398);
						tb1 = F890_5578(RTCW(loc4), tr1);
						if (tb1) {
							RTHOOK(35);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							F28_476(RTCW(tr1), (EIF_BOOLEAN) 0);
							RTHOOK(36);
							loc1++;
						} else {
							RTHOOK(37);
							tr1 = RTMS_EX_H("help",4,1751477360);
							tb1 = F890_5578(RTCW(loc4), tr1);
							if (tb1) {
								RTHOOK(38);
								F909_6250(Current);
								RTHOOK(39);
								esdie(((EIF_INTEGER_32) 0L));
							} else {
								RTHOOK(40);
								tr1 = RTMS_EX_H("init",4,1768843636);
								tb1 = F890_5578(RTCW(loc4), tr1);
								if (tb1) {
									RTHOOK(41);
									if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
										RTHOOK(42);
										tr1 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
										RTAR(Current, tr1);
										*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
										RTHOOK(43);
										loc1 += ((EIF_INTEGER_32) 2L);
									} else {
										RTHOOK(44);
										*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									}
								} else {
									RTHOOK(45);
									tr1 = RTMS_EX_H("catalog",7,114913127);
									tb1 = F890_5578(RTCW(loc4), tr1);
									if (tb1) {
										RTHOOK(46);
										if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
											RTHOOK(47);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
											tr2 = RTLNS(eif_new_type(779, 0x00).id, 779, _OBJSIZ_2_1_0_0_0_0_0_0_);
											tr3 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
											F780_4210(RTCW(tr2), tr3);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(tr1))-646])(tr1, tr2);
											RTHOOK(48);
											loc1 += ((EIF_INTEGER_32) 2L);
										} else {
											RTHOOK(49);
											*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										}
									} else {
										RTHOOK(50);
										tr1 = RTMS_EX_H("output",6,25180788);
										tb1 = F890_5578(RTCW(loc4), tr1);
										if (tb1) {
											RTHOOK(51);
											if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
												RTHOOK(52);
												tr1 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
												RTAR(Current, tr1);
												*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
												RTHOOK(53);
												loc1 += ((EIF_INTEGER_32) 2L);
											} else {
												RTHOOK(54);
												*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
											}
										} else {
											RTHOOK(55);
											tr1 = RTMS_EX_H("filter",6,2020914034);
											tb1 = F890_5578(RTCW(loc4), tr1);
											if (tb1) {
												RTHOOK(56);
												if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
													RTHOOK(57);
													tr1 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
													loc8 = F53_718(Current, tr1);
													RTHOOK(58);
													if ((EIF_BOOLEAN)(loc8 != NULL)) {
														RTHOOK(59);
														tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
														F28_477(RTCW(tr1), loc8);
														RTHOOK(60);
														loc1 += ((EIF_INTEGER_32) 2L);
													} else {
														RTHOOK(61);
														if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
															RTHOOK(62);
															tr1 = F232_2630(Current);
															tr2 = RTMS_EX_H("No filter type specified",24,344537188);
															F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
														} else {
															RTHOOK(63);
															if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
																RTHOOK(64);
																tr1 = F232_2630(Current);
																tr2 = RTMS_EX_H("Filter type `",13,889022304);
																F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
																RTHOOK(65);
																tr1 = F232_2630(Current);
																F11_257(RTCW(tr1), *(EIF_REFERENCE *)(Current), (EIF_BOOLEAN) 0);
																RTHOOK(66);
																tr1 = F232_2630(Current);
																tr2 = RTMS_EX_H("\' is not valid",14,1454872932);
																F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
															} else {
																RTHOOK(67);
																if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_) == ((EIF_INTEGER_32) 0L))) {
																	RTHOOK(68);
																	tr1 = F232_2630(Current);
																	tr2 = RTMS_EX_H("No filter values specified for filter type `",44,1453693024);
																	F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
																	RTHOOK(69);
																	tr1 = F232_2630(Current);
																	F11_257(RTCW(tr1), *(EIF_REFERENCE *)(Current), (EIF_BOOLEAN) 0);
																	RTHOOK(70);
																	tr1 = F232_2630(Current);
																	tr2 = RTMS_EX_H("\'",1,39);
																	F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																} else {
																	RTHOOK(71);
																	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_) > ((EIF_INTEGER_32) 1L))) {
																		RTHOOK(72);
																		tr1 = F232_2630(Current);
																		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_);
																		tr2 = eif_out__i4_s1(ti4_1);
																		tr3 = RTMS_EX_H(" filter values specified for filter type `",42,1064957792);
																		tr2 = F895_5795(RTCW(tr2), tr3);
																		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
																		RTHOOK(73);
																		tr1 = F232_2630(Current);
																		F11_257(RTCW(tr1), *(EIF_REFERENCE *)(Current), (EIF_BOOLEAN) 0);
																		RTHOOK(74);
																		tr1 = F232_2630(Current);
																		tr2 = RTMS_EX_H("\' - not currently supported",27,1933668708);
																		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																	}
																}
															}
														}
														RTHOOK(75);
														*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
													}
												} else {
													RTHOOK(76);
													*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
												}
											} else {
												RTHOOK(77);
												tr1 = RTMS_EX_H("order",5,1920034674);
												tb1 = F890_5578(RTCW(loc4), tr1);
												if (tb1) {
													RTHOOK(78);
													tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
													F28_480(RTCW(tr1), (EIF_BOOLEAN) 1);
													RTHOOK(79);
													loc1++;
												} else {
													RTHOOK(80);
													tr1 = RTMS_EX_H("noorder",7,1668607346);
													tb1 = F890_5578(RTCW(loc4), tr1);
													if (tb1) {
														RTHOOK(81);
														tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
														F28_480(RTCW(tr1), (EIF_BOOLEAN) 0);
														RTHOOK(82);
														loc1++;
													} else {
														RTHOOK(83);
														tr1 = RTMS_EX_H("max_threads",11,1641978739);
														tb1 = F890_5578(RTCW(loc4), tr1);
														if (tb1) {
															RTHOOK(84);
															if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
																RTHOOK(85);
																loc6 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
																RTHOOK(86);
																tb1 = F890_5564(RTCW(loc6));
																if (tb1) {
																	RTHOOK(87);
																	loc3 = F890_5598(RTCW(loc6));
																	RTHOOK(88);
																	if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) -1L))) {
																		RTHOOK(89);
																		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
																		F28_478(RTCW(tr1), loc3);
																		RTHOOK(90);
																		loc1 += ((EIF_INTEGER_32) 2L);
																	} else {
																		RTHOOK(91);
																		tr1 = F232_2630(Current);
																		tr2 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000m\000\000\000a\000\000\000x\000\000\000i\000\000\000m\000\000\000u\000\000\000m\000\000\000 \000\000\000t\000\000\000h\000\000\000r\000\000\000e\000\000\000a\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000u\000\000\000n\000\000\000t\000\000\000 \000\000\000",29,649026848);
																		tr3 = eif_out__i4_s1(loc3);
																		tr3 = F890_5592(RTCW(tr3));
																		tr2 = F899_5995(tr2, tr3);
																		tr3 = F890_5592(RTMS_EX_H(" - must be >= -1",16,1113561137));
																		tr2 = F899_5995(RTCW(tr2), tr3);
																		F11_257(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																		RTHOOK(92);
																		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																	}
																} else {
																	RTHOOK(93);
																	tr1 = F232_2630(Current);
																	tr2 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000m\000\000\000a\000\000\000x\000\000\000i\000\000\000m\000\000\000u\000\000\000m\000\000\000 \000\000\000t\000\000\000h\000\000\000r\000\000\000e\000\000\000a\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000u\000\000\000n\000\000\000t\000\000\000:\000\000\000 \000\000\000",30,794934560);
																	tr2 = F899_5995(tr2, loc6);
																	F11_257(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																	RTHOOK(94);
																	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																}
															} else {
																RTHOOK(95);
																*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
															}
														} else {
															RTHOOK(96);
															tr1 = RTMS_EX_H("max_c_processes",15,2097447795);
															tb1 = F890_5578(RTCW(loc4), tr1);
															if (tb1) {
																RTHOOK(97);
																if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
																	RTHOOK(98);
																	loc7 = F585_3350(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
																	RTHOOK(99);
																	tb1 = F890_5564(RTCW(loc7));
																	if (tb1) {
																		RTHOOK(100);
																		loc3 = F890_5598(RTCW(loc7));
																		RTHOOK(101);
																		if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) -1L))) {
																			RTHOOK(102);
																			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
																			F28_479(RTCW(tr1), loc3);
																			RTHOOK(103);
																			loc1 += ((EIF_INTEGER_32) 2L);
																		} else {
																			RTHOOK(104);
																			tr1 = F232_2630(Current);
																			tr2 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000m\000\000\000a\000\000\000x\000\000\000i\000\000\000m\000\000\000u\000\000\000m\000\000\000 \000\000\000C\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000e\000\000\000s\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000 \000\000\000",34,638565664);
																			tr3 = eif_out__i4_s1(loc3);
																			tr3 = F890_5592(RTCW(tr3));
																			tr2 = F899_5995(tr2, tr3);
																			tr3 = F890_5592(RTMS_EX_H(" - must be >= -1",16,1113561137));
																			tr2 = F899_5995(RTCW(tr2), tr3);
																			F11_257(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																			RTHOOK(105);
																			*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																		}
																	} else {
																		RTHOOK(106);
																		tr1 = F232_2630(Current);
																		tr2 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000m\000\000\000a\000\000\000x\000\000\000i\000\000\000m\000\000\000u\000\000\000m\000\000\000 \000\000\000C\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000e\000\000\000s\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000:\000\000\000 \000\000\000",35,264351264);
																		tr2 = F899_5995(tr2, loc7);
																		F11_257(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																		RTHOOK(107);
																		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																	}
																} else {
																	RTHOOK(108);
																	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																}
															} else {
																RTHOOK(109);
																tr1 = RTMS_EX_H("nologo",6,2036361583);
																tb1 = F890_5578(RTCW(loc4), tr1);
																if (tb1) {
																	RTHOOK(110);
																	loc1++;
																	RTHOOK(111);
																	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																} else {
																	RTHOOK(112);
																	tr1 = RTMS_EX_H("nosummary",9,2036610681);
																	tb1 = F890_5578(RTCW(loc4), tr1);
																	if (tb1) {
																		RTHOOK(113);
																		loc1++;
																		RTHOOK(114);
																		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
																		F28_481(RTCW(tr1), (EIF_BOOLEAN) 0);
																	} else {
																		RTHOOK(115);
																		tr1 = F232_2630(Current);
																		tr2 = RTMS_EX_H("Unknown option: ",16,1304633120);
																		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
																		RTHOOK(116);
																		tr1 = F232_2630(Current);
																		tr2 = F585_3350(RTCW(arg1), loc1);
																		F11_255(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
																		RTHOOK(117);
																		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} else {
			RTHOOK(118);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTHOOK(119);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_6_0_1_);
	F657_3576(RTCW(tr1), ti4_1);
	RTHOOK(120);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
		RTHOOK(121);
		tr1 = F232_2630(Current);
		tr2 = RTMS_EX_H("No initial test control file specified (-init option omitted)",61,1585108521);
		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
		RTHOOK(122);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(123);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F495_2928(RTCW(tr1));
	if (tb1) {
		RTHOOK(124);
		tr1 = F232_2630(Current);
		tr2 = RTMS_EX_H("No test catalogs specified (-catalog option omitted)",52,879666217);
		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
		RTHOOK(125);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(126);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) == NULL)) {
		RTHOOK(127);
		tr1 = F232_2630(Current);
		tr2 = RTMS_EX_H("No test output directory specified (-output option omitted)",59,877110313);
		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
		RTHOOK(128);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(134);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.check_test_suite_dir */
void F909_6246 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("check_test_suite_dir", 908, Current, 1, 0, 12168);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(205, 0x00).id, 205, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F206_2382(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTHOOK(2);
	tb1 = F206_2406(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(4);
		tr1 = F232_2630(Current);
		tr2 = RTMS_EX_H("Directory not found: ",21,1680308768);
		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
		RTHOOK(5);
		tr1 = F232_2630(Current);
		F11_255(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), (EIF_BOOLEAN) 0);
		RTHOOK(6);
		F11_258(RTCV(F232_2630(Current)));
	} else {
		RTHOOK(7);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.execute_init_control_file */
void F909_6247 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("execute_init_control_file", 908, Current, 1, 0, 12169);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_10_4_0_1_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(6167,F906_6167, (Current));
	F914_6327(RTCW(loc1), tr1, NULL, tr2, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	F914_6332(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_10_0_);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(5);
		tr1 = F232_2630(Current);
		tr2 = RTMS_EX_H("Error in initial control file ",30,1290761504);
		F11_256(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
		RTHOOK(6);
		tr1 = F232_2630(Current);
		F11_255(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), (EIF_BOOLEAN) 1);
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		F233_2636(RTCW(tr1));
	} else {
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.do_tests */
void F909_6248 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("do_tests", 908, Current, 7, 0, 12170);
	RTGC;
	RTHOOK(1);
	RTCT0("from_precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2400[Dtype(loc6)-646])(loc6);
	RTHOOK(3);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {659,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3619(RTCW(loc4), ((EIF_INTEGER_32) 100L));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2361[Dtype(loc7)-293])(loc7);
		if (tb1) break;
		RTHOOK(5);
		if ((EIF_BOOLEAN) !loc3) break;
		RTHOOK(6);
		loc1 = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_10_2_0_1_0_0_0_0_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2360[Dtype(loc7)-293])(loc7);
		F923_6548(RTCW(loc1), tr1);
		RTHOOK(7);
		F923_6553(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(8);
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_10_0_);
		if (tb2) {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			F660_3666(RTCW(loc4), tr1);
		} else {
			RTHOOK(10);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			F233_2636(RTCW(tr1));
		}
		RTHOOK(12);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2362[Dtype(loc7)-293])(loc7);
	}
	RTHOOK(13);
	if (loc3) {
		RTHOOK(14);
		loc2 = F910_6257(Current, loc4, *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(15);
		F757_4131(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(16);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_1_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(17);
			tr1 = RTLNS(eif_new_type(116, 0x00).id, 116, _OBJSIZ_0_0_0_0_0_0_0_0_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_1_);
			ti4_1 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 255L));
			esdie(ti4_1);
		}
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.display_help_instructions */
void F909_6249 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display_help_instructions", 908, Current, 0, 0, 12171);
	RTGC;
	RTHOOK(1);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("Use -help option to display help",32,1238470768);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.display_usage */
void F909_6250 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display_usage", 908, Current, 0, 0, 12172);
	RTGC;
	RTHOOK(1);
	F11_258(RTCV(F232_2630(Current)));
	RTHOOK(2);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("Usage:",6,1802166074);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   eweasel [-help] [-nologo] [-nosummary]",41,1239472989);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("      [-max_threads COUNT] [-max_c_processes COUNT]",51,632362845);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(5);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("      [-order | -noorder] [-keep [{all | passed | failed}]] [-clean | -noclean]",79,120555613);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(6);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("      [-filter FILTER] [-define NAME VALUE ...]",47,990397533);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(7);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("      -init INIT_CONTROL_FILE -catalog TEST_CATALOG -output TEST_SUITE_DIR",74,1981079378);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(8);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("",0,0);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(9);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("Options (may appear in any order and later options override earlier options):",77,87864378);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(10);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("",0,0);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(11);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -help        Display this help message and exit.",51,956466734);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(12);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -max_threads Specify maximum number of worker threads for multithreaded",74,1109815396);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(13);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                eweasel.  Default is -1 (do all tests in main thread).",70,1845274670);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(14);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Value of 0 will curently cause a hang in MT version.",68,546008878);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(15);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Ignored in single-threaded version.",51,1560888110);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(16);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -max_c_processes",19,391619187);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(17);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Specify maximum number of processes to use simultaneously for",77,767154802);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(18);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                C compilations for any test that requires C compilations. ",74,1381020448);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(19);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Default is number of processors on machine. ",60,532819488);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(20);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -order       Display test execution results in catalog order.",64,430076718);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(21);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -noorder     Display test execution results as soon as they available.",73,512516142);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(22);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                This is the default.  Ignored in single-threaded version.",73,255672878);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(23);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -keep        Keep some test directories after execution, depending",69,1942783079);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(24);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                on next argument (all, passed or failed).  If the next",70,1600991092);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(25);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                argument is omitted, keep all test directories.",63,435158830);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(26);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -clean       Delete EIFGENs directory after each test finishes.",66,1129260334);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(27);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                This option has no effect if -keep is not specified,",68,396344620);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(28);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                since every test directory will be deleted after execution.",75,1498409006);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(29);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -noclean     Do not delete EIFGENs directory after test finishes (default).",78,1689072686);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(30);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -filter      Apply filter to select tests.",45,597314606);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(31);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                If no filter is given all tests in the catalog are executed.",76,1059880494);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(32);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Only one filter is supported - later filter options override",76,447481445);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(33);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                earlier ones.",29,1769219630);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(34);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                Filter can be one of:",37,763303226);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(35);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    \'test TEST_NAME\'",36,2132970791);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(36);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    \'directory TEST_DIRECTORY\'",46,122323239);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(37);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    \'keyword TEST_KEYWORD\'",42,1863422503);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(38);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                where TEST_NAME, TEST_DIRECTORY and TEST_KEYWORD refer",70,623462002);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(39);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                to test names, test directories and test keywords in the",72,287659621);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(40);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                test catalog.  You may use dir as a synonym for directory",73,976924537);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(41);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                and kw as a synonym for keyword.",48,220751662);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(42);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -init        Specify initial test suite control file to be read.",67,274439470);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(43);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                This file should setup the eweasel environment.",63,1710633262);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(44);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -catalog     Specify the name of a test catalog file.  This option may",73,1576159097);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(45);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                appear more than once to specify multiple catalogs.",67,1465221934);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(46);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -output      Name of test suite directory.  A directory is created in this",77,1177112691);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(47);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                directory for each test that is executed.  Use the -keep and",76,1732829284);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(48);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                -clean options to control whether created test directories",74,1377945459);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(49);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                are kept after execution and whether the EIFGENs directory",74,597831289);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(50);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                is deleted.",27,396253998);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(51);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -define      Define name to have value during tests.",55,957784878);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(52);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                You need to define:",35,1751489850);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(53);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    INCLUDE for directory with include files",60,583774323);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(54);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    ISE_EIFFEL for directory with Eiffel installation",69,1423721838);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(55);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    ISE_PLATFORM for name of platform",53,997770349);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(56);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    VERSION for compiler version",48,1197333614);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(57);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("                    PLATFORM_TYPE (unix, windows, dotnet)",57,1825110313);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(58);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -nologo      Suppress copyright message and version information.",67,799990318);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(59);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("   -nosummary   Suppress summary of test results.",49,1029314606);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(60);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL}.display_version */
void F909_6251 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("display_version", 908, Current, 1, 0, 12173);
	RTGC;
	RTHOOK(1);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H("EiffelWeasel test execution manager",35,451090802);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	loc1 = RTMS_EX_H("$Revision: 104251 $",19,1394052132);
	RTHOOK(3);
	F895_5798(RTCW(loc1), ((EIF_INTEGER_32) 11L));
	RTHOOK(4);
	F895_5800(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(5);
	tr1 = F232_2630(Current);
	tr2 = RTMS_EX_H(" (version 1.3.1.",16,1813390638);
	tr2 = F895_5795(tr2, loc1);
	tr3 = RTMS_EX_H(")",1,41);
	tr2 = F895_5795(RTCW(tr2), tr3);
	F11_254(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
