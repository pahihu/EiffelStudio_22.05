/*
 * Code for class EW_EWEASEL_ST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew311.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_ST}.new_test_suite */
EIF_REFERENCE F910_6257 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("new_test_suite", 909, Current, 0, 2, 12178);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_3_0_0_4_0_0_0_0_);
	F756_4114(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_4_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
