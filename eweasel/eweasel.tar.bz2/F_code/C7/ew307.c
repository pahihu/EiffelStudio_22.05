/*
 * Code for class EW_INSTRUCTION_TABLES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew307.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_INSTRUCTION_TABLES}.test_command_table */
static EIF_REFERENCE F906_6166_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_command_table", 905, Current, 0, 0, 12088);
	RTGC;
	RTOSP (6166);
#define Result RTOSR(6166)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {677,53,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 677, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F673_3703(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(178, 0x00).id, 178, _OBJSIZ_7_4_0_1_0_0_0_0_);
	tr2 = RTOSCF(1844,F178_1844, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(56, 0x00).id, 56, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr2 = RTOSCF(1859,F178_1859, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(745, 0x00).id, 745, _OBJSIZ_10_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1845,F178_1845, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(55, 0x00).id, 55, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1857,F178_1857, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(54, 0x00).id, 54, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1853,F178_1853, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(59, 0x00).id, 59, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1852,F178_1852, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1814,F178_1814, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTLNS(eif_new_type(64, 0x00).id, 64, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1815,F178_1815, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(655, 0x00).id, 655, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1838,F178_1838, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(11);
	tr1 = RTLNS(eif_new_type(654, 0x00).id, 654, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1858,F178_1858, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(651, 0x00).id, 651, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1835,F178_1835, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(754, 0x00).id, 754, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1836,F178_1836, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(14);
	tr1 = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1837,F178_1837, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(15);
	tr1 = RTLNS(eif_new_type(653, 0x00).id, 653, _OBJSIZ_8_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1850,F178_1850, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(16);
	tr1 = RTLNS(eif_new_type(652, 0x00).id, 652, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1860,F178_1860, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(761, 0x00).id, 761, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1830,F178_1830, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(18);
	tr1 = RTLNS(eif_new_type(762, 0x00).id, 762, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1833,F178_1833, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(19);
	tr1 = RTLNS(eif_new_type(765, 0x00).id, 765, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1831,F178_1831, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(20);
	tr1 = RTLNS(eif_new_type(764, 0x00).id, 764, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1832,F178_1832, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(21);
	tr1 = RTLNS(eif_new_type(751, 0x00).id, 751, _OBJSIZ_8_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1839,F178_1839, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(22);
	tr1 = RTLNS(eif_new_type(62, 0x00).id, 62, _OBJSIZ_6_1_0_2_0_0_0_0_);
	tr2 = RTOSCF(1834,F178_1834, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(23);
	tr1 = RTLNS(eif_new_type(776, 0x00).id, 776, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1826,F178_1826, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(24);
	tr1 = RTLNS(eif_new_type(775, 0x00).id, 775, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1827,F178_1827, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(25);
	tr1 = RTLNS(eif_new_type(774, 0x00).id, 774, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1825,F178_1825, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(26);
	tr1 = RTLNS(eif_new_type(773, 0x00).id, 773, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1824,F178_1824, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(27);
	tr1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1823,F178_1823, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(28);
	tr1 = RTLNS(eif_new_type(771, 0x00).id, 771, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1828,F178_1828, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(29);
	tr1 = RTLNS(eif_new_type(746, 0x00).id, 746, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1849,F178_1849, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(30);
	tr1 = RTLNS(eif_new_type(748, 0x00).id, 748, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1819,F178_1819, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(31);
	tr1 = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1813,F178_1813, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(32);
	tr1 = RTLNS(eif_new_type(749, 0x00).id, 749, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1843,F178_1843, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(33);
	tr1 = RTLNS(eif_new_type(60, 0x00).id, 60, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1829,F178_1829, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(34);
	tr1 = RTLNS(eif_new_type(770, 0x00).id, 770, _OBJSIZ_10_3_0_2_0_0_0_0_);
	tr2 = RTOSCF(1820,F178_1820, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(35);
	tr1 = RTLNS(eif_new_type(101, 0x00).id, 101, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1821,F178_1821, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(36);
	tr1 = RTLNS(eif_new_type(767, 0x00).id, 767, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1818,F178_1818, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(37);
	tr1 = RTLNS(eif_new_type(768, 0x00).id, 768, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1816,F178_1816, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(38);
	tr1 = RTLNS(eif_new_type(63, 0x00).id, 63, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1817,F178_1817, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(39);
	tr1 = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_9_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1842,F178_1842, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(40);
	tr1 = RTLNS(eif_new_type(758, 0x00).id, 758, _OBJSIZ_9_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1840,F178_1840, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(41);
	tr1 = RTLNS(eif_new_type(61, 0x00).id, 61, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1841,F178_1841, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(42);
	tr1 = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_8_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1822,F178_1822, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(43);
	tr1 = RTLNS(eif_new_type(57, 0x00).id, 57, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1847,F178_1847, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(44);
	tr1 = RTLNS(eif_new_type(777, 0x00).id, 777, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOSCF(1848,F178_1848, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(45);
	tr1 = RTLNS(eif_new_type(58, 0x00).id, 58, _OBJSIZ_6_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1854,F178_1854, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTOSE (6166);
	RTHOOK(46);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F906_6166 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6166,F906_6166_body,(Current));
}

/* {EW_INSTRUCTION_TABLES}.test_suite_command_table */
static EIF_REFERENCE F906_6167_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_suite_command_table", 905, Current, 0, 0, 12089);
	RTGC;
	RTOSP (6167);
#define Result RTOSR(6167)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {677,53,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 677, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F673_3703(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(178, 0x00).id, 178, _OBJSIZ_7_4_0_1_0_0_0_0_);
	tr2 = RTOSCF(1844,F178_1844, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(56, 0x00).id, 56, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr2 = RTOSCF(1859,F178_1859, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(745, 0x00).id, 745, _OBJSIZ_10_2_0_1_0_0_0_0_);
	tr2 = RTOSCF(1845,F178_1845, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(655, 0x00).id, 655, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1838,F178_1838, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(654, 0x00).id, 654, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1858,F178_1858, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(651, 0x00).id, 651, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1835,F178_1835, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(754, 0x00).id, 754, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1836,F178_1836, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOSCF(1837,F178_1837, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTOSE (6167);
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F906_6167 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6167,F906_6167_body,(Current));
}

/* {EW_INSTRUCTION_TABLES}.test_catalog_command_table */
static EIF_REFERENCE F906_6168_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_catalog_command_table", 905, Current, 0, 0, 12090);
	RTGC;
	RTOSP (6168);
#define Result RTOSR(6168)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {677,157,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 677, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F673_3703(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(159, 0x00).id, 159, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOSCF(1859,F178_1859, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(179, 0x00).id, 179, _OBJSIZ_2_2_0_0_0_0_0_0_);
	tr2 = RTOSCF(1844,F178_1844, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(158, 0x00).id, 158, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOSCF(1851,F178_1851, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(752, 0x00).id, 752, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOSCF(1855,F178_1855, (Current));
	F673_3749(RTCW(Result), tr1, tr2);
	RTOSE (6168);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F906_6168 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6168,F906_6168_body,(Current));
}

void EIF_Minit307 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
