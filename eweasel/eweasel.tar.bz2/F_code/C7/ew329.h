
#ifndef _C7_ew329_
#define _C7_ew329_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F928_6607(EIF_REFERENCE);
extern EIF_REFERENCE F928_6608(EIF_REFERENCE);
extern void EIF_Minit329(void);
extern EIF_REFERENCE F924_6584(EIF_REFERENCE);
extern void F106_1387(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F107_1409(EIF_REFERENCE);
extern EIF_REFERENCE F927_6600(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
