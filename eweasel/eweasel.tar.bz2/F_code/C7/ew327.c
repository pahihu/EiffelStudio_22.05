/*
 * Code for class EW_C_COMPILATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew327.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_C_COMPILATION}.make */
void F926_6595 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,arg4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTEAA("make", 925, Current, 2, 5, 12521);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {646,896,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 646, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F647_3462(RTCW(loc1));
	RTHOOK(2);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("-\000\000\000l\000\000\000o\000\000\000c\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",9,566239598);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, tr1);
		RTHOOK(4);
		loc2 = (EIF_REFERENCE) arg3;
	} else {
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, arg3);
		RTHOOK(6);
		loc2 = RTOSCF(6597,F926_6597, (Current));
	}
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, arg1);
	RTHOOK(8);
	if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(9);
		tr1 = RTMS32_EX_H("-\000\000\000n\000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000",6,1975866211);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, tr1);
		RTHOOK(10);
		tr1 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr2 = eif_out__i4_s1(arg5);
		F899_5937(RTCW(tr1), tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2527[Dtype(RTCW(loc1))-646])(loc1, tr1);
	}
	RTHOOK(11);
	F924_6571(Current, loc2, loc1, arg4, NULL, NULL, arg2);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EW_C_COMPILATION}.next_compile_result_type */
EIF_REFERENCE F926_6596 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_compile_result_type", 925, Current, 0, 0, 12522);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_C_COMPILATION}.shell_command */

EIF_REFERENCE F926_6597 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6597,RTMS32_EX_H("/\000\000\000b\000\000\000i\000\000\000n\000\000\000/\000\000\000s\000\000\000h\000\000\000",7,2075682408));
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
