
#ifndef _C7_fi345_
#define _C7_fi345_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F495_2928(EIF_REFERENCE);
extern void EIF_Minit345(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
