
#ifndef _C7_ew314_
#define _C7_ew314_

#ifdef __cplusplus
extern "C" {
#endif

extern void F913_6319(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F913_6322(EIF_REFERENCE);
extern void F913_6323(EIF_REFERENCE);
extern void F913_6324(EIF_REFERENCE);
extern void F913_6325(EIF_REFERENCE);
extern void F913_6326(EIF_REFERENCE);
extern void EIF_Minit314(void);

#ifdef __cplusplus
}
#endif

#endif
