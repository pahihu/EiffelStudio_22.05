#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* MISMATCH_INFORMATION wipe_out */
void A204_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F673_3757)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A204_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F680_3830)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A204_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F680_3831)(Current, arg1, arg2);
}


#ifdef __cplusplus
}
#endif
