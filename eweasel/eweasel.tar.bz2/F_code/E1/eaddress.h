#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F680_3831(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F673_3757(EIF_REFERENCE);
extern void F680_3830(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif
