#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names2[];
static const uint32 types2 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags2 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype2_0 [] = {676,883,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_1 [] = {672,892,892,0xFFFF};

static const EIF_TYPE_INDEX *gtypes2 [] = {
g_atype2_0,
g_atype2_1,
};

static const long offsets2 [] =
{
0,
 + @REFACS(1),
};

extern const char *names3[];
static const uint32 types3 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags3 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype3_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes3 [] = {
g_atype3_0,
g_atype3_1,
g_atype3_2,
};

static const long offsets3 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names4[];
static const uint32 types4 [] =
{
SK_UINT32,
};

static const uint16 attr_flags4 [] =
{1,};

static const EIF_TYPE_INDEX g_atype4_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes4 [] = {
g_atype4_0,
};

static const long offsets4 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names7[];
static const uint32 types7 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags7 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype7_0 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype7_1 [] = {902,0xFFFF};

static const EIF_TYPE_INDEX *gtypes7 [] = {
g_atype7_0,
g_atype7_1,
};

static const long offsets7 [] =
{
0,
 + @REFACS(1),
};

extern const char *names8[];
static const uint32 types8 [] =
{
SK_REF,
};

static const uint16 attr_flags8 [] =
{0,};

static const EIF_TYPE_INDEX g_atype8_0 [] = {620,907,0xFFFF};

static const EIF_TYPE_INDEX *gtypes8 [] = {
g_atype8_0,
};

static const long offsets8 [] =
{
0,
};

extern const char *names11[];
static const uint32 types11 [] =
{
SK_REF,
};

static const uint16 attr_flags11 [] =
{0,};

static const EIF_TYPE_INDEX g_atype11_0 [] = {0,0xFFFF};

static const EIF_TYPE_INDEX *gtypes11 [] = {
g_atype11_0,
};

static const long offsets11 [] =
{
0,
};

extern const char *names13[];
static const uint32 types13 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags13 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype13_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype13_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype13_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype13_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes13 [] = {
g_atype13_0,
g_atype13_1,
g_atype13_2,
g_atype13_3,
};

static const long offsets13 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_REF,
};

static const uint16 attr_flags27 [] =
{0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {558,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
};

static const long offsets27 [] =
{
0,
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags28 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {160,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
g_atype28_1,
g_atype28_2,
g_atype28_3,
g_atype28_4,
g_atype28_5,
g_atype28_6,
g_atype28_7,
g_atype28_8,
};

static const long offsets28 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @LNGOFF(1,6,0,0),
+ @LNGOFF(1,6,0,1),
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags34 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {885,0xFFF9,1,811,185,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_2 [] = {885,0xFFF9,2,811,185,185,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_3 [] = {885,0xFFF9,1,811,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_4 [] = {659,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_5 [] = {675,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_11 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
g_atype34_2,
g_atype34_3,
g_atype34_4,
g_atype34_5,
g_atype34_6,
g_atype34_7,
g_atype34_8,
g_atype34_9,
g_atype34_10,
g_atype34_11,
};

static const long offsets34 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names35[];
static const uint32 types35 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags35 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype35_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_1 [] = {885,0xFFF9,1,811,185,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_2 [] = {885,0xFFF9,2,811,185,185,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_3 [] = {885,0xFFF9,1,811,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_4 [] = {659,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_5 [] = {675,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_11 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes35 [] = {
g_atype35_0,
g_atype35_1,
g_atype35_2,
g_atype35_3,
g_atype35_4,
g_atype35_5,
g_atype35_6,
g_atype35_7,
g_atype35_8,
g_atype35_9,
g_atype35_10,
g_atype35_11,
};

static const long offsets35 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_REF,
};

static const uint16 attr_flags43 [] =
{0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
};

static const long offsets43 [] =
{
0,
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_INT32,
};

static const uint16 attr_flags44 [] =
{0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
};

static const long offsets44 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_UINT64,
};

static const uint16 attr_flags45 [] =
{0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
};

static const long offsets45 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags46 [] =
{0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
};

static const long offsets46 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names47[];
static const uint32 types47 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags47 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype47_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_1 [] = {46,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes47 [] = {
g_atype47_0,
g_atype47_1,
};

static const long offsets47 [] =
{
0,
 + @REFACS(1),
};

extern const char *names48[];
static const uint32 types48 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags48 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype48_0 [] = {47,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes48 [] = {
g_atype48_0,
g_atype48_1,
};

static const long offsets48 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names49[];
static const uint32 types49 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags49 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype49_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_1 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_2 [] = {48,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes49 [] = {
g_atype49_0,
g_atype49_1,
g_atype49_2,
};

static const long offsets49 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names53[];
static const uint32 types53 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags53 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype53_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype53_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype53_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes53 [] = {
g_atype53_0,
g_atype53_1,
g_atype53_2,
};

static const long offsets53 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names54[];
static const uint32 types54 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags54 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype54_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype54_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes54 [] = {
g_atype54_0,
g_atype54_1,
g_atype54_2,
g_atype54_3,
g_atype54_4,
g_atype54_5,
g_atype54_6,
};

static const long offsets54 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names55[];
static const uint32 types55 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags55 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype55_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes55 [] = {
g_atype55_0,
g_atype55_1,
g_atype55_2,
g_atype55_3,
g_atype55_4,
g_atype55_5,
g_atype55_6,
g_atype55_7,
g_atype55_8,
};

static const long offsets55 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names56[];
static const uint32 types56 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags56 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype56_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes56 [] = {
g_atype56_0,
g_atype56_1,
g_atype56_2,
g_atype56_3,
g_atype56_4,
g_atype56_5,
g_atype56_6,
g_atype56_7,
g_atype56_8,
};

static const long offsets56 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags57 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
g_atype57_1,
g_atype57_2,
g_atype57_3,
g_atype57_4,
g_atype57_5,
g_atype57_6,
};

static const long offsets57 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names58[];
static const uint32 types58 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags58 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype58_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes58 [] = {
g_atype58_0,
g_atype58_1,
g_atype58_2,
g_atype58_3,
g_atype58_4,
g_atype58_5,
g_atype58_6,
g_atype58_7,
g_atype58_8,
g_atype58_9,
};

static const long offsets58 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names59[];
static const uint32 types59 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags59 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype59_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes59 [] = {
g_atype59_0,
g_atype59_1,
g_atype59_2,
g_atype59_3,
g_atype59_4,
g_atype59_5,
g_atype59_6,
g_atype59_7,
};

static const long offsets59 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
};

extern const char *names60[];
static const uint32 types60 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags60 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype60_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes60 [] = {
g_atype60_0,
g_atype60_1,
g_atype60_2,
g_atype60_3,
g_atype60_4,
g_atype60_5,
g_atype60_6,
g_atype60_7,
g_atype60_8,
};

static const long offsets60 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names61[];
static const uint32 types61 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags61 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype61_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_6 [] = {105,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes61 [] = {
g_atype61_0,
g_atype61_1,
g_atype61_2,
g_atype61_3,
g_atype61_4,
g_atype61_5,
g_atype61_6,
g_atype61_7,
g_atype61_8,
g_atype61_9,
};

static const long offsets61 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags62 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_6 [] = {103,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
g_atype62_2,
g_atype62_3,
g_atype62_4,
g_atype62_5,
g_atype62_6,
g_atype62_7,
g_atype62_8,
g_atype62_9,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names63[];
static const uint32 types63 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags63 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype63_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes63 [] = {
g_atype63_0,
g_atype63_1,
g_atype63_2,
g_atype63_3,
g_atype63_4,
g_atype63_5,
g_atype63_6,
g_atype63_7,
g_atype63_8,
};

static const long offsets63 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
};

extern const char *names64[];
static const uint32 types64 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags64 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype64_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_6 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype64_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes64 [] = {
g_atype64_0,
g_atype64_1,
g_atype64_2,
g_atype64_3,
g_atype64_4,
g_atype64_5,
g_atype64_6,
g_atype64_7,
g_atype64_8,
g_atype64_9,
};

static const long offsets64 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names65[];
static const uint32 types65 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags65 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype65_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes65 [] = {
g_atype65_0,
g_atype65_1,
g_atype65_2,
g_atype65_3,
g_atype65_4,
g_atype65_5,
g_atype65_6,
g_atype65_7,
g_atype65_8,
g_atype65_9,
};

static const long offsets65 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names66[];
static const uint32 types66 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags66 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype66_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes66 [] = {
g_atype66_0,
g_atype66_1,
g_atype66_2,
g_atype66_3,
g_atype66_4,
g_atype66_5,
g_atype66_6,
g_atype66_7,
g_atype66_8,
};

static const long offsets66 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names67[];
static const uint32 types67 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags67 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype67_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes67 [] = {
g_atype67_0,
g_atype67_1,
g_atype67_2,
g_atype67_3,
g_atype67_4,
g_atype67_5,
g_atype67_6,
g_atype67_7,
g_atype67_8,
g_atype67_9,
};

static const long offsets67 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags70 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_2 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
g_atype70_2,
};

static const long offsets70 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names74[];
static const uint32 types74 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags74 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype74_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_1 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes74 [] = {
g_atype74_0,
g_atype74_1,
};

static const long offsets74 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags77 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_1 [] = {671,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
g_atype77_1,
};

static const long offsets77 [] =
{
0,
 + @REFACS(1),
};

extern const char *names88[];
static const uint32 types88 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags88 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype88_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_1 [] = {684,686,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes88 [] = {
g_atype88_0,
g_atype88_1,
};

static const long offsets88 [] =
{
0,
 + @REFACS(1),
};

extern const char *names89[];
static const uint32 types89 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags89 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype89_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_1 [] = {684,686,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes89 [] = {
g_atype89_0,
g_atype89_1,
};

static const long offsets89 [] =
{
0,
 + @REFACS(1),
};

extern const char *names90[];
static const uint32 types90 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags90 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype90_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_1 [] = {684,686,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes90 [] = {
g_atype90_0,
g_atype90_1,
};

static const long offsets90 [] =
{
0,
 + @REFACS(1),
};

extern const char *names92[];
static const uint32 types92 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags92 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype92_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_1 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_2 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_3 [] = {685,850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes92 [] = {
g_atype92_0,
g_atype92_1,
g_atype92_2,
g_atype92_3,
};

static const long offsets92 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names93[];
static const uint32 types93 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags93 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype93_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes93 [] = {
g_atype93_0,
g_atype93_1,
g_atype93_2,
g_atype93_3,
g_atype93_4,
g_atype93_5,
g_atype93_6,
};

static const long offsets93 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names94[];
static const uint32 types94 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags94 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype94_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_9 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_10 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes94 [] = {
g_atype94_0,
g_atype94_1,
g_atype94_2,
g_atype94_3,
g_atype94_4,
g_atype94_5,
g_atype94_6,
g_atype94_7,
g_atype94_8,
g_atype94_9,
g_atype94_10,
};

static const long offsets94 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags95 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_8 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_9 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
g_atype95_1,
g_atype95_2,
g_atype95_3,
g_atype95_4,
g_atype95_5,
g_atype95_6,
g_atype95_7,
g_atype95_8,
g_atype95_9,
};

static const long offsets95 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags96 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_12 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_13 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_14 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
g_atype96_3,
g_atype96_4,
g_atype96_5,
g_atype96_6,
g_atype96_7,
g_atype96_8,
g_atype96_9,
g_atype96_10,
g_atype96_11,
g_atype96_12,
g_atype96_13,
g_atype96_14,
};

static const long offsets96 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags102 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_6 [] = {106,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
g_atype102_1,
g_atype102_2,
g_atype102_3,
g_atype102_4,
g_atype102_5,
g_atype102_6,
g_atype102_7,
g_atype102_8,
g_atype102_9,
};

static const long offsets102 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags104 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_3 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
g_atype104_1,
g_atype104_2,
g_atype104_3,
};

static const long offsets104 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @CHROFF(0,3),
};

extern const char *names105[];
static const uint32 types105 [] =
{
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags105 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype105_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_1 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes105 [] = {
g_atype105_0,
g_atype105_1,
};

static const long offsets105 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names106[];
static const uint32 types106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags106 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype106_0 [] = {649,175,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_1 [] = {649,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_2 [] = {174,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_3 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_12 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_13 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_14 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes106 [] = {
g_atype106_0,
g_atype106_1,
g_atype106_2,
g_atype106_3,
g_atype106_4,
g_atype106_5,
g_atype106_6,
g_atype106_7,
g_atype106_8,
g_atype106_9,
g_atype106_10,
g_atype106_11,
g_atype106_12,
g_atype106_13,
g_atype106_14,
};

static const long offsets106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags107 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {649,175,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_1 [] = {649,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_2 [] = {174,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_3 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_5 [] = {649,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_12 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_13 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_14 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_15 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_16 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_17 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_18 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_20 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_21 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_22 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
g_atype107_1,
g_atype107_2,
g_atype107_3,
g_atype107_4,
g_atype107_5,
g_atype107_6,
g_atype107_7,
g_atype107_8,
g_atype107_9,
g_atype107_10,
g_atype107_11,
g_atype107_12,
g_atype107_13,
g_atype107_14,
g_atype107_15,
g_atype107_16,
g_atype107_17,
g_atype107_18,
g_atype107_19,
g_atype107_20,
g_atype107_21,
g_atype107_22,
};

static const long offsets107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @CHROFF(7,12),
+ @CHROFF(7,13),
+ @CHROFF(7,14),
+ @CHROFF(7,15),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags109 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
g_atype109_1,
};

static const long offsets109 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names111[];
static const uint32 types111 [] =
{
SK_INT32,
};

static const uint16 attr_flags111 [] =
{0,};

static const EIF_TYPE_INDEX g_atype111_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes111 [] = {
g_atype111_0,
};

static const long offsets111 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_INT32,
};

static const uint16 attr_flags112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
};

static const long offsets112 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags113 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {46,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
g_atype113_2,
};

static const long offsets113 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags114 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {47,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
g_atype114_1,
g_atype114_2,
};

static const long offsets114 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags115 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
g_atype115_2,
};

static const long offsets115 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names118[];
static const uint32 types118 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags118 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype118_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes118 [] = {
g_atype118_0,
g_atype118_1,
g_atype118_2,
g_atype118_3,
g_atype118_4,
g_atype118_5,
g_atype118_6,
};

static const long offsets118 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names119[];
static const uint32 types119 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags119 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype119_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes119 [] = {
g_atype119_0,
g_atype119_1,
g_atype119_2,
g_atype119_3,
g_atype119_4,
g_atype119_5,
g_atype119_6,
};

static const long offsets119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names120[];
static const uint32 types120 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags120 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype120_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes120 [] = {
g_atype120_0,
g_atype120_1,
g_atype120_2,
g_atype120_3,
g_atype120_4,
g_atype120_5,
g_atype120_6,
};

static const long offsets120 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names121[];
static const uint32 types121 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags121 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype121_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes121 [] = {
g_atype121_0,
g_atype121_1,
g_atype121_2,
g_atype121_3,
g_atype121_4,
g_atype121_5,
g_atype121_6,
};

static const long offsets121 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags122 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
g_atype122_1,
g_atype122_2,
g_atype122_3,
g_atype122_4,
g_atype122_5,
g_atype122_6,
};

static const long offsets122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags123 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
g_atype123_1,
g_atype123_2,
g_atype123_3,
g_atype123_4,
g_atype123_5,
g_atype123_6,
};

static const long offsets123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags124 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
g_atype124_1,
g_atype124_2,
g_atype124_3,
g_atype124_4,
g_atype124_5,
g_atype124_6,
};

static const long offsets124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags125 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
g_atype125_1,
g_atype125_2,
g_atype125_3,
g_atype125_4,
g_atype125_5,
g_atype125_6,
g_atype125_7,
};

static const long offsets125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags126 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
g_atype126_1,
g_atype126_2,
g_atype126_3,
g_atype126_4,
g_atype126_5,
g_atype126_6,
g_atype126_7,
g_atype126_8,
g_atype126_9,
};

static const long offsets126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags127 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
g_atype127_2,
g_atype127_3,
g_atype127_4,
g_atype127_5,
g_atype127_6,
g_atype127_7,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
g_atype128_2,
g_atype128_3,
g_atype128_4,
g_atype128_5,
g_atype128_6,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags129 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
g_atype129_2,
g_atype129_3,
g_atype129_4,
g_atype129_5,
g_atype129_6,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags130 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
g_atype130_3,
g_atype130_4,
g_atype130_5,
g_atype130_6,
};

static const long offsets130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names131[];
static const uint32 types131 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags131 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype131_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes131 [] = {
g_atype131_0,
g_atype131_1,
g_atype131_2,
g_atype131_3,
g_atype131_4,
g_atype131_5,
g_atype131_6,
};

static const long offsets131 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags132 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
g_atype132_1,
g_atype132_2,
g_atype132_3,
g_atype132_4,
g_atype132_5,
g_atype132_6,
};

static const long offsets132 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags133 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
g_atype133_1,
g_atype133_2,
g_atype133_3,
g_atype133_4,
g_atype133_5,
g_atype133_6,
g_atype133_7,
};

static const long offsets133 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags134 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
g_atype134_1,
g_atype134_2,
g_atype134_3,
g_atype134_4,
g_atype134_5,
g_atype134_6,
};

static const long offsets134 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags135 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
g_atype135_2,
g_atype135_3,
g_atype135_4,
g_atype135_5,
g_atype135_6,
};

static const long offsets135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags136 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
g_atype136_2,
g_atype136_3,
g_atype136_4,
g_atype136_5,
g_atype136_6,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags137 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
g_atype137_2,
g_atype137_3,
g_atype137_4,
g_atype137_5,
g_atype137_6,
};

static const long offsets137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags138 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
g_atype138_1,
g_atype138_2,
g_atype138_3,
g_atype138_4,
g_atype138_5,
g_atype138_6,
g_atype138_7,
};

static const long offsets138 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
g_atype139_4,
g_atype139_5,
g_atype139_6,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
g_atype140_4,
g_atype140_5,
g_atype140_6,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
g_atype141_6,
g_atype141_7,
g_atype141_8,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags142 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
g_atype142_2,
g_atype142_3,
g_atype142_4,
g_atype142_5,
g_atype142_6,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags143 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
g_atype143_1,
g_atype143_2,
g_atype143_3,
g_atype143_4,
g_atype143_5,
g_atype143_6,
};

static const long offsets143 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
g_atype144_6,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags145 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
g_atype145_1,
g_atype145_2,
g_atype145_3,
g_atype145_4,
g_atype145_5,
g_atype145_6,
};

static const long offsets145 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags146 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
g_atype146_3,
g_atype146_4,
g_atype146_5,
g_atype146_6,
g_atype146_7,
g_atype146_8,
};

static const long offsets146 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags147 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
g_atype147_3,
g_atype147_4,
g_atype147_5,
g_atype147_6,
};

static const long offsets147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags148 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
g_atype148_1,
g_atype148_2,
g_atype148_3,
g_atype148_4,
g_atype148_5,
g_atype148_6,
};

static const long offsets148 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags149 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
g_atype149_1,
g_atype149_2,
g_atype149_3,
g_atype149_4,
g_atype149_5,
g_atype149_6,
};

static const long offsets149 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags150 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
g_atype150_1,
g_atype150_2,
g_atype150_3,
g_atype150_4,
g_atype150_5,
g_atype150_6,
};

static const long offsets150 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags151 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
g_atype151_2,
g_atype151_3,
g_atype151_4,
g_atype151_5,
g_atype151_6,
};

static const long offsets151 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags152 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
g_atype152_2,
g_atype152_3,
g_atype152_4,
g_atype152_5,
g_atype152_6,
};

static const long offsets152 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags153 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
g_atype153_2,
g_atype153_3,
g_atype153_4,
g_atype153_5,
g_atype153_6,
};

static const long offsets153 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
g_atype154_5,
g_atype154_6,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
g_atype155_5,
g_atype155_6,
g_atype155_7,
};

static const long offsets155 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
g_atype156_3,
g_atype156_4,
g_atype156_5,
g_atype156_6,
};

static const long offsets156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
g_atype157_5,
g_atype157_6,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags158 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
};

static const long offsets158 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names159[];
static const uint32 types159 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags159 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype159_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_1 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes159 [] = {
g_atype159_0,
g_atype159_1,
};

static const long offsets159 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names160[];
static const uint32 types160 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags160 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype160_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_1 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes160 [] = {
g_atype160_0,
g_atype160_1,
};

static const long offsets160 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
};

static const uint16 attr_flags162 [] =
{0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {896,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
};

static const long offsets162 [] =
{
0,
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
};

static const uint16 attr_flags163 [] =
{0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {896,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
};

static const long offsets163 [] =
{
0,
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
};

static const uint16 attr_flags164 [] =
{0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {896,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
};

static const long offsets164 [] =
{
0,
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags167 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
};

static const long offsets167 [] =
{
0,
 + @REFACS(1),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags169 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
};

static const long offsets169 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags170 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
};

static const long offsets170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags171 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
g_atype171_3,
};

static const long offsets171 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
g_atype173_3,
g_atype173_4,
};

static const long offsets173 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags174 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
g_atype174_1,
};

static const long offsets174 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
g_atype175_1,
g_atype175_2,
};

static const long offsets175 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags176 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
g_atype176_1,
};

static const long offsets176 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags179 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_6 [] = {53,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_11 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
g_atype179_2,
g_atype179_3,
g_atype179_4,
g_atype179_5,
g_atype179_6,
g_atype179_7,
g_atype179_8,
g_atype179_9,
g_atype179_10,
g_atype179_11,
};

static const long offsets179 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags182 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
};

static const long offsets182 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_9 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_10 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_11 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_12 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
g_atype183_6,
g_atype183_7,
g_atype183_8,
g_atype183_9,
g_atype183_10,
g_atype183_11,
g_atype183_12,
};

static const long offsets183 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
};

static const long offsets186 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {185,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
};

static const long offsets190 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags191 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
};

static const long offsets191 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
};

static const uint16 attr_flags192 [] =
{0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {684,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
};

static const long offsets192 [] =
{
0,
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
};

static const uint16 attr_flags193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {685,850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
};

static const long offsets193 [] =
{
0,
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
};

static const uint16 attr_flags194 [] =
{0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {686,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
};

static const long offsets194 [] =
{
0,
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
};

static const uint16 attr_flags195 [] =
{0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {687,829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
};

static const long offsets195 [] =
{
0,
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
};

static const uint16 attr_flags196 [] =
{0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {688,832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
};

static const long offsets196 [] =
{
0,
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
};

static const uint16 attr_flags197 [] =
{0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {689,820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
};

static const long offsets197 [] =
{
0,
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
};

static const uint16 attr_flags198 [] =
{0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {690,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
};

static const long offsets198 [] =
{
0,
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
};

static const uint16 attr_flags199 [] =
{0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {691,817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
};

static const long offsets199 [] =
{
0,
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
};

static const uint16 attr_flags200 [] =
{0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {692,835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
};

static const long offsets200 [] =
{
0,
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
};

static const uint16 attr_flags201 [] =
{0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {693,883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
};

static const long offsets201 [] =
{
0,
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
};

static const uint16 attr_flags202 [] =
{0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {694,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
};

static const long offsets202 [] =
{
0,
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
};

static const uint16 attr_flags203 [] =
{0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {695,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
};

static const long offsets203 [] =
{
0,
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
};

static const long offsets205 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_5 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
g_atype206_5,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_INT32,
};

static const uint16 attr_flags209 [] =
{0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
};

static const long offsets209 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names210[];
static const uint32 types210 [] =
{
SK_INT32,
};

static const uint16 attr_flags210 [] =
{0,};

static const EIF_TYPE_INDEX g_atype210_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes210 [] = {
g_atype210_0,
};

static const long offsets210 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names211[];
static const uint32 types211 [] =
{
SK_INT32,
};

static const uint16 attr_flags211 [] =
{0,};

static const EIF_TYPE_INDEX g_atype211_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes211 [] = {
g_atype211_0,
};

static const long offsets211 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {584,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {672,896,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_7 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_8 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_9 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_10 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_11 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_12 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_13 [] = {584,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_14 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_15 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_16 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_17 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_18 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_20 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_21 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_22 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_23 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_24 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_25 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_26 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_27 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_28 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_29 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
g_atype212_4,
g_atype212_5,
g_atype212_6,
g_atype212_7,
g_atype212_8,
g_atype212_9,
g_atype212_10,
g_atype212_11,
g_atype212_12,
g_atype212_13,
g_atype212_14,
g_atype212_15,
g_atype212_16,
g_atype212_17,
g_atype212_18,
g_atype212_19,
g_atype212_20,
g_atype212_21,
g_atype212_22,
g_atype212_23,
g_atype212_24,
g_atype212_25,
g_atype212_26,
g_atype212_27,
g_atype212_28,
g_atype212_29,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
+ @CHROFF(17,0),
+ @CHROFF(17,1),
+ @CHROFF(17,2),
+ @CHROFF(17,3),
+ @CHROFF(17,4),
+ @CHROFF(17,5),
+ @CHROFF(17,6),
+ @LNGOFF(17,7,0,0),
+ @LNGOFF(17,7,0,1),
+ @LNGOFF(17,7,0,2),
+ @LNGOFF(17,7,0,3),
+ @LNGOFF(17,7,0,4),
+ @LNGOFF(17,7,0,5),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags225 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {0xFFF5,1,684,0xFFF8,1,2772,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {0xFFF5,1,658,0xFFF8,1,2921,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
};

static const long offsets225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags226 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
};

static const long offsets226 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
};

static const uint16 attr_flags233 [] =
{0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {646,233,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
};

static const long offsets233 [] =
{
0,
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags234 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
g_atype234_3,
g_atype234_4,
};

static const long offsets234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
};

static const long offsets235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags236 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
g_atype236_1,
g_atype236_2,
g_atype236_3,
g_atype236_4,
};

static const long offsets236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags252 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
g_atype252_1,
g_atype252_2,
g_atype252_3,
};

static const long offsets252 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {559,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
g_atype282_4,
g_atype282_5,
g_atype282_6,
};

static const long offsets282 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags283 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {560,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
g_atype283_3,
g_atype283_4,
g_atype283_5,
g_atype283_6,
};

static const long offsets283 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {561,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
g_atype284_1,
g_atype284_2,
g_atype284_3,
g_atype284_4,
g_atype284_5,
g_atype284_6,
};

static const long offsets284 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags285 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {562,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
g_atype285_1,
g_atype285_2,
g_atype285_3,
g_atype285_4,
g_atype285_5,
g_atype285_6,
};

static const long offsets285 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags286 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {563,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
g_atype286_3,
g_atype286_4,
g_atype286_5,
g_atype286_6,
};

static const long offsets286 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {564,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
g_atype287_4,
g_atype287_5,
g_atype287_6,
};

static const long offsets287 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {565,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
g_atype288_5,
g_atype288_6,
};

static const long offsets288 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags289 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {566,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
g_atype289_6,
};

static const long offsets289 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {567,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
g_atype290_6,
};

static const long offsets290 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {568,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
g_atype291_6,
};

static const long offsets291 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {569,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
g_atype292_6,
};

static const long offsets292 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {570,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
g_atype293_6,
};

static const long offsets293 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {672,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
g_atype294_4,
g_atype294_5,
g_atype294_6,
};

static const long offsets294 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {673,0xFFF8,1,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
g_atype295_6,
};

static const long offsets295 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags296 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {674,844,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
g_atype296_5,
g_atype296_6,
};

static const long offsets296 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags297 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {675,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
g_atype297_4,
g_atype297_5,
g_atype297_6,
};

static const long offsets297 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {676,883,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
g_atype298_4,
g_atype298_5,
g_atype298_6,
};

static const long offsets298 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {646,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {46,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
g_atype299_4,
g_atype299_5,
g_atype299_6,
g_atype299_7,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags300 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {647,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {47,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
g_atype300_5,
g_atype300_6,
g_atype300_7,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags301 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {648,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
g_atype301_3,
g_atype301_4,
g_atype301_5,
g_atype301_6,
g_atype301_7,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags302 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
};

static const long offsets302 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags303 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
};

static const long offsets303 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags304 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
g_atype304_2,
};

static const long offsets304 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
g_atype305_2,
};

static const long offsets305 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags306 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
};

static const long offsets306 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names307[];
static const uint32 types307 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags307 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype307_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes307 [] = {
g_atype307_0,
g_atype307_1,
g_atype307_2,
};

static const long offsets307 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
};

static const long offsets308 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
};

static const long offsets309 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
};

static const long offsets310 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
};

static const long offsets311 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
};

static const long offsets312 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
};

static const long offsets313 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {659,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {660,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags316 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {661,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
g_atype316_3,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {662,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
};

static const long offsets317 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {663,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {664,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
};

static const long offsets319 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {665,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {666,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {667,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {668,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
};

static const long offsets323 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {669,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {670,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
};

static const long offsets327 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_1 [] = {584,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
g_atype328_1,
g_atype328_2,
g_atype328_3,
g_atype328_4,
};

static const long offsets328 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {585,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
};

static const long offsets329 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {587,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
};

static const long offsets331 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {588,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
};

static const long offsets332 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {589,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
g_atype333_3,
g_atype333_4,
};

static const long offsets333 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags334 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {590,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
g_atype334_2,
g_atype334_3,
g_atype334_4,
};

static const long offsets334 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags335 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {591,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
g_atype335_4,
};

static const long offsets335 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {592,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
g_atype336_4,
};

static const long offsets336 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {593,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
g_atype337_3,
g_atype337_4,
};

static const long offsets337 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags338 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {594,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
g_atype338_3,
g_atype338_4,
};

static const long offsets338 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags339 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {595,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
g_atype339_3,
g_atype339_4,
};

static const long offsets339 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags340 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
g_atype340_2,
};

static const long offsets340 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
};

static const long offsets341 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags342 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
};

static const long offsets342 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
};

static const long offsets343 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
g_atype344_2,
};

static const long offsets344 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags345 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
};

static const long offsets345 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags346 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
};

static const long offsets346 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
};

static const long offsets347 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags348 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
};

static const long offsets348 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags349 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
};

static const long offsets349 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags350 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
g_atype350_1,
g_atype350_2,
};

static const long offsets350 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags351 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
g_atype351_1,
g_atype351_2,
};

static const long offsets351 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_BOOL,
};

static const uint16 attr_flags352 [] =
{0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
};

static const long offsets352 [] =
{
+ @CHROFF(0,0),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_BOOL,
};

static const uint16 attr_flags353 [] =
{0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
};

static const long offsets353 [] =
{
+ @CHROFF(0,0),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_BOOL,
};

static const uint16 attr_flags354 [] =
{0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
};

static const long offsets354 [] =
{
+ @CHROFF(0,0),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_BOOL,
};

static const uint16 attr_flags355 [] =
{0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
};

static const long offsets355 [] =
{
+ @CHROFF(0,0),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_BOOL,
};

static const uint16 attr_flags356 [] =
{0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
};

static const long offsets356 [] =
{
+ @CHROFF(0,0),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_BOOL,
};

static const uint16 attr_flags357 [] =
{0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
};

static const long offsets357 [] =
{
+ @CHROFF(0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_BOOL,
};

static const uint16 attr_flags358 [] =
{0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
};

static const long offsets358 [] =
{
+ @CHROFF(0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_BOOL,
};

static const uint16 attr_flags359 [] =
{0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
};

static const long offsets359 [] =
{
+ @CHROFF(0,0),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_BOOL,
};

static const uint16 attr_flags360 [] =
{0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
};

static const long offsets360 [] =
{
+ @CHROFF(0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_BOOL,
};

static const uint16 attr_flags361 [] =
{0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
};

static const long offsets361 [] =
{
+ @CHROFF(0,0),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_BOOL,
};

static const uint16 attr_flags362 [] =
{0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
};

static const long offsets362 [] =
{
+ @CHROFF(0,0),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_BOOL,
};

static const uint16 attr_flags363 [] =
{0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
};

static const long offsets363 [] =
{
+ @CHROFF(0,0),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_BOOL,
};

static const uint16 attr_flags364 [] =
{0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
};

static const long offsets364 [] =
{
+ @CHROFF(0,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_BOOL,
};

static const uint16 attr_flags365 [] =
{0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
};

static const long offsets365 [] =
{
+ @CHROFF(0,0),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_BOOL,
};

static const uint16 attr_flags366 [] =
{0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
};

static const long offsets366 [] =
{
+ @CHROFF(0,0),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_BOOL,
};

static const uint16 attr_flags367 [] =
{0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
};

static const long offsets367 [] =
{
+ @CHROFF(0,0),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_BOOL,
};

static const uint16 attr_flags368 [] =
{0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
};

static const long offsets368 [] =
{
+ @CHROFF(0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_BOOL,
};

static const uint16 attr_flags369 [] =
{0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
};

static const long offsets369 [] =
{
+ @CHROFF(0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_BOOL,
};

static const uint16 attr_flags370 [] =
{0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
};

static const long offsets370 [] =
{
+ @CHROFF(0,0),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_BOOL,
};

static const uint16 attr_flags371 [] =
{0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
};

static const long offsets371 [] =
{
+ @CHROFF(0,0),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_BOOL,
};

static const uint16 attr_flags372 [] =
{0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
};

static const long offsets372 [] =
{
+ @CHROFF(0,0),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_BOOL,
};

static const uint16 attr_flags373 [] =
{0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
};

static const long offsets373 [] =
{
+ @CHROFF(0,0),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_BOOL,
};

static const uint16 attr_flags374 [] =
{0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
};

static const long offsets374 [] =
{
+ @CHROFF(0,0),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_BOOL,
};

static const uint16 attr_flags375 [] =
{0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
};

static const long offsets375 [] =
{
+ @CHROFF(0,0),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_BOOL,
};

static const uint16 attr_flags376 [] =
{0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
};

static const long offsets376 [] =
{
+ @CHROFF(0,0),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_BOOL,
};

static const uint16 attr_flags377 [] =
{0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
};

static const long offsets377 [] =
{
+ @CHROFF(0,0),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_BOOL,
};

static const uint16 attr_flags378 [] =
{0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
};

static const long offsets378 [] =
{
+ @CHROFF(0,0),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_BOOL,
};

static const uint16 attr_flags379 [] =
{0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
};

static const long offsets379 [] =
{
+ @CHROFF(0,0),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_BOOL,
};

static const uint16 attr_flags380 [] =
{0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
};

static const long offsets380 [] =
{
+ @CHROFF(0,0),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_BOOL,
};

static const uint16 attr_flags381 [] =
{0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
};

static const long offsets381 [] =
{
+ @CHROFF(0,0),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_BOOL,
};

static const uint16 attr_flags382 [] =
{0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
};

static const long offsets382 [] =
{
+ @CHROFF(0,0),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_BOOL,
};

static const uint16 attr_flags383 [] =
{0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
};

static const long offsets383 [] =
{
+ @CHROFF(0,0),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_BOOL,
};

static const uint16 attr_flags384 [] =
{0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
};

static const long offsets384 [] =
{
+ @CHROFF(0,0),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_BOOL,
};

static const uint16 attr_flags385 [] =
{0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
};

static const long offsets385 [] =
{
+ @CHROFF(0,0),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_BOOL,
};

static const uint16 attr_flags386 [] =
{0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
};

static const long offsets386 [] =
{
+ @CHROFF(0,0),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_BOOL,
};

static const uint16 attr_flags387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
};

static const long offsets387 [] =
{
+ @CHROFF(0,0),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_BOOL,
};

static const uint16 attr_flags388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
};

static const long offsets388 [] =
{
+ @CHROFF(0,0),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_BOOL,
};

static const uint16 attr_flags389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
};

static const long offsets389 [] =
{
+ @CHROFF(0,0),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_BOOL,
};

static const uint16 attr_flags390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
};

static const long offsets390 [] =
{
+ @CHROFF(0,0),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_BOOL,
};

static const uint16 attr_flags391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
};

static const long offsets391 [] =
{
+ @CHROFF(0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_BOOL,
};

static const uint16 attr_flags392 [] =
{0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
};

static const long offsets392 [] =
{
+ @CHROFF(0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_BOOL,
};

static const uint16 attr_flags393 [] =
{0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
};

static const long offsets393 [] =
{
+ @CHROFF(0,0),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_BOOL,
};

static const uint16 attr_flags394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
};

static const long offsets394 [] =
{
+ @CHROFF(0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_BOOL,
};

static const uint16 attr_flags395 [] =
{0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
};

static const long offsets395 [] =
{
+ @CHROFF(0,0),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_BOOL,
};

static const uint16 attr_flags396 [] =
{0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
};

static const long offsets396 [] =
{
+ @CHROFF(0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_BOOL,
};

static const uint16 attr_flags397 [] =
{0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
};

static const long offsets397 [] =
{
+ @CHROFF(0,0),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_BOOL,
};

static const uint16 attr_flags398 [] =
{0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
};

static const long offsets398 [] =
{
+ @CHROFF(0,0),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_BOOL,
};

static const uint16 attr_flags399 [] =
{0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
};

static const long offsets399 [] =
{
+ @CHROFF(0,0),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_BOOL,
};

static const uint16 attr_flags400 [] =
{0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
};

static const long offsets400 [] =
{
+ @CHROFF(0,0),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_BOOL,
};

static const uint16 attr_flags401 [] =
{0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
};

static const long offsets401 [] =
{
+ @CHROFF(0,0),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_BOOL,
};

static const uint16 attr_flags402 [] =
{0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
};

static const long offsets402 [] =
{
+ @CHROFF(0,0),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_BOOL,
};

static const uint16 attr_flags403 [] =
{0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
};

static const long offsets403 [] =
{
+ @CHROFF(0,0),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_BOOL,
};

static const uint16 attr_flags404 [] =
{0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
};

static const long offsets404 [] =
{
+ @CHROFF(0,0),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_BOOL,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
+ @CHROFF(0,0),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_BOOL,
};

static const uint16 attr_flags406 [] =
{0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
};

static const long offsets406 [] =
{
+ @CHROFF(0,0),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_BOOL,
};

static const uint16 attr_flags407 [] =
{0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
};

static const long offsets407 [] =
{
+ @CHROFF(0,0),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_BOOL,
};

static const uint16 attr_flags408 [] =
{0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
};

static const long offsets408 [] =
{
+ @CHROFF(0,0),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_BOOL,
};

static const uint16 attr_flags409 [] =
{0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
};

static const long offsets409 [] =
{
+ @CHROFF(0,0),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_BOOL,
};

static const uint16 attr_flags410 [] =
{0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
};

static const long offsets410 [] =
{
+ @CHROFF(0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_BOOL,
};

static const uint16 attr_flags411 [] =
{0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
};

static const long offsets411 [] =
{
+ @CHROFF(0,0),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_BOOL,
};

static const uint16 attr_flags412 [] =
{0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
};

static const long offsets412 [] =
{
+ @CHROFF(0,0),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_BOOL,
};

static const uint16 attr_flags413 [] =
{0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
};

static const long offsets413 [] =
{
+ @CHROFF(0,0),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_BOOL,
};

static const uint16 attr_flags414 [] =
{0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
};

static const long offsets414 [] =
{
+ @CHROFF(0,0),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_BOOL,
};

static const uint16 attr_flags415 [] =
{0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
};

static const long offsets415 [] =
{
+ @CHROFF(0,0),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_BOOL,
};

static const uint16 attr_flags416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
};

static const long offsets416 [] =
{
+ @CHROFF(0,0),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_BOOL,
};

static const uint16 attr_flags417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
};

static const long offsets417 [] =
{
+ @CHROFF(0,0),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_BOOL,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
+ @CHROFF(0,0),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_BOOL,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
+ @CHROFF(0,0),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_BOOL,
};

static const uint16 attr_flags420 [] =
{0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
};

static const long offsets420 [] =
{
+ @CHROFF(0,0),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_BOOL,
};

static const uint16 attr_flags421 [] =
{0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
};

static const long offsets421 [] =
{
+ @CHROFF(0,0),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_BOOL,
};

static const uint16 attr_flags422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
};

static const long offsets422 [] =
{
+ @CHROFF(0,0),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_BOOL,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
+ @CHROFF(0,0),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_BOOL,
};

static const uint16 attr_flags424 [] =
{0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
};

static const long offsets424 [] =
{
+ @CHROFF(0,0),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_BOOL,
};

static const uint16 attr_flags425 [] =
{0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
};

static const long offsets425 [] =
{
+ @CHROFF(0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_BOOL,
};

static const uint16 attr_flags426 [] =
{0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
};

static const long offsets426 [] =
{
+ @CHROFF(0,0),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_BOOL,
};

static const uint16 attr_flags427 [] =
{0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
};

static const long offsets427 [] =
{
+ @CHROFF(0,0),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_BOOL,
};

static const uint16 attr_flags428 [] =
{0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
};

static const long offsets428 [] =
{
+ @CHROFF(0,0),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_BOOL,
};

static const uint16 attr_flags429 [] =
{0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
};

static const long offsets429 [] =
{
+ @CHROFF(0,0),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_BOOL,
};

static const uint16 attr_flags430 [] =
{0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
};

static const long offsets430 [] =
{
+ @CHROFF(0,0),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_BOOL,
};

static const uint16 attr_flags431 [] =
{0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
};

static const long offsets431 [] =
{
+ @CHROFF(0,0),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_BOOL,
};

static const uint16 attr_flags432 [] =
{0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
};

static const long offsets432 [] =
{
+ @CHROFF(0,0),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_BOOL,
};

static const uint16 attr_flags433 [] =
{0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
};

static const long offsets433 [] =
{
+ @CHROFF(0,0),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_BOOL,
};

static const uint16 attr_flags434 [] =
{0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
};

static const long offsets434 [] =
{
+ @CHROFF(0,0),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_BOOL,
};

static const uint16 attr_flags435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
};

static const long offsets435 [] =
{
+ @CHROFF(0,0),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_BOOL,
};

static const uint16 attr_flags436 [] =
{0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
};

static const long offsets436 [] =
{
+ @CHROFF(0,0),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_BOOL,
};

static const uint16 attr_flags437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
};

static const long offsets437 [] =
{
+ @CHROFF(0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_BOOL,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @CHROFF(0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_BOOL,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @CHROFF(0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_BOOL,
};

static const uint16 attr_flags440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
};

static const long offsets440 [] =
{
+ @CHROFF(0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_BOOL,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @CHROFF(0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_BOOL,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @CHROFF(0,0),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_BOOL,
};

static const uint16 attr_flags443 [] =
{0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
};

static const long offsets443 [] =
{
+ @CHROFF(0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_BOOL,
};

static const uint16 attr_flags444 [] =
{0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
};

static const long offsets444 [] =
{
+ @CHROFF(0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
};

static const uint16 attr_flags445 [] =
{0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_BOOL,
};

static const uint16 attr_flags446 [] =
{0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
};

static const long offsets446 [] =
{
+ @CHROFF(0,0),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_BOOL,
};

static const uint16 attr_flags447 [] =
{0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
};

static const long offsets447 [] =
{
+ @CHROFF(0,0),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_BOOL,
};

static const uint16 attr_flags448 [] =
{0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
};

static const long offsets448 [] =
{
+ @CHROFF(0,0),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_BOOL,
};

static const uint16 attr_flags449 [] =
{0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
};

static const long offsets449 [] =
{
+ @CHROFF(0,0),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_BOOL,
};

static const uint16 attr_flags450 [] =
{0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
};

static const long offsets450 [] =
{
+ @CHROFF(0,0),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_BOOL,
};

static const uint16 attr_flags451 [] =
{0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
};

static const long offsets451 [] =
{
+ @CHROFF(0,0),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_BOOL,
};

static const uint16 attr_flags452 [] =
{0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
};

static const long offsets452 [] =
{
+ @CHROFF(0,0),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_BOOL,
};

static const uint16 attr_flags453 [] =
{0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
};

static const long offsets453 [] =
{
+ @CHROFF(0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_BOOL,
};

static const uint16 attr_flags454 [] =
{0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
};

static const long offsets454 [] =
{
+ @CHROFF(0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_BOOL,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @CHROFF(0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_BOOL,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
+ @CHROFF(0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags493 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
g_atype493_1,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags494 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
g_atype494_1,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags557 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_3 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_4 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_7 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_8 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_9 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_15 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_16 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_17 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_18 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_19 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
g_atype557_1,
g_atype557_2,
g_atype557_3,
g_atype557_4,
g_atype557_5,
g_atype557_6,
g_atype557_7,
g_atype557_8,
g_atype557_9,
g_atype557_10,
g_atype557_11,
g_atype557_12,
g_atype557_13,
g_atype557_14,
g_atype557_15,
g_atype557_16,
g_atype557_17,
g_atype557_18,
g_atype557_19,
};

static const long offsets557 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags558 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_3 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_4 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_5 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_8 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_9 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_10 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_16 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_17 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_18 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_19 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_20 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
g_atype558_1,
g_atype558_2,
g_atype558_3,
g_atype558_4,
g_atype558_5,
g_atype558_6,
g_atype558_7,
g_atype558_8,
g_atype558_9,
g_atype558_10,
g_atype558_11,
g_atype558_12,
g_atype558_13,
g_atype558_14,
g_atype558_15,
g_atype558_16,
g_atype558_17,
g_atype558_18,
g_atype558_19,
g_atype558_20,
};

static const long offsets558 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags559 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_3 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_4 [] = {6,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_5 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_6 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_10 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_11 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_12 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_13 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_17 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_18 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_19 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_20 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_21 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_22 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
g_atype559_1,
g_atype559_2,
g_atype559_3,
g_atype559_4,
g_atype559_5,
g_atype559_6,
g_atype559_7,
g_atype559_8,
g_atype559_9,
g_atype559_10,
g_atype559_11,
g_atype559_12,
g_atype559_13,
g_atype559_14,
g_atype559_15,
g_atype559_16,
g_atype559_17,
g_atype559_18,
g_atype559_19,
g_atype559_20,
g_atype559_21,
g_atype559_22,
};

static const long offsets559 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags584 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
g_atype584_1,
g_atype584_2,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags585 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
g_atype585_1,
g_atype585_2,
g_atype585_3,
};

static const long offsets585 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags586 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
g_atype586_1,
g_atype586_2,
g_atype586_3,
};

static const long offsets586 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags587 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
g_atype587_1,
g_atype587_2,
g_atype587_3,
};

static const long offsets587 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags588 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
g_atype588_1,
g_atype588_2,
g_atype588_3,
};

static const long offsets588 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags589 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
g_atype589_1,
g_atype589_2,
g_atype589_3,
};

static const long offsets589 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags590 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
g_atype590_1,
g_atype590_2,
g_atype590_3,
};

static const long offsets590 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags591 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
g_atype591_1,
g_atype591_2,
g_atype591_3,
};

static const long offsets591 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags592 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
g_atype592_1,
g_atype592_2,
g_atype592_3,
};

static const long offsets592 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags593 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
g_atype593_1,
g_atype593_2,
g_atype593_3,
};

static const long offsets593 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags594 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
g_atype594_1,
g_atype594_2,
g_atype594_3,
};

static const long offsets594 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags595 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
g_atype595_1,
g_atype595_2,
g_atype595_3,
};

static const long offsets595 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags596 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
g_atype596_1,
g_atype596_2,
g_atype596_3,
};

static const long offsets596 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags647 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {46,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_1 [] = {46,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
g_atype647_1,
g_atype647_2,
g_atype647_3,
g_atype647_4,
g_atype647_5,
};

static const long offsets647 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags648 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {47,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_1 [] = {47,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
g_atype648_1,
g_atype648_2,
g_atype648_3,
g_atype648_4,
g_atype648_5,
};

static const long offsets648 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags649 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_1 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_2 [] = {648,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_3 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
g_atype649_1,
g_atype649_2,
g_atype649_3,
g_atype649_4,
g_atype649_5,
g_atype649_6,
g_atype649_7,
};

static const long offsets649 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags650 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_1 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_2 [] = {649,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_3 [] = {48,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_7 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
g_atype650_1,
g_atype650_2,
g_atype650_3,
g_atype650_4,
g_atype650_5,
g_atype650_6,
g_atype650_7,
};

static const long offsets650 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags652 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
g_atype652_1,
g_atype652_2,
g_atype652_3,
g_atype652_4,
g_atype652_5,
g_atype652_6,
g_atype652_7,
g_atype652_8,
g_atype652_9,
};

static const long offsets652 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags653 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
g_atype653_1,
g_atype653_2,
g_atype653_3,
g_atype653_4,
g_atype653_5,
g_atype653_6,
g_atype653_7,
g_atype653_8,
g_atype653_9,
g_atype653_10,
};

static const long offsets653 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags654 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_11 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
g_atype654_1,
g_atype654_2,
g_atype654_3,
g_atype654_4,
g_atype654_5,
g_atype654_6,
g_atype654_7,
g_atype654_8,
g_atype654_9,
g_atype654_10,
g_atype654_11,
};

static const long offsets654 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
+ @LNGOFF(8,2,0,1),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags655 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
g_atype655_1,
g_atype655_2,
g_atype655_3,
g_atype655_4,
g_atype655_5,
g_atype655_6,
g_atype655_7,
g_atype655_8,
};

static const long offsets655 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags656 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
g_atype656_1,
g_atype656_2,
g_atype656_3,
g_atype656_4,
g_atype656_5,
g_atype656_6,
g_atype656_7,
g_atype656_8,
g_atype656_9,
};

static const long offsets656 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags657 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {672,896,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_1 [] = {677,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_2 [] = {659,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
g_atype657_1,
g_atype657_2,
g_atype657_3,
g_atype657_4,
};

static const long offsets657 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags659 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
g_atype659_1,
g_atype659_2,
g_atype659_3,
};

static const long offsets659 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags660 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
g_atype660_1,
g_atype660_2,
};

static const long offsets660 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags661 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {685,850,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
g_atype661_1,
g_atype661_2,
};

static const long offsets661 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags662 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
g_atype662_1,
g_atype662_2,
};

static const long offsets662 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags663 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
g_atype663_1,
g_atype663_2,
};

static const long offsets663 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags664 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
g_atype664_1,
g_atype664_2,
};

static const long offsets664 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags665 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {689,820,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
g_atype665_1,
g_atype665_2,
};

static const long offsets665 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags666 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {690,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
g_atype666_1,
g_atype666_2,
};

static const long offsets666 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags667 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {691,817,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
g_atype667_1,
g_atype667_2,
};

static const long offsets667 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags668 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
g_atype668_1,
g_atype668_2,
};

static const long offsets668 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags669 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
g_atype669_1,
g_atype669_2,
};

static const long offsets669 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags670 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {694,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
g_atype670_1,
g_atype670_2,
};

static const long offsets670 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags671 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {695,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
g_atype671_1,
g_atype671_2,
};

static const long offsets671 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_INT32,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags673 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_1 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_2 [] = {684,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_3 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_4 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_6 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_16 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
g_atype673_1,
g_atype673_2,
g_atype673_3,
g_atype673_4,
g_atype673_5,
g_atype673_6,
g_atype673_7,
g_atype673_8,
g_atype673_9,
g_atype673_10,
g_atype673_11,
g_atype673_12,
g_atype673_13,
g_atype673_14,
g_atype673_15,
g_atype673_16,
};

static const long offsets673 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags674 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_1 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_2 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_3 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_4 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_16 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
g_atype674_1,
g_atype674_2,
g_atype674_3,
g_atype674_4,
g_atype674_5,
g_atype674_6,
g_atype674_7,
g_atype674_8,
g_atype674_9,
g_atype674_10,
g_atype674_11,
g_atype674_12,
g_atype674_13,
g_atype674_14,
g_atype674_15,
g_atype674_16,
};

static const long offsets674 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags675 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_1 [] = {684,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_2 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_3 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_16 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
g_atype675_1,
g_atype675_2,
g_atype675_3,
g_atype675_4,
g_atype675_5,
g_atype675_6,
g_atype675_7,
g_atype675_8,
g_atype675_9,
g_atype675_10,
g_atype675_11,
g_atype675_12,
g_atype675_13,
g_atype675_14,
g_atype675_15,
g_atype675_16,
};

static const long offsets675 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags676 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_1 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_2 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_3 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_16 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
g_atype676_1,
g_atype676_2,
g_atype676_3,
g_atype676_4,
g_atype676_5,
g_atype676_6,
g_atype676_7,
g_atype676_8,
g_atype676_9,
g_atype676_10,
g_atype676_11,
g_atype676_12,
g_atype676_13,
g_atype676_14,
g_atype676_15,
g_atype676_16,
};

static const long offsets676 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags677 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {693,883,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_1 [] = {684,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_2 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_3 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_15 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_16 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
g_atype677_1,
g_atype677_2,
g_atype677_3,
g_atype677_4,
g_atype677_5,
g_atype677_6,
g_atype677_7,
g_atype677_8,
g_atype677_9,
g_atype677_10,
g_atype677_11,
g_atype677_12,
g_atype677_13,
g_atype677_14,
g_atype677_15,
g_atype677_16,
};

static const long offsets677 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags678 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_1 [] = {684,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_2 [] = {684,889,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_3 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_4 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_6 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_17 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
g_atype678_1,
g_atype678_2,
g_atype678_3,
g_atype678_4,
g_atype678_5,
g_atype678_6,
g_atype678_7,
g_atype678_8,
g_atype678_9,
g_atype678_10,
g_atype678_11,
g_atype678_12,
g_atype678_13,
g_atype678_14,
g_atype678_15,
g_atype678_16,
g_atype678_17,
};

static const long offsets678 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags679 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_1 [] = {684,889,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_2 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_3 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_4 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_17 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
g_atype679_1,
g_atype679_2,
g_atype679_3,
g_atype679_4,
g_atype679_5,
g_atype679_6,
g_atype679_7,
g_atype679_8,
g_atype679_9,
g_atype679_10,
g_atype679_11,
g_atype679_12,
g_atype679_13,
g_atype679_14,
g_atype679_15,
g_atype679_16,
g_atype679_17,
};

static const long offsets679 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags680 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_1 [] = {684,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_2 [] = {684,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_3 [] = {686,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_4 [] = {692,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_7 [] = {893,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_8 [] = {893,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_17 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_18 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
g_atype680_1,
g_atype680_2,
g_atype680_3,
g_atype680_4,
g_atype680_5,
g_atype680_6,
g_atype680_7,
g_atype680_8,
g_atype680_9,
g_atype680_10,
g_atype680_11,
g_atype680_12,
g_atype680_13,
g_atype680_14,
g_atype680_15,
g_atype680_16,
g_atype680_17,
g_atype680_18,
};

static const long offsets680 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags682 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_3 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
g_atype682_1,
g_atype682_2,
g_atype682_3,
g_atype682_4,
g_atype682_5,
g_atype682_6,
g_atype682_7,
g_atype682_8,
};

static const long offsets682 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags683 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_2 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_3 [] = {682,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_4 [] = {667,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_5 [] = {659,682,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_6 [] = {659,696,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_7 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_14 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
g_atype683_1,
g_atype683_2,
g_atype683_3,
g_atype683_4,
g_atype683_5,
g_atype683_6,
g_atype683_7,
g_atype683_8,
g_atype683_9,
g_atype683_10,
g_atype683_11,
g_atype683_12,
g_atype683_13,
g_atype683_14,
};

static const long offsets683 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags697 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_2 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
g_atype697_1,
g_atype697_2,
};

static const long offsets697 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags698 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
g_atype698_2,
g_atype698_3,
g_atype698_4,
g_atype698_5,
};

static const long offsets698 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags699 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
g_atype699_1,
g_atype699_2,
g_atype699_3,
g_atype699_4,
g_atype699_5,
};

static const long offsets699 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags700 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
g_atype700_1,
g_atype700_2,
g_atype700_3,
g_atype700_4,
g_atype700_5,
};

static const long offsets700 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags701 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_1 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
g_atype701_1,
g_atype701_2,
g_atype701_3,
g_atype701_4,
g_atype701_5,
};

static const long offsets701 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags702 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_5 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
g_atype702_1,
g_atype702_2,
g_atype702_3,
g_atype702_4,
g_atype702_5,
};

static const long offsets702 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags703 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
g_atype703_2,
g_atype703_3,
g_atype703_4,
g_atype703_5,
};

static const long offsets703 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags704 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
g_atype704_2,
g_atype704_3,
g_atype704_4,
g_atype704_5,
};

static const long offsets704 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags705 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
g_atype705_2,
g_atype705_3,
g_atype705_4,
g_atype705_5,
};

static const long offsets705 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags706 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_5 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
g_atype706_2,
g_atype706_3,
g_atype706_4,
g_atype706_5,
};

static const long offsets706 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags707 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
g_atype707_2,
g_atype707_3,
g_atype707_4,
g_atype707_5,
};

static const long offsets707 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags708 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
g_atype708_2,
g_atype708_3,
g_atype708_4,
g_atype708_5,
};

static const long offsets708 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags709 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_5 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
g_atype709_1,
g_atype709_2,
g_atype709_3,
g_atype709_4,
g_atype709_5,
};

static const long offsets709 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags710 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_5 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
g_atype710_1,
g_atype710_2,
g_atype710_3,
g_atype710_4,
g_atype710_5,
};

static const long offsets710 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags711 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_1 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
g_atype711_1,
g_atype711_2,
g_atype711_3,
g_atype711_4,
g_atype711_5,
};

static const long offsets711 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags712 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_5 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
g_atype712_1,
g_atype712_2,
g_atype712_3,
g_atype712_4,
g_atype712_5,
};

static const long offsets712 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags713 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
g_atype713_1,
g_atype713_2,
g_atype713_3,
g_atype713_4,
};

static const long offsets713 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags714 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_2 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
g_atype714_1,
g_atype714_2,
g_atype714_3,
g_atype714_4,
};

static const long offsets714 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags715 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
g_atype715_1,
g_atype715_2,
g_atype715_3,
g_atype715_4,
};

static const long offsets715 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags716 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_4 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
g_atype716_1,
g_atype716_2,
g_atype716_3,
g_atype716_4,
};

static const long offsets716 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags717 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_2 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
g_atype717_1,
g_atype717_2,
g_atype717_3,
g_atype717_4,
};

static const long offsets717 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags718 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
g_atype718_1,
g_atype718_2,
g_atype718_3,
g_atype718_4,
};

static const long offsets718 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags719 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
g_atype719_1,
g_atype719_2,
g_atype719_3,
g_atype719_4,
};

static const long offsets719 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags720 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_4 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
g_atype720_1,
g_atype720_2,
g_atype720_3,
g_atype720_4,
};

static const long offsets720 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags721 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
g_atype721_1,
g_atype721_2,
g_atype721_3,
g_atype721_4,
};

static const long offsets721 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags722 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_4 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
g_atype722_1,
g_atype722_2,
g_atype722_3,
g_atype722_4,
};

static const long offsets722 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags723 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_2 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
g_atype723_1,
g_atype723_2,
g_atype723_3,
g_atype723_4,
};

static const long offsets723 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags724 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype724_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype724_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype724_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype724_4 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
g_atype724_1,
g_atype724_2,
g_atype724_3,
g_atype724_4,
};

static const long offsets724 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags725 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype725_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype725_2 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype725_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype725_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
g_atype725_1,
g_atype725_2,
g_atype725_3,
g_atype725_4,
};

static const long offsets725 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags726 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype726_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype726_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype726_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype726_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
g_atype726_1,
g_atype726_2,
g_atype726_3,
g_atype726_4,
};

static const long offsets726 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags727 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype727_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype727_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype727_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype727_4 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
g_atype727_1,
g_atype727_2,
g_atype727_3,
g_atype727_4,
};

static const long offsets727 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags728 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype728_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype728_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype728_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype728_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype728_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
g_atype728_1,
g_atype728_2,
g_atype728_3,
g_atype728_4,
g_atype728_5,
};

static const long offsets728 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags729 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype729_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype729_2 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype729_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype729_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype729_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
g_atype729_1,
g_atype729_2,
g_atype729_3,
g_atype729_4,
g_atype729_5,
};

static const long offsets729 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags730 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype730_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype730_2 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype730_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype730_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype730_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
g_atype730_1,
g_atype730_2,
g_atype730_3,
g_atype730_4,
g_atype730_5,
};

static const long offsets730 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags731 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype731_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype731_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype731_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype731_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype731_5 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
g_atype731_1,
g_atype731_2,
g_atype731_3,
g_atype731_4,
g_atype731_5,
};

static const long offsets731 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags732 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_2 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
g_atype732_1,
g_atype732_2,
g_atype732_3,
g_atype732_4,
g_atype732_5,
};

static const long offsets732 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags733 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_2 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
g_atype733_1,
g_atype733_2,
g_atype733_3,
g_atype733_4,
g_atype733_5,
};

static const long offsets733 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags734 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_5 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
g_atype734_1,
g_atype734_2,
g_atype734_3,
g_atype734_4,
g_atype734_5,
};

static const long offsets734 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags735 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype735_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype735_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype735_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype735_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype735_5 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
g_atype735_1,
g_atype735_2,
g_atype735_3,
g_atype735_4,
g_atype735_5,
};

static const long offsets735 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags736 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype736_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype736_2 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype736_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype736_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype736_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
g_atype736_1,
g_atype736_2,
g_atype736_3,
g_atype736_4,
g_atype736_5,
};

static const long offsets736 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags737 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
g_atype737_1,
g_atype737_2,
g_atype737_3,
g_atype737_4,
g_atype737_5,
};

static const long offsets737 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags738 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_5 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
g_atype738_1,
g_atype738_2,
g_atype738_3,
g_atype738_4,
g_atype738_5,
};

static const long offsets738 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags739 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
g_atype739_1,
g_atype739_2,
g_atype739_3,
g_atype739_4,
g_atype739_5,
};

static const long offsets739 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags740 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
g_atype740_1,
g_atype740_2,
g_atype740_3,
g_atype740_4,
g_atype740_5,
};

static const long offsets740 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags741 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_5 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
g_atype741_1,
g_atype741_2,
g_atype741_3,
g_atype741_4,
g_atype741_5,
};

static const long offsets741 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags742 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {0xFFF9,2,811,844,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
g_atype742_1,
g_atype742_2,
g_atype742_3,
g_atype742_4,
g_atype742_5,
};

static const long offsets742 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags746 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_9 [] = {620,53,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
g_atype746_1,
g_atype746_2,
g_atype746_3,
g_atype746_4,
g_atype746_5,
g_atype746_6,
g_atype746_7,
g_atype746_8,
g_atype746_9,
g_atype746_10,
g_atype746_11,
g_atype746_12,
};

static const long offsets746 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @LNGOFF(10,2,0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags747 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
g_atype747_1,
g_atype747_2,
g_atype747_3,
g_atype747_4,
g_atype747_5,
g_atype747_6,
g_atype747_7,
g_atype747_8,
g_atype747_9,
};

static const long offsets747 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags748 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
g_atype748_1,
g_atype748_2,
g_atype748_3,
g_atype748_4,
g_atype748_5,
g_atype748_6,
g_atype748_7,
g_atype748_8,
g_atype748_9,
g_atype748_10,
};

static const long offsets748 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags749 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
g_atype749_1,
g_atype749_2,
g_atype749_3,
g_atype749_4,
g_atype749_5,
g_atype749_6,
g_atype749_7,
g_atype749_8,
};

static const long offsets749 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags750 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
g_atype750_1,
g_atype750_2,
g_atype750_3,
g_atype750_4,
g_atype750_5,
g_atype750_6,
g_atype750_7,
g_atype750_8,
};

static const long offsets750 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags751 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_8 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
g_atype751_1,
g_atype751_2,
g_atype751_3,
g_atype751_4,
g_atype751_5,
g_atype751_6,
g_atype751_7,
g_atype751_8,
};

static const long offsets751 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags752 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
g_atype752_1,
g_atype752_2,
g_atype752_3,
g_atype752_4,
g_atype752_5,
g_atype752_6,
g_atype752_7,
g_atype752_8,
g_atype752_9,
g_atype752_10,
};

static const long offsets752 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_1 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
g_atype753_1,
};

static const long offsets753 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags754 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
g_atype754_1,
g_atype754_2,
g_atype754_3,
g_atype754_4,
g_atype754_5,
g_atype754_6,
g_atype754_7,
g_atype754_8,
g_atype754_9,
};

static const long offsets754 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags755 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
g_atype755_1,
g_atype755_2,
g_atype755_3,
g_atype755_4,
g_atype755_5,
g_atype755_6,
g_atype755_7,
g_atype755_8,
g_atype755_9,
};

static const long offsets755 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags756 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {620,907,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_1 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
g_atype756_1,
g_atype756_2,
g_atype756_3,
g_atype756_4,
g_atype756_5,
g_atype756_6,
};

static const long offsets756 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags757 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {620,907,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_1 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
g_atype757_1,
g_atype757_2,
g_atype757_3,
g_atype757_4,
g_atype757_5,
g_atype757_6,
};

static const long offsets757 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags758 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_8 [] = {646,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_11 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
g_atype758_1,
g_atype758_2,
g_atype758_3,
g_atype758_4,
g_atype758_5,
g_atype758_6,
g_atype758_7,
g_atype758_8,
g_atype758_9,
g_atype758_10,
g_atype758_11,
};

static const long offsets758 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags759 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_8 [] = {646,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_11 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
g_atype759_1,
g_atype759_2,
g_atype759_3,
g_atype759_4,
g_atype759_5,
g_atype759_6,
g_atype759_7,
g_atype759_8,
g_atype759_9,
g_atype759_10,
g_atype759_11,
};

static const long offsets759 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags760 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_8 [] = {646,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_11 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
g_atype760_1,
g_atype760_2,
g_atype760_3,
g_atype760_4,
g_atype760_5,
g_atype760_6,
g_atype760_7,
g_atype760_8,
g_atype760_9,
g_atype760_10,
g_atype760_11,
};

static const long offsets760 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags761 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
g_atype761_1,
g_atype761_2,
g_atype761_3,
g_atype761_4,
g_atype761_5,
g_atype761_6,
g_atype761_7,
g_atype761_8,
g_atype761_9,
g_atype761_10,
g_atype761_11,
g_atype761_12,
};

static const long offsets761 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags762 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
g_atype762_1,
g_atype762_2,
g_atype762_3,
g_atype762_4,
g_atype762_5,
g_atype762_6,
g_atype762_7,
g_atype762_8,
g_atype762_9,
g_atype762_10,
g_atype762_11,
g_atype762_12,
};

static const long offsets762 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags763 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
g_atype763_1,
g_atype763_2,
g_atype763_3,
g_atype763_4,
g_atype763_5,
g_atype763_6,
g_atype763_7,
g_atype763_8,
g_atype763_9,
g_atype763_10,
g_atype763_11,
g_atype763_12,
};

static const long offsets763 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags764 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
g_atype764_1,
g_atype764_2,
g_atype764_3,
g_atype764_4,
g_atype764_5,
g_atype764_6,
g_atype764_7,
g_atype764_8,
g_atype764_9,
g_atype764_10,
g_atype764_11,
g_atype764_12,
};

static const long offsets764 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags765 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
g_atype765_1,
g_atype765_2,
g_atype765_3,
g_atype765_4,
g_atype765_5,
g_atype765_6,
g_atype765_7,
g_atype765_8,
g_atype765_9,
g_atype765_10,
g_atype765_11,
g_atype765_12,
};

static const long offsets765 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags766 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
g_atype766_1,
g_atype766_2,
g_atype766_3,
g_atype766_4,
g_atype766_5,
g_atype766_6,
g_atype766_7,
g_atype766_8,
g_atype766_9,
g_atype766_10,
g_atype766_11,
g_atype766_12,
};

static const long offsets766 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags767 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
g_atype767_1,
g_atype767_2,
g_atype767_3,
g_atype767_4,
g_atype767_5,
g_atype767_6,
g_atype767_7,
g_atype767_8,
g_atype767_9,
};

static const long offsets767 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags768 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
g_atype768_1,
g_atype768_2,
g_atype768_3,
g_atype768_4,
g_atype768_5,
g_atype768_6,
g_atype768_7,
g_atype768_8,
g_atype768_9,
};

static const long offsets768 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags769 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_9 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
g_atype769_1,
g_atype769_2,
g_atype769_3,
g_atype769_4,
g_atype769_5,
g_atype769_6,
g_atype769_7,
g_atype769_8,
g_atype769_9,
};

static const long offsets769 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags770 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
g_atype770_1,
g_atype770_2,
g_atype770_3,
g_atype770_4,
g_atype770_5,
g_atype770_6,
g_atype770_7,
g_atype770_8,
g_atype770_9,
g_atype770_10,
};

static const long offsets770 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags771 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_8 [] = {620,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_9 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_12 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_14 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
g_atype771_1,
g_atype771_2,
g_atype771_3,
g_atype771_4,
g_atype771_5,
g_atype771_6,
g_atype771_7,
g_atype771_8,
g_atype771_9,
g_atype771_10,
g_atype771_11,
g_atype771_12,
g_atype771_13,
g_atype771_14,
};

static const long offsets771 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @LNGOFF(10,3,0,0),
+ @LNGOFF(10,3,0,1),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags772 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
g_atype772_2,
g_atype772_3,
g_atype772_4,
g_atype772_5,
g_atype772_6,
g_atype772_7,
g_atype772_8,
g_atype772_9,
g_atype772_10,
};

static const long offsets772 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags773 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
g_atype773_4,
g_atype773_5,
g_atype773_6,
g_atype773_7,
g_atype773_8,
g_atype773_9,
g_atype773_10,
};

static const long offsets773 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags774 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
g_atype774_3,
g_atype774_4,
g_atype774_5,
g_atype774_6,
g_atype774_7,
g_atype774_8,
g_atype774_9,
g_atype774_10,
};

static const long offsets774 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags775 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
g_atype775_2,
g_atype775_3,
g_atype775_4,
g_atype775_5,
g_atype775_6,
g_atype775_7,
g_atype775_8,
g_atype775_9,
g_atype775_10,
};

static const long offsets775 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags776 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
g_atype776_3,
g_atype776_4,
g_atype776_5,
g_atype776_6,
g_atype776_7,
g_atype776_8,
g_atype776_9,
g_atype776_10,
};

static const long offsets776 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags777 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
g_atype777_2,
g_atype777_3,
g_atype777_4,
g_atype777_5,
g_atype777_6,
g_atype777_7,
g_atype777_8,
g_atype777_9,
g_atype777_10,
};

static const long offsets777 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
+ @LNGOFF(7,2,0,1),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags778 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_4 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_7 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
g_atype778_2,
g_atype778_3,
g_atype778_4,
g_atype778_5,
g_atype778_6,
g_atype778_7,
g_atype778_8,
g_atype778_9,
g_atype778_10,
g_atype778_11,
g_atype778_12,
};

static const long offsets778 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags780 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
g_atype780_2,
};

static const long offsets780 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags781 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
};

static const long offsets781 [] =
{
0,
 + @REFACS(1),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags782 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
};

static const long offsets782 [] =
{
0,
 + @REFACS(1),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags783 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
};

static const long offsets783 [] =
{
0,
 + @REFACS(1),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags784 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
};

static const long offsets784 [] =
{
0,
 + @REFACS(1),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags785 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
};

static const long offsets785 [] =
{
0,
 + @REFACS(1),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags786 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
};

static const long offsets786 [] =
{
0,
 + @REFACS(1),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags787 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
g_atype787_1,
};

static const long offsets787 [] =
{
0,
 + @REFACS(1),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags788 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
g_atype788_1,
};

static const long offsets788 [] =
{
0,
 + @REFACS(1),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags789 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
g_atype789_1,
};

static const long offsets789 [] =
{
0,
 + @REFACS(1),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags790 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
g_atype790_1,
};

static const long offsets790 [] =
{
0,
 + @REFACS(1),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags791 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
g_atype791_1,
};

static const long offsets791 [] =
{
0,
 + @REFACS(1),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags792 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
g_atype792_1,
};

static const long offsets792 [] =
{
0,
 + @REFACS(1),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags793 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
g_atype793_1,
};

static const long offsets793 [] =
{
0,
 + @REFACS(1),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags794 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
g_atype794_1,
};

static const long offsets794 [] =
{
0,
 + @REFACS(1),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags795 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
g_atype795_1,
};

static const long offsets795 [] =
{
0,
 + @REFACS(1),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags796 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
};

static const long offsets796 [] =
{
0,
 + @REFACS(1),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags797 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
};

static const long offsets797 [] =
{
0,
 + @REFACS(1),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags798 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
};

static const long offsets798 [] =
{
0,
 + @REFACS(1),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags799 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
};

static const long offsets799 [] =
{
0,
 + @REFACS(1),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags800 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
};

static const long offsets800 [] =
{
0,
 + @REFACS(1),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags801 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
};

static const long offsets801 [] =
{
0,
 + @REFACS(1),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags802 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
};

static const long offsets802 [] =
{
0,
 + @REFACS(1),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags803 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
};

static const long offsets803 [] =
{
0,
 + @REFACS(1),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags804 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
};

static const long offsets804 [] =
{
0,
 + @REFACS(1),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags805 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
};

static const long offsets805 [] =
{
0,
 + @REFACS(1),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags806 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
};

static const long offsets806 [] =
{
0,
 + @REFACS(1),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags807 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
};

static const long offsets807 [] =
{
0,
 + @REFACS(1),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags808 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
};

static const long offsets808 [] =
{
0,
 + @REFACS(1),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags809 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
};

static const long offsets809 [] =
{
0,
 + @REFACS(1),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags810 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
g_atype810_1,
};

static const long offsets810 [] =
{
0,
 + @REFACS(1),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags811 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
g_atype811_1,
};

static const long offsets811 [] =
{
0,
 + @REFACS(1),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_UINT32,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_UINT32,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_UINT32,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_UINT16,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_UINT16,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_UINT16,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_UINT8,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_UINT8,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_UINT8,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_REAL32,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_REAL32,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_REAL32,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_REAL64,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_REAL64,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_REAL64,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags828 [] =
{0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
};

static const long offsets828 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags829 [] =
{0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
};

static const long offsets829 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @CHROFF(0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @CHROFF(0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @CHROFF(0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_BOOL,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @CHROFF(0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_BOOL,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @CHROFF(0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_BOOL,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @CHROFF(0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_INT8,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @CHROFF(0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_INT8,
};

static const uint16 attr_flags838 [] =
{0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
};

static const long offsets838 [] =
{
+ @CHROFF(0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_INT8,
};

static const uint16 attr_flags839 [] =
{0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
};

static const long offsets839 [] =
{
+ @CHROFF(0,0),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_INT64,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_INT64,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_INT64,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_INT32,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_INT32,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_INT32,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_INT16,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_INT16,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_INT16,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_UINT64,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_UINT64,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_UINT64,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {850,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_POINTER,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_POINTER,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_POINTER,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_POINTER,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_POINTER,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_POINTER,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_POINTER,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_POINTER,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_POINTER,
};

static const uint16 attr_flags860 [] =
{0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
};

static const long offsets860 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_POINTER,
};

static const uint16 attr_flags861 [] =
{0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
};

static const long offsets861 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_POINTER,
};

static const uint16 attr_flags862 [] =
{0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
};

static const long offsets862 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_POINTER,
};

static const uint16 attr_flags863 [] =
{0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
};

static const long offsets863 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_POINTER,
};

static const uint16 attr_flags864 [] =
{0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
};

static const long offsets864 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_POINTER,
};

static const uint16 attr_flags865 [] =
{0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
};

static const long offsets865 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_POINTER,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_POINTER,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_POINTER,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_POINTER,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_POINTER,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_POINTER,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_POINTER,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_POINTER,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_POINTER,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_POINTER,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_POINTER,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_POINTER,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_POINTER,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_POINTER,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_POINTER,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_POINTER,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_POINTER,
};

static const uint16 attr_flags882 [] =
{0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
};

static const long offsets882 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_POINTER,
};

static const uint16 attr_flags883 [] =
{0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
};

static const long offsets883 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_POINTER,
};

static const uint16 attr_flags884 [] =
{0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
};

static const long offsets884 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags885 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_1 [] = {0xFFF9,0,811,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_2 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_3 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_9 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_10 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_11 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
g_atype885_1,
g_atype885_2,
g_atype885_3,
g_atype885_4,
g_atype885_5,
g_atype885_6,
g_atype885_7,
g_atype885_8,
g_atype885_9,
g_atype885_10,
g_atype885_11,
};

static const long offsets885 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags886 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {0xFFF9,0,811,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_2 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_3 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_9 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_10 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_11 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
g_atype886_2,
g_atype886_3,
g_atype886_4,
g_atype886_5,
g_atype886_6,
g_atype886_7,
g_atype886_8,
g_atype886_9,
g_atype886_10,
g_atype886_11,
};

static const long offsets886 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags887 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {0xFFF9,0,811,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_2 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_3 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_10 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_11 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_12 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
g_atype887_2,
g_atype887_3,
g_atype887_4,
g_atype887_5,
g_atype887_6,
g_atype887_7,
g_atype887_8,
g_atype887_9,
g_atype887_10,
g_atype887_11,
g_atype887_12,
};

static const long offsets887 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags888 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {0xFFF9,0,811,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_2 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_3 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_10 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_11 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_12 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
g_atype888_2,
g_atype888_3,
g_atype888_4,
g_atype888_5,
g_atype888_6,
g_atype888_7,
g_atype888_8,
g_atype888_9,
g_atype888_10,
g_atype888_11,
g_atype888_12,
};

static const long offsets888 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags889 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {0xFFF9,0,811,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_2 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_3 [] = {586,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_10 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_11 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_12 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
g_atype889_2,
g_atype889_3,
g_atype889_4,
g_atype889_5,
g_atype889_6,
g_atype889_7,
g_atype889_8,
g_atype889_9,
g_atype889_10,
g_atype889_11,
g_atype889_12,
};

static const long offsets889 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags890 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
};

static const long offsets890 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags891 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
};

static const long offsets891 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags892 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
};

static const long offsets892 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags893 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
g_atype893_2,
g_atype893_3,
};

static const long offsets893 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags894 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
g_atype894_2,
g_atype894_3,
g_atype894_4,
};

static const long offsets894 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags895 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
g_atype895_2,
g_atype895_3,
g_atype895_4,
};

static const long offsets895 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags896 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {688,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_5 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
g_atype896_2,
g_atype896_3,
g_atype896_4,
g_atype896_5,
};

static const long offsets896 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags897 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_3 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
g_atype897_1,
g_atype897_2,
g_atype897_3,
};

static const long offsets897 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags898 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
g_atype898_1,
g_atype898_2,
g_atype898_3,
g_atype898_4,
};

static const long offsets898 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags899 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {687,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_4 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
g_atype899_1,
g_atype899_2,
g_atype899_3,
g_atype899_4,
};

static const long offsets899 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags900 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_1 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_2 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_3 [] = {898,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_4 [] = {6,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_5 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_6 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_10 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_11 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_12 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_13 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_15 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_17 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_18 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_19 [] = {883,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_20 [] = {850,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_21 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_22 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
g_atype900_1,
g_atype900_2,
g_atype900_3,
g_atype900_4,
g_atype900_5,
g_atype900_6,
g_atype900_7,
g_atype900_8,
g_atype900_9,
g_atype900_10,
g_atype900_11,
g_atype900_12,
g_atype900_13,
g_atype900_14,
g_atype900_15,
g_atype900_16,
g_atype900_17,
g_atype900_18,
g_atype900_19,
g_atype900_20,
g_atype900_21,
g_atype900_22,
};

static const long offsets900 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags902 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {673,681,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_1 [] = {584,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_2 [] = {584,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_3 [] = {920,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_6 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
g_atype902_1,
g_atype902_2,
g_atype902_3,
g_atype902_4,
g_atype902_5,
g_atype902_6,
};

static const long offsets902 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags903 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
g_atype903_1,
g_atype903_2,
};

static const long offsets903 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags904 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
g_atype904_1,
g_atype904_2,
};

static const long offsets904 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags905 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {889,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_2 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
g_atype905_1,
g_atype905_2,
};

static const long offsets905 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags907 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {232,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_1 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_7 [] = {677,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_8 [] = {926,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_9 [] = {105,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_10 [] = {925,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_11 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_12 [] = {103,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_13 [] = {620,53,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_14 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_15 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_16 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_17 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_18 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_19 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_20 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
g_atype907_1,
g_atype907_2,
g_atype907_3,
g_atype907_4,
g_atype907_5,
g_atype907_6,
g_atype907_7,
g_atype907_8,
g_atype907_9,
g_atype907_10,
g_atype907_11,
g_atype907_12,
g_atype907_13,
g_atype907_14,
g_atype907_15,
g_atype907_16,
g_atype907_17,
g_atype907_18,
g_atype907_19,
g_atype907_20,
};

static const long offsets907 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @LNGOFF(14,2,0,0),
+ @LNGOFF(14,2,0,1),
+ @LNGOFF(14,2,0,2),
+ @LNGOFF(14,2,0,3),
+ @LNGOFF(14,2,0,4),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags908 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_1 [] = {232,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_3 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_6 [] = {620,896,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_7 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
g_atype908_1,
g_atype908_2,
g_atype908_3,
g_atype908_4,
g_atype908_5,
g_atype908_6,
g_atype908_7,
};

static const long offsets908 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags909 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_1 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_3 [] = {620,779,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_5 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
g_atype909_1,
g_atype909_2,
g_atype909_3,
g_atype909_4,
g_atype909_5,
g_atype909_6,
g_atype909_7,
g_atype909_8,
g_atype909_9,
g_atype909_10,
};

static const long offsets909 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags910 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_1 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_2 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_3 [] = {620,779,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_5 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
g_atype910_1,
g_atype910_2,
g_atype910_3,
g_atype910_4,
g_atype910_5,
g_atype910_6,
g_atype910_7,
g_atype910_8,
g_atype910_9,
g_atype910_10,
};

static const long offsets910 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags911 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_3 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
g_atype911_1,
g_atype911_2,
g_atype911_3,
};

static const long offsets911 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags912 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {181,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_1 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_3 [] = {883,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
g_atype912_1,
g_atype912_2,
g_atype912_3,
};

static const long offsets912 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags913 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
g_atype913_1,
};

static const long offsets913 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags914 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_1 [] = {232,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_2 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_3 [] = {646,53,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_4 [] = {677,53,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_7 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_8 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_9 [] = {53,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_12 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_13 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_14 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
g_atype914_1,
g_atype914_2,
g_atype914_3,
g_atype914_4,
g_atype914_5,
g_atype914_6,
g_atype914_7,
g_atype914_8,
g_atype914_9,
g_atype914_10,
g_atype914_11,
g_atype914_12,
g_atype914_13,
g_atype914_14,
};

static const long offsets914 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @LNGOFF(10,4,0,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags915 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {682,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_1 [] = {682,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_2 [] = {682,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_3 [] = {646,0xFFF9,2,811,682,659,0xFFF9,2,811,696,696,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_4 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_6 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_10 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
g_atype915_1,
g_atype915_2,
g_atype915_3,
g_atype915_4,
g_atype915_5,
g_atype915_6,
g_atype915_7,
g_atype915_8,
g_atype915_9,
g_atype915_10,
};

static const long offsets915 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags916 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_1 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
g_atype916_1,
};

static const long offsets916 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags917 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_1 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
g_atype917_1,
};

static const long offsets917 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_INT32,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_INT32,
};

static const uint16 attr_flags919 [] =
{0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
};

static const long offsets919 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags920 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_2 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
g_atype920_1,
g_atype920_2,
};

static const long offsets920 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags921 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_1 [] = {892,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_2 [] = {673,681,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_3 [] = {584,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_4 [] = {584,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_5 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_9 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_10 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_11 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_12 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_13 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_14 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_15 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
g_atype921_1,
g_atype921_2,
g_atype921_3,
g_atype921_4,
g_atype921_5,
g_atype921_6,
g_atype921_7,
g_atype921_8,
g_atype921_9,
g_atype921_10,
g_atype921_11,
g_atype921_12,
g_atype921_13,
g_atype921_14,
g_atype921_15,
};

static const long offsets921 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
+ @R64OFF(5,1,0,8,0,0,0,0),
+ @R64OFF(5,1,0,8,0,0,0,1),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags922 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {916,0xFFFF};
static const EIF_TYPE_INDEX g_atype922_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype922_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype922_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype922_4 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
g_atype922_1,
g_atype922_2,
g_atype922_3,
g_atype922_4,
};

static const long offsets922 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags923 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_1 [] = {232,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_2 [] = {656,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_3 [] = {646,907,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_5 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_6 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_7 [] = {779,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_8 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_9 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_10 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_11 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_12 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
g_atype923_1,
g_atype923_2,
g_atype923_3,
g_atype923_4,
g_atype923_5,
g_atype923_6,
g_atype923_7,
g_atype923_8,
g_atype923_9,
g_atype923_10,
g_atype923_11,
g_atype923_12,
};

static const long offsets923 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @LNGOFF(10,2,0,0),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags924 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_1 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_2 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_3 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_6 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_8 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
g_atype924_1,
g_atype924_2,
g_atype924_3,
g_atype924_4,
g_atype924_5,
g_atype924_6,
g_atype924_7,
g_atype924_8,
};

static const long offsets924 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags925 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_1 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_2 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_3 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_6 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_8 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
g_atype925_1,
g_atype925_2,
g_atype925_3,
g_atype925_4,
g_atype925_5,
g_atype925_6,
g_atype925_7,
g_atype925_8,
};

static const long offsets925 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags926 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_1 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_2 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_3 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_6 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_7 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_8 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
g_atype926_1,
g_atype926_2,
g_atype926_3,
g_atype926_4,
g_atype926_5,
g_atype926_6,
g_atype926_7,
g_atype926_8,
};

static const long offsets926 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags927 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_1 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_2 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_3 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_7 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_9 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
g_atype927_1,
g_atype927_2,
g_atype927_3,
g_atype927_4,
g_atype927_5,
g_atype927_6,
g_atype927_7,
g_atype927_8,
g_atype927_9,
};

static const long offsets927 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags928 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_1 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_2 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_3 [] = {557,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_4 [] = {896,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_7 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_8 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_9 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
g_atype928_1,
g_atype928_2,
g_atype928_3,
g_atype928_4,
g_atype928_5,
g_atype928_6,
g_atype928_7,
g_atype928_8,
g_atype928_9,
};

static const long offsets928 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names2,
	types2,
	attr_flags2,
	gtypes2,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets2,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names3,
	types3,
	attr_flags3,
	gtypes3,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets3,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names4,
	types4,
	attr_flags4,
	gtypes4,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets4,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names7,
	types7,
	attr_flags7,
	gtypes7,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets7,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_EIFFEL_TEST_CATALOG",
	names8,
	types8,
	attr_flags8,
	gtypes8,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets8,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_EWEASEL_OUTPUT_CONTROL",
	names11,
	types11,
	attr_flags11,
	gtypes11,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets11,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names13,
	types13,
	attr_flags13,
	gtypes13,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets13,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_TEST_SUITE_OPTIONS",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_LANGUAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GROUP_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_UNIX_OS_ACCESS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names35,
	types35,
	attr_flags35,
	gtypes35,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets35,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names47,
	types47,
	attr_flags47,
	gtypes47,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets47,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names48,
	types48,
	attr_flags48,
	gtypes48,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets48,
	NULL
},
{
	(long) 3,
	(long) 3,
	"BI_LINKABLE",
	names49,
	types49,
	attr_flags49,
	gtypes49,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets49,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_STRING_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EW_FILTER_CREATION",
	names53,
	types53,
	attr_flags53,
	gtypes53,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets53,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EW_TEST_INSTRUCTION",
	names54,
	types54,
	attr_flags54,
	gtypes54,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets54,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_TEST_DESCRIPTION_INST",
	names55,
	types55,
	attr_flags55,
	gtypes55,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets55,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_TEST_NAME_INST",
	names56,
	types56,
	attr_flags56,
	gtypes56,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets56,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EW_UNKNOWN_INST",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_PREFERENCE_INST",
	names58,
	types58,
	attr_flags58,
	gtypes58,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets58,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EW_TEST_END_INST",
	names59,
	types59,
	attr_flags59,
	gtypes59,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets59,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_SYSTEM_INST",
	names60,
	types60,
	attr_flags60,
	gtypes60,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets60,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_COMPILE_RESULT_INST",
	names61,
	types61,
	attr_flags61,
	gtypes61,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets61,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_EXECUTE_RESULT_INST",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_CPU_LIMIT_INST",
	names63,
	types63,
	attr_flags63,
	gtypes63,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets63,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_C_COMPILE_RESULT_INST",
	names64,
	types64,
	attr_flags64,
	gtypes64,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets64,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_CONFIG_INST",
	names65,
	types65,
	attr_flags65,
	gtypes65,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets65,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_ACE_INST",
	names66,
	types66,
	attr_flags66,
	gtypes66,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets66,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_COMPILE_INST",
	names67,
	types67,
	attr_flags67,
	gtypes67,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets67,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"MEMORY_STRUCTURE",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALUE",
	names74,
	types74,
	attr_flags74,
	gtypes74,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets74,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DATE_TIME_VALUE",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_EIFFEL_COMPILER_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_UNIX_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_SIGNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names88,
	types88,
	attr_flags88,
	gtypes88,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets88,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names89,
	types89,
	attr_flags89,
	gtypes89,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets89,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names90,
	types90,
	attr_flags90,
	gtypes90,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets90,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names92,
	types92,
	attr_flags92,
	gtypes92,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets92,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names93,
	types93,
	attr_flags93,
	gtypes93,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets93,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names94,
	types94,
	attr_flags94,
	gtypes94,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets94,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEM_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_CODE_ANALYSIS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_CODE_ANALYSIS_RESULT_INST",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_PROCESS_RESULT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EW_EXECUTION_RESULT",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_C_COMPILATION_RESULT",
	names105,
	types105,
	attr_flags105,
	gtypes105,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets105,
	NULL
},
{
	(long) 15,
	(long) 15,
	"EW_EIFFEL_COMPILATION_RESULT",
	names106,
	types106,
	attr_flags106,
	gtypes106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets106,
	NULL
},
{
	(long) 23,
	(long) 23,
	"EW_CODE_ANALYSIS_RESULT",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names111,
	types111,
	attr_flags111,
	gtypes111,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets111,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TWO_WAY_LIST_CURSOR",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names118,
	types118,
	attr_flags118,
	gtypes118,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets118,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names119,
	types119,
	attr_flags119,
	gtypes119,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets119,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names120,
	types120,
	attr_flags120,
	gtypes120,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets120,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names121,
	types121,
	attr_flags121,
	gtypes121,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets121,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names131,
	types131,
	attr_flags131,
	gtypes131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets131,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_CATALOG_INSTRUCTION",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_SOURCE_PATH_INST",
	names159,
	types159,
	attr_flags159,
	gtypes159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets159,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_UNKNOWN_CAT_INST",
	names160,
	types160,
	attr_flags160,
	gtypes160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets160,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_EIFFEL_TEST_FILTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_FILTER_KEYWORD",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_FILTER_TEST_NAME",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_FILTER_TEST_DIRECTORY",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_FILTER_ALL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERVAL",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TIME_DURATION",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_DURATION",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DATE_DURATION",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EW_CODE_ANALYSIS_VIOLATION",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_EIFFEL_ERROR",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EW_EIFFEL_VALIDITY_ERROR",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_EIFFEL_SYNTAX_ERROR",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSOLUTE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_KEYWORD_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EW_IF_INST",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EW_CATALOG_IF_INST",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEMORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_OPERATING_SYSTEM",
	names210,
	types210,
	attr_flags210,
	gtypes210,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets210,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_UNIX_OS",
	names211,
	types211,
	attr_flags211,
	gtypes211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets211,
	NULL
},
{
	(long) 30,
	(long) 30,
	"EW_UNIX_PROCESS",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_SHARED_OBJECTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EW_ERROR_LIST",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EW_ERROR",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EW_EXECUTION_ERROR",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EW_PARSE_ERROR",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_EIFFEL_TEST_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 8,
	(long) 7,
	"TWO_WAY_LIST_ITERATION_CURSOR",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names307,
	types307,
	attr_flags307,
	gtypes307,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets307,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PART_SORTED_LIST",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SORTED_LIST",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 8,
	(long) 8,
	"TWO_WAY_LIST",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 8,
	(long) 8,
	"SORTED_TWO_WAY_LIST",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_SUBSTITUTION_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_DEFINE_DATE_INST",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_UNSETENV_INST",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EW_SETENV_INST",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_UNDEFINE_INST",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_DEFINE_INST",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EW_TEST_ENVIRONMENT",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALUE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DATE_TIME_CODE",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_PREDEFINED_VARIABLES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_OS_ACCESS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_INCLUDE_INST",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_RESUME_COMPILE_INST",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPARE_INST",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_CLEANUP_INST",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_EXIT_COMPILE_INST",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_ABORT_COMPILE_INST",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_DELETE_INST",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_TEST_INST",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_DEFINE_FILE_INST",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_DEFINE_DIR_INST",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EW_EIFFEL_TEST_SUITE",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EW_EIFFEL_TEST_SUITE_ST",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EW_EXECUTE_INST",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EW_EXECUTE_FINAL_INST",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EW_EXECUTE_WORK_INST",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_INST",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_BIN_INST",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_FILE_INST",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_TEXT_INST",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_SUB_INST",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_COPY_RAW_INST",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_C_COMPILE_INST",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_C_COMPILE_WORK_INST",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_C_COMPILE_FINAL_INST",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_START_COMPILE_INST",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 15,
	(long) 15,
	"EW_RUN_CODE_ANALYSIS_INST",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_PRECOMPILED_INST",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_FINAL_KEEP_INST",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_FINAL_INST",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_FROZEN_INST",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_QUICK_MELTED_INST",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_COMPILE_MELTED_INST",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_PRETTIFY_INST",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 6,
	(long) 6,
	"SEQ_STRING",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FIND_SEPARATOR_FACILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATE_TIME_CODE_STRING",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EW_INSTRUCTION_TABLES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 21,
	(long) 21,
	"EW_EIFFEL_EWEASEL_TEST",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EW_NAMED_EIFFEL_TEST",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_EWEASEL",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 11,
	(long) 11,
	"EW_EWEASEL_ST",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GC_INFO",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MEM_INFO",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EW_UNIX_PIPE",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 15,
	(long) 15,
	"EW_TEST_CONTROL_FILE",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALIDITY_CHECKER",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALIDITY_CHECKER",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_VALIDITY_CHECKER",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 16,
	(long) 16,
	"DATE_TIME_PARSER",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DATE_TIME",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 13,
	(long) 13,
	"EW_TEST_CATALOG_FILE",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_EWEASEL_PROCESS",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_SYSTEM_EXECUTION",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EW_C_COMPILATION",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_EIFFEL_COMPILATION",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EW_CODE_ANALYSIS_PROCESS",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets928,
	NULL
},};


#ifdef __cplusplus
}
#endif
