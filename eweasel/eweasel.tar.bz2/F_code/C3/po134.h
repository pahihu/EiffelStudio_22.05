
#ifndef _C3_po134_
#define _C3_po134_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F156_1614(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
