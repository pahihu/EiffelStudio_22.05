
#ifndef _C3_lo130_
#define _C3_lo130_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F152_1604(EIF_REFERENCE);
extern void EIF_Minit130(void);

#ifdef __cplusplus
}
#endif

#endif
