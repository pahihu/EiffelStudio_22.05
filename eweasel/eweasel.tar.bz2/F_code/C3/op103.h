
#ifndef _C3_op103_
#define _C3_op103_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F125_1533(EIF_REFERENCE);
extern void F125_1536(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit103(void);

#ifdef __cplusplus
}
#endif

#endif
