
#ifndef _C3_ew143_
#define _C3_ew143_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F165_1633(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit143(void);

#ifdef __cplusplus
}
#endif

#endif
