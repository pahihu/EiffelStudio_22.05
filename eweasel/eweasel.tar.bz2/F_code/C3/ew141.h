
#ifndef _C3_ew141_
#define _C3_ew141_

#ifdef __cplusplus
extern "C" {
#endif

extern void F163_1627(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F163_1628(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit141(void);
extern EIF_BOOLEAN F890_5578(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
