
#ifndef _C3_se120_
#define _C3_se120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F142_1586(EIF_REFERENCE);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
