
#ifndef _C3_in133_
#define _C3_in133_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F155_1610(EIF_REFERENCE);
extern void F155_1611(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit133(void);

#ifdef __cplusplus
}
#endif

#endif
