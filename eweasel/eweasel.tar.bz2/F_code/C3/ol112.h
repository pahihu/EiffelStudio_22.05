
#ifndef _C3_ol112_
#define _C3_ol112_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F134_1570(EIF_REFERENCE);
extern void EIF_Minit112(void);

#ifdef __cplusplus
}
#endif

#endif
