
#ifndef _C3_op105_
#define _C3_op105_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F127_1556(EIF_REFERENCE);
extern void F127_1559(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit105(void);

#ifdef __cplusplus
}
#endif

#endif
