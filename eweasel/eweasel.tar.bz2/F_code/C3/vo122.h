
#ifndef _C3_vo122_
#define _C3_vo122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F144_1588(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
