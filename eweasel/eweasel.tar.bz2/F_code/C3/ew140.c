/*
 * Code for class EW_FILTER_KEYWORD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew140.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_FILTER_KEYWORD}.make */
void F162_1624 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 161, Current, 0, 1, 1679);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_FILTER_KEYWORD}.selects */
EIF_BOOLEAN F162_1625 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	
	
	RTEAA("selects", 161, Current, 0, 1, 1680);
	RTHOOK(1);
	tb1 = F908_6231(RTCW(arg1), *(EIF_REFERENCE *)(Current));
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
