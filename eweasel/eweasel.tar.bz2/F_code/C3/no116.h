
#ifndef _C3_no116_
#define _C3_no116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F138_1574(EIF_REFERENCE);
extern void F138_1576(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
