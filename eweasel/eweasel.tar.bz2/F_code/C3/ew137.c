/*
 * Code for class EW_SOURCE_PATH_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew137.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_SOURCE_PATH_INST}.execute */
void F159_1621 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("execute", 158, Current, 4, 1, 1677);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F897_5863(RTCW(loc1), tr1);
	RTHOOK(2);
	F892_5656(RTCW(loc1));
	RTHOOK(3);
	loc3 = F52_709(Current, loc1);
	RTHOOK(4);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2561[Dtype(RTCW(loc3))-557])(loc3);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2833[Dtype(RTCW(loc3))-646])(loc3);
		loc2 = F657_3578(RTCW(tr1), tr2);
		RTHOOK(6);
		loc4 = RTLNS(eif_new_type(557, 0x00).id, 557, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F557_2954(RTCW(loc4), loc2);
		RTHOOK(7);
		tb1 = F557_2989(RTCW(loc4));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(8);
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000o\000\000\000u\000\000\000n\000\000\000d\000\000\000",19,1389757796);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			RTHOOK(9);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTHOOK(10);
			tb1 = F557_2998(RTCW(loc4));
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(11);
				tr1 = RTMS32_EX_H("n\000\000\000o\000\000\000t\000\000\000 \000\000\000a\000\000\000 \000\000\000d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000",15,1700642937);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				RTHOOK(12);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(13);
				F923_6561(RTCW(arg1), loc2);
				RTHOOK(14);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		RTHOOK(15);
		tr1 = RTMS32_EX_H("m\000\000\000u\000\000\000s\000\000\000t\000\000\000 \000\000\000b\000\000\000e\000\000\000 \000\000\000e\000\000\000x\000\000\000a\000\000\000c\000\000\000t\000\000\000l\000\000\000y\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",28,1257768820);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(16);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

void EIF_Minit137 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
