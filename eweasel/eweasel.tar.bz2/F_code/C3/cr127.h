
#ifndef _C3_cr127_
#define _C3_cr127_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F149_1600(EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
