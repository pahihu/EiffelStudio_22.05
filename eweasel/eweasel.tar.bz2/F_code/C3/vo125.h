
#ifndef _C3_vo125_
#define _C3_vo125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F147_1598(EIF_REFERENCE);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
