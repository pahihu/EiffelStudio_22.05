
#ifndef _C3_ro124_
#define _C3_ro124_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F146_1594(EIF_REFERENCE);
extern void F146_1596(EIF_REFERENCE, EIF_REFERENCE);
extern void F146_1597(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit124(void);

#ifdef __cplusplus
}
#endif

#endif
