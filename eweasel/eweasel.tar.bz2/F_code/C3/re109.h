
#ifndef _C3_re109_
#define _C3_re109_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F131_1564(EIF_REFERENCE);
extern void EIF_Minit109(void);

#ifdef __cplusplus
}
#endif

#endif
