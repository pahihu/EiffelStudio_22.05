
#ifndef _C3_ew140_
#define _C3_ew140_

#ifdef __cplusplus
extern "C" {
#endif

extern void F162_1624(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F162_1625(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit140(void);
extern EIF_BOOLEAN F908_6231(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
