
#ifndef _C3_ew138_
#define _C3_ew138_

#ifdef __cplusplus
extern "C" {
#endif

extern void F160_1622(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit138(void);
extern EIF_REFERENCE F899_5995(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F890_5592(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
