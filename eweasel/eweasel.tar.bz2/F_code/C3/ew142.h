
#ifndef _C3_ew142_
#define _C3_ew142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F164_1630(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F164_1631(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit142(void);
extern EIF_BOOLEAN F890_5578(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
