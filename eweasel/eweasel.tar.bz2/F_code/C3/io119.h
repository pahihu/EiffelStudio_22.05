
#ifndef _C3_io119_
#define _C3_io119_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F141_1580(EIF_REFERENCE);
extern void F141_1583(EIF_REFERENCE, EIF_INTEGER_32);
extern void F141_1584(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit119(void);

#ifdef __cplusplus
}
#endif

#endif
