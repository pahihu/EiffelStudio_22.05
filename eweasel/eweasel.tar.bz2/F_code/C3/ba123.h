
#ifndef _C3_ba123_
#define _C3_ba123_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F145_1590(EIF_REFERENCE);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
