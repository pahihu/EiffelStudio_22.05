
#ifndef _C3_mi118_
#define _C3_mi118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F140_1578(EIF_REFERENCE);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
