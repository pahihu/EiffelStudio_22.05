
#ifndef _C3_ad128_
#define _C3_ad128_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F150_1602(EIF_REFERENCE);
extern void EIF_Minit128(void);

#ifdef __cplusplus
}
#endif

#endif
