/*
 * Code for class EW_UNKNOWN_CAT_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew138.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_UNKNOWN_CAT_INST}.execute */
void F160_1622 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("execute", 159, Current, 0, 1, 1678);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000k\000\000\000n\000\000\000o\000\000\000w\000\000\000n\000\000\000 \000\000\000t\000\000\000e\000\000\000s\000\000\000t\000\000\000 \000\000\000c\000\000\000a\000\000\000t\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000\"\000\000\000",34,43590946);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	tr1 = F899_5995(tr1, tr2);
	tr2 = F890_5592(RTMS_EX_H("\"",1,34));
	tr1 = F899_5995(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
