
#ifndef _C3_pa144_
#define _C3_pa144_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F166_1635(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit144(void);
extern char *(*R1464[])();

#ifdef __cplusplus
}
#endif

#endif
