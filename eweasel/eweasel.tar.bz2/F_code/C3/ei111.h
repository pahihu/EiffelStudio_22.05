
#ifndef _C3_ei111_
#define _C3_ei111_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F133_1566(EIF_REFERENCE);
extern void F133_1568(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit111(void);

#ifdef __cplusplus
}
#endif

#endif
