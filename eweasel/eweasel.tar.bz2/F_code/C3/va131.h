
#ifndef _C3_va131_
#define _C3_va131_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F153_1606(EIF_REFERENCE);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
