
#ifndef _C3_ex115_
#define _C3_ex115_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F137_1572(EIF_REFERENCE);
extern void EIF_Minit115(void);

#ifdef __cplusplus
}
#endif

#endif
