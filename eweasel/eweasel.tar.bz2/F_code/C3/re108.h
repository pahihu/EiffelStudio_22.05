
#ifndef _C3_re108_
#define _C3_re108_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F130_1562(EIF_REFERENCE);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
