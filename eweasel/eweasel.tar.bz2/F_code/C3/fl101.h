
#ifndef _C3_fl101_
#define _C3_fl101_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F123_1531(EIF_REFERENCE);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
