
#ifndef _C3_ew137_
#define _C3_ew137_

#ifdef __cplusplus
extern "C" {
#endif

extern void F159_1621(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit137(void);
extern void F897_5863(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F657_3578(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F557_2998(EIF_REFERENCE);
extern EIF_REFERENCE F52_709(EIF_REFERENCE, EIF_REFERENCE);
extern void F892_5656(EIF_REFERENCE);
extern void F557_2954(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F557_2989(EIF_REFERENCE);
extern void F923_6561(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2561[])();
extern char *(*R2833[])();

#ifdef __cplusplus
}
#endif

#endif
