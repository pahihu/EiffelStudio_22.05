
#ifndef _C3_ch132_
#define _C3_ch132_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F154_1608(EIF_REFERENCE);
extern void EIF_Minit132(void);

#ifdef __cplusplus
}
#endif

#endif
