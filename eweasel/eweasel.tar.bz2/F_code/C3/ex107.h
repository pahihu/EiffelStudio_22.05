
#ifndef _C3_ex107_
#define _C3_ex107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F129_1560(EIF_REFERENCE);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
