/*
 * Code for class PART_COMPARABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa144.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PART_COMPARABLE}.is_less_equal */
EIF_BOOLEAN F166_1635 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_less_equal", 165, Current, 0, 1, 1689);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tr1 = RTCCL(arg1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1464[Dtype(Current)-170])(Current, tr1);
	if (!tb1) {
		Result = RTEQ(Current, arg1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit144 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
