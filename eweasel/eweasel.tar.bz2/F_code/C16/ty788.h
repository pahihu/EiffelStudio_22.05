
#ifndef _C16_ty788_
#define _C16_ty788_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F279_2731(EIF_REFERENCE);
extern void EIF_Minit788(void);
extern char *(*R2467[])();
extern char *(*R2454[])();
extern char *(*R2771[])();

#ifdef __cplusplus
}
#endif

#endif
