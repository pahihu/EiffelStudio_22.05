
#ifndef _C16_fi760_
#define _C16_fi760_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F503_2928(EIF_REFERENCE);
extern void EIF_Minit760(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
