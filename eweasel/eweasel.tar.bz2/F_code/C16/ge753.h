
#ifndef _C16_ge753_
#define _C16_ge753_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F310_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F310_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F310_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F310_2789(EIF_REFERENCE);
extern void F310_2792(EIF_REFERENCE);
extern void EIF_Minit753(void);

#ifdef __cplusplus
}
#endif

#endif
