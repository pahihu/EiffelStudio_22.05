
#ifndef _C16_re787_
#define _C16_re787_

#ifdef __cplusplus
extern "C" {
#endif

extern void F291_2737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F291_2739(EIF_REFERENCE);
extern EIF_INTEGER_32 F291_2740(EIF_REFERENCE);
extern EIF_INTEGER_32 F291_2741(EIF_REFERENCE);
extern EIF_INTEGER_32 F291_2742(EIF_REFERENCE);
extern EIF_BOOLEAN F291_2749(EIF_REFERENCE);
extern EIF_BOOLEAN F291_2750(EIF_REFERENCE);
extern EIF_BOOLEAN F291_2751(EIF_REFERENCE);
extern EIF_BOOLEAN F291_2752(EIF_REFERENCE);
extern void F291_2754(EIF_REFERENCE);
extern void F291_2756(EIF_REFERENCE);
extern void F291_2757(EIF_REFERENCE);
extern void EIF_Minit787(void);
extern char *(*R2775[])();
extern char *(*R2772[])();
extern char *(*R2773[])();

#ifdef __cplusplus
}
#endif

#endif
