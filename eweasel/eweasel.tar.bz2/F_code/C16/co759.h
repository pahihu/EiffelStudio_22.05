
#ifndef _C16_co759_
#define _C16_co759_

#ifdef __cplusplus
extern "C" {
#endif

extern void F360_2830(EIF_REFERENCE);
extern void EIF_Minit759(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
