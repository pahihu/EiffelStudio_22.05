/*
 * Code for class BILINEAR [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi773.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F396_2857 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 395, Current, 0, 0, 3855);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F629_3443(Current)) {
		Result = F629_3442(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F396_2860 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 395, Current, 0, 1, 3856);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F629_3443(Current)) {
		tb1 = (EIF_BOOLEAN) !F503_2928(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F668_3652(Current);
	}
	RTHOOK(3);
	F384_2843(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit773 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
