
#ifndef _C16_to767_
#define _C16_to767_

#ifdef __cplusplus
extern "C" {
#endif

extern void F200_2350(EIF_REFERENCE, EIF_INTEGER_32);
extern void F200_2351(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F200_2357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit767(void);
extern void F693_3933(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2108[];
extern EIF_TYPE_INDEX *Y2108_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
