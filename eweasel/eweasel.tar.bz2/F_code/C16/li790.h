
#ifndef _C16_li790_
#define _C16_li790_

#ifdef __cplusplus
extern "C" {
#endif

extern void F385_2843(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F385_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F385_2849(EIF_REFERENCE);
extern void EIF_Minit790(void);
extern EIF_BOOLEAN F630_3442(EIF_REFERENCE);
extern EIF_BOOLEAN F504_2928(EIF_REFERENCE);
extern EIF_POINTER F669_3624(EIF_REFERENCE);
extern void F669_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F606_3418(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
