
#ifndef _C16_co792_
#define _C16_co792_

#ifdef __cplusplus
extern "C" {
#endif

extern void F361_2830(EIF_REFERENCE);
extern void EIF_Minit792(void);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
