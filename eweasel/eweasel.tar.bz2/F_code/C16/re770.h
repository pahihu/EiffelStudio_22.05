
#ifndef _C16_re770_
#define _C16_re770_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F529_2941(EIF_REFERENCE);
extern void F529_2943(EIF_REFERENCE);
extern void EIF_Minit770(void);
extern char *(*R2564[])();
extern char *(*R2570[])();

#ifdef __cplusplus
}
#endif

#endif
