
#ifndef _C16_ar769_
#define _C16_ar769_

#ifdef __cplusplus
extern "C" {
#endif

extern void F322_2797(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2798(EIF_REFERENCE);
extern EIF_REFERENCE F322_2801(EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2802(EIF_REFERENCE);
extern void EIF_Minit769(void);
extern EIF_INTEGER_32 F668_3642(EIF_REFERENCE);
extern EIF_REFERENCE F668_3623(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
