
#ifndef _C16_bi773_
#define _C16_bi773_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F396_2857(EIF_REFERENCE);
extern void F396_2860(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit773(void);
extern EIF_BOOLEAN F503_2928(EIF_REFERENCE);
extern void F384_2843(EIF_REFERENCE, EIF_BOOLEAN);
extern void F668_3652(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3443(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3442(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
