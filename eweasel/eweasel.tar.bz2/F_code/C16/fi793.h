
#ifndef _C16_fi793_
#define _C16_fi793_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F504_2928(EIF_REFERENCE);
extern void EIF_Minit793(void);
extern char *(*R2561[])();

#ifdef __cplusplus
}
#endif

#endif
