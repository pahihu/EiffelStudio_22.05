
#ifndef _C16_li757_
#define _C16_li757_

#ifdef __cplusplus
extern "C" {
#endif

extern void F384_2843(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F384_2847(EIF_REFERENCE);
extern EIF_BOOLEAN F384_2849(EIF_REFERENCE);
extern void EIF_Minit757(void);
extern EIF_BOOLEAN F605_3418(EIF_REFERENCE);
extern EIF_BOOLEAN F668_3624(EIF_REFERENCE);
extern EIF_BOOLEAN F503_2928(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3442(EIF_REFERENCE);
extern void F668_3652(EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
