
#ifndef _C1_st16_
#define _C1_st16_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F28_390_body(EIF_REFERENCE);
extern EIF_REFERENCE F28_390(EIF_REFERENCE);
static EIF_REFERENCE F28_391_body(EIF_REFERENCE);
extern EIF_REFERENCE F28_391(EIF_REFERENCE);
extern EIF_REFERENCE F28_393(EIF_REFERENCE);
extern void F28_417(EIF_REFERENCE);
extern void F28_418(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F28_420(EIF_REFERENCE, EIF_REFERENCE);
extern void F28_443(EIF_REFERENCE);
extern void EIF_Minit16(void);
extern void F917_6132(EIF_REFERENCE, EIF_REFERENCE);
extern void F917_6131(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2285[])();
extern char *(*R2287[])();
extern char *(*R2289[])();

#ifdef __cplusplus
}
#endif

#endif
