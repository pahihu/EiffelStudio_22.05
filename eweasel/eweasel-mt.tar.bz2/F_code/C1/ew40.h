
#ifndef _C1_ew40_
#define _C1_ew40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F60_762(EIF_REFERENCE, EIF_REFERENCE);
extern void F60_763(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F60_764(EIF_REFERENCE);
extern EIF_BOOLEAN F60_765(EIF_REFERENCE);
extern void EIF_Minit40(void);
extern EIF_REFERENCE F906_5673(EIF_REFERENCE);
extern EIF_REFERENCE F915_6076(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
