
#ifndef _C1_ew46_
#define _C1_ew46_

#ifdef __cplusplus
extern "C" {
#endif

extern void F66_791(EIF_REFERENCE, EIF_REFERENCE);
extern void F66_792(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F66_793(EIF_REFERENCE);
extern EIF_BOOLEAN F66_794(EIF_REFERENCE);
extern void EIF_Minit46(void);
extern void F925_6323(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F54_715(EIF_REFERENCE, EIF_REFERENCE);
extern void F925_6322(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2598[])();
extern char *(*R2571[])();

#ifdef __cplusplus
}
#endif

#endif
