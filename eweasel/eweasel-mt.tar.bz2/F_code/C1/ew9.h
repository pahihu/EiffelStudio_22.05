
#ifndef _C1_ew9_
#define _C1_ew9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_110(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_114(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_115(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
