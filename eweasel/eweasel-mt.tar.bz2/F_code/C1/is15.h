
#ifndef _C1_is15_
#define _C1_is15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F15_285(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F15_287(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F15_295(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
