
#ifndef _C1_ew39_
#define _C1_ew39_

#ifdef __cplusplus
extern "C" {
#endif

extern void F59_757(EIF_REFERENCE, EIF_REFERENCE);
extern void F59_758(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F59_759(EIF_REFERENCE);
extern EIF_BOOLEAN F59_760(EIF_REFERENCE);
extern void EIF_Minit39(void);
extern void F925_6319(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
