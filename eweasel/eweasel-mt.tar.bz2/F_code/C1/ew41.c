/*
 * Code for class EW_TEST_END_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew41.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_END_INST}.inst_initialize */
void F61_766 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 60, Current, 0, 1, 845);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4295[Dtype(RTCW(arg1))-909])(arg1);
	if (tb1) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(4);
		tr1 = RTMS32_EX_H("n\000\000\000o\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000s\000\000\000 \000\000\000a\000\000\000l\000\000\000l\000\000\000o\000\000\000w\000\000\000e\000\000\000d\000\000\000",20,132335972);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_TEST_END_INST}.execute */
void F61_767 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("execute", 60, Current, 2, 1, 846);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		F945_6724(RTCW(loc1));
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(6);
		F942_6697(RTCW(loc2));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_TEST_END_INST}.init_ok */
EIF_BOOLEAN F61_768 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_);
}


/* {EW_TEST_END_INST}.execute_ok */
EIF_BOOLEAN F61_769 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EW_TEST_END_INST}.test_execution_terminated */
EIF_BOOLEAN F61_770 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
