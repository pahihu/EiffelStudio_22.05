
#ifndef _C1_ew44_
#define _C1_ew44_

#ifdef __cplusplus
extern "C" {
#endif

extern void F64_781(EIF_REFERENCE, EIF_REFERENCE);
extern void F64_782(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F64_783(EIF_REFERENCE);
extern EIF_BOOLEAN F64_784(EIF_REFERENCE);
extern void EIF_Minit44(void);
extern EIF_INTEGER_32 F54_711(EIF_REFERENCE, EIF_REFERENCE);
extern void F925_6322(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
