
#ifndef _C1_da19_
#define _C1_da19_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F31_497_body(EIF_REFERENCE);
extern EIF_REFERENCE F31_497(EIF_REFERENCE);
static EIF_REFERENCE F31_498_body(EIF_REFERENCE);
extern EIF_REFERENCE F31_498(EIF_REFERENCE);
extern void EIF_Minit19(void);
extern void F356_2867(EIF_REFERENCE);
extern EIF_REFERENCE F699_4014(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
