
#ifndef _C1_ew37_
#define _C1_ew37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F57_746(EIF_REFERENCE, EIF_REFERENCE);
extern void F57_747(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F57_748(EIF_REFERENCE);
extern EIF_BOOLEAN F57_749(EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F925_6324(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F54_717(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2598[])();
extern char *(*R2571[])();

#ifdef __cplusplus
}
#endif

#endif
