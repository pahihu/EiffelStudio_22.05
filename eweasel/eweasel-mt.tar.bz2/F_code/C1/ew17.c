/*
 * Code for class EW_TEST_SUITE_OPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew17.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_SUITE_OPTIONS}.make */
void F29_469 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 28, Current, 0, 0, 481);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(169, 0x00).id, 169, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_keep_all */
void F29_479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_keep_all", 28, Current, 0, 0, 491);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_keep_passed */
void F29_480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_keep_passed", 28, Current, 0, 0, 492);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_keep_failed */
void F29_481 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_keep_failed", 28, Current, 0, 0, 493);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_cleanup_requested */
void F29_482 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_cleanup_requested", 28, Current, 0, 1, 494);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_3_) = (EIF_BOOLEAN) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_filter */
void F29_483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_filter", 28, Current, 0, 1, 495);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_max_threads */
void F29_484 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_max_threads", 28, Current, 0, 1, 496);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_max_c_processes */
void F29_485 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_max_c_processes", 28, Current, 0, 1, 497);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_results_in_catalog_order */
void F29_486 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_results_in_catalog_order", 28, Current, 0, 1, 498);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_4_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EW_TEST_SUITE_OPTIONS}.set_display_summary */
void F29_487 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_display_summary", 28, Current, 0, 1, 499);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_5_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit17 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
