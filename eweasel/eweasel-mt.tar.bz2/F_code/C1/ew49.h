
#ifndef _C1_ew49_
#define _C1_ew49_

#ifdef __cplusplus
extern "C" {
#endif

extern void F69_818(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F69_820(EIF_REFERENCE);
extern EIF_BOOLEAN F69_821(EIF_REFERENCE);
extern void EIF_Minit49(void);
extern EIF_REFERENCE F54_715(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2598[])();
extern char *(*R2870[])();
extern long O766[];
extern long O767[];

#ifdef __cplusplus
}
#endif

#endif
