
#ifndef _C1_ew45_
#define _C1_ew45_

#ifdef __cplusplus
extern "C" {
#endif

extern void F65_786(EIF_REFERENCE, EIF_REFERENCE);
extern void F65_787(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F65_788(EIF_REFERENCE);
extern EIF_BOOLEAN F65_789(EIF_REFERENCE);
extern void EIF_Minit45(void);
extern void F925_6321(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F54_711(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
