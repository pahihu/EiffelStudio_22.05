/*
 * Code for class EW_COMPILE_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew49.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_COMPILE_INST}.inst_initialize */
void F69_818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("inst_initialize", 68, Current, 1, 1, 897);
	RTGC;
	RTHOOK(1);
	loc1 = F54_715(Current, arg1);
	RTHOOK(2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(loc1))-563])(loc1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current + O767[dtype-68]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(4);
		tr1 = RTMS32_EX_H("m\000\000\000u\000\000\000s\000\000\000t\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000l\000\000\000y\000\000\000 \000\000\0000\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\0001\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",27,1435733876);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(loc1))-563])(loc1);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(6);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2870[Dtype(RTCW(loc1))-652])(loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
			RTHOOK(7);
			*(EIF_BOOLEAN *)(Current + O767[dtype-68]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(8);
			*(EIF_BOOLEAN *)(Current + O767[dtype-68]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EW_COMPILE_INST}.init_ok */
EIF_BOOLEAN F69_820 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O767[Dtype(Current)-68]);
}


/* {EW_COMPILE_INST}.execute_ok */
EIF_BOOLEAN F69_821 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O766[Dtype(Current)-68]);
}


void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
