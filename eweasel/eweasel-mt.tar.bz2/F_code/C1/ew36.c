/*
 * Code for class EW_TEST_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_INSTRUCTION}.initialize */
void F56_728 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("initialize", 55, Current, 2, 1, 813);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F913_5944(RTCW(loc1), loc2);
		RTHOOK(4);
		F908_5737(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(6);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(7);
	F56_745(Current, arg1);
	RTHOOK(8);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R712[Dtype(Current)-56])(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EW_TEST_INSTRUCTION}.initialize_for_conditional */
void F56_729 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc1);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("initialize_for_conditional", 55, Current, 1, 3, 814);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5944(RTCW(loc1), arg3);
	RTHOOK(3);
	F908_5737(RTCW(loc1));
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	F56_745(Current, arg1);
	RTHOOK(6);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R712[Dtype(Current)-56])(Current, loc1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_TEST_INSTRUCTION}.test_execution_terminated */
EIF_BOOLEAN F56_734 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("test_execution_terminated", 55, Current, 0, 0, 815);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EW_TEST_INSTRUCTION}.command_table */
EIF_REFERENCE F56_737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("command_table", 55, Current, 0, 0, 818);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_TEST_INSTRUCTION}.init_environment */
EIF_REFERENCE F56_738 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("init_environment", 55, Current, 0, 0, 819);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_TEST_INSTRUCTION}.executable_file_error */
EIF_REFERENCE F56_744 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("executable_file_error", 55, Current, 1, 1, 811);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(563, 0x00).id, 563, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F563_2991(RTCW(loc1), arg1);
		RTHOOK(3);
		tb1 = F563_3026(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			tr1 = RTMS32_EX_H("f\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000",5,1769494816);
			tr1 = F915_6076(tr1, arg1);
			tr2 = RTMS32_EX_H(" \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000o\000\000\000u\000\000\000n\000\000\000d\000\000\000",10,261004900);
			Result = F915_6076(RTCW(tr1), tr2);
		} else {
			RTHOOK(5);
			tb1 = F563_3033(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(6);
				tr1 = RTMS32_EX_H("f\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000",5,1769494816);
				tr1 = F915_6076(tr1, arg1);
				tr2 = RTMS32_EX_H(" \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000a\000\000\000 \000\000\000p\000\000\000l\000\000\000a\000\000\000i\000\000\000n\000\000\000 \000\000\000f\000\000\000i\000\000\000l\000\000\000e\000\000\000",17,1637487717);
				Result = F915_6076(RTCW(tr1), tr2);
			} else {
				RTHOOK(7);
				tb1 = F563_3031(RTCW(loc1));
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(8);
					tr1 = RTMS32_EX_H("f\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000",5,1769494816);
					tr1 = F915_6076(tr1, arg1);
					tr2 = RTMS32_EX_H(" \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000e\000\000\000x\000\000\000e\000\000\000c\000\000\000u\000\000\000t\000\000\000a\000\000\000b\000\000\000l\000\000\000e\000\000\000",15,2067964005);
					Result = F915_6076(RTCW(tr1), tr2);
				}
			}
		}
	} else {
		RTHOOK(9);
		Result = RTMS32_EX_H("f\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000s\000\000\000p\000\000\000e\000\000\000c\000\000\000i\000\000\000f\000\000\000i\000\000\000e\000\000\000d\000\000\000",18,777784420);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_TEST_INSTRUCTION}.set_arguments */
void F56_745 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_arguments", 55, Current, 0, 1, 812);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = F56_738(Current);
	tr1 = F670_3651(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F908_5737(RTCW(tr1));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_4_0_0_);
	*(EIF_INTEGER_32 *)(Current + O725[Dtype(Current)-55]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
