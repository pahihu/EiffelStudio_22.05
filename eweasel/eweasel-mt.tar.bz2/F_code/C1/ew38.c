/*
 * Code for class EW_TEST_DESCRIPTION_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew38.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_DESCRIPTION_INST}.inst_initialize */
void F58_752 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 57, Current, 0, 1, 831);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4295[Dtype(RTCW(arg1))-909])(arg1);
	if (tb1) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		tr1 = RTMS32_EX_H("n\000\000\000o\000\000\000 \000\000\000t\000\000\000e\000\000\000s\000\000\000t\000\000\000 \000\000\000d\000\000\000e\000\000\000s\000\000\000c\000\000\000r\000\000\000i\000\000\000p\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000l\000\000\000i\000\000\000e\000\000\000d\000\000\000",28,1435748196);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_TEST_DESCRIPTION_INST}.execute */
void F58_753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 57, Current, 0, 1, 832);
	RTHOOK(1);
	F925_6320(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	RTEE;
}

/* {EW_TEST_DESCRIPTION_INST}.init_ok */
EIF_BOOLEAN F58_754 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_);
}


/* {EW_TEST_DESCRIPTION_INST}.execute_ok */
EIF_BOOLEAN F58_755 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit38 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
