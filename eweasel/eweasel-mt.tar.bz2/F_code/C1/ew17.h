
#ifndef _C1_ew17_
#define _C1_ew17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_469(EIF_REFERENCE);
extern void F29_479(EIF_REFERENCE);
extern void F29_480(EIF_REFERENCE);
extern void F29_481(EIF_REFERENCE);
extern void F29_482(EIF_REFERENCE, EIF_BOOLEAN);
extern void F29_483(EIF_REFERENCE, EIF_REFERENCE);
extern void F29_484(EIF_REFERENCE, EIF_INTEGER_32);
extern void F29_485(EIF_REFERENCE, EIF_INTEGER_32);
extern void F29_486(EIF_REFERENCE, EIF_BOOLEAN);
extern void F29_487(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
