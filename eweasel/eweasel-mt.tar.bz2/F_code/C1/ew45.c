/*
 * Code for class EW_SYSTEM_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew45.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_SYSTEM_INST}.inst_initialize */
void F65_786 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 64, Current, 0, 1, 865);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4295[Dtype(RTCW(arg1))-909])(arg1);
	if (!tb2) {
		tb1 = (EIF_BOOLEAN) (F54_711(Current, arg1) > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		tr1 = RTMS32_EX_H("z\000\000\000e\000\000\000r\000\000\000o\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000m\000\000\000o\000\000\000r\000\000\000e\000\000\000 \000\000\000t\000\000\000h\000\000\000a\000\000\000n\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000s\000\000\000y\000\000\000s\000\000\000t\000\000\000e\000\000\000m\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000l\000\000\000i\000\000\000e\000\000\000d\000\000\000",42,908027748);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(5);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_SYSTEM_INST}.execute */
void F65_787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 64, Current, 0, 1, 866);
	RTHOOK(1);
	F925_6321(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	RTEE;
}

/* {EW_SYSTEM_INST}.init_ok */
EIF_BOOLEAN F65_788 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_);
}


/* {EW_SYSTEM_INST}.execute_ok */
EIF_BOOLEAN F65_789 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
