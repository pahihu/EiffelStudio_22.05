
#ifndef _C1_do28_
#define _C1_do28_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F40_566(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
