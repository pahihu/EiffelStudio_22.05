/*
 * Code for class EW_UNKNOWN_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_UNKNOWN_INST}.inst_initialize */
void F60_762 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("inst_initialize", 59, Current, 0, 1, 841);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000k\000\000\000n\000\000\000o\000\000\000w\000\000\000n\000\000\000 \000\000\000t\000\000\000e\000\000\000s\000\000\000t\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000\"\000\000\000",26,1866083874);
	tr1 = F915_6076(tr1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr2 = F906_5673(RTMS_EX_H("\"",1,34));
	tr1 = F915_6076(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_UNKNOWN_INST}.execute */
void F60_763 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("execute", 59, Current, 0, 1, 842);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000k\000\000\000n\000\000\000o\000\000\000w\000\000\000n\000\000\000 \000\000\000t\000\000\000e\000\000\000s\000\000\000t\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000\"\000\000\000",26,1866083874);
	tr1 = F915_6076(tr1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr2 = F906_5673(RTMS_EX_H("\"",1,34));
	tr1 = F915_6076(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_UNKNOWN_INST}.init_ok */
EIF_BOOLEAN F60_764 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EW_UNKNOWN_INST}.execute_ok */
EIF_BOOLEAN F60_765 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
