
#ifndef _C1_ew35_
#define _C1_ew35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F55_724(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit35(void);
extern void F168_1660(EIF_REFERENCE, EIF_REFERENCE);
extern void F169_1663(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F913_5969(EIF_REFERENCE, EIF_REFERENCE);
extern void F167_1657(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F54_715(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2598[])();
extern char *(*R4339[])();
extern char *(*R2870[])();
extern char *(*R2571[])();

#ifdef __cplusplus
}
#endif

#endif
