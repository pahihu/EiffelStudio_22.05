
#ifndef _C1_ew42_
#define _C1_ew42_

#ifdef __cplusplus
extern "C" {
#endif

extern void F62_771(EIF_REFERENCE, EIF_REFERENCE);
extern void F62_772(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F62_773(EIF_REFERENCE);
extern EIF_BOOLEAN F62_774(EIF_REFERENCE);
extern void EIF_Minit42(void);
extern EIF_INTEGER_32 F906_5679(EIF_REFERENCE);
extern void F925_6325(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F54_711(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F906_5645(EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
