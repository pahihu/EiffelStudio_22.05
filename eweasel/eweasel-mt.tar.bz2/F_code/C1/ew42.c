/*
 * Code for class EW_CPU_LIMIT_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew42.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_CPU_LIMIT_INST}.inst_initialize */
void F62_771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 61, Current, 0, 1, 851);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4295[Dtype(RTCW(arg1))-909])(arg1);
	if (!tb3) {
		tb2 = (EIF_BOOLEAN) (F54_711(Current, arg1) > ((EIF_INTEGER_32) 0L));
	}
	if (!tb2) {
		tb2 = F906_5645(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		tr1 = RTMS32_EX_H("n\000\000\000e\000\000\000e\000\000\000d\000\000\000 \000\000\000e\000\000\000x\000\000\000a\000\000\000c\000\000\000t\000\000\000l\000\000\000y\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000i\000\000\000n\000\000\000t\000\000\000e\000\000\000g\000\000\000e\000\000\000r\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",33,95559796);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		ti4_1 = F906_5679(RTCW(arg1));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_CPU_LIMIT_INST}.execute */
void F62_772 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 61, Current, 0, 1, 852);
	RTHOOK(1);
	F925_6325(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_));
	RTHOOK(2);
	RTEE;
}

/* {EW_CPU_LIMIT_INST}.init_ok */
EIF_BOOLEAN F62_773 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_);
}


/* {EW_CPU_LIMIT_INST}.execute_ok */
EIF_BOOLEAN F62_774 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
