/*
 * Code for class EW_EWEASEL_OUTPUT_CONTROL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew12.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_OUTPUT_CONTROL}.make */
void F12_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 11, Current, 0, 1, 255);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.flush */
void F12_258 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("flush", 11, Current, 0, 0, 257);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(33,F28_390, (RTCV(RTOUCR(0,F1_24, (Current)))));
	F563_3089(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.update */
void F12_259 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("update", 11, Current, 0, 0, 258);
	RTHOOK(1);
	F12_258(Current);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append */
void F12_260 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("append", 11, Current, 0, 2, 259);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(0,F1_24, (Current));
	F28_420(RTCW(tr1), arg1);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		F28_443(RTCV(RTOUCR(0,F1_24, (Current))));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_32 */
void F12_261 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	struct eif_ex_31 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(52, 0x00).id);
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("append_32", 11, Current, 1, 2, 260);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(0,F1_24, (Current));
	tr2 = F53_646(RTCW(loc1), arg1);
	F28_420(RTCW(tr1), tr2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		F28_443(RTCV(RTOUCR(0,F1_24, (Current))));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_error */
void F12_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("append_error", 11, Current, 0, 2, 261);
	RTHOOK(1);
	F12_260(Current, arg1, arg2);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_error_32 */
void F12_263 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("append_error_32", 11, Current, 0, 2, 262);
	RTHOOK(1);
	F12_261(Current, arg1, arg2);
	RTHOOK(2);
	RTEE;
}

/* {EW_EWEASEL_OUTPUT_CONTROL}.append_new_line */
void F12_264 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("append_new_line", 11, Current, 0, 0, 263);
	RTGC;
	RTHOOK(1);
	F28_443(RTCV(RTOUCR(0,F1_24, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
