/*
 * Code for class EW_STRING_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew34.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_STRING_UTILITIES}.is_identifier_char */
EIF_BOOLEAN F54_709 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_identifier_char", 53, Current, 0, 1, 803);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '0':
		case (EIF_CHARACTER_8) '1':
		case (EIF_CHARACTER_8) '2':
		case (EIF_CHARACTER_8) '3':
		case (EIF_CHARACTER_8) '4':
		case (EIF_CHARACTER_8) '5':
		case (EIF_CHARACTER_8) '6':
		case (EIF_CHARACTER_8) '7':
		case (EIF_CHARACTER_8) '8':
		case (EIF_CHARACTER_8) '9':
		case (EIF_CHARACTER_8) 'A':
		case (EIF_CHARACTER_8) 'B':
		case (EIF_CHARACTER_8) 'C':
		case (EIF_CHARACTER_8) 'D':
		case (EIF_CHARACTER_8) 'E':
		case (EIF_CHARACTER_8) 'F':
		case (EIF_CHARACTER_8) 'G':
		case (EIF_CHARACTER_8) 'H':
		case (EIF_CHARACTER_8) 'I':
		case (EIF_CHARACTER_8) 'J':
		case (EIF_CHARACTER_8) 'K':
		case (EIF_CHARACTER_8) 'L':
		case (EIF_CHARACTER_8) 'M':
		case (EIF_CHARACTER_8) 'N':
		case (EIF_CHARACTER_8) 'O':
		case (EIF_CHARACTER_8) 'P':
		case (EIF_CHARACTER_8) 'Q':
		case (EIF_CHARACTER_8) 'R':
		case (EIF_CHARACTER_8) 'S':
		case (EIF_CHARACTER_8) 'T':
		case (EIF_CHARACTER_8) 'U':
		case (EIF_CHARACTER_8) 'V':
		case (EIF_CHARACTER_8) 'W':
		case (EIF_CHARACTER_8) 'X':
		case (EIF_CHARACTER_8) 'Y':
		case (EIF_CHARACTER_8) 'Z':
		case (EIF_CHARACTER_8) '_':
		case (EIF_CHARACTER_8) 'a':
		case (EIF_CHARACTER_8) 'b':
		case (EIF_CHARACTER_8) 'c':
		case (EIF_CHARACTER_8) 'd':
		case (EIF_CHARACTER_8) 'e':
		case (EIF_CHARACTER_8) 'f':
		case (EIF_CHARACTER_8) 'g':
		case (EIF_CHARACTER_8) 'h':
		case (EIF_CHARACTER_8) 'i':
		case (EIF_CHARACTER_8) 'j':
		case (EIF_CHARACTER_8) 'k':
		case (EIF_CHARACTER_8) 'l':
		case (EIF_CHARACTER_8) 'm':
		case (EIF_CHARACTER_8) 'n':
		case (EIF_CHARACTER_8) 'o':
		case (EIF_CHARACTER_8) 'p':
		case (EIF_CHARACTER_8) 'q':
		case (EIF_CHARACTER_8) 'r':
		case (EIF_CHARACTER_8) 's':
		case (EIF_CHARACTER_8) 't':
		case (EIF_CHARACTER_8) 'u':
		case (EIF_CHARACTER_8) 'v':
		case (EIF_CHARACTER_8) 'w':
		case (EIF_CHARACTER_8) 'x':
		case (EIF_CHARACTER_8) 'y':
		case (EIF_CHARACTER_8) 'z':
			RTHOOK(2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.is_prefix */
EIF_BOOLEAN F54_710 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_prefix", 53, Current, 2, 2, 804);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= ti4_1);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == loc2) || (EIF_BOOLEAN) !Result)) break;
		RTHOOK(4);
		loc1++;
		RTHOOK(5);
		tc1 = F911_5823(RTCW(arg1), loc1);
		tc2 = F911_5823(RTCW(arg2), loc1);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.first_white_position */
EIF_INTEGER_32 F54_711 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("first_white_position", 53, Current, 1, 1, 805);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4528[Dtype(arg1)-912]);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (Result > loc1)) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4281[Dtype(RTCW(arg1))-909])(arg1, Result);
			tr1 = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb2 = F838_4772(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		Result++;
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN) (Result > loc1)) {
		RTHOOK(6);
		RTHOOK(7);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.empty_strings_removed */
EIF_REFERENCE F54_713 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("empty_strings_removed", 53, Current, 2, 1, 791);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 672, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(arg1))-563])(arg1);
	F673_3692(RTCW(Result), ti4_1);
	RTHOOK(2);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2437[Dtype(RTCW(arg1))-652])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2054[Dtype(loc1)-296])(loc1);
		if (tb1) break;
		RTHOOK(3);
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2053[Dtype(loc1)-296])(loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb3 = F502_2965(loc2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			RTHOOK(4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc2);
		}
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2055[Dtype(loc1)-296])(loc1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.trim_white_space */
void F54_714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("trim_white_space", 53, Current, 2, 1, 792);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2437[Dtype(RTCW(arg1))-652])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2054[Dtype(loc1)-296])(loc1);
		if (tb1) break;
		RTHOOK(2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2053[Dtype(loc1)-296])(loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(3);
			F908_5737(loc2);
		}
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2055[Dtype(loc1)-296])(loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_STRING_UTILITIES}.broken_into_words */
EIF_REFERENCE F54_715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTEAA("broken_into_words", 53, Current, 6, 1, 793);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,912,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 672, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F673_3692(RTCW(Result), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4528[Dtype(arg1)-912]);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(4);
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4281[Dtype(RTCW(arg1))-909])(arg1, loc1);
		tr1 = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = tw1;
		loc6 = F838_4772(RTCW(tr1));
		RTHOOK(5);
		if (loc5) {
			RTHOOK(6);
			if (loc6) {
				RTHOOK(7);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(8);
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
				RTHOOK(9);
				loc4 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F913_5942(RTCW(loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc2) + ((EIF_INTEGER_32) 1L)));
				RTHOOK(10);
				F915_6031(RTCW(loc4), arg1, loc2, loc3);
				RTHOOK(11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc4);
			}
		} else {
			RTHOOK(12);
			if ((EIF_BOOLEAN) !loc6) {
				RTHOOK(13);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(14);
				loc2 = (EIF_INTEGER_32) loc1;
			}
		}
		RTHOOK(15);
		loc1++;
	}
	RTHOOK(16);
	if (loc5) {
		RTHOOK(17);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(18);
		loc4 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F913_5942(RTCW(loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc2) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(19);
		F915_6031(RTCW(loc4), arg1, loc2, loc3);
		RTHOOK(20);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc4);
	}
	RTHOOK(21);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.broken_into_words_8 */
EIF_REFERENCE F54_716 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTEAA("broken_into_words_8", 53, Current, 6, 1, 794);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,910,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 672, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F673_3692(RTCW(Result), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(4);
		tc1 = F911_5823(RTCW(arg1), loc1);
		loc6 = eif_builtin_CHARACTER_8_is_space__c1_b(tc1);
		RTHOOK(5);
		if (loc5) {
			RTHOOK(6);
			if (loc6) {
				RTHOOK(7);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(8);
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
				RTHOOK(9);
				loc4 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F909_5744(RTCW(loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc2) + ((EIF_INTEGER_32) 1L)));
				RTHOOK(10);
				F911_5831(RTCW(loc4), arg1, loc2, loc3);
				RTHOOK(11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc4);
			}
		} else {
			RTHOOK(12);
			if ((EIF_BOOLEAN) !loc6) {
				RTHOOK(13);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(14);
				loc2 = (EIF_INTEGER_32) loc1;
			}
		}
		RTHOOK(15);
		loc1++;
	}
	RTHOOK(16);
	if (loc5) {
		RTHOOK(17);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(18);
		loc4 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F909_5744(RTCW(loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc2) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(19);
		F911_5831(RTCW(loc4), arg1, loc2, loc3);
		RTHOOK(20);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc4);
	}
	RTHOOK(21);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.broken_into_arguments */
EIF_REFERENCE F54_717 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("broken_into_arguments", 53, Current, 5, 1, 795);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5944(RTCW(loc1), arg1);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,912,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 672, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F673_3692(RTCW(Result), ((EIF_INTEGER_32) 8L));
	for (;;) {
		RTHOOK(3);
		if (loc5) break;
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		loc2 = F913_5954(RTCW(loc1), tw1, ((EIF_INTEGER_32) 1L));
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(6);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			loc3 = F913_5954(RTCW(loc1), tw1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)))) {
			RTHOOK(9);
			loc4 = F54_715(Current, loc1);
			RTHOOK(10);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2884[Dtype(RTCW(Result))-652])(Result, loc4);
			RTHOOK(11);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(12);
			tr1 = F906_5695(RTCW(loc1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			loc4 = F54_715(Current, tr1);
			RTHOOK(13);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2884[Dtype(RTCW(Result))-652])(Result, loc4);
			RTHOOK(14);
			tr1 = F915_6104(RTCW(loc1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, tr1);
			RTHOOK(15);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2556[Dtype(RTCW(Result))-652])(Result);
			RTHOOK(16);
			F915_6079(RTCW(loc1), loc3);
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.broken_at */
EIF_REFERENCE F54_718 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLIU(4);
	
	RTEAA("broken_at", 53, Current, 6, 2, 796);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {652,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 652, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F653_3499(RTCW(Result));
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4528[Dtype(arg1)-912]);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(6);
		loc6 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4281[Dtype(RTCW(arg1))-909])(arg1, loc1);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc6 == arg2)) {
			RTHOOK(8);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
			RTHOOK(9);
			loc5 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F913_5942(RTCW(loc5), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc3) + ((EIF_INTEGER_32) 1L)));
			RTHOOK(10);
			F915_6031(RTCW(loc5), arg1, loc3, loc4);
			RTHOOK(11);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc5);
			RTHOOK(12);
			loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		}
		RTHOOK(13);
		loc1++;
	}
	RTHOOK(14);
	if ((EIF_BOOLEAN) (loc3 <= loc2)) {
		RTHOOK(15);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(16);
		loc5 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F913_5942(RTCW(loc5), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc3) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(17);
		F915_6031(RTCW(loc5), arg1, loc3, loc4);
		RTHOOK(18);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(Result))-652])(Result, loc5);
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.merged_with_separator */
EIF_REFERENCE F54_719 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("merged_with_separator", 53, Current, 1, 2, 797);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F906_5614(RTCW(Result));
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F501_2965(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2437[Dtype(RTCW(arg1))-652])(arg1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2054[Dtype(loc1)-296])(loc1);
			if (tb1) break;
			RTHOOK(4);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2501[Dtype(loc1)-296])(loc1);
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(5);
				F915_6057(RTCW(Result), arg2);
			}
			RTHOOK(6);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2053[Dtype(loc1)-296])(loc1);
			F915_6057(RTCW(Result), tr1);
			RTHOOK(7);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2055[Dtype(loc1)-296])(loc1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.leading_args_removed */
EIF_REFERENCE F54_720 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("leading_args_removed", 53, Current, 2, 2, 798);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5944(RTCW(Result), arg1);
	RTHOOK(2);
	F908_5737(RTCW(Result));
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		RTHOOK(5);
		loc2 = F54_711(Current, Result);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			F915_6039(RTCW(Result), ((EIF_INTEGER_32) 0L));
		} else {
			RTHOOK(8);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			tr1 = F915_6104(RTCW(Result), loc2, ti4_1);
			Result = (EIF_REFERENCE) tr1;
			RTHOOK(9);
			F915_6041(RTCW(Result));
		}
		RTHOOK(10);
		loc1++;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_STRING_UTILITIES}.from_utf_8 */
EIF_REFERENCE F54_722 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("from_utf_8", 53, Current, 0, 1, 800);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F52_662(Current, arg1);
}

/* {EW_STRING_UTILITIES}.to_utf_8 */
EIF_REFERENCE F54_723 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_utf_8", 53, Current, 0, 1, 801);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F52_646(Current, arg1);
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
