/*
 * Code for class EW_ACE_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew44.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_ACE_INST}.inst_initialize */
void F64_781 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("inst_initialize", 63, Current, 0, 1, 860);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4295[Dtype(RTCW(arg1))-909])(arg1);
	if (!tb2) {
		tb1 = (EIF_BOOLEAN) (F54_711(Current, arg1) > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTMS32_EX_H("z\000\000\000e\000\000\000r\000\000\000o\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000m\000\000\000o\000\000\000r\000\000\000e\000\000\000 \000\000\000t\000\000\000h\000\000\000a\000\000\000n\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000A\000\000\000c\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000l\000\000\000i\000\000\000e\000\000\000d\000\000\000",39,1834231652);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(5);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_ACE_INST}.execute */
void F64_782 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute", 63, Current, 0, 1, 861);
	RTHOOK(1);
	F925_6322(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	RTEE;
}

/* {EW_ACE_INST}.init_ok */
EIF_BOOLEAN F64_783 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_);
}


/* {EW_ACE_INST}.execute_ok */
EIF_BOOLEAN F64_784 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
