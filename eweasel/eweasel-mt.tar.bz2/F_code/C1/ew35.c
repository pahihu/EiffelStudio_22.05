/*
 * Code for class EW_FILTER_CREATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew35.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_FILTER_CREATION}.string_to_filter */
EIF_REFERENCE F55_724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("string_to_filter", 54, Current, 2, 1, 807);
	RTGC;
	RTHOOK(1);
	loc1 = F54_715(Current, arg1);
	RTHOOK(2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(loc1))-563])(loc1);
	if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2870[Dtype(RTCW(loc1))-652])(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4339[Dtype(RTCW(tr1))-909])(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(loc1))-563])(loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(6);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_) == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(7);
			ti4_1 = ((EIF_INTEGER_32) 2L);
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2571[Dtype(RTCW(loc1))-590])(loc1, (EIF_REFERENCE) &ti4_1);
		}
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS32_EX_H("t\000\000\000e\000\000\000s\000\000\000t\000\000\000",4,1952805748);
		tb1 = F913_5969(RTCW(tr1), tr2);
		if (tb1) {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(10);
				tr1 = RTLNS(eif_new_type(168, 0x00).id, 168, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F169_1663(RTCW(tr1), loc2);
				RTHOOK(11);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) tr1;
			}
		} else {
			RTHOOK(12);
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTMS32_EX_H("d\000\000\000i\000\000\000r\000\000\000",3,6580594);
			tb2 = F913_5969(RTCW(tr1), tr2);
			if (!tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = RTMS32_EX_H("d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000",9,1028911737);
				tb2 = F913_5969(RTCW(tr1), tr2);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(13);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(14);
					Result = RTLNS(eif_new_type(167, 0x00).id, 167, _OBJSIZ_1_0_0_0_0_0_0_0_);
					F168_1660(RTCW(Result), loc2);
				}
			} else {
				RTHOOK(15);
				tb1 = '\01';
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = RTMS32_EX_H("k\000\000\000w\000\000\000",2,27511);
				tb2 = F913_5969(RTCW(tr1), tr2);
				if (!tb2) {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = RTMS32_EX_H("k\000\000\000e\000\000\000y\000\000\000w\000\000\000o\000\000\000r\000\000\000d\000\000\000",7,223684196);
					tb2 = F913_5969(RTCW(tr1), tr2);
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(16);
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						RTHOOK(17);
						Result = RTLNS(eif_new_type(166, 0x00).id, 166, _OBJSIZ_1_0_0_0_0_0_0_0_);
						F167_1657(RTCW(Result), loc2);
						RTHOOK(18);
						RTLE;
						RTEE;
						return (EIF_REFERENCE) Result;
					}
				} else {
					RTHOOK(19);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		}
	} else {
		RTHOOK(20);
		tr1 = RTMS32_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(21);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(22);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit35 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
