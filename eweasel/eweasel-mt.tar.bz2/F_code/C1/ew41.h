
#ifndef _C1_ew41_
#define _C1_ew41_

#ifdef __cplusplus
extern "C" {
#endif

extern void F61_766(EIF_REFERENCE, EIF_REFERENCE);
extern void F61_767(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F61_768(EIF_REFERENCE);
extern EIF_BOOLEAN F61_769(EIF_REFERENCE);
extern EIF_BOOLEAN F61_770(EIF_REFERENCE);
extern void EIF_Minit41(void);
extern void F942_6697(EIF_REFERENCE);
extern void F945_6724(EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
