
#ifndef _C1_ew38_
#define _C1_ew38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F58_752(EIF_REFERENCE, EIF_REFERENCE);
extern void F58_753(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F58_754(EIF_REFERENCE);
extern EIF_BOOLEAN F58_755(EIF_REFERENCE);
extern void EIF_Minit38(void);
extern void F925_6320(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4295[])();

#ifdef __cplusplus
}
#endif

#endif
