/*
 * Code for class RESIZABLE [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re770.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RESIZABLE}.additional_space */
EIF_INTEGER_32 F536_2978 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("additional_space", 535, Current, 0, 0, 4146);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2601[Dtype(Current)-590])(Current);
	Result = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 5L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RESIZABLE}.automatic_grow */
void F536_2980 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("automatic_grow", 535, Current, 0, 0, 4148);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2601[dtype-590])(Current);
	ti4_2 = F536_2978(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2607[dtype-590])(Current, (EIF_INTEGER_32) (ti4_1 + ti4_2));
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit770 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
