
#ifndef _C16_re770_
#define _C16_re770_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F536_2978(EIF_REFERENCE);
extern void F536_2980(EIF_REFERENCE);
extern void EIF_Minit770(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
