
#ifndef _C16_fi754_
#define _C16_fi754_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F510_2965(EIF_REFERENCE);
extern void EIF_Minit754(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
