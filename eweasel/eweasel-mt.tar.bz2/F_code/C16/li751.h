
#ifndef _C16_li751_
#define _C16_li751_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_2880(EIF_REFERENCE, EIF_NATURAL_8);
extern EIF_BOOLEAN F389_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F389_2886(EIF_REFERENCE);
extern void EIF_Minit751(void);
extern EIF_NATURAL_8 F682_3697(EIF_REFERENCE);
extern void F682_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F510_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F636_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F612_3455(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
