
#ifndef _C16_co753_
#define _C16_co753_

#ifdef __cplusplus
extern "C" {
#endif

extern void F365_2867(EIF_REFERENCE);
extern void EIF_Minit753(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
