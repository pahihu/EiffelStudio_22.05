
#ifndef _C16_to768_
#define _C16_to768_

#ifdef __cplusplus
extern "C" {
#endif

extern void F202_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F202_2154(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F202_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit768(void);
extern void F708_4006(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
