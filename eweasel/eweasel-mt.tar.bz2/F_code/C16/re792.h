
#ifndef _C16_re792_
#define _C16_re792_

#ifdef __cplusplus
extern "C" {
#endif

extern void F295_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F295_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F295_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F295_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F295_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F295_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F295_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F295_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F295_2789(EIF_REFERENCE);
extern void F295_2791(EIF_REFERENCE);
extern void F295_2793(EIF_REFERENCE);
extern void F295_2794(EIF_REFERENCE);
extern void EIF_Minit792(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
