
#ifndef _C16_ty793_
#define _C16_ty793_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F283_2768(EIF_REFERENCE);
extern void EIF_Minit793(void);
extern EIF_INTEGER_32 F316_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
