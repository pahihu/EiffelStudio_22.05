
#ifndef _C16_ar769_
#define _C16_ar769_

#ifdef __cplusplus
extern "C" {
#endif

extern void F327_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2835(EIF_REFERENCE);
extern EIF_REFERENCE F327_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2839(EIF_REFERENCE);
extern void EIF_Minit769(void);
extern EIF_REFERENCE F682_3696(EIF_REFERENCE);
extern EIF_INTEGER_32 F682_3715(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
