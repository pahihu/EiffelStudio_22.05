
#ifndef _C16_bi764_
#define _C16_bi764_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F401_2894(EIF_REFERENCE);
extern void F401_2897(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit764(void);
extern EIF_BOOLEAN F636_3480(EIF_REFERENCE);
extern EIF_BOOLEAN F636_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F510_2965(EIF_REFERENCE);
extern void F682_3725(EIF_REFERENCE);
extern void F389_2880(EIF_REFERENCE, EIF_NATURAL_8);

#ifdef __cplusplus
}
#endif

#endif
