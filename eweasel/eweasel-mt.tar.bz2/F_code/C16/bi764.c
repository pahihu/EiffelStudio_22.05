/*
 * Code for class BILINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi764.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F401_2894 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 400, Current, 0, 0, 3905);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F636_3480(Current)) {
		Result = F636_3479(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F401_2897 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 400, Current, 0, 1, 3906);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F636_3480(Current)) {
		tb1 = (EIF_BOOLEAN) !F510_2965(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F682_3725(Current);
	}
	RTHOOK(3);
	F389_2880(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit764 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
