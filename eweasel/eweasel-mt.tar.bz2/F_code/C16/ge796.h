
#ifndef _C16_ge796_
#define _C16_ge796_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F316_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F316_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F316_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F316_2826(EIF_REFERENCE);
extern void F316_2829(EIF_REFERENCE);
extern void EIF_Minit796(void);

#ifdef __cplusplus
}
#endif

#endif
