
#ifndef _C17_re822_
#define _C17_re822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F537_2978(EIF_REFERENCE);
extern void F537_2980(EIF_REFERENCE);
extern void EIF_Minit822(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
