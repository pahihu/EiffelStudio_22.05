
#ifndef _C17_li803_
#define _C17_li803_

#ifdef __cplusplus
extern "C" {
#endif

extern void F390_2880(EIF_REFERENCE, EIF_REAL_32);
extern EIF_BOOLEAN F390_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F390_2886(EIF_REFERENCE);
extern void EIF_Minit803(void);
extern EIF_BOOLEAN F613_3455(EIF_REFERENCE);
extern EIF_BOOLEAN F637_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F511_2965(EIF_REFERENCE);
extern EIF_REAL_32 F683_3697(EIF_REFERENCE);
extern void F683_3725(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
