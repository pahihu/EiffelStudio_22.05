
#ifndef _C17_re828_
#define _C17_re828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F296_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F296_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F296_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F296_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F296_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2789(EIF_REFERENCE);
extern void F296_2791(EIF_REFERENCE);
extern void F296_2793(EIF_REFERENCE);
extern void F296_2794(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
