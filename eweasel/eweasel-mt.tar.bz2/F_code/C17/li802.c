/*
 * Code for class LIST [REAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li802.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST}.is_equal */
EIF_BOOLEAN F637_3478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("is_equal", 636, Current, 2, 1, 5772);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		Result = '\0';
		tb1 = '\0';
		tb2 = F511_2965(RTCW(arg1));
		if ((EIF_BOOLEAN)(F511_2965(Current) == tb2)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O2536[Dtype(arg1)-355]);
			tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O2536[dtype-355]) == tb2);
		}
		if (tb1) {
			ti4_1 = F683_3713(RTCW(arg1));
			Result = (EIF_BOOLEAN)(F683_3713(Current) == ti4_1);
		}
		RTHOOK(5);
		tb1 = '\0';
		if (Result) {
			tb1 = (EIF_BOOLEAN) !F511_2965(Current);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = F683_3703(Current);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = F683_3703(RTCW(arg1));
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTHOOK(7);
				F683_3723(Current);
				RTHOOK(8);
				F683_3723(RTCW(arg1));
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!F637_3479(Current)) {
						tb1 = (EIF_BOOLEAN) !Result;
					}
					if (tb1) break;
					RTHOOK(10);
					if (*(EIF_BOOLEAN *)(Current + O2536[dtype-355])) {
						RTHOOK(11);
						tr4_1 = F683_3697(Current);
						tr4_2 = F683_3697(RTCW(arg1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) eif_is_equal_real_32 (tr4_1, tr4_2);
					} else {
						RTHOOK(12);
						tr4_1 = F683_3697(Current);
						tr4_2 = F683_3697(RTCW(arg1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) eif_is_equal_real_32 (tr4_1, tr4_2);
					}
					RTHOOK(13);
					F683_3725(Current);
					RTHOOK(14);
					F683_3725(RTCW(arg1));
				}
				RTHOOK(15);
				F683_3728(Current, loc1);
				RTHOOK(16);
				F683_3728(RTCW(arg1), loc2);
			} else {
				
			}
		} else {
			RTHOOK(18);
			tb2 = '\0';
			tb3 = '\0';
			if (F511_2965(Current)) {
				tb4 = F511_2965(RTCW(arg1));
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O2536[Dtype(arg1)-355]);
				tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O2536[dtype-355]) == tb3);
			}
			if (tb2) {
				RTHOOK(19);
				RTHOOK(20);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.after */
EIF_BOOLEAN F637_3479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("after", 636, Current, 0, 0, 5773);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_2 = F683_3713(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.before */
EIF_BOOLEAN F637_3480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("before", 636, Current, 0, 0, 5774);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
