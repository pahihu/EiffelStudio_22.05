
#ifndef _C17_bi816_
#define _C17_bi816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F402_2894(EIF_REFERENCE);
extern void F402_2897(EIF_REFERENCE, EIF_REAL_32);
extern void EIF_Minit816(void);
extern EIF_BOOLEAN F637_3480(EIF_REFERENCE);
extern EIF_BOOLEAN F511_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F637_3479(EIF_REFERENCE);
extern void F390_2880(EIF_REFERENCE, EIF_REAL_32);
extern void F683_3725(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
