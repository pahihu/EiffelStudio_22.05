/*
 * Code for class LINEAR [REAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li803.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.search */
void F390_2880 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 389, Current, 0, 1, 3862);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O2536[Dtype(Current)-355])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F390_2884(Current)) {
				tb1 = (EIF_BOOLEAN) eif_is_equal_real_32 (arg1, F683_3697(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F683_3725(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F390_2884(Current)) {
				tb2 = (EIF_BOOLEAN) eif_is_equal_real_32 (arg1, F683_3697(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F683_3725(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F390_2884 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 389, Current, 0, 0, 3852);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F613_3455(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F390_2886 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 389, Current, 0, 0, 3853);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F511_2965(Current)) {
		Result = F637_3479(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
