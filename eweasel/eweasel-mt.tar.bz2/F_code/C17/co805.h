
#ifndef _C17_co805_
#define _C17_co805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F366_2867(EIF_REFERENCE);
extern void EIF_Minit805(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
