
#ifndef _C17_ge832_
#define _C17_ge832_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F317_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F317_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F317_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F317_2826(EIF_REFERENCE);
extern void F317_2829(EIF_REFERENCE);
extern void EIF_Minit832(void);

#ifdef __cplusplus
}
#endif

#endif
