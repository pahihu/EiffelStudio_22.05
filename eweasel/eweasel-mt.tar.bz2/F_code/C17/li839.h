
#ifndef _C17_li839_
#define _C17_li839_

#ifdef __cplusplus
extern "C" {
#endif

extern void F391_2880(EIF_REFERENCE, EIF_REAL_64);
extern EIF_BOOLEAN F391_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F391_2886(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern EIF_BOOLEAN F512_2965(EIF_REFERENCE);
extern void F684_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F614_3455(EIF_REFERENCE);
extern EIF_REAL_64 F684_3697(EIF_REFERENCE);
extern EIF_BOOLEAN F638_3479(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
