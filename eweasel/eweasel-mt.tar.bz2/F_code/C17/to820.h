
#ifndef _C17_to820_
#define _C17_to820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F203_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F203_2154(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern void F203_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern void F709_4006(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
