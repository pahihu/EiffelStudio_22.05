/*
 * Code for class SPECIAL [REAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sp833.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SPECIAL}.make_empty */
void F710_4005 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_empty", 709, Current, 0, 1, 8257);
	RTGC;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {SPECIAL}.make_filled */
void F710_4006 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_filled", 709, Current, 0, 2, 8258);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (SPECIAL.make_empty) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F710_4027(Current, arg1, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {SPECIAL}.item */
EIF_REAL_64 F710_4008 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_REAL_64 *) Current + arg1);
}

EIF_REFERENCE F710_40081 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_REAL_64 r = *((EIF_REAL_64 *) Current + arg1);
	Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)Result = r;
	return Result;
}

/* {SPECIAL}.at */
EIF_REAL_64 F710_4009 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_REAL_64 *) Current + arg1);
}

EIF_REFERENCE F710_40091 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_REAL_64 r = *((EIF_REAL_64 *) Current + arg1);
	Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)Result = r;
	return Result;
}

/* {SPECIAL}.item_address */
EIF_POINTER F710_4011 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return (EIF_POINTER) (Current + (rt_uint_ptr) arg1 * (rt_uint_ptr)sizeof(EIF_REAL_64));
}

/* {SPECIAL}.base_address */
EIF_POINTER F710_4012 (EIF_REFERENCE Current)
{
	return (EIF_POINTER) Current;
}

/* {SPECIAL}.to_array */
EIF_REFERENCE F710_4014 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("to_array", 709, Current, 0, 0, 8266);
	RTGC;
	RTHOOK(1);
	{
		EIF_TYPE_INDEX typarr0[] = {601,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y2438,Y2438_gen_type,Dftype(Current),239);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 601, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F602_3385(RTCW(tr1), Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {SPECIAL}.lower */
EIF_INTEGER_32 F710_4016 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {SPECIAL}.upper */
EIF_INTEGER_32 F710_4017 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("upper", 709, Current, 0, 0, 8269);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.count */
EIF_INTEGER_32 F710_4018 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 709, Current, 0, 0, 8270);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.capacity */
EIF_INTEGER_32 F710_4019 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("capacity", 709, Current, 0, 0, 8271);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.same_items */
EIF_BOOLEAN F710_4021 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_items", 709, Current, 3, 4, 8273);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tr8_2 = *((EIF_REAL_64 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tr8_1 = tr8_2;
			/* INLINED CODE (SPECIAL.item) */
			tr8_3 = *((EIF_REAL_64 *)Current + (loc2));
			/* END INLINED CODE */
			if ((EIF_BOOLEAN) !eif_is_equal_real_64 (tr8_1, tr8_3)) {
				RTHOOK(8);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(9);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
			}
			RTHOOK(10);
			loc1++;
			RTHOOK(11);
			loc2++;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.valid_index */
EIF_BOOLEAN F710_4022 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("valid_index", 709, Current, 0, 1, 8274);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) <= arg1)) {
		Result = (EIF_BOOLEAN) (arg1 < (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.put */
void F710_4023 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	*((EIF_REAL_64 *) Current + arg2) = arg1;
}

void F710_40232 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_REAL_64 *) Current + arg2) = *(EIF_REAL_64 *)arg1;
}

/* {SPECIAL}.force */
void F710_4024 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 arg3 = RT_SPECIAL_COUNT(Current);
	*((EIF_REAL_64 *) Current + arg2) = arg1;
	if (arg2 == arg3) { RT_SPECIAL_COUNT(Current) = arg3 + 1; }
}

void F710_40242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_REAL_64 *) Current + arg2) = *(EIF_REAL_64 *)arg1;
}

/* {SPECIAL}.extend */
void F710_4025 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current);
	*((EIF_REAL_64 *) Current + arg2) = arg1;
	RT_SPECIAL_COUNT(Current) = arg2 + 1;
}

void F710_40252 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current);
	*((EIF_REAL_64 *) Current + arg2) = *(EIF_REAL_64 *)arg1;
	RT_SPECIAL_COUNT(Current) = arg2 + 1;
}

/* {SPECIAL}.fill_with */
void F710_4027 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 i;
	for (i = arg2; i <= arg3; i++) {
		*((EIF_REAL_64 *) Current + i) = arg1;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

void F710_40272 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	EIF_INTEGER_32 i;
	EIF_REAL_64 arg1x = *(EIF_REAL_64 *)arg1;
	for (i = arg2; i < arg3; i++) {
	*((EIF_REAL_64 *) Current + i) = arg1x;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

/* {SPECIAL}.insert_data */
void F710_4029 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("insert_data", 709, Current, 6, 4, 8281);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - arg3);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_REAL_64 *)Current + (arg3),(EIF_REAL_64 *)arg1 + arg2, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg4);
		RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
		/* END INLINED CODE */
		;
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg4 <= loc1)) {
			RTHOOK(5);
			/* INLINED CODE (SPECIAL.overlapping_move) */
			memmove((EIF_REAL_64 *)Current + ((EIF_INTEGER_32) (arg3 + arg4)),(EIF_REAL_64 *)Current + arg3, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)loc1);
			RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), (EIF_INTEGER_32) (arg3 + arg4) + loc1);
			/* END INLINED CODE */
			;
			RTHOOK(6);
			/* INLINED CODE (SPECIAL.copy_data) */
			memmove((EIF_REAL_64 *)Current + (arg3),(EIF_REAL_64 *)arg1 + arg2, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg4);
			RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
			/* END INLINED CODE */
			;
		} else {
			RTHOOK(7);
			loc4 = (EIF_INTEGER_32) arg2;
			RTHOOK(8);
			loc6 = (EIF_INTEGER_32) arg3;
			RTHOOK(9);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
			RTHOOK(10);
			loc3 = (EIF_INTEGER_32) arg4;
			RTHOOK(11);
			loc2 = (EIF_INTEGER_32) loc1;
			for (;;) {
				RTHOOK(12);
				if ((EIF_BOOLEAN) (loc4 >= loc5)) break;
				RTHOOK(13);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_REAL_64 *)Current + ((EIF_INTEGER_32) (loc6 + loc2)),(EIF_REAL_64 *)Current + loc6, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)loc1);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), (EIF_INTEGER_32) (loc6 + loc2) + loc1);
				/* END INLINED CODE */
				;
				RTHOOK(14);
				/* INLINED CODE (SPECIAL.copy_data) */
				memmove((EIF_REAL_64 *)Current + (loc6),(EIF_REAL_64 *)arg1 + loc4, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)loc2);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), loc6 + loc2);
				/* END INLINED CODE */
				;
				RTHOOK(15);
				loc6 += loc2;
				RTHOOK(16);
				loc4 += loc2;
				RTHOOK(17);
				loc3 -= loc1;
				RTHOOK(18);
				ti4_1 = eif_min_int32 (loc2,loc3);
				loc2 = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {SPECIAL}.copy_data */
void F710_4030 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("copy_data", 709, Current, 3, 4, 8282);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		/* INLINED CODE (SPECIAL.overlapping_move) */
		memmove((EIF_REAL_64 *)Current + (arg3),(EIF_REAL_64 *)Current + arg2, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg4);
		RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
		/* END INLINED CODE */
		;
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tr8_2 = *((EIF_REAL_64 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tr8_1 = tr8_2;
			F710_4024(Current, tr8_1, loc2);
			RTHOOK(8);
			loc1++;
			RTHOOK(9);
			loc2++;
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {SPECIAL}.move_data */
void F710_4031 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_data", 709, Current, 0, 3, 8283);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
	} else {
		RTHOOK(2);
		if ((EIF_BOOLEAN) (arg1 > arg2)) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) < arg1)) {
				RTHOOK(4);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_REAL_64 *)Current + (arg2),(EIF_REAL_64 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(5);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_REAL_64 *)Current + (arg2),(EIF_REAL_64 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 + arg3) < arg2)) {
				RTHOOK(7);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_REAL_64 *)Current + (arg2),(EIF_REAL_64 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(8);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_REAL_64 *)Current + (arg2),(EIF_REAL_64 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {SPECIAL}.overlapping_move */
void F710_4032 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("overlapping_move", 709, Current, 3, 3, 8284);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < arg2)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg3) - ((EIF_INTEGER_32) 1L));
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) >= (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
			RTHOOK(6);
			/* INLINED CODE (SPECIAL.item) */
			tr8_2 = *((EIF_REAL_64 *)Current + (arg1));
			/* END INLINED CODE */
			tr8_1 = tr8_2;
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
			F710_4027(Current, tr8_1, ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + arg3) - ((EIF_INTEGER_32) 1L)));
		}
		
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(9);
			/* INLINED CODE (SPECIAL.item) */
			tr8_2 = *((EIF_REAL_64 *)Current + (loc1));
			/* END INLINED CODE */
			tr8_1 = tr8_2;
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_REAL_64 *)Current + ((EIF_INTEGER_32) (loc1 + loc3))) = tr8_1;
			/* END INLINED CODE */
			;
			RTHOOK(10);
			loc1--;
		}
	} else {
		RTHOOK(11);
		loc1 = (EIF_INTEGER_32) arg1;
		RTHOOK(12);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
		RTHOOK(13);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - arg2);
		
		for (;;) {
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(16);
			/* INLINED CODE (SPECIAL.item) */
			tr8_2 = *((EIF_REAL_64 *)Current + (loc1));
			/* END INLINED CODE */
			tr8_1 = tr8_2;
			F710_4024(Current, tr8_1, (EIF_INTEGER_32) (loc1 - loc3));
			RTHOOK(17);
			loc1++;
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {SPECIAL}.non_overlapping_move */
void F710_4033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("non_overlapping_move", 709, Current, 3, 3, 8285);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tr8_2 = *((EIF_REAL_64 *)Current + (loc1));
		/* END INLINED CODE */
		tr8_1 = tr8_2;
		F710_4024(Current, tr8_1, (EIF_INTEGER_32) (loc1 + loc3));
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {SPECIAL}.keep_head */
void F710_4034 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("keep_head", 709, Current, 0, 1, 8286);
	RTHOOK(1);
	eif_builtin_SPECIAL_set_count__i4_ (Current, arg1);
	RTHOOK(4);
	RTEE;
}

/* {SPECIAL}.remove_tail */
void F710_4037 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_tail", 709, Current, 0, 1, 8289);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	F710_4034(Current, (EIF_INTEGER_32) (ti4_1 - arg1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {SPECIAL}.resized_area */
EIF_REFERENCE F710_4038 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area", 709, Current, 0, 1, 8290);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg1,sizeof(EIF_REAL_64), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	ti4_1 = eif_min_int32 (arg1,ti4_1);
	/* INLINED CODE (SPECIAL.copy_data) */
	memmove((EIF_REAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_REAL_64 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)ti4_1);
	RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
	/* END INLINED CODE */
	;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.resized_area_with_default */
EIF_REFERENCE F710_4039 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area_with_default", 709, Current, 0, 2, 8291);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg2,sizeof(EIF_REAL_64), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_REAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_REAL_64 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)ti4_1);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
		/* END INLINED CODE */
		;
		RTHOOK(4);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		F710_4027(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	} else {
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_REAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_REAL_64 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_REAL_64) * (rt_uint_ptr)arg2);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + arg2);
		/* END INLINED CODE */
		;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area */
EIF_REFERENCE F710_4040 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area", 709, Current, 0, 1, 8292);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area_with_default */
EIF_REFERENCE F710_4041 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area_with_default", 709, Current, 0, 2, 8293);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg2);
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Result);
	F710_4027(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.wipe_out */
void F710_4043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("wipe_out", 709, Current, 0, 0, 8295);
	RTHOOK(1);
	eif_builtin_SPECIAL_set_count__i4_ (Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	RTEE;
}

/* {SPECIAL}.clear_all */
void F710_4044 (EIF_REFERENCE Current)
{
	memset (Current, 0, RT_SPECIAL_VISIBLE_SIZE(Current));
}

/* {SPECIAL}.element_size */
EIF_INTEGER_32 F710_4052 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("element_size", 709, Current, 0, 0, 8254);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_element_size__i4 (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.set_count */
void F710_4053 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_count", 709, Current, 0, 1, 8255);
	eif_builtin_SPECIAL_set_count__i4_ (Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit833 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
