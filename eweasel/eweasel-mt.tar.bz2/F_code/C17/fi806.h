
#ifndef _C17_fi806_
#define _C17_fi806_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F511_2965(EIF_REFERENCE);
extern void EIF_Minit806(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
