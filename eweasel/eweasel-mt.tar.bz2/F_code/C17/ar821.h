
#ifndef _C17_ar821_
#define _C17_ar821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F328_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F328_2835(EIF_REFERENCE);
extern EIF_REFERENCE F328_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F328_2839(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern EIF_INTEGER_32 F683_3715(EIF_REFERENCE);
extern EIF_REFERENCE F683_3696(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
