
#ifndef _C17_ty829_
#define _C17_ty829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F284_2768(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern EIF_INTEGER_32 F317_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
