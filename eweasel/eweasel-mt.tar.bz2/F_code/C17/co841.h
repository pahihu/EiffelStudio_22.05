
#ifndef _C17_co841_
#define _C17_co841_

#ifdef __cplusplus
extern "C" {
#endif

extern void F367_2867(EIF_REFERENCE);
extern void EIF_Minit841(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
