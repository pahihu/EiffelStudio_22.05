
#ifndef _C11_re503_
#define _C11_re503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F289_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2789(EIF_REFERENCE);
extern void F289_2791(EIF_REFERENCE);
extern void F289_2793(EIF_REFERENCE);
extern void F289_2794(EIF_REFERENCE);
extern void EIF_Minit503(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
