
#ifndef _C11_co547_
#define _C11_co547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F361_2867(EIF_REFERENCE);
extern void EIF_Minit547(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
