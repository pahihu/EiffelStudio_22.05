
#ifndef _C11_ce544_
#define _C11_ce544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F45_622(EIF_REFERENCE);
extern void F45_623(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit544(void);
extern long O605[];

#ifdef __cplusplus
}
#endif

#endif
