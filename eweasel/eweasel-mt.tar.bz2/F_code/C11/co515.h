
#ifndef _C11_co515_
#define _C11_co515_

#ifdef __cplusplus
extern "C" {
#endif

extern void F360_2867(EIF_REFERENCE);
extern void EIF_Minit515(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
