/*
 * Code for class CELL [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_INTEGER_32 F45_622 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O605[Dtype(Current)-43]);
}


/* {CELL}.put */
void F45_623 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put", 44, Current, 0, 1, 619);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O605[Dtype(Current)-43]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
