
#ifndef _C11_li546_
#define _C11_li546_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F304_2802(EIF_REFERENCE);
extern EIF_BOOLEAN F304_2803(EIF_REFERENCE);
extern void F304_2804(EIF_REFERENCE);
extern void F304_2805(EIF_REFERENCE);
extern EIF_REFERENCE F304_2806(EIF_REFERENCE);
extern void EIF_Minit546(void);
extern EIF_BOOLEAN F287_2786(EIF_REFERENCE);
extern void F287_2794(EIF_REFERENCE);
extern void F287_2793(EIF_REFERENCE);
extern EIF_INTEGER_32 F275_2768(EIF_REFERENCE);
extern EIF_BOOLEAN F287_2788(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
