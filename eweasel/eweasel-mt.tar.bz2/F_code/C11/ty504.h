
#ifndef _C11_ty504_
#define _C11_ty504_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F277_2768(EIF_REFERENCE);
extern void EIF_Minit504(void);
extern EIF_INTEGER_32 F309_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
