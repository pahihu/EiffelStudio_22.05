
#ifndef _C11_bi539_
#define _C11_bi539_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F396_2894(EIF_REFERENCE);
extern void F396_2897(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit539(void);
extern void F382_2880(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F503_2965(EIF_REFERENCE);
extern char *(*R2555[])();
extern char *(*R2557[])();
extern char *(*R2558[])();

#ifdef __cplusplus
}
#endif

#endif
