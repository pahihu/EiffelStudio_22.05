/*
 * Code for class LIST [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li512.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST}.is_equal */
EIF_BOOLEAN F630_3478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("is_equal", 629, Current, 2, 1, 5744);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		Result = '\0';
		tb1 = '\0';
		tb2 = F505_2965(RTCW(arg1));
		if ((EIF_BOOLEAN)(F505_2965(Current) == tb2)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O2536[Dtype(arg1)-355]);
			tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O2536[dtype-355]) == tb2);
		}
		if (tb1) {
			ti4_1 = F676_3713(RTCW(arg1));
			Result = (EIF_BOOLEAN)(F676_3713(Current) == ti4_1);
		}
		RTHOOK(5);
		tb1 = '\0';
		if (Result) {
			tb1 = (EIF_BOOLEAN) !F505_2965(Current);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = F676_3703(Current);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = F676_3703(RTCW(arg1));
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTHOOK(7);
				F676_3723(Current);
				RTHOOK(8);
				F676_3723(RTCW(arg1));
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!F630_3479(Current)) {
						tb1 = (EIF_BOOLEAN) !Result;
					}
					if (tb1) break;
					RTHOOK(10);
					if (*(EIF_BOOLEAN *)(Current + O2536[dtype-355])) {
						RTHOOK(11);
						tu8_1 = F676_3697(Current);
						tu8_2 = F676_3697(RTCW(arg1));
						Result = (EIF_BOOLEAN) (tu8_1 == tu8_2);
					} else {
						RTHOOK(12);
						tu8_1 = F676_3697(Current);
						tu8_2 = F676_3697(RTCW(arg1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 == tu8_2);
					}
					RTHOOK(13);
					F676_3725(Current);
					RTHOOK(14);
					F676_3725(RTCW(arg1));
				}
				RTHOOK(15);
				F676_3728(Current, loc1);
				RTHOOK(16);
				F676_3728(RTCW(arg1), loc2);
			} else {
				
			}
		} else {
			RTHOOK(18);
			tb2 = '\0';
			tb3 = '\0';
			if (F505_2965(Current)) {
				tb4 = F505_2965(RTCW(arg1));
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O2536[Dtype(arg1)-355]);
				tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O2536[dtype-355]) == tb3);
			}
			if (tb2) {
				RTHOOK(19);
				RTHOOK(20);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.after */
EIF_BOOLEAN F630_3479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("after", 629, Current, 0, 0, 5745);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_2 = F676_3713(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.before */
EIF_BOOLEAN F630_3480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("before", 629, Current, 0, 0, 5746);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
