
#ifndef _C11_bi526_
#define _C11_bi526_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F395_2894(EIF_REFERENCE);
extern void F395_2897(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit526(void);
extern EIF_BOOLEAN F505_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F630_3480(EIF_REFERENCE);
extern void F676_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F630_3479(EIF_REFERENCE);
extern void F384_2880(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
