
#ifndef _C11_ge506_
#define _C11_ge506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F309_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F309_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F309_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F309_2826(EIF_REFERENCE);
extern void F309_2829(EIF_REFERENCE);
extern void EIF_Minit506(void);

#ifdef __cplusplus
}
#endif

#endif
