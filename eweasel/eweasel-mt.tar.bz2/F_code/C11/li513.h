
#ifndef _C11_li513_
#define _C11_li513_

#ifdef __cplusplus
extern "C" {
#endif

extern void F384_2880(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F384_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F384_2886(EIF_REFERENCE);
extern void EIF_Minit513(void);
extern EIF_NATURAL_64 F676_3697(EIF_REFERENCE);
extern void F676_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F630_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F606_3455(EIF_REFERENCE);
extern EIF_BOOLEAN F505_2965(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
