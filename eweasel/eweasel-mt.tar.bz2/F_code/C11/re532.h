
#ifndef _C11_re532_
#define _C11_re532_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F530_2978(EIF_REFERENCE);
extern void F530_2980(EIF_REFERENCE);
extern void EIF_Minit532(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
