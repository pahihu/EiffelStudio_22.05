
#ifndef _C11_fi516_
#define _C11_fi516_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F505_2965(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
