/*
 * Code for class BILINEAR [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F395_2894 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 394, Current, 0, 0, 3887);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F630_3480(Current)) {
		Result = F630_3479(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F395_2897 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 394, Current, 0, 1, 3888);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F630_3480(Current)) {
		tb1 = (EIF_BOOLEAN) !F505_2965(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F676_3725(Current);
	}
	RTHOOK(3);
	F384_2880(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
