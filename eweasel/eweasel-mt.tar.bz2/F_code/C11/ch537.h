
#ifndef _C11_ch537_
#define _C11_ch537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F607_3444(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F607_3447(EIF_REFERENCE);
extern EIF_BOOLEAN F607_3452(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F607_3454(EIF_REFERENCE);
extern EIF_BOOLEAN F607_3455(EIF_REFERENCE);
extern void F607_3459(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit537(void);
extern EIF_BOOLEAN F382_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F503_2965(EIF_REFERENCE);
extern char *(*R2584[])();
extern char *(*R2586[])();
extern char *(*R2544[])();
extern char *(*R2551[])();
extern char *(*R2598[])();
extern char *(*R2556[])();
extern char *(*R2557[])();
extern char *(*R2873[])();
extern char *(*R2564[])();
extern char *(*R2578[])();

#ifdef __cplusplus
}
#endif

#endif
