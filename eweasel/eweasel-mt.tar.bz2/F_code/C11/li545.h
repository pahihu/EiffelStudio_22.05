
#ifndef _C11_li545_
#define _C11_li545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F119_1498(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit545(void);

#ifdef __cplusplus
}
#endif

#endif
