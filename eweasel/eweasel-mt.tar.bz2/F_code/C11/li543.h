
#ifndef _C11_li543_
#define _C11_li543_

#ifdef __cplusplus
extern "C" {
#endif

extern void F50_626(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit543(void);

#ifdef __cplusplus
}
#endif

#endif
