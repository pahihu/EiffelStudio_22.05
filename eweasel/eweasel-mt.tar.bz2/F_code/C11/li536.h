
#ifndef _C11_li536_
#define _C11_li536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F631_3478(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F631_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F631_3480(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern EIF_BOOLEAN F503_2965(EIF_REFERENCE);
extern char *(*R2584[])();
extern char *(*R2586[])();
extern char *(*R2544[])();
extern char *(*R2551[])();
extern char *(*R2555[])();
extern char *(*R2598[])();
extern char *(*R2557[])();
extern char *(*R2578[])();
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
