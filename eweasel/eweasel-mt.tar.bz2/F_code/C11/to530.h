
#ifndef _C11_to530_
#define _C11_to530_

#ifdef __cplusplus
extern "C" {
#endif

extern void F196_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F196_2154(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F196_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit530(void);
extern void F702_4006(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
