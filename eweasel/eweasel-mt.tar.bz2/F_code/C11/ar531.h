
#ifndef _C11_ar531_
#define _C11_ar531_

#ifdef __cplusplus
extern "C" {
#endif

extern void F321_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2835(EIF_REFERENCE);
extern EIF_REFERENCE F321_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2839(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern EIF_REFERENCE F676_3696(EIF_REFERENCE);
extern EIF_INTEGER_32 F676_3715(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
