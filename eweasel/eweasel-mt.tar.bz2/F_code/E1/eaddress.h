#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F686_3830(EIF_REFERENCE);
extern void F694_3903(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F87_1090(EIF_REFERENCE, EIF_BOOLEAN);
extern void F694_3904(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F87_1088(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif
