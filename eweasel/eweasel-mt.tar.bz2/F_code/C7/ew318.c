/*
 * Code for class EW_INSTRUCTION_TABLES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_INSTRUCTION_TABLES}.test_command_table */
static EIF_REFERENCE F924_6287_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(16)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_command_table", 923, Current, 0, 0, 12333);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {691,55,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 691, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F686_3776(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(184, 0x00).id, 184, _OBJSIZ_7_4_0_1_0_0_0_0_);
	tr2 = RTOUCR(56,F183_1877, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(59, 0x00).id, 59, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr2 = RTOUCR(51,F183_1892, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(766, 0x00).id, 766, _OBJSIZ_10_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(57,F183_1878, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(58, 0x00).id, 58, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(58,F183_1890, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(57, 0x00).id, 57, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(59,F183_1886, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(64, 0x00).id, 64, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(60,F183_1885, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(63, 0x00).id, 63, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(61,F183_1847, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(62,F183_1848, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(668, 0x00).id, 668, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(63,F183_1871, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(11);
	tr1 = RTLNS(eif_new_type(667, 0x00).id, 667, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(64,F183_1891, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(666, 0x00).id, 666, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(65,F183_1868, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(765, 0x00).id, 765, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(66,F183_1869, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(14);
	tr1 = RTLNS(eif_new_type(764, 0x00).id, 764, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(67,F183_1870, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(15);
	tr1 = RTLNS(eif_new_type(665, 0x00).id, 665, _OBJSIZ_8_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(68,F183_1883, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(16);
	tr1 = RTLNS(eif_new_type(664, 0x00).id, 664, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(69,F183_1893, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(771, 0x00).id, 771, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(70,F183_1863, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(18);
	tr1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(71,F183_1866, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(19);
	tr1 = RTLNS(eif_new_type(775, 0x00).id, 775, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(72,F183_1864, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(20);
	tr1 = RTLNS(eif_new_type(774, 0x00).id, 774, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(73,F183_1865, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(21);
	tr1 = RTLNS(eif_new_type(761, 0x00).id, 761, _OBJSIZ_8_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(74,F183_1872, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(22);
	tr1 = RTLNS(eif_new_type(61, 0x00).id, 61, _OBJSIZ_6_1_0_2_0_0_0_0_);
	tr2 = RTOUCR(75,F183_1867, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(23);
	tr1 = RTLNS(eif_new_type(788, 0x00).id, 788, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(76,F183_1859, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(24);
	tr1 = RTLNS(eif_new_type(787, 0x00).id, 787, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(77,F183_1860, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(25);
	tr1 = RTLNS(eif_new_type(786, 0x00).id, 786, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(78,F183_1858, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(26);
	tr1 = RTLNS(eif_new_type(793, 0x00).id, 793, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(79,F183_1857, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(27);
	tr1 = RTLNS(eif_new_type(792, 0x00).id, 792, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(80,F183_1856, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(28);
	tr1 = RTLNS(eif_new_type(791, 0x00).id, 791, _OBJSIZ_7_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(81,F183_1861, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(29);
	tr1 = RTLNS(eif_new_type(768, 0x00).id, 768, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(82,F183_1882, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(30);
	tr1 = RTLNS(eif_new_type(767, 0x00).id, 767, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(83,F183_1852, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(31);
	tr1 = RTLNS(eif_new_type(760, 0x00).id, 760, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(84,F183_1846, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(32);
	tr1 = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(85,F183_1876, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(33);
	tr1 = RTLNS(eif_new_type(66, 0x00).id, 66, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(86,F183_1862, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(34);
	tr1 = RTLNS(eif_new_type(790, 0x00).id, 790, _OBJSIZ_10_3_0_2_0_0_0_0_);
	tr2 = RTOUCR(87,F183_1853, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(35);
	tr1 = RTLNS(eif_new_type(106, 0x00).id, 106, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(88,F183_1854, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(36);
	tr1 = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(89,F183_1851, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(37);
	tr1 = RTLNS(eif_new_type(780, 0x00).id, 780, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(90,F183_1849, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(38);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(91,F183_1850, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(39);
	tr1 = RTLNS(eif_new_type(778, 0x00).id, 778, _OBJSIZ_9_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(92,F183_1875, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(40);
	tr1 = RTLNS(eif_new_type(777, 0x00).id, 777, _OBJSIZ_9_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(93,F183_1873, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(41);
	tr1 = RTLNS(eif_new_type(62, 0x00).id, 62, _OBJSIZ_7_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(94,F183_1874, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(42);
	tr1 = RTLNS(eif_new_type(763, 0x00).id, 763, _OBJSIZ_8_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(95,F183_1855, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(43);
	tr1 = RTLNS(eif_new_type(56, 0x00).id, 56, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(96,F183_1880, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(44);
	tr1 = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_9_2_0_2_0_0_0_0_);
	tr2 = RTOUCR(97,F183_1881, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(45);
	tr1 = RTLNS(eif_new_type(60, 0x00).id, 60, _OBJSIZ_6_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(49,F183_1887, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(46);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F924_6287 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(16,F924_6287_body,(Current));
}

/* {EW_INSTRUCTION_TABLES}.test_suite_command_table */
static EIF_REFERENCE F924_6288_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(31)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_suite_command_table", 923, Current, 0, 0, 12334);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {691,55,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 691, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F686_3776(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(184, 0x00).id, 184, _OBJSIZ_7_4_0_1_0_0_0_0_);
	tr2 = RTOUCR(56,F183_1877, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(59, 0x00).id, 59, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr2 = RTOUCR(51,F183_1892, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(766, 0x00).id, 766, _OBJSIZ_10_2_0_1_0_0_0_0_);
	tr2 = RTOUCR(57,F183_1878, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(668, 0x00).id, 668, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(63,F183_1871, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(667, 0x00).id, 667, _OBJSIZ_7_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(64,F183_1891, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(666, 0x00).id, 666, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(65,F183_1868, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(765, 0x00).id, 765, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(66,F183_1869, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTLNS(eif_new_type(764, 0x00).id, 764, _OBJSIZ_8_1_0_1_0_0_0_0_);
	tr2 = RTOUCR(67,F183_1870, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F924_6288 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(31,F924_6288_body,(Current));
}

/* {EW_INSTRUCTION_TABLES}.test_catalog_command_table */
static EIF_REFERENCE F924_6289_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(98)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("test_catalog_command_table", 923, Current, 0, 0, 12335);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {691,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 691, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F686_3776(RTCW(tr1), ((EIF_INTEGER_32) 30L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(164, 0x00).id, 164, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOUCR(51,F183_1892, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(183, 0x00).id, 183, _OBJSIZ_2_2_0_0_0_0_0_0_);
	tr2 = RTOUCR(56,F183_1877, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOUCR(99,F183_1884, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(762, 0x00).id, 762, _OBJSIZ_1_1_0_0_0_0_0_0_);
	tr2 = RTOUCR(100,F183_1888, (Current));
	F686_3822(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F924_6289 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(98,F924_6289_body,(Current));
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
