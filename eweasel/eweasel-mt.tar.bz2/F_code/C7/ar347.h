
#ifndef _C7_ar347_
#define _C7_ar347_

#ifdef __cplusplus
extern "C" {
#endif

extern void F673_3692(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F673_3696(EIF_REFERENCE);
extern EIF_REFERENCE F673_3697(EIF_REFERENCE);
extern EIF_REFERENCE F673_3698(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F673_3700(EIF_REFERENCE);
extern EIF_REFERENCE F673_3701(EIF_REFERENCE);
extern EIF_INTEGER_32 F673_3702(EIF_REFERENCE);
extern EIF_REFERENCE F673_3703(EIF_REFERENCE);
extern EIF_REFERENCE F673_3706(EIF_REFERENCE);
extern EIF_INTEGER_32 F673_3713(EIF_REFERENCE);
extern EIF_INTEGER_32 F673_3714(EIF_REFERENCE);
extern EIF_INTEGER_32 F673_3715(EIF_REFERENCE);
extern EIF_BOOLEAN F673_3716(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F673_3719(EIF_REFERENCE, EIF_INTEGER_32);
extern void F673_3723(EIF_REFERENCE);
extern void F673_3724(EIF_REFERENCE);
extern void F673_3725(EIF_REFERENCE);
extern void F673_3727(EIF_REFERENCE, EIF_INTEGER_32);
extern void F673_3728(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3729(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3733(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3738(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3739(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3740(EIF_REFERENCE, EIF_INTEGER_32);
extern void F673_3743(EIF_REFERENCE, EIF_REFERENCE);
extern void F673_3746(EIF_REFERENCE);
extern void F673_3751(EIF_REFERENCE);
extern void F673_3753(EIF_REFERENCE);
extern void EIF_Minit347(void);
extern void F671_3658(EIF_REFERENCE);
extern EIF_REFERENCE F686_3782(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F686_3784(EIF_REFERENCE, EIF_REFERENCE);
extern void F117_1496(EIF_REFERENCE, EIF_INTEGER_32);
extern void F603_3459(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F671_3659(EIF_REFERENCE);
extern char *(*R3234[])();
extern char *(*R3235[])();
extern char *(*R3236[])();
extern char *(*R1921[])();
extern char *(*R3001[])();
extern char *(*R3242[])();
extern char *(*R3245[])();
extern char *(*R3248[])();
extern char *(*R2598[])();
extern char *(*R3214[])();
extern char *(*R3215[])();
extern char *(*R2521[])();
extern char *(*R2568[])();
extern char *(*R2605[])();
extern char *(*R3227[])();
extern char *(*R2571[])();
extern char *(*R2534[])();
extern char *(*R2808[])();
extern char *(*R3230[])();
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];
extern EIF_TYPE_INDEX Y1922[];
extern EIF_TYPE_INDEX *Y1922_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
