
#ifndef _C7_ew340_
#define _C7_ew340_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F946_6728(EIF_REFERENCE);
extern EIF_REFERENCE F946_6729(EIF_REFERENCE);
extern void EIF_Minit340(void);
extern EIF_REFERENCE F945_6721(EIF_REFERENCE);
extern EIF_REFERENCE F942_6705(EIF_REFERENCE);
extern EIF_BOOLEAN F112_1442(EIF_REFERENCE);
extern void F111_1420(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
