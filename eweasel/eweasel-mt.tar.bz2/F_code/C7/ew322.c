/*
 * Code for class EW_EWEASEL_MT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew322.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_MT}.new_test_suite */
EIF_REFERENCE F928_6378 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_test_suite", 927, Current, 0, 2, 12423);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_6_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(784, 0x00).id, 784, _OBJSIZ_3_0_0_4_0_0_0_0_);
		F783_4235(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_4_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(783, 0x00).id, 783, _OBJSIZ_3_0_0_4_0_0_0_0_);
		F783_4235(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_4_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit322 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
