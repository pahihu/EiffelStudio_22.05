/*
 * Code for class SEQ_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se306.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEQ_STRING}.search_string_after */
void F912_5912 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("search_string_after", 911, Current, 0, 2, 11970);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F397_2894(Current)) {
		RTHOOK(2);
		ti4_1 = F909_5763(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_), arg2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {SEQ_STRING}.current_item */
EIF_CHARACTER_8 F912_5914 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("current_item", 911, Current, 0, 0, 11972);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F911_5823(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
}

/* {SEQ_STRING}.index */
EIF_INTEGER_32 F912_5915 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
}


/* {SEQ_STRING}.has */
EIF_BOOLEAN F912_5917 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 911, Current, 0, 1, 11975);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F506_2965(Current)) {
		RTHOOK(2);
		ti4_1 = F909_5757(Current, arg1, ((EIF_INTEGER_32) 1L));
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {SEQ_STRING}.before */
EIF_BOOLEAN F912_5918 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("before", 911, Current, 0, 0, 11976);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) < ((EIF_INTEGER_32) 1L));
}

/* {SEQ_STRING}.after */
EIF_BOOLEAN F912_5919 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("after", 911, Current, 0, 0, 11977);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_));
}

/* {SEQ_STRING}.start */
void F912_5920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("start", 911, Current, 0, 0, 11978);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	RTEE;
}

/* {SEQ_STRING}.forth */
void F912_5923 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("forth", 911, Current, 0, 0, 11981);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))++;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit306 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
