
#ifndef _C7_ti329_
#define _C7_ti329_

#ifdef __cplusplus
extern "C" {
#endif

extern void F935_6522(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F935_6532(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit329(void);
extern void F75_930(EIF_REFERENCE, EIF_INTEGER_32);
extern void F75_928(EIF_REFERENCE, EIF_INTEGER_32);
extern void F75_929(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
