/*
 * Code for class EW_CODE_ANALYSIS_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_CODE_ANALYSIS_PROCESS}.next_analysis_result_type */
EIF_REFERENCE F946_6728 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_analysis_result_type", 945, Current, 0, 0, 12778);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_CODE_ANALYSIS_PROCESS}.next_analysis_result */
EIF_REFERENCE F946_6729 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_analysis_result", 945, Current, 0, 0, 12779);
	RTGC;
	RTHOOK(1);
	Result = F945_6721(Current);
	RTHOOK(2);
	tb1 = F112_1442(RTCW(Result));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = F942_6705(Current);
		F111_1420(RTCW(Result), tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
