
#ifndef _C7_ew322_
#define _C7_ew322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F928_6378(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit322(void);
extern void F783_4235(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
