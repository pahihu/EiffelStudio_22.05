/*
 * Code for class THREAD_ATTRIBUTES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "th310.h"
#include "eif_eiffel.h"
#include "eif_threads.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F916_6117
static void inline_F916_6117 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	#ifdef EIF_THREADS
	((EIF_THR_ATTR_TYPE *) arg1)->priority = arg2;
#endif
	;
}
#define INLINE_F916_6117
#endif
#ifndef INLINE_F916_6121
static EIF_INTEGER_32 inline_F916_6121 (void)
{
	#ifdef EIF_THREADS
	return sizeof(EIF_THR_ATTR_TYPE);
#else
	return 1L;
#endif
	;
}
#define INLINE_F916_6121
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {THREAD_ATTRIBUTES}.make */
void F916_6109 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 915, Current, 0, 0, 12158);
	RTGC;
	RTHOOK(1);
	F105_1327(Current);
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_thr_default_priority();
	F916_6110(Current, ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {THREAD_ATTRIBUTES}.set_priority */
void F916_6110 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_priority", 915, Current, 0, 1, 12159);
	RTGC;
	RTHOOK(1);
	tp1 = F105_1330(Current);
	inline_F916_6117(tp1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {THREAD_ATTRIBUTES}.default_priority */
EIF_INTEGER_32 F916_6114 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_priority", 915, Current, 0, 0, 12163);Result = (EIF_INTEGER_32) eif_thr_default_priority();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {THREAD_ATTRIBUTES}.c_set_priority */
void F916_6117 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_set_priority", 915, Current, 0, 2, 12166);
	inline_F916_6117 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {THREAD_ATTRIBUTES}.structure_size */
EIF_INTEGER_32 F916_6121 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("structure_size", 915, Current, 0, 0, 12170);
	Result = inline_F916_6121 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
