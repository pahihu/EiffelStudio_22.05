/*
 * Code for class EW_C_COMPILATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew338.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_C_COMPILATION}.make */
void F944_6716 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,arg4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTEAA("make", 943, Current, 2, 5, 12766);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {652,912,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 652, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F653_3499(RTCW(loc1));
	RTHOOK(2);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("-\000\000\000l\000\000\000o\000\000\000c\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",9,566239598);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(loc1))-652])(loc1, tr1);
		RTHOOK(4);
		loc2 = (EIF_REFERENCE) arg3;
	} else {
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(loc1))-652])(loc1, arg3);
		RTHOOK(6);
		loc2 = RTOUCR(206,F944_6718, (Current));
	}
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(loc1))-652])(loc1, arg1);
	RTHOOK(8);
	if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(9);
		tr1 = RTMS32_EX_H("-\000\000\000n\000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000",6,1975866211);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(loc1))-652])(loc1, tr1);
		RTHOOK(10);
		tr1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr2 = eif_out__i4_s1(arg5);
		F915_6018(RTCW(tr1), tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(loc1))-652])(loc1, tr1);
	}
	RTHOOK(11);
	F942_6692(Current, loc2, loc1, arg4, NULL, NULL, arg2);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EW_C_COMPILATION}.next_compile_result_type */
EIF_REFERENCE F944_6717 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_compile_result_type", 943, Current, 0, 0, 12767);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_C_COMPILATION}.shell_command */

EIF_REFERENCE F944_6718 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (206,RTMS32_EX_H("/\000\000\000b\000\000\000i\000\000\000n\000\000\000/\000\000\000s\000\000\000h\000\000\000",7,2075682408));
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
