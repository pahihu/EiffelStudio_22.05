/*
 * Code for class STRING_GENERAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_GENERAL}.reset_hash_codes */
void F908_5712 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_hash_codes", 907, Current, 0, 0, 11800);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O4370[dtype-905]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O4371[dtype-905]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.append_code */
void F908_5714 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("append_code", 907, Current, 1, 1, 11801);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4317[dtype-909])(Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4318[dtype-909])(Current))) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4406[dtype-910])(Current, loc1);
	}
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4373[dtype-910])(Current, loc1);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R4376[dtype-910])(Current, arg1, loc1);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.append */
void F908_5725 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append", 907, Current, 3, 1, 11802);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4317[Dtype(RTCW(arg1))-909])(arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4317[dtype-909])(Current);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc2);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4318[dtype-909])(Current))) {
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4406[dtype-910])(Current, loc2);
		}
		RTHOOK(6);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(7);
			if ((EIF_BOOLEAN) (loc3 > loc1)) break;
			RTHOOK(8);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4280[Dtype(RTCW(arg1))-909])(arg1, loc3);
			F908_5714(Current, tu4_1);
			RTHOOK(9);
			loc3++;
		}
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4373[dtype-910])(Current, loc2);
		RTHOOK(11);
		F908_5712(Current);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.adjust */
void F908_5737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("adjust", 907, Current, 0, 0, 11798);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4398[dtype-910])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4399[dtype-910])(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
