/*
 * Code for class EW_EIFFEL_TEST_QUEUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew312.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EIFFEL_TEST_QUEUE}.make */
void F918_6192 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 917, Current, 0, 0, 12253);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(232, 0).id);
	F233_2319(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,8,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F673_3692(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,8,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F673_3692(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {672,8,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F673_3692(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(233, 0).id);
	F234_2335(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = RTLNSMART(eif_new_type(233, 0).id);
	F234_2335(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.set_results_in_catalog_order */
void F918_6195 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_results_in_catalog_order", 917, Current, 0, 1, 12256);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.extend */
void F918_6196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("extend", 917, Current, 1, 1, 12257);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(8, 0x00).id, 8, _OBJSIZ_1_2_0_0_0_0_0_0_);
	F9_110(RTCW(loc1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2322(RTCW(tr1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F673_3733(RTCW(tr1), loc1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F234_2337(RTCW(tr1));
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2324(RTCW(tr1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.mark_test_completed */
void F918_6197 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("mark_test_completed", 917, Current, 3, 1, 12258);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2322(RTCW(tr1));
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(3);
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	} else {
		RTHOOK(4);
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	}
	RTHOOK(5);
	F673_3723(RTCW(loc3));
	for (;;) {
		RTHOOK(6);
		tb1 = '\01';
		tb2 = F627_3479(RTCW(loc3));
		if (!tb2) {
			tb1 = loc1;
		}
		if (tb1) break;
		RTHOOK(7);
		loc2 = F673_3697(RTCW(loc3));
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			RTHOOK(9);
			F9_114(RTCW(loc2), (EIF_BOOLEAN) 0);
			RTHOOK(10);
			F9_115(RTCW(loc2), (EIF_BOOLEAN) 0);
			RTHOOK(11);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(12);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
				RTHOOK(13);
				F673_3746(RTCW(loc3));
				RTHOOK(14);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				F673_3733(RTCW(tr1), loc2);
			}
		}
		RTHOOK(15);
		tb2 = F627_3479(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(16);
			F673_3725(RTCW(loc3));
		}
	}
	RTHOOK(17);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F234_2337(RTCW(tr1));
	RTHOOK(18);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F234_2337(RTCW(tr1));
	RTHOOK(19);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2324(RTCW(tr1));
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.next_waiting_test */
EIF_REFERENCE F918_6198 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_waiting_test", 917, Current, 2, 0, 12259);
	RTGC;
	for (;;) {
		RTHOOK(1);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result != NULL) || loc1)) break;
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F233_2322(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F673_3723(RTCW(tr1));
		for (;;) {
			RTHOOK(4);
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb2 = F627_3479(RTCW(tr1));
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb1) break;
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc2 = F673_3697(RTCW(tr1));
			RTHOOK(6);
			tb2 = '\0';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_0_);
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_1_);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				RTHOOK(7);
				F9_115(RTCW(loc2), (EIF_BOOLEAN) 1);
				RTHOOK(8);
				Result = *(EIF_REFERENCE *)(RTCW(loc2));
				RTHOOK(9);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
					RTHOOK(10);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F673_3746(RTCW(tr1));
					RTHOOK(11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					F673_3733(RTCW(tr1), loc2);
				}
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F673_3725(RTCW(tr1));
		}
		RTHOOK(13);
		loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && loc1);
		RTHOOK(14);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !loc1)) {
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F234_2339(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		}
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(Current);
		F233_2324(RTCW(tr1));
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_TEST_QUEUE}.next_completed_test */
EIF_REFERENCE F918_6199 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_completed_test", 917, Current, 2, 0, 12260);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result != NULL) || (EIF_BOOLEAN) !loc2)) break;
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		F233_2322(RTCW(tr1));
		RTHOOK(4);
		loc2 = F918_6202(Current);
		RTHOOK(5);
		if (loc2) {
			RTHOOK(6);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc1 = F673_3700(RTCW(tr1));
				RTHOOK(8);
				tb1 = '\0';
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_0_);
				if ((EIF_BOOLEAN) !tb2) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_1_);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					RTHOOK(9);
					Result = *(EIF_REFERENCE *)(RTCW(loc1));
					RTHOOK(10);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F673_3723(RTCW(tr1));
					RTHOOK(11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F673_3746(RTCW(tr1));
				}
			} else {
				RTHOOK(12);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tb1 = F501_2965(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(13);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					tr1 = F673_3700(RTCW(tr1));
					Result = *(EIF_REFERENCE *)(RTCW(tr1));
					RTHOOK(14);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					F673_3723(RTCW(tr1));
					RTHOOK(15);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					F673_3746(RTCW(tr1));
				}
			}
		}
		RTHOOK(16);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && loc2)) {
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F234_2339(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		}
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current);
		F233_2324(RTCW(tr1));
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_TEST_QUEUE}.set_all_tests_added */
void F918_6200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_all_tests_added", 917, Current, 0, 0, 12242);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2322(RTCW(tr1));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F234_2338(RTCW(tr1));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2324(RTCW(tr1));
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.broadcast_all_tests_completed */
void F918_6201 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("broadcast_all_tests_completed", 917, Current, 0, 0, 12243);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2322(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F234_2338(RTCW(tr1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	F233_2324(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_TEST_QUEUE}.has_more_tests */
EIF_BOOLEAN F918_6202 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("has_more_tests", 917, Current, 0, 0, 12244);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F501_2965(RTCW(tr1));
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	} else {
		RTHOOK(3);
		Result = '\01';
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = F501_2965(RTCW(tr1));
		if (!(EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb2 = F501_2965(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = F501_2965(RTCW(tr1));
			Result = (EIF_BOOLEAN) !tb1;
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit312 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
