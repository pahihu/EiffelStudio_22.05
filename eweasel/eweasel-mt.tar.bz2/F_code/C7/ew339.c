/*
 * Code for class EW_EIFFEL_COMPILATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EIFFEL_COMPILATION}.make */
void F945_6719 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 944, Current, 0, 4, 12770);
	RTHOOK(1);
	F942_6692(Current, arg1, arg2, arg3, NULL, NULL, arg4);
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.next_compile_result_type */
EIF_REFERENCE F945_6720 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_compile_result_type", 944, Current, 0, 0, 12771);
	RTGC;
	RTHOOK(1);
	RTCT0("callable", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EW_EIFFEL_COMPILATION}.next_compile_result */
EIF_REFERENCE F945_6721 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_compile_result", 944, Current, 0, 0, 12772);
	RTGC;
	RTHOOK(1);
	Result = F942_6699(Current);
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1307[Dtype(RTCW(Result))-110])(Result);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = F942_6705(Current);
		F111_1420(RTCW(Result), tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_COMPILATION}.resume */
void F945_6722 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("resume", 944, Current, 0, 0, 12773);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("\012",1,10);
	F942_6695(Current, tr1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.quit */
void F945_6723 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("quit", 944, Current, 0, 0, 12774);
	RTGC;
	RTHOOK(1);
	F942_6695(Current, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.abort */
void F945_6724 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("abort", 944, Current, 0, 0, 12775);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
		RTHOOK(2);
		F945_6723(Current);
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5087[Dtype(Current)-942])(Current);
		{
			/* INLINED CODE (ANY.do_nothing) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	F942_6697(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.terminate */
void F945_6725 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("terminate", 944, Current, 0, 0, 12776);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
		RTHOOK(2);
		F945_6723(Current);
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5087[Dtype(Current)-942])(Current);
		{
			/* INLINED CODE (ANY.do_nothing) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	F942_6696(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_COMPILATION}.read_chunk */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F945_6726 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 EIF_VOLATILE loc7 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEAA("read_chunk", 944, Current, 7, 0, 12777);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F909_5744(RTCW(tr1), ((EIF_INTEGER_32) 128L));
		loc5 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == (EIF_CHARACTER_8) '\012') || *(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) || loc2)) break;
			RTHOOK(5);
			F942_6709(Current);
			RTHOOK(6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
				RTHOOK(7);
				loc7 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_7_0_);
				RTHOOK(8);
				if ((EIF_BOOLEAN)(loc7 != (EIF_CHARACTER_8) '\015')) {
					RTHOOK(9);
					F911_5871(RTCW(loc5), loc7);
					RTHOOK(10);
					loc6++;
					RTHOOK(11);
					loc3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(187,F84_1051, (Current)))+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc6 == ti4_1)) {
						tr1 = RTOUCR(187,F84_1051, (Current));
						tb1 = F909_5772(RTCW(loc5), tr1);
						loc3 = tb1;
					}
					RTHOOK(12);
					loc4 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(188,F84_1052, (Current)))+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc6 == ti4_1)) {
						tr1 = RTOUCR(188,F84_1052, (Current));
						tb1 = F909_5772(RTCW(loc5), tr1);
						loc4 = tb1;
					}
					RTHOOK(13);
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || loc4);
				}
			}
		}
	}
	RTHOOK(14);
	if (loc2) {
		RTHOOK(15);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(16);
		if (loc3) {
			RTHOOK(17);
			tr1 = RTMS_EX_H("q\012",2,28938);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(18);
			tr1 = RTMS_EX_H("n\012",2,28170);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(19);
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc5;
	RTE_E
	RTXSC;
	RTHOOK(20);
	if ((EIF_BOOLEAN)(F122_1514(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(21);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(22);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(23);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(24);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
