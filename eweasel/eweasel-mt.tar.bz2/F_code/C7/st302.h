
#ifndef _C7_st302_
#define _C7_st302_

#ifdef __cplusplus
extern "C" {
#endif

extern void F908_5712(EIF_REFERENCE);
extern void F908_5714(EIF_REFERENCE, EIF_NATURAL_32);
extern void F908_5725(EIF_REFERENCE, EIF_REFERENCE);
extern void F908_5737(EIF_REFERENCE);
extern void EIF_Minit302(void);
extern char *(*R4406[])();
extern char *(*R4373[])();
extern char *(*R4376[])();
extern char *(*R4398[])();
extern char *(*R4399[])();
extern char *(*R4317[])();
extern char *(*R4318[])();
extern char *(*R4280[])();
extern long O4370[];
extern long O4371[];

#ifdef __cplusplus
}
#endif

#endif
