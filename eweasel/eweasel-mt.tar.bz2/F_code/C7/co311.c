/*
 * Code for class CONSOLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co311.h"
#include "eif_console.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONSOLE}.make_open_stdout */
void F917_6131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_stdout", 916, Current, 0, 1, 12181);
	RTGC;
	RTHOOK(1);
	F565_3272(Current, arg1);
	RTHOOK(2);
	tp1 = (EIF_POINTER) console_def(((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F563_3218(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONSOLE}.make_open_stderr */
void F917_6132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_stderr", 916, Current, 0, 1, 12182);
	RTGC;
	RTHOOK(1);
	F565_3272(Current, arg1);
	RTHOOK(2);
	tp1 = (EIF_POINTER) console_def(((EIF_INTEGER_32) 2L));
	*(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	F563_3218(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONSOLE}.end_of_file */
EIF_BOOLEAN F917_6135 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("end_of_file", 916, Current, 0, 0, 12185);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(console_eof((FILE*) tp1));
}

/* {CONSOLE}.exists */
EIF_BOOLEAN F917_6136 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exists", 916, Current, 0, 0, 12186);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONSOLE}.count */
EIF_INTEGER_32 F917_6137 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {CONSOLE}.dispose */
void F917_6138 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 916, Current, 0, 0, 12188);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.back */
void F917_6139 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("back", 916, Current, 0, 0, 12189);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.read_line */
void F917_6145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_line", 916, Current, 0, 0, 12195);
	RTHOOK(1);
	F917_6147(Current);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.read_line_thread_aware */
void F917_6147 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLIU(3);
	
	RTEAA("read_line_thread_aware", 916, Current, 7, 0, 12197);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc7 = RTOUCR(106,F563_3161, (Current));
	RTHOOK(3);
	F911_5886(RTCW(loc4));
	RTHOOK(4);
	loc1 = F114_1484(RTCW(loc7));
	for (;;) {
		RTHOOK(5);
		if (loc3) break;
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		tp2 = F114_1482(RTCW(loc7));
		loc2 = F917_6188(Current, tp1, tp2, loc1, ((EIF_INTEGER_32) 0L));
		RTHOOK(7);
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
		RTHOOK(8);
		loc6 = eif_min_int32 (loc2,loc1);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc6);
		RTHOOK(9);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= loc1);
		RTHOOK(10);
		F911_5890(RTCW(loc4), loc6);
		RTHOOK(11);
		F911_5906(RTCW(loc4), loc6);
		RTHOOK(12);
		ti4_1 = eif_min_int32 (loc2,loc1);
		F114_1476(RTCW(loc7), loc4, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {CONSOLE}.read_stream */
void F917_6148 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_stream", 916, Current, 0, 1, 12198);
	RTHOOK(1);
	F917_6150(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.read_stream_thread_aware */
void F917_6150 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("read_stream_thread_aware", 916, Current, 3, 1, 12200);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc2 = RTOUCR(106,F563_3161, (Current));
	RTHOOK(3);
	F114_1490(RTCW(loc2), arg1);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	tp2 = F114_1482(RTCW(loc2));
	loc1 = F917_6190(Current, tp1, tp2, arg1);
	RTHOOK(5);
	F114_1490(RTCW(loc2), loc1);
	RTHOOK(6);
	F911_5890(RTCW(loc3), loc1);
	RTHOOK(7);
	F911_5906(RTCW(loc3), loc1);
	RTHOOK(8);
	F114_1478(RTCW(loc2), loc3);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONSOLE}.read_character */
void F917_6154 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("read_character", 916, Current, 0, 0, 12204);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	tc1 = F917_6184(Current, tp1);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_) = (EIF_CHARACTER_8) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONSOLE}.put_character */
void F917_6157 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("put_character", 916, Current, 0, 1, 12207);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	console_pc((FILE*) tp1, (EIF_CHARACTER) arg1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.put_string */
void F917_6159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("put_string", 916, Current, 2, 1, 12209);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4440[Dtype(arg1)-908]);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		console_ps((FILE*) tp1, (char*) loc2, (EIF_INTEGER) loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONSOLE}.put_new_line */
void F917_6167 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("put_new_line", 916, Current, 0, 0, 12217);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	console_tnwl((FILE*) tp1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.new_line */
void F917_6168 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("new_line", 916, Current, 0, 0, 12218);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	console_tnwl((FILE*) tp1);
	RTHOOK(2);
	RTEE;
}

/* {CONSOLE}.is_empty */
EIF_BOOLEAN F917_6169 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {CONSOLE}.console_def */
EIF_POINTER F917_6170 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_def", 916, Current, 0, 1, 12220);Result = (EIF_POINTER) console_def(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_eof */
EIF_BOOLEAN F917_6175 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_eof", 916, Current, 0, 1, 12225);Result = (EIF_BOOLEAN) EIF_TEST(console_eof((FILE*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_ps */
void F917_6177 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_ps", 916, Current, 0, 3, 12227);console_ps((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_pc */
void F917_6179 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_pc", 916, Current, 0, 2, 12229);console_pc((FILE*) arg1, (EIF_CHARACTER) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_tnwl */
void F917_6182 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_tnwl", 916, Current, 0, 1, 12232);console_tnwl((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONSOLE}.console_readchar */
EIF_CHARACTER_8 F917_6184 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readchar", 916, Current, 0, 1, 12234);
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) console_readchar((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_readline */
EIF_INTEGER_32 F917_6188 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readline", 916, Current, 0, 4, 12238);
	EIF_ENTER_C;Result = (EIF_INTEGER_32) console_readline((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.console_readstream */
EIF_INTEGER_32 F917_6190 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("console_readstream", 916, Current, 0, 3, 12240);
	EIF_ENTER_C;Result = (EIF_INTEGER_32) console_readstream((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CONSOLE}.file_close */
void F917_6191 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_close", 916, Current, 0, 1, 12241);console_file_close((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
