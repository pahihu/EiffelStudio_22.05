/*
 * Code for class EW_EIFFEL_EWEASEL_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew319.h"
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F82_993
static EIF_INTEGER_32 inline_F82_993 (void)
{
	time_t current_time;

  				current_time = time(&current_time);
  				if (current_time == (time_t) -1) {
    					eraise("time() call failed", EN_PROG);
  				}
  				return (EIF_INTEGER) current_time;
	;
}
#define INLINE_F82_993
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EIFFEL_EWEASEL_TEST}.make */
void F925_6290 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 924, Current, 0, 1, 12359);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F925_6299(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.execute */
void F925_6292 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTEAA("execute", 924, Current, 5, 1, 12361);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2544[Dtype(RTCW(tr1))-563])(tr1);
	for (;;) {
		RTHOOK(5);
		tb1 = '\01';
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2555[Dtype(RTCW(tr1))-499])(tr1);
		if (!tb3) {
			tb2 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_);
		}
		if (!tb2) {
			tb1 = loc5;
		}
		if (tb1) break;
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2578[Dtype(RTCW(tr1))-499])(tr1);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R713[Dtype(RTCW(loc1))-56])(loc1, Current);
		RTHOOK(8);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R715[Dtype(RTCW(loc1))-56])(loc1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) tb2;
		RTHOOK(9);
		loc5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R716[Dtype(RTCW(loc1))-56])(loc1);
		RTHOOK(10);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-499])(tr1);
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_)) {
		RTHOOK(12);
		if ((EIF_BOOLEAN) !loc5) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2556[Dtype(RTCW(tr1))-652])(tr1);
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2578[Dtype(RTCW(tr1))-499])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R713[Dtype(RTCW(tr1))-56])(tr1, Current);
		}
		RTHOOK(15);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(16);
			RTCT0("from_loop_invariant", EX_CHECK);
				RTCF0;
		}
		RTHOOK(17);
		loc3 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F906_5614(RTCW(loc3));
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		F915_6057(RTCW(loc3), tr1);
		RTHOOK(19);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F915_6071(RTCW(loc3), tw1);
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		F915_6057(RTCW(loc3), tr1);
		RTHOOK(21);
		loc4 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F906_5614(RTCW(loc4));
		RTHOOK(22);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		tr1 = F906_5673(RTCW(tr1));
		F915_6057(RTCW(loc4), tr1);
		RTHOOK(23);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F915_6071(RTCW(loc4), tw1);
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
		F915_6057(RTCW(loc4), tr1);
		RTHOOK(25);
		loc2 = RTLNS(eif_new_type(660, 0x00).id, 660, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O725[Dtype(loc1)-55]);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F659_3585(RTCW(loc2), tr1, ti4_1, loc3, loc4, tr2);
		RTHOOK(26);
		F925_6338(Current, loc2);
	}
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.copy_wait_required */
EIF_BOOLEAN F925_6296 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("copy_wait_required", 924, Current, 0, 0, 12365);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_)) {
		ti4_1 = inline_F82_993();
		Result = (EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_2_));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.unset_copy_wait */
void F925_6297 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unset_copy_wait", 924, Current, 0, 0, 12366);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_defaults */
void F925_6299 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_defaults", 924, Current, 0, 0, 12368);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {691,912,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F686_3776(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(44,F663_3606, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTOUCR(45,F663_3605, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.e_compile_output_name */
EIF_REFERENCE F925_6311 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("e_compile_output_name", 924, Current, 0, 0, 12380);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5942(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOUCR(46,F925_6339, (Current));
	F915_6057(RTCW(Result), tr1);
	RTHOOK(3);
	F915_6060(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_1_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.c_compile_output_name */
EIF_REFERENCE F925_6312 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("c_compile_output_name", 924, Current, 0, 0, 12381);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5942(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOUCR(47,F925_6340, (Current));
	F915_6057(RTCW(Result), tr1);
	RTHOOK(3);
	F915_6060(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_3_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.execution_output_name */
EIF_REFERENCE F925_6313 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("execution_output_name", 924, Current, 0, 0, 12382);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5942(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	tr1 = RTOUCR(48,F925_6341, (Current));
	F915_6057(RTCW(Result), tr1);
	RTHOOK(3);
	F915_6060(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_4_));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_test_name */
void F925_6319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_test_name", 924, Current, 0, 1, 12336);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_test_description */
void F925_6320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_test_description", 924, Current, 0, 1, 12337);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_system_name */
void F925_6321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_system_name", 924, Current, 0, 1, 12338);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_ace_name */
void F925_6322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_ace_name", 924, Current, 0, 1, 12339);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_target_name */
void F925_6323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTEAA("set_target_name", 924, Current, 1, 1, 12340);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(21,F758_4126, (Current));
	loc1 = F670_3652(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = RTOUCR(19,F759_4135, (Current));
	tr2 = RTOUCR(20,F663_3608, (Current));
	tr1 = F211_2289(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTOUCR(19,F759_4135, (Current));
	tr1 = F211_2289(RTCW(tr1), loc1, arg1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(26,F758_4129, (Current));
	tr3 = RTOUCR(19,F759_4135, (Current));
	tr4 = RTOUCR(25,F663_3609, (Current));
	tr3 = F211_2289(RTCW(tr3), loc1, tr4);
	F670_3645(RTCW(tr1), tr2, tr3);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(28,F758_4130, (Current));
	tr3 = RTOUCR(19,F759_4135, (Current));
	tr4 = RTOUCR(27,F663_3610, (Current));
	tr3 = F211_2289(RTCW(tr3), loc1, tr4);
	F670_3645(RTCW(tr1), tr2, tr3);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_preference */
void F925_6324 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("set_preference", 924, Current, 0, 2, 12341);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F686_3823(RTCW(tr1), arg2, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_cpu_limit */
void F925_6325 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_cpu_limit", 924, Current, 0, 1, 12342);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compilation */
void F925_6326 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_e_compilation", 924, Current, 0, 1, 12343);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compile_start_time */
void F925_6327 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_e_compile_start_time", 924, Current, 0, 1, 12344);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_c_compilation */
void F925_6328 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_c_compilation", 924, Current, 0, 1, 12345);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_e_compilation_result */
void F925_6329 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_e_compilation_result", 924, Current, 0, 1, 12346);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_c_compilation_result */
void F925_6330 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_c_compilation_result", 924, Current, 0, 1, 12347);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_execution_result */
void F925_6331 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_execution_result", 924, Current, 0, 1, 12348);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.set_instructions */
void F925_6332 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_instructions", 924, Current, 0, 1, 12349);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_e_compile_count */
void F925_6333 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_e_compile_count", 924, Current, 0, 0, 12350);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_1_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_c_compile_count */
void F925_6334 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_c_compile_count", 924, Current, 0, 0, 12351);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_3_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.increment_execution_count */
void F925_6335 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increment_execution_count", 924, Current, 0, 0, 12352);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_4_))++;
	RTHOOK(2);
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.add_error */
void F925_6338 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_error", 924, Current, 0, 1, 12355);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(657, 0).id);
		F658_3579(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	F658_3580(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_EIFFEL_EWEASEL_TEST}.eiffel_compile_output_prefix */

EIF_REFERENCE F925_6339 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (46,RTMS32_EX_H("e\000\000\000_\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000i\000\000\000l\000\000\000e\000\000\000",9,2077996133));
}

/* {EW_EIFFEL_EWEASEL_TEST}.c_compile_output_prefix */

EIF_REFERENCE F925_6340 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (47,RTMS32_EX_H("c\000\000\000_\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000i\000\000\000l\000\000\000e\000\000\000",9,1960031333));
}

/* {EW_EIFFEL_EWEASEL_TEST}.execution_output_prefix */

EIF_REFERENCE F925_6341 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (48,RTMS32_EX_H("e\000\000\000x\000\000\000e\000\000\000c\000\000\000u\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",9,986487406));
}

void EIF_Minit319 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
