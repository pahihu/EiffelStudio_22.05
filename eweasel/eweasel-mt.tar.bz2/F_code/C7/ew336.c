/*
 * Code for class EW_EWEASEL_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_EWEASEL_PROCESS}.make */
void F942_6692 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,arg6);
	RTLIU(9);
	
	RTEAA("make", 941, Current, 3, 6, 12759);
	RTGC;
	RTHOOK(1);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(arg2))-563])(arg2);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {590,912,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 590, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F591_3382(RTCW(loc1), NULL, ((EIF_INTEGER_32) 1L), loc3);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2544[Dtype(RTCW(arg2))-563])(arg2);
	RTHOOK(4);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2555[Dtype(RTCW(arg2))-499])(arg2);
		if (tb1) break;
		RTHOOK(6);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2578[Dtype(RTCW(arg2))-499])(arg2);
		F591_3406(RTCW(loc1), tr1, loc2);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2557[Dtype(RTCW(arg2))-499])(arg2);
		RTHOOK(8);
		loc2++;
	}
	RTHOOK(9);
	tr1 = RTLNSMART(eif_new_type(238, 0).id);
	F239_2637(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current);
	F239_2661(RTCW(tr1), loc1);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current);
	F239_2662(RTCW(tr1), arg3);
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current);
	F239_2663(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTHOOK(13);
	if ((EIF_BOOLEAN)(arg4 == NULL)) {
		RTHOOK(14);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2667(RTCW(tr1));
	} else {
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2664(RTCW(tr1), arg4);
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN)(arg5 == NULL)) {
		RTHOOK(17);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2668(RTCW(tr1));
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2670(RTCW(tr1));
	} else {
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2665(RTCW(tr1), arg5);
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2670(RTCW(tr1));
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current);
	F239_2671(RTCW(tr1));
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_17_2_);
	if (tb2) {
		RTHOOK(23);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F239_2658(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(24);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(25);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_17_1_);
	if (tb2) {
		RTHOOK(26);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F239_2659(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(27);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(28);
	if ((EIF_BOOLEAN)(arg6 != NULL)) {
		RTHOOK(29);
		tr1 = RTLNSMART(eif_new_type(563, 0).id);
		F563_2994(RTCW(tr1), arg6);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(30);
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg6;
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.put_string */
void F942_6695 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string", 941, Current, 0, 1, 12762);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F563_3100(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F563_3089(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.terminate */
void F942_6696 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("terminate", 941, Current, 0, 0, 12741);
	RTGC;
	RTHOOK(1);
	F942_6706(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2672(RTCW(tr1));
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current + O5081[Dtype(Current)-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.abort */
void F942_6697 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("abort", 941, Current, 0, 0, 12742);
	RTGC;
	RTHOOK(1);
	F942_6706(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		RTHOOK(3);
		F942_6707(Current);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2672(RTCW(tr1));
		RTHOOK(5);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current + O5081[Dtype(Current)-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.next_result */
EIF_REFERENCE F942_6699 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_result", 941, Current, 1, 0, 12744);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(eif_final_id(Y5086,Y5086_gen_type,Dftype(Current),941).id);
	F1_29(RTCW(Result));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5096[dtype-942])(Current);
	for (;;) {
		RTHOOK(3);
		if (loc1) break;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F563_3100(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F563_3089(RTCW(tr1));
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1270[Dtype(RTCW(Result))-108])(Result, *(EIF_REFERENCE *)(Current + _REFACS_5_));
		RTHOOK(7);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O5082[dtype-941]) || *(EIF_BOOLEAN *)(Current + O5081[dtype-941]))) {
			RTHOOK(8);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5096[dtype-942])(Current);
		}
	}
	RTHOOK(10);
	if (*(EIF_BOOLEAN *)(Current + O5082[dtype-941])) {
		RTHOOK(11);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5084[dtype-942])(Current);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EWEASEL_PROCESS}.savefile_contents */
EIF_REFERENCE F942_6705 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("savefile_contents", 941, Current, 1, 0, 12750);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(563, 0x00).id, 563, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F563_2993(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F909_5744(RTCW(Result), ((EIF_INTEGER_32) 100L));
	for (;;) {
		RTHOOK(3);
		tb1 = F563_3025(RTCW(loc1));
		if (tb1) break;
		RTHOOK(4);
		F563_3140(RTCW(loc1), ((EIF_INTEGER_32) 4096L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		F911_5857(RTCW(Result), tr1);
	}
	RTHOOK(6);
	F563_3078(RTCW(loc1));
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EW_EWEASEL_PROCESS}.close */
void F942_6706 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("close", 941, Current, 0, 0, 12751);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb2 = F563_3050(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F563_3078(RTCW(tr1));
	}
	RTHOOK(3);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb2 = F563_3050(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F563_3078(RTCW(tr1));
	}
	RTHOOK(5);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = F563_3050(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F563_3078(RTCW(tr1));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EW_EWEASEL_PROCESS}.try_to_terminate */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F942_6707 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("try_to_terminate", 941, Current, 1, 0, 12752);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F239_2674(RTCW(tr1));
	}
	RTE_E
	RTXSC;
	RTHOOK(3);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(5);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EW_EWEASEL_PROCESS}.read_chunk */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F942_6708 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("read_chunk", 941, Current, 1, 0, 12753);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F563_3142(RTCW(tr1), ((EIF_INTEGER_32) 4096L));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F563_3025(RTCW(tr1));
		if (tb1) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current + O5082[dtype-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(F122_1514(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(7);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current + O5082[dtype-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		RTHOOK(10);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(11);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EW_EWEASEL_PROCESS}.read_character */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F942_6709 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_CHARACTER_8  EIF_VOLATILE tc1;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("read_character", 941, Current, 1, 0, 12754);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F563_3133(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F563_3025(RTCW(tr1));
		if (tb1) {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current + O5082[dtype-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(tr1)+ _CHROFF_4_0_);
		*(EIF_CHARACTER_8 *)(Current + O5099[dtype-941]) = (EIF_CHARACTER_8) tc1;
	}
	RTE_E
	RTXSC;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(F122_1514(Current) == ((EIF_INTEGER_32) 21L))) {
		RTHOOK(7);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current + O5082[dtype-941]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		*(EIF_CHARACTER_8 *)(Current + O5099[dtype-941]) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
		RTHOOK(10);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(11);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
