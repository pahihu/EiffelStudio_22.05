
#ifndef _C7_ew325_
#define _C7_ew325_

#ifdef __cplusplus
extern "C" {
#endif

extern void F931_6440(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F931_6443(EIF_REFERENCE);
extern void F931_6444(EIF_REFERENCE);
extern void F931_6445(EIF_REFERENCE);
extern void F931_6446(EIF_REFERENCE);
extern void F931_6447(EIF_REFERENCE);
extern void EIF_Minit325(void);

#ifdef __cplusplus
}
#endif

#endif
