/*
 * Code for class EW_TEST_CONTROL_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew326.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_TEST_CONTROL_FILE}.make */
void F932_6448 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("make", 931, Current, 0, 4, 12494);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg3;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_) = (EIF_BOOLEAN) arg4;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.parse_and_execute */
void F932_6453 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("parse_and_execute", 931, Current, 1, 1, 12499);
	RTGC;
	RTHOOK(1);
	F932_6454(Current, arg1);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_)) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_14_2_0_5_0_0_0_0_);
		F925_6290(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		RTHOOK(4);
		F925_6292(RTCW(loc1), arg1);
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
		RTHOOK(6);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_14_0_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) tb1;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(9);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.parse */
void F932_6454 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("parse", 931, Current, 1, 1, 12500);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(563, 0x00).id, 563, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F563_2991(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	RTHOOK(3);
	tb1 = F563_3026(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(659, 0x00).id, 659, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr2 = RTMS32_EX_H("F\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000o\000\000\000u\000\000\000n\000\000\000d\000\000\000:\000\000\000 \000\000\000",16,1014623520);
		tr2 = F915_6076(tr2, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		F659_3584(RTCW(tr1), tr2);
		F932_6458(Current, tr1);
	} else {
		RTHOOK(6);
		tb1 = F563_3033(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(7);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(8);
			tr1 = RTLNS(eif_new_type(659, 0x00).id, 659, _OBJSIZ_4_0_0_1_0_0_0_0_);
			tr2 = RTMS32_EX_H("F\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000a\000\000\000 \000\000\000p\000\000\000l\000\000\000a\000\000\000i\000\000\000n\000\000\000 \000\000\000f\000\000\000i\000\000\000l\000\000\000e\000\000\000:\000\000\000 \000\000\000",23,930742048);
			tr2 = F915_6076(tr2, *(EIF_REFERENCE *)(Current + _REFACS_8_));
			F659_3584(RTCW(tr1), tr2);
			F932_6458(Current, tr1);
		} else {
			RTHOOK(9);
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
			RTHOOK(10);
			F932_6456(Current, loc1);
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.parse_existing_file */
void F932_6456 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLIU(9);
	
	RTEAA("parse_existing_file", 931, Current, 3, 1, 12502);
	RTGC;
	RTHOOK(1);
	F563_3061(RTCW(arg1));
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_4_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {652,55,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F653_3499(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	for (;;) {
		RTHOOK(5);
		tb1 = '\01';
		tb2 = F563_3025(RTCW(arg1));
		if (!tb2) {
			tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_);
		}
		if (tb1) break;
		RTHOOK(6);
		F563_3137(RTCW(arg1));
		RTHOOK(7);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_4_0_0_))++;
		RTHOOK(8);
		tb2 = F563_3025(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc1 = F54_722(Current, tr1);
			RTHOOK(10);
			tr1 = F906_5673(RTCW(loc1));
			F932_6457(Current, tr1);
			RTHOOK(11);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL))) {
				RTHOOK(12);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(tr1))-652])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_9_));
			}
		} else {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb2 = F506_2965(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(14);
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc1 = F54_722(Current, tr1);
				RTHOOK(15);
				tr1 = F906_5673(RTCW(loc1));
				F932_6457(Current, tr1);
				RTHOOK(16);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL))) {
					RTHOOK(17);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2564[Dtype(RTCW(tr1))-652])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_9_));
				}
				RTHOOK(18);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(19);
	F563_3078(RTCW(arg1));
	RTHOOK(20);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_)) {
		RTHOOK(21);
		loc2 = RTLNS(eif_new_type(659, 0x00).id, 659, _OBJSIZ_4_0_0_1_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_4_0_0_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F670_3651(RTCW(tr2), loc1);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
		F659_3585(RTCW(loc2), tr1, ti4_1, loc1, tr2, tr3);
		RTHOOK(22);
		F932_6458(Current, loc2);
		RTHOOK(23);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(24);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_2_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_))) {
			RTHOOK(25);
			loc2 = RTLNS(eif_new_type(659, 0x00).id, 659, _OBJSIZ_4_0_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_4_0_0_);
			tr2 = RTMS32_EX_H("",0,0);
			tr3 = RTMS32_EX_H("",0,0);
			tr4 = RTMS32_EX_H("n\000\000\000o\000\000\000 \000\000\000",3,7237408);
			tr5 = RTOUCR(49,F183_1887, (Current));
			tr4 = F915_6076(tr4, tr5);
			tr5 = F906_5673(RTMS_EX_H(" instruction found",18,930325092));
			tr4 = F915_6076(RTCW(tr4), tr5);
			F659_3585(RTCW(loc2), tr1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), tr2, tr3, tr4);
			RTHOOK(26);
			F932_6458(Current, loc2);
			RTHOOK(27);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTHOOK(28);
			if (loc3) {
				RTHOOK(29);
				loc2 = RTLNS(eif_new_type(659, 0x00).id, 659, _OBJSIZ_4_0_0_1_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_4_0_0_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr2 = F670_3651(RTCW(tr2), loc1);
				tr3 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000n\000\000\000e\000\000\000w\000\000\000l\000\000\000i\000\000\000n\000\000\000e\000\000\000 \000\000\000a\000\000\000t\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000f\000\000\000i\000\000\000l\000\000\000e\000\000\000",30,25744997);
				F659_3585(RTCW(loc2), tr1, ti4_1, loc1, tr2, tr3);
				RTHOOK(30);
				F932_6458(Current, loc2);
				RTHOOK(31);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(32);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.parse_line */
void F932_6457 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTEAA("parse_line", 931, Current, 5, 1, 12503);
	RTGC;
	RTHOOK(1);
	F908_5737(RTCW(arg1));
	RTHOOK(2);
	tb1 = '\01';
	tb2 = F502_2965(RTCW(arg1));
	if (!tb2) {
		tr1 = RTOUCR(50,F932_6459, (Current));
		tb2 = F913_5977(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(5);
		loc1 = F54_711(Current, arg1);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc2 = (EIF_REFERENCE) arg1;
			RTHOOK(8);
			loc3 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F913_5942(RTCW(loc3), ((EIF_INTEGER_32) 0L));
		} else {
			RTHOOK(9);
			loc2 = F915_6104(RTCW(arg1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(10);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc3 = F915_6104(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		}
		RTHOOK(11);
		F915_6098(RTCW(loc2));
		RTHOOK(12);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc2;
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = F686_3784(RTCW(tr1), loc2);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(14);
			loc2 = RTOUCR(51,F183_1892, (Current));
		}
		
		RTHOOK(16);
		tr1 = RTOUCR(49,F183_1887, (Current));
		tb1 = F906_5659(RTCW(loc2), tr1);
		if (tb1) {
			RTHOOK(17);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F686_3782(RTCW(tr1), loc2);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(19);
			loc4 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
		} else {
			RTHOOK(20);
			RTCT0("from_assertion", EX_CHECK);
				RTCF0;
		}
		RTHOOK(21);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc3;
		RTHOOK(22);
		F56_728(RTCW(loc4), Current);
		RTHOOK(23);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R714[Dtype(RTCW(loc4))-56])(loc4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
		RTHOOK(24);
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc4;
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.add_error */
void F932_6458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_error", 931, Current, 0, 1, 12504);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(657, 0).id);
		F658_3579(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F658_3580(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EW_TEST_CONTROL_FILE}.comment_start */

EIF_REFERENCE F932_6459 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (50,RTMS32_EX_H("-\000\000\000-\000\000\000",2,11565));
}

/* {EW_TEST_CONTROL_FILE}.add_errors */
void F932_6460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_errors", 931, Current, 0, 1, 12506);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(657, 0).id);
		F658_3579(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F658_3581(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
