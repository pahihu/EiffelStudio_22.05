
#ifndef _C7_th310_
#define _C7_th310_

#ifdef __cplusplus
extern "C" {
#endif

extern void F916_6109(EIF_REFERENCE);
extern void F916_6110(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F916_6114(EIF_REFERENCE);
extern void F916_6117(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_INTEGER_32 F916_6121(EIF_REFERENCE);
extern void EIF_Minit310(void);
extern void F105_1327(EIF_REFERENCE);
extern EIF_POINTER F105_1330(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
