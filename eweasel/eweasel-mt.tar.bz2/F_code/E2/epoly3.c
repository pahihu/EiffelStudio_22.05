#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O605[8];
void O605_init () {
	O605[0] = 0;
	O605[1] = + _LNGOFF_0_0_0_0_;
	O605[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O605[3] = + _CHROFF_0_0_;
	O605[4] = + _LNGOFF_0_0_0_0_;
	O605[5] = 0;
	O605[6] = + _LNGOFF_1_0_0_0_;
	O605[7] = 0;
}

long O609[3];
void O609_init () {
	O609[0] =  + _REFACS_1_;
	O609[1] = 0;
	O609[2] =  + _REFACS_1_;
}

long O725[739];
void O725_init () {
	O725[0] = + _LNGOFF_6_0_0_0_;
	O725[1] = + _LNGOFF_8_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O725[i] = + _LNGOFF_7_1_0_0_;}
	O725[4] = + _LNGOFF_6_0_0_0_;
	{long i; for (i = 5; i < 7; i++) O725[i] = + _LNGOFF_6_1_0_0_;}
	O725[7] = + _LNGOFF_7_2_0_0_;
	{long i; for (i = 8; i < 10; i++) O725[i] = + _LNGOFF_7_1_0_0_;}
	O725[10] = + _LNGOFF_8_1_0_0_;
	{long i; for (i = 11; i < 14; i++) O725[i] = + _LNGOFF_7_2_0_0_;}
	O725[51] = + _LNGOFF_7_2_0_0_;
	O725[129] = + _LNGOFF_7_4_0_0_;
	O725[609] = + _LNGOFF_7_2_0_0_;
	O725[610] = + _LNGOFF_8_2_0_0_;
	O725[611] = + _LNGOFF_8_1_0_0_;
	O725[612] = + _LNGOFF_7_1_0_0_;
	O725[613] = + _LNGOFF_8_1_0_0_;
	{long i; for (i = 704; i < 706; i++) O725[i] = + _LNGOFF_6_2_0_0_;}
	O725[706] = + _LNGOFF_8_2_0_0_;
	O725[708] = + _LNGOFF_8_2_0_0_;
	{long i; for (i = 709; i < 711; i++) O725[i] = + _LNGOFF_8_1_0_0_;}
	O725[711] = + _LNGOFF_10_2_0_0_;
	O725[712] = + _LNGOFF_6_2_0_0_;
	O725[713] = + _LNGOFF_7_2_0_0_;
	{long i; for (i = 715; i < 724; i++) O725[i] = + _LNGOFF_9_2_0_0_;}
	{long i; for (i = 724; i < 727; i++) O725[i] = + _LNGOFF_7_2_0_0_;}
	{long i; for (i = 730; i < 734; i++) O725[i] = + _LNGOFF_7_2_0_0_;}
	O725[734] = + _LNGOFF_9_2_0_0_;
	O725[735] = + _LNGOFF_10_3_0_0_;
	{long i; for (i = 736; i < 739; i++) O725[i] = + _LNGOFF_7_2_0_0_;}
}

long O766[726];
void O766_init () {
	O766[0] = + _CHROFF_7_0_;
	O766[700] = + _CHROFF_7_0_;
	{long i; for (i = 717; i < 721; i++) O766[i] = + _CHROFF_7_0_;}
	O766[721] = + _CHROFF_9_0_;
	O766[722] = + _CHROFF_10_0_;
	{long i; for (i = 723; i < 726; i++) O766[i] = + _CHROFF_7_0_;}
}

long O767[726];
void O767_init () {
	O767[0] = + _CHROFF_7_1_;
	O767[700] = + _CHROFF_7_1_;
	{long i; for (i = 717; i < 721; i++) O767[i] = + _CHROFF_7_1_;}
	O767[721] = + _CHROFF_9_1_;
	O767[722] = + _CHROFF_10_1_;
	{long i; for (i = 723; i < 726; i++) O767[i] = + _CHROFF_7_1_;}
}

long O865[866];
void O865_init () {
	O865[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 859; i < 861; i++) O865[i] = + _LNGOFF_0_0_0_0_;}
	O865[863] = + _LNGOFF_0_0_0_0_;
	O865[864] = + _LNGOFF_5_1_0_0_;
	O865[865] = + _LNGOFF_2_0_0_0_;
}

EIF_TYPE_INDEX *Y897_gen_type [863];
EIF_TYPE_INDEX Y897 [863];
void Y897_init (void)
{
	egc_routines_types [897] = Y897;
	egc_routines_gen_types [897] = Y897_gen_type;
	egc_routines_offset [897] = 77;
	Y897[0] = 74;
	Y897[862] = 934;
}

long O1111[4];
void O1111_init () {
	O1111[0] = + _CHROFF_2_0_;
	O1111[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1111[i] = + _CHROFF_2_0_;}
}

long O1112[4];
void O1112_init () {
	O1112[0] = + _CHROFF_2_1_;
	O1112[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1112[i] = + _CHROFF_2_1_;}
}

long O1294[2];
void O1294_init () {
	O1294[0] = + _CHROFF_5_0_;
	O1294[1] = + _CHROFF_7_0_;
}

long O1298[2];
void O1298_init () {
	O1298[0] = + _CHROFF_5_1_;
	O1298[1] = + _CHROFF_7_1_;
}

long O1299[2];
void O1299_init () {
	O1299[0] = + _CHROFF_5_2_;
	O1299[1] = + _CHROFF_7_2_;
}

long O1300[2];
void O1300_init () {
	O1300[0] = + _CHROFF_5_3_;
	O1300[1] = + _CHROFF_7_3_;
}

long O1301[2];
void O1301_init () {
	O1301[0] = + _CHROFF_5_4_;
	O1301[1] = + _CHROFF_7_4_;
}

long O1302[2];
void O1302_init () {
	O1302[0] = + _CHROFF_5_5_;
	O1302[1] = + _CHROFF_7_5_;
}

long O1303[2];
void O1303_init () {
	O1303[0] = + _CHROFF_5_6_;
	O1303[1] = + _CHROFF_7_6_;
}

long O1304[2];
void O1304_init () {
	O1304[0] = + _CHROFF_5_7_;
	O1304[1] = + _CHROFF_7_7_;
}

long O1305[2];
void O1305_init () {
	O1305[0] = + _CHROFF_5_8_;
	O1305[1] = + _CHROFF_7_8_;
}

long O1310[2];
void O1310_init () {
	O1310[0] = + _CHROFF_5_9_;
	O1310[1] = + _CHROFF_7_9_;
}

long O1488[601];
void O1488_init () {
	{long i; for (i = 0; i < 3; i++) O1488[i] = + _CHROFF_1_0_;}
	O1488[21] = + _CHROFF_2_0_;
	O1488[600] = + _CHROFF_1_0_;
}

long O1604[3];
void O1604_init () {
	{long i; for (i = 0; i < 2; i++) O1604[i] = + _LNGOFF_1_0_0_0_;}
	O1604[2] = + _LNGOFF_2_0_0_0_;
}

static EIF_TYPE_INDEX Y1916_pgtype0[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype1[] = {699,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype2[] = {700,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype3[] = {701,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype4[] = {702,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype5[] = {703,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype6[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype7[] = {705,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype8[] = {706,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype9[] = {707,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype10[] = {708,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype11[] = {709,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype12[] = {707,830,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype13[] = {707,830,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype14[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype15[] = {699,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype16[] = {700,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype17[] = {701,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype18[] = {702,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype19[] = {703,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype20[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype21[] = {705,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype22[] = {706,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype23[] = {707,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype24[] = {708,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype25[] = {709,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype26[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype27[] = {699,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype28[] = {700,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype29[] = {701,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype30[] = {702,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype31[] = {703,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype32[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype33[] = {705,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype34[] = {706,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype35[] = {707,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype36[] = {708,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype37[] = {709,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype38[] = {702,842,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype39[] = {702,842,0xFFFF};
static EIF_TYPE_INDEX Y1916_pgtype40[] = {699,839,0xFFFF};
EIF_TYPE_INDEX *Y1916_gen_type [723];
EIF_TYPE_INDEX Y1916 [723];
void Y1916_init (void)
{
	egc_routines_types [1916] = Y1916;
	egc_routines_gen_types [1916] = Y1916_gen_type;
	egc_routines_offset [1916] = 192;
	Y1916_gen_type [0] = Y1916_pgtype0;
	Y1916_gen_type [1] = Y1916_pgtype1;
	Y1916_gen_type [2] = Y1916_pgtype2;
	Y1916_gen_type [3] = Y1916_pgtype3;
	Y1916_gen_type [4] = Y1916_pgtype4;
	Y1916_gen_type [5] = Y1916_pgtype5;
	Y1916_gen_type [6] = Y1916_pgtype6;
	Y1916_gen_type [7] = Y1916_pgtype7;
	Y1916_gen_type [8] = Y1916_pgtype8;
	Y1916_gen_type [9] = Y1916_pgtype9;
	Y1916_gen_type [10] = Y1916_pgtype10;
	Y1916_gen_type [11] = Y1916_pgtype11;
	Y1916_gen_type [14] = Y1916_pgtype12;
	Y1916_gen_type [15] = Y1916_pgtype13;
	Y1916_gen_type [398] = Y1916_pgtype14;
	Y1916_gen_type [399] = Y1916_pgtype15;
	Y1916_gen_type [400] = Y1916_pgtype16;
	Y1916_gen_type [401] = Y1916_pgtype17;
	Y1916_gen_type [402] = Y1916_pgtype18;
	Y1916_gen_type [403] = Y1916_pgtype19;
	Y1916_gen_type [404] = Y1916_pgtype20;
	Y1916_gen_type [405] = Y1916_pgtype21;
	Y1916_gen_type [406] = Y1916_pgtype22;
	Y1916_gen_type [407] = Y1916_pgtype23;
	Y1916_gen_type [408] = Y1916_pgtype24;
	Y1916_gen_type [409] = Y1916_pgtype25;
	Y1916_gen_type [480] = Y1916_pgtype26;
	Y1916_gen_type [481] = Y1916_pgtype27;
	Y1916_gen_type [482] = Y1916_pgtype28;
	Y1916_gen_type [483] = Y1916_pgtype29;
	Y1916_gen_type [484] = Y1916_pgtype30;
	Y1916_gen_type [485] = Y1916_pgtype31;
	Y1916_gen_type [486] = Y1916_pgtype32;
	Y1916_gen_type [487] = Y1916_pgtype33;
	Y1916_gen_type [488] = Y1916_pgtype34;
	Y1916_gen_type [489] = Y1916_pgtype35;
	Y1916_gen_type [490] = Y1916_pgtype36;
	Y1916_gen_type [491] = Y1916_pgtype37;
	Y1916_gen_type [718] = Y1916_pgtype38;
	Y1916_gen_type [719] = Y1916_pgtype39;
	Y1916_gen_type [722] = Y1916_pgtype40;
	Y1916[0] = 698;
	Y1916[1] = 699;
	Y1916[2] = 700;
	Y1916[3] = 701;
	Y1916[4] = 702;
	Y1916[5] = 703;
	Y1916[6] = 704;
	Y1916[7] = 705;
	Y1916[8] = 706;
	Y1916[9] = 707;
	Y1916[10] = 708;
	Y1916[11] = 709;
	{long i; for (i = 14; i < 16; i++) Y1916[i] = 707;};
	Y1916[398] = 698;
	Y1916[399] = 699;
	Y1916[400] = 700;
	Y1916[401] = 701;
	Y1916[402] = 702;
	Y1916[403] = 703;
	Y1916[404] = 704;
	Y1916[405] = 705;
	Y1916[406] = 706;
	Y1916[407] = 707;
	Y1916[408] = 708;
	Y1916[409] = 709;
	Y1916[480] = 698;
	Y1916[481] = 699;
	Y1916[482] = 700;
	Y1916[483] = 701;
	Y1916[484] = 702;
	Y1916[485] = 703;
	Y1916[486] = 704;
	Y1916[487] = 705;
	Y1916[488] = 706;
	Y1916[489] = 707;
	Y1916[490] = 708;
	Y1916[491] = 709;
	{long i; for (i = 718; i < 720; i++) Y1916[i] = 702;};
	Y1916[722] = 699;
}

long O2257[681];
void O2257_init () {
	O2257[0] = + _CHROFF_1_0_;
	O2257[326] = + _CHROFF_3_0_;
	O2257[327] = + _CHROFF_4_0_;
	O2257[328] = + _CHROFF_5_0_;
	O2257[680] = + _CHROFF_5_0_;
}

long O2259[681];
void O2259_init () {
	O2259[0] = + _LNGOFF_1_3_2_1_;
	O2259[326] = + _LNGOFF_3_6_2_1_;
	O2259[327] = + _LNGOFF_4_6_2_1_;
	O2259[328] = + _LNGOFF_5_7_2_1_;
	O2259[680] = + _LNGOFF_5_7_2_1_;
}

long O2269[681];
void O2269_init () {
	O2269[0] = + _R32OFF_1_3_2_3_0_;
	O2269[326] = + _R32OFF_3_6_2_4_0_;
	O2269[327] = + _R32OFF_4_6_2_4_0_;
	O2269[328] = + _R32OFF_5_7_2_4_0_;
	O2269[680] = + _R32OFF_5_7_2_4_0_;
}

long O2271[681];
void O2271_init () {
	O2271[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O2271[326] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O2271[327] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O2271[328] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O2271[680] = + _R64OFF_5_7_2_4_1_1_2_0_;
}

long O2507[21];
void O2507_init () {
	{long i; for (i = 0; i < 18; i++) O2507[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 18; i < 21; i++) O2507[i] = + _LNGOFF_2_1_0_0_;}
}

long O2511[21];
void O2511_init () {
	{long i; for (i = 0; i < 18; i++) O2511[i] = + _CHROFF_1_0_;}
	{long i; for (i = 18; i < 21; i++) O2511[i] = + _CHROFF_2_0_;}
}

long O2512[21];
void O2512_init () {
	{long i; for (i = 0; i < 18; i++) O2512[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 18; i < 21; i++) O2512[i] = + _LNGOFF_2_1_0_1_;}
}

long O2513[21];
void O2513_init () {
	{long i; for (i = 0; i < 18; i++) O2513[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 18; i < 21; i++) O2513[i] = + _LNGOFF_2_1_0_2_;}
}

long O2514[21];
void O2514_init () {
	{long i; for (i = 0; i < 18; i++) O2514[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 18; i < 21; i++) O2514[i] = + _LNGOFF_2_1_0_3_;}
}

long O2515[21];
void O2515_init () {
	{long i; for (i = 0; i < 18; i++) O2515[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 18; i < 21; i++) O2515[i] = + _LNGOFF_2_1_0_4_;}
}

long O2536[562];
void O2536_init () {
	{long i; for (i = 0; i < 207; i++) O2536[i] = + _CHROFF_0_0_;}
	O2536[207] = + _CHROFF_3_2_;
	O2536[208] = + _CHROFF_4_2_;
	O2536[209] = + _CHROFF_5_2_;
	{long i; for (i = 222; i < 235; i++) O2536[i] = + _CHROFF_0_0_;}
	{long i; for (i = 235; i < 247; i++) O2536[i] = + _CHROFF_1_0_;}
	{long i; for (i = 247; i < 297; i++) O2536[i] = + _CHROFF_0_0_;}
	{long i; for (i = 297; i < 299; i++) O2536[i] = + _CHROFF_2_0_;}
	{long i; for (i = 299; i < 301; i++) O2536[i] = + _CHROFF_4_0_;}
	{long i; for (i = 316; i < 329; i++) O2536[i] = + _CHROFF_1_0_;}
	O2536[330] = + _CHROFF_7_0_;
	O2536[331] = + _CHROFF_5_0_;
	O2536[332] = + _CHROFF_4_0_;
	O2536[333] = + _CHROFF_6_0_;
	O2536[334] = + _CHROFF_4_0_;
	O2536[335] = + _CHROFF_5_0_;
	O2536[336] = + _CHROFF_7_0_;
	O2536[337] = + _CHROFF_5_0_;
	O2536[338] = + _CHROFF_9_0_;
	{long i; for (i = 555; i < 557; i++) O2536[i] = + _CHROFF_1_0_;}
	O2536[559] = + _CHROFF_1_0_;
	O2536[561] = + _CHROFF_5_2_;
}

long O2625[355];
void O2625_init () {
	O2625[0] = + _PTROFF_3_6_2_4_1_0_;
	O2625[1] = + _PTROFF_4_6_2_4_1_0_;
	O2625[2] = + _PTROFF_5_7_2_4_1_0_;
	O2625[354] = + _PTROFF_5_7_2_4_1_0_;
}

long O2764[355];
void O2764_init () {
	O2764[0] = + _LNGOFF_3_6_2_3_;
	O2764[1] = + _LNGOFF_4_6_2_3_;
	O2764[2] = + _LNGOFF_5_7_2_3_;
	O2764[354] = + _LNGOFF_5_7_2_3_;
}

long O2773[355];
void O2773_init () {
	O2773[0] = + _CHROFF_3_3_;
	O2773[1] = + _CHROFF_4_3_;
	O2773[2] = + _CHROFF_5_3_;
	O2773[354] = + _CHROFF_5_3_;
}

long O2905[4];
void O2905_init () {
	{long i; for (i = 0; i < 2; i++) O2905[i] = + _CHROFF_2_1_;}
	{long i; for (i = 2; i < 4; i++) O2905[i] = + _CHROFF_4_1_;}
}

long O2906[4];
void O2906_init () {
	{long i; for (i = 0; i < 2; i++) O2906[i] = + _CHROFF_2_2_;}
	{long i; for (i = 2; i < 4; i++) O2906[i] = + _CHROFF_4_2_;}
}

long O2907[4];
void O2907_init () {
	{long i; for (i = 0; i < 2; i++) O2907[i] = + _LNGOFF_2_3_0_0_;}
	{long i; for (i = 2; i < 4; i++) O2907[i] = + _LNGOFF_4_3_0_0_;}
}

EIF_TYPE_INDEX *Y2992_gen_type [1];
EIF_TYPE_INDEX Y2992 [1];
void Y2992_init (void)
{
	egc_routines_types [2992] = Y2992;
	egc_routines_gen_types [2992] = Y2992_gen_type;
	egc_routines_offset [2992] = 671;
	Y2992[0] = 848;
}

long O3008[256];
void O3008_init () {
	O3008[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 251; i < 253; i++) O3008[i] = + _LNGOFF_0_0_0_0_;}
	O3008[253] = + _LNGOFF_0_0_0_1_;
	O3008[254] = + _LNGOFF_5_1_0_1_;
	O3008[255] = + _LNGOFF_2_0_0_1_;
}


#ifdef __cplusplus
}
#endif
