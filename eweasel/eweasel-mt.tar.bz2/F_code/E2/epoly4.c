#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3022[9];
void O3022_init () {
	O3022[0] = 0;
	O3022[1] = + _LNGOFF_5_3_0_0_;
	O3022[2] = + _LNGOFF_4_3_0_0_;
	O3022[3] = 0;
	O3022[4] = + _LNGOFF_4_3_0_0_;
	O3022[5] = + _PTROFF_5_3_0_7_0_0_;
	O3022[6] = 0;
	O3022[7] = + _LNGOFF_5_4_0_0_;
	O3022[8] = 0;
}

long O3031[9];
void O3031_init () {
	O3031[0] = + _LNGOFF_7_3_0_0_;
	O3031[1] = + _LNGOFF_5_3_0_1_;
	O3031[2] = + _LNGOFF_4_3_0_1_;
	O3031[3] = + _LNGOFF_6_3_0_0_;
	O3031[4] = + _LNGOFF_4_3_0_1_;
	O3031[5] = + _LNGOFF_5_3_0_0_;
	O3031[6] = + _LNGOFF_7_4_0_0_;
	O3031[7] = + _LNGOFF_5_4_0_1_;
	O3031[8] = + _LNGOFF_9_3_0_0_;
}

long O3058[9];
void O3058_init () {
	O3058[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3058[i] = 0;}
	O3058[3] =  + _REFACS_1_;
	{long i; for (i = 4; i < 6; i++) O3058[i] = 0;}
	O3058[6] =  + _REFACS_1_;
	O3058[7] = 0;
	O3058[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3058_pgtype0[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype1[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype2[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype3[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype4[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype5[] = {705,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype6[] = {698,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype7[] = {704,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3058_pgtype8[] = {698,0,0xFFFF};
EIF_TYPE_INDEX *Y3058_gen_type [9];
EIF_TYPE_INDEX Y3058 [9];
void Y3058_init (void)
{
	egc_routines_types [3058] = Y3058;
	egc_routines_gen_types [3058] = Y3058_gen_type;
	egc_routines_offset [3058] = 685;
	Y3058_gen_type [0] = Y3058_pgtype0;
	Y3058_gen_type [1] = Y3058_pgtype1;
	Y3058_gen_type [2] = Y3058_pgtype2;
	Y3058_gen_type [3] = Y3058_pgtype3;
	Y3058_gen_type [4] = Y3058_pgtype4;
	Y3058_gen_type [5] = Y3058_pgtype5;
	Y3058_gen_type [6] = Y3058_pgtype6;
	Y3058_gen_type [7] = Y3058_pgtype7;
	Y3058_gen_type [8] = Y3058_pgtype8;
	Y3058[0] = 698;
	{long i; for (i = 1; i < 3; i++) Y3058[i] = 704;};
	Y3058[3] = 698;
	Y3058[4] = 704;
	Y3058[5] = 705;
	Y3058[6] = 698;
	Y3058[7] = 704;
	Y3058[8] = 698;
}

long O3059[9];
void O3059_init () {
	O3059[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O3059[i] =  + _REFACS_1_;}
	O3059[3] =  + _REFACS_2_;
	{long i; for (i = 4; i < 6; i++) O3059[i] =  + _REFACS_1_;}
	O3059[6] =  + _REFACS_2_;
	O3059[7] =  + _REFACS_1_;
	O3059[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3059_pgtype0[] = {698,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype1[] = {698,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype2[] = {705,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype3[] = {704,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype4[] = {704,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype5[] = {698,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype6[] = {698,905,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype7[] = {698,905,0xFFFF};
static EIF_TYPE_INDEX Y3059_pgtype8[] = {698,910,0xFFFF};
EIF_TYPE_INDEX *Y3059_gen_type [9];
EIF_TYPE_INDEX Y3059 [9];
void Y3059_init (void)
{
	egc_routines_types [3059] = Y3059;
	egc_routines_gen_types [3059] = Y3059_gen_type;
	egc_routines_offset [3059] = 685;
	Y3059_gen_type [0] = Y3059_pgtype0;
	Y3059_gen_type [1] = Y3059_pgtype1;
	Y3059_gen_type [2] = Y3059_pgtype2;
	Y3059_gen_type [3] = Y3059_pgtype3;
	Y3059_gen_type [4] = Y3059_pgtype4;
	Y3059_gen_type [5] = Y3059_pgtype5;
	Y3059_gen_type [6] = Y3059_pgtype6;
	Y3059_gen_type [7] = Y3059_pgtype7;
	Y3059_gen_type [8] = Y3059_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y3059[i] = 698;};
	Y3059[2] = 705;
	{long i; for (i = 3; i < 5; i++) Y3059[i] = 704;};
	{long i; for (i = 5; i < 9; i++) Y3059[i] = 698;};
}

long O3060[9];
void O3060_init () {
	O3060[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O3060[i] =  + _REFACS_2_;}
	O3060[3] =  + _REFACS_3_;
	{long i; for (i = 4; i < 6; i++) O3060[i] =  + _REFACS_2_;}
	O3060[6] =  + _REFACS_3_;
	O3060[7] =  + _REFACS_2_;
	O3060[8] =  + _REFACS_3_;
}

long O3061[9];
void O3061_init () {
	O3061[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O3061[i] =  + _REFACS_3_;}
	O3061[3] =  + _REFACS_4_;
	{long i; for (i = 4; i < 6; i++) O3061[i] =  + _REFACS_3_;}
	O3061[6] =  + _REFACS_4_;
	O3061[7] =  + _REFACS_3_;
	O3061[8] =  + _REFACS_4_;
}

long O3062[9];
void O3062_init () {
	O3062[0] = + _LNGOFF_7_3_0_1_;
	O3062[1] = + _LNGOFF_5_3_0_2_;
	O3062[2] = + _LNGOFF_4_3_0_2_;
	O3062[3] = + _LNGOFF_6_3_0_1_;
	O3062[4] = + _LNGOFF_4_3_0_2_;
	O3062[5] = + _LNGOFF_5_3_0_1_;
	O3062[6] = + _LNGOFF_7_4_0_1_;
	O3062[7] = + _LNGOFF_5_4_0_2_;
	O3062[8] = + _LNGOFF_9_3_0_1_;
}

long O3063[9];
void O3063_init () {
	O3063[0] = + _CHROFF_7_2_;
	O3063[1] = + _CHROFF_5_2_;
	O3063[2] = + _CHROFF_4_2_;
	O3063[3] = + _CHROFF_6_2_;
	O3063[4] = + _CHROFF_4_2_;
	O3063[5] = + _CHROFF_5_2_;
	O3063[6] = + _CHROFF_7_2_;
	O3063[7] = + _CHROFF_5_2_;
	O3063[8] = + _CHROFF_9_2_;
}

long O3064[9];
void O3064_init () {
	O3064[0] = + _LNGOFF_7_3_0_2_;
	O3064[1] = + _LNGOFF_5_3_0_3_;
	O3064[2] = + _LNGOFF_4_3_0_3_;
	O3064[3] = + _LNGOFF_6_3_0_2_;
	O3064[4] = + _LNGOFF_4_3_0_3_;
	O3064[5] = + _LNGOFF_5_3_0_2_;
	O3064[6] = + _LNGOFF_7_4_0_2_;
	O3064[7] = + _LNGOFF_5_4_0_3_;
	O3064[8] = + _LNGOFF_9_3_0_2_;
}

long O3067[9];
void O3067_init () {
	O3067[0] = + _LNGOFF_7_3_0_3_;
	O3067[1] = + _LNGOFF_5_3_0_4_;
	O3067[2] = + _LNGOFF_4_3_0_4_;
	O3067[3] = + _LNGOFF_6_3_0_3_;
	O3067[4] = + _LNGOFF_4_3_0_4_;
	O3067[5] = + _LNGOFF_5_3_0_3_;
	O3067[6] = + _LNGOFF_7_4_0_3_;
	O3067[7] = + _LNGOFF_5_4_0_4_;
	O3067[8] = + _LNGOFF_9_3_0_3_;
}

long O3068[9];
void O3068_init () {
	O3068[0] = + _LNGOFF_7_3_0_4_;
	O3068[1] = + _LNGOFF_5_3_0_5_;
	O3068[2] = + _LNGOFF_4_3_0_5_;
	O3068[3] = + _LNGOFF_6_3_0_4_;
	O3068[4] = + _LNGOFF_4_3_0_5_;
	O3068[5] = + _LNGOFF_5_3_0_4_;
	O3068[6] = + _LNGOFF_7_4_0_4_;
	O3068[7] = + _LNGOFF_5_4_0_5_;
	O3068[8] = + _LNGOFF_9_3_0_4_;
}

long O3072[9];
void O3072_init () {
	O3072[0] = + _LNGOFF_7_3_0_5_;
	O3072[1] = + _LNGOFF_5_3_0_6_;
	O3072[2] = + _LNGOFF_4_3_0_6_;
	O3072[3] = + _LNGOFF_6_3_0_5_;
	O3072[4] = + _LNGOFF_4_3_0_6_;
	O3072[5] = + _LNGOFF_5_3_0_5_;
	O3072[6] = + _LNGOFF_7_4_0_5_;
	O3072[7] = + _LNGOFF_5_4_0_6_;
	O3072[8] = + _LNGOFF_9_3_0_5_;
}

long O3073[9];
void O3073_init () {
	O3073[0] =  + _REFACS_5_;
	O3073[1] = + _LNGOFF_5_3_0_7_;
	O3073[2] = + _LNGOFF_4_3_0_7_;
	O3073[3] =  + _REFACS_5_;
	O3073[4] = + _LNGOFF_4_3_0_7_;
	O3073[5] = + _PTROFF_5_3_0_7_0_1_;
	O3073[6] =  + _REFACS_5_;
	O3073[7] = + _LNGOFF_5_4_0_7_;
	O3073[8] =  + _REFACS_5_;
}

long O3074[9];
void O3074_init () {
	O3074[0] =  + _REFACS_6_;
	O3074[1] =  + _REFACS_4_;
	O3074[2] = + _PTROFF_4_3_0_9_0_0_;
	O3074[3] = + _LNGOFF_6_3_0_6_;
	O3074[4] = + _LNGOFF_4_3_0_8_;
	O3074[5] =  + _REFACS_4_;
	O3074[6] =  + _REFACS_6_;
	O3074[7] =  + _REFACS_4_;
	O3074[8] =  + _REFACS_6_;
}

long O3108[9];
void O3108_init () {
	O3108[0] = + _LNGOFF_7_3_0_6_;
	O3108[1] = + _LNGOFF_5_3_0_8_;
	O3108[2] = + _LNGOFF_4_3_0_8_;
	O3108[3] = + _LNGOFF_6_3_0_7_;
	O3108[4] = + _LNGOFF_4_3_0_9_;
	O3108[5] = + _LNGOFF_5_3_0_6_;
	O3108[6] = + _LNGOFF_7_4_0_6_;
	O3108[7] = + _LNGOFF_5_4_0_8_;
	O3108[8] = + _LNGOFF_9_3_0_6_;
}

long O3111[2];
void O3111_init () {
	O3111[0] = + _CHROFF_7_3_;
	O3111[1] = + _CHROFF_5_3_;
}

long O4370[10];
void O4370_init () {
	{long i; for (i = 0; i < 3; i++) O4370[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O4370[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O4370[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O4370[i] = + _LNGOFF_1_0_0_0_;}
	O4370[9] = + _LNGOFF_1_1_0_0_;
}

long O4371[10];
void O4371_init () {
	{long i; for (i = 0; i < 3; i++) O4371[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O4371[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O4371[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O4371[i] = + _LNGOFF_1_0_0_1_;}
	O4371[9] = + _LNGOFF_1_1_0_1_;
}

long O4440[4];
void O4440_init () {
	{long i; for (i = 0; i < 2; i++) O4440[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4440[i] = + _LNGOFF_1_1_0_2_;}
}

long O4528[3];
void O4528_init () {
	{long i; for (i = 0; i < 2; i++) O4528[i] = + _LNGOFF_1_0_0_2_;}
	O4528[2] = + _LNGOFF_1_1_0_2_;
}

long O5081[5];
void O5081_init () {
	{long i; for (i = 0; i < 3; i++) O5081[i] = + _CHROFF_6_1_;}
	{long i; for (i = 3; i < 5; i++) O5081[i] = + _CHROFF_7_1_;}
}

long O5082[5];
void O5082_init () {
	{long i; for (i = 0; i < 3; i++) O5082[i] = + _CHROFF_6_2_;}
	{long i; for (i = 3; i < 5; i++) O5082[i] = + _CHROFF_7_2_;}
}

long O5099[5];
void O5099_init () {
	{long i; for (i = 0; i < 3; i++) O5099[i] = + _CHROFF_6_0_;}
	{long i; for (i = 3; i < 5; i++) O5099[i] = + _CHROFF_7_0_;}
}


#ifdef __cplusplus
}
#endif
