#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2574[322])();
void R2574_init () {
	R2574[0] = (char *(*)()) F591_3406_2574_9;
	R2574[1] = (char *(*)()) F592_3406_2574_9;
	R2574[2] = (char *(*)()) F593_3406_2574_9;
	R2574[3] = (char *(*)()) F594_3406_2574_9;
	R2574[4] = (char *(*)()) F595_3406_2574_9;
	R2574[5] = (char *(*)()) F596_3406_2574_9;
	R2574[6] = (char *(*)()) F597_3406_2574_9;
	R2574[7] = (char *(*)()) F598_3406_2574_9;
	R2574[8] = (char *(*)()) F599_3406_2574_9;
	R2574[9] = (char *(*)()) F600_3406_2574_9;
	R2574[10] = (char *(*)()) F601_3406_2574_9;
	R2574[11] = (char *(*)()) F602_3406_2574_9;
	R2574[95] = (char *(*)()) F686_3822;
	R2574[96] = (char *(*)()) F687_3822_2574_9;
	R2574[97] = (char *(*)()) F688_3822_2574_9;
	R2574[98] = (char *(*)()) F689_3822_2574_9;
	R2574[99] = (char *(*)()) F690_3822_2574_9;
	R2574[100] = (char *(*)()) F691_3822_2574_9;
	R2574[101] = (char *(*)()) F686_3822;
	R2574[102] = (char *(*)()) F687_3822_2574_9;
	R2574[103] = (char *(*)()) F686_3822;
	{long i; for (i = 320; i < 322; i++) R2574[i] = (char *(*)()) F911_5844_2574_9;}
}
static void F591_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F591_3406(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F592_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F592_3406(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F593_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F593_3406(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F594_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F594_3406(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F595_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F595_3406(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F596_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F596_3406(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F597_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F597_3406(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F598_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F598_3406(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F599_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F599_3406(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F600_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F600_3406(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F601_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F601_3406(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F602_3406_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F602_3406(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F687_3822_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F687_3822(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F688_3822_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F688_3822(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_POINTER *)arg2);
}
static void F689_3822_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F689_3822(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F690_3822_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F690_3822(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F691_3822_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F691_3822(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F911_5844_2574_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F911_5844(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2576_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype32[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype33[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype34[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype35[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype36[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype37[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype38[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype39[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype40[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype41[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype42[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype43[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype44[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype45[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype46[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype47[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype48[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype49[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype50[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype51[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype52[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype53[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype54[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype55[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype56[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype57[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype58[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype59[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype60[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype61[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype62[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype63[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype64[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype65[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype66[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype67[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype68[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype69[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype70[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype71[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype72[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype73[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype74[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype75[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype76[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype77[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype78[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype79[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype80[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype81[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype82[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype83[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype84[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype85[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype86[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype87[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype88[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype89[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype90[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype91[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype92[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype93[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype94[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype95[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype96[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype97[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype98[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype99[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype100[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype101[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype102[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype103[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype104[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype105[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype106[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype107[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype108[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype109[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype110[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype111[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype112[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype113[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype114[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype115[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype116[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype117[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype118[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype119[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype120[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype121[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype122[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype128[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype129[] = {905,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype130[] = {905,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype131[] = {910,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype132[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype133[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2576_pgtype134[] = {848,0xFFFF};
EIF_TYPE_INDEX *Y2576_gen_type [487];
EIF_TYPE_INDEX Y2576 [487];
void Y2576_init (void)
{
	egc_routines_types [2576] = Y2576;
	egc_routines_gen_types [2576] = Y2576_gen_type;
	egc_routines_offset [2576] = 428;
	Y2576_gen_type [0] = Y2576_pgtype0;
	Y2576_gen_type [1] = Y2576_pgtype1;
	Y2576_gen_type [2] = Y2576_pgtype2;
	Y2576_gen_type [3] = Y2576_pgtype3;
	Y2576_gen_type [4] = Y2576_pgtype4;
	Y2576_gen_type [5] = Y2576_pgtype5;
	Y2576_gen_type [6] = Y2576_pgtype6;
	Y2576_gen_type [7] = Y2576_pgtype7;
	Y2576_gen_type [8] = Y2576_pgtype8;
	Y2576_gen_type [9] = Y2576_pgtype9;
	Y2576_gen_type [10] = Y2576_pgtype10;
	Y2576_gen_type [11] = Y2576_pgtype11;
	Y2576_gen_type [12] = Y2576_pgtype12;
	Y2576_gen_type [13] = Y2576_pgtype13;
	Y2576_gen_type [14] = Y2576_pgtype14;
	Y2576_gen_type [15] = Y2576_pgtype15;
	Y2576_gen_type [16] = Y2576_pgtype16;
	Y2576_gen_type [17] = Y2576_pgtype17;
	Y2576_gen_type [18] = Y2576_pgtype18;
	Y2576_gen_type [19] = Y2576_pgtype19;
	Y2576_gen_type [20] = Y2576_pgtype20;
	Y2576_gen_type [21] = Y2576_pgtype21;
	Y2576_gen_type [22] = Y2576_pgtype22;
	Y2576_gen_type [23] = Y2576_pgtype23;
	Y2576_gen_type [24] = Y2576_pgtype24;
	Y2576_gen_type [25] = Y2576_pgtype25;
	Y2576_gen_type [26] = Y2576_pgtype26;
	Y2576_gen_type [27] = Y2576_pgtype27;
	Y2576_gen_type [28] = Y2576_pgtype28;
	Y2576_gen_type [29] = Y2576_pgtype29;
	Y2576_gen_type [30] = Y2576_pgtype30;
	Y2576_gen_type [31] = Y2576_pgtype31;
	Y2576_gen_type [149] = Y2576_pgtype32;
	Y2576_gen_type [150] = Y2576_pgtype33;
	Y2576_gen_type [151] = Y2576_pgtype34;
	Y2576_gen_type [152] = Y2576_pgtype35;
	Y2576_gen_type [153] = Y2576_pgtype36;
	Y2576_gen_type [154] = Y2576_pgtype37;
	Y2576_gen_type [155] = Y2576_pgtype38;
	Y2576_gen_type [156] = Y2576_pgtype39;
	Y2576_gen_type [157] = Y2576_pgtype40;
	Y2576_gen_type [158] = Y2576_pgtype41;
	Y2576_gen_type [159] = Y2576_pgtype42;
	Y2576_gen_type [160] = Y2576_pgtype43;
	Y2576_gen_type [161] = Y2576_pgtype44;
	Y2576_gen_type [162] = Y2576_pgtype45;
	Y2576_gen_type [163] = Y2576_pgtype46;
	Y2576_gen_type [164] = Y2576_pgtype47;
	Y2576_gen_type [165] = Y2576_pgtype48;
	Y2576_gen_type [166] = Y2576_pgtype49;
	Y2576_gen_type [167] = Y2576_pgtype50;
	Y2576_gen_type [168] = Y2576_pgtype51;
	Y2576_gen_type [169] = Y2576_pgtype52;
	Y2576_gen_type [170] = Y2576_pgtype53;
	Y2576_gen_type [171] = Y2576_pgtype54;
	Y2576_gen_type [172] = Y2576_pgtype55;
	Y2576_gen_type [173] = Y2576_pgtype56;
	Y2576_gen_type [174] = Y2576_pgtype57;
	Y2576_gen_type [175] = Y2576_pgtype58;
	Y2576_gen_type [176] = Y2576_pgtype59;
	Y2576_gen_type [177] = Y2576_pgtype60;
	Y2576_gen_type [178] = Y2576_pgtype61;
	Y2576_gen_type [179] = Y2576_pgtype62;
	Y2576_gen_type [180] = Y2576_pgtype63;
	Y2576_gen_type [181] = Y2576_pgtype64;
	Y2576_gen_type [182] = Y2576_pgtype65;
	Y2576_gen_type [183] = Y2576_pgtype66;
	Y2576_gen_type [184] = Y2576_pgtype67;
	Y2576_gen_type [185] = Y2576_pgtype68;
	Y2576_gen_type [186] = Y2576_pgtype69;
	Y2576_gen_type [187] = Y2576_pgtype70;
	Y2576_gen_type [188] = Y2576_pgtype71;
	Y2576_gen_type [189] = Y2576_pgtype72;
	Y2576_gen_type [190] = Y2576_pgtype73;
	Y2576_gen_type [191] = Y2576_pgtype74;
	Y2576_gen_type [192] = Y2576_pgtype75;
	Y2576_gen_type [193] = Y2576_pgtype76;
	Y2576_gen_type [194] = Y2576_pgtype77;
	Y2576_gen_type [195] = Y2576_pgtype78;
	Y2576_gen_type [196] = Y2576_pgtype79;
	Y2576_gen_type [197] = Y2576_pgtype80;
	Y2576_gen_type [198] = Y2576_pgtype81;
	Y2576_gen_type [199] = Y2576_pgtype82;
	Y2576_gen_type [200] = Y2576_pgtype83;
	Y2576_gen_type [201] = Y2576_pgtype84;
	Y2576_gen_type [202] = Y2576_pgtype85;
	Y2576_gen_type [203] = Y2576_pgtype86;
	Y2576_gen_type [204] = Y2576_pgtype87;
	Y2576_gen_type [205] = Y2576_pgtype88;
	Y2576_gen_type [206] = Y2576_pgtype89;
	Y2576_gen_type [207] = Y2576_pgtype90;
	Y2576_gen_type [208] = Y2576_pgtype91;
	Y2576_gen_type [209] = Y2576_pgtype92;
	Y2576_gen_type [210] = Y2576_pgtype93;
	Y2576_gen_type [211] = Y2576_pgtype94;
	Y2576_gen_type [212] = Y2576_pgtype95;
	Y2576_gen_type [213] = Y2576_pgtype96;
	Y2576_gen_type [214] = Y2576_pgtype97;
	Y2576_gen_type [215] = Y2576_pgtype98;
	Y2576_gen_type [216] = Y2576_pgtype99;
	Y2576_gen_type [217] = Y2576_pgtype100;
	Y2576_gen_type [218] = Y2576_pgtype101;
	Y2576_gen_type [219] = Y2576_pgtype102;
	Y2576_gen_type [220] = Y2576_pgtype103;
	Y2576_gen_type [221] = Y2576_pgtype104;
	Y2576_gen_type [222] = Y2576_pgtype105;
	Y2576_gen_type [223] = Y2576_pgtype106;
	Y2576_gen_type [224] = Y2576_pgtype107;
	Y2576_gen_type [225] = Y2576_pgtype108;
	Y2576_gen_type [226] = Y2576_pgtype109;
	Y2576_gen_type [227] = Y2576_pgtype110;
	Y2576_gen_type [244] = Y2576_pgtype111;
	Y2576_gen_type [245] = Y2576_pgtype112;
	Y2576_gen_type [246] = Y2576_pgtype113;
	Y2576_gen_type [247] = Y2576_pgtype114;
	Y2576_gen_type [248] = Y2576_pgtype115;
	Y2576_gen_type [249] = Y2576_pgtype116;
	Y2576_gen_type [250] = Y2576_pgtype117;
	Y2576_gen_type [251] = Y2576_pgtype118;
	Y2576_gen_type [252] = Y2576_pgtype119;
	Y2576_gen_type [253] = Y2576_pgtype120;
	Y2576_gen_type [254] = Y2576_pgtype121;
	Y2576_gen_type [255] = Y2576_pgtype122;
	Y2576_gen_type [257] = Y2576_pgtype123;
	Y2576_gen_type [258] = Y2576_pgtype124;
	Y2576_gen_type [259] = Y2576_pgtype125;
	Y2576_gen_type [260] = Y2576_pgtype126;
	Y2576_gen_type [261] = Y2576_pgtype127;
	Y2576_gen_type [262] = Y2576_pgtype128;
	Y2576_gen_type [263] = Y2576_pgtype129;
	Y2576_gen_type [264] = Y2576_pgtype130;
	Y2576_gen_type [265] = Y2576_pgtype131;
	Y2576_gen_type [482] = Y2576_pgtype132;
	Y2576_gen_type [483] = Y2576_pgtype133;
	Y2576_gen_type [486] = Y2576_pgtype134;
	{long i; for (i = 149; i < 228; i++) Y2576[i] = 848;};
	{long i; for (i = 244; i < 256; i++) Y2576[i] = 848;};
	{long i; for (i = 263; i < 265; i++) Y2576[i] = 905;};
	Y2576[265] = 910;
	{long i; for (i = 482; i < 484; i++) Y2576[i] = 848;};
	Y2576[486] = 848;
}

char *(*R2578[418])();
void R2578_init () {
	R2578[0] = (char *(*)()) F499_2936_2578_1;
	{long i; for (i = 64; i < 66; i++) R2578[i] = (char *(*)()) F563_3003_2578_1;}
	R2578[153] = (char *(*)()) F653_3501;
	R2578[154] = (char *(*)()) F654_3501_2578_1;
	R2578[156] = (char *(*)()) F653_3501;
	R2578[173] = (char *(*)()) F673_3697;
	R2578[174] = (char *(*)()) F674_3697_2578_1;
	R2578[175] = (char *(*)()) F675_3697_2578_1;
	R2578[176] = (char *(*)()) F676_3697_2578_1;
	R2578[177] = (char *(*)()) F677_3697_2578_1;
	R2578[178] = (char *(*)()) F678_3697_2578_1;
	R2578[179] = (char *(*)()) F679_3697_2578_1;
	R2578[180] = (char *(*)()) F680_3697_2578_1;
	R2578[181] = (char *(*)()) F681_3697_2578_1;
	R2578[182] = (char *(*)()) F682_3697_2578_1;
	R2578[183] = (char *(*)()) F683_3697_2578_1;
	R2578[184] = (char *(*)()) F684_3697_2578_1;
	R2578[412] = (char *(*)()) F912_5914_2578_1;
	R2578[417] = (char *(*)()) F563_3003_2578_1;
}
static EIF_REFERENCE F499_2936_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_2936(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F563_3003_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F563_3003(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F654_3501_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F654_3501(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3697_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_5914_2578_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F912_5914(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y2578_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2578_pgtype105[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y2578_gen_type [457];
EIF_TYPE_INDEX Y2578 [457];
void Y2578_init (void)
{
	egc_routines_types [2578] = Y2578;
	egc_routines_gen_types [2578] = Y2578_gen_type;
	egc_routines_offset [2578] = 460;
	Y2578_gen_type [0] = Y2578_pgtype0;
	Y2578_gen_type [1] = Y2578_pgtype1;
	Y2578_gen_type [2] = Y2578_pgtype2;
	Y2578_gen_type [3] = Y2578_pgtype3;
	Y2578_gen_type [4] = Y2578_pgtype4;
	Y2578_gen_type [5] = Y2578_pgtype5;
	Y2578_gen_type [6] = Y2578_pgtype6;
	Y2578_gen_type [7] = Y2578_pgtype7;
	Y2578_gen_type [8] = Y2578_pgtype8;
	Y2578_gen_type [9] = Y2578_pgtype9;
	Y2578_gen_type [10] = Y2578_pgtype10;
	Y2578_gen_type [11] = Y2578_pgtype11;
	Y2578_gen_type [12] = Y2578_pgtype12;
	Y2578_gen_type [13] = Y2578_pgtype13;
	Y2578_gen_type [14] = Y2578_pgtype14;
	Y2578_gen_type [15] = Y2578_pgtype15;
	Y2578_gen_type [16] = Y2578_pgtype16;
	Y2578_gen_type [17] = Y2578_pgtype17;
	Y2578_gen_type [18] = Y2578_pgtype18;
	Y2578_gen_type [19] = Y2578_pgtype19;
	Y2578_gen_type [20] = Y2578_pgtype20;
	Y2578_gen_type [21] = Y2578_pgtype21;
	Y2578_gen_type [22] = Y2578_pgtype22;
	Y2578_gen_type [23] = Y2578_pgtype23;
	Y2578_gen_type [38] = Y2578_pgtype24;
	Y2578_gen_type [52] = Y2578_pgtype25;
	Y2578_gen_type [53] = Y2578_pgtype26;
	Y2578_gen_type [90] = Y2578_pgtype27;
	Y2578_gen_type [91] = Y2578_pgtype28;
	Y2578_gen_type [92] = Y2578_pgtype29;
	Y2578_gen_type [93] = Y2578_pgtype30;
	Y2578_gen_type [94] = Y2578_pgtype31;
	Y2578_gen_type [95] = Y2578_pgtype32;
	Y2578_gen_type [96] = Y2578_pgtype33;
	Y2578_gen_type [97] = Y2578_pgtype34;
	Y2578_gen_type [98] = Y2578_pgtype35;
	Y2578_gen_type [99] = Y2578_pgtype36;
	Y2578_gen_type [100] = Y2578_pgtype37;
	Y2578_gen_type [101] = Y2578_pgtype38;
	Y2578_gen_type [142] = Y2578_pgtype39;
	Y2578_gen_type [143] = Y2578_pgtype40;
	Y2578_gen_type [144] = Y2578_pgtype41;
	Y2578_gen_type [145] = Y2578_pgtype42;
	Y2578_gen_type [146] = Y2578_pgtype43;
	Y2578_gen_type [147] = Y2578_pgtype44;
	Y2578_gen_type [148] = Y2578_pgtype45;
	Y2578_gen_type [149] = Y2578_pgtype46;
	Y2578_gen_type [150] = Y2578_pgtype47;
	Y2578_gen_type [151] = Y2578_pgtype48;
	Y2578_gen_type [152] = Y2578_pgtype49;
	Y2578_gen_type [153] = Y2578_pgtype50;
	Y2578_gen_type [154] = Y2578_pgtype51;
	Y2578_gen_type [155] = Y2578_pgtype52;
	Y2578_gen_type [156] = Y2578_pgtype53;
	Y2578_gen_type [157] = Y2578_pgtype54;
	Y2578_gen_type [158] = Y2578_pgtype55;
	Y2578_gen_type [159] = Y2578_pgtype56;
	Y2578_gen_type [160] = Y2578_pgtype57;
	Y2578_gen_type [161] = Y2578_pgtype58;
	Y2578_gen_type [162] = Y2578_pgtype59;
	Y2578_gen_type [163] = Y2578_pgtype60;
	Y2578_gen_type [164] = Y2578_pgtype61;
	Y2578_gen_type [165] = Y2578_pgtype62;
	Y2578_gen_type [166] = Y2578_pgtype63;
	Y2578_gen_type [167] = Y2578_pgtype64;
	Y2578_gen_type [168] = Y2578_pgtype65;
	Y2578_gen_type [169] = Y2578_pgtype66;
	Y2578_gen_type [170] = Y2578_pgtype67;
	Y2578_gen_type [171] = Y2578_pgtype68;
	Y2578_gen_type [172] = Y2578_pgtype69;
	Y2578_gen_type [173] = Y2578_pgtype70;
	Y2578_gen_type [174] = Y2578_pgtype71;
	Y2578_gen_type [175] = Y2578_pgtype72;
	Y2578_gen_type [176] = Y2578_pgtype73;
	Y2578_gen_type [177] = Y2578_pgtype74;
	Y2578_gen_type [178] = Y2578_pgtype75;
	Y2578_gen_type [179] = Y2578_pgtype76;
	Y2578_gen_type [180] = Y2578_pgtype77;
	Y2578_gen_type [181] = Y2578_pgtype78;
	Y2578_gen_type [182] = Y2578_pgtype79;
	Y2578_gen_type [183] = Y2578_pgtype80;
	Y2578_gen_type [184] = Y2578_pgtype81;
	Y2578_gen_type [185] = Y2578_pgtype82;
	Y2578_gen_type [186] = Y2578_pgtype83;
	Y2578_gen_type [187] = Y2578_pgtype84;
	Y2578_gen_type [188] = Y2578_pgtype85;
	Y2578_gen_type [189] = Y2578_pgtype86;
	Y2578_gen_type [190] = Y2578_pgtype87;
	Y2578_gen_type [191] = Y2578_pgtype88;
	Y2578_gen_type [192] = Y2578_pgtype89;
	Y2578_gen_type [193] = Y2578_pgtype90;
	Y2578_gen_type [194] = Y2578_pgtype91;
	Y2578_gen_type [195] = Y2578_pgtype92;
	Y2578_gen_type [211] = Y2578_pgtype93;
	Y2578_gen_type [212] = Y2578_pgtype94;
	Y2578_gen_type [213] = Y2578_pgtype95;
	Y2578_gen_type [214] = Y2578_pgtype96;
	Y2578_gen_type [215] = Y2578_pgtype97;
	Y2578_gen_type [216] = Y2578_pgtype98;
	Y2578_gen_type [217] = Y2578_pgtype99;
	Y2578_gen_type [218] = Y2578_pgtype100;
	Y2578_gen_type [219] = Y2578_pgtype101;
	Y2578_gen_type [220] = Y2578_pgtype102;
	Y2578_gen_type [221] = Y2578_pgtype103;
	Y2578_gen_type [222] = Y2578_pgtype104;
	Y2578_gen_type [223] = Y2578_pgtype105;
	Y2578[39] = 848;
	{long i; for (i = 102; i < 105; i++) Y2578[i] = 842;};
	Y2578[451] = 842;
	Y2578[456] = 842;
}

char *(*R2584[32])();
void R2584_init () {
	R2584[0] = (char *(*)()) F653_3505;
	R2584[1] = (char *(*)()) F654_3505;
	R2584[3] = (char *(*)()) F655_3548;
	R2584[20] = (char *(*)()) F673_3703;
	R2584[21] = (char *(*)()) F674_3703;
	R2584[22] = (char *(*)()) F675_3703;
	R2584[23] = (char *(*)()) F676_3703;
	R2584[24] = (char *(*)()) F677_3703;
	R2584[25] = (char *(*)()) F678_3703;
	R2584[26] = (char *(*)()) F679_3703;
	R2584[27] = (char *(*)()) F680_3703;
	R2584[28] = (char *(*)()) F681_3703;
	R2584[29] = (char *(*)()) F682_3703;
	R2584[30] = (char *(*)()) F683_3703;
	R2584[31] = (char *(*)()) F684_3703;
}

static EIF_TYPE_INDEX Y2584_pgtype0[] = {117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2584_pgtype1[] = {118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2584_pgtype2[] = {119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2584_pgtype3[] = {119,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y2584_gen_type [212];
EIF_TYPE_INDEX Y2584 [212];
void Y2584_init (void)
{
	egc_routines_types [2584] = Y2584;
	egc_routines_gen_types [2584] = Y2584_gen_type;
	egc_routines_offset [2584] = 472;
	Y2584_gen_type [180] = Y2584_pgtype0;
	Y2584_gen_type [181] = Y2584_pgtype1;
	Y2584_gen_type [182] = Y2584_pgtype2;
	Y2584_gen_type [183] = Y2584_pgtype3;
	{long i; for (i = 0; i < 12; i++) Y2584[i] = 114;};
	{long i; for (i = 130; i < 180; i++) Y2584[i] = 114;};
	Y2584[180] = 117;
	Y2584[181] = 118;
	{long i; for (i = 182; i < 184; i++) Y2584[i] = 119;};
	{long i; for (i = 200; i < 212; i++) Y2584[i] = 116;};
}

char *(*R2586[32])();
void R2586_init () {
	R2586[0] = (char *(*)()) F653_3524;
	R2586[1] = (char *(*)()) F654_3524;
	R2586[3] = (char *(*)()) F653_3524;
	R2586[20] = (char *(*)()) F673_3728;
	R2586[21] = (char *(*)()) F674_3728;
	R2586[22] = (char *(*)()) F675_3728;
	R2586[23] = (char *(*)()) F676_3728;
	R2586[24] = (char *(*)()) F677_3728;
	R2586[25] = (char *(*)()) F678_3728;
	R2586[26] = (char *(*)()) F679_3728;
	R2586[27] = (char *(*)()) F680_3728;
	R2586[28] = (char *(*)()) F681_3728;
	R2586[29] = (char *(*)()) F682_3728;
	R2586[30] = (char *(*)()) F683_3728;
	R2586[31] = (char *(*)()) F684_3728;
}

char *(*R2598[354])();
void R2598_init () {
	{long i; for (i = 0; i < 2; i++) R2598[i] = (char *(*)()) F563_3021;}
	R2598[27] = (char *(*)()) F591_3394;
	R2598[28] = (char *(*)()) F592_3394;
	R2598[29] = (char *(*)()) F593_3394;
	R2598[30] = (char *(*)()) F594_3394;
	R2598[31] = (char *(*)()) F595_3394;
	R2598[32] = (char *(*)()) F596_3394;
	R2598[33] = (char *(*)()) F597_3394;
	R2598[34] = (char *(*)()) F598_3394;
	R2598[35] = (char *(*)()) F599_3394;
	R2598[36] = (char *(*)()) F600_3394;
	R2598[37] = (char *(*)()) F601_3394;
	R2598[38] = (char *(*)()) F602_3394;
	R2598[89] = (char *(*)()) F653_3508;
	R2598[90] = (char *(*)()) F654_3508;
	R2598[92] = (char *(*)()) F653_3508;
	R2598[109] = (char *(*)()) F673_3713;
	R2598[110] = (char *(*)()) F674_3713;
	R2598[111] = (char *(*)()) F675_3713;
	R2598[112] = (char *(*)()) F676_3713;
	R2598[113] = (char *(*)()) F677_3713;
	R2598[114] = (char *(*)()) F678_3713;
	R2598[115] = (char *(*)()) F679_3713;
	R2598[116] = (char *(*)()) F680_3713;
	R2598[117] = (char *(*)()) F681_3713;
	R2598[118] = (char *(*)()) F682_3713;
	R2598[119] = (char *(*)()) F683_3713;
	R2598[120] = (char *(*)()) F684_3713;
	R2598[122] = (char *(*)()) F686_3794;
	R2598[123] = (char *(*)()) F687_3794;
	R2598[124] = (char *(*)()) F688_3794;
	R2598[125] = (char *(*)()) F689_3794;
	R2598[126] = (char *(*)()) F690_3794;
	R2598[127] = (char *(*)()) F691_3794;
	R2598[128] = (char *(*)()) F686_3794;
	R2598[129] = (char *(*)()) F687_3794;
	R2598[130] = (char *(*)()) F686_3794;
	{long i; for (i = 347; i < 349; i++) R2598[i] = (char *(*)()) F909_5766;}
	R2598[351] = (char *(*)()) F913_5963;
	R2598[353] = (char *(*)()) F917_6137;
}

char *(*R2601[325])();
void R2601_init () {
	R2601[0] = (char *(*)()) F591_3395;
	R2601[1] = (char *(*)()) F592_3395;
	R2601[2] = (char *(*)()) F593_3395;
	R2601[3] = (char *(*)()) F594_3395;
	R2601[4] = (char *(*)()) F595_3395;
	R2601[5] = (char *(*)()) F596_3395;
	R2601[6] = (char *(*)()) F597_3395;
	R2601[7] = (char *(*)()) F598_3395;
	R2601[8] = (char *(*)()) F599_3395;
	R2601[9] = (char *(*)()) F600_3395;
	R2601[10] = (char *(*)()) F601_3395;
	R2601[11] = (char *(*)()) F602_3395;
	R2601[82] = (char *(*)()) F673_3714;
	R2601[83] = (char *(*)()) F674_3714;
	R2601[84] = (char *(*)()) F675_3714;
	R2601[85] = (char *(*)()) F676_3714;
	R2601[86] = (char *(*)()) F677_3714;
	R2601[87] = (char *(*)()) F678_3714;
	R2601[88] = (char *(*)()) F679_3714;
	R2601[89] = (char *(*)()) F680_3714;
	R2601[90] = (char *(*)()) F681_3714;
	R2601[91] = (char *(*)()) F682_3714;
	R2601[92] = (char *(*)()) F683_3714;
	R2601[93] = (char *(*)()) F684_3714;
	{long i; for (i = 320; i < 322; i++) R2601[i] = (char *(*)()) F909_5765;}
	R2601[324] = (char *(*)()) F913_5962;
}

char *(*R2605[325])();
void R2605_init () {
	R2605[0] = (char *(*)()) F527_2978;
	R2605[1] = (char *(*)()) F528_2978;
	R2605[2] = (char *(*)()) F529_2978;
	R2605[3] = (char *(*)()) F530_2978;
	R2605[4] = (char *(*)()) F531_2978;
	R2605[5] = (char *(*)()) F532_2978;
	R2605[6] = (char *(*)()) F533_2978;
	R2605[7] = (char *(*)()) F534_2978;
	R2605[8] = (char *(*)()) F535_2978;
	R2605[9] = (char *(*)()) F536_2978;
	R2605[10] = (char *(*)()) F537_2978;
	R2605[11] = (char *(*)()) F538_2978;
	R2605[82] = (char *(*)()) F527_2978;
	R2605[83] = (char *(*)()) F528_2978;
	R2605[84] = (char *(*)()) F529_2978;
	R2605[85] = (char *(*)()) F530_2978;
	R2605[86] = (char *(*)()) F531_2978;
	R2605[87] = (char *(*)()) F532_2978;
	R2605[88] = (char *(*)()) F533_2978;
	R2605[89] = (char *(*)()) F534_2978;
	R2605[90] = (char *(*)()) F535_2978;
	R2605[91] = (char *(*)()) F536_2978;
	R2605[92] = (char *(*)()) F537_2978;
	R2605[93] = (char *(*)()) F538_2978;
	{long i; for (i = 320; i < 322; i++) R2605[i] = (char *(*)()) F531_2978;}
	R2605[324] = (char *(*)()) F528_2978;
}

char *(*R2607[325])();
void R2607_init () {
	R2607[0] = (char *(*)()) F591_3425;
	R2607[1] = (char *(*)()) F592_3425;
	R2607[2] = (char *(*)()) F593_3425;
	R2607[3] = (char *(*)()) F594_3425;
	R2607[4] = (char *(*)()) F595_3425;
	R2607[5] = (char *(*)()) F596_3425;
	R2607[6] = (char *(*)()) F597_3425;
	R2607[7] = (char *(*)()) F598_3425;
	R2607[8] = (char *(*)()) F599_3425;
	R2607[9] = (char *(*)()) F600_3425;
	R2607[10] = (char *(*)()) F601_3425;
	R2607[11] = (char *(*)()) F602_3425;
	R2607[82] = (char *(*)()) F673_3740;
	R2607[83] = (char *(*)()) F674_3740;
	R2607[84] = (char *(*)()) F675_3740;
	R2607[85] = (char *(*)()) F676_3740;
	R2607[86] = (char *(*)()) F677_3740;
	R2607[87] = (char *(*)()) F678_3740;
	R2607[88] = (char *(*)()) F679_3740;
	R2607[89] = (char *(*)()) F680_3740;
	R2607[90] = (char *(*)()) F681_3740;
	R2607[91] = (char *(*)()) F682_3740;
	R2607[92] = (char *(*)()) F683_3740;
	R2607[93] = (char *(*)()) F684_3740;
	{long i; for (i = 320; i < 322; i++) R2607[i] = (char *(*)()) F911_5890;}
	R2607[324] = (char *(*)()) F915_6090;
}

char *(*R2612[354])();
void R2612_init () {
	R2612[0] = (char *(*)()) F563_2991;
	R2612[1] = (char *(*)()) F565_3272;
	R2612[353] = (char *(*)()) F565_3272;
}

char *(*R2637[354])();
void R2637_init () {
	{long i; for (i = 0; i < 2; i++) R2637[i] = (char *(*)()) F563_3025;}
	R2637[353] = (char *(*)()) F917_6135;
}

char *(*R2706[354])();
void R2706_init () {
	R2706[0] = (char *(*)()) F564_3266;
	R2706[1] = (char *(*)()) F563_3149;
	R2706[353] = (char *(*)()) F563_3149;
}

char *(*R2707[354])();
void R2707_init () {
	{long i; for (i = 0; i < 2; i++) R2707[i] = (char *(*)()) F563_3150;}
	R2707[353] = (char *(*)()) F917_6191;
}

char *(*R2722[354])();
void R2722_init () {
	R2722[0] = (char *(*)()) F564_3267;
	R2722[1] = (char *(*)()) F563_3165;
	R2722[353] = (char *(*)()) F563_3165;
}

char *(*R2808[325])();
void R2808_init () {
	R2808[0] = (char *(*)()) F591_3387;
	R2808[1] = (char *(*)()) F592_3387_2808_26;
	R2808[2] = (char *(*)()) F593_3387_2808_26;
	R2808[3] = (char *(*)()) F594_3387_2808_26;
	R2808[4] = (char *(*)()) F595_3387_2808_26;
	R2808[5] = (char *(*)()) F596_3387_2808_26;
	R2808[6] = (char *(*)()) F597_3387_2808_26;
	R2808[7] = (char *(*)()) F598_3387_2808_26;
	R2808[8] = (char *(*)()) F599_3387_2808_26;
	R2808[9] = (char *(*)()) F600_3387_2808_26;
	R2808[10] = (char *(*)()) F601_3387_2808_26;
	R2808[11] = (char *(*)()) F602_3387_2808_26;
	R2808[62] = (char *(*)()) F603_3444;
	R2808[63] = (char *(*)()) F607_3444_2808_26;
	R2808[65] = (char *(*)()) F603_3444;
	R2808[82] = (char *(*)()) F673_3698;
	R2808[83] = (char *(*)()) F674_3698_2808_26;
	R2808[84] = (char *(*)()) F675_3698_2808_26;
	R2808[85] = (char *(*)()) F676_3698_2808_26;
	R2808[86] = (char *(*)()) F677_3698_2808_26;
	R2808[87] = (char *(*)()) F678_3698_2808_26;
	R2808[88] = (char *(*)()) F679_3698_2808_26;
	R2808[89] = (char *(*)()) F680_3698_2808_26;
	R2808[90] = (char *(*)()) F681_3698_2808_26;
	R2808[91] = (char *(*)()) F682_3698_2808_26;
	R2808[92] = (char *(*)()) F683_3698_2808_26;
	R2808[93] = (char *(*)()) F684_3698_2808_26;
	R2808[95] = (char *(*)()) F686_3792;
	R2808[96] = (char *(*)()) F687_3792_2808_26;
	R2808[97] = (char *(*)()) F688_3792_2808_26;
	R2808[98] = (char *(*)()) F689_3792;
	R2808[99] = (char *(*)()) F690_3792_2808_26;
	R2808[100] = (char *(*)()) F691_3792_2808_26;
	R2808[101] = (char *(*)()) F686_3792;
	R2808[102] = (char *(*)()) F687_3792_2808_26;
	R2808[103] = (char *(*)()) F686_3792;
	R2808[108] = (char *(*)()) F699_4008;
	R2808[109] = (char *(*)()) F700_4008_2808_26;
	R2808[110] = (char *(*)()) F701_4008_2808_26;
	R2808[111] = (char *(*)()) F702_4008_2808_26;
	R2808[112] = (char *(*)()) F703_4008_2808_26;
	R2808[113] = (char *(*)()) F704_4008_2808_26;
	R2808[114] = (char *(*)()) F705_4008_2808_26;
	R2808[115] = (char *(*)()) F706_4008_2808_26;
	R2808[116] = (char *(*)()) F707_4008_2808_26;
	R2808[117] = (char *(*)()) F708_4008_2808_26;
	R2808[118] = (char *(*)()) F709_4008_2808_26;
	R2808[119] = (char *(*)()) F710_4008_2808_26;
	R2808[237] = (char *(*)()) F828_4381;
	R2808[319] = (char *(*)()) F910_5801_2808_26;
	{long i; for (i = 320; i < 322; i++) R2808[i] = (char *(*)()) F911_5823_2808_26;}
	R2808[323] = (char *(*)()) F914_6001_2808_26;
	R2808[324] = (char *(*)()) F915_6024_2808_26;
}
static EIF_REFERENCE F592_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F592_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F594_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F595_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F596_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F597_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F598_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F599_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F599_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F600_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F600_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F601_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F601_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F602_3387_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F602_3387(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F607_3444_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F607_3444(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3698_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3698(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3792_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F687_3792(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3792_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F688_3792(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3792_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F690_3792(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3792_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F691_3792(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F700_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F701_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F701_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F702_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F703_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F704_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F705_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F706_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F707_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F708_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F709_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_4008_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F710_4008(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F910_5801_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F910_5801(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F911_5823_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F911_5823(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F914_6001_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F914_6001(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F915_6024_2808_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F915_6024(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R2809[325])();
void R2809_init () {
	R2809[0] = (char *(*)()) F591_3392;
	R2809[1] = (char *(*)()) F592_3392;
	R2809[2] = (char *(*)()) F593_3392;
	R2809[3] = (char *(*)()) F594_3392;
	R2809[4] = (char *(*)()) F595_3392;
	R2809[5] = (char *(*)()) F596_3392;
	R2809[6] = (char *(*)()) F597_3392;
	R2809[7] = (char *(*)()) F598_3392;
	R2809[8] = (char *(*)()) F599_3392;
	R2809[9] = (char *(*)()) F600_3392;
	R2809[10] = (char *(*)()) F601_3392;
	R2809[11] = (char *(*)()) F602_3392;
	R2809[62] = (char *(*)()) F603_3447;
	R2809[63] = (char *(*)()) F607_3447;
	R2809[65] = (char *(*)()) F603_3447;
	R2809[82] = (char *(*)()) F603_3447;
	R2809[83] = (char *(*)()) F604_3447;
	R2809[84] = (char *(*)()) F605_3447;
	R2809[85] = (char *(*)()) F606_3447;
	R2809[86] = (char *(*)()) F608_3447;
	R2809[87] = (char *(*)()) F609_3447;
	R2809[88] = (char *(*)()) F607_3447;
	R2809[89] = (char *(*)()) F610_3447;
	R2809[90] = (char *(*)()) F611_3447;
	R2809[91] = (char *(*)()) F612_3447;
	R2809[92] = (char *(*)()) F613_3447;
	R2809[93] = (char *(*)()) F614_3447;
	R2809[95] = (char *(*)()) F686_3797;
	R2809[96] = (char *(*)()) F687_3797;
	R2809[97] = (char *(*)()) F688_3797;
	R2809[98] = (char *(*)()) F689_3797;
	R2809[99] = (char *(*)()) F690_3797;
	R2809[100] = (char *(*)()) F691_3797;
	R2809[101] = (char *(*)()) F686_3797;
	R2809[102] = (char *(*)()) F687_3797;
	R2809[103] = (char *(*)()) F686_3797;
	R2809[108] = (char *(*)()) F699_4016;
	R2809[109] = (char *(*)()) F700_4016;
	R2809[110] = (char *(*)()) F701_4016;
	R2809[111] = (char *(*)()) F702_4016;
	R2809[112] = (char *(*)()) F703_4016;
	R2809[113] = (char *(*)()) F704_4016;
	R2809[114] = (char *(*)()) F705_4016;
	R2809[115] = (char *(*)()) F706_4016;
	R2809[116] = (char *(*)()) F707_4016;
	R2809[117] = (char *(*)()) F708_4016;
	R2809[118] = (char *(*)()) F709_4016;
	R2809[119] = (char *(*)()) F710_4016;
	R2809[237] = (char *(*)()) F828_4411;
	{long i; for (i = 319; i < 322; i++) R2809[i] = (char *(*)()) F909_5768;}
	{long i; for (i = 323; i < 325; i++) R2809[i] = (char *(*)()) F913_5965;}
}

EIF_TYPE_INDEX *Y2809_gen_type [350];
EIF_TYPE_INDEX Y2809 [350];
void Y2809_init (void)
{
	egc_routines_types [2809] = Y2809;
	egc_routines_gen_types [2809] = Y2809_gen_type;
	egc_routines_offset [2809] = 565;
	{long i; for (i = 0; i < 91; i++) Y2809[i] = 848;};
	{long i; for (i = 107; i < 119; i++) Y2809[i] = 848;};
	{long i; for (i = 120; i < 129; i++) Y2809[i] = 848;};
	{long i; for (i = 133; i < 145; i++) Y2809[i] = 848;};
	Y2809[262] = 848;
	{long i; for (i = 343; i < 350; i++) Y2809[i] = 848;};
}

char *(*R2810[325])();
void R2810_init () {
	R2810[0] = (char *(*)()) F591_3393;
	R2810[1] = (char *(*)()) F592_3393;
	R2810[2] = (char *(*)()) F593_3393;
	R2810[3] = (char *(*)()) F594_3393;
	R2810[4] = (char *(*)()) F595_3393;
	R2810[5] = (char *(*)()) F596_3393;
	R2810[6] = (char *(*)()) F597_3393;
	R2810[7] = (char *(*)()) F598_3393;
	R2810[8] = (char *(*)()) F599_3393;
	R2810[9] = (char *(*)()) F600_3393;
	R2810[10] = (char *(*)()) F601_3393;
	R2810[11] = (char *(*)()) F602_3393;
	R2810[62] = (char *(*)()) F653_3508;
	R2810[63] = (char *(*)()) F654_3508;
	R2810[65] = (char *(*)()) F653_3508;
	R2810[82] = (char *(*)()) F673_3713;
	R2810[83] = (char *(*)()) F674_3713;
	R2810[84] = (char *(*)()) F675_3713;
	R2810[85] = (char *(*)()) F676_3713;
	R2810[86] = (char *(*)()) F677_3713;
	R2810[87] = (char *(*)()) F678_3713;
	R2810[88] = (char *(*)()) F679_3713;
	R2810[89] = (char *(*)()) F680_3713;
	R2810[90] = (char *(*)()) F681_3713;
	R2810[91] = (char *(*)()) F682_3713;
	R2810[92] = (char *(*)()) F683_3713;
	R2810[93] = (char *(*)()) F684_3713;
	R2810[95] = (char *(*)()) F686_3798;
	R2810[96] = (char *(*)()) F687_3798;
	R2810[97] = (char *(*)()) F688_3798;
	R2810[98] = (char *(*)()) F689_3798;
	R2810[99] = (char *(*)()) F690_3798;
	R2810[100] = (char *(*)()) F691_3798;
	R2810[101] = (char *(*)()) F686_3798;
	R2810[102] = (char *(*)()) F687_3798;
	R2810[103] = (char *(*)()) F686_3798;
	R2810[108] = (char *(*)()) F699_4017;
	R2810[109] = (char *(*)()) F700_4017;
	R2810[110] = (char *(*)()) F701_4017;
	R2810[111] = (char *(*)()) F702_4017;
	R2810[112] = (char *(*)()) F703_4017;
	R2810[113] = (char *(*)()) F704_4017;
	R2810[114] = (char *(*)()) F705_4017;
	R2810[115] = (char *(*)()) F706_4017;
	R2810[116] = (char *(*)()) F707_4017;
	R2810[117] = (char *(*)()) F708_4017;
	R2810[118] = (char *(*)()) F709_4017;
	R2810[119] = (char *(*)()) F710_4017;
	R2810[237] = (char *(*)()) F828_4410;
	{long i; for (i = 319; i < 322; i++) R2810[i] = (char *(*)()) F909_5766;}
	{long i; for (i = 323; i < 325; i++) R2810[i] = (char *(*)()) F913_5963;}
}

char *(*R2812[325])();
void R2812_init () {
	R2812[0] = (char *(*)()) F591_3402;
	R2812[1] = (char *(*)()) F592_3402;
	R2812[2] = (char *(*)()) F593_3402;
	R2812[3] = (char *(*)()) F594_3402;
	R2812[4] = (char *(*)()) F595_3402;
	R2812[5] = (char *(*)()) F596_3402;
	R2812[6] = (char *(*)()) F597_3402;
	R2812[7] = (char *(*)()) F598_3402;
	R2812[8] = (char *(*)()) F599_3402;
	R2812[9] = (char *(*)()) F600_3402;
	R2812[10] = (char *(*)()) F601_3402;
	R2812[11] = (char *(*)()) F602_3402;
	R2812[62] = (char *(*)()) F603_3452;
	R2812[63] = (char *(*)()) F607_3452;
	R2812[65] = (char *(*)()) F603_3452;
	R2812[82] = (char *(*)()) F673_3719;
	R2812[83] = (char *(*)()) F674_3719;
	R2812[84] = (char *(*)()) F675_3719;
	R2812[85] = (char *(*)()) F676_3719;
	R2812[86] = (char *(*)()) F677_3719;
	R2812[87] = (char *(*)()) F678_3719;
	R2812[88] = (char *(*)()) F679_3719;
	R2812[89] = (char *(*)()) F680_3719;
	R2812[90] = (char *(*)()) F681_3719;
	R2812[91] = (char *(*)()) F682_3719;
	R2812[92] = (char *(*)()) F683_3719;
	R2812[93] = (char *(*)()) F684_3719;
	R2812[95] = (char *(*)()) F686_3814;
	R2812[96] = (char *(*)()) F687_3814;
	R2812[97] = (char *(*)()) F688_3814;
	R2812[98] = (char *(*)()) F689_3814;
	R2812[99] = (char *(*)()) F690_3814;
	R2812[100] = (char *(*)()) F691_3814;
	R2812[101] = (char *(*)()) F686_3814;
	R2812[102] = (char *(*)()) F687_3814;
	R2812[103] = (char *(*)()) F686_3814;
	R2812[108] = (char *(*)()) F699_4022;
	R2812[109] = (char *(*)()) F700_4022;
	R2812[110] = (char *(*)()) F701_4022;
	R2812[111] = (char *(*)()) F702_4022;
	R2812[112] = (char *(*)()) F703_4022;
	R2812[113] = (char *(*)()) F704_4022;
	R2812[114] = (char *(*)()) F705_4022;
	R2812[115] = (char *(*)()) F706_4022;
	R2812[116] = (char *(*)()) F707_4022;
	R2812[117] = (char *(*)()) F708_4022;
	R2812[118] = (char *(*)()) F709_4022;
	R2812[119] = (char *(*)()) F710_4022;
	R2812[237] = (char *(*)()) F828_4408;
	{long i; for (i = 319; i < 322; i++) R2812[i] = (char *(*)()) F906_5626;}
	{long i; for (i = 323; i < 325; i++) R2812[i] = (char *(*)()) F906_5626;}
}

char *(*R2836[12])();
void R2836_init () {
	R2836[0] = (char *(*)()) F591_3385;
	R2836[1] = (char *(*)()) F592_3385;
	R2836[2] = (char *(*)()) F593_3385;
	R2836[3] = (char *(*)()) F594_3385;
	R2836[4] = (char *(*)()) F595_3385;
	R2836[5] = (char *(*)()) F596_3385;
	R2836[6] = (char *(*)()) F597_3385;
	R2836[7] = (char *(*)()) F598_3385;
	R2836[8] = (char *(*)()) F599_3385;
	R2836[9] = (char *(*)()) F600_3385;
	R2836[10] = (char *(*)()) F601_3385;
	R2836[11] = (char *(*)()) F602_3385;
}

char *(*R2860[12])();
void R2860_init () {
	R2860[0] = (char *(*)()) F591_3427;
	R2860[1] = (char *(*)()) F592_3427_2860_129;
	R2860[2] = (char *(*)()) F593_3427_2860_129;
	R2860[3] = (char *(*)()) F594_3427_2860_129;
	R2860[4] = (char *(*)()) F595_3427_2860_129;
	R2860[5] = (char *(*)()) F596_3427_2860_129;
	R2860[6] = (char *(*)()) F597_3427_2860_129;
	R2860[7] = (char *(*)()) F598_3427_2860_129;
	R2860[8] = (char *(*)()) F599_3427_2860_129;
	R2860[9] = (char *(*)()) F600_3427_2860_129;
	R2860[10] = (char *(*)()) F601_3427_2860_129;
	R2860[11] = (char *(*)()) F602_3427_2860_129;
}
static void F592_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F592_3427(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F593_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F593_3427(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F594_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F594_3427(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F595_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F595_3427(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F596_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F596_3427(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F597_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F597_3427(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F598_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F598_3427(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F599_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F599_3427(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F600_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F600_3427(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F601_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F601_3427(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F602_3427_2860_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F602_3427(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R2867[12])();
void R2867_init () {
	R2867[0] = (char *(*)()) F591_3439;
	R2867[1] = (char *(*)()) F592_3439;
	R2867[2] = (char *(*)()) F593_3439;
	R2867[3] = (char *(*)()) F594_3439;
	R2867[4] = (char *(*)()) F595_3439;
	R2867[5] = (char *(*)()) F596_3439;
	R2867[6] = (char *(*)()) F597_3439;
	R2867[7] = (char *(*)()) F598_3439;
	R2867[8] = (char *(*)()) F599_3439;
	R2867[9] = (char *(*)()) F600_3439;
	R2867[10] = (char *(*)()) F601_3439;
	R2867[11] = (char *(*)()) F602_3439;
}

char *(*R2870[32])();
void R2870_init () {
	R2870[0] = (char *(*)()) F653_3502;
	R2870[1] = (char *(*)()) F654_3502_2870_1;
	R2870[3] = (char *(*)()) F653_3502;
	R2870[20] = (char *(*)()) F673_3700;
	R2870[21] = (char *(*)()) F674_3700_2870_1;
	R2870[22] = (char *(*)()) F675_3700_2870_1;
	R2870[23] = (char *(*)()) F676_3700_2870_1;
	R2870[24] = (char *(*)()) F677_3700_2870_1;
	R2870[25] = (char *(*)()) F678_3700_2870_1;
	R2870[26] = (char *(*)()) F679_3700_2870_1;
	R2870[27] = (char *(*)()) F680_3700_2870_1;
	R2870[28] = (char *(*)()) F681_3700_2870_1;
	R2870[29] = (char *(*)()) F682_3700_2870_1;
	R2870[30] = (char *(*)()) F683_3700_2870_1;
	R2870[31] = (char *(*)()) F684_3700_2870_1;
}
static EIF_REFERENCE F654_3502_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F654_3502(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3700_2870_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3700(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R2871[32])();
void R2871_init () {
	R2871[0] = (char *(*)()) F653_3503;
	R2871[1] = (char *(*)()) F654_3503_2871_1;
	R2871[3] = (char *(*)()) F653_3503;
	R2871[20] = (char *(*)()) F673_3701;
	R2871[21] = (char *(*)()) F674_3701_2871_1;
	R2871[22] = (char *(*)()) F675_3701_2871_1;
	R2871[23] = (char *(*)()) F676_3701_2871_1;
	R2871[24] = (char *(*)()) F677_3701_2871_1;
	R2871[25] = (char *(*)()) F678_3701_2871_1;
	R2871[26] = (char *(*)()) F679_3701_2871_1;
	R2871[27] = (char *(*)()) F680_3701_2871_1;
	R2871[28] = (char *(*)()) F681_3701_2871_1;
	R2871[29] = (char *(*)()) F682_3701_2871_1;
	R2871[30] = (char *(*)()) F683_3701_2871_1;
	R2871[31] = (char *(*)()) F684_3701_2871_1;
}
static EIF_REFERENCE F654_3503_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F654_3503(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3701_2871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R2872[4])();
void R2872_init () {
	R2872[0] = (char *(*)()) F653_3522;
	R2872[1] = (char *(*)()) F654_3522;
	R2872[3] = (char *(*)()) F655_3554;
}

char *(*R2873[32])();
void R2873_init () {
	R2873[0] = (char *(*)()) F653_3523;
	R2873[1] = (char *(*)()) F654_3523;
	R2873[3] = (char *(*)()) F653_3523;
	R2873[20] = (char *(*)()) F673_3727;
	R2873[21] = (char *(*)()) F674_3727;
	R2873[22] = (char *(*)()) F675_3727;
	R2873[23] = (char *(*)()) F676_3727;
	R2873[24] = (char *(*)()) F677_3727;
	R2873[25] = (char *(*)()) F678_3727;
	R2873[26] = (char *(*)()) F679_3727;
	R2873[27] = (char *(*)()) F680_3727;
	R2873[28] = (char *(*)()) F681_3727;
	R2873[29] = (char *(*)()) F682_3727;
	R2873[30] = (char *(*)()) F683_3727;
	R2873[31] = (char *(*)()) F684_3727;
}

char *(*R2875[32])();
void R2875_init () {
	R2875[0] = (char *(*)()) F653_3514;
	R2875[1] = (char *(*)()) F654_3514;
	R2875[3] = (char *(*)()) F655_3550;
	R2875[20] = (char *(*)()) F603_3454;
	R2875[21] = (char *(*)()) F604_3454;
	R2875[22] = (char *(*)()) F605_3454;
	R2875[23] = (char *(*)()) F606_3454;
	R2875[24] = (char *(*)()) F608_3454;
	R2875[25] = (char *(*)()) F609_3454;
	R2875[26] = (char *(*)()) F607_3454;
	R2875[27] = (char *(*)()) F610_3454;
	R2875[28] = (char *(*)()) F611_3454;
	R2875[29] = (char *(*)()) F612_3454;
	R2875[30] = (char *(*)()) F613_3454;
	R2875[31] = (char *(*)()) F614_3454;
}

char *(*R2884[32])();
void R2884_init () {
	R2884[0] = (char *(*)()) F653_3531;
	R2884[1] = (char *(*)()) F654_3531;
	R2884[3] = (char *(*)()) F655_3560;
	R2884[20] = (char *(*)()) F673_3738;
	R2884[21] = (char *(*)()) F674_3738;
	R2884[22] = (char *(*)()) F675_3738;
	R2884[23] = (char *(*)()) F676_3738;
	R2884[24] = (char *(*)()) F677_3738;
	R2884[25] = (char *(*)()) F678_3738;
	R2884[26] = (char *(*)()) F679_3738;
	R2884[27] = (char *(*)()) F680_3738;
	R2884[28] = (char *(*)()) F681_3738;
	R2884[29] = (char *(*)()) F682_3738;
	R2884[30] = (char *(*)()) F683_3738;
	R2884[31] = (char *(*)()) F684_3738;
}

char *(*R2898[4])();
void R2898_init () {
	R2898[0] = (char *(*)()) F653_3538;
	R2898[1] = (char *(*)()) F654_3538_2898_5;
	R2898[3] = (char *(*)()) F655_3569;
}
static EIF_REFERENCE F654_3538_2898_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F654_3538(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2902[4])();
void R2902_init () {
	R2902[0] = (char *(*)()) F653_3542;
	R2902[1] = (char *(*)()) F654_3542;
	R2902[3] = (char *(*)()) F655_3546;
}

char *(*R2904[4])();
void R2904_init () {
	R2904[0] = (char *(*)()) F653_3544;
	R2904[1] = (char *(*)()) F654_3544;
	R2904[3] = (char *(*)()) F653_3544;
}

char *(*R2924[2])();
void R2924_init () {
	R2924[0] = (char *(*)()) F660_3594;
	R2924[1] = (char *(*)()) F661_3595;
}

char *(*R2981[268])();
void R2981_init () {
	R2981[0] = (char *(*)()) F673_3753;
	R2981[1] = (char *(*)()) F674_3753;
	R2981[2] = (char *(*)()) F675_3753;
	R2981[3] = (char *(*)()) F676_3753;
	R2981[4] = (char *(*)()) F677_3753;
	R2981[5] = (char *(*)()) F678_3753;
	R2981[6] = (char *(*)()) F679_3753;
	R2981[7] = (char *(*)()) F680_3753;
	R2981[8] = (char *(*)()) F681_3753;
	R2981[9] = (char *(*)()) F682_3753;
	R2981[10] = (char *(*)()) F683_3753;
	R2981[11] = (char *(*)()) F684_3753;
	R2981[13] = (char *(*)()) F686_3835;
	R2981[14] = (char *(*)()) F687_3835;
	R2981[15] = (char *(*)()) F688_3835;
	R2981[16] = (char *(*)()) F689_3835;
	R2981[17] = (char *(*)()) F690_3835;
	R2981[18] = (char *(*)()) F691_3835;
	R2981[19] = (char *(*)()) F686_3835;
	R2981[20] = (char *(*)()) F687_3835;
	R2981[21] = (char *(*)()) F686_3835;
	R2981[155] = (char *(*)()) F828_4489;
	{long i; for (i = 238; i < 240; i++) R2981[i] = (char *(*)()) F911_5907;}
	R2981[241] = (char *(*)()) F914_6017;
	R2981[242] = (char *(*)()) F915_6108;
	R2981[264] = (char *(*)()) F685_3767;
	R2981[267] = (char *(*)()) F685_3767;
}

char *(*R2997[12])();
void R2997_init () {
	R2997[0] = (char *(*)()) F673_3696;
	R2997[1] = (char *(*)()) F674_3696;
	R2997[2] = (char *(*)()) F675_3696;
	R2997[3] = (char *(*)()) F676_3696;
	R2997[4] = (char *(*)()) F677_3696;
	R2997[5] = (char *(*)()) F678_3696;
	R2997[6] = (char *(*)()) F679_3696;
	R2997[7] = (char *(*)()) F680_3696;
	R2997[8] = (char *(*)()) F681_3696;
	R2997[9] = (char *(*)()) F682_3696;
	R2997[10] = (char *(*)()) F683_3696;
	R2997[11] = (char *(*)()) F684_3696;
}

char *(*R3001[12])();
void R3001_init () {
	R3001[0] = (char *(*)()) F673_3715;
	R3001[1] = (char *(*)()) F674_3715;
	R3001[2] = (char *(*)()) F675_3715;
	R3001[3] = (char *(*)()) F676_3715;
	R3001[4] = (char *(*)()) F677_3715;
	R3001[5] = (char *(*)()) F678_3715;
	R3001[6] = (char *(*)()) F679_3715;
	R3001[7] = (char *(*)()) F680_3715;
	R3001[8] = (char *(*)()) F681_3715;
	R3001[9] = (char *(*)()) F682_3715;
	R3001[10] = (char *(*)()) F683_3715;
	R3001[11] = (char *(*)()) F684_3715;
}

char *(*R3018[9])();
void R3018_init () {
	R3018[0] = (char *(*)()) F686_3776;
	R3018[1] = (char *(*)()) F687_3776;
	R3018[2] = (char *(*)()) F688_3776;
	R3018[3] = (char *(*)()) F689_3776;
	R3018[4] = (char *(*)()) F690_3776;
	R3018[5] = (char *(*)()) F691_3776;
	R3018[6] = (char *(*)()) F686_3776;
	R3018[7] = (char *(*)()) F687_3776;
	R3018[8] = (char *(*)()) F686_3776;
}

char *(*R3021[9])();
void R3021_init () {
	R3021[0] = (char *(*)()) F686_3779;
	R3021[1] = (char *(*)()) F687_3779;
	R3021[2] = (char *(*)()) F688_3779;
	R3021[3] = (char *(*)()) F689_3779;
	R3021[4] = (char *(*)()) F690_3779;
	R3021[5] = (char *(*)()) F691_3779;
	R3021[6] = (char *(*)()) F686_3779;
	R3021[7] = (char *(*)()) F687_3779;
	R3021[8] = (char *(*)()) F686_3779;
}

char *(*R3022[9])();
void R3022_init () {
	R3022[0] = (char *(*)()) F686_3780;
	R3022[1] = (char *(*)()) F687_3780_3022_1;
	R3022[2] = (char *(*)()) F688_3780_3022_1;
	R3022[3] = (char *(*)()) F689_3780;
	R3022[4] = (char *(*)()) F690_3780_3022_1;
	R3022[5] = (char *(*)()) F691_3780_3022_1;
	R3022[6] = (char *(*)()) F686_3780;
	R3022[7] = (char *(*)()) F687_3780_3022_1;
	R3022[8] = (char *(*)()) F686_3780;
}
static EIF_REFERENCE F687_3780_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F687_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3780_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F688_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3780_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F690_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3780_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F691_3780(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3030[9])();
void R3030_init () {
	R3030[0] = (char *(*)()) F686_3793;
	R3030[1] = (char *(*)()) F687_3793;
	R3030[2] = (char *(*)()) F688_3793_3030_19;
	R3030[3] = (char *(*)()) F689_3793_3030_19;
	R3030[4] = (char *(*)()) F690_3793_3030_19;
	R3030[5] = (char *(*)()) F691_3793;
	R3030[6] = (char *(*)()) F692_3890;
	R3030[7] = (char *(*)()) F693_3890;
	R3030[8] = (char *(*)()) F686_3793;
}
static EIF_INTEGER_32 F688_3793_3030_19 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F688_3793(Current, *(EIF_POINTER *)arg1);
}
static EIF_INTEGER_32 F689_3793_3030_19 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F689_3793(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F690_3793_3030_19 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F690_3793(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3032[9])();
void R3032_init () {
	R3032[0] = (char *(*)()) F686_3800;
	R3032[1] = (char *(*)()) F687_3800;
	R3032[2] = (char *(*)()) F688_3800_3032_3;
	R3032[3] = (char *(*)()) F689_3800_3032_3;
	R3032[4] = (char *(*)()) F690_3800_3032_3;
	R3032[5] = (char *(*)()) F691_3800;
	R3032[6] = (char *(*)()) F692_3892;
	R3032[7] = (char *(*)()) F693_3892;
	R3032[8] = (char *(*)()) F686_3800;
}
static EIF_BOOLEAN F688_3800_3032_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F688_3800(Current, *(EIF_POINTER *)arg1, *(EIF_POINTER *)arg2);
}
static EIF_BOOLEAN F689_3800_3032_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F689_3800(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F690_3800_3032_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F690_3800(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3038[9])();
void R3038_init () {
	R3038[0] = (char *(*)()) F686_3808;
	R3038[1] = (char *(*)()) F687_3808;
	R3038[2] = (char *(*)()) F688_3808;
	R3038[3] = (char *(*)()) F689_3808;
	R3038[4] = (char *(*)()) F690_3808;
	R3038[5] = (char *(*)()) F691_3808;
	R3038[6] = (char *(*)()) F686_3808;
	R3038[7] = (char *(*)()) F687_3808;
	R3038[8] = (char *(*)()) F686_3808;
}

char *(*R3039[9])();
void R3039_init () {
	R3039[0] = (char *(*)()) F686_3809;
	R3039[1] = (char *(*)()) F687_3809;
	R3039[2] = (char *(*)()) F688_3809;
	R3039[3] = (char *(*)()) F689_3809;
	R3039[4] = (char *(*)()) F690_3809;
	R3039[5] = (char *(*)()) F691_3809;
	R3039[6] = (char *(*)()) F686_3809;
	R3039[7] = (char *(*)()) F687_3809;
	R3039[8] = (char *(*)()) F686_3809;
}

char *(*R3045[9])();
void R3045_init () {
	R3045[0] = (char *(*)()) F686_3816;
	R3045[1] = (char *(*)()) F687_3816;
	R3045[2] = (char *(*)()) F688_3816;
	R3045[3] = (char *(*)()) F689_3816;
	R3045[4] = (char *(*)()) F690_3816;
	R3045[5] = (char *(*)()) F691_3816;
	R3045[6] = (char *(*)()) F686_3816;
	R3045[7] = (char *(*)()) F687_3816;
	R3045[8] = (char *(*)()) F686_3816;
}

char *(*R3047[9])();
void R3047_init () {
	R3047[0] = (char *(*)()) F686_3818;
	R3047[1] = (char *(*)()) F687_3818;
	R3047[2] = (char *(*)()) F688_3818_3047_4;
	R3047[3] = (char *(*)()) F689_3818_3047_4;
	R3047[4] = (char *(*)()) F690_3818_3047_4;
	R3047[5] = (char *(*)()) F691_3818;
	R3047[6] = (char *(*)()) F686_3818;
	R3047[7] = (char *(*)()) F687_3818;
	R3047[8] = (char *(*)()) F686_3818;
}
static void F688_3818_3047_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F688_3818(Current, *(EIF_POINTER *)arg1);
}
static void F689_3818_3047_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F689_3818(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F690_3818_3047_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_3818(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3049[9])();
void R3049_init () {
	R3049[0] = (char *(*)()) F686_3820;
	R3049[1] = (char *(*)()) F687_3820;
	R3049[2] = (char *(*)()) F688_3820;
	R3049[3] = (char *(*)()) F689_3820;
	R3049[4] = (char *(*)()) F690_3820;
	R3049[5] = (char *(*)()) F691_3820;
	R3049[6] = (char *(*)()) F686_3820;
	R3049[7] = (char *(*)()) F687_3820;
	R3049[8] = (char *(*)()) F686_3820;
}

char *(*R3050[9])();
void R3050_init () {
	R3050[0] = (char *(*)()) F686_3821;
	R3050[1] = (char *(*)()) F687_3821;
	R3050[2] = (char *(*)()) F688_3821;
	R3050[3] = (char *(*)()) F689_3821;
	R3050[4] = (char *(*)()) F690_3821;
	R3050[5] = (char *(*)()) F691_3821;
	R3050[6] = (char *(*)()) F686_3821;
	R3050[7] = (char *(*)()) F687_3821;
	R3050[8] = (char *(*)()) F686_3821;
}

char *(*R3056[9])();
void R3056_init () {
	R3056[0] = (char *(*)()) F686_3834;
	R3056[1] = (char *(*)()) F687_3834;
	R3056[2] = (char *(*)()) F688_3834;
	R3056[3] = (char *(*)()) F689_3834;
	R3056[4] = (char *(*)()) F690_3834;
	R3056[5] = (char *(*)()) F691_3834;
	R3056[6] = (char *(*)()) F692_3894;
	R3056[7] = (char *(*)()) F693_3894;
	R3056[8] = (char *(*)()) F686_3834;
}

char *(*R3065[9])();
void R3065_init () {
	R3065[0] = (char *(*)()) F686_3844;
	R3065[1] = (char *(*)()) F687_3844;
	R3065[2] = (char *(*)()) F688_3844;
	R3065[3] = (char *(*)()) F689_3844;
	R3065[4] = (char *(*)()) F690_3844;
	R3065[5] = (char *(*)()) F691_3844;
	R3065[6] = (char *(*)()) F686_3844;
	R3065[7] = (char *(*)()) F687_3844;
	R3065[8] = (char *(*)()) F686_3844;
}

char *(*R3066[9])();
void R3066_init () {
	R3066[0] = (char *(*)()) F686_3845;
	R3066[1] = (char *(*)()) F687_3845;
	R3066[2] = (char *(*)()) F688_3845;
	R3066[3] = (char *(*)()) F689_3845;
	R3066[4] = (char *(*)()) F690_3845;
	R3066[5] = (char *(*)()) F691_3845;
	R3066[6] = (char *(*)()) F686_3845;
	R3066[7] = (char *(*)()) F687_3845;
	R3066[8] = (char *(*)()) F686_3845;
}

char *(*R3073[9])();
void R3073_init () {
	R3073[0] = (char *(*)()) F686_3852;
	R3073[1] = (char *(*)()) F687_3852_3073_1;
	R3073[2] = (char *(*)()) F688_3852_3073_1;
	R3073[3] = (char *(*)()) F689_3852;
	R3073[4] = (char *(*)()) F690_3852_3073_1;
	R3073[5] = (char *(*)()) F691_3852_3073_1;
	R3073[6] = (char *(*)()) F686_3852;
	R3073[7] = (char *(*)()) F687_3852_3073_1;
	R3073[8] = (char *(*)()) F686_3852;
}
static EIF_REFERENCE F687_3852_3073_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F687_3852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3852_3073_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F688_3852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3852_3073_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F690_3852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3852_3073_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F691_3852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3074[9])();
void R3074_init () {
	R3074[0] = (char *(*)()) F686_3853;
	R3074[1] = (char *(*)()) F687_3853;
	R3074[2] = (char *(*)()) F688_3853_3074_1;
	R3074[3] = (char *(*)()) F689_3853_3074_1;
	R3074[4] = (char *(*)()) F690_3853_3074_1;
	R3074[5] = (char *(*)()) F691_3853;
	R3074[6] = (char *(*)()) F686_3853;
	R3074[7] = (char *(*)()) F687_3853;
	R3074[8] = (char *(*)()) F686_3853;
}
static EIF_REFERENCE F688_3853_3074_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F688_3853(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_3853_3074_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F689_3853(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3853_3074_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F690_3853(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3075[9])();
void R3075_init () {
	R3075[0] = (char *(*)()) F686_3854;
	R3075[1] = (char *(*)()) F687_3854;
	R3075[2] = (char *(*)()) F688_3854;
	R3075[3] = (char *(*)()) F689_3854;
	R3075[4] = (char *(*)()) F690_3854;
	R3075[5] = (char *(*)()) F691_3854;
	R3075[6] = (char *(*)()) F686_3854;
	R3075[7] = (char *(*)()) F687_3854;
	R3075[8] = (char *(*)()) F686_3854;
}

char *(*R3076[9])();
void R3076_init () {
	R3076[0] = (char *(*)()) F686_3855;
	R3076[1] = (char *(*)()) F687_3855;
	R3076[2] = (char *(*)()) F688_3855;
	R3076[3] = (char *(*)()) F689_3855;
	R3076[4] = (char *(*)()) F690_3855;
	R3076[5] = (char *(*)()) F691_3855;
	R3076[6] = (char *(*)()) F686_3855;
	R3076[7] = (char *(*)()) F687_3855;
	R3076[8] = (char *(*)()) F686_3855;
}

char *(*R3077[9])();
void R3077_init () {
	R3077[0] = (char *(*)()) F686_3856;
	R3077[1] = (char *(*)()) F687_3856;
	R3077[2] = (char *(*)()) F688_3856;
	R3077[3] = (char *(*)()) F689_3856;
	R3077[4] = (char *(*)()) F690_3856;
	R3077[5] = (char *(*)()) F691_3856;
	R3077[6] = (char *(*)()) F686_3856;
	R3077[7] = (char *(*)()) F687_3856;
	R3077[8] = (char *(*)()) F686_3856;
}

char *(*R3079[9])();
void R3079_init () {
	R3079[0] = (char *(*)()) F686_3858;
	R3079[1] = (char *(*)()) F687_3858;
	R3079[2] = (char *(*)()) F688_3858;
	R3079[3] = (char *(*)()) F689_3858;
	R3079[4] = (char *(*)()) F690_3858;
	R3079[5] = (char *(*)()) F691_3858;
	R3079[6] = (char *(*)()) F686_3858;
	R3079[7] = (char *(*)()) F687_3858;
	R3079[8] = (char *(*)()) F686_3858;
}

char *(*R3081[9])();
void R3081_init () {
	R3081[0] = (char *(*)()) F686_3860;
	R3081[1] = (char *(*)()) F687_3860;
	R3081[2] = (char *(*)()) F688_3860;
	R3081[3] = (char *(*)()) F689_3860;
	R3081[4] = (char *(*)()) F690_3860;
	R3081[5] = (char *(*)()) F691_3860;
	R3081[6] = (char *(*)()) F686_3860;
	R3081[7] = (char *(*)()) F687_3860;
	R3081[8] = (char *(*)()) F686_3860;
}

char *(*R3082[9])();
void R3082_init () {
	R3082[0] = (char *(*)()) F686_3861;
	R3082[1] = (char *(*)()) F687_3861;
	R3082[2] = (char *(*)()) F688_3861;
	R3082[3] = (char *(*)()) F689_3861;
	R3082[4] = (char *(*)()) F690_3861;
	R3082[5] = (char *(*)()) F691_3861;
	R3082[6] = (char *(*)()) F686_3861;
	R3082[7] = (char *(*)()) F687_3861;
	R3082[8] = (char *(*)()) F686_3861;
}

char *(*R3083[9])();
void R3083_init () {
	R3083[0] = (char *(*)()) F686_3862;
	R3083[1] = (char *(*)()) F687_3862;
	R3083[2] = (char *(*)()) F688_3862;
	R3083[3] = (char *(*)()) F689_3862;
	R3083[4] = (char *(*)()) F690_3862;
	R3083[5] = (char *(*)()) F691_3862;
	R3083[6] = (char *(*)()) F686_3862;
	R3083[7] = (char *(*)()) F687_3862;
	R3083[8] = (char *(*)()) F686_3862;
}

char *(*R3087[9])();
void R3087_init () {
	R3087[0] = (char *(*)()) F686_3866;
	R3087[1] = (char *(*)()) F687_3866;
	R3087[2] = (char *(*)()) F688_3866_3087_4;
	R3087[3] = (char *(*)()) F689_3866_3087_4;
	R3087[4] = (char *(*)()) F690_3866_3087_4;
	R3087[5] = (char *(*)()) F691_3866;
	R3087[6] = (char *(*)()) F686_3866;
	R3087[7] = (char *(*)()) F687_3866;
	R3087[8] = (char *(*)()) F686_3866;
}
static void F688_3866_3087_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F688_3866(Current, *(EIF_POINTER *)arg1);
}
static void F689_3866_3087_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F689_3866(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F690_3866_3087_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F690_3866(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3093[9])();
void R3093_init () {
	R3093[0] = (char *(*)()) F686_3872;
	R3093[1] = (char *(*)()) F687_3872;
	R3093[2] = (char *(*)()) F688_3872;
	R3093[3] = (char *(*)()) F689_3872;
	R3093[4] = (char *(*)()) F690_3872;
	R3093[5] = (char *(*)()) F691_3872;
	R3093[6] = (char *(*)()) F686_3872;
	R3093[7] = (char *(*)()) F687_3872;
	R3093[8] = (char *(*)()) F686_3872;
}

char *(*R3106[9])();
void R3106_init () {
	R3106[0] = (char *(*)()) F686_3885;
	R3106[1] = (char *(*)()) F687_3885;
	R3106[2] = (char *(*)()) F688_3885;
	R3106[3] = (char *(*)()) F689_3885;
	R3106[4] = (char *(*)()) F690_3885;
	R3106[5] = (char *(*)()) F691_3885;
	R3106[6] = (char *(*)()) F686_3885;
	R3106[7] = (char *(*)()) F687_3885;
	R3106[8] = (char *(*)()) F686_3885;
}

char *(*R3109[2])();
void R3109_init () {
	R3109[0] = (char *(*)()) F692_3888;
	R3109[1] = (char *(*)()) F693_3888;
}

char *(*R3214[12])();
void R3214_init () {
	R3214[0] = (char *(*)()) F699_4018;
	R3214[1] = (char *(*)()) F700_4018;
	R3214[2] = (char *(*)()) F701_4018;
	R3214[3] = (char *(*)()) F702_4018;
	R3214[4] = (char *(*)()) F703_4018;
	R3214[5] = (char *(*)()) F704_4018;
	R3214[6] = (char *(*)()) F705_4018;
	R3214[7] = (char *(*)()) F706_4018;
	R3214[8] = (char *(*)()) F707_4018;
	R3214[9] = (char *(*)()) F708_4018;
	R3214[10] = (char *(*)()) F709_4018;
	R3214[11] = (char *(*)()) F710_4018;
}

char *(*R3215[12])();
void R3215_init () {
	R3215[0] = (char *(*)()) F699_4019;
	R3215[1] = (char *(*)()) F700_4019;
	R3215[2] = (char *(*)()) F701_4019;
	R3215[3] = (char *(*)()) F702_4019;
	R3215[4] = (char *(*)()) F703_4019;
	R3215[5] = (char *(*)()) F704_4019;
	R3215[6] = (char *(*)()) F705_4019;
	R3215[7] = (char *(*)()) F706_4019;
	R3215[8] = (char *(*)()) F707_4019;
	R3215[9] = (char *(*)()) F708_4019;
	R3215[10] = (char *(*)()) F709_4019;
	R3215[11] = (char *(*)()) F710_4019;
}

char *(*R3217[12])();
void R3217_init () {
	R3217[0] = (char *(*)()) F699_4005;
	R3217[1] = (char *(*)()) F700_4005;
	R3217[2] = (char *(*)()) F701_4005;
	R3217[3] = (char *(*)()) F702_4005;
	R3217[4] = (char *(*)()) F703_4005;
	R3217[5] = (char *(*)()) F704_4005;
	R3217[6] = (char *(*)()) F705_4005;
	R3217[7] = (char *(*)()) F706_4005;
	R3217[8] = (char *(*)()) F707_4005;
	R3217[9] = (char *(*)()) F708_4005;
	R3217[10] = (char *(*)()) F709_4005;
	R3217[11] = (char *(*)()) F710_4005;
}

char *(*R3218[12])();
void R3218_init () {
	R3218[0] = (char *(*)()) F699_4006;
	R3218[1] = (char *(*)()) F700_4006_3218_125;
	R3218[2] = (char *(*)()) F701_4006_3218_125;
	R3218[3] = (char *(*)()) F702_4006_3218_125;
	R3218[4] = (char *(*)()) F703_4006_3218_125;
	R3218[5] = (char *(*)()) F704_4006_3218_125;
	R3218[6] = (char *(*)()) F705_4006_3218_125;
	R3218[7] = (char *(*)()) F706_4006_3218_125;
	R3218[8] = (char *(*)()) F707_4006_3218_125;
	R3218[9] = (char *(*)()) F708_4006_3218_125;
	R3218[10] = (char *(*)()) F709_4006_3218_125;
	R3218[11] = (char *(*)()) F710_4006_3218_125;
}
static void F700_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F700_4006(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F701_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F701_4006(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F702_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F702_4006(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F703_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F703_4006(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F704_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F704_4006(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F705_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F705_4006(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F706_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F706_4006(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F707_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F707_4006(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F708_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F708_4006(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F709_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F709_4006(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F710_4006_3218_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F710_4006(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3227[12])();
void R3227_init () {
	R3227[0] = (char *(*)()) F699_4021;
	R3227[1] = (char *(*)()) F700_4021;
	R3227[2] = (char *(*)()) F701_4021;
	R3227[3] = (char *(*)()) F702_4021;
	R3227[4] = (char *(*)()) F703_4021;
	R3227[5] = (char *(*)()) F704_4021;
	R3227[6] = (char *(*)()) F705_4021;
	R3227[7] = (char *(*)()) F706_4021;
	R3227[8] = (char *(*)()) F707_4021;
	R3227[9] = (char *(*)()) F708_4021;
	R3227[10] = (char *(*)()) F709_4021;
	R3227[11] = (char *(*)()) F710_4021;
}

char *(*R3228[12])();
void R3228_init () {
	R3228[0] = (char *(*)()) F699_4023;
	R3228[1] = (char *(*)()) F700_4023_3228_125;
	R3228[2] = (char *(*)()) F701_4023_3228_125;
	R3228[3] = (char *(*)()) F702_4023_3228_125;
	R3228[4] = (char *(*)()) F703_4023_3228_125;
	R3228[5] = (char *(*)()) F704_4023_3228_125;
	R3228[6] = (char *(*)()) F705_4023_3228_125;
	R3228[7] = (char *(*)()) F706_4023_3228_125;
	R3228[8] = (char *(*)()) F707_4023_3228_125;
	R3228[9] = (char *(*)()) F708_4023_3228_125;
	R3228[10] = (char *(*)()) F709_4023_3228_125;
	R3228[11] = (char *(*)()) F710_4023_3228_125;
}
static void F700_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F700_4023(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F701_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F701_4023(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F702_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F702_4023(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F703_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F703_4023(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F704_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F704_4023(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F705_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F705_4023(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F706_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F706_4023(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F707_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F707_4023(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F708_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F708_4023(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F709_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F709_4023(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F710_4023_3228_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F710_4023(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3229[12])();
void R3229_init () {
	R3229[0] = (char *(*)()) F699_4024;
	R3229[1] = (char *(*)()) F700_4024_3229_125;
	R3229[2] = (char *(*)()) F701_4024_3229_125;
	R3229[3] = (char *(*)()) F702_4024_3229_125;
	R3229[4] = (char *(*)()) F703_4024_3229_125;
	R3229[5] = (char *(*)()) F704_4024_3229_125;
	R3229[6] = (char *(*)()) F705_4024_3229_125;
	R3229[7] = (char *(*)()) F706_4024_3229_125;
	R3229[8] = (char *(*)()) F707_4024_3229_125;
	R3229[9] = (char *(*)()) F708_4024_3229_125;
	R3229[10] = (char *(*)()) F709_4024_3229_125;
	R3229[11] = (char *(*)()) F710_4024_3229_125;
}
static void F700_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F700_4024(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F701_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F701_4024(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F702_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F702_4024(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F703_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F703_4024(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F704_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F704_4024(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F705_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F705_4024(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F706_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F706_4024(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F707_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F707_4024(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F708_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F708_4024(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F709_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F709_4024(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F710_4024_3229_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F710_4024(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3230[12])();
void R3230_init () {
	R3230[0] = (char *(*)()) F699_4025;
	R3230[1] = (char *(*)()) F700_4025_3230_4;
	R3230[2] = (char *(*)()) F701_4025_3230_4;
	R3230[3] = (char *(*)()) F702_4025_3230_4;
	R3230[4] = (char *(*)()) F703_4025_3230_4;
	R3230[5] = (char *(*)()) F704_4025_3230_4;
	R3230[6] = (char *(*)()) F705_4025_3230_4;
	R3230[7] = (char *(*)()) F706_4025_3230_4;
	R3230[8] = (char *(*)()) F707_4025_3230_4;
	R3230[9] = (char *(*)()) F708_4025_3230_4;
	R3230[10] = (char *(*)()) F709_4025_3230_4;
	R3230[11] = (char *(*)()) F710_4025_3230_4;
}
static void F700_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F700_4025(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F701_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F701_4025(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F702_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F702_4025(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F703_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F703_4025(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F704_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F704_4025(Current, *(EIF_BOOLEAN *)arg1);
}
static void F705_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F705_4025(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F706_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F706_4025(Current, *(EIF_POINTER *)arg1);
}
static void F707_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F707_4025(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F708_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F708_4025(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F709_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F709_4025(Current, *(EIF_REAL_32 *)arg1);
}
static void F710_4025_3230_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F710_4025(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3232[12])();
void R3232_init () {
	R3232[0] = (char *(*)()) F699_4027;
	R3232[1] = (char *(*)()) F700_4027_3232_129;
	R3232[2] = (char *(*)()) F701_4027_3232_129;
	R3232[3] = (char *(*)()) F702_4027_3232_129;
	R3232[4] = (char *(*)()) F703_4027_3232_129;
	R3232[5] = (char *(*)()) F704_4027_3232_129;
	R3232[6] = (char *(*)()) F705_4027_3232_129;
	R3232[7] = (char *(*)()) F706_4027_3232_129;
	R3232[8] = (char *(*)()) F707_4027_3232_129;
	R3232[9] = (char *(*)()) F708_4027_3232_129;
	R3232[10] = (char *(*)()) F709_4027_3232_129;
	R3232[11] = (char *(*)()) F710_4027_3232_129;
}
static void F700_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F700_4027(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F701_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F701_4027(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F702_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F702_4027(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F703_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F703_4027(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F704_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F704_4027(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F705_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F705_4027(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F706_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F706_4027(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F707_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F707_4027(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F708_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F708_4027(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F709_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F709_4027(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F710_4027_3232_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F710_4027(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3234[12])();
void R3234_init () {
	R3234[0] = (char *(*)()) F699_4029;
	R3234[1] = (char *(*)()) F700_4029;
	R3234[2] = (char *(*)()) F701_4029;
	R3234[3] = (char *(*)()) F702_4029;
	R3234[4] = (char *(*)()) F703_4029;
	R3234[5] = (char *(*)()) F704_4029;
	R3234[6] = (char *(*)()) F705_4029;
	R3234[7] = (char *(*)()) F706_4029;
	R3234[8] = (char *(*)()) F707_4029;
	R3234[9] = (char *(*)()) F708_4029;
	R3234[10] = (char *(*)()) F709_4029;
	R3234[11] = (char *(*)()) F710_4029;
}

char *(*R3235[12])();
void R3235_init () {
	R3235[0] = (char *(*)()) F699_4030;
	R3235[1] = (char *(*)()) F700_4030;
	R3235[2] = (char *(*)()) F701_4030;
	R3235[3] = (char *(*)()) F702_4030;
	R3235[4] = (char *(*)()) F703_4030;
	R3235[5] = (char *(*)()) F704_4030;
	R3235[6] = (char *(*)()) F705_4030;
	R3235[7] = (char *(*)()) F706_4030;
	R3235[8] = (char *(*)()) F707_4030;
	R3235[9] = (char *(*)()) F708_4030;
	R3235[10] = (char *(*)()) F709_4030;
	R3235[11] = (char *(*)()) F710_4030;
}

char *(*R3236[12])();
void R3236_init () {
	R3236[0] = (char *(*)()) F699_4031;
	R3236[1] = (char *(*)()) F700_4031;
	R3236[2] = (char *(*)()) F701_4031;
	R3236[3] = (char *(*)()) F702_4031;
	R3236[4] = (char *(*)()) F703_4031;
	R3236[5] = (char *(*)()) F704_4031;
	R3236[6] = (char *(*)()) F705_4031;
	R3236[7] = (char *(*)()) F706_4031;
	R3236[8] = (char *(*)()) F707_4031;
	R3236[9] = (char *(*)()) F708_4031;
	R3236[10] = (char *(*)()) F709_4031;
	R3236[11] = (char *(*)()) F710_4031;
}

char *(*R3237[12])();
void R3237_init () {
	R3237[0] = (char *(*)()) F699_4032;
	R3237[1] = (char *(*)()) F700_4032;
	R3237[2] = (char *(*)()) F701_4032;
	R3237[3] = (char *(*)()) F702_4032;
	R3237[4] = (char *(*)()) F703_4032;
	R3237[5] = (char *(*)()) F704_4032;
	R3237[6] = (char *(*)()) F705_4032;
	R3237[7] = (char *(*)()) F706_4032;
	R3237[8] = (char *(*)()) F707_4032;
	R3237[9] = (char *(*)()) F708_4032;
	R3237[10] = (char *(*)()) F709_4032;
	R3237[11] = (char *(*)()) F710_4032;
}

char *(*R3238[12])();
void R3238_init () {
	R3238[0] = (char *(*)()) F699_4033;
	R3238[1] = (char *(*)()) F700_4033;
	R3238[2] = (char *(*)()) F701_4033;
	R3238[3] = (char *(*)()) F702_4033;
	R3238[4] = (char *(*)()) F703_4033;
	R3238[5] = (char *(*)()) F704_4033;
	R3238[6] = (char *(*)()) F705_4033;
	R3238[7] = (char *(*)()) F706_4033;
	R3238[8] = (char *(*)()) F707_4033;
	R3238[9] = (char *(*)()) F708_4033;
	R3238[10] = (char *(*)()) F709_4033;
	R3238[11] = (char *(*)()) F710_4033;
}

char *(*R3239[12])();
void R3239_init () {
	R3239[0] = (char *(*)()) F699_4034;
	R3239[1] = (char *(*)()) F700_4034;
	R3239[2] = (char *(*)()) F701_4034;
	R3239[3] = (char *(*)()) F702_4034;
	R3239[4] = (char *(*)()) F703_4034;
	R3239[5] = (char *(*)()) F704_4034;
	R3239[6] = (char *(*)()) F705_4034;
	R3239[7] = (char *(*)()) F706_4034;
	R3239[8] = (char *(*)()) F707_4034;
	R3239[9] = (char *(*)()) F708_4034;
	R3239[10] = (char *(*)()) F709_4034;
	R3239[11] = (char *(*)()) F710_4034;
}

char *(*R3242[12])();
void R3242_init () {
	R3242[0] = (char *(*)()) F699_4037;
	R3242[1] = (char *(*)()) F700_4037;
	R3242[2] = (char *(*)()) F701_4037;
	R3242[3] = (char *(*)()) F702_4037;
	R3242[4] = (char *(*)()) F703_4037;
	R3242[5] = (char *(*)()) F704_4037;
	R3242[6] = (char *(*)()) F705_4037;
	R3242[7] = (char *(*)()) F706_4037;
	R3242[8] = (char *(*)()) F707_4037;
	R3242[9] = (char *(*)()) F708_4037;
	R3242[10] = (char *(*)()) F709_4037;
	R3242[11] = (char *(*)()) F710_4037;
}

char *(*R3245[12])();
void R3245_init () {
	R3245[0] = (char *(*)()) F699_4040;
	R3245[1] = (char *(*)()) F700_4040;
	R3245[2] = (char *(*)()) F701_4040;
	R3245[3] = (char *(*)()) F702_4040;
	R3245[4] = (char *(*)()) F703_4040;
	R3245[5] = (char *(*)()) F704_4040;
	R3245[6] = (char *(*)()) F705_4040;
	R3245[7] = (char *(*)()) F706_4040;
	R3245[8] = (char *(*)()) F707_4040;
	R3245[9] = (char *(*)()) F708_4040;
	R3245[10] = (char *(*)()) F709_4040;
	R3245[11] = (char *(*)()) F710_4040;
}

char *(*R3246[12])();
void R3246_init () {
	R3246[0] = (char *(*)()) F699_4041;
	R3246[1] = (char *(*)()) F700_4041_3246_104;
	R3246[2] = (char *(*)()) F701_4041_3246_104;
	R3246[3] = (char *(*)()) F702_4041_3246_104;
	R3246[4] = (char *(*)()) F703_4041_3246_104;
	R3246[5] = (char *(*)()) F704_4041_3246_104;
	R3246[6] = (char *(*)()) F705_4041_3246_104;
	R3246[7] = (char *(*)()) F706_4041_3246_104;
	R3246[8] = (char *(*)()) F707_4041_3246_104;
	R3246[9] = (char *(*)()) F708_4041_3246_104;
	R3246[10] = (char *(*)()) F709_4041_3246_104;
	R3246[11] = (char *(*)()) F710_4041_3246_104;
}
static EIF_REFERENCE F700_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F700_4041(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F701_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F701_4041(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F702_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F702_4041(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F703_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F703_4041(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F704_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F704_4041(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F705_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F705_4041(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F706_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F706_4041(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F707_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F707_4041(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F708_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F708_4041(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F709_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F709_4041(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F710_4041_3246_104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F710_4041(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3248[12])();
void R3248_init () {
	R3248[0] = (char *(*)()) F699_4043;
	R3248[1] = (char *(*)()) F700_4043;
	R3248[2] = (char *(*)()) F701_4043;
	R3248[3] = (char *(*)()) F702_4043;
	R3248[4] = (char *(*)()) F703_4043;
	R3248[5] = (char *(*)()) F704_4043;
	R3248[6] = (char *(*)()) F705_4043;
	R3248[7] = (char *(*)()) F706_4043;
	R3248[8] = (char *(*)()) F707_4043;
	R3248[9] = (char *(*)()) F708_4043;
	R3248[10] = (char *(*)()) F709_4043;
	R3248[11] = (char *(*)()) F710_4043;
}

char *(*R3257[12])();
void R3257_init () {
	R3257[0] = (char *(*)()) F699_4053;
	R3257[1] = (char *(*)()) F700_4053;
	R3257[2] = (char *(*)()) F701_4053;
	R3257[3] = (char *(*)()) F702_4053;
	R3257[4] = (char *(*)()) F703_4053;
	R3257[5] = (char *(*)()) F704_4053;
	R3257[6] = (char *(*)()) F705_4053;
	R3257[7] = (char *(*)()) F706_4053;
	R3257[8] = (char *(*)()) F707_4053;
	R3257[9] = (char *(*)()) F708_4053;
	R3257[10] = (char *(*)()) F709_4053;
	R3257[11] = (char *(*)()) F710_4053;
}

char *(*R3304[26])();
void R3304_init () {
	R3304[0] = (char *(*)()) F833_4665_3304_1;
	R3304[1] = (char *(*)()) F834_4665_3304_1;
	R3304[3] = (char *(*)()) F836_4731_3304_1;
	R3304[4] = (char *(*)()) F837_4731_3304_1;
	R3304[15] = (char *(*)()) F848_4928_3304_1;
	R3304[16] = (char *(*)()) F849_4928_3304_1;
	R3304[18] = (char *(*)()) F851_5026_3304_1;
	R3304[19] = (char *(*)()) F852_5026_3304_1;
	R3304[21] = (char *(*)()) F854_5125_3304_1;
	R3304[22] = (char *(*)()) F855_5125_3304_1;
	R3304[24] = (char *(*)()) F857_5224_3304_1;
	R3304[25] = (char *(*)()) F858_5224_3304_1;
}
static EIF_REFERENCE F833_4665_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F833_4665(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F834_4665_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F834_4665(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F836_4731_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F836_4731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F837_4731_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F837_4731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_4928_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F848_4928(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_4928_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F849_4928(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_5026_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F851_5026(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_5026_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F852_5026(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_5125_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F854_5125(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(854, 0x00).id, 854, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_5125_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F855_5125(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(854, 0x00).id, 854, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_5224_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F857_5224(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(857, 0x00).id, 857, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_5224_3304_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F858_5224(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(857, 0x00).id, 857, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}

char *(*R3355[5])();
void R3355_init () {
	{long i; for (i = 0; i < 2; i++) R3355[i] = (char *(*)()) F772_4209;}
	R3355[3] = (char *(*)()) F775_4214;
	R3355[4] = (char *(*)()) F776_4215;
}

char *(*R3358[5])();
void R3358_init () {
	{long i; for (i = 0; i < 2; i++) R3358[i] = (char *(*)()) F772_4210;}
	{long i; for (i = 3; i < 5; i++) R3358[i] = (char *(*)()) F771_4203;}
}

char *(*R3362[5])();
void R3362_init () {
	{long i; for (i = 0; i < 2; i++) R3362[i] = (char *(*)()) F772_4211;}
	{long i; for (i = 3; i < 5; i++) R3362[i] = (char *(*)()) F774_4213;}
}

char *(*R3363[5])();
void R3363_init () {
	R3363[0] = (char *(*)()) F771_4208;
	R3363[1] = (char *(*)()) F773_4212;
	{long i; for (i = 3; i < 5; i++) R3363[i] = (char *(*)()) F771_4208;}
}

char *(*R3370[2])();
void R3370_init () {
	R3370[0] = (char *(*)()) F778_4225;
	R3370[1] = (char *(*)()) F779_4226;
}

char *(*R3374[2])();
void R3374_init () {
	R3374[0] = (char *(*)()) F781_4233;
	R3374[1] = (char *(*)()) F782_4234;
}

char *(*R3378[2])();
void R3378_init () {
	R3378[0] = (char *(*)()) F784_4252;
	R3378[1] = (char *(*)()) F785_4253;
}

char *(*R3394[8])();
void R3394_init () {
	R3394[0] = (char *(*)()) F787_4258;
	R3394[1] = (char *(*)()) F788_4259;
	R3394[2] = (char *(*)()) F789_4260;
	R3394[3] = (char *(*)()) F790_4263;
	R3394[4] = (char *(*)()) F791_4268;
	R3394[5] = (char *(*)()) F792_4284;
	R3394[6] = (char *(*)()) F793_4285;
	R3394[7] = (char *(*)()) F794_4286;
}

EIF_TYPE_INDEX *Y3395_gen_type [9];
EIF_TYPE_INDEX Y3395 [9];
void Y3395_init (void)
{
	egc_routines_types [3395] = Y3395;
	egc_routines_gen_types [3395] = Y3395_gen_type;
	egc_routines_offset [3395] = 785;
	{long i; for (i = 0; i < 5; i++) Y3395[i] = 944;};
	Y3395[5] = 945;
	{long i; for (i = 6; i < 9; i++) Y3395[i] = 944;};
}

char *(*R3396[8])();
void R3396_init () {
	{long i; for (i = 0; i < 3; i++) R3396[i] = (char *(*)()) F786_4257;}
	R3396[3] = (char *(*)()) F790_4262;
	{long i; for (i = 4; i < 8; i++) R3396[i] = (char *(*)()) F786_4257;}
}

char *(*R3412[120])();
void R3412_init () {
	R3412[0] = (char *(*)()) F796_4313;
	R3412[1] = (char *(*)()) F797_4355;
	R3412[2] = (char *(*)()) F798_4355;
	R3412[3] = (char *(*)()) F799_4355;
	R3412[4] = (char *(*)()) F800_4355;
	R3412[5] = (char *(*)()) F801_4355;
	R3412[6] = (char *(*)()) F802_4355;
	R3412[7] = (char *(*)()) F803_4355;
	R3412[8] = (char *(*)()) F804_4355;
	R3412[9] = (char *(*)()) F805_4355;
	R3412[10] = (char *(*)()) F806_4355;
	R3412[11] = (char *(*)()) F807_4355;
	R3412[12] = (char *(*)()) F808_4355;
	R3412[13] = (char *(*)()) F809_4355;
	R3412[14] = (char *(*)()) F810_4355;
	R3412[15] = (char *(*)()) F811_4355;
	R3412[16] = (char *(*)()) F812_4355;
	R3412[17] = (char *(*)()) F813_4355;
	R3412[18] = (char *(*)()) F814_4355;
	R3412[19] = (char *(*)()) F815_4355;
	R3412[20] = (char *(*)()) F816_4355;
	R3412[21] = (char *(*)()) F817_4355;
	R3412[22] = (char *(*)()) F818_4355;
	R3412[23] = (char *(*)()) F819_4355;
	R3412[24] = (char *(*)()) F820_4355;
	R3412[25] = (char *(*)()) F821_4355;
	R3412[26] = (char *(*)()) F822_4355;
	R3412[27] = (char *(*)()) F823_4355;
	R3412[28] = (char *(*)()) F824_4355;
	R3412[29] = (char *(*)()) F825_4355;
	R3412[30] = (char *(*)()) F826_4355;
	R3412[31] = (char *(*)()) F827_4355;
	R3412[32] = (char *(*)()) F828_4407;
	{long i; for (i = 34; i < 36; i++) R3412[i] = (char *(*)()) F829_4514;}
	{long i; for (i = 37; i < 39; i++) R3412[i] = (char *(*)()) F832_4609;}
	{long i; for (i = 40; i < 42; i++) R3412[i] = (char *(*)()) F835_4675;}
	{long i; for (i = 43; i < 45; i++) R3412[i] = (char *(*)()) F838_4742;}
	{long i; for (i = 46; i < 48; i++) R3412[i] = (char *(*)()) F841_4783;}
	{long i; for (i = 49; i < 51; i++) R3412[i] = (char *(*)()) F844_4831;}
	{long i; for (i = 52; i < 54; i++) R3412[i] = (char *(*)()) F847_4852;}
	{long i; for (i = 55; i < 57; i++) R3412[i] = (char *(*)()) F850_4951;}
	{long i; for (i = 58; i < 60; i++) R3412[i] = (char *(*)()) F853_5049;}
	{long i; for (i = 61; i < 63; i++) R3412[i] = (char *(*)()) F856_5148;}
	{long i; for (i = 64; i < 66; i++) R3412[i] = (char *(*)()) F859_5247;}
	{long i; for (i = 67; i < 69; i++) R3412[i] = (char *(*)()) F862_5341;}
	{long i; for (i = 70; i < 72; i++) R3412[i] = (char *(*)()) F865_5435;}
	{long i; for (i = 73; i < 103; i++) R3412[i] = (char *(*)()) F868_5530;}
	R3412[103] = (char *(*)()) F899_5556;
	R3412[104] = (char *(*)()) F900_5556;
	{long i; for (i = 114; i < 117; i++) R3412[i] = (char *(*)()) F906_5623;}
	{long i; for (i = 118; i < 120; i++) R3412[i] = (char *(*)()) F906_5623;}
}

char *(*R3470[31])();
void R3470_init () {
	R3470[0] = (char *(*)()) F797_4351;
	R3470[1] = (char *(*)()) F798_4351;
	R3470[2] = (char *(*)()) F799_4351;
	R3470[3] = (char *(*)()) F800_4351;
	R3470[4] = (char *(*)()) F801_4351;
	R3470[5] = (char *(*)()) F802_4351;
	R3470[6] = (char *(*)()) F803_4351;
	R3470[7] = (char *(*)()) F804_4351;
	R3470[8] = (char *(*)()) F805_4351;
	R3470[9] = (char *(*)()) F806_4351;
	R3470[10] = (char *(*)()) F807_4351;
	R3470[11] = (char *(*)()) F808_4351;
	R3470[12] = (char *(*)()) F809_4351;
	R3470[13] = (char *(*)()) F810_4351;
	R3470[14] = (char *(*)()) F811_4351;
	R3470[15] = (char *(*)()) F812_4351;
	R3470[16] = (char *(*)()) F813_4351;
	R3470[17] = (char *(*)()) F814_4351;
	R3470[18] = (char *(*)()) F815_4351;
	R3470[19] = (char *(*)()) F816_4351;
	R3470[20] = (char *(*)()) F817_4351;
	R3470[21] = (char *(*)()) F818_4351;
	R3470[22] = (char *(*)()) F819_4351;
	R3470[23] = (char *(*)()) F820_4351;
	R3470[24] = (char *(*)()) F821_4351;
	R3470[25] = (char *(*)()) F822_4351;
	R3470[26] = (char *(*)()) F823_4351;
	R3470[27] = (char *(*)()) F824_4351;
	R3470[28] = (char *(*)()) F825_4351;
	R3470[29] = (char *(*)()) F826_4351;
	R3470[30] = (char *(*)()) F827_4351;
}

char *(*R3473[31])();
void R3473_init () {
	R3473[0] = (char *(*)()) F797_4354;
	R3473[1] = (char *(*)()) F798_4354;
	R3473[2] = (char *(*)()) F799_4354;
	R3473[3] = (char *(*)()) F800_4354;
	R3473[4] = (char *(*)()) F801_4354;
	R3473[5] = (char *(*)()) F802_4354;
	R3473[6] = (char *(*)()) F803_4354;
	R3473[7] = (char *(*)()) F804_4354;
	R3473[8] = (char *(*)()) F805_4354;
	R3473[9] = (char *(*)()) F806_4354;
	R3473[10] = (char *(*)()) F807_4354;
	R3473[11] = (char *(*)()) F808_4354;
	R3473[12] = (char *(*)()) F809_4354;
	R3473[13] = (char *(*)()) F810_4354;
	R3473[14] = (char *(*)()) F811_4354;
	R3473[15] = (char *(*)()) F812_4354;
	R3473[16] = (char *(*)()) F813_4354;
	R3473[17] = (char *(*)()) F814_4354;
	R3473[18] = (char *(*)()) F815_4354;
	R3473[19] = (char *(*)()) F816_4354;
	R3473[20] = (char *(*)()) F817_4354;
	R3473[21] = (char *(*)()) F818_4354;
	R3473[22] = (char *(*)()) F819_4354;
	R3473[23] = (char *(*)()) F820_4354;
	R3473[24] = (char *(*)()) F821_4354;
	R3473[25] = (char *(*)()) F822_4354;
	R3473[26] = (char *(*)()) F823_4354;
	R3473[27] = (char *(*)()) F824_4354;
	R3473[28] = (char *(*)()) F825_4354;
	R3473[29] = (char *(*)()) F826_4354;
	R3473[30] = (char *(*)()) F827_4354;
}

char *(*R3478[31])();
void R3478_init () {
	R3478[0] = (char *(*)()) F797_4360;
	R3478[1] = (char *(*)()) F798_4360;
	R3478[2] = (char *(*)()) F799_4360;
	R3478[3] = (char *(*)()) F800_4360;
	R3478[4] = (char *(*)()) F801_4360;
	R3478[5] = (char *(*)()) F802_4360;
	R3478[6] = (char *(*)()) F803_4360;
	R3478[7] = (char *(*)()) F804_4360;
	R3478[8] = (char *(*)()) F805_4360;
	R3478[9] = (char *(*)()) F806_4360;
	R3478[10] = (char *(*)()) F807_4360;
	R3478[11] = (char *(*)()) F808_4360;
	R3478[12] = (char *(*)()) F809_4360;
	R3478[13] = (char *(*)()) F810_4360;
	R3478[14] = (char *(*)()) F811_4360;
	R3478[15] = (char *(*)()) F812_4360;
	R3478[16] = (char *(*)()) F813_4360;
	R3478[17] = (char *(*)()) F814_4360;
	R3478[18] = (char *(*)()) F815_4360;
	R3478[19] = (char *(*)()) F816_4360;
	R3478[20] = (char *(*)()) F817_4360;
	R3478[21] = (char *(*)()) F818_4360;
	R3478[22] = (char *(*)()) F819_4360;
	R3478[23] = (char *(*)()) F820_4360;
	R3478[24] = (char *(*)()) F821_4360;
	R3478[25] = (char *(*)()) F822_4360;
	R3478[26] = (char *(*)()) F823_4360;
	R3478[27] = (char *(*)()) F824_4360;
	R3478[28] = (char *(*)()) F825_4360;
	R3478[29] = (char *(*)()) F826_4360;
	R3478[30] = (char *(*)()) F827_4360;
}

char *(*R3483[31])();
void R3483_init () {
	R3483[0] = (char *(*)()) F797_4368;
	R3483[1] = (char *(*)()) F798_4368_3483_1;
	R3483[2] = (char *(*)()) F799_4368_3483_1;
	R3483[3] = (char *(*)()) F800_4368_3483_1;
	R3483[4] = (char *(*)()) F801_4368_3483_1;
	R3483[5] = (char *(*)()) F802_4368_3483_1;
	R3483[6] = (char *(*)()) F803_4368_3483_1;
	R3483[7] = (char *(*)()) F804_4368_3483_1;
	R3483[8] = (char *(*)()) F805_4368_3483_1;
	R3483[9] = (char *(*)()) F806_4368_3483_1;
	R3483[10] = (char *(*)()) F807_4368_3483_1;
	R3483[11] = (char *(*)()) F808_4368_3483_1;
	R3483[12] = (char *(*)()) F809_4368_3483_1;
	R3483[13] = (char *(*)()) F810_4368_3483_1;
	R3483[14] = (char *(*)()) F811_4368_3483_1;
	R3483[15] = (char *(*)()) F812_4368_3483_1;
	R3483[16] = (char *(*)()) F813_4368_3483_1;
	R3483[17] = (char *(*)()) F814_4368;
	R3483[18] = (char *(*)()) F815_4368_3483_1;
	R3483[19] = (char *(*)()) F816_4368_3483_1;
	R3483[20] = (char *(*)()) F817_4368_3483_1;
	R3483[21] = (char *(*)()) F818_4368_3483_1;
	R3483[22] = (char *(*)()) F819_4368_3483_1;
	R3483[23] = (char *(*)()) F820_4368_3483_1;
	R3483[24] = (char *(*)()) F821_4368_3483_1;
	R3483[25] = (char *(*)()) F822_4368_3483_1;
	R3483[26] = (char *(*)()) F823_4368_3483_1;
	R3483[27] = (char *(*)()) F824_4368_3483_1;
	R3483[28] = (char *(*)()) F825_4368_3483_1;
	R3483[29] = (char *(*)()) F826_4368_3483_1;
	R3483[30] = (char *(*)()) F827_4368_3483_1;
}
static EIF_REFERENCE F798_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F798_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F799_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {870,848,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 870, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F800_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {871,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 871, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F801_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F802_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F803_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F804_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F805_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F806_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F806_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F807_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F807_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(857, 0x00).id, 857, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F808_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F808_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(854, 0x00).id, 854, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F809_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F810_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F811_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F812_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F813_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F815_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F815_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {873,866,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 873, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F816_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F816_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {875,842,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 875, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F817_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F817_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {877,851,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 877, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F818_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F818_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {879,839,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 879, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F819_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {881,836,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 881, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F820_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F820_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {883,863,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 883, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F821_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F821_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {885,860,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 885, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F822_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F822_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {887,854,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 887, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F823_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F823_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {889,899,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 889, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F824_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F824_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {891,845,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 891, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F825_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {893,833,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 893, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F826_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {895,830,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 895, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F827_4368_3483_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F827_4368(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {897,857,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 897, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}

char *(*R3493[31])();
void R3493_init () {
	R3493[0] = (char *(*)()) F797_4380;
	R3493[1] = (char *(*)()) F798_4380;
	R3493[2] = (char *(*)()) F799_4380;
	R3493[3] = (char *(*)()) F800_4380;
	R3493[4] = (char *(*)()) F801_4380;
	R3493[5] = (char *(*)()) F802_4380;
	R3493[6] = (char *(*)()) F803_4380;
	R3493[7] = (char *(*)()) F804_4380;
	R3493[8] = (char *(*)()) F805_4380;
	R3493[9] = (char *(*)()) F806_4380;
	R3493[10] = (char *(*)()) F807_4380;
	R3493[11] = (char *(*)()) F808_4380;
	R3493[12] = (char *(*)()) F809_4380;
	R3493[13] = (char *(*)()) F810_4380;
	R3493[14] = (char *(*)()) F811_4380;
	R3493[15] = (char *(*)()) F812_4380;
	R3493[16] = (char *(*)()) F813_4380;
	R3493[17] = (char *(*)()) F814_4380;
	R3493[18] = (char *(*)()) F815_4380;
	R3493[19] = (char *(*)()) F816_4380;
	R3493[20] = (char *(*)()) F817_4380;
	R3493[21] = (char *(*)()) F818_4380;
	R3493[22] = (char *(*)()) F819_4380;
	R3493[23] = (char *(*)()) F820_4380;
	R3493[24] = (char *(*)()) F821_4380;
	R3493[25] = (char *(*)()) F822_4380;
	R3493[26] = (char *(*)()) F823_4380;
	R3493[27] = (char *(*)()) F824_4380;
	R3493[28] = (char *(*)()) F825_4380;
	R3493[29] = (char *(*)()) F826_4380;
	R3493[30] = (char *(*)()) F827_4380;
}

char *(*R3637[2])();
void R3637_init () {
	R3637[0] = (char *(*)()) F830_4591;
	R3637[1] = (char *(*)()) F831_4591;
}

char *(*R3638[2])();
void R3638_init () {
	R3638[0] = (char *(*)()) F830_4592;
	R3638[1] = (char *(*)()) F831_4592;
}

char *(*R3639[2])();
void R3639_init () {
	R3639[0] = (char *(*)()) F830_4593;
	R3639[1] = (char *(*)()) F831_4593;
}

char *(*R3640[2])();
void R3640_init () {
	R3640[0] = (char *(*)()) F830_4594;
	R3640[1] = (char *(*)()) F831_4594;
}

char *(*R3642[2])();
void R3642_init () {
	R3642[0] = (char *(*)()) F830_4596;
	R3642[1] = (char *(*)()) F831_4596;
}

char *(*R3688[2])();
void R3688_init () {
	R3688[0] = (char *(*)()) F833_4654;
	R3688[1] = (char *(*)()) F834_4654;
}

char *(*R3695[2])();
void R3695_init () {
	R3695[0] = (char *(*)()) F833_4658;
	R3695[1] = (char *(*)()) F834_4658;
}

char *(*R3722[2])();
void R3722_init () {
	R3722[0] = (char *(*)()) F836_4720;
	R3722[1] = (char *(*)()) F837_4720;
}

char *(*R3729[2])();
void R3729_init () {
	R3729[0] = (char *(*)()) F836_4724;
	R3729[1] = (char *(*)()) F837_4724;
}

char *(*R3743[2])();
void R3743_init () {
	R3743[0] = (char *(*)()) F839_4778;
	R3743[1] = (char *(*)()) F840_4778;
}

char *(*R3849[2])();
void R3849_init () {
	R3849[0] = (char *(*)()) F848_4934;
	R3849[1] = (char *(*)()) F849_4934;
}

char *(*R3850[2])();
void R3850_init () {
	R3850[0] = (char *(*)()) F848_4935;
	R3850[1] = (char *(*)()) F849_4935;
}

char *(*R3854[2])();
void R3854_init () {
	R3854[0] = (char *(*)()) F848_4939;
	R3854[1] = (char *(*)()) F849_4939;
}

char *(*R3905[2])();
void R3905_init () {
	R3905[0] = (char *(*)()) F851_5033;
	R3905[1] = (char *(*)()) F852_5033;
}

char *(*R3908[2])();
void R3908_init () {
	R3908[0] = (char *(*)()) F851_5036;
	R3908[1] = (char *(*)()) F852_5036;
}

char *(*R3961[2])();
void R3961_init () {
	R3961[0] = (char *(*)()) F854_5132;
	R3961[1] = (char *(*)()) F855_5132;
}

char *(*R3964[2])();
void R3964_init () {
	R3964[0] = (char *(*)()) F854_5135;
	R3964[1] = (char *(*)()) F855_5135;
}

char *(*R4014[2])();
void R4014_init () {
	R4014[0] = (char *(*)()) F857_5228;
	R4014[1] = (char *(*)()) F858_5228;
}

char *(*R4017[2])();
void R4017_init () {
	R4017[0] = (char *(*)()) F857_5231;
	R4017[1] = (char *(*)()) F858_5231;
}

char *(*R4020[2])();
void R4020_init () {
	R4020[0] = (char *(*)()) F857_5234;
	R4020[1] = (char *(*)()) F858_5234;
}

char *(*R4074[2])();
void R4074_init () {
	R4074[0] = (char *(*)()) F860_5328;
	R4074[1] = (char *(*)()) F861_5328;
}

char *(*R4120[2])();
void R4120_init () {
	R4120[0] = (char *(*)()) F863_5416;
	R4120[1] = (char *(*)()) F864_5416;
}

char *(*R4121[2])();
void R4121_init () {
	R4121[0] = (char *(*)()) F863_5417;
	R4121[1] = (char *(*)()) F864_5417;
}

char *(*R4123[2])();
void R4123_init () {
	R4123[0] = (char *(*)()) F863_5419;
	R4123[1] = (char *(*)()) F864_5419;
}

char *(*R4126[2])();
void R4126_init () {
	R4126[0] = (char *(*)()) F863_5422;
	R4126[1] = (char *(*)()) F864_5422;
}

char *(*R4127[2])();
void R4127_init () {
	R4127[0] = (char *(*)()) F863_5423;
	R4127[1] = (char *(*)()) F864_5423;
}

char *(*R4175[2])();
void R4175_init () {
	R4175[0] = (char *(*)()) F866_5513;
	R4175[1] = (char *(*)()) F867_5513;
}

char *(*R4176[2])();
void R4176_init () {
	R4176[0] = (char *(*)()) F866_5514;
	R4176[1] = (char *(*)()) F867_5514;
}

char *(*R4179[2])();
void R4179_init () {
	R4179[0] = (char *(*)()) F866_5517;
	R4179[1] = (char *(*)()) F867_5517;
}

char *(*R4278[6])();
void R4278_init () {
	{long i; for (i = 0; i < 3; i++) R4278[i] = (char *(*)()) F909_5744;}
	{long i; for (i = 4; i < 6; i++) R4278[i] = (char *(*)()) F913_5942;}
}

char *(*R4280[6])();
void R4280_init () {
	R4280[0] = (char *(*)()) F910_5804;
	{long i; for (i = 1; i < 3; i++) R4280[i] = (char *(*)()) F911_5826;}
	R4280[4] = (char *(*)()) F914_6003;
	R4280[5] = (char *(*)()) F915_6026;
}

char *(*R4281[6])();
void R4281_init () {
	R4281[0] = (char *(*)()) F910_5803;
	{long i; for (i = 1; i < 3; i++) R4281[i] = (char *(*)()) F911_5825;}
	R4281[4] = (char *(*)()) F914_6001;
	R4281[5] = (char *(*)()) F915_6024;
}

char *(*R4282[6])();
void R4282_init () {
	{long i; for (i = 0; i < 3; i++) R4282[i] = (char *(*)()) F906_5617;}
	{long i; for (i = 4; i < 6; i++) R4282[i] = (char *(*)()) F913_5954;}
}

char *(*R4295[6])();
void R4295_init () {
	R4295[0] = (char *(*)()) F910_5813;
	{long i; for (i = 1; i < 3; i++) R4295[i] = (char *(*)()) F506_2965;}
	R4295[4] = (char *(*)()) F914_6013;
	R4295[5] = (char *(*)()) F502_2965;
}

char *(*R4317[6])();
void R4317_init () {
	{long i; for (i = 0; i < 3; i++) R4317[i] = (char *(*)()) F909_5766;}
	{long i; for (i = 4; i < 6; i++) R4317[i] = (char *(*)()) F913_5963;}
}

char *(*R4318[6])();
void R4318_init () {
	{long i; for (i = 0; i < 3; i++) R4318[i] = (char *(*)()) F909_5765;}
	{long i; for (i = 4; i < 6; i++) R4318[i] = (char *(*)()) F913_5962;}
}

char *(*R4339[6])();
void R4339_init () {
	R4339[0] = (char *(*)()) F910_5809;
	{long i; for (i = 1; i < 3; i++) R4339[i] = (char *(*)()) F911_5892;}
	R4339[4] = (char *(*)()) F914_6008;
	R4339[5] = (char *(*)()) F915_6092;
}

char *(*R4358[6])();
void R4358_init () {
	R4358[0] = (char *(*)()) F910_5811;
	{long i; for (i = 1; i < 3; i++) R4358[i] = (char *(*)()) F911_5904;}
	R4358[4] = (char *(*)()) F914_6010;
	R4358[5] = (char *(*)()) F915_6104;
}

char *(*R4362[6])();
void R4362_init () {
	R4362[0] = (char *(*)()) F910_5815;
	{long i; for (i = 1; i < 3; i++) R4362[i] = (char *(*)()) F911_5908;}
	R4362[4] = (char *(*)()) F914_6014;
	R4362[5] = (char *(*)()) F915_6107;
}

char *(*R4373[5])();
void R4373_init () {
	{long i; for (i = 0; i < 2; i++) R4373[i] = (char *(*)()) F911_5906;}
	R4373[4] = (char *(*)()) F915_6106;
}

char *(*R4376[5])();
void R4376_init () {
	{long i; for (i = 0; i < 2; i++) R4376[i] = (char *(*)()) F911_5845;}
	R4376[4] = (char *(*)()) F915_6045;
}

char *(*R4398[5])();
void R4398_init () {
	{long i; for (i = 0; i < 2; i++) R4398[i] = (char *(*)()) F911_5841;}
	R4398[4] = (char *(*)()) F915_6041;
}

char *(*R4399[5])();
void R4399_init () {
	{long i; for (i = 0; i < 2; i++) R4399[i] = (char *(*)()) F911_5842;}
	R4399[4] = (char *(*)()) F915_6042;
}

char *(*R4406[5])();
void R4406_init () {
	{long i; for (i = 0; i < 2; i++) R4406[i] = (char *(*)()) F911_5889;}
	R4406[4] = (char *(*)()) F915_6089;
}

char *(*R4438[3])();
void R4438_init () {
	R4438[0] = (char *(*)()) F910_5817;
	{long i; for (i = 1; i < 3; i++) R4438[i] = (char *(*)()) F909_5796;}
}

char *(*R4520[2])();
void R4520_init () {
	R4520[0] = (char *(*)()) F914_6007;
	R4520[1] = (char *(*)()) F915_6102;
}

char *(*R4526[2])();
void R4526_init () {
	R4526[0] = (char *(*)()) F914_6016;
	R4526[1] = (char *(*)()) F913_5993;
}

char *(*R5084[4])();
void R5084_init () {
	{long i; for (i = 0; i < 2; i++) R5084[i] = (char *(*)()) F942_6696;}
	{long i; for (i = 2; i < 4; i++) R5084[i] = (char *(*)()) F945_6725;}
}

EIF_TYPE_INDEX *Y5086_gen_type [5];
EIF_TYPE_INDEX Y5086 [5];
void Y5086_init (void)
{
	egc_routines_types [5086] = Y5086;
	egc_routines_gen_types [5086] = Y5086_gen_type;
	egc_routines_offset [5086] = 941;
	Y5086[0] = 107;
	Y5086[1] = 108;
	Y5086[2] = 109;
	Y5086[3] = 110;
	Y5086[4] = 111;
}

char *(*R5087[4])();
void R5087_init () {
	{long i; for (i = 0; i < 2; i++) R5087[i] = (char *(*)()) F942_6699;}
	R5087[2] = (char *(*)()) F945_6721;
	R5087[3] = (char *(*)()) F946_6729;
}

char *(*R5096[4])();
void R5096_init () {
	{long i; for (i = 0; i < 2; i++) R5096[i] = (char *(*)()) F942_6708;}
	{long i; for (i = 2; i < 4; i++) R5096[i] = (char *(*)()) F945_6726;}
}
char *(*R2[946])();
void R2_init () {}
char *(*R6[946])();
void R6_init () {}

char *(*R3[946])();
void R3_init () {
	R3[232] = (char *(*)()) F233_2328;
	R3[233] = (char *(*)()) F234_2343;
	R3[234] = (char *(*)()) F235_2441;
	R3[235] = (char *(*)()) F236_2479;
	R3[238] = (char *(*)()) F238_2627;
	{long i; for (i = 563; i < 565; i++) R3[i] = (char *(*)()) F237_2540;}
	R3[916] = (char *(*)()) F917_6138;
	R3[930] = (char *(*)()) F931_6447;
}

char *(*R4[946])();
void R4_init () {
	R4[2] = (char *(*)()) F1_15;
	{long i; for (i = 7; i < 9; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 10; i < 12; i++) R4[i] = (char *(*)()) F1_15;}
	R4[14] = (char *(*)()) F1_15;
	{long i; for (i = 27; i < 29; i++) R4[i] = (char *(*)()) F1_15;}
	R4[30] = (char *(*)()) F1_15;
	R4[39] = (char *(*)()) F1_15;
	{long i; for (i = 42; i < 53; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 56; i < 68; i++) R4[i] = (char *(*)()) F1_15;}
	R4[69] = (char *(*)()) F1_15;
	R4[75] = (char *(*)()) F1_15;
	R4[92] = (char *(*)()) F1_15;
	{long i; for (i = 94; i < 96; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 97; i < 99; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 101; i < 103; i++) R4[i] = (char *(*)()) F1_15;}
	R4[106] = (char *(*)()) F1_15;
	{long i; for (i = 108; i < 112; i++) R4[i] = (char *(*)()) F1_15;}
	R4[113] = (char *(*)()) F1_15;
	{long i; for (i = 116; i < 120; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 121; i < 124; i++) R4[i] = (char *(*)()) F1_15;}
	R4[127] = (char *(*)()) F1_15;
	{long i; for (i = 129; i < 132; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 133; i < 136; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 137; i < 139; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 141; i < 143; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 144; i < 147; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 148; i < 152; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 153; i < 155; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 156; i < 162; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 163; i < 165; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 166; i < 170; i++) R4[i] = (char *(*)()) F1_15;}
	R4[175] = (char *(*)()) F1_15;
	R4[177] = (char *(*)()) F1_15;
	{long i; for (i = 179; i < 181; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 183; i < 185; i++) R4[i] = (char *(*)()) F1_15;}
	R4[187] = (char *(*)()) F1_15;
	R4[205] = (char *(*)()) F1_15;
	R4[206] = (char *(*)()) F207_2227;
	R4[208] = (char *(*)()) F1_15;
	R4[210] = (char *(*)()) F1_15;
	{long i; for (i = 232; i < 234; i++) R4[i] = (char *(*)()) F1_15;}
	R4[234] = (char *(*)()) F235_2360;
	R4[235] = (char *(*)()) F1_15;
	R4[238] = (char *(*)()) F1_15;
	R4[252] = (char *(*)()) F1_15;
	{long i; for (i = 296; i < 305; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 317; i < 329; i++) R4[i] = (char *(*)()) F1_15;}
	R4[499] = (char *(*)()) F1_15;
	{long i; for (i = 563; i < 565; i++) R4[i] = (char *(*)()) F1_15;}
	R4[590] = (char *(*)()) F591_3435;
	R4[591] = (char *(*)()) F592_3435;
	R4[592] = (char *(*)()) F593_3435;
	R4[593] = (char *(*)()) F594_3435;
	R4[594] = (char *(*)()) F595_3435;
	R4[595] = (char *(*)()) F596_3435;
	R4[596] = (char *(*)()) F597_3435;
	R4[597] = (char *(*)()) F598_3435;
	R4[598] = (char *(*)()) F599_3435;
	R4[599] = (char *(*)()) F600_3435;
	R4[600] = (char *(*)()) F601_3435;
	R4[601] = (char *(*)()) F602_3435;
	R4[652] = (char *(*)()) F653_3536;
	R4[653] = (char *(*)()) F654_3536;
	R4[655] = (char *(*)()) F653_3536;
	R4[657] = (char *(*)()) F1_15;
	{long i; for (i = 659; i < 661; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 664; i < 670; i++) R4[i] = (char *(*)()) F1_15;}
	R4[672] = (char *(*)()) F673_3743;
	R4[673] = (char *(*)()) F674_3743;
	R4[674] = (char *(*)()) F675_3743;
	R4[675] = (char *(*)()) F676_3743;
	R4[676] = (char *(*)()) F677_3743;
	R4[677] = (char *(*)()) F678_3743;
	R4[678] = (char *(*)()) F679_3743;
	R4[679] = (char *(*)()) F680_3743;
	R4[680] = (char *(*)()) F681_3743;
	R4[681] = (char *(*)()) F682_3743;
	R4[682] = (char *(*)()) F683_3743;
	R4[683] = (char *(*)()) F684_3743;
	R4[685] = (char *(*)()) F686_3833;
	R4[686] = (char *(*)()) F687_3833;
	R4[687] = (char *(*)()) F688_3833;
	R4[688] = (char *(*)()) F689_3833;
	R4[689] = (char *(*)()) F690_3833;
	R4[690] = (char *(*)()) F691_3833;
	R4[691] = (char *(*)()) F686_3833;
	R4[692] = (char *(*)()) F687_3833;
	R4[693] = (char *(*)()) F686_3833;
	R4[695] = (char *(*)()) F1_15;
	{long i; for (i = 698; i < 710; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 759; i < 770; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 771; i < 773; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 774; i < 776; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 777; i < 779; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 780; i < 782; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 783; i < 785; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 786; i < 794; i++) R4[i] = (char *(*)()) F1_15;}
	R4[795] = (char *(*)()) F796_4327;
	{long i; for (i = 796; i < 828; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 829; i < 831; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 832; i < 834; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 835; i < 837; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 838; i < 840; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 841; i < 843; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 844; i < 846; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 847; i < 849; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 850; i < 852; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 853; i < 855; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 856; i < 858; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 859; i < 861; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 862; i < 864; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 865; i < 867; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 868; i < 900; i++) R4[i] = (char *(*)()) F1_15;}
	R4[909] = (char *(*)()) F910_5800;
	{long i; for (i = 910; i < 912; i++) R4[i] = (char *(*)()) F909_5784;}
	R4[913] = (char *(*)()) F914_6000;
	R4[914] = (char *(*)()) F913_5981;
	{long i; for (i = 915; i < 918; i++) R4[i] = (char *(*)()) F1_15;}
	R4[919] = (char *(*)()) F1_15;
	{long i; for (i = 924; i < 926; i++) R4[i] = (char *(*)()) F1_15;}
	R4[927] = (char *(*)()) F1_15;
	{long i; for (i = 930; i < 932; i++) R4[i] = (char *(*)()) F1_15;}
	R4[934] = (char *(*)()) F1_15;
	R4[936] = (char *(*)()) F1_15;
	R4[939] = (char *(*)()) F940_6656;
	R4[940] = (char *(*)()) F1_15;
	{long i; for (i = 942; i < 946; i++) R4[i] = (char *(*)()) F1_15;}
}

char *(*R5[946])();
void R5_init () {
	R5[2] = (char *(*)()) F1_8;
	{long i; for (i = 7; i < 9; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 10; i < 12; i++) R5[i] = (char *(*)()) F1_8;}
	R5[14] = (char *(*)()) F1_8;
	{long i; for (i = 27; i < 29; i++) R5[i] = (char *(*)()) F1_8;}
	R5[30] = (char *(*)()) F1_8;
	R5[39] = (char *(*)()) F1_8;
	{long i; for (i = 42; i < 53; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 56; i < 68; i++) R5[i] = (char *(*)()) F1_8;}
	R5[69] = (char *(*)()) F1_8;
	R5[75] = (char *(*)()) F1_8;
	R5[92] = (char *(*)()) F1_8;
	{long i; for (i = 94; i < 96; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 97; i < 99; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 101; i < 103; i++) R5[i] = (char *(*)()) F1_8;}
	R5[106] = (char *(*)()) F1_8;
	{long i; for (i = 108; i < 112; i++) R5[i] = (char *(*)()) F1_8;}
	R5[113] = (char *(*)()) F1_8;
	{long i; for (i = 116; i < 120; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 121; i < 124; i++) R5[i] = (char *(*)()) F1_8;}
	R5[127] = (char *(*)()) F1_8;
	{long i; for (i = 129; i < 132; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 133; i < 136; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 137; i < 139; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 143; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 144; i < 147; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 148; i < 152; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 153; i < 155; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 156; i < 162; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 163; i < 165; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 166; i < 170; i++) R5[i] = (char *(*)()) F1_8;}
	R5[175] = (char *(*)()) F176_1779;
	R5[177] = (char *(*)()) F178_1819;
	R5[179] = (char *(*)()) F179_1828;
	R5[180] = (char *(*)()) F181_1838;
	{long i; for (i = 183; i < 185; i++) R5[i] = (char *(*)()) F1_8;}
	R5[187] = (char *(*)()) F1_8;
	R5[205] = (char *(*)()) F206_2177;
	R5[206] = (char *(*)()) F207_2226;
	R5[208] = (char *(*)()) F1_8;
	R5[210] = (char *(*)()) F1_8;
	{long i; for (i = 232; i < 234; i++) R5[i] = (char *(*)()) F1_8;}
	R5[234] = (char *(*)()) F235_2359;
	R5[235] = (char *(*)()) F1_8;
	R5[238] = (char *(*)()) F1_8;
	R5[252] = (char *(*)()) F1_8;
	{long i; for (i = 296; i < 305; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 317; i < 329; i++) R5[i] = (char *(*)()) F1_8;}
	R5[499] = (char *(*)()) F1_8;
	{long i; for (i = 563; i < 565; i++) R5[i] = (char *(*)()) F1_8;}
	R5[590] = (char *(*)()) F591_3397;
	R5[591] = (char *(*)()) F592_3397;
	R5[592] = (char *(*)()) F593_3397;
	R5[593] = (char *(*)()) F594_3397;
	R5[594] = (char *(*)()) F595_3397;
	R5[595] = (char *(*)()) F596_3397;
	R5[596] = (char *(*)()) F597_3397;
	R5[597] = (char *(*)()) F598_3397;
	R5[598] = (char *(*)()) F599_3397;
	R5[599] = (char *(*)()) F600_3397;
	R5[600] = (char *(*)()) F601_3397;
	R5[601] = (char *(*)()) F602_3397;
	R5[652] = (char *(*)()) F627_3478;
	R5[653] = (char *(*)()) F631_3478;
	R5[655] = (char *(*)()) F627_3478;
	R5[657] = (char *(*)()) F1_8;
	{long i; for (i = 659; i < 661; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 664; i < 670; i++) R5[i] = (char *(*)()) F1_8;}
	R5[672] = (char *(*)()) F673_3716;
	R5[673] = (char *(*)()) F674_3716;
	R5[674] = (char *(*)()) F675_3716;
	R5[675] = (char *(*)()) F676_3716;
	R5[676] = (char *(*)()) F677_3716;
	R5[677] = (char *(*)()) F678_3716;
	R5[678] = (char *(*)()) F679_3716;
	R5[679] = (char *(*)()) F680_3716;
	R5[680] = (char *(*)()) F681_3716;
	R5[681] = (char *(*)()) F682_3716;
	R5[682] = (char *(*)()) F683_3716;
	R5[683] = (char *(*)()) F684_3716;
	R5[685] = (char *(*)()) F686_3799;
	R5[686] = (char *(*)()) F687_3799;
	R5[687] = (char *(*)()) F688_3799;
	R5[688] = (char *(*)()) F689_3799;
	R5[689] = (char *(*)()) F690_3799;
	R5[690] = (char *(*)()) F691_3799;
	R5[691] = (char *(*)()) F692_3893;
	R5[692] = (char *(*)()) F693_3893;
	R5[693] = (char *(*)()) F686_3799;
	R5[695] = (char *(*)()) F1_8;
	{long i; for (i = 698; i < 710; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 759; i < 770; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 771; i < 773; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 774; i < 776; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 777; i < 779; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 780; i < 782; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 783; i < 785; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 786; i < 794; i++) R5[i] = (char *(*)()) F1_8;}
	R5[795] = (char *(*)()) F796_4324;
	R5[796] = (char *(*)()) F797_4361;
	R5[797] = (char *(*)()) F798_4361;
	R5[798] = (char *(*)()) F799_4361;
	R5[799] = (char *(*)()) F800_4361;
	R5[800] = (char *(*)()) F801_4361;
	R5[801] = (char *(*)()) F802_4361;
	R5[802] = (char *(*)()) F803_4361;
	R5[803] = (char *(*)()) F804_4361;
	R5[804] = (char *(*)()) F805_4361;
	R5[805] = (char *(*)()) F806_4361;
	R5[806] = (char *(*)()) F807_4361;
	R5[807] = (char *(*)()) F808_4361;
	R5[808] = (char *(*)()) F809_4361;
	R5[809] = (char *(*)()) F810_4361;
	R5[810] = (char *(*)()) F811_4361;
	R5[811] = (char *(*)()) F812_4361;
	R5[812] = (char *(*)()) F813_4361;
	R5[813] = (char *(*)()) F814_4361;
	R5[814] = (char *(*)()) F815_4361;
	R5[815] = (char *(*)()) F816_4361;
	R5[816] = (char *(*)()) F817_4361;
	R5[817] = (char *(*)()) F818_4361;
	R5[818] = (char *(*)()) F819_4361;
	R5[819] = (char *(*)()) F820_4361;
	R5[820] = (char *(*)()) F821_4361;
	R5[821] = (char *(*)()) F822_4361;
	R5[822] = (char *(*)()) F823_4361;
	R5[823] = (char *(*)()) F824_4361;
	R5[824] = (char *(*)()) F825_4361;
	R5[825] = (char *(*)()) F826_4361;
	R5[826] = (char *(*)()) F827_4361;
	R5[827] = (char *(*)()) F828_4404;
	{long i; for (i = 829; i < 831; i++) R5[i] = (char *(*)()) F829_4522;}
	{long i; for (i = 832; i < 834; i++) R5[i] = (char *(*)()) F832_4621;}
	{long i; for (i = 835; i < 837; i++) R5[i] = (char *(*)()) F835_4687;}
	{long i; for (i = 838; i < 840; i++) R5[i] = (char *(*)()) F838_4748;}
	{long i; for (i = 841; i < 843; i++) R5[i] = (char *(*)()) F841_4788;}
	{long i; for (i = 844; i < 846; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 847; i < 849; i++) R5[i] = (char *(*)()) F847_4860;}
	{long i; for (i = 850; i < 852; i++) R5[i] = (char *(*)()) F850_4959;}
	{long i; for (i = 853; i < 855; i++) R5[i] = (char *(*)()) F853_5057;}
	{long i; for (i = 856; i < 858; i++) R5[i] = (char *(*)()) F856_5156;}
	{long i; for (i = 859; i < 861; i++) R5[i] = (char *(*)()) F859_5255;}
	{long i; for (i = 862; i < 864; i++) R5[i] = (char *(*)()) F862_5349;}
	{long i; for (i = 865; i < 867; i++) R5[i] = (char *(*)()) F865_5443;}
	{long i; for (i = 868; i < 900; i++) R5[i] = (char *(*)()) F868_5532;}
	{long i; for (i = 909; i < 912; i++) R5[i] = (char *(*)()) F909_5769;}
	{long i; for (i = 913; i < 915; i++) R5[i] = (char *(*)()) F913_5966;}
	{long i; for (i = 915; i < 918; i++) R5[i] = (char *(*)()) F1_8;}
	R5[919] = (char *(*)()) F1_8;
	{long i; for (i = 924; i < 926; i++) R5[i] = (char *(*)()) F1_8;}
	R5[927] = (char *(*)()) F1_8;
	{long i; for (i = 930; i < 932; i++) R5[i] = (char *(*)()) F1_8;}
	R5[934] = (char *(*)()) F177_1801;
	R5[936] = (char *(*)()) F177_1801;
	R5[939] = (char *(*)()) F940_6652;
	R5[940] = (char *(*)()) F1_8;
	{long i; for (i = 942; i < 946; i++) R5[i] = (char *(*)()) F1_8;}
}


#ifdef __cplusplus
}
#endif
