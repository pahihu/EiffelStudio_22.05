#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[944])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 7; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 8; i < 10; i++) R11[i] = (char *(*)()) F1_8;}
	R11[12] = (char *(*)()) F1_8;
	{long i; for (i = 25; i < 27; i++) R11[i] = (char *(*)()) F1_8;}
	R11[28] = (char *(*)()) F1_8;
	R11[37] = (char *(*)()) F1_8;
	{long i; for (i = 40; i < 51; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 54; i < 66; i++) R11[i] = (char *(*)()) F1_8;}
	R11[67] = (char *(*)()) F1_8;
	R11[73] = (char *(*)()) F1_8;
	R11[90] = (char *(*)()) F1_8;
	{long i; for (i = 92; i < 94; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 95; i < 97; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 99; i < 101; i++) R11[i] = (char *(*)()) F1_8;}
	R11[104] = (char *(*)()) F1_8;
	{long i; for (i = 106; i < 110; i++) R11[i] = (char *(*)()) F1_8;}
	R11[111] = (char *(*)()) F1_8;
	{long i; for (i = 114; i < 118; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 119; i < 122; i++) R11[i] = (char *(*)()) F1_8;}
	R11[125] = (char *(*)()) F1_8;
	{long i; for (i = 127; i < 130; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 131; i < 134; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 135; i < 137; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 139; i < 141; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 142; i < 145; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 146; i < 150; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 151; i < 153; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 154; i < 160; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 161; i < 163; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 164; i < 168; i++) R11[i] = (char *(*)()) F1_8;}
	R11[173] = (char *(*)()) F176_1779;
	R11[175] = (char *(*)()) F178_1819;
	R11[177] = (char *(*)()) F179_1828;
	R11[178] = (char *(*)()) F181_1838;
	{long i; for (i = 181; i < 183; i++) R11[i] = (char *(*)()) F1_8;}
	R11[185] = (char *(*)()) F1_8;
	R11[203] = (char *(*)()) F206_2177;
	R11[204] = (char *(*)()) F207_2226;
	R11[206] = (char *(*)()) F1_8;
	R11[208] = (char *(*)()) F1_8;
	{long i; for (i = 230; i < 232; i++) R11[i] = (char *(*)()) F1_8;}
	R11[232] = (char *(*)()) F235_2359;
	R11[233] = (char *(*)()) F1_8;
	R11[236] = (char *(*)()) F1_8;
	R11[250] = (char *(*)()) F1_8;
	{long i; for (i = 294; i < 303; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 315; i < 327; i++) R11[i] = (char *(*)()) F1_8;}
	R11[497] = (char *(*)()) F1_8;
	{long i; for (i = 561; i < 563; i++) R11[i] = (char *(*)()) F1_8;}
	R11[588] = (char *(*)()) F591_3397;
	R11[589] = (char *(*)()) F592_3397;
	R11[590] = (char *(*)()) F593_3397;
	R11[591] = (char *(*)()) F594_3397;
	R11[592] = (char *(*)()) F595_3397;
	R11[593] = (char *(*)()) F596_3397;
	R11[594] = (char *(*)()) F597_3397;
	R11[595] = (char *(*)()) F598_3397;
	R11[596] = (char *(*)()) F599_3397;
	R11[597] = (char *(*)()) F600_3397;
	R11[598] = (char *(*)()) F601_3397;
	R11[599] = (char *(*)()) F602_3397;
	R11[650] = (char *(*)()) F627_3478;
	R11[651] = (char *(*)()) F631_3478;
	R11[653] = (char *(*)()) F627_3478;
	R11[655] = (char *(*)()) F1_8;
	{long i; for (i = 657; i < 659; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 662; i < 668; i++) R11[i] = (char *(*)()) F1_8;}
	R11[670] = (char *(*)()) F673_3716;
	R11[671] = (char *(*)()) F674_3716;
	R11[672] = (char *(*)()) F675_3716;
	R11[673] = (char *(*)()) F676_3716;
	R11[674] = (char *(*)()) F677_3716;
	R11[675] = (char *(*)()) F678_3716;
	R11[676] = (char *(*)()) F679_3716;
	R11[677] = (char *(*)()) F680_3716;
	R11[678] = (char *(*)()) F681_3716;
	R11[679] = (char *(*)()) F682_3716;
	R11[680] = (char *(*)()) F683_3716;
	R11[681] = (char *(*)()) F684_3716;
	R11[683] = (char *(*)()) F686_3799;
	R11[684] = (char *(*)()) F687_3799;
	R11[685] = (char *(*)()) F688_3799;
	R11[686] = (char *(*)()) F689_3799;
	R11[687] = (char *(*)()) F690_3799;
	R11[688] = (char *(*)()) F691_3799;
	R11[689] = (char *(*)()) F692_3893;
	R11[690] = (char *(*)()) F693_3893;
	R11[691] = (char *(*)()) F686_3799;
	R11[693] = (char *(*)()) F1_8;
	{long i; for (i = 696; i < 708; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 757; i < 768; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 769; i < 771; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 772; i < 774; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 775; i < 777; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 778; i < 780; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 781; i < 783; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 784; i < 792; i++) R11[i] = (char *(*)()) F1_8;}
	R11[793] = (char *(*)()) F796_4324;
	R11[794] = (char *(*)()) F797_4361;
	R11[795] = (char *(*)()) F798_4361;
	R11[796] = (char *(*)()) F799_4361;
	R11[797] = (char *(*)()) F800_4361;
	R11[798] = (char *(*)()) F801_4361;
	R11[799] = (char *(*)()) F802_4361;
	R11[800] = (char *(*)()) F803_4361;
	R11[801] = (char *(*)()) F804_4361;
	R11[802] = (char *(*)()) F805_4361;
	R11[803] = (char *(*)()) F806_4361;
	R11[804] = (char *(*)()) F807_4361;
	R11[805] = (char *(*)()) F808_4361;
	R11[806] = (char *(*)()) F809_4361;
	R11[807] = (char *(*)()) F810_4361;
	R11[808] = (char *(*)()) F811_4361;
	R11[809] = (char *(*)()) F812_4361;
	R11[810] = (char *(*)()) F813_4361;
	R11[811] = (char *(*)()) F814_4361;
	R11[812] = (char *(*)()) F815_4361;
	R11[813] = (char *(*)()) F816_4361;
	R11[814] = (char *(*)()) F817_4361;
	R11[815] = (char *(*)()) F818_4361;
	R11[816] = (char *(*)()) F819_4361;
	R11[817] = (char *(*)()) F820_4361;
	R11[818] = (char *(*)()) F821_4361;
	R11[819] = (char *(*)()) F822_4361;
	R11[820] = (char *(*)()) F823_4361;
	R11[821] = (char *(*)()) F824_4361;
	R11[822] = (char *(*)()) F825_4361;
	R11[823] = (char *(*)()) F826_4361;
	R11[824] = (char *(*)()) F827_4361;
	R11[825] = (char *(*)()) F828_4404;
	{long i; for (i = 827; i < 829; i++) R11[i] = (char *(*)()) F829_4522;}
	{long i; for (i = 830; i < 832; i++) R11[i] = (char *(*)()) F832_4621;}
	{long i; for (i = 833; i < 835; i++) R11[i] = (char *(*)()) F835_4687;}
	{long i; for (i = 836; i < 838; i++) R11[i] = (char *(*)()) F838_4748;}
	{long i; for (i = 839; i < 841; i++) R11[i] = (char *(*)()) F841_4788;}
	{long i; for (i = 842; i < 844; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 845; i < 847; i++) R11[i] = (char *(*)()) F847_4860;}
	{long i; for (i = 848; i < 850; i++) R11[i] = (char *(*)()) F850_4959;}
	{long i; for (i = 851; i < 853; i++) R11[i] = (char *(*)()) F853_5057;}
	{long i; for (i = 854; i < 856; i++) R11[i] = (char *(*)()) F856_5156;}
	{long i; for (i = 857; i < 859; i++) R11[i] = (char *(*)()) F859_5255;}
	{long i; for (i = 860; i < 862; i++) R11[i] = (char *(*)()) F862_5349;}
	{long i; for (i = 863; i < 865; i++) R11[i] = (char *(*)()) F865_5443;}
	{long i; for (i = 866; i < 898; i++) R11[i] = (char *(*)()) F868_5532;}
	{long i; for (i = 907; i < 910; i++) R11[i] = (char *(*)()) F909_5769;}
	{long i; for (i = 911; i < 913; i++) R11[i] = (char *(*)()) F913_5966;}
	{long i; for (i = 913; i < 916; i++) R11[i] = (char *(*)()) F1_8;}
	R11[917] = (char *(*)()) F1_8;
	{long i; for (i = 922; i < 924; i++) R11[i] = (char *(*)()) F1_8;}
	R11[925] = (char *(*)()) F1_8;
	{long i; for (i = 928; i < 930; i++) R11[i] = (char *(*)()) F1_8;}
	R11[932] = (char *(*)()) F177_1801;
	R11[934] = (char *(*)()) F177_1801;
	R11[937] = (char *(*)()) F940_6652;
	R11[938] = (char *(*)()) F1_8;
	{long i; for (i = 940; i < 944; i++) R11[i] = (char *(*)()) F1_8;}
}

char *(*R605[8])();
void R605_init () {
	R605[0] = (char *(*)()) F44_622;
	R605[1] = (char *(*)()) F45_622_605_1;
	R605[2] = (char *(*)()) F46_622_605_1;
	R605[3] = (char *(*)()) F47_622_605_1;
	R605[4] = (char *(*)()) F48_622_605_1;
	R605[5] = (char *(*)()) F44_622;
	R605[6] = (char *(*)()) F45_622_605_1;
	R605[7] = (char *(*)()) F44_622;
}
static EIF_REFERENCE F45_622_605_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F45_622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F46_622_605_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F46_622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F47_622_605_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F47_622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F48_622_605_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F48_622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R606[8])();
void R606_init () {
	R606[0] = (char *(*)()) F44_623;
	R606[1] = (char *(*)()) F45_623_606_4;
	R606[2] = (char *(*)()) F46_623_606_4;
	R606[3] = (char *(*)()) F47_623_606_4;
	R606[4] = (char *(*)()) F48_623_606_4;
	R606[5] = (char *(*)()) F44_623;
	R606[6] = (char *(*)()) F45_623_606_4;
	R606[7] = (char *(*)()) F44_623;
}
static void F45_623_606_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F45_623(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F46_623_606_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F46_623(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F47_623_606_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F47_623(Current, *(EIF_BOOLEAN *)arg1);
}
static void F48_623_606_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F48_623(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R610[3])();
void R610_init () {
	R610[0] = (char *(*)()) F49_626;
	R610[1] = (char *(*)()) F50_626;
	R610[2] = (char *(*)()) F51_629;
}

char *(*R712[738])();
void R712_init () {
	R712[0] = (char *(*)()) F57_746;
	R712[1] = (char *(*)()) F58_752;
	R712[2] = (char *(*)()) F59_757;
	R712[3] = (char *(*)()) F60_762;
	R712[4] = (char *(*)()) F61_766;
	R712[5] = (char *(*)()) F62_771;
	R712[6] = (char *(*)()) F63_776;
	R712[7] = (char *(*)()) F64_781;
	R712[8] = (char *(*)()) F65_786;
	R712[9] = (char *(*)()) F66_791;
	R712[10] = (char *(*)()) F67_797;
	R712[11] = (char *(*)()) F68_813;
	R712[50] = (char *(*)()) F107_1355;
	R712[128] = (char *(*)()) F185_1897;
	R712[608] = (char *(*)()) F665_3616;
	R712[609] = (char *(*)()) F666_3621;
	R712[610] = (char *(*)()) F667_3627;
	R712[611] = (char *(*)()) F668_3633;
	R712[612] = (char *(*)()) F669_3638;
	R712[703] = (char *(*)()) F760_4136;
	R712[704] = (char *(*)()) F761_4140;
	R712[705] = (char *(*)()) F762_4144;
	R712[707] = (char *(*)()) F764_4151;
	R712[708] = (char *(*)()) F765_4158;
	R712[709] = (char *(*)()) F766_4165;
	R712[710] = (char *(*)()) F767_4172;
	R712[711] = (char *(*)()) F768_4181;
	R712[712] = (char *(*)()) F69_818;
	{long i; for (i = 715; i < 717; i++) R712[i] = (char *(*)()) F771_4194;}
	{long i; for (i = 718; i < 720; i++) R712[i] = (char *(*)()) F771_4194;}
	{long i; for (i = 721; i < 723; i++) R712[i] = (char *(*)()) F777_4216;}
	{long i; for (i = 724; i < 726; i++) R712[i] = (char *(*)()) F780_4227;}
	{long i; for (i = 730; i < 733; i++) R712[i] = (char *(*)()) F69_818;}
	R712[733] = (char *(*)()) F790_4261;
	R712[734] = (char *(*)()) F791_4267;
	{long i; for (i = 735; i < 738; i++) R712[i] = (char *(*)()) F69_818;}
}

char *(*R713[738])();
void R713_init () {
	R713[0] = (char *(*)()) F57_747;
	R713[1] = (char *(*)()) F58_753;
	R713[2] = (char *(*)()) F59_758;
	R713[3] = (char *(*)()) F60_763;
	R713[4] = (char *(*)()) F61_767;
	R713[5] = (char *(*)()) F62_772;
	R713[6] = (char *(*)()) F63_777;
	R713[7] = (char *(*)()) F64_782;
	R713[8] = (char *(*)()) F65_787;
	R713[9] = (char *(*)()) F66_792;
	R713[10] = (char *(*)()) F67_798;
	R713[11] = (char *(*)()) F68_814;
	R713[50] = (char *(*)()) F107_1356;
	R713[128] = (char *(*)()) F185_1898;
	R713[608] = (char *(*)()) F665_3617;
	R713[609] = (char *(*)()) F666_3622;
	R713[610] = (char *(*)()) F667_3628;
	R713[611] = (char *(*)()) F668_3634;
	R713[612] = (char *(*)()) F669_3639;
	R713[703] = (char *(*)()) F760_4137;
	R713[704] = (char *(*)()) F761_4141;
	R713[705] = (char *(*)()) F762_4145;
	R713[707] = (char *(*)()) F764_4152;
	R713[708] = (char *(*)()) F765_4159;
	R713[709] = (char *(*)()) F766_4166;
	R713[710] = (char *(*)()) F767_4173;
	R713[711] = (char *(*)()) F768_4182;
	R713[712] = (char *(*)()) F769_4186;
	{long i; for (i = 715; i < 717; i++) R713[i] = (char *(*)()) F771_4196;}
	{long i; for (i = 718; i < 720; i++) R713[i] = (char *(*)()) F771_4196;}
	{long i; for (i = 721; i < 723; i++) R713[i] = (char *(*)()) F777_4217;}
	{long i; for (i = 724; i < 726; i++) R713[i] = (char *(*)()) F780_4228;}
	{long i; for (i = 730; i < 733; i++) R713[i] = (char *(*)()) F786_4254;}
	R713[733] = (char *(*)()) F790_4264;
	R713[734] = (char *(*)()) F791_4270;
	{long i; for (i = 735; i < 738; i++) R713[i] = (char *(*)()) F786_4254;}
}

char *(*R714[738])();
void R714_init () {
	R714[0] = (char *(*)()) F57_748;
	R714[1] = (char *(*)()) F58_754;
	R714[2] = (char *(*)()) F59_759;
	R714[3] = (char *(*)()) F60_764;
	R714[4] = (char *(*)()) F61_768;
	R714[5] = (char *(*)()) F62_773;
	R714[6] = (char *(*)()) F63_778;
	R714[7] = (char *(*)()) F64_783;
	R714[8] = (char *(*)()) F65_788;
	R714[9] = (char *(*)()) F66_793;
	R714[10] = (char *(*)()) F67_799;
	R714[11] = (char *(*)()) F68_815;
	R714[50] = (char *(*)()) F107_1357;
	R714[128] = (char *(*)()) F185_1899;
	R714[608] = (char *(*)()) F665_3618;
	R714[609] = (char *(*)()) F666_3623;
	R714[610] = (char *(*)()) F667_3629;
	R714[611] = (char *(*)()) F668_3635;
	R714[612] = (char *(*)()) F669_3640;
	R714[703] = (char *(*)()) F760_4138;
	R714[704] = (char *(*)()) F761_4142;
	R714[705] = (char *(*)()) F762_4146;
	R714[707] = (char *(*)()) F764_4153;
	R714[708] = (char *(*)()) F765_4160;
	R714[709] = (char *(*)()) F766_4167;
	R714[710] = (char *(*)()) F767_4174;
	R714[711] = (char *(*)()) F768_4183;
	R714[712] = (char *(*)()) F69_820;
	{long i; for (i = 715; i < 717; i++) R714[i] = (char *(*)()) F771_4198;}
	{long i; for (i = 718; i < 720; i++) R714[i] = (char *(*)()) F771_4198;}
	{long i; for (i = 721; i < 723; i++) R714[i] = (char *(*)()) F777_4218;}
	{long i; for (i = 724; i < 726; i++) R714[i] = (char *(*)()) F780_4229;}
	{long i; for (i = 730; i < 738; i++) R714[i] = (char *(*)()) F69_820;}
}

char *(*R715[738])();
void R715_init () {
	R715[0] = (char *(*)()) F57_749;
	R715[1] = (char *(*)()) F58_755;
	R715[2] = (char *(*)()) F59_760;
	R715[3] = (char *(*)()) F60_765;
	R715[4] = (char *(*)()) F61_769;
	R715[5] = (char *(*)()) F62_774;
	R715[6] = (char *(*)()) F63_779;
	R715[7] = (char *(*)()) F64_784;
	R715[8] = (char *(*)()) F65_789;
	R715[9] = (char *(*)()) F66_794;
	R715[10] = (char *(*)()) F67_800;
	R715[11] = (char *(*)()) F68_816;
	R715[50] = (char *(*)()) F107_1358;
	R715[128] = (char *(*)()) F185_1900;
	R715[608] = (char *(*)()) F665_3619;
	R715[609] = (char *(*)()) F666_3624;
	R715[610] = (char *(*)()) F667_3630;
	R715[611] = (char *(*)()) F668_3636;
	R715[612] = (char *(*)()) F669_3641;
	R715[703] = (char *(*)()) F760_4139;
	R715[704] = (char *(*)()) F761_4143;
	R715[705] = (char *(*)()) F762_4147;
	R715[707] = (char *(*)()) F764_4154;
	R715[708] = (char *(*)()) F765_4161;
	R715[709] = (char *(*)()) F766_4168;
	R715[710] = (char *(*)()) F767_4175;
	R715[711] = (char *(*)()) F768_4184;
	R715[712] = (char *(*)()) F69_821;
	{long i; for (i = 715; i < 717; i++) R715[i] = (char *(*)()) F771_4199;}
	{long i; for (i = 718; i < 720; i++) R715[i] = (char *(*)()) F771_4199;}
	{long i; for (i = 721; i < 723; i++) R715[i] = (char *(*)()) F777_4219;}
	{long i; for (i = 724; i < 726; i++) R715[i] = (char *(*)()) F780_4230;}
	{long i; for (i = 730; i < 738; i++) R715[i] = (char *(*)()) F69_821;}
}

char *(*R716[738])();
void R716_init () {
	{long i; for (i = 0; i < 4; i++) R716[i] = (char *(*)()) F56_734;}
	R716[4] = (char *(*)()) F61_770;
	{long i; for (i = 5; i < 12; i++) R716[i] = (char *(*)()) F56_734;}
	R716[50] = (char *(*)()) F56_734;
	R716[128] = (char *(*)()) F185_1901;
	{long i; for (i = 608; i < 613; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 703; i < 706; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 707; i < 713; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 715; i < 717; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 718; i < 720; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 721; i < 723; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 724; i < 726; i++) R716[i] = (char *(*)()) F56_734;}
	{long i; for (i = 730; i < 738; i++) R716[i] = (char *(*)()) F56_734;}
}

char *(*R1270[4])();
void R1270_init () {
	R1270[0] = (char *(*)()) F109_1379;
	R1270[1] = (char *(*)()) F110_1390;
	R1270[2] = (char *(*)()) F111_1413;
	R1270[3] = (char *(*)()) F112_1446;
}

char *(*R1307[2])();
void R1307_init () {
	R1307[0] = (char *(*)()) F111_1410;
	R1307[1] = (char *(*)()) F112_1442;
}

char *(*R1309[2])();
void R1309_init () {
	R1309[0] = (char *(*)()) F111_1412;
	R1309[1] = (char *(*)()) F112_1445;
}

char *(*R1317[2])();
void R1317_init () {
	R1317[0] = (char *(*)()) F111_1421;
	R1317[1] = (char *(*)()) F112_1453;
}

char *(*R1318[2])();
void R1318_init () {
	R1318[0] = (char *(*)()) F111_1422;
	R1318[1] = (char *(*)()) F112_1454;
}

char *(*R1389[3])();
void R1389_init () {
	R1389[0] = (char *(*)()) F118_1498;
	R1389[1] = (char *(*)()) F119_1498;
	R1389[2] = (char *(*)()) F118_1498;
}

char *(*R1428[40])();
void R1428_init () {
	R1428[0] = (char *(*)()) F123_1537;
	R1428[1] = (char *(*)()) F124_1561;
	R1428[5] = (char *(*)()) F128_1564;
	R1428[7] = (char *(*)()) F130_1566;
	R1428[8] = (char *(*)()) F131_1570;
	R1428[9] = (char *(*)()) F132_1576;
	R1428[11] = (char *(*)()) F134_1593;
	R1428[12] = (char *(*)()) F135_1595;
	R1428[13] = (char *(*)()) F136_1597;
	R1428[15] = (char *(*)()) F138_1599;
	R1428[16] = (char *(*)()) F139_1603;
	R1428[19] = (char *(*)()) F142_1605;
	R1428[20] = (char *(*)()) F143_1607;
	R1428[22] = (char *(*)()) F145_1611;
	R1428[23] = (char *(*)()) F146_1617;
	R1428[24] = (char *(*)()) F147_1619;
	R1428[26] = (char *(*)()) F149_1621;
	R1428[27] = (char *(*)()) F150_1623;
	R1428[28] = (char *(*)()) F151_1627;
	R1428[29] = (char *(*)()) F152_1631;
	R1428[31] = (char *(*)()) F154_1633;
	R1428[32] = (char *(*)()) F155_1635;
	R1428[34] = (char *(*)()) F157_1637;
	R1428[35] = (char *(*)()) F158_1639;
	R1428[36] = (char *(*)()) F159_1641;
	R1428[37] = (char *(*)()) F160_1643;
	R1428[38] = (char *(*)()) F161_1647;
	R1428[39] = (char *(*)()) F162_1649;
}

char *(*R1487[600])();
void R1487_init () {
	R1487[0] = (char *(*)()) F164_1654;
	R1487[1] = (char *(*)()) F165_1655;
	R1487[20] = (char *(*)()) F184_1894;
	R1487[599] = (char *(*)()) F763_4150;
}

char *(*R1490[4])();
void R1490_init () {
	R1490[0] = (char *(*)()) F167_1658;
	R1490[1] = (char *(*)()) F168_1661;
	R1490[2] = (char *(*)()) F169_1664;
	R1490[3] = (char *(*)()) F170_1666;
}

char *(*R1497[765])();
void R1497_init () {
	R1497[0] = (char *(*)()) F176_1778;
	R1497[2] = (char *(*)()) F178_1820;
	R1497[4] = (char *(*)()) F179_1829;
	R1497[5] = (char *(*)()) F181_1839;
	R1497[620] = (char *(*)()) F796_4323;
	R1497[621] = (char *(*)()) F797_4362;
	R1497[622] = (char *(*)()) F798_4362;
	R1497[623] = (char *(*)()) F799_4362;
	R1497[624] = (char *(*)()) F800_4362;
	R1497[625] = (char *(*)()) F801_4362;
	R1497[626] = (char *(*)()) F802_4362;
	R1497[627] = (char *(*)()) F803_4362;
	R1497[628] = (char *(*)()) F804_4362;
	R1497[629] = (char *(*)()) F805_4362;
	R1497[630] = (char *(*)()) F806_4362;
	R1497[631] = (char *(*)()) F807_4362;
	R1497[632] = (char *(*)()) F808_4362;
	R1497[633] = (char *(*)()) F809_4362;
	R1497[634] = (char *(*)()) F810_4362;
	R1497[635] = (char *(*)()) F811_4362;
	R1497[636] = (char *(*)()) F812_4362;
	R1497[637] = (char *(*)()) F813_4362;
	R1497[638] = (char *(*)()) F814_4362;
	R1497[639] = (char *(*)()) F815_4362;
	R1497[640] = (char *(*)()) F816_4362;
	R1497[641] = (char *(*)()) F817_4362;
	R1497[642] = (char *(*)()) F818_4362;
	R1497[643] = (char *(*)()) F819_4362;
	R1497[644] = (char *(*)()) F820_4362;
	R1497[645] = (char *(*)()) F821_4362;
	R1497[646] = (char *(*)()) F822_4362;
	R1497[647] = (char *(*)()) F823_4362;
	R1497[648] = (char *(*)()) F824_4362;
	R1497[649] = (char *(*)()) F825_4362;
	R1497[650] = (char *(*)()) F826_4362;
	R1497[651] = (char *(*)()) F827_4362;
	R1497[654] = (char *(*)()) F830_4581_1497_2;
	R1497[655] = (char *(*)()) F831_4581_1497_2;
	R1497[657] = (char *(*)()) F833_4650_1497_2;
	R1497[658] = (char *(*)()) F834_4650_1497_2;
	R1497[660] = (char *(*)()) F836_4716_1497_2;
	R1497[661] = (char *(*)()) F837_4716_1497_2;
	{long i; for (i = 663; i < 665; i++) R1497[i] = (char *(*)()) F838_4747;}
	{long i; for (i = 666; i < 668; i++) R1497[i] = (char *(*)()) F841_4787;}
	R1497[672] = (char *(*)()) F848_4922_1497_2;
	R1497[673] = (char *(*)()) F849_4922_1497_2;
	R1497[675] = (char *(*)()) F851_5020_1497_2;
	R1497[676] = (char *(*)()) F852_5020_1497_2;
	R1497[678] = (char *(*)()) F854_5119_1497_2;
	R1497[679] = (char *(*)()) F855_5119_1497_2;
	R1497[681] = (char *(*)()) F857_5218_1497_2;
	R1497[682] = (char *(*)()) F858_5218_1497_2;
	R1497[684] = (char *(*)()) F860_5313_1497_2;
	R1497[685] = (char *(*)()) F861_5313_1497_2;
	R1497[687] = (char *(*)()) F863_5407_1497_2;
	R1497[688] = (char *(*)()) F864_5407_1497_2;
	R1497[690] = (char *(*)()) F866_5502_1497_2;
	R1497[691] = (char *(*)()) F867_5502_1497_2;
	{long i; for (i = 734; i < 737; i++) R1497[i] = (char *(*)()) F909_5774;}
	{long i; for (i = 738; i < 740; i++) R1497[i] = (char *(*)()) F913_5971;}
	R1497[759] = (char *(*)()) F935_6532;
	R1497[761] = (char *(*)()) F937_6570;
	R1497[764] = (char *(*)()) F940_6651;
}
static EIF_BOOLEAN F830_4581_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F830_4581(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F831_4581_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F831_4581(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F833_4650_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F833_4650(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F834_4650_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F834_4650(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F836_4716_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F836_4716(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F837_4716_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F837_4716(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F848_4922_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F848_4922(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F849_4922_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F849_4922(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F851_5020_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F851_5020(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F852_5020_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F852_5020(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F854_5119_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F854_5119(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F855_5119_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F855_5119(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F857_5218_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F857_5218(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F858_5218_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F858_5218(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F860_5313_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F860_5313(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F861_5313_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F861_5313(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F863_5407_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F863_5407(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F864_5407_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F864_5407(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F866_5502_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F866_5502(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F867_5502_1497_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F867_5502(Current, *(EIF_NATURAL_16 *)arg1);
}

char *(*R1498[765])();
void R1498_init () {
	R1498[0] = (char *(*)()) F171_1668;
	R1498[2] = (char *(*)()) F177_1798;
	{long i; for (i = 4; i < 6; i++) R1498[i] = (char *(*)()) F177_1798;}
	R1498[620] = (char *(*)()) F177_1798;
	R1498[621] = (char *(*)()) F797_4363;
	R1498[622] = (char *(*)()) F798_4363;
	R1498[623] = (char *(*)()) F799_4363;
	R1498[624] = (char *(*)()) F800_4363;
	R1498[625] = (char *(*)()) F801_4363;
	R1498[626] = (char *(*)()) F802_4363;
	R1498[627] = (char *(*)()) F803_4363;
	R1498[628] = (char *(*)()) F804_4363;
	R1498[629] = (char *(*)()) F805_4363;
	R1498[630] = (char *(*)()) F806_4363;
	R1498[631] = (char *(*)()) F807_4363;
	R1498[632] = (char *(*)()) F808_4363;
	R1498[633] = (char *(*)()) F809_4363;
	R1498[634] = (char *(*)()) F810_4363;
	R1498[635] = (char *(*)()) F811_4363;
	R1498[636] = (char *(*)()) F812_4363;
	R1498[637] = (char *(*)()) F813_4363;
	R1498[638] = (char *(*)()) F814_4363;
	R1498[639] = (char *(*)()) F815_4363;
	R1498[640] = (char *(*)()) F816_4363;
	R1498[641] = (char *(*)()) F817_4363;
	R1498[642] = (char *(*)()) F818_4363;
	R1498[643] = (char *(*)()) F819_4363;
	R1498[644] = (char *(*)()) F820_4363;
	R1498[645] = (char *(*)()) F821_4363;
	R1498[646] = (char *(*)()) F822_4363;
	R1498[647] = (char *(*)()) F823_4363;
	R1498[648] = (char *(*)()) F824_4363;
	R1498[649] = (char *(*)()) F825_4363;
	R1498[650] = (char *(*)()) F826_4363;
	R1498[651] = (char *(*)()) F827_4363;
	{long i; for (i = 654; i < 656; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 657; i < 659; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 660; i < 662; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 663; i < 665; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 666; i < 668; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 672; i < 674; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 675; i < 677; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 678; i < 680; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 681; i < 683; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 684; i < 686; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 687; i < 689; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 690; i < 692; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 734; i < 737; i++) R1498[i] = (char *(*)()) F177_1798;}
	{long i; for (i = 738; i < 740; i++) R1498[i] = (char *(*)()) F177_1798;}
	R1498[759] = (char *(*)()) F177_1798;
	R1498[761] = (char *(*)()) F177_1798;
	R1498[764] = (char *(*)()) F177_1798;
}

char *(*R1608[2])();
void R1608_init () {
	R1608[0] = (char *(*)()) F179_1830;
	R1608[1] = (char *(*)()) F181_1840;
}

char *(*R1914[709])();
void R1914_init () {
	R1914[0] = (char *(*)()) F202_2153;
	R1914[384] = (char *(*)()) F193_2153;
	R1914[385] = (char *(*)()) F194_2153;
	R1914[386] = (char *(*)()) F195_2153;
	R1914[387] = (char *(*)()) F196_2153;
	R1914[388] = (char *(*)()) F197_2153;
	R1914[389] = (char *(*)()) F198_2153;
	R1914[390] = (char *(*)()) F199_2153;
	R1914[391] = (char *(*)()) F200_2153;
	R1914[392] = (char *(*)()) F201_2153;
	R1914[393] = (char *(*)()) F202_2153;
	R1914[394] = (char *(*)()) F203_2153;
	R1914[395] = (char *(*)()) F204_2153;
	R1914[466] = (char *(*)()) F193_2153;
	R1914[467] = (char *(*)()) F194_2153;
	R1914[468] = (char *(*)()) F195_2153;
	R1914[469] = (char *(*)()) F196_2153;
	R1914[470] = (char *(*)()) F197_2153;
	R1914[471] = (char *(*)()) F198_2153;
	R1914[472] = (char *(*)()) F199_2153;
	R1914[473] = (char *(*)()) F200_2153;
	R1914[474] = (char *(*)()) F201_2153;
	R1914[475] = (char *(*)()) F202_2153;
	R1914[476] = (char *(*)()) F203_2153;
	R1914[477] = (char *(*)()) F204_2153;
	{long i; for (i = 704; i < 706; i++) R1914[i] = (char *(*)()) F197_2153;}
	R1914[708] = (char *(*)()) F194_2153;
}

char *(*R1915[709])();
void R1915_init () {
	R1915[0] = (char *(*)()) F202_2154_1915_125;
	R1915[384] = (char *(*)()) F193_2154;
	R1915[385] = (char *(*)()) F194_2154_1915_125;
	R1915[386] = (char *(*)()) F195_2154_1915_125;
	R1915[387] = (char *(*)()) F196_2154_1915_125;
	R1915[388] = (char *(*)()) F197_2154_1915_125;
	R1915[389] = (char *(*)()) F198_2154_1915_125;
	R1915[390] = (char *(*)()) F199_2154_1915_125;
	R1915[391] = (char *(*)()) F200_2154_1915_125;
	R1915[392] = (char *(*)()) F201_2154_1915_125;
	R1915[393] = (char *(*)()) F202_2154_1915_125;
	R1915[394] = (char *(*)()) F203_2154_1915_125;
	R1915[395] = (char *(*)()) F204_2154_1915_125;
	R1915[466] = (char *(*)()) F193_2154;
	R1915[467] = (char *(*)()) F194_2154_1915_125;
	R1915[468] = (char *(*)()) F195_2154_1915_125;
	R1915[469] = (char *(*)()) F196_2154_1915_125;
	R1915[470] = (char *(*)()) F197_2154_1915_125;
	R1915[471] = (char *(*)()) F198_2154_1915_125;
	R1915[472] = (char *(*)()) F199_2154_1915_125;
	R1915[473] = (char *(*)()) F200_2154_1915_125;
	R1915[474] = (char *(*)()) F201_2154_1915_125;
	R1915[475] = (char *(*)()) F202_2154_1915_125;
	R1915[476] = (char *(*)()) F203_2154_1915_125;
	R1915[477] = (char *(*)()) F204_2154_1915_125;
	{long i; for (i = 704; i < 706; i++) R1915[i] = (char *(*)()) F197_2154_1915_125;}
	R1915[708] = (char *(*)()) F194_2154_1915_125;
}
static void F202_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F202_2154(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F194_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F194_2154(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F195_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F195_2154(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F196_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F196_2154(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F197_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F197_2154(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F198_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F198_2154(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F199_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F199_2154(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F200_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F200_2154(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F201_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F201_2154(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F203_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F203_2154(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F204_2154_1915_125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F204_2154(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R1921[709])();
void R1921_init () {
	R1921[0] = (char *(*)()) F202_2160;
	R1921[384] = (char *(*)()) F193_2160;
	R1921[385] = (char *(*)()) F194_2160;
	R1921[386] = (char *(*)()) F195_2160;
	R1921[387] = (char *(*)()) F196_2160;
	R1921[388] = (char *(*)()) F197_2160;
	R1921[389] = (char *(*)()) F198_2160;
	R1921[390] = (char *(*)()) F199_2160;
	R1921[391] = (char *(*)()) F200_2160;
	R1921[392] = (char *(*)()) F201_2160;
	R1921[393] = (char *(*)()) F202_2160;
	R1921[394] = (char *(*)()) F203_2160;
	R1921[395] = (char *(*)()) F204_2160;
	R1921[466] = (char *(*)()) F193_2160;
	R1921[467] = (char *(*)()) F194_2160;
	R1921[468] = (char *(*)()) F195_2160;
	R1921[469] = (char *(*)()) F196_2160;
	R1921[470] = (char *(*)()) F197_2160;
	R1921[471] = (char *(*)()) F198_2160;
	R1921[472] = (char *(*)()) F199_2160;
	R1921[473] = (char *(*)()) F200_2160;
	R1921[474] = (char *(*)()) F201_2160;
	R1921[475] = (char *(*)()) F202_2160;
	R1921[476] = (char *(*)()) F203_2160;
	R1921[477] = (char *(*)()) F204_2160;
	{long i; for (i = 704; i < 706; i++) R1921[i] = (char *(*)()) F197_2160;}
	R1921[708] = (char *(*)()) F194_2160;
}

static EIF_TYPE_INDEX Y1922_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype12[] = {830,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype13[] = {830,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype38[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype39[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y1922_pgtype40[] = {839,0xFFFF};
EIF_TYPE_INDEX *Y1922_gen_type [723];
EIF_TYPE_INDEX Y1922 [723];
void Y1922_init (void)
{
	egc_routines_types [1922] = Y1922;
	egc_routines_gen_types [1922] = Y1922_gen_type;
	egc_routines_offset [1922] = 192;
	Y1922_gen_type [0] = Y1922_pgtype0;
	Y1922_gen_type [1] = Y1922_pgtype1;
	Y1922_gen_type [2] = Y1922_pgtype2;
	Y1922_gen_type [3] = Y1922_pgtype3;
	Y1922_gen_type [4] = Y1922_pgtype4;
	Y1922_gen_type [5] = Y1922_pgtype5;
	Y1922_gen_type [6] = Y1922_pgtype6;
	Y1922_gen_type [7] = Y1922_pgtype7;
	Y1922_gen_type [8] = Y1922_pgtype8;
	Y1922_gen_type [9] = Y1922_pgtype9;
	Y1922_gen_type [10] = Y1922_pgtype10;
	Y1922_gen_type [11] = Y1922_pgtype11;
	Y1922_gen_type [14] = Y1922_pgtype12;
	Y1922_gen_type [15] = Y1922_pgtype13;
	Y1922_gen_type [398] = Y1922_pgtype14;
	Y1922_gen_type [399] = Y1922_pgtype15;
	Y1922_gen_type [400] = Y1922_pgtype16;
	Y1922_gen_type [401] = Y1922_pgtype17;
	Y1922_gen_type [402] = Y1922_pgtype18;
	Y1922_gen_type [403] = Y1922_pgtype19;
	Y1922_gen_type [404] = Y1922_pgtype20;
	Y1922_gen_type [405] = Y1922_pgtype21;
	Y1922_gen_type [406] = Y1922_pgtype22;
	Y1922_gen_type [407] = Y1922_pgtype23;
	Y1922_gen_type [408] = Y1922_pgtype24;
	Y1922_gen_type [409] = Y1922_pgtype25;
	Y1922_gen_type [480] = Y1922_pgtype26;
	Y1922_gen_type [481] = Y1922_pgtype27;
	Y1922_gen_type [482] = Y1922_pgtype28;
	Y1922_gen_type [483] = Y1922_pgtype29;
	Y1922_gen_type [484] = Y1922_pgtype30;
	Y1922_gen_type [485] = Y1922_pgtype31;
	Y1922_gen_type [486] = Y1922_pgtype32;
	Y1922_gen_type [487] = Y1922_pgtype33;
	Y1922_gen_type [488] = Y1922_pgtype34;
	Y1922_gen_type [489] = Y1922_pgtype35;
	Y1922_gen_type [490] = Y1922_pgtype36;
	Y1922_gen_type [491] = Y1922_pgtype37;
	Y1922_gen_type [718] = Y1922_pgtype38;
	Y1922_gen_type [719] = Y1922_pgtype39;
	Y1922_gen_type [722] = Y1922_pgtype40;
	{long i; for (i = 14; i < 16; i++) Y1922[i] = 830;};
	{long i; for (i = 718; i < 720; i++) Y1922[i] = 842;};
	Y1922[722] = 839;
}

char *(*R2053[204])();
void R2053_init () {
	R2053[0] = (char *(*)()) F297_2796;
	R2053[1] = (char *(*)()) F298_2796_2053_1;
	R2053[2] = (char *(*)()) F299_2796_2053_1;
	R2053[3] = (char *(*)()) F300_2796;
	R2053[4] = (char *(*)()) F301_2796_2053_1;
	R2053[5] = (char *(*)()) F302_2796_2053_1;
	R2053[6] = (char *(*)()) F303_2802;
	R2053[7] = (char *(*)()) F304_2802_2053_1;
	R2053[8] = (char *(*)()) F305_2808;
	R2053[21] = (char *(*)()) F306_2814;
	R2053[22] = (char *(*)()) F307_2814_2053_1;
	R2053[23] = (char *(*)()) F308_2814_2053_1;
	R2053[24] = (char *(*)()) F309_2814_2053_1;
	R2053[25] = (char *(*)()) F310_2814_2053_1;
	R2053[26] = (char *(*)()) F311_2814_2053_1;
	R2053[27] = (char *(*)()) F312_2814_2053_1;
	R2053[28] = (char *(*)()) F313_2814_2053_1;
	R2053[29] = (char *(*)()) F314_2814_2053_1;
	R2053[30] = (char *(*)()) F315_2814_2053_1;
	R2053[31] = (char *(*)()) F316_2814_2053_1;
	R2053[32] = (char *(*)()) F317_2814_2053_1;
	R2053[203] = (char *(*)()) F499_2936_2053_1;
}
static EIF_REFERENCE F298_2796_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F298_2796(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F299_2796_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F299_2796(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F301_2796_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F301_2796(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F302_2796_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F302_2796(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F304_2802_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F304_2802(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F307_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F307_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F308_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F308_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F309_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F309_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F310_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F310_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F311_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F311_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F312_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F312_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F313_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F313_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F314_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F314_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F315_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F315_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F316_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F316_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F317_2814_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F317_2814(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F499_2936_2053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_2936(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2054[204])();
void R2054_init () {
	R2054[0] = (char *(*)()) F297_2799;
	R2054[1] = (char *(*)()) F298_2799;
	R2054[2] = (char *(*)()) F299_2799;
	R2054[3] = (char *(*)()) F300_2799;
	R2054[4] = (char *(*)()) F301_2799;
	R2054[5] = (char *(*)()) F302_2799;
	R2054[6] = (char *(*)()) F303_2803;
	R2054[7] = (char *(*)()) F304_2803;
	R2054[8] = (char *(*)()) F305_2809;
	R2054[21] = (char *(*)()) F306_2823;
	R2054[22] = (char *(*)()) F307_2823;
	R2054[23] = (char *(*)()) F308_2823;
	R2054[24] = (char *(*)()) F309_2823;
	R2054[25] = (char *(*)()) F310_2823;
	R2054[26] = (char *(*)()) F311_2823;
	R2054[27] = (char *(*)()) F312_2823;
	R2054[28] = (char *(*)()) F313_2823;
	R2054[29] = (char *(*)()) F314_2823;
	R2054[30] = (char *(*)()) F315_2823;
	R2054[31] = (char *(*)()) F316_2823;
	R2054[32] = (char *(*)()) F317_2823;
	R2054[203] = (char *(*)()) F499_2937;
}


#ifdef __cplusplus
}
#endif
