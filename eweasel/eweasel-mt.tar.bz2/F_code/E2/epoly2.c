#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2055[204])();
void R2055_init () {
	R2055[0] = (char *(*)()) F297_2800;
	R2055[1] = (char *(*)()) F298_2800;
	R2055[2] = (char *(*)()) F299_2800;
	R2055[3] = (char *(*)()) F300_2800;
	R2055[4] = (char *(*)()) F301_2800;
	R2055[5] = (char *(*)()) F302_2800;
	R2055[6] = (char *(*)()) F303_2805;
	R2055[7] = (char *(*)()) F304_2805;
	R2055[8] = (char *(*)()) F305_2811;
	R2055[21] = (char *(*)()) F306_2829;
	R2055[22] = (char *(*)()) F307_2829;
	R2055[23] = (char *(*)()) F308_2829;
	R2055[24] = (char *(*)()) F309_2829;
	R2055[25] = (char *(*)()) F310_2829;
	R2055[26] = (char *(*)()) F311_2829;
	R2055[27] = (char *(*)()) F312_2829;
	R2055[28] = (char *(*)()) F313_2829;
	R2055[29] = (char *(*)()) F314_2829;
	R2055[30] = (char *(*)()) F315_2829;
	R2055[31] = (char *(*)()) F316_2829;
	R2055[32] = (char *(*)()) F317_2829;
	R2055[203] = (char *(*)()) F499_2943;
}

char *(*R2061[6])();
void R2061_init () {
	R2061[0] = (char *(*)()) F297_2797;
	R2061[1] = (char *(*)()) F298_2797;
	R2061[2] = (char *(*)()) F299_2797_2061_1;
	R2061[3] = (char *(*)()) F300_2797_2061_1;
	R2061[4] = (char *(*)()) F301_2797_2061_1;
	R2061[5] = (char *(*)()) F302_2797;
}
static EIF_REFERENCE F299_2797_2061_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F299_2797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F300_2797_2061_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F300_2797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F301_2797_2061_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F301_2797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2274[354])();
void R2274_init () {
	{long i; for (i = 0; i < 2; i++) R2274[i] = (char *(*)()) F563_3026;}
	R2274[353] = (char *(*)()) F917_6136;
}

char *(*R2285[354])();
void R2285_init () {
	{long i; for (i = 0; i < 2; i++) R2285[i] = (char *(*)()) F563_3105;}
	R2285[353] = (char *(*)()) F917_6167;
}

char *(*R2286[354])();
void R2286_init () {
	{long i; for (i = 0; i < 2; i++) R2286[i] = (char *(*)()) F563_3106;}
	R2286[353] = (char *(*)()) F917_6168;
}

char *(*R2287[354])();
void R2287_init () {
	{long i; for (i = 0; i < 2; i++) R2287[i] = (char *(*)()) F563_3100;}
	R2287[353] = (char *(*)()) F917_6159;
}

char *(*R2289[354])();
void R2289_init () {
	{long i; for (i = 0; i < 2; i++) R2289[i] = (char *(*)()) F563_3103;}
	R2289[353] = (char *(*)()) F917_6157;
}

char *(*R2317[354])();
void R2317_init () {
	{long i; for (i = 0; i < 2; i++) R2317[i] = (char *(*)()) F563_3133;}
	R2317[353] = (char *(*)()) F917_6154;
}

char *(*R2330[354])();
void R2330_init () {
	{long i; for (i = 0; i < 2; i++) R2330[i] = (char *(*)()) F563_3140;}
	R2330[353] = (char *(*)()) F917_6148;
}

char *(*R2333[354])();
void R2333_init () {
	{long i; for (i = 0; i < 2; i++) R2333[i] = (char *(*)()) F563_3137;}
	R2333[353] = (char *(*)()) F917_6145;
}

char *(*R2437[42])();
void R2437_init () {
	R2437[0] = (char *(*)()) F653_3506;
	R2437[1] = (char *(*)()) F654_3506;
	R2437[3] = (char *(*)()) F655_3549;
	R2437[20] = (char *(*)()) F673_3706;
	R2437[21] = (char *(*)()) F674_3706;
	R2437[22] = (char *(*)()) F675_3706;
	R2437[23] = (char *(*)()) F676_3706;
	R2437[24] = (char *(*)()) F677_3706;
	R2437[25] = (char *(*)()) F678_3706;
	R2437[26] = (char *(*)()) F679_3706;
	R2437[27] = (char *(*)()) F680_3706;
	R2437[28] = (char *(*)()) F681_3706;
	R2437[29] = (char *(*)()) F682_3706;
	R2437[30] = (char *(*)()) F683_3706;
	R2437[31] = (char *(*)()) F684_3706;
	R2437[33] = (char *(*)()) F686_3791;
	R2437[34] = (char *(*)()) F687_3791;
	R2437[35] = (char *(*)()) F688_3791;
	R2437[36] = (char *(*)()) F689_3791;
	R2437[37] = (char *(*)()) F690_3791;
	R2437[38] = (char *(*)()) F691_3791;
	R2437[39] = (char *(*)()) F686_3791;
	R2437[40] = (char *(*)()) F687_3791;
	R2437[41] = (char *(*)()) F686_3791;
}

static EIF_TYPE_INDEX Y2438_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype12[] = {910,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype13[] = {913,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype14[] = {839,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype90[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype91[] = {839,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype260[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype323[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype324[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype325[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype350[] = {848,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype438[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype451[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype452[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype453[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype454[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype455[] = {842,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype456[] = {839,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype457[] = {839,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype458[] = {839,0xFFFF};
static EIF_TYPE_INDEX Y2438_pgtype459[] = {842,0xFFFF};
EIF_TYPE_INDEX *Y2438_gen_type [678];
EIF_TYPE_INDEX Y2438 [678];
void Y2438_init (void)
{
	egc_routines_types [2438] = Y2438;
	egc_routines_gen_types [2438] = Y2438_gen_type;
	egc_routines_offset [2438] = 239;
	Y2438_gen_type [0] = Y2438_pgtype0;
	Y2438_gen_type [1] = Y2438_pgtype1;
	Y2438_gen_type [2] = Y2438_pgtype2;
	Y2438_gen_type [3] = Y2438_pgtype3;
	Y2438_gen_type [4] = Y2438_pgtype4;
	Y2438_gen_type [5] = Y2438_pgtype5;
	Y2438_gen_type [6] = Y2438_pgtype6;
	Y2438_gen_type [7] = Y2438_pgtype7;
	Y2438_gen_type [8] = Y2438_pgtype8;
	Y2438_gen_type [9] = Y2438_pgtype9;
	Y2438_gen_type [10] = Y2438_pgtype10;
	Y2438_gen_type [11] = Y2438_pgtype11;
	Y2438_gen_type [12] = Y2438_pgtype12;
	Y2438_gen_type [13] = Y2438_pgtype13;
	Y2438_gen_type [14] = Y2438_pgtype14;
	Y2438_gen_type [15] = Y2438_pgtype15;
	Y2438_gen_type [16] = Y2438_pgtype16;
	Y2438_gen_type [17] = Y2438_pgtype17;
	Y2438_gen_type [18] = Y2438_pgtype18;
	Y2438_gen_type [19] = Y2438_pgtype19;
	Y2438_gen_type [20] = Y2438_pgtype20;
	Y2438_gen_type [21] = Y2438_pgtype21;
	Y2438_gen_type [22] = Y2438_pgtype22;
	Y2438_gen_type [23] = Y2438_pgtype23;
	Y2438_gen_type [24] = Y2438_pgtype24;
	Y2438_gen_type [25] = Y2438_pgtype25;
	Y2438_gen_type [26] = Y2438_pgtype26;
	Y2438_gen_type [27] = Y2438_pgtype27;
	Y2438_gen_type [28] = Y2438_pgtype28;
	Y2438_gen_type [29] = Y2438_pgtype29;
	Y2438_gen_type [30] = Y2438_pgtype30;
	Y2438_gen_type [31] = Y2438_pgtype31;
	Y2438_gen_type [32] = Y2438_pgtype32;
	Y2438_gen_type [33] = Y2438_pgtype33;
	Y2438_gen_type [34] = Y2438_pgtype34;
	Y2438_gen_type [35] = Y2438_pgtype35;
	Y2438_gen_type [36] = Y2438_pgtype36;
	Y2438_gen_type [37] = Y2438_pgtype37;
	Y2438_gen_type [38] = Y2438_pgtype38;
	Y2438_gen_type [39] = Y2438_pgtype39;
	Y2438_gen_type [40] = Y2438_pgtype40;
	Y2438_gen_type [41] = Y2438_pgtype41;
	Y2438_gen_type [42] = Y2438_pgtype42;
	Y2438_gen_type [43] = Y2438_pgtype43;
	Y2438_gen_type [44] = Y2438_pgtype44;
	Y2438_gen_type [45] = Y2438_pgtype45;
	Y2438_gen_type [46] = Y2438_pgtype46;
	Y2438_gen_type [47] = Y2438_pgtype47;
	Y2438_gen_type [48] = Y2438_pgtype48;
	Y2438_gen_type [49] = Y2438_pgtype49;
	Y2438_gen_type [50] = Y2438_pgtype50;
	Y2438_gen_type [51] = Y2438_pgtype51;
	Y2438_gen_type [52] = Y2438_pgtype52;
	Y2438_gen_type [53] = Y2438_pgtype53;
	Y2438_gen_type [54] = Y2438_pgtype54;
	Y2438_gen_type [55] = Y2438_pgtype55;
	Y2438_gen_type [56] = Y2438_pgtype56;
	Y2438_gen_type [57] = Y2438_pgtype57;
	Y2438_gen_type [58] = Y2438_pgtype58;
	Y2438_gen_type [59] = Y2438_pgtype59;
	Y2438_gen_type [60] = Y2438_pgtype60;
	Y2438_gen_type [61] = Y2438_pgtype61;
	Y2438_gen_type [62] = Y2438_pgtype62;
	Y2438_gen_type [63] = Y2438_pgtype63;
	Y2438_gen_type [64] = Y2438_pgtype64;
	Y2438_gen_type [65] = Y2438_pgtype65;
	Y2438_gen_type [66] = Y2438_pgtype66;
	Y2438_gen_type [67] = Y2438_pgtype67;
	Y2438_gen_type [68] = Y2438_pgtype68;
	Y2438_gen_type [69] = Y2438_pgtype69;
	Y2438_gen_type [70] = Y2438_pgtype70;
	Y2438_gen_type [71] = Y2438_pgtype71;
	Y2438_gen_type [72] = Y2438_pgtype72;
	Y2438_gen_type [73] = Y2438_pgtype73;
	Y2438_gen_type [74] = Y2438_pgtype74;
	Y2438_gen_type [75] = Y2438_pgtype75;
	Y2438_gen_type [76] = Y2438_pgtype76;
	Y2438_gen_type [77] = Y2438_pgtype77;
	Y2438_gen_type [78] = Y2438_pgtype78;
	Y2438_gen_type [79] = Y2438_pgtype79;
	Y2438_gen_type [80] = Y2438_pgtype80;
	Y2438_gen_type [81] = Y2438_pgtype81;
	Y2438_gen_type [82] = Y2438_pgtype82;
	Y2438_gen_type [83] = Y2438_pgtype83;
	Y2438_gen_type [84] = Y2438_pgtype84;
	Y2438_gen_type [85] = Y2438_pgtype85;
	Y2438_gen_type [86] = Y2438_pgtype86;
	Y2438_gen_type [87] = Y2438_pgtype87;
	Y2438_gen_type [88] = Y2438_pgtype88;
	Y2438_gen_type [89] = Y2438_pgtype89;
	Y2438_gen_type [90] = Y2438_pgtype90;
	Y2438_gen_type [91] = Y2438_pgtype91;
	Y2438_gen_type [92] = Y2438_pgtype92;
	Y2438_gen_type [93] = Y2438_pgtype93;
	Y2438_gen_type [94] = Y2438_pgtype94;
	Y2438_gen_type [95] = Y2438_pgtype95;
	Y2438_gen_type [96] = Y2438_pgtype96;
	Y2438_gen_type [97] = Y2438_pgtype97;
	Y2438_gen_type [98] = Y2438_pgtype98;
	Y2438_gen_type [99] = Y2438_pgtype99;
	Y2438_gen_type [100] = Y2438_pgtype100;
	Y2438_gen_type [101] = Y2438_pgtype101;
	Y2438_gen_type [102] = Y2438_pgtype102;
	Y2438_gen_type [103] = Y2438_pgtype103;
	Y2438_gen_type [104] = Y2438_pgtype104;
	Y2438_gen_type [105] = Y2438_pgtype105;
	Y2438_gen_type [106] = Y2438_pgtype106;
	Y2438_gen_type [107] = Y2438_pgtype107;
	Y2438_gen_type [108] = Y2438_pgtype108;
	Y2438_gen_type [109] = Y2438_pgtype109;
	Y2438_gen_type [110] = Y2438_pgtype110;
	Y2438_gen_type [111] = Y2438_pgtype111;
	Y2438_gen_type [112] = Y2438_pgtype112;
	Y2438_gen_type [113] = Y2438_pgtype113;
	Y2438_gen_type [114] = Y2438_pgtype114;
	Y2438_gen_type [115] = Y2438_pgtype115;
	Y2438_gen_type [116] = Y2438_pgtype116;
	Y2438_gen_type [117] = Y2438_pgtype117;
	Y2438_gen_type [118] = Y2438_pgtype118;
	Y2438_gen_type [119] = Y2438_pgtype119;
	Y2438_gen_type [120] = Y2438_pgtype120;
	Y2438_gen_type [121] = Y2438_pgtype121;
	Y2438_gen_type [122] = Y2438_pgtype122;
	Y2438_gen_type [123] = Y2438_pgtype123;
	Y2438_gen_type [124] = Y2438_pgtype124;
	Y2438_gen_type [125] = Y2438_pgtype125;
	Y2438_gen_type [126] = Y2438_pgtype126;
	Y2438_gen_type [127] = Y2438_pgtype127;
	Y2438_gen_type [128] = Y2438_pgtype128;
	Y2438_gen_type [129] = Y2438_pgtype129;
	Y2438_gen_type [130] = Y2438_pgtype130;
	Y2438_gen_type [131] = Y2438_pgtype131;
	Y2438_gen_type [132] = Y2438_pgtype132;
	Y2438_gen_type [133] = Y2438_pgtype133;
	Y2438_gen_type [134] = Y2438_pgtype134;
	Y2438_gen_type [135] = Y2438_pgtype135;
	Y2438_gen_type [136] = Y2438_pgtype136;
	Y2438_gen_type [137] = Y2438_pgtype137;
	Y2438_gen_type [138] = Y2438_pgtype138;
	Y2438_gen_type [139] = Y2438_pgtype139;
	Y2438_gen_type [140] = Y2438_pgtype140;
	Y2438_gen_type [141] = Y2438_pgtype141;
	Y2438_gen_type [142] = Y2438_pgtype142;
	Y2438_gen_type [143] = Y2438_pgtype143;
	Y2438_gen_type [144] = Y2438_pgtype144;
	Y2438_gen_type [145] = Y2438_pgtype145;
	Y2438_gen_type [146] = Y2438_pgtype146;
	Y2438_gen_type [147] = Y2438_pgtype147;
	Y2438_gen_type [148] = Y2438_pgtype148;
	Y2438_gen_type [149] = Y2438_pgtype149;
	Y2438_gen_type [150] = Y2438_pgtype150;
	Y2438_gen_type [151] = Y2438_pgtype151;
	Y2438_gen_type [152] = Y2438_pgtype152;
	Y2438_gen_type [153] = Y2438_pgtype153;
	Y2438_gen_type [154] = Y2438_pgtype154;
	Y2438_gen_type [155] = Y2438_pgtype155;
	Y2438_gen_type [156] = Y2438_pgtype156;
	Y2438_gen_type [157] = Y2438_pgtype157;
	Y2438_gen_type [158] = Y2438_pgtype158;
	Y2438_gen_type [159] = Y2438_pgtype159;
	Y2438_gen_type [160] = Y2438_pgtype160;
	Y2438_gen_type [161] = Y2438_pgtype161;
	Y2438_gen_type [162] = Y2438_pgtype162;
	Y2438_gen_type [163] = Y2438_pgtype163;
	Y2438_gen_type [164] = Y2438_pgtype164;
	Y2438_gen_type [165] = Y2438_pgtype165;
	Y2438_gen_type [166] = Y2438_pgtype166;
	Y2438_gen_type [167] = Y2438_pgtype167;
	Y2438_gen_type [168] = Y2438_pgtype168;
	Y2438_gen_type [169] = Y2438_pgtype169;
	Y2438_gen_type [170] = Y2438_pgtype170;
	Y2438_gen_type [171] = Y2438_pgtype171;
	Y2438_gen_type [172] = Y2438_pgtype172;
	Y2438_gen_type [173] = Y2438_pgtype173;
	Y2438_gen_type [174] = Y2438_pgtype174;
	Y2438_gen_type [175] = Y2438_pgtype175;
	Y2438_gen_type [176] = Y2438_pgtype176;
	Y2438_gen_type [177] = Y2438_pgtype177;
	Y2438_gen_type [178] = Y2438_pgtype178;
	Y2438_gen_type [179] = Y2438_pgtype179;
	Y2438_gen_type [180] = Y2438_pgtype180;
	Y2438_gen_type [181] = Y2438_pgtype181;
	Y2438_gen_type [182] = Y2438_pgtype182;
	Y2438_gen_type [183] = Y2438_pgtype183;
	Y2438_gen_type [184] = Y2438_pgtype184;
	Y2438_gen_type [185] = Y2438_pgtype185;
	Y2438_gen_type [186] = Y2438_pgtype186;
	Y2438_gen_type [187] = Y2438_pgtype187;
	Y2438_gen_type [188] = Y2438_pgtype188;
	Y2438_gen_type [189] = Y2438_pgtype189;
	Y2438_gen_type [190] = Y2438_pgtype190;
	Y2438_gen_type [191] = Y2438_pgtype191;
	Y2438_gen_type [192] = Y2438_pgtype192;
	Y2438_gen_type [193] = Y2438_pgtype193;
	Y2438_gen_type [194] = Y2438_pgtype194;
	Y2438_gen_type [195] = Y2438_pgtype195;
	Y2438_gen_type [196] = Y2438_pgtype196;
	Y2438_gen_type [197] = Y2438_pgtype197;
	Y2438_gen_type [198] = Y2438_pgtype198;
	Y2438_gen_type [199] = Y2438_pgtype199;
	Y2438_gen_type [200] = Y2438_pgtype200;
	Y2438_gen_type [201] = Y2438_pgtype201;
	Y2438_gen_type [202] = Y2438_pgtype202;
	Y2438_gen_type [203] = Y2438_pgtype203;
	Y2438_gen_type [204] = Y2438_pgtype204;
	Y2438_gen_type [205] = Y2438_pgtype205;
	Y2438_gen_type [206] = Y2438_pgtype206;
	Y2438_gen_type [207] = Y2438_pgtype207;
	Y2438_gen_type [208] = Y2438_pgtype208;
	Y2438_gen_type [209] = Y2438_pgtype209;
	Y2438_gen_type [210] = Y2438_pgtype210;
	Y2438_gen_type [211] = Y2438_pgtype211;
	Y2438_gen_type [212] = Y2438_pgtype212;
	Y2438_gen_type [213] = Y2438_pgtype213;
	Y2438_gen_type [214] = Y2438_pgtype214;
	Y2438_gen_type [215] = Y2438_pgtype215;
	Y2438_gen_type [216] = Y2438_pgtype216;
	Y2438_gen_type [217] = Y2438_pgtype217;
	Y2438_gen_type [218] = Y2438_pgtype218;
	Y2438_gen_type [219] = Y2438_pgtype219;
	Y2438_gen_type [220] = Y2438_pgtype220;
	Y2438_gen_type [221] = Y2438_pgtype221;
	Y2438_gen_type [222] = Y2438_pgtype222;
	Y2438_gen_type [223] = Y2438_pgtype223;
	Y2438_gen_type [224] = Y2438_pgtype224;
	Y2438_gen_type [225] = Y2438_pgtype225;
	Y2438_gen_type [226] = Y2438_pgtype226;
	Y2438_gen_type [227] = Y2438_pgtype227;
	Y2438_gen_type [228] = Y2438_pgtype228;
	Y2438_gen_type [229] = Y2438_pgtype229;
	Y2438_gen_type [230] = Y2438_pgtype230;
	Y2438_gen_type [231] = Y2438_pgtype231;
	Y2438_gen_type [232] = Y2438_pgtype232;
	Y2438_gen_type [233] = Y2438_pgtype233;
	Y2438_gen_type [234] = Y2438_pgtype234;
	Y2438_gen_type [235] = Y2438_pgtype235;
	Y2438_gen_type [236] = Y2438_pgtype236;
	Y2438_gen_type [237] = Y2438_pgtype237;
	Y2438_gen_type [238] = Y2438_pgtype238;
	Y2438_gen_type [239] = Y2438_pgtype239;
	Y2438_gen_type [240] = Y2438_pgtype240;
	Y2438_gen_type [241] = Y2438_pgtype241;
	Y2438_gen_type [242] = Y2438_pgtype242;
	Y2438_gen_type [243] = Y2438_pgtype243;
	Y2438_gen_type [244] = Y2438_pgtype244;
	Y2438_gen_type [245] = Y2438_pgtype245;
	Y2438_gen_type [246] = Y2438_pgtype246;
	Y2438_gen_type [247] = Y2438_pgtype247;
	Y2438_gen_type [248] = Y2438_pgtype248;
	Y2438_gen_type [249] = Y2438_pgtype249;
	Y2438_gen_type [250] = Y2438_pgtype250;
	Y2438_gen_type [251] = Y2438_pgtype251;
	Y2438_gen_type [252] = Y2438_pgtype252;
	Y2438_gen_type [253] = Y2438_pgtype253;
	Y2438_gen_type [254] = Y2438_pgtype254;
	Y2438_gen_type [255] = Y2438_pgtype255;
	Y2438_gen_type [256] = Y2438_pgtype256;
	Y2438_gen_type [257] = Y2438_pgtype257;
	Y2438_gen_type [258] = Y2438_pgtype258;
	Y2438_gen_type [259] = Y2438_pgtype259;
	Y2438_gen_type [260] = Y2438_pgtype260;
	Y2438_gen_type [261] = Y2438_pgtype261;
	Y2438_gen_type [262] = Y2438_pgtype262;
	Y2438_gen_type [263] = Y2438_pgtype263;
	Y2438_gen_type [264] = Y2438_pgtype264;
	Y2438_gen_type [265] = Y2438_pgtype265;
	Y2438_gen_type [266] = Y2438_pgtype266;
	Y2438_gen_type [267] = Y2438_pgtype267;
	Y2438_gen_type [268] = Y2438_pgtype268;
	Y2438_gen_type [269] = Y2438_pgtype269;
	Y2438_gen_type [270] = Y2438_pgtype270;
	Y2438_gen_type [271] = Y2438_pgtype271;
	Y2438_gen_type [272] = Y2438_pgtype272;
	Y2438_gen_type [273] = Y2438_pgtype273;
	Y2438_gen_type [274] = Y2438_pgtype274;
	Y2438_gen_type [275] = Y2438_pgtype275;
	Y2438_gen_type [276] = Y2438_pgtype276;
	Y2438_gen_type [277] = Y2438_pgtype277;
	Y2438_gen_type [278] = Y2438_pgtype278;
	Y2438_gen_type [279] = Y2438_pgtype279;
	Y2438_gen_type [280] = Y2438_pgtype280;
	Y2438_gen_type [281] = Y2438_pgtype281;
	Y2438_gen_type [282] = Y2438_pgtype282;
	Y2438_gen_type [283] = Y2438_pgtype283;
	Y2438_gen_type [284] = Y2438_pgtype284;
	Y2438_gen_type [285] = Y2438_pgtype285;
	Y2438_gen_type [286] = Y2438_pgtype286;
	Y2438_gen_type [287] = Y2438_pgtype287;
	Y2438_gen_type [288] = Y2438_pgtype288;
	Y2438_gen_type [289] = Y2438_pgtype289;
	Y2438_gen_type [290] = Y2438_pgtype290;
	Y2438_gen_type [291] = Y2438_pgtype291;
	Y2438_gen_type [292] = Y2438_pgtype292;
	Y2438_gen_type [293] = Y2438_pgtype293;
	Y2438_gen_type [294] = Y2438_pgtype294;
	Y2438_gen_type [295] = Y2438_pgtype295;
	Y2438_gen_type [296] = Y2438_pgtype296;
	Y2438_gen_type [297] = Y2438_pgtype297;
	Y2438_gen_type [298] = Y2438_pgtype298;
	Y2438_gen_type [299] = Y2438_pgtype299;
	Y2438_gen_type [300] = Y2438_pgtype300;
	Y2438_gen_type [301] = Y2438_pgtype301;
	Y2438_gen_type [302] = Y2438_pgtype302;
	Y2438_gen_type [303] = Y2438_pgtype303;
	Y2438_gen_type [304] = Y2438_pgtype304;
	Y2438_gen_type [305] = Y2438_pgtype305;
	Y2438_gen_type [306] = Y2438_pgtype306;
	Y2438_gen_type [307] = Y2438_pgtype307;
	Y2438_gen_type [308] = Y2438_pgtype308;
	Y2438_gen_type [309] = Y2438_pgtype309;
	Y2438_gen_type [310] = Y2438_pgtype310;
	Y2438_gen_type [311] = Y2438_pgtype311;
	Y2438_gen_type [312] = Y2438_pgtype312;
	Y2438_gen_type [313] = Y2438_pgtype313;
	Y2438_gen_type [314] = Y2438_pgtype314;
	Y2438_gen_type [315] = Y2438_pgtype315;
	Y2438_gen_type [316] = Y2438_pgtype316;
	Y2438_gen_type [317] = Y2438_pgtype317;
	Y2438_gen_type [318] = Y2438_pgtype318;
	Y2438_gen_type [319] = Y2438_pgtype319;
	Y2438_gen_type [320] = Y2438_pgtype320;
	Y2438_gen_type [321] = Y2438_pgtype321;
	Y2438_gen_type [322] = Y2438_pgtype322;
	Y2438_gen_type [323] = Y2438_pgtype323;
	Y2438_gen_type [324] = Y2438_pgtype324;
	Y2438_gen_type [325] = Y2438_pgtype325;
	Y2438_gen_type [326] = Y2438_pgtype326;
	Y2438_gen_type [327] = Y2438_pgtype327;
	Y2438_gen_type [328] = Y2438_pgtype328;
	Y2438_gen_type [329] = Y2438_pgtype329;
	Y2438_gen_type [330] = Y2438_pgtype330;
	Y2438_gen_type [331] = Y2438_pgtype331;
	Y2438_gen_type [332] = Y2438_pgtype332;
	Y2438_gen_type [333] = Y2438_pgtype333;
	Y2438_gen_type [334] = Y2438_pgtype334;
	Y2438_gen_type [335] = Y2438_pgtype335;
	Y2438_gen_type [336] = Y2438_pgtype336;
	Y2438_gen_type [337] = Y2438_pgtype337;
	Y2438_gen_type [338] = Y2438_pgtype338;
	Y2438_gen_type [339] = Y2438_pgtype339;
	Y2438_gen_type [340] = Y2438_pgtype340;
	Y2438_gen_type [341] = Y2438_pgtype341;
	Y2438_gen_type [342] = Y2438_pgtype342;
	Y2438_gen_type [343] = Y2438_pgtype343;
	Y2438_gen_type [344] = Y2438_pgtype344;
	Y2438_gen_type [345] = Y2438_pgtype345;
	Y2438_gen_type [346] = Y2438_pgtype346;
	Y2438_gen_type [347] = Y2438_pgtype347;
	Y2438_gen_type [348] = Y2438_pgtype348;
	Y2438_gen_type [349] = Y2438_pgtype349;
	Y2438_gen_type [350] = Y2438_pgtype350;
	Y2438_gen_type [351] = Y2438_pgtype351;
	Y2438_gen_type [352] = Y2438_pgtype352;
	Y2438_gen_type [353] = Y2438_pgtype353;
	Y2438_gen_type [354] = Y2438_pgtype354;
	Y2438_gen_type [355] = Y2438_pgtype355;
	Y2438_gen_type [356] = Y2438_pgtype356;
	Y2438_gen_type [357] = Y2438_pgtype357;
	Y2438_gen_type [358] = Y2438_pgtype358;
	Y2438_gen_type [359] = Y2438_pgtype359;
	Y2438_gen_type [360] = Y2438_pgtype360;
	Y2438_gen_type [361] = Y2438_pgtype361;
	Y2438_gen_type [362] = Y2438_pgtype362;
	Y2438_gen_type [363] = Y2438_pgtype363;
	Y2438_gen_type [364] = Y2438_pgtype364;
	Y2438_gen_type [365] = Y2438_pgtype365;
	Y2438_gen_type [366] = Y2438_pgtype366;
	Y2438_gen_type [367] = Y2438_pgtype367;
	Y2438_gen_type [368] = Y2438_pgtype368;
	Y2438_gen_type [369] = Y2438_pgtype369;
	Y2438_gen_type [370] = Y2438_pgtype370;
	Y2438_gen_type [371] = Y2438_pgtype371;
	Y2438_gen_type [372] = Y2438_pgtype372;
	Y2438_gen_type [373] = Y2438_pgtype373;
	Y2438_gen_type [374] = Y2438_pgtype374;
	Y2438_gen_type [375] = Y2438_pgtype375;
	Y2438_gen_type [376] = Y2438_pgtype376;
	Y2438_gen_type [377] = Y2438_pgtype377;
	Y2438_gen_type [378] = Y2438_pgtype378;
	Y2438_gen_type [379] = Y2438_pgtype379;
	Y2438_gen_type [380] = Y2438_pgtype380;
	Y2438_gen_type [381] = Y2438_pgtype381;
	Y2438_gen_type [382] = Y2438_pgtype382;
	Y2438_gen_type [383] = Y2438_pgtype383;
	Y2438_gen_type [384] = Y2438_pgtype384;
	Y2438_gen_type [385] = Y2438_pgtype385;
	Y2438_gen_type [386] = Y2438_pgtype386;
	Y2438_gen_type [387] = Y2438_pgtype387;
	Y2438_gen_type [388] = Y2438_pgtype388;
	Y2438_gen_type [389] = Y2438_pgtype389;
	Y2438_gen_type [390] = Y2438_pgtype390;
	Y2438_gen_type [391] = Y2438_pgtype391;
	Y2438_gen_type [392] = Y2438_pgtype392;
	Y2438_gen_type [393] = Y2438_pgtype393;
	Y2438_gen_type [394] = Y2438_pgtype394;
	Y2438_gen_type [395] = Y2438_pgtype395;
	Y2438_gen_type [396] = Y2438_pgtype396;
	Y2438_gen_type [397] = Y2438_pgtype397;
	Y2438_gen_type [398] = Y2438_pgtype398;
	Y2438_gen_type [399] = Y2438_pgtype399;
	Y2438_gen_type [400] = Y2438_pgtype400;
	Y2438_gen_type [401] = Y2438_pgtype401;
	Y2438_gen_type [402] = Y2438_pgtype402;
	Y2438_gen_type [403] = Y2438_pgtype403;
	Y2438_gen_type [404] = Y2438_pgtype404;
	Y2438_gen_type [405] = Y2438_pgtype405;
	Y2438_gen_type [406] = Y2438_pgtype406;
	Y2438_gen_type [407] = Y2438_pgtype407;
	Y2438_gen_type [408] = Y2438_pgtype408;
	Y2438_gen_type [409] = Y2438_pgtype409;
	Y2438_gen_type [410] = Y2438_pgtype410;
	Y2438_gen_type [411] = Y2438_pgtype411;
	Y2438_gen_type [412] = Y2438_pgtype412;
	Y2438_gen_type [413] = Y2438_pgtype413;
	Y2438_gen_type [414] = Y2438_pgtype414;
	Y2438_gen_type [415] = Y2438_pgtype415;
	Y2438_gen_type [416] = Y2438_pgtype416;
	Y2438_gen_type [432] = Y2438_pgtype417;
	Y2438_gen_type [433] = Y2438_pgtype418;
	Y2438_gen_type [434] = Y2438_pgtype419;
	Y2438_gen_type [435] = Y2438_pgtype420;
	Y2438_gen_type [436] = Y2438_pgtype421;
	Y2438_gen_type [437] = Y2438_pgtype422;
	Y2438_gen_type [438] = Y2438_pgtype423;
	Y2438_gen_type [439] = Y2438_pgtype424;
	Y2438_gen_type [440] = Y2438_pgtype425;
	Y2438_gen_type [441] = Y2438_pgtype426;
	Y2438_gen_type [442] = Y2438_pgtype427;
	Y2438_gen_type [443] = Y2438_pgtype428;
	Y2438_gen_type [444] = Y2438_pgtype429;
	Y2438_gen_type [446] = Y2438_pgtype430;
	Y2438_gen_type [447] = Y2438_pgtype431;
	Y2438_gen_type [448] = Y2438_pgtype432;
	Y2438_gen_type [449] = Y2438_pgtype433;
	Y2438_gen_type [450] = Y2438_pgtype434;
	Y2438_gen_type [451] = Y2438_pgtype435;
	Y2438_gen_type [452] = Y2438_pgtype436;
	Y2438_gen_type [453] = Y2438_pgtype437;
	Y2438_gen_type [454] = Y2438_pgtype438;
	Y2438_gen_type [459] = Y2438_pgtype439;
	Y2438_gen_type [460] = Y2438_pgtype440;
	Y2438_gen_type [461] = Y2438_pgtype441;
	Y2438_gen_type [462] = Y2438_pgtype442;
	Y2438_gen_type [463] = Y2438_pgtype443;
	Y2438_gen_type [464] = Y2438_pgtype444;
	Y2438_gen_type [465] = Y2438_pgtype445;
	Y2438_gen_type [466] = Y2438_pgtype446;
	Y2438_gen_type [467] = Y2438_pgtype447;
	Y2438_gen_type [468] = Y2438_pgtype448;
	Y2438_gen_type [469] = Y2438_pgtype449;
	Y2438_gen_type [470] = Y2438_pgtype450;
	Y2438_gen_type [588] = Y2438_pgtype451;
	Y2438_gen_type [669] = Y2438_pgtype452;
	Y2438_gen_type [670] = Y2438_pgtype453;
	Y2438_gen_type [671] = Y2438_pgtype454;
	Y2438_gen_type [672] = Y2438_pgtype455;
	Y2438_gen_type [673] = Y2438_pgtype456;
	Y2438_gen_type [674] = Y2438_pgtype457;
	Y2438_gen_type [675] = Y2438_pgtype458;
	Y2438_gen_type [677] = Y2438_pgtype459;
	Y2438[12] = 910;
	Y2438[13] = 913;
	Y2438[14] = 839;
	Y2438[90] = 842;
	Y2438[91] = 839;
	Y2438[260] = 848;
	{long i; for (i = 323; i < 326; i++) Y2438[i] = 842;};
	Y2438[350] = 848;
	Y2438[454] = 0;
	Y2438[588] = 0;
	{long i; for (i = 669; i < 673; i++) Y2438[i] = 842;};
	{long i; for (i = 673; i < 676; i++) Y2438[i] = 839;};
	Y2438[677] = 842;
}

char *(*R2491[33])();
void R2491_init () {
	R2491[0] = (char *(*)()) F285_2776;
	{long i; for (i = 1; i < 3; i++) R2491[i] = (char *(*)()) F287_2776;}
	R2491[3] = (char *(*)()) F285_2776;
	R2491[4] = (char *(*)()) F287_2776;
	R2491[5] = (char *(*)()) F292_2776;
	R2491[6] = (char *(*)()) F285_2776;
	R2491[7] = (char *(*)()) F287_2776;
	R2491[8] = (char *(*)()) F285_2776;
	R2491[21] = (char *(*)()) F306_2816;
	R2491[22] = (char *(*)()) F307_2816;
	R2491[23] = (char *(*)()) F308_2816;
	R2491[24] = (char *(*)()) F309_2816;
	R2491[25] = (char *(*)()) F310_2816;
	R2491[26] = (char *(*)()) F311_2816;
	R2491[27] = (char *(*)()) F312_2816;
	R2491[28] = (char *(*)()) F313_2816;
	R2491[29] = (char *(*)()) F314_2816;
	R2491[30] = (char *(*)()) F315_2816;
	R2491[31] = (char *(*)()) F316_2816;
	R2491[32] = (char *(*)()) F317_2816;
}

char *(*R2492[33])();
void R2492_init () {
	R2492[0] = (char *(*)()) F285_2777;
	{long i; for (i = 1; i < 3; i++) R2492[i] = (char *(*)()) F287_2777;}
	R2492[3] = (char *(*)()) F285_2777;
	R2492[4] = (char *(*)()) F287_2777;
	R2492[5] = (char *(*)()) F292_2777;
	R2492[6] = (char *(*)()) F285_2777;
	R2492[7] = (char *(*)()) F287_2777;
	R2492[8] = (char *(*)()) F285_2777;
	R2492[21] = (char *(*)()) F318_2835;
	R2492[22] = (char *(*)()) F319_2835;
	R2492[23] = (char *(*)()) F320_2835;
	R2492[24] = (char *(*)()) F321_2835;
	R2492[25] = (char *(*)()) F322_2835;
	R2492[26] = (char *(*)()) F323_2835;
	R2492[27] = (char *(*)()) F324_2835;
	R2492[28] = (char *(*)()) F325_2835;
	R2492[29] = (char *(*)()) F326_2835;
	R2492[30] = (char *(*)()) F327_2835;
	R2492[31] = (char *(*)()) F328_2835;
	R2492[32] = (char *(*)()) F329_2835;
}

char *(*R2500[9])();
void R2500_init () {
	R2500[0] = (char *(*)()) F285_2788;
	{long i; for (i = 1; i < 3; i++) R2500[i] = (char *(*)()) F287_2788;}
	R2500[3] = (char *(*)()) F285_2788;
	R2500[4] = (char *(*)()) F287_2788;
	R2500[5] = (char *(*)()) F292_2788;
	R2500[6] = (char *(*)()) F285_2788;
	R2500[7] = (char *(*)()) F287_2788;
	R2500[8] = (char *(*)()) F285_2788;
}

char *(*R2501[33])();
void R2501_init () {
	R2501[0] = (char *(*)()) F285_2789;
	{long i; for (i = 1; i < 3; i++) R2501[i] = (char *(*)()) F287_2789;}
	R2501[3] = (char *(*)()) F285_2789;
	R2501[4] = (char *(*)()) F287_2789;
	R2501[5] = (char *(*)()) F292_2789;
	R2501[6] = (char *(*)()) F285_2789;
	R2501[7] = (char *(*)()) F287_2789;
	R2501[8] = (char *(*)()) F285_2789;
	R2501[21] = (char *(*)()) F306_2826;
	R2501[22] = (char *(*)()) F307_2826;
	R2501[23] = (char *(*)()) F308_2826;
	R2501[24] = (char *(*)()) F309_2826;
	R2501[25] = (char *(*)()) F310_2826;
	R2501[26] = (char *(*)()) F311_2826;
	R2501[27] = (char *(*)()) F312_2826;
	R2501[28] = (char *(*)()) F313_2826;
	R2501[29] = (char *(*)()) F314_2826;
	R2501[30] = (char *(*)()) F315_2826;
	R2501[31] = (char *(*)()) F316_2826;
	R2501[32] = (char *(*)()) F317_2826;
}

char *(*R2503[9])();
void R2503_init () {
	R2503[0] = (char *(*)()) F285_2793;
	{long i; for (i = 1; i < 3; i++) R2503[i] = (char *(*)()) F287_2793;}
	R2503[3] = (char *(*)()) F285_2793;
	R2503[4] = (char *(*)()) F287_2793;
	R2503[5] = (char *(*)()) F292_2793;
	R2503[6] = (char *(*)()) F303_2804;
	R2503[7] = (char *(*)()) F304_2804;
	R2503[8] = (char *(*)()) F305_2810;
}

char *(*R2504[33])();
void R2504_init () {
	R2504[0] = (char *(*)()) F297_2801;
	R2504[1] = (char *(*)()) F298_2801;
	R2504[2] = (char *(*)()) F299_2801;
	R2504[3] = (char *(*)()) F300_2801;
	R2504[4] = (char *(*)()) F301_2801;
	R2504[5] = (char *(*)()) F302_2801;
	R2504[6] = (char *(*)()) F303_2806;
	R2504[7] = (char *(*)()) F304_2806;
	R2504[8] = (char *(*)()) F305_2812;
	R2504[21] = (char *(*)()) F318_2838;
	R2504[22] = (char *(*)()) F319_2838;
	R2504[23] = (char *(*)()) F320_2838;
	R2504[24] = (char *(*)()) F321_2838;
	R2504[25] = (char *(*)()) F322_2838;
	R2504[26] = (char *(*)()) F323_2838;
	R2504[27] = (char *(*)()) F324_2838;
	R2504[28] = (char *(*)()) F325_2838;
	R2504[29] = (char *(*)()) F326_2838;
	R2504[30] = (char *(*)()) F327_2838;
	R2504[31] = (char *(*)()) F328_2838;
	R2504[32] = (char *(*)()) F329_2838;
}

char *(*R2506[9])();
void R2506_init () {
	R2506[0] = (char *(*)()) F285_2774;
	{long i; for (i = 1; i < 3; i++) R2506[i] = (char *(*)()) F287_2774;}
	R2506[3] = (char *(*)()) F285_2774;
	R2506[4] = (char *(*)()) F287_2774;
	R2506[5] = (char *(*)()) F292_2774;
	R2506[6] = (char *(*)()) F285_2774;
	R2506[7] = (char *(*)()) F287_2774;
	R2506[8] = (char *(*)()) F285_2774;
}

char *(*R2519[12])();
void R2519_init () {
	R2519[0] = (char *(*)()) F318_2839;
	R2519[1] = (char *(*)()) F319_2839;
	R2519[2] = (char *(*)()) F320_2839;
	R2519[3] = (char *(*)()) F321_2839;
	R2519[4] = (char *(*)()) F322_2839;
	R2519[5] = (char *(*)()) F323_2839;
	R2519[6] = (char *(*)()) F324_2839;
	R2519[7] = (char *(*)()) F325_2839;
	R2519[8] = (char *(*)()) F326_2839;
	R2519[9] = (char *(*)()) F327_2839;
	R2519[10] = (char *(*)()) F328_2839;
	R2519[11] = (char *(*)()) F329_2839;
}

char *(*R2521[12])();
void R2521_init () {
	R2521[0] = (char *(*)()) F318_2834;
	R2521[1] = (char *(*)()) F319_2834;
	R2521[2] = (char *(*)()) F320_2834;
	R2521[3] = (char *(*)()) F321_2834;
	R2521[4] = (char *(*)()) F322_2834;
	R2521[5] = (char *(*)()) F323_2834;
	R2521[6] = (char *(*)()) F324_2834;
	R2521[7] = (char *(*)()) F325_2834;
	R2521[8] = (char *(*)()) F326_2834;
	R2521[9] = (char *(*)()) F327_2834;
	R2521[10] = (char *(*)()) F328_2834;
	R2521[11] = (char *(*)()) F329_2834;
}

char *(*R2533[416])();
void R2533_init () {
	R2533[0] = (char *(*)()) F500_2958_2533_2;
	R2533[411] = (char *(*)()) F909_5779_2533_2;
	R2533[412] = (char *(*)()) F912_5917_2533_2;
	R2533[415] = (char *(*)()) F913_5976_2533_2;
}
static EIF_BOOLEAN F500_2958_2533_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F500_2958(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F909_5779_2533_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F909_5779(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F912_5917_2533_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F912_5917(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F913_5976_2533_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F913_5976(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R2534[418])();
void R2534_init () {
	R2534[0] = (char *(*)()) F497_2932;
	{long i; for (i = 64; i < 66; i++) R2534[i] = (char *(*)()) F506_2965;}
	R2534[91] = (char *(*)()) F501_2965;
	R2534[92] = (char *(*)()) F502_2965;
	R2534[93] = (char *(*)()) F504_2965;
	R2534[94] = (char *(*)()) F505_2965;
	R2534[95] = (char *(*)()) F506_2965;
	R2534[96] = (char *(*)()) F507_2965;
	R2534[97] = (char *(*)()) F503_2965;
	R2534[98] = (char *(*)()) F508_2965;
	R2534[99] = (char *(*)()) F509_2965;
	R2534[100] = (char *(*)()) F510_2965;
	R2534[101] = (char *(*)()) F511_2965;
	R2534[102] = (char *(*)()) F512_2965;
	R2534[153] = (char *(*)()) F501_2965;
	R2534[154] = (char *(*)()) F503_2965;
	R2534[156] = (char *(*)()) F501_2965;
	R2534[173] = (char *(*)()) F501_2965;
	R2534[174] = (char *(*)()) F502_2965;
	R2534[175] = (char *(*)()) F504_2965;
	R2534[176] = (char *(*)()) F505_2965;
	R2534[177] = (char *(*)()) F506_2965;
	R2534[178] = (char *(*)()) F507_2965;
	R2534[179] = (char *(*)()) F503_2965;
	R2534[180] = (char *(*)()) F508_2965;
	R2534[181] = (char *(*)()) F509_2965;
	R2534[182] = (char *(*)()) F510_2965;
	R2534[183] = (char *(*)()) F511_2965;
	R2534[184] = (char *(*)()) F512_2965;
	R2534[186] = (char *(*)()) F501_2965;
	{long i; for (i = 187; i < 189; i++) R2534[i] = (char *(*)()) F503_2965;}
	R2534[189] = (char *(*)()) F501_2965;
	R2534[190] = (char *(*)()) F503_2965;
	R2534[191] = (char *(*)()) F508_2965;
	R2534[192] = (char *(*)()) F501_2965;
	R2534[193] = (char *(*)()) F503_2965;
	R2534[194] = (char *(*)()) F501_2965;
	{long i; for (i = 411; i < 413; i++) R2534[i] = (char *(*)()) F506_2965;}
	R2534[415] = (char *(*)()) F502_2965;
	R2534[417] = (char *(*)()) F917_6169;
}

char *(*R2538[418])();
void R2538_init () {
	R2538[0] = (char *(*)()) F358_2867;
	{long i; for (i = 64; i < 66; i++) R2538[i] = (char *(*)()) F361_2867;}
	R2538[91] = (char *(*)()) F356_2867;
	R2538[92] = (char *(*)()) F357_2867;
	R2538[93] = (char *(*)()) F359_2867;
	R2538[94] = (char *(*)()) F360_2867;
	R2538[95] = (char *(*)()) F361_2867;
	R2538[96] = (char *(*)()) F362_2867;
	R2538[97] = (char *(*)()) F358_2867;
	R2538[98] = (char *(*)()) F363_2867;
	R2538[99] = (char *(*)()) F364_2867;
	R2538[100] = (char *(*)()) F365_2867;
	R2538[101] = (char *(*)()) F366_2867;
	R2538[102] = (char *(*)()) F367_2867;
	R2538[153] = (char *(*)()) F356_2867;
	R2538[154] = (char *(*)()) F358_2867;
	R2538[156] = (char *(*)()) F356_2867;
	R2538[173] = (char *(*)()) F356_2867;
	R2538[174] = (char *(*)()) F357_2867;
	R2538[175] = (char *(*)()) F359_2867;
	R2538[176] = (char *(*)()) F360_2867;
	R2538[177] = (char *(*)()) F361_2867;
	R2538[178] = (char *(*)()) F362_2867;
	R2538[179] = (char *(*)()) F358_2867;
	R2538[180] = (char *(*)()) F363_2867;
	R2538[181] = (char *(*)()) F364_2867;
	R2538[182] = (char *(*)()) F365_2867;
	R2538[183] = (char *(*)()) F366_2867;
	R2538[184] = (char *(*)()) F367_2867;
	R2538[186] = (char *(*)()) F356_2867;
	{long i; for (i = 187; i < 189; i++) R2538[i] = (char *(*)()) F358_2867;}
	R2538[189] = (char *(*)()) F356_2867;
	R2538[190] = (char *(*)()) F358_2867;
	R2538[191] = (char *(*)()) F363_2867;
	R2538[192] = (char *(*)()) F356_2867;
	R2538[193] = (char *(*)()) F358_2867;
	R2538[194] = (char *(*)()) F356_2867;
	{long i; for (i = 411; i < 413; i++) R2538[i] = (char *(*)()) F361_2867;}
	R2538[415] = (char *(*)()) F357_2867;
	R2538[417] = (char *(*)()) F361_2867;
}

char *(*R2542[418])();
void R2542_init () {
	R2542[0] = (char *(*)()) F499_2936_2542_1;
	{long i; for (i = 64; i < 66; i++) R2542[i] = (char *(*)()) F563_3003_2542_1;}
	R2542[153] = (char *(*)()) F653_3501;
	R2542[154] = (char *(*)()) F654_3501_2542_1;
	R2542[156] = (char *(*)()) F653_3501;
	R2542[173] = (char *(*)()) F673_3697;
	R2542[174] = (char *(*)()) F674_3697_2542_1;
	R2542[175] = (char *(*)()) F675_3697_2542_1;
	R2542[176] = (char *(*)()) F676_3697_2542_1;
	R2542[177] = (char *(*)()) F677_3697_2542_1;
	R2542[178] = (char *(*)()) F678_3697_2542_1;
	R2542[179] = (char *(*)()) F679_3697_2542_1;
	R2542[180] = (char *(*)()) F680_3697_2542_1;
	R2542[181] = (char *(*)()) F681_3697_2542_1;
	R2542[182] = (char *(*)()) F682_3697_2542_1;
	R2542[183] = (char *(*)()) F683_3697_2542_1;
	R2542[184] = (char *(*)()) F684_3697_2542_1;
	R2542[412] = (char *(*)()) F912_5914_2542_1;
	R2542[417] = (char *(*)()) F563_3003_2542_1;
}
static EIF_REFERENCE F499_2936_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_2936(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F563_3003_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F563_3003(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F654_3501_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F654_3501(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F674_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3697_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3697(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_5914_2542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F912_5914(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2543[418])();
void R2543_init () {
	R2543[0] = (char *(*)()) F382_2886;
	{long i; for (i = 64; i < 66; i++) R2543[i] = (char *(*)()) F563_3024;}
	R2543[153] = (char *(*)()) F653_3512;
	R2543[154] = (char *(*)()) F654_3512;
	R2543[156] = (char *(*)()) F653_3512;
	R2543[173] = (char *(*)()) F603_3455;
	R2543[174] = (char *(*)()) F604_3455;
	R2543[175] = (char *(*)()) F605_3455;
	R2543[176] = (char *(*)()) F606_3455;
	R2543[177] = (char *(*)()) F608_3455;
	R2543[178] = (char *(*)()) F609_3455;
	R2543[179] = (char *(*)()) F607_3455;
	R2543[180] = (char *(*)()) F610_3455;
	R2543[181] = (char *(*)()) F611_3455;
	R2543[182] = (char *(*)()) F612_3455;
	R2543[183] = (char *(*)()) F613_3455;
	R2543[184] = (char *(*)()) F614_3455;
	R2543[412] = (char *(*)()) F397_2894;
	R2543[417] = (char *(*)()) F563_3024;
}

char *(*R2544[354])();
void R2544_init () {
	{long i; for (i = 0; i < 2; i++) R2544[i] = (char *(*)()) F563_3079;}
	R2544[89] = (char *(*)()) F653_3518;
	R2544[90] = (char *(*)()) F654_3518;
	R2544[92] = (char *(*)()) F653_3518;
	R2544[109] = (char *(*)()) F673_3723;
	R2544[110] = (char *(*)()) F674_3723;
	R2544[111] = (char *(*)()) F675_3723;
	R2544[112] = (char *(*)()) F676_3723;
	R2544[113] = (char *(*)()) F677_3723;
	R2544[114] = (char *(*)()) F678_3723;
	R2544[115] = (char *(*)()) F679_3723;
	R2544[116] = (char *(*)()) F680_3723;
	R2544[117] = (char *(*)()) F681_3723;
	R2544[118] = (char *(*)()) F682_3723;
	R2544[119] = (char *(*)()) F683_3723;
	R2544[120] = (char *(*)()) F684_3723;
	R2544[348] = (char *(*)()) F912_5920;
	R2544[353] = (char *(*)()) F563_3079;
}

char *(*R2550[418])();
void R2550_init () {
	R2550[0] = (char *(*)()) F382_2880_2550_4;
	{long i; for (i = 64; i < 66; i++) R2550[i] = (char *(*)()) F397_2897_2550_4;}
	R2550[153] = (char *(*)()) F392_2897;
	R2550[154] = (char *(*)()) F396_2897_2550_4;
	R2550[156] = (char *(*)()) F392_2897;
	R2550[173] = (char *(*)()) F673_3729;
	R2550[174] = (char *(*)()) F674_3729_2550_4;
	R2550[175] = (char *(*)()) F675_3729_2550_4;
	R2550[176] = (char *(*)()) F676_3729_2550_4;
	R2550[177] = (char *(*)()) F677_3729_2550_4;
	R2550[178] = (char *(*)()) F678_3729_2550_4;
	R2550[179] = (char *(*)()) F679_3729_2550_4;
	R2550[180] = (char *(*)()) F680_3729_2550_4;
	R2550[181] = (char *(*)()) F681_3729_2550_4;
	R2550[182] = (char *(*)()) F682_3729_2550_4;
	R2550[183] = (char *(*)()) F683_3729_2550_4;
	R2550[184] = (char *(*)()) F684_3729_2550_4;
	R2550[412] = (char *(*)()) F397_2897_2550_4;
	R2550[417] = (char *(*)()) F397_2897_2550_4;
}
static void F382_2880_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F382_2880(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F397_2897_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F397_2897(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F396_2897_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F396_2897(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F674_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3729(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F675_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_3729(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F676_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F676_3729(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F677_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_3729(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F678_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F678_3729(Current, *(EIF_BOOLEAN *)arg1);
}
static void F679_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F679_3729(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F680_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F680_3729(Current, *(EIF_POINTER *)arg1);
}
static void F681_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F681_3729(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F682_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_3729(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F683_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_3729(Current, *(EIF_REAL_32 *)arg1);
}
static void F684_3729_2550_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_3729(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2551[418])();
void R2551_init () {
	R2551[0] = (char *(*)()) F499_2935;
	{long i; for (i = 64; i < 66; i++) R2551[i] = (char *(*)()) F563_3004;}
	R2551[153] = (char *(*)()) F653_3504;
	R2551[154] = (char *(*)()) F654_3504;
	R2551[156] = (char *(*)()) F653_3504;
	R2551[173] = (char *(*)()) F673_3702;
	R2551[174] = (char *(*)()) F674_3702;
	R2551[175] = (char *(*)()) F675_3702;
	R2551[176] = (char *(*)()) F676_3702;
	R2551[177] = (char *(*)()) F677_3702;
	R2551[178] = (char *(*)()) F678_3702;
	R2551[179] = (char *(*)()) F679_3702;
	R2551[180] = (char *(*)()) F680_3702;
	R2551[181] = (char *(*)()) F681_3702;
	R2551[182] = (char *(*)()) F682_3702;
	R2551[183] = (char *(*)()) F683_3702;
	R2551[184] = (char *(*)()) F684_3702;
	R2551[412] = (char *(*)()) F912_5915;
	R2551[417] = (char *(*)()) F563_3004;
}

char *(*R2554[418])();
void R2554_init () {
	R2554[0] = (char *(*)()) F382_2884;
	{long i; for (i = 64; i < 66; i++) R2554[i] = (char *(*)()) F385_2884;}
	R2554[153] = (char *(*)()) F380_2884;
	R2554[154] = (char *(*)()) F382_2884;
	R2554[156] = (char *(*)()) F380_2884;
	R2554[173] = (char *(*)()) F380_2884;
	R2554[174] = (char *(*)()) F381_2884;
	R2554[175] = (char *(*)()) F383_2884;
	R2554[176] = (char *(*)()) F384_2884;
	R2554[177] = (char *(*)()) F385_2884;
	R2554[178] = (char *(*)()) F386_2884;
	R2554[179] = (char *(*)()) F382_2884;
	R2554[180] = (char *(*)()) F387_2884;
	R2554[181] = (char *(*)()) F388_2884;
	R2554[182] = (char *(*)()) F389_2884;
	R2554[183] = (char *(*)()) F390_2884;
	R2554[184] = (char *(*)()) F391_2884;
	R2554[412] = (char *(*)()) F385_2884;
	R2554[417] = (char *(*)()) F385_2884;
}

char *(*R2555[418])();
void R2555_init () {
	R2555[0] = (char *(*)()) F499_2937;
	{long i; for (i = 64; i < 66; i++) R2555[i] = (char *(*)()) F563_3022;}
	R2555[153] = (char *(*)()) F653_3510;
	R2555[154] = (char *(*)()) F654_3510;
	R2555[156] = (char *(*)()) F653_3510;
	R2555[173] = (char *(*)()) F627_3479;
	R2555[174] = (char *(*)()) F628_3479;
	R2555[175] = (char *(*)()) F629_3479;
	R2555[176] = (char *(*)()) F630_3479;
	R2555[177] = (char *(*)()) F632_3479;
	R2555[178] = (char *(*)()) F633_3479;
	R2555[179] = (char *(*)()) F631_3479;
	R2555[180] = (char *(*)()) F634_3479;
	R2555[181] = (char *(*)()) F635_3479;
	R2555[182] = (char *(*)()) F636_3479;
	R2555[183] = (char *(*)()) F637_3479;
	R2555[184] = (char *(*)()) F638_3479;
	R2555[412] = (char *(*)()) F912_5919;
	R2555[417] = (char *(*)()) F563_3022;
}

char *(*R2556[32])();
void R2556_init () {
	R2556[0] = (char *(*)()) F653_3519;
	R2556[1] = (char *(*)()) F654_3519;
	R2556[3] = (char *(*)()) F655_3553;
	R2556[20] = (char *(*)()) F673_3724;
	R2556[21] = (char *(*)()) F674_3724;
	R2556[22] = (char *(*)()) F675_3724;
	R2556[23] = (char *(*)()) F676_3724;
	R2556[24] = (char *(*)()) F677_3724;
	R2556[25] = (char *(*)()) F678_3724;
	R2556[26] = (char *(*)()) F679_3724;
	R2556[27] = (char *(*)()) F680_3724;
	R2556[28] = (char *(*)()) F681_3724;
	R2556[29] = (char *(*)()) F682_3724;
	R2556[30] = (char *(*)()) F683_3724;
	R2556[31] = (char *(*)()) F684_3724;
}

char *(*R2557[418])();
void R2557_init () {
	R2557[0] = (char *(*)()) F499_2943;
	{long i; for (i = 64; i < 66; i++) R2557[i] = (char *(*)()) F563_3081;}
	R2557[153] = (char *(*)()) F653_3520;
	R2557[154] = (char *(*)()) F654_3520;
	R2557[156] = (char *(*)()) F655_3551;
	R2557[173] = (char *(*)()) F673_3725;
	R2557[174] = (char *(*)()) F674_3725;
	R2557[175] = (char *(*)()) F675_3725;
	R2557[176] = (char *(*)()) F676_3725;
	R2557[177] = (char *(*)()) F677_3725;
	R2557[178] = (char *(*)()) F678_3725;
	R2557[179] = (char *(*)()) F679_3725;
	R2557[180] = (char *(*)()) F680_3725;
	R2557[181] = (char *(*)()) F681_3725;
	R2557[182] = (char *(*)()) F682_3725;
	R2557[183] = (char *(*)()) F683_3725;
	R2557[184] = (char *(*)()) F684_3725;
	R2557[412] = (char *(*)()) F912_5923;
	R2557[417] = (char *(*)()) F563_3081;
}

char *(*R2558[354])();
void R2558_init () {
	{long i; for (i = 0; i < 2; i++) R2558[i] = (char *(*)()) F563_3023;}
	R2558[89] = (char *(*)()) F653_3511;
	R2558[90] = (char *(*)()) F654_3511;
	R2558[92] = (char *(*)()) F653_3511;
	R2558[109] = (char *(*)()) F627_3480;
	R2558[110] = (char *(*)()) F628_3480;
	R2558[111] = (char *(*)()) F629_3480;
	R2558[112] = (char *(*)()) F630_3480;
	R2558[113] = (char *(*)()) F632_3480;
	R2558[114] = (char *(*)()) F633_3480;
	R2558[115] = (char *(*)()) F631_3480;
	R2558[116] = (char *(*)()) F634_3480;
	R2558[117] = (char *(*)()) F635_3480;
	R2558[118] = (char *(*)()) F636_3480;
	R2558[119] = (char *(*)()) F637_3480;
	R2558[120] = (char *(*)()) F638_3480;
	R2558[348] = (char *(*)()) F912_5918;
	R2558[353] = (char *(*)()) F563_3023;
}

char *(*R2559[354])();
void R2559_init () {
	{long i; for (i = 0; i < 2; i++) R2559[i] = (char *(*)()) F563_3082;}
	R2559[92] = (char *(*)()) F655_3552;
	R2559[353] = (char *(*)()) F917_6139;
}

char *(*R2564[263])();
void R2564_init () {
	R2564[0] = (char *(*)()) F653_3526;
	R2564[1] = (char *(*)()) F654_3526_2564_4;
	R2564[3] = (char *(*)()) F656_3571;
	R2564[20] = (char *(*)()) F673_3733;
	R2564[21] = (char *(*)()) F674_3733_2564_4;
	R2564[22] = (char *(*)()) F675_3733_2564_4;
	R2564[23] = (char *(*)()) F676_3733_2564_4;
	R2564[24] = (char *(*)()) F677_3733_2564_4;
	R2564[25] = (char *(*)()) F678_3733_2564_4;
	R2564[26] = (char *(*)()) F679_3733_2564_4;
	R2564[27] = (char *(*)()) F680_3733_2564_4;
	R2564[28] = (char *(*)()) F681_3733_2564_4;
	R2564[29] = (char *(*)()) F682_3733_2564_4;
	R2564[30] = (char *(*)()) F683_3733_2564_4;
	R2564[31] = (char *(*)()) F684_3733_2564_4;
	{long i; for (i = 258; i < 260; i++) R2564[i] = (char *(*)()) F911_5871_2564_4;}
	R2564[262] = (char *(*)()) F915_6071_2564_4;
}
static void F654_3526_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F654_3526(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F674_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3733(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F675_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F675_3733(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F676_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F676_3733(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F677_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_3733(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F678_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F678_3733(Current, *(EIF_BOOLEAN *)arg1);
}
static void F679_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F679_3733(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F680_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F680_3733(Current, *(EIF_POINTER *)arg1);
}
static void F681_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F681_3733(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F682_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_3733(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F683_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_3733(Current, *(EIF_REAL_32 *)arg1);
}
static void F684_3733_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_3733(Current, *(EIF_REAL_64 *)arg1);
}
static void F911_5871_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F911_5871(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F915_6071_2564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F915_6071(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R2568[259])();
void R2568_init () {
	R2568[0] = (char *(*)()) F653_3535;
	R2568[1] = (char *(*)()) F654_3535;
	R2568[3] = (char *(*)()) F655_3564;
	R2568[20] = (char *(*)()) F673_3751;
	R2568[21] = (char *(*)()) F674_3751;
	R2568[22] = (char *(*)()) F675_3751;
	R2568[23] = (char *(*)()) F676_3751;
	R2568[24] = (char *(*)()) F677_3751;
	R2568[25] = (char *(*)()) F678_3751;
	R2568[26] = (char *(*)()) F679_3751;
	R2568[27] = (char *(*)()) F680_3751;
	R2568[28] = (char *(*)()) F681_3751;
	R2568[29] = (char *(*)()) F682_3751;
	R2568[30] = (char *(*)()) F683_3751;
	R2568[31] = (char *(*)()) F684_3751;
	R2568[33] = (char *(*)()) F686_3830;
	R2568[34] = (char *(*)()) F687_3830;
	R2568[35] = (char *(*)()) F688_3830;
	R2568[36] = (char *(*)()) F689_3830;
	R2568[37] = (char *(*)()) F690_3830;
	R2568[38] = (char *(*)()) F691_3830;
	R2568[39] = (char *(*)()) F686_3830;
	R2568[40] = (char *(*)()) F687_3830;
	R2568[41] = (char *(*)()) F686_3830;
	R2568[258] = (char *(*)()) F911_5886;
}

char *(*R2571[325])();
void R2571_init () {
	R2571[0] = (char *(*)()) F591_3387_2571_5;
	R2571[1] = (char *(*)()) F592_3387_2571_5;
	R2571[2] = (char *(*)()) F593_3387_2571_5;
	R2571[3] = (char *(*)()) F594_3387_2571_5;
	R2571[4] = (char *(*)()) F595_3387_2571_5;
	R2571[5] = (char *(*)()) F596_3387_2571_5;
	R2571[6] = (char *(*)()) F597_3387_2571_5;
	R2571[7] = (char *(*)()) F598_3387_2571_5;
	R2571[8] = (char *(*)()) F599_3387_2571_5;
	R2571[9] = (char *(*)()) F600_3387_2571_5;
	R2571[10] = (char *(*)()) F601_3387_2571_5;
	R2571[11] = (char *(*)()) F602_3387_2571_5;
	R2571[62] = (char *(*)()) F603_3444_2571_5;
	R2571[63] = (char *(*)()) F607_3444_2571_5;
	R2571[65] = (char *(*)()) F603_3444_2571_5;
	R2571[82] = (char *(*)()) F673_3698_2571_5;
	R2571[83] = (char *(*)()) F674_3698_2571_5;
	R2571[84] = (char *(*)()) F675_3698_2571_5;
	R2571[85] = (char *(*)()) F676_3698_2571_5;
	R2571[86] = (char *(*)()) F677_3698_2571_5;
	R2571[87] = (char *(*)()) F678_3698_2571_5;
	R2571[88] = (char *(*)()) F679_3698_2571_5;
	R2571[89] = (char *(*)()) F680_3698_2571_5;
	R2571[90] = (char *(*)()) F681_3698_2571_5;
	R2571[91] = (char *(*)()) F682_3698_2571_5;
	R2571[92] = (char *(*)()) F683_3698_2571_5;
	R2571[93] = (char *(*)()) F684_3698_2571_5;
	{long i; for (i = 320; i < 322; i++) R2571[i] = (char *(*)()) F911_5823_2571_5;}
	R2571[324] = (char *(*)()) F915_6024_2571_5;
}
static EIF_REFERENCE F591_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_3387(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F592_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F592_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F594_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F595_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F596_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F597_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F598_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F599_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F599_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F600_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F600_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F601_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F601_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F602_3387_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F602_3387(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_3444_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F603_3444(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F607_3444_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F607_3444(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F673_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F673_3698(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F674_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F674_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F675_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F675_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(866, 0x00).id, 866, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F676_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(860, 0x00).id, 860, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F677_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F679_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F680_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(899, 0x00).id, 899, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F681_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(863, 0x00).id, 863, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F682_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(830, 0x00).id, 830, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F683_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3698_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F684_3698(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(836, 0x00).id, 836, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F911_5823_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F911_5823(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(842, 0x00).id, 842, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F915_6024_2571_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F915_6024(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(839, 0x00).id, 839, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
