/*
 * Code for class BILINEAR [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi490.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F394_2894 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 393, Current, 0, 0, 3884);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F629_3480(Current)) {
		Result = F629_3479(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F394_2897 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 393, Current, 0, 1, 3885);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F629_3480(Current)) {
		tb1 = (EIF_BOOLEAN) !F504_2965(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F675_3725(Current);
	}
	RTHOOK(3);
	F383_2880(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit490 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
