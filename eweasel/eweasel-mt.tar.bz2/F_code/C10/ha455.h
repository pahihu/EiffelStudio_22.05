
#ifndef _C10_ha455_
#define _C10_ha455_

#ifdef __cplusplus
extern "C" {
#endif

extern void F686_3776(EIF_REFERENCE, EIF_INTEGER_32);
extern void F686_3779(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F686_3780(EIF_REFERENCE);
extern EIF_REFERENCE F686_3782(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F686_3784(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F686_3791(EIF_REFERENCE);
extern EIF_REFERENCE F686_3792(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F686_3793(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3794(EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3797(EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3798(EIF_REFERENCE);
extern EIF_BOOLEAN F686_3799(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F686_3800(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F686_3808(EIF_REFERENCE);
extern EIF_BOOLEAN F686_3809(EIF_REFERENCE);
extern EIF_BOOLEAN F686_3814(EIF_REFERENCE, EIF_INTEGER_32);
extern void F686_3816(EIF_REFERENCE);
extern void F686_3818(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3820(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F686_3821(EIF_REFERENCE, EIF_INTEGER_32);
extern void F686_3822(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3823(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3828(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3830(EIF_REFERENCE);
extern void F686_3833(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F686_3834(EIF_REFERENCE, EIF_INTEGER_32);
extern void F686_3835(EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3844(EIF_REFERENCE);
extern EIF_BOOLEAN F686_3845(EIF_REFERENCE);
extern EIF_REFERENCE F686_3852(EIF_REFERENCE);
extern EIF_REFERENCE F686_3853(EIF_REFERENCE);
extern EIF_INTEGER_32 F686_3854(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F686_3855(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F686_3856(EIF_REFERENCE, EIF_INTEGER_32);
extern void F686_3858(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3860(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3861(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3862(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3866(EIF_REFERENCE, EIF_REFERENCE);
extern void F686_3872(EIF_REFERENCE);
extern void F686_3885(EIF_REFERENCE);
extern void EIF_Minit455(void);
extern void F671_3658(EIF_REFERENCE);
extern void F704_4027(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F705_4006(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F704_4024(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F705_4027(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F704_4006(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F704_4017(EIF_REFERENCE);
extern EIF_REFERENCE F671_3659(EIF_REFERENCE);
extern EIF_INTEGER_32 F500_2955(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R3081[])();
extern char *(*R3082[])();
extern char *(*R3083[])();
extern char *(*R3087[])();
extern char *(*R3065[])();
extern char *(*R3047[])();
extern char *(*R2503[])();
extern char *(*R3049[])();
extern char *(*R2506[])();
extern char *(*R3242[])();
extern char *(*R3050[])();
extern char *(*R3045[])();
extern char *(*R2437[])();
extern char *(*R3056[])();
extern char *(*R2574[])();
extern char *(*R2538[])();
extern char *(*R3018[])();
extern char *(*R2054[])();
extern char *(*R2053[])();
extern char *(*R3214[])();
extern char *(*R2055[])();
extern char *(*R3215[])();
extern char *(*R3248[])();
extern char *(*R3022[])();
extern char *(*R3066[])();
extern char *(*R3412[])();
extern char *(*R2061[])();
extern char *(*R3106[])();
extern char *(*R3021[])();
extern char *(*R3039[])();
extern char *(*R3030[])();
extern char *(*R3229[])();
extern char *(*R3032[])();
extern char *(*R3076[])();
extern char *(*R3077[])();
extern char *(*R3093[])();
extern char *(*R3079[])();
extern char *(*R3228[])();
extern char *(*R3038[])();
extern char *(*R2808[])();
extern char *(*R3075[])();
extern long O3068[];
extern long O3108[];
extern long O3072[];
extern long O3073[];
extern long O3031[];
extern long O2536[];
extern long O3058[];
extern long O3059[];
extern long O3074[];
extern long O3060[];
extern long O3061[];
extern long O3062[];
extern long O3063[];
extern long O3064[];
extern long O3022[];
extern long O3067[];
extern EIF_TYPE_INDEX Y2576[];
extern EIF_TYPE_INDEX *Y2576_gen_type [];
extern EIF_TYPE_INDEX Y2438[];
extern EIF_TYPE_INDEX *Y2438_gen_type [];
extern EIF_TYPE_INDEX Y3058[];
extern EIF_TYPE_INDEX *Y3058_gen_type [];
extern EIF_TYPE_INDEX Y3059[];
extern EIF_TYPE_INDEX *Y3059_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
