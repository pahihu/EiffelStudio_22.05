
#ifndef _C10_re463_
#define _C10_re463_

#ifdef __cplusplus
extern "C" {
#endif

extern void F288_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F288_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F288_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F288_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F288_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F288_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F288_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F288_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F288_2789(EIF_REFERENCE);
extern void F288_2791(EIF_REFERENCE);
extern void F288_2793(EIF_REFERENCE);
extern void F288_2794(EIF_REFERENCE);
extern void EIF_Minit463(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
