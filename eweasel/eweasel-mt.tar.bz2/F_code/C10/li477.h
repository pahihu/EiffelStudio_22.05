
#ifndef _C10_li477_
#define _C10_li477_

#ifdef __cplusplus
extern "C" {
#endif

extern void F383_2880(EIF_REFERENCE, EIF_NATURAL_16);
extern EIF_BOOLEAN F383_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F383_2886(EIF_REFERENCE);
extern void EIF_Minit477(void);
extern EIF_NATURAL_16 F675_3697(EIF_REFERENCE);
extern EIF_BOOLEAN F504_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F605_3455(EIF_REFERENCE);
extern void F675_3725(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
