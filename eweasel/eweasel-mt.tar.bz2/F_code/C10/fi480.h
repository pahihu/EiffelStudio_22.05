
#ifndef _C10_fi480_
#define _C10_fi480_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F504_2965(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
