
#ifndef _C10_ty450_
#define _C10_ty450_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F275_2768(EIF_REFERENCE);
extern void EIF_Minit450(void);
extern char *(*R2504[])();
extern char *(*R2491[])();
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
