
#ifndef _C10_bi490_
#define _C10_bi490_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F394_2894(EIF_REFERENCE);
extern void F394_2897(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit490(void);
extern EIF_BOOLEAN F504_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3479(EIF_REFERENCE);
extern void F675_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F629_3480(EIF_REFERENCE);
extern void F383_2880(EIF_REFERENCE, EIF_NATURAL_16);

#ifdef __cplusplus
}
#endif

#endif
