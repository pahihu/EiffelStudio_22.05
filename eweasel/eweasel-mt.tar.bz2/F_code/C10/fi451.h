
#ifndef _C10_fi451_
#define _C10_fi451_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F503_2965(EIF_REFERENCE);
extern void EIF_Minit451(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
