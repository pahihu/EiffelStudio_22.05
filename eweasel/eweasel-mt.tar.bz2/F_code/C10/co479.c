/*
 * Code for class CONTAINER [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co479.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F359_2867 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 358, Current, 0, 0, 3610);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O2536[Dtype(Current)-355]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit479 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
