
#ifndef _C10_ha460_
#define _C10_ha460_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F297_2796(EIF_REFERENCE);
extern EIF_REFERENCE F297_2797(EIF_REFERENCE);
extern EIF_BOOLEAN F297_2799(EIF_REFERENCE);
extern void F297_2800(EIF_REFERENCE);
extern EIF_REFERENCE F297_2801(EIF_REFERENCE);
extern void EIF_Minit460(void);
extern char *(*R2500[])();
extern char *(*R3049[])();
extern char *(*R3050[])();
extern char *(*R3214[])();
extern char *(*R2808[])();
extern long O3058[];
extern long O3059[];

#ifdef __cplusplus
}
#endif

#endif
