
#ifndef _C10_re496_
#define _C10_re496_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F529_2978(EIF_REFERENCE);
extern void F529_2980(EIF_REFERENCE);
extern void EIF_Minit496(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
