
#ifndef _C10_ge473_
#define _C10_ge473_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F308_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F308_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F308_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F308_2826(EIF_REFERENCE);
extern void F308_2829(EIF_REFERENCE);
extern void EIF_Minit473(void);

#ifdef __cplusplus
}
#endif

#endif
