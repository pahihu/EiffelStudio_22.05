
#ifndef _C10_co479_
#define _C10_co479_

#ifdef __cplusplus
extern "C" {
#endif

extern void F359_2867(EIF_REFERENCE);
extern void EIF_Minit479(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
