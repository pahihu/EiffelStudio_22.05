
#ifndef _C10_ty464_
#define _C10_ty464_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F276_2768(EIF_REFERENCE);
extern void EIF_Minit464(void);
extern EIF_INTEGER_32 F308_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
