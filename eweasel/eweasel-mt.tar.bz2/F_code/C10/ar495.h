
#ifndef _C10_ar495_
#define _C10_ar495_

#ifdef __cplusplus
extern "C" {
#endif

extern void F320_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2835(EIF_REFERENCE);
extern EIF_REFERENCE F320_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2839(EIF_REFERENCE);
extern void EIF_Minit495(void);
extern EIF_REFERENCE F675_3696(EIF_REFERENCE);
extern EIF_INTEGER_32 F675_3715(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
