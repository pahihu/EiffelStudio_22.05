
#ifndef _C10_to494_
#define _C10_to494_

#ifdef __cplusplus
extern "C" {
#endif

extern void F195_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F195_2154(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F195_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit494(void);
extern void F701_4006(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
