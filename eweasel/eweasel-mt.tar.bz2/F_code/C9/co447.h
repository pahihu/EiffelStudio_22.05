
#ifndef _C9_co447_
#define _C9_co447_

#ifdef __cplusplus
extern "C" {
#endif

extern void F358_2867(EIF_REFERENCE);
extern void EIF_Minit447(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
