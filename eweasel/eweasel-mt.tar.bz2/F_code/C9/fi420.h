
#ifndef _C9_fi420_
#define _C9_fi420_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F502_2965(EIF_REFERENCE);
extern void EIF_Minit420(void);
extern char *(*R2598[])();

#ifdef __cplusplus
}
#endif

#endif
