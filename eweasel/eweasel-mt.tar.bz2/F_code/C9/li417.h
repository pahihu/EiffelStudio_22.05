
#ifndef _C9_li417_
#define _C9_li417_

#ifdef __cplusplus
extern "C" {
#endif

extern void F381_2880(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_BOOLEAN F381_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F381_2886(EIF_REFERENCE);
extern void EIF_Minit417(void);
extern EIF_BOOLEAN F628_3479(EIF_REFERENCE);
extern EIF_BOOLEAN F502_2965(EIF_REFERENCE);
extern void F674_3725(EIF_REFERENCE);
extern EIF_CHARACTER_32 F674_3697(EIF_REFERENCE);
extern EIF_BOOLEAN F604_3455(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
