
#ifndef _C9_ty403_
#define _C9_ty403_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F274_2768(EIF_REFERENCE);
extern void EIF_Minit403(void);
extern EIF_INTEGER_32 F307_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
