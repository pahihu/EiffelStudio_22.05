
#ifndef _C9_re449_
#define _C9_re449_

#ifdef __cplusplus
extern "C" {
#endif

extern void F287_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F287_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F287_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F287_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F287_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F287_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F287_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F287_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F287_2789(EIF_REFERENCE);
extern void F287_2791(EIF_REFERENCE);
extern void F287_2793(EIF_REFERENCE);
extern void F287_2794(EIF_REFERENCE);
extern void EIF_Minit449(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();
extern long O2507[];
extern long O2511[];
extern long O2512[];
extern long O2513[];
extern long O2514[];
extern long O2515[];

#ifdef __cplusplus
}
#endif

#endif
