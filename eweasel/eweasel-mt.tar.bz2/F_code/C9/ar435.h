
#ifndef _C9_ar435_
#define _C9_ar435_

#ifdef __cplusplus
extern "C" {
#endif

extern void F319_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F319_2835(EIF_REFERENCE);
extern EIF_REFERENCE F319_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F319_2839(EIF_REFERENCE);
extern void EIF_Minit435(void);
extern EIF_INTEGER_32 F674_3715(EIF_REFERENCE);
extern EIF_REFERENCE F674_3696(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
