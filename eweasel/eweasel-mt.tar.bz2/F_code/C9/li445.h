
#ifndef _C9_li445_
#define _C9_li445_

#ifdef __cplusplus
extern "C" {
#endif

extern void F382_2880(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F382_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F382_2886(EIF_REFERENCE);
extern void EIF_Minit445(void);
extern char *(*R2542[])();
extern char *(*R2543[])();
extern char *(*R2555[])();
extern char *(*R2557[])();
extern char *(*R2534[])();
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
