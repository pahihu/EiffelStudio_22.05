
#ifndef _C9_re436_
#define _C9_re436_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F528_2978(EIF_REFERENCE);
extern void F528_2980(EIF_REFERENCE);
extern void EIF_Minit436(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
