
#ifndef _C9_bi430_
#define _C9_bi430_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F393_2894(EIF_REFERENCE);
extern void F393_2897(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit430(void);
extern void F381_2880(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_BOOLEAN F502_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F628_3479(EIF_REFERENCE);
extern void F674_3725(EIF_REFERENCE);
extern EIF_BOOLEAN F628_3480(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
