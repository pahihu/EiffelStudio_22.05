/*
 * Code for class GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_32, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge402.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.item */
EIF_CHARACTER_32 F307_2814 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item", 306, Current, 0, 0, 3188);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	/* INLINED CODE (SPECIAL.item) */
	tw2 = *((EIF_CHARACTER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_)));
	/* END INLINED CODE */
	Result = tw2;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.target_index */
EIF_INTEGER_32 F307_2816 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("target_index", 306, Current, 0, 0, 3190);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) + ((EIF_INTEGER_32) 1L)) - ((EIF_INTEGER_32) 0L));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.after */
EIF_BOOLEAN F307_2823 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("after", 306, Current, 0, 0, 3178);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.is_first */
EIF_BOOLEAN F307_2826 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_first", 306, Current, 0, 0, 3181);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) 0L));
}

/* {GENERAL_SPECIAL_ITERATION_CURSOR}.forth */
void F307_2829 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("forth", 306, Current, 0, 0, 3184);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))++;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit402 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
