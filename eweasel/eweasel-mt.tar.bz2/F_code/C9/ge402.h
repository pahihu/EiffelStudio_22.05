
#ifndef _C9_ge402_
#define _C9_ge402_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F307_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F307_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F307_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F307_2826(EIF_REFERENCE);
extern void F307_2829(EIF_REFERENCE);
extern void EIF_Minit402(void);

#ifdef __cplusplus
}
#endif

#endif
