
#ifndef _C9_to434_
#define _C9_to434_

#ifdef __cplusplus
extern "C" {
#endif

extern void F194_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F194_2154(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F194_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit434(void);
extern void F700_4006(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
