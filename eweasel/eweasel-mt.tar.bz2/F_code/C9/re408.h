
#ifndef _C9_re408_
#define _C9_re408_

#ifdef __cplusplus
extern "C" {
#endif

extern void F286_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F286_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F286_2789(EIF_REFERENCE);
extern void F286_2791(EIF_REFERENCE);
extern void F286_2793(EIF_REFERENCE);
extern void F286_2794(EIF_REFERENCE);
extern void EIF_Minit408(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
