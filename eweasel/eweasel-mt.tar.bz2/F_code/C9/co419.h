
#ifndef _C9_co419_
#define _C9_co419_

#ifdef __cplusplus
extern "C" {
#endif

extern void F357_2867(EIF_REFERENCE);
extern void EIF_Minit419(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
