
#ifndef _C3_po138_
#define _C3_po138_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F161_1647(EIF_REFERENCE);
extern void EIF_Minit138(void);

#ifdef __cplusplus
}
#endif

#endif
