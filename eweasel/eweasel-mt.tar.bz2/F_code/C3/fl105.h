
#ifndef _C3_fl105_
#define _C3_fl105_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F128_1564(EIF_REFERENCE);
extern void EIF_Minit105(void);

#ifdef __cplusplus
}
#endif

#endif
