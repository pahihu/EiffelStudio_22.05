
#ifndef _C3_ba127_
#define _C3_ba127_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F150_1623(EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
