
#ifndef _C3_mi124_
#define _C3_mi124_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F147_1619(EIF_REFERENCE);
extern void EIF_Minit124(void);

#ifdef __cplusplus
}
#endif

#endif
