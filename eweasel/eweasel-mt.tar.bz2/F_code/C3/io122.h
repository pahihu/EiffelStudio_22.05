
#ifndef _C3_io122_
#define _C3_io122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F145_1611(EIF_REFERENCE);
extern void F145_1614(EIF_REFERENCE, EIF_INTEGER_32);
extern void F145_1615(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
