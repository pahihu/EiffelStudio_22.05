
#ifndef _C3_va135_
#define _C3_va135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F158_1639(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
