
#ifndef _C3_ch136_
#define _C3_ch136_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F159_1641(EIF_REFERENCE);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
