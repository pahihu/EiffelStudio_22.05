
#ifndef _C3_ew146_
#define _C3_ew146_

#ifdef __cplusplus
extern "C" {
#endif

extern void F169_1663(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F169_1664(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit146(void);
extern EIF_BOOLEAN F906_5659(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
