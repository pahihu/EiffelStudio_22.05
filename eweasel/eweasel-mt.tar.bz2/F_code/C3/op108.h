
#ifndef _C3_op108_
#define _C3_op108_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F131_1570(EIF_REFERENCE);
extern void F131_1573(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
