
#ifndef _C3_re112_
#define _C3_re112_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F135_1595(EIF_REFERENCE);
extern void EIF_Minit112(void);

#ifdef __cplusplus
}
#endif

#endif
