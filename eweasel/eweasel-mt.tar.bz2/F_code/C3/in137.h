
#ifndef _C3_in137_
#define _C3_in137_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F160_1643(EIF_REFERENCE);
extern void F160_1644(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit137(void);

#ifdef __cplusplus
}
#endif

#endif
