
#ifndef _C3_ei115_
#define _C3_ei115_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F138_1599(EIF_REFERENCE);
extern void F138_1601(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit115(void);

#ifdef __cplusplus
}
#endif

#endif
