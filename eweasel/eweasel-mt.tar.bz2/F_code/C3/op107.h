
#ifndef _C3_op107_
#define _C3_op107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F130_1566(EIF_REFERENCE);
extern void F130_1569(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
