
#ifndef _C3_ew144_
#define _C3_ew144_

#ifdef __cplusplus
extern "C" {
#endif

extern void F167_1657(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F167_1658(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit144(void);
extern EIF_BOOLEAN F926_6352(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
