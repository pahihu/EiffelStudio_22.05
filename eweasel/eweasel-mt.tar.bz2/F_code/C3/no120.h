
#ifndef _C3_no120_
#define _C3_no120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F143_1607(EIF_REFERENCE);
extern void F143_1609(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
