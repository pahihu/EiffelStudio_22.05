
#ifndef _C3_pa148_
#define _C3_pa148_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F171_1668(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit148(void);
extern char *(*R1497[])();

#ifdef __cplusplus
}
#endif

#endif
