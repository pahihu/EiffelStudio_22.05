
#ifndef _C3_ew147_
#define _C3_ew147_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F170_1666(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit147(void);

#ifdef __cplusplus
}
#endif

#endif
