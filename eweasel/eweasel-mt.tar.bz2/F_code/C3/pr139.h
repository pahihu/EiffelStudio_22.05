
#ifndef _C3_pr139_
#define _C3_pr139_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F162_1649(EIF_REFERENCE);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
