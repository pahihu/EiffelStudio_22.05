
#ifndef _C3_ro128_
#define _C3_ro128_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F151_1627(EIF_REFERENCE);
extern void F151_1629(EIF_REFERENCE, EIF_REFERENCE);
extern void F151_1630(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit128(void);

#ifdef __cplusplus
}
#endif

#endif
