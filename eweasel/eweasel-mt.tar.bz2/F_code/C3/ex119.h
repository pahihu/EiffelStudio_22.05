
#ifndef _C3_ex119_
#define _C3_ex119_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F142_1605(EIF_REFERENCE);
extern void EIF_Minit119(void);

#ifdef __cplusplus
}
#endif

#endif
