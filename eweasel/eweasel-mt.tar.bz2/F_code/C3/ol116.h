
#ifndef _C3_ol116_
#define _C3_ol116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F139_1603(EIF_REFERENCE);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
