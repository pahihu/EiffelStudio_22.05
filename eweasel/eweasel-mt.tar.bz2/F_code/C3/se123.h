
#ifndef _C3_se123_
#define _C3_se123_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F146_1617(EIF_REFERENCE);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
