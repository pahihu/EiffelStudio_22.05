
#ifndef _C3_ex111_
#define _C3_ex111_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F134_1593(EIF_REFERENCE);
extern void EIF_Minit111(void);

#ifdef __cplusplus
}
#endif

#endif
