
#ifndef _C3_ew141_
#define _C3_ew141_

#ifdef __cplusplus
extern "C" {
#endif

extern void F164_1654(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit141(void);
extern EIF_REFERENCE F670_3651(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F563_3035(EIF_REFERENCE);
extern EIF_BOOLEAN F563_3026(EIF_REFERENCE);
extern void F908_5737(EIF_REFERENCE);
extern EIF_REFERENCE F54_715(EIF_REFERENCE, EIF_REFERENCE);
extern void F563_2991(EIF_REFERENCE, EIF_REFERENCE);
extern void F941_6682(EIF_REFERENCE, EIF_REFERENCE);
extern void F913_5944(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2598[])();
extern char *(*R2870[])();

#ifdef __cplusplus
}
#endif

#endif
