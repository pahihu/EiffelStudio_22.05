/*
 * Code for class EW_SOURCE_PATH_INST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EW_SOURCE_PATH_INST}.execute */
void F164_1654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("execute", 163, Current, 4, 1, 1712);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F913_5944(RTCW(loc1), tr1);
	RTHOOK(2);
	F908_5737(RTCW(loc1));
	RTHOOK(3);
	loc3 = F54_715(Current, loc1);
	RTHOOK(4);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2598[Dtype(RTCW(loc3))-563])(loc3);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2870[Dtype(RTCW(loc3))-652])(loc3);
		loc2 = F670_3651(RTCW(tr1), tr2);
		RTHOOK(6);
		loc4 = RTLNS(eif_new_type(563, 0x00).id, 563, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F563_2991(RTCW(loc4), loc2);
		RTHOOK(7);
		tb1 = F563_3026(RTCW(loc4));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(8);
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000o\000\000\000u\000\000\000n\000\000\000d\000\000\000",19,1389757796);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			RTHOOK(9);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTHOOK(10);
			tb1 = F563_3035(RTCW(loc4));
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(11);
				tr1 = RTMS32_EX_H("n\000\000\000o\000\000\000t\000\000\000 \000\000\000a\000\000\000 \000\000\000d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000",15,1700642937);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				RTHOOK(12);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(13);
				F941_6682(RTCW(arg1), loc2);
				RTHOOK(14);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		RTHOOK(15);
		tr1 = RTMS32_EX_H("m\000\000\000u\000\000\000s\000\000\000t\000\000\000 \000\000\000b\000\000\000e\000\000\000 \000\000\000e\000\000\000x\000\000\000a\000\000\000c\000\000\000t\000\000\000l\000\000\000y\000\000\000 \000\000\000o\000\000\000n\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",28,1257768820);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(16);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
