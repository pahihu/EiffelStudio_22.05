
#ifndef _C3_ew142_
#define _C3_ew142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F165_1655(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit142(void);
extern EIF_REFERENCE F906_5673(EIF_REFERENCE);
extern EIF_REFERENCE F915_6076(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
