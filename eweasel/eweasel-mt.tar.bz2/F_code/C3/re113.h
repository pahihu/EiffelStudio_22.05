
#ifndef _C3_re113_
#define _C3_re113_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F136_1597(EIF_REFERENCE);
extern void EIF_Minit113(void);

#ifdef __cplusplus
}
#endif

#endif
