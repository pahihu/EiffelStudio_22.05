
#ifndef _C3_lo134_
#define _C3_lo134_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F157_1637(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
