
#ifndef _C3_vo129_
#define _C3_vo129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F152_1631(EIF_REFERENCE);
extern void EIF_Minit129(void);

#ifdef __cplusplus
}
#endif

#endif
