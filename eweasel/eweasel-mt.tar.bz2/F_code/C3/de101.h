
#ifndef _C3_de101_
#define _C3_de101_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F124_1561(EIF_REFERENCE);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
