
#ifndef _C3_vo126_
#define _C3_vo126_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F149_1621(EIF_REFERENCE);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
