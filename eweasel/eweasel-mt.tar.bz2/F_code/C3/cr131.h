
#ifndef _C3_cr131_
#define _C3_cr131_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F154_1633(EIF_REFERENCE);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
