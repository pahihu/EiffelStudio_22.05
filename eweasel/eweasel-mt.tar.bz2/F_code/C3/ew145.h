
#ifndef _C3_ew145_
#define _C3_ew145_

#ifdef __cplusplus
extern "C" {
#endif

extern void F168_1660(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F168_1661(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit145(void);
extern EIF_BOOLEAN F906_5659(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
