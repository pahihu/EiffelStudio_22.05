/*
 * Code for class SORTED_TWO_WAY_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "so938.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SORTED_TWO_WAY_LIST}.extend */
void F656_3571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("extend", 655, Current, 0, 1, 5956);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	F639_3483(Current, tr1);
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F655_3557(Current, tr1);
	RTHOOK(3);
	F655_3552(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {SORTED_TWO_WAY_LIST}.sort */
void F656_3573 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc4);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("sort", 655, Current, 6, 0, 5958);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F501_2965(Current)) {
		RTHOOK(2);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 10L)) / ((EIF_INTEGER_32) 13L));
		for (;;) {
			RTHOOK(3);
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) break;
			RTHOOK(4);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(5);
			F653_3523(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + loc2));
			for (;;) {
				RTHOOK(6);
				if (loc1) break;
				RTHOOK(7);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(8);
				loc3 = *(EIF_REFERENCE *)(Current);
				RTHOOK(9);
				loc4 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				for (;;) {
					RTHOOK(10);
					if ((EIF_BOOLEAN)(loc4 == NULL)) break;
					RTHOOK(11);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTHOOK(12);
						loc5 = *(EIF_REFERENCE *)(RTCW(loc3));
						RTHOOK(13);
						loc6 = *(EIF_REFERENCE *)(RTCW(loc4));
						RTHOOK(14);
						tr1 = RTCCL(loc5);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1497[Dtype(RTCW(loc6))-175])(loc6, tr1);
						if (tb1) {
							RTHOOK(15);
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							RTHOOK(16);
							tr1 = RTCCL(loc5);
							F44_623(RTCW(loc4), tr1);
							RTHOOK(17);
							tr1 = RTCCL(loc6);
							F44_623(RTCW(loc3), tr1);
						}
						RTHOOK(18);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
						loc3 = (EIF_REFERENCE) tr1;
					}
					RTHOOK(19);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
					loc4 = (EIF_REFERENCE) tr1;
				}
			}
			RTHOOK(20);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 10L)) / ((EIF_INTEGER_32) 13L));
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

void EIF_Minit938 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
