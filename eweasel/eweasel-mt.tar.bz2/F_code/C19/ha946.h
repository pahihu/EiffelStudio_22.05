
#ifndef _C19_ha946_
#define _C19_ha946_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F302_2796(EIF_REFERENCE);
extern EIF_REFERENCE F302_2797(EIF_REFERENCE);
extern EIF_BOOLEAN F302_2799(EIF_REFERENCE);
extern void F302_2800(EIF_REFERENCE);
extern EIF_REFERENCE F302_2801(EIF_REFERENCE);
extern void EIF_Minit946(void);
extern EIF_INTEGER_32 F691_3820(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F292_2788(EIF_REFERENCE);
extern EIF_INTEGER_32 F691_3821(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R3214[])();
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
