
#ifndef _C19_pa940_
#define _C19_pa940_

#ifdef __cplusplus
extern "C" {
#endif

extern void F639_3483(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit940(void);
extern void F655_3551(EIF_REFERENCE);
extern EIF_REFERENCE F653_3501(EIF_REFERENCE);
extern void F653_3518(EIF_REFERENCE);
extern char *(*R1498[])();
extern long O2906[];

#ifdef __cplusplus
}
#endif

#endif
