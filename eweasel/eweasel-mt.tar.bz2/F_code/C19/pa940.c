/*
 * Code for class PART_SORTED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa940.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PART_SORTED_LIST}.search_after */
void F639_3483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("search_after", 638, Current, 0, 1, 5781);
	RTGC;
	RTHOOK(1);
	F653_3518(Current);
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current + O2906[Dtype(Current)-652])) {
			tr1 = F653_3501(Current);
			tr2 = RTCCL(tr1);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1498[Dtype(RTCW(arg1))-175])(arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(3);
		F655_3551(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit940 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
