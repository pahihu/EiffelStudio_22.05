
#ifndef _C19_so938_
#define _C19_so938_

#ifdef __cplusplus
extern "C" {
#endif

extern void F656_3571(EIF_REFERENCE, EIF_REFERENCE);
extern void F656_3573(EIF_REFERENCE);
extern void EIF_Minit938(void);
extern void F655_3552(EIF_REFERENCE);
extern void F653_3523(EIF_REFERENCE, EIF_INTEGER_32);
extern void F639_3483(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_3557(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F501_2965(EIF_REFERENCE);
extern void F44_623(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1497[])();

#ifdef __cplusplus
}
#endif

#endif
