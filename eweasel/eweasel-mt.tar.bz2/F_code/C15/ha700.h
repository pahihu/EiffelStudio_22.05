
#ifndef _C15_ha700_
#define _C15_ha700_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F300_2796(EIF_REFERENCE);
extern EIF_INTEGER_32 F300_2797(EIF_REFERENCE);
extern EIF_BOOLEAN F300_2799(EIF_REFERENCE);
extern void F300_2800(EIF_REFERENCE);
extern EIF_REFERENCE F300_2801(EIF_REFERENCE);
extern void EIF_Minit700(void);
extern char *(*R2500[])();
extern char *(*R3049[])();
extern char *(*R3050[])();
extern char *(*R2808[])();
extern long O3058[];
extern long O3059[];

#ifdef __cplusplus
}
#endif

#endif
