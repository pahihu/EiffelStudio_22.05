
#ifndef _C15_ar734_
#define _C15_ar734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F326_2834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F326_2835(EIF_REFERENCE);
extern EIF_REFERENCE F326_2838(EIF_REFERENCE);
extern EIF_INTEGER_32 F326_2839(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern EIF_INTEGER_32 F681_3715(EIF_REFERENCE);
extern EIF_REFERENCE F681_3696(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
