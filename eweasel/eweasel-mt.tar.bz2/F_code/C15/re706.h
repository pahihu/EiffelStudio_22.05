
#ifndef _C15_re706_
#define _C15_re706_

#ifdef __cplusplus
extern "C" {
#endif

extern void F293_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F293_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F293_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F293_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F293_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F293_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F293_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F293_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F293_2789(EIF_REFERENCE);
extern void F293_2791(EIF_REFERENCE);
extern void F293_2793(EIF_REFERENCE);
extern void F293_2794(EIF_REFERENCE);
extern void EIF_Minit706(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
