
#ifndef _C15_ty742_
#define _C15_ty742_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F282_2768(EIF_REFERENCE);
extern void EIF_Minit742(void);
extern EIF_INTEGER_32 F315_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
