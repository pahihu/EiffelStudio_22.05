
#ifndef _C15_li716_
#define _C15_li716_

#ifdef __cplusplus
extern "C" {
#endif

extern void F388_2880(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F388_2884(EIF_REFERENCE);
extern EIF_BOOLEAN F388_2886(EIF_REFERENCE);
extern void EIF_Minit716(void);
extern EIF_BOOLEAN F611_3455(EIF_REFERENCE);
extern EIF_BOOLEAN F635_3479(EIF_REFERENCE);
extern void F681_3725(EIF_REFERENCE);
extern EIF_NATURAL_32 F681_3697(EIF_REFERENCE);
extern EIF_BOOLEAN F509_2965(EIF_REFERENCE);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
