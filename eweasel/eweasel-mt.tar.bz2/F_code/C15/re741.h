
#ifndef _C15_re741_
#define _C15_re741_

#ifdef __cplusplus
extern "C" {
#endif

extern void F294_2774(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F294_2776(EIF_REFERENCE);
extern EIF_INTEGER_32 F294_2777(EIF_REFERENCE);
extern EIF_INTEGER_32 F294_2778(EIF_REFERENCE);
extern EIF_INTEGER_32 F294_2779(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2786(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2787(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2788(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2789(EIF_REFERENCE);
extern void F294_2791(EIF_REFERENCE);
extern void F294_2793(EIF_REFERENCE);
extern void F294_2794(EIF_REFERENCE);
extern void EIF_Minit741(void);
extern char *(*R2810[])();
extern char *(*R2812[])();
extern char *(*R2809[])();

#ifdef __cplusplus
}
#endif

#endif
