
#ifndef _C15_ge744_
#define _C15_ge744_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F315_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F315_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F315_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F315_2826(EIF_REFERENCE);
extern void F315_2829(EIF_REFERENCE);
extern void EIF_Minit744(void);

#ifdef __cplusplus
}
#endif

#endif
