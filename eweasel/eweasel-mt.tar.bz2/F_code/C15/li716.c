/*
 * Code for class LINEAR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li716.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.search */
void F388_2880 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 387, Current, 0, 1, 3836);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O2536[Dtype(Current)-355])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F388_2884(Current)) {
				tb1 = (arg1 == F681_3697(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F681_3725(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F388_2884(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F681_3697(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F681_3725(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F388_2884 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 387, Current, 0, 0, 3826);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F611_3455(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F388_2886 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 387, Current, 0, 0, 3827);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F509_2965(Current)) {
		Result = F635_3479(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit716 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
