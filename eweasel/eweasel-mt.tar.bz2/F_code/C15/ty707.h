
#ifndef _C15_ty707_
#define _C15_ty707_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F281_2768(EIF_REFERENCE);
extern void EIF_Minit707(void);
extern EIF_INTEGER_32 F314_2816(EIF_REFERENCE);
extern char *(*R2808[])();

#ifdef __cplusplus
}
#endif

#endif
