
#ifndef _C15_co718_
#define _C15_co718_

#ifdef __cplusplus
extern "C" {
#endif

extern void F364_2867(EIF_REFERENCE);
extern void EIF_Minit718(void);
extern long O2536[];

#ifdef __cplusplus
}
#endif

#endif
