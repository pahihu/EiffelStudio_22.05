
#ifndef _C15_re735_
#define _C15_re735_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F535_2978(EIF_REFERENCE);
extern void F535_2980(EIF_REFERENCE);
extern void EIF_Minit735(void);
extern char *(*R2601[])();
extern char *(*R2607[])();

#ifdef __cplusplus
}
#endif

#endif
