
#ifndef _C15_ge709_
#define _C15_ge709_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F314_2814(EIF_REFERENCE);
extern EIF_INTEGER_32 F314_2816(EIF_REFERENCE);
extern EIF_BOOLEAN F314_2823(EIF_REFERENCE);
extern EIF_BOOLEAN F314_2826(EIF_REFERENCE);
extern void F314_2829(EIF_REFERENCE);
extern void EIF_Minit709(void);

#ifdef __cplusplus
}
#endif

#endif
