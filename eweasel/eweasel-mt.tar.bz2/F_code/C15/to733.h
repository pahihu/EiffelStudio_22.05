
#ifndef _C15_to733_
#define _C15_to733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F201_2153(EIF_REFERENCE, EIF_INTEGER_32);
extern void F201_2154(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F201_2160(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit733(void);
extern void F707_4006(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1916[];
extern EIF_TYPE_INDEX *Y1916_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
