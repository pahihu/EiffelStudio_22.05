
#ifndef _C15_bi729_
#define _C15_bi729_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F400_2894(EIF_REFERENCE);
extern void F400_2897(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit729(void);
extern void F388_2880(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F509_2965(EIF_REFERENCE);
extern EIF_BOOLEAN F635_3480(EIF_REFERENCE);
extern EIF_BOOLEAN F635_3479(EIF_REFERENCE);
extern void F681_3725(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
