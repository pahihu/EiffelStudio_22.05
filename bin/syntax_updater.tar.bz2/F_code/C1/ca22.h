
#ifndef _C1_ca22_
#define _C1_ca22_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_263(EIF_REFERENCE);
extern void F22_264(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F22_267(EIF_REFERENCE, EIF_INTEGER_32);
extern void F22_268(EIF_REFERENCE);
extern void F22_269(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F1154_10563(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5979[])();

#ifdef __cplusplus
}
#endif

#endif
