
#ifndef _C1_i116_
#define _C1_i116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F16_230(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit16(void);
extern void F147_2012(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
