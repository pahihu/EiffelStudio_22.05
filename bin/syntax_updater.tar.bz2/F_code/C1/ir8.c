/*
 * Code for class IRON_PACKAGE_FILE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir8.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_FILE_FACTORY}.new_package_file */
EIF_REFERENCE F8_96 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_package_file", 7, Current, 1, 1, 89);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(211, 0x01).id, 211, _OBJSIZ_5_2_0_0_0_0_0_0_);
	F212_2973(RTCW(loc1), arg1);
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2874[Dtype(Result)-209]);
	if (tb1) {
		RTHOOK(4);
		Result = RTLNS(eif_new_type(210, 0x01).id, 210, _OBJSIZ_4_2_0_0_0_0_0_0_);
		F211_2960(RTCW(Result), arg1);
		RTHOOK(5);
		tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2874[Dtype(Result)-209]);
		if (tb1) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
