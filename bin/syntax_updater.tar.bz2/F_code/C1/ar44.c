/*
 * Code for class ARGUMENT_EXTERNALS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar44.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F44_697
static EIF_INTEGER_32 inline_F44_697 (void)
{
	#ifdef TIOCGSIZE
	struct ttysize win;
    if (ioctl (STDIN_FILENO, TIOCGSIZE, &win))
        return 0;
    else
        return win.ts_cols;
#elif defined TIOCGWINSZ
	struct winsize win;
    if (ioctl (STDIN_FILENO, TIOCGWINSZ, &win))
        return 0;
    else
        return win.ws_col;
#else
    {
		// Not likely to work because COLUMNS generally is a shell variable.
        const char *s;
        s = getenv ("COLUMNS");
        if (s)
            return strtol (s, 0, 10);
        else
            return 0;
    }
#endif
	;
}
#define INLINE_F44_697
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_EXTERNALS}.c_get_term_columns */
EIF_INTEGER_32 F44_697 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_get_term_columns", 43, Current, 0, 0, 786);
	Result = inline_F44_697 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
