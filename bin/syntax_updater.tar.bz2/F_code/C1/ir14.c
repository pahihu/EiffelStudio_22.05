/*
 * Code for class IRON_STRING_VARIABLE_EXPANSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir14.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_STRING_VARIABLE_EXPANSER}.expand_string_32 */
void F15_229 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,arg2);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("expand_string_32", 14, Current, 6, 2, 222);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) loc1;
	RTHOOK(3);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		RTHOOK(4);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		loc1 = F1094_9671(RTCW(arg1), tw1, loc2);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc2 = (EIF_INTEGER_32) loc1;
			RTHOOK(8);
			loc1++;
			RTHOOK(9);
			tw1 = F1096_9741(RTCW(arg1), loc1);
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
			if ((EIF_BOOLEAN)(tw1 == tw2)) {
				RTHOOK(10);
				loc1++;
				RTHOOK(11);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
				loc3 = F1094_9671(RTCW(arg1), tw1, loc1);
				RTHOOK(12);
				loc5 = F1096_9821(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			} else {
				RTHOOK(13);
				tw1 = F1096_9741(RTCW(arg1), loc1);
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
				if ((EIF_BOOLEAN)(tw1 == tw2)) {
					RTHOOK(14);
					loc1++;
					RTHOOK(15);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
					loc3 = F1094_9671(RTCW(arg1), tw1, loc1);
					RTHOOK(16);
					loc5 = F1096_9821(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				} else {
					RTHOOK(17);
					tb2 = '\01';
					tw1 = F1096_9741(RTCW(arg1), loc1);
					tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb3 = F1044_9352(RTCW(tr1));
					if (!tb3) {
						tw1 = F1096_9741(RTCW(arg1), loc1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						RTHOOK(18);
						loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
						for (;;) {
							RTHOOK(19);
							tb2 = '\01';
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
							if (!(EIF_BOOLEAN) (loc3 > ti4_1)) {
								tb3 = '\01';
								tw1 = F1096_9741(RTCW(arg1), loc3);
								tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
								*(EIF_CHARACTER_32 *)tr1 = tw1;
								tb4 = F1044_9360(RTCW(tr1));
								if (!tb4) {
									tw1 = F1096_9741(RTCW(arg1), loc3);
									tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
									tb3 = (EIF_BOOLEAN)(tw1 == tw2);
								}
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							if (tb2) break;
							RTHOOK(20);
							loc3++;
						}
						RTHOOK(21);
						loc3--;
						RTHOOK(22);
						loc5 = F1096_9821(RTCW(arg1), loc1, loc3);
					} else {
						RTHOOK(23);
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						RTHOOK(24);
						loc5 = (EIF_REFERENCE) NULL;
					}
				}
			}
			RTHOOK(25);
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
				RTHOOK(26);
				tb3 = '\0';
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1039,0xFF01,1093,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = loc5;
					RTAR(tr1,loc5);
					tr1 = F1087_9520(RTCW(arg2), tr1);
					loc6 = tr1;
					tb3 = EIF_TEST(loc6);
				}
				if (tb3) {
					RTHOOK(27);
					F1096_9750(RTCW(arg1), loc6, loc2, loc3);
					RTHOOK(28);
					loc1 = *(EIF_INTEGER_32 *)(loc6 + O7650[Dtype(loc6)-1093]);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc1);
				} else {
					RTHOOK(29);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				}
			}
		}
		RTHOOK(30);
		loc2 = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

void EIF_Minit14 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
