
#ifndef _C1_by35_
#define _C1_by35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F34_466(EIF_REFERENCE);
extern void EIF_Minit35(void);

#ifdef __cplusplus
}
#endif

#endif
