/*
 * Code for class CONF_IRON_INSTALLATION_API_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co26.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_IRON_INSTALLATION_API_FACTORY}.iron_installation_api */
EIF_REFERENCE F26_349 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("iron_installation_api", 25, Current, 0, 2, 364);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(442, 0x01).id, 442, _OBJSIZ_5_0_0_1_0_0_0_0_);
	F442_6172(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
