
#ifndef _C1_ir8_
#define _C1_ir8_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F8_96(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);
extern void F212_2973(EIF_REFERENCE, EIF_REFERENCE);
extern void F211_2960(EIF_REFERENCE, EIF_REFERENCE);
extern long O2874[];

#ifdef __cplusplus
}
#endif

#endif
