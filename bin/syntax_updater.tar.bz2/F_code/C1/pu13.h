
#ifndef _C1_pu13_
#define _C1_pu13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F13_212(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F13_221(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_BOOLEAN);
extern EIF_CHARACTER_8 F13_222(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_NATURAL_32 F13_223(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_REFERENCE);
extern EIF_NATURAL_32 F13_224(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F13_227(EIF_REFERENCE);
extern void EIF_Minit13(void);
extern void F1097_9826(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R7531[])();
extern char *(*R7494[])();
extern char *(*R7758[])();
extern char *(*R7591[])();

#ifdef __cplusplus
}
#endif

#endif
