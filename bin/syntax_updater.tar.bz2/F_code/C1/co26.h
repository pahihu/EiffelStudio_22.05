
#ifndef _C1_co26_
#define _C1_co26_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F26_349(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit26(void);
extern void F442_6172(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
