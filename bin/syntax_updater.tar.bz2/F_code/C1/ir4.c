/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir4.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F4_43 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 3, Current, 0, 0, 52);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1095, 1).id);
	F1091_9529(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F4_46 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 3, Current, 0, 1, 55);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F4_47 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (47,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F4_48 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (48,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F4_49 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (49,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F4_50 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (50,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F4_51 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (51,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F4_52 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("parse", 3, Current, 1, 1, 61);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1007, 0x01).id, 1007, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1008_8833(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6687[Dtype(RTCW(loc1))-1006])(loc1);
	if (tb2) {
		tb2 = F1006_8589(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1006_8621(RTCW(loc1));
		RTHOOK(4);
		F4_53(Current, loc1);
		RTHOOK(5);
		F1006_8638(RTCW(loc1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F4_53 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("parse_file", 3, Current, 2, 1, 62);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	RTHOOK(2);
	loc1 = F629_7216(RTCW(arg1));
	for (;;) {
		RTHOOK(3);
		if (loc1) break;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6743[Dtype(RTCW(arg1))-1006])(arg1, ((EIF_INTEGER_32) 2046L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(loc2))-1098])(loc2, tr1);
		RTHOOK(6);
		loc1 = '\01';
		tb1 = F629_7216(RTCW(arg1));
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	RTHOOK(7);
	F4_54(Current, loc2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F4_54 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_71 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(78, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("parse_text", 3, Current, 1, 1, 63);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1096_9803(RTCW(tr1));
	RTHOOK(2);
	F79_1105(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(3);
	F4_55(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F4_55 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("parse_buffer", 3, Current, 2, 0, 64);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F760_7351(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		RTHOOK(5);
		loc1 = F4_68(Current);
		RTHOOK(6);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				RTHOOK(7);
				loc1 = F4_65(Current);
				RTHOOK(8);
				F4_56(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				RTHOOK(9);
				loc1 = F4_65(Current);
				RTHOOK(10);
				loc2 = F4_71(Current);
				RTHOOK(11);
				tr1 = F1091_9588(RTCV(RTOSCF(47,F4_47, (Current))));
				tb1 = F1094_9684(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(12);
					F4_57(Current);
				} else {
					RTHOOK(13);
					tr1 = F1091_9588(RTCV(RTOSCF(49,F4_49, (Current))));
					tb1 = F1094_9684(RTCW(loc2), tr1);
					if (tb1) {
						RTHOOK(14);
						F4_60(Current);
					} else {
						RTHOOK(15);
						tr1 = F1091_9588(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F4_64(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				RTHOOK(16);
				loc1 = F4_65(Current);
				RTHOOK(17);
				loc2 = F4_71(Current);
				RTHOOK(18);
				tr1 = RTOSCF(48,F4_48, (Current));
				tb1 = F1091_9571(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(19);
					F4_58(Current);
				} else {
					RTHOOK(20);
					tr1 = F1091_9588(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F4_64(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				RTHOOK(21);
				loc1 = F4_65(Current);
				RTHOOK(22);
				loc2 = F4_71(Current);
				RTHOOK(23);
				tr1 = RTOSCF(50,F4_50, (Current));
				tb1 = F1091_9571(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(24);
					F4_62(Current);
				} else {
					RTHOOK(25);
					tr1 = F1091_9588(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F4_64(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				RTHOOK(26);
				loc1 = F4_65(Current);
				RTHOOK(27);
				loc2 = F4_71(Current);
				RTHOOK(28);
				tr1 = F1091_9588(RTCV(RTOSCF(51,F4_51, (Current))));
				tb1 = F1094_9684(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(29);
					tr1 = F1091_9588(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F4_64(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				RTHOOK(30);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					RTHOOK(31);
					tr1 = F1091_9588(RTMS_EX_H("Unexpected null character.",26,830567726));
					F4_64(Current, tr1);
				}
				break;
			default:
				RTHOOK(32);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F4_77(Current, loc1);
				tr1 = F1096_9793(tr1, tr2);
				tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
				tr1 = F1096_9793(RTCW(tr1), tr2);
				F4_64(Current, tr1);
				break;
		}
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F4_56 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("parse_comment", 3, Current, 3, 0, 65);
	RTGC;
	RTHOOK(1);
	loc1 = F4_66(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			RTHOOK(4);
			loc1 = F4_66(Current);
			RTHOOK(5);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(6);
				loc2 = F4_70(Current);
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTHOOK(8);
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				RTHOOK(9);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F4_77(Current, loc1);
				tr1 = F1096_9793(tr1, tr2);
				tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
				tr1 = F1096_9793(RTCW(tr1), tr2);
				F4_64(Current, tr1);
			}
		}
	} else {
		RTHOOK(10);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F4_77(Current, loc1);
		tr1 = F1096_9793(tr1, tr2);
		tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
		tr1 = F1096_9793(RTCW(tr1), tr2);
		F4_64(Current, tr1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F4_57 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTEAA("parse_package_declaration", 3, Current, 3, 0, 66);
	RTGC;
	RTHOOK(1);
	loc2 = F4_68(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F4_65(Current);
		RTHOOK(4);
		loc1 = F4_73(Current);
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc1))-1094])(loc1);
		if (tb1) {
			RTHOOK(6);
			tr1 = F1091_9588(RTMS_EX_H("Invalid package name",20,1534212709));
			F4_64(Current, tr1);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(8);
				F212_2977(loc3, loc1);
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F4_58 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_setup_declaration", 3, Current, 5, 0, 67);
	RTGC;
	RTHOOK(1);
	loc5 = F4_68(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F4_65(Current);
		RTHOOK(4);
		loc1 = F4_75(Current);
		RTHOOK(5);
		loc5 = F4_65(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc1))-1094])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F4_66(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F4_65(Current);
					RTHOOK(11);
					F4_56(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F4_68(Current);
						RTHOOK(14);
						loc5 = F4_65(Current);
						RTHOOK(15);
						loc1 = F4_75(Current);
						RTHOOK(16);
						loc5 = F4_65(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1091_9588(RTMS_EX_H("Invalid setup name",18,1945739621));
					F4_64(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1091_9588(RTCV(RTOSCF(49,F4_49, (Current))));
				tb1 = F1094_9684(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1091_9588(RTCV(RTOSCF(50,F4_50, (Current))));
					tb1 = F1094_9684(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1091_9588(RTCV(RTOSCF(51,F4_51, (Current))));
						tb1 = F1094_9684(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F4_59(Current, loc1);
							RTHOOK(28);
							loc5 = F4_65(Current);
							RTHOOK(29);
							loc5 = F4_68(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F4_65(Current);
								RTHOOK(32);
								F4_56(Current);
								RTHOOK(33);
								loc5 = F4_68(Current);
							}
							RTHOOK(34);
							loc5 = F4_65(Current);
							RTHOOK(35);
							loc1 = F4_75(Current);
							RTHOOK(36);
							loc5 = F4_65(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F4_62(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F4_60(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F4_59 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_setup_item_declaration", 3, Current, 5, 1, 68);
	RTGC;
	RTHOOK(1);
	loc4 = F4_68(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F4_69(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1091_9588(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F4_64(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F4_66(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F4_70(Current);
					RTHOOK(10);
					tb1 = F1091_9547(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1091_9529(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F4_70(Current);
							RTHOOK(14);
							F1096_9759(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1091_9588(RTMS_EX_H("]\"",2,23842));
							tb1 = F1094_9695(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1094_9692(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1096_9774(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1096_9787(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1096_9774(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1096_9787(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F4_78(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1096_9765(RTCW(loc1), loc4);
						RTHOOK(25);
						F1096_9759(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1091_9588(RTMS_EX_H("\"",1,34));
						tb1 = F1094_9695(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1096_9798(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1096_9765(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1091_9529(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1096_9787(RTCW(loc1), tw1);
					RTHOOK(32);
					F1096_9787(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F4_70(Current);
					F1096_9774(RTCW(loc1), tr1);
					RTHOOK(34);
					F1096_9758(RTCW(loc1));
					RTHOOK(35);
					F1096_9759(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1096_9741(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1096_9741(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						RTHOOK(37);
						F1096_9796(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1096_9798(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F4_68(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1091_9529(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F4_65(Current);
					RTHOOK(45);
					loc1 = F4_70(Current);
					RTHOOK(46);
					F1096_9758(RTCW(loc1));
					RTHOOK(47);
					F1096_9759(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1091_9588(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F212_2978(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F4_77(Current, loc4);
		tr1 = F1096_9793(tr1, tr2);
		tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
		tr1 = F1096_9793(RTCW(tr1), tr2);
		F4_64(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F4_60 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_projects_declaration", 3, Current, 5, 0, 69);
	RTGC;
	RTHOOK(1);
	loc5 = F4_68(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F4_65(Current);
		RTHOOK(4);
		loc1 = F4_75(Current);
		RTHOOK(5);
		loc5 = F4_65(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc1))-1094])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F4_66(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F4_65(Current);
					RTHOOK(11);
					F4_56(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F4_68(Current);
						RTHOOK(14);
						loc5 = F4_65(Current);
						RTHOOK(15);
						loc1 = F4_75(Current);
						RTHOOK(16);
						loc5 = F4_65(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1091_9588(RTMS_EX_H("Invalid project name",20,415510117));
					F4_64(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1091_9588(RTCV(RTOSCF(48,F4_48, (Current))));
				tb1 = F1094_9684(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1091_9588(RTCV(RTOSCF(50,F4_50, (Current))));
					tb1 = F1094_9684(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1091_9588(RTCV(RTOSCF(51,F4_51, (Current))));
						tb1 = F1094_9684(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F4_61(Current, loc1);
							RTHOOK(28);
							loc5 = F4_65(Current);
							RTHOOK(29);
							loc5 = F4_68(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F4_65(Current);
								RTHOOK(32);
								F4_56(Current);
								RTHOOK(33);
								loc5 = F4_68(Current);
							}
							RTHOOK(34);
							loc5 = F4_65(Current);
							RTHOOK(35);
							loc1 = F4_75(Current);
							RTHOOK(36);
							loc5 = F4_65(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F4_62(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F4_58(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F4_61 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_project_item_declaration", 3, Current, 4, 1, 70);
	RTGC;
	RTHOOK(1);
	loc2 = F4_68(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		RTHOOK(3);
		loc2 = F4_68(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			RTHOOK(5);
			tr1 = F1091_9588(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F4_64(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				RTHOOK(7);
				loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1091_9529(RTCW(loc1));
				RTHOOK(8);
				loc2 = F4_66(Current);
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					RTHOOK(10);
					F1096_9787(RTCW(loc1), loc2);
					RTHOOK(11);
					loc2 = F4_66(Current);
				}
				RTHOOK(12);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(13);
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						RTHOOK(14);
						F212_2979(loc3, arg1, loc1);
					}
					RTHOOK(15);
					loc2 = F4_68(Current);
				}
			} else {
				RTHOOK(16);
				loc1 = F4_70(Current);
				RTHOOK(17);
				F1096_9758(RTCW(loc1));
				RTHOOK(18);
				F1096_9759(RTCW(loc1));
				RTHOOK(19);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					RTHOOK(20);
					F212_2979(loc4, arg1, loc1);
				}
			}
		}
	} else {
		RTHOOK(21);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F4_77(Current, loc2);
		tr1 = F1096_9793(tr1, tr2);
		tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
		tr1 = F1096_9793(RTCW(tr1), tr2);
		F4_64(Current, tr1);
	}
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F4_62 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_notes_declaration", 3, Current, 3, 0, 71);
	RTGC;
	RTHOOK(1);
	loc2 = F4_68(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F4_65(Current);
		RTHOOK(4);
		loc1 = F4_76(Current);
		RTHOOK(5);
		loc2 = F4_65(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc1))-1094])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc2 = F4_66(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(10);
					loc2 = F4_65(Current);
					RTHOOK(11);
					F4_56(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc2 = F4_68(Current);
						RTHOOK(14);
						loc2 = F4_65(Current);
						RTHOOK(15);
						loc1 = F4_76(Current);
						RTHOOK(16);
						loc2 = F4_65(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1091_9588(RTMS_EX_H("Invalid note name",17,17618021));
					F4_64(Current, tr1);
					RTHOOK(18);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1091_9588(RTCV(RTOSCF(47,F4_47, (Current))));
				tb1 = F1094_9684(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(21);
					tr1 = F1091_9588(RTCV(RTOSCF(48,F4_48, (Current))));
					tb1 = F1094_9684(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(22);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(23);
						tr1 = F1091_9588(RTCV(RTOSCF(51,F4_51, (Current))));
						tb1 = F1094_9684(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(24);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(25);
							F4_63(Current, loc1);
							RTHOOK(26);
							loc2 = F4_65(Current);
							RTHOOK(27);
							loc2 = F4_68(Current);
							for (;;) {
								RTHOOK(28);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								RTHOOK(29);
								loc2 = F4_65(Current);
								RTHOOK(30);
								F4_56(Current);
								RTHOOK(31);
								loc2 = F4_68(Current);
							}
							RTHOOK(32);
							loc2 = F4_65(Current);
							RTHOOK(33);
							loc1 = F4_76(Current);
							RTHOOK(34);
							loc2 = F4_65(Current);
						}
					}
				}
			}
		}
		RTHOOK(35);
		if (loc3) {
			RTHOOK(36);
			tr1 = F1091_9588(RTCV(RTOSCF(47,F4_47, (Current))));
			tb1 = F1094_9684(RTCW(loc1), tr1);
			if (tb1) {
				RTHOOK(37);
				F4_57(Current);
			} else {
				RTHOOK(38);
				tr1 = F1091_9588(RTCV(RTOSCF(48,F4_48, (Current))));
				tb1 = F1094_9684(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(39);
					F4_58(Current);
				}
			}
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F4_63 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_note_item_declaration", 3, Current, 5, 1, 72);
	RTGC;
	RTHOOK(1);
	loc4 = F4_68(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F4_69(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1091_9588(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F4_64(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F4_66(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F4_70(Current);
					RTHOOK(10);
					tb1 = F1091_9547(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1091_9529(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F4_70(Current);
							RTHOOK(14);
							F1096_9759(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1091_9588(RTMS_EX_H("]\"",2,23842));
							tb1 = F1094_9695(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1094_9692(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1096_9774(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1096_9787(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1096_9774(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1096_9787(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F4_78(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1096_9765(RTCW(loc1), loc4);
						RTHOOK(25);
						F1096_9759(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1091_9588(RTMS_EX_H("\"",1,34));
						tb1 = F1094_9695(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1096_9798(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1096_9765(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1091_9529(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1096_9787(RTCW(loc1), tw1);
					RTHOOK(32);
					F1096_9787(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F4_70(Current);
					F1096_9774(RTCW(loc1), tr1);
					RTHOOK(34);
					F1096_9758(RTCW(loc1));
					RTHOOK(35);
					F1096_9759(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1096_9741(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1096_9741(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F1094_9671(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						RTHOOK(37);
						F1096_9796(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1096_9798(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F4_68(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1091_9529(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F4_65(Current);
					RTHOOK(45);
					loc1 = F4_70(Current);
					RTHOOK(46);
					F1096_9758(RTCW(loc1));
					RTHOOK(47);
					F1096_9759(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1091_9588(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F212_2980(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F4_77(Current, loc4);
		tr1 = F1096_9793(tr1, tr2);
		tr2 = F1091_9588(RTMS_EX_H("].",2,23854));
		tr1 = F1096_9793(RTCW(tr1), tr2);
		F4_64(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F4_64 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("report_error", 3, Current, 1, 1, 73);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F4_65 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("previous_character", 3, Current, 0, 0, 74);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		RTHOOK(3);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1096_9741(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		} else {
			RTHOOK(5);
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		RTHOOK(6);
		F4_67(Current);
	} else {
		RTHOOK(7);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		RTHOOK(8);
		tr1 = F1091_9588(RTMS_EX_H("out of input",12,330662516));
		F4_64(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F4_66 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_character", 3, Current, 0, 0, 75);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1091_9588(RTMS_EX_H("out of input",12,330662516));
		F4_64(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1096_9741(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		RTHOOK(6);
		F4_67(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F4_67 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update_end_of_input", 3, Current, 0, 0, 76);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F4_68 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character", 3, Current, 0, 0, 77);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1091_9588(RTMS_EX_H("out of input",12,330662516));
		F4_64(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F4_66(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F1044_9358(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F4_66(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F4_69 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character_until_eol", 3, Current, 0, 0, 78);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1091_9588(RTMS_EX_H("out of input",12,330662516));
		F4_64(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F4_66(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F1044_9358(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F4_66(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F4_70 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("next_text_until_eol", 3, Current, 1, 0, 79);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc1 = F4_66(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		RTHOOK(4);
		F1096_9787(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F4_66(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F4_71 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alphabetic", 3, Current, 1, 0, 40);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc1 = F4_66(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F1044_9352(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1096_9787(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F4_66(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F4_73 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_package_name", 3, Current, 1, 0, 42);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc1 = F4_66(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1044_9360(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1096_9787(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F4_66(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F4_75 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alpha_numeric_or_dash", 3, Current, 1, 0, 44);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc1 = F4_66(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F1044_9360(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1096_9787(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F4_66(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F4_76 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("next_alpha_numeric_with_bracket", 3, Current, 2, 0, 45);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc1 = F4_66(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1044_9360(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1096_9787(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F4_66(Current);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				RTHOOK(8);
				loc2--;
			}
		} else {
			RTHOOK(9);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(10);
				loc2++;
			}
		}
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(12);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		tr1 = F1096_9793(tr1, Result);
		tr2 = F1091_9588(RTMS_EX_H("\"",1,34));
		tr1 = F1096_9793(RTCW(tr1), tr2);
		F4_64(Current, tr1);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F4_77 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("character_to_string", 3, Current, 0, 1, 46);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1094_9659(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	F1096_9787(RTCW(Result), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F4_78 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("normalize_multiline", 3, Current, 6, 1, 47);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) loc1;
	RTHOOK(3);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F1094_9671(RTCW(arg1), tw1, loc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc3 = (EIF_INTEGER_32) loc5;
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				RTHOOK(10);
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					RTHOOK(11);
					tw1 = F1096_9741(RTCW(arg1), loc2);
					tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F1044_9358(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					RTHOOK(12);
					loc2++;
				}
				RTHOOK(13);
				loc6 = F1096_9821(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				RTHOOK(14);
				loc2 = (EIF_INTEGER_32) loc1;
				RTHOOK(15);
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					RTHOOK(16);
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						tw1 = F1096_9741(RTCW(loc6), loc4);
						tw2 = F1096_9741(RTCW(arg1), loc2);
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					RTHOOK(17);
					loc4++;
					RTHOOK(18);
					loc2++;
				}
				RTHOOK(19);
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					tw1 = F1096_9741(RTCW(loc6), loc4);
					tw2 = F1096_9741(RTCW(arg1), loc2);
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					RTHOOK(20);
					F1096_9756(RTCW(loc6), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				}
			}
		}
		RTHOOK(21);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(22);
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		RTHOOK(23);
		tb3 = F1094_9694(RTCW(arg1), loc6);
		if (tb3) {
			RTHOOK(24);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			F1096_9796(RTCW(arg1), ti4_1);
		}
		RTHOOK(25);
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		tr1 = F1096_9793(tr1, loc6);
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F1096_9751(RTCW(arg1), tr1, tr2);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit4 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
