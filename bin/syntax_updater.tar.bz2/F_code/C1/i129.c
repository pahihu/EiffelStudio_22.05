/*
 * Code for class I18N_DATE_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i129.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_FORMATTER}.make */
void F29_365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("make", 28, Current, 0, 1, 382);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(362, 1).id);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_22_);
	F363_5024(RTCW(tr1), tr2, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(362, 1).id);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_24_);
	F363_5024(RTCW(tr1), tr2, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(362, 1).id);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_21_);
	F363_5024(RTCW(tr1), tr2, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
