/*
 * Code for class KL_OPERATING_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_OPERATING_SYSTEM}.is_windows */
static EIF_BOOLEAN F33_388_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("is_windows", 32, Current, 3, 0, 405);
	RTGC;
	RTOSP (388);
#define Result RTOSR(388)
	RTHOOK(1);
	tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
	loc2 = F33_392(Current, tr1);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = RTMS_EX_H("windows",7,1657536371);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-1])(loc2, tr1);
		if (tb1) {
			RTHOOK(4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		RTHOOK(5);
		tr1 = RTMS_EX_H("OS",2,20307);
		loc3 = F33_392(Current, tr1);
		RTHOOK(6);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = RTMS_EX_H("Windows_NT",10,121334100);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc3))-1])(loc3, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(7);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(8);
			loc1 = F33_391(Current);
			RTHOOK(9);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L))) {
				RTHOOK(10);
				tb1 = '\0';
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, ((EIF_INTEGER_32) 2L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ':')) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, ((EIF_INTEGER_32) 3L)));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
				}
				if (tb1) {
					RTHOOK(11);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(12);
					tb1 = '\0';
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\')) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, ((EIF_INTEGER_32) 2L)));
						tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
					}
					if (tb1) {
						RTHOOK(13);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	RTOSE (388);
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F33_388 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(388,F33_388_body,(Current));
}

/* {KL_OPERATING_SYSTEM}.current_working_directory */
EIF_REFERENCE F33_391 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("current_working_directory", 32, Current, 0, 0, 408);
	RTGC;
	RTHOOK(1);
	tr1 = F432_5970(RTCV(RTOSCF(393,F33_393, (Current))));
	Result = F1115_10506(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.variable_value */
EIF_REFERENCE F33_392 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("variable_value", 32, Current, 1, 1, 409);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(393,F33_393, (Current));
	tr1 = F432_5974(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = F1094_9691(loc1);
		if (tb1) {
			RTHOOK(3);
			tr1 = F1091_9582(loc1);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(1024, 0x01).id, 1024, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F1025_9075(RTCW(tr1), loc1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.execution_environment */
static EIF_REFERENCE F33_393_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("execution_environment", 32, Current, 0, 0, 410);
	RTGC;
	RTOSP (393);
#define Result RTOSR(393)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(431, 0x01).id, 431, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (393);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F33_393 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(393,F33_393_body,(Current));
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
