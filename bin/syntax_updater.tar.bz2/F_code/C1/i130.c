/*
 * Code for class I18N_STRING_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i130.h"
#include <ctype.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_STRING_FORMATTER}.default_create */
void F30_372 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("default_create", 29, Current, 0, 0, 389);
	RTHOOK(1);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '$';
	RTHOOK(3);
	RTEE;
}

/* {I18N_STRING_FORMATTER}.formatted_string */
EIF_REFERENCE F30_376 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,loc10);
	RTLIU(8);
	
	RTEAA("formatted_string", 29, Current, 10, 2, 393);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
	RTHOOK(3);
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_);
	loc5 = (EIF_NATURAL_32) tc1;
	RTHOOK(4);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > loc6)) break;
		RTHOOK(7);
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(arg1))-1094])(arg1, loc1);
		RTHOOK(8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc6) && (EIF_BOOLEAN)(loc3 == loc5))) {
			RTHOOK(9);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
			RTHOOK(10);
			loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(arg1))-1094])(arg1, loc2);
			RTHOOK(11);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				RTHOOK(12);
				tb1 = '\01';
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > loc6)) {
					tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_NATURAL_32 *)tr1 = loc4;
					tb3 = F1240_11457(RTCW(tr1));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (!tb2) {
					tc1 = (EIF_CHARACTER_8) loc4;
					tb2 = EIF_TEST(isdigit(tc1));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) break;
				RTHOOK(13);
				tc1 = (EIF_CHARACTER_8) loc4;
				tr1 = eif_out__c1_s1(tc1);
				ti4_1 = F1091_9594(RTCW(tr1));
				loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (loc7 * ((EIF_INTEGER_32) 10L)));
				RTHOOK(14);
				loc2++;
				RTHOOK(15);
				if ((EIF_BOOLEAN) (loc2 <= loc6)) {
					RTHOOK(16);
					loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(arg1))-1094])(arg1, loc2);
				}
			}
			RTHOOK(17);
			if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
				RTHOOK(18);
				tb2 = '\0';
				tb3 = F1040_9200(RTCW(arg2), loc7);
				if (tb3) {
					tr1 = F1040_9173(RTCW(arg2), loc7);
					loc8 = RTCCL(tr1);
					tb2 = EIF_TEST(loc8);
				}
				if (tb2) {
					RTHOOK(19);
					loc9 = RTCCL(loc8);
					loc9 = RTRV(eif_new_type(1090, 0x01),loc9);
					if (EIF_TEST(loc9)) {
						RTHOOK(20);
						F1096_9773(RTCW(Result), loc9);
					} else {
						RTHOOK(21);
						loc10 = RTCCL(loc8);
						loc10 = RTRV(eif_new_type(1090, 0x01),loc10);
						if (EIF_TEST(loc10)) {
							RTHOOK(22);
							tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F1094_9667(RTCW(tr1), loc10);
							F1096_9773(RTCW(Result), tr1);
						} else {
							RTHOOK(23);
							tr1 = RTCCL(loc8);
							tr1 = F30_379(Current, tr1);
							F1096_9773(RTCW(Result), tr1);
						}
					}
				} else {
					RTHOOK(24);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7572[Dtype(RTCW(arg1))-1094])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
					F1096_9773(RTCW(Result), tr1);
				}
				RTHOOK(25);
				loc1 = (EIF_INTEGER_32) loc2;
			} else {
				RTHOOK(26);
				F1093_9629(RTCW(Result), loc3);
				RTHOOK(27);
				loc1++;
			}
		} else {
			RTHOOK(28);
			F1093_9629(RTCW(Result), loc3);
			RTHOOK(29);
			loc1++;
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_STRING_FORMATTER}.out_from_separate_any */
EIF_REFERENCE F30_379 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("out_from_separate_any", 29, Current, 0, 1, 396);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(arg1))-1])(arg1);
	F1097_9834(RTCW(Result), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
