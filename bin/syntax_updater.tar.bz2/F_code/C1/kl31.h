
#ifndef _C1_kl31_
#define _C1_kl31_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,382)
static EIF_REFERENCE F31_382_body(EIF_REFERENCE);
extern EIF_REFERENCE F31_382(EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
