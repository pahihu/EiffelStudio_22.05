
#ifndef _C1_ar44_
#define _C1_ar44_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F44_697(EIF_REFERENCE);
extern void EIF_Minit44(void);

#ifdef __cplusplus
}
#endif

#endif
