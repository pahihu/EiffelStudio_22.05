/*
 * Code for class reference FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi19.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F18_240 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("directory_path_exists", 17, Current, 0, 1, 256);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = F1115_10476(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(435, 0x01).id, 435, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F436_6069(RTCW(tr1), arg1);
		tb1 = F436_6092(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE_UTILITIES}.create_directory */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F18_245 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("create_directory", 17, Current, 2, 1, 261);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(435, 0x01).id, 435, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F436_6067(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tb1 = F436_6092(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			F436_6072(RTCW(loc2));
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(5);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(7);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.file_path_exists */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F18_251 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("file_path_exists", 17, Current, 2, 1, 250);
	RTGC;
	RTE_T
	RTHOOK(1);
	tb1 = '\0';
	tb2 = F1115_10476(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN) !loc2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1006, 0x01).id, 1006, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F1006_8552(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		Result = '\0';
		tb1 = F1006_8586(RTCW(loc1));
		if (tb1) {
			tb1 = F1006_8593(RTCW(loc1));
			Result = tb1;
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(6);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
