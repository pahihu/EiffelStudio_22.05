
#ifndef _C1_ir7_
#define _C1_ir7_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F7_95(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit7(void);
extern void F1103_10032(EIF_REFERENCE, EIF_REFERENCE);
extern void F1105_10093(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1340_14189(EIF_REFERENCE);
extern void F1340_14171(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1091_9576(EIF_REFERENCE, EIF_REFERENCE);
extern void F1103_10030(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
