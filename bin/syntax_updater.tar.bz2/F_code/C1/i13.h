
#ifndef _C1_i13_
#define _C1_i13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3_37(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F3_41(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_CHARACTER_8);
extern void EIF_Minit3(void);
extern void F1096_9735(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_9766(EIF_REFERENCE, EIF_REFERENCE);
extern void F1094_9660(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
