
#ifndef _C1_i128_
#define _C1_i128_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_360(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit28(void);
extern void F144_2002(EIF_REFERENCE, EIF_REFERENCE);
extern long O1689[];

#ifdef __cplusplus
}
#endif

#endif
