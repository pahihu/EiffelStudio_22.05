
#ifndef _C1_kl17_
#define _C1_kl17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F17_231(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
