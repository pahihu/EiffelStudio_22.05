
#ifndef _C1_i129_
#define _C1_i129_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_365(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit29(void);
extern void F363_5024(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
