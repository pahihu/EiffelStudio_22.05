
#ifndef _C1_pc21_
#define _C1_pc21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_253(EIF_REFERENCE);
extern void F21_254(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F21_256(EIF_REFERENCE, EIF_INTEGER_32);
extern void F21_257(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_258(EIF_REFERENCE, EIF_INTEGER_32);
extern void F21_259(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_260(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_261(EIF_REFERENCE);
extern void EIF_Minit21(void);
extern void F1155_10563(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R7706[])();

#ifdef __cplusplus
}
#endif

#endif
