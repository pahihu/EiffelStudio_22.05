/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F9_99 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_file", 8, Current, 0, 1, 92);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F9_105(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F9_105 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_17 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(18, 0x00).id);
	RTLI(21);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,loc13);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc14);
	RTLR(11,loc5);
	RTLR(12,loc15);
	RTLR(13,loc6);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc8);
	RTLR(17,loc9);
	RTLR(18,loc7);
	RTLR(19,loc4);
	RTLR(20,loc18);
	RTLIU(21);
	
	RTEAA("load", 8, Current, 18, 0, 98);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1114, 1).id);
	F1115_10466(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = F9_110(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1321, 0x01).id, 1321, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F1322_13585(RTCW(loc1), loc10);
		RTHOOK(4);
		F1322_13605(RTCW(loc1));
		RTHOOK(5);
		tb1 = '\0';
		tb2 = F1322_13589(RTCW(loc1));
		if (tb2) {
			tr1 = F1322_13601(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F1222_10887(RTCW(tr1), tr2);
			tr1 = F1256_11899(loc11, tr1);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(1255, 0x01),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F1222_10887(RTCW(tr1), tr2);
				tr1 = F1256_11899(loc12, tr1);
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(1221, 0x01),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				RTHOOK(7);
				loc2 = RTLNS(eif_new_type(6, 0x01).id, 6, _OBJSIZ_0_0_0_0_0_0_0_0_);
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F1091_9588(RTCW(tr1));
				loc3 = F7_95(RTCW(loc2), tr1);
			}
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(10);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5826[Dtype(RTCW(loc3))-1102])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				RTHOOK(11);
				tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F1222_10887(RTCW(tr1), tr2);
				tr1 = F1256_11899(loc11, tr1);
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(1221, 0x01),loc14);
				if (EIF_TEST(loc14)) {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F1091_9588(RTCW(tr1));
				}
				RTHOOK(13);
				tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F1222_10887(RTCW(tr1), tr2);
				tr1 = F1256_11899(loc11, tr1);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1221, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					RTHOOK(14);
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F1091_9588(RTCW(tr1));
				}
				RTHOOK(15);
				tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F1222_10887(RTCW(tr1), tr2);
				tr1 = F1256_11899(loc11, tr1);
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(1221, 0x01),loc16);
				if (EIF_TEST(loc16)) {
					RTHOOK(16);
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1102, 0x01),loc17);
					if (EIF_TEST(loc17)) {
						RTHOOK(17);
						tr1 = RTLNSMART(eif_new_type(1114, 1).id);
						tr2 = F1222_10900(loc16);
						F1115_10468(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						RTHOOK(18);
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							RTHOOK(19);
							loc8 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_0_0_0_0_0_0_0_0_);
							RTHOOK(20);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F1115_10495(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F1115_10498(RTCW(tr1), tr2);
							RTHOOK(21);
							tb1 = F19_251(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								RTHOOK(22);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F1115_10495(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F1115_10498(RTCW(tr1), tr2);
							}
							RTHOOK(23);
							tb1 = F19_251(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								RTHOOK(24);
								loc9 = F9_108(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							RTHOOK(25);
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F19_251(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								RTHOOK(26);
								loc4 = F8_96(RTCW(loc8), loc9);
								RTHOOK(27);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2883[Dtype(RTCW(loc4))-210])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						RTHOOK(28);
						tr1 = RTLNSMART(eif_new_type(1114, 1).id);
						tr2 = F1222_10900(loc16);
						F1115_10468(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						RTHOOK(29);
						tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F1222_10887(RTCW(tr1), tr2);
						tr1 = F1256_11899(loc11, tr1);
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(1255, 0x01),loc18);
						if (EIF_TEST(loc18)) {
							RTHOOK(30);
							tr1 = F9_107(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					RTHOOK(31);
					tr1 = RTLNSMART(eif_new_type(1114, 1).id);
					F1115_10466(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F9_107 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(28);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc1);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLR(20,loc16);
	RTLR(21,loc17);
	RTLR(22,loc18);
	RTLR(23,tr3);
	RTLR(24,loc19);
	RTLR(25,loc20);
	RTLR(26,loc21);
	RTLR(27,Current);
	RTLIU(28);
	
	RTEAA("json_object_to_package", 8, Current, 21, 2, 100);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F1222_10887(RTCW(tr1), tr2);
	tr1 = F1256_11899(RTCW(arg1), tr1);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1221, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1221, 0x01),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1103, 0x01).id, 1103, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1104_10047(RTCW(Result), tr1, arg2);
		RTHOOK(3);
		tr1 = F1256_11907(RTCW(arg1));
		tr1 = F1091_9588(RTCW(tr1));
		F1104_10078(RTCW(Result), tr1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1104_10082(RTCW(Result), tr1);
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1221, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			RTHOOK(6);
			tr1 = F1222_10900(loc4);
			F1104_10083(RTCW(Result), tr1);
		}
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1221, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			RTHOOK(8);
			tr1 = F1222_10900(loc5);
			F1104_10084(RTCW(Result), tr1);
		}
		RTHOOK(9);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(1222, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			RTHOOK(10);
			loc1 = *(EIF_REFERENCE *)(loc6);
			RTHOOK(11);
			tb1 = F1091_9565(RTCW(loc1));
			if (tb1) {
				RTHOOK(12);
				tu4_1 = F1091_9599(RTCW(loc1));
				F1104_10085(RTCW(Result), tu4_1);
			}
		}
		RTHOOK(13);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1221, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1104_10087(RTCW(Result), tr1);
		}
		RTHOOK(15);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(1221, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1104_10089(RTCW(Result), tr1);
		}
		RTHOOK(17);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1222, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			RTHOOK(18);
			loc1 = *(EIF_REFERENCE *)(loc9);
			RTHOOK(19);
			tb1 = F1091_9560(RTCW(loc1));
			if (tb1) {
				RTHOOK(20);
				ti4_1 = F1091_9594(RTCW(loc1));
				F1104_10086(RTCW(Result), ti4_1);
			}
		}
		RTHOOK(21);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1254, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			RTHOOK(22);
			tr1 = F1255_11876(loc10);
			loc11 = F950_7857(RTCW(tr1));
			for (;;) {
				tb1 = F552_7140(loc11);
				if (tb1) break;
				RTHOOK(23);
				tr1 = F552_7131(loc11);
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(1221, 0x01),loc12);
				if (EIF_TEST(loc12)) {
					RTHOOK(24);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F950_7883(RTCW(tr1), tr2);
				}
				RTHOOK(25);
				F552_7146(loc11);
			}
		}
		RTHOOK(26);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(1254, 0x01),loc13);
		if (EIF_TEST(loc13)) {
			RTHOOK(27);
			tr1 = F1255_11876(loc13);
			loc14 = F950_7857(RTCW(tr1));
			for (;;) {
				tb2 = F552_7140(loc14);
				if (tb2) break;
				RTHOOK(28);
				tr1 = F552_7131(loc14);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1221, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					RTHOOK(29);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					tr2 = F1222_10900(loc15);
					F950_7883(RTCW(tr1), tr2);
				}
				RTHOOK(30);
				F552_7146(loc14);
			}
		}
		RTHOOK(31);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1255, 0x01),loc16);
		if (EIF_TEST(loc16)) {
			RTHOOK(32);
			loc17 = F1256_11909(loc16);
			for (;;) {
				tb3 = F540_7116(loc17);
				if (tb3) break;
				RTHOOK(33);
				tr1 = F540_7113(loc17);
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(1221, 0x01),loc18);
				if (EIF_TEST(loc18)) {
					RTHOOK(34);
					tr1 = F1222_10900(loc18);
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					tr3 = F540_7114(loc17);
					tr3 = F1222_10900(RTCW(tr3));
					tr2 = F1096_9793(tr2, tr3);
					tr3 = F1091_9588(RTMS_EX_H("]",1,93));
					tr2 = F1096_9793(RTCW(tr2), tr3);
					F1104_10081(RTCW(Result), tr1, tr2);
				}
				RTHOOK(35);
				F540_7117(loc17);
			}
		}
		RTHOOK(36);
		tr1 = RTLNS(eif_new_type(1221, 0x00).id, 1221, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F1222_10887(RTCW(tr1), tr2);
		tr1 = F1256_11899(RTCW(arg1), tr1);
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(1255, 0x01),loc19);
		if (EIF_TEST(loc19)) {
			RTHOOK(37);
			loc20 = F1256_11909(loc19);
			for (;;) {
				tb4 = F540_7116(loc20);
				if (tb4) break;
				RTHOOK(38);
				tr1 = F540_7113(loc20);
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(1221, 0x01),loc21);
				if (EIF_TEST(loc21)) {
					RTHOOK(39);
					tr1 = F1222_10900(loc21);
					tr2 = F540_7114(loc20);
					tr2 = F1222_10900(RTCW(tr2));
					F1104_10081(RTCW(Result), tr1, tr2);
				}
				RTHOOK(40);
				F540_7117(loc20);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F9_108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,Current);
	RTLIU(7);
	
	RTEAA("first_iron_file_path_from", 8, Current, 3, 1, 101);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(435, 0x01).id, 435, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F436_6069(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = F436_6092(RTCW(loc1));
	if (tb1) {
		RTHOOK(3);
		tr1 = F436_6083(RTCW(loc1));
		tr1 = F950_7857(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F552_7140(loc2);
			if (tb1) break;
			RTHOOK(4);
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			RTHOOK(5);
			tb2 = '\01';
			tr1 = F552_7131(loc2);
			tb3 = F1115_10473(RTCW(tr1));
			if (!tb3) {
				tr1 = F552_7131(loc2);
				tb3 = F1115_10474(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				RTHOOK(6);
				tb2 = '\0';
				tr1 = F552_7131(loc2);
				tr1 = F1115_10485(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F1091_9571(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					RTHOOK(7);
					tr1 = F552_7131(loc2);
					Result = F1115_10496(RTCW(arg1), tr1);
				}
			}
			RTHOOK(8);
			F552_7146(loc2);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F9_110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("file_content", 8, Current, 1, 1, 103);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1006, 0x01).id, 1006, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1006_8552(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F1006_8586(RTCW(loc1));
	if (tb2) {
		tb2 = F1006_8605(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1006_8621(RTCW(loc1));
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1097_9826(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			RTHOOK(5);
			tb1 = F629_7216(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			F1006_8700(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
		}
		RTHOOK(8);
		F1006_8638(RTCW(loc1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
