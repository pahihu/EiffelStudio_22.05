/*
 * Code for class IRON_CLIENT_DB
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir12.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT_DB}.make */
void F12_197 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 11, Current, 0, 1, 190);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_CLIENT_DB}.revision */
EIF_INTEGER_32 F12_199 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("revision", 11, Current, 2, 0, 192);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1006, 0x01).id, 1006, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(6133,F438_6133, (RTCW(tr1)));
	F1006_8552(RTCW(loc1), tr1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F1006_8586(RTCW(loc1));
	if (tb2) {
		tb2 = F1006_8589(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1006_8621(RTCW(loc1));
		RTHOOK(4);
		F1006_8699(RTCW(loc1));
		RTHOOK(5);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTHOOK(6);
		tb1 = F1091_9560(RTCW(loc2));
		if (tb1) {
			RTHOOK(7);
			Result = F1091_9594(RTCW(loc2));
		} else {
			RTHOOK(8);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		RTHOOK(9);
		F1006_8638(RTCW(loc1));
	} else {
		RTHOOK(10);
		RTHOOK(11);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repositories */
EIF_REFERENCE F12_200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("repositories", 11, Current, 1, 0, 193);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(207, 0x01).id, 207, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(6132,F438_6132, (RTCW(tr1)));
	F208_2916(RTCW(loc1), tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.installed_packages */
EIF_REFERENCE F12_201 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,Result);
	RTLR(12,loc10);
	RTLR(13,tr2);
	RTLR(14,loc11);
	RTLIU(15);
	
	RTEAA("installed_packages", 11, Current, 11, 0, 194);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F603_7199(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(6136,F438_6136, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1114,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F950_7843(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(105, 0x01).id, 105, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F106_1427(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1115_10487(RTCW(loc1));
	tr1 = F1115_10489(RTCW(tr1));
	F106_1431(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F950_7857(RTCW(loc3));
	for (;;) {
		tb1 = F552_7140(loc6);
		if (tb1) break;
		RTHOOK(8);
		loc4 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F552_7131(loc6);
		F9_99(RTCW(loc4), tr1);
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(10);
			F950_7883(RTCW(loc5), loc7);
		} else {
			RTHOOK(11);
			tb2 = '\0';
			tr1 = F552_7131(loc6);
			tr1 = F12_208(Current, tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tr1 = F12_209(Current, loc8);
				loc9 = tr1;
				tb2 = EIF_TEST(loc9);
			}
			if (tb2) {
				RTHOOK(12);
				F950_7883(RTCW(loc5), loc9);
			}
		}
		RTHOOK(13);
		F552_7146(loc6);
	}
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F950_7864(RTCW(loc5));
	F950_7843(RTCW(Result), ti4_1);
	RTHOOK(15);
	F603_7199(RTCW(Result));
	RTHOOK(16);
	loc10 = F950_7857(RTCV(F12_200(Current)));
	for (;;) {
		tb2 = F552_7140(loc10);
		if (tb2) break;
		RTHOOK(17);
		tb3 = F757_7351(RTCW(loc5));
		if (tb3) break;
		RTHOOK(18);
		F950_7874(RTCW(loc5));
		for (;;) {
			RTHOOK(19);
			tb4 = F914_7703(RTCW(loc5));
			if (tb4) break;
			RTHOOK(20);
			tr1 = F552_7131(loc10);
			tr2 = F950_7848(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5831[Dtype(RTCW(tr1))-1102])(tr1, tr2);
			if (tb5) {
				RTHOOK(21);
				tr1 = F950_7848(RTCW(loc5));
				F950_7883(RTCW(Result), tr1);
				RTHOOK(22);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5884[Dtype(RTCW(loc5))-796])(loc5);
			} else {
				RTHOOK(23);
				F950_7876(RTCW(loc5));
			}
		}
		RTHOOK(24);
		F552_7146(loc10);
	}
	RTHOOK(25);
	tb5 = F757_7351(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb5) {
		RTHOOK(26);
		loc11 = F950_7857(RTCW(loc5));
		for (;;) {
			tb5 = F552_7140(loc11);
			if (tb5) break;
			RTHOOK(27);
			tr1 = F552_7131(loc11);
			F950_7883(RTCW(Result), tr1);
			RTHOOK(28);
			F552_7146(loc11);
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.quick_installed_package */
EIF_REFERENCE F12_202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,arg1);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,tr2);
	RTLR(15,Result);
	RTLIU(16);
	
	RTEAA("quick_installed_package", 11, Current, 11, 1, 195);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1103,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F950_7843(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F603_7199(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(6136,F438_6136, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1114,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F950_7843(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(105, 0x01).id, 105, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F106_1427(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1115_10487(RTCW(loc1));
	tr1 = F1115_10489(RTCW(tr1));
	F106_1431(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F950_7857(RTCW(loc3));
	for (;;) {
		tb1 = F552_7140(loc6);
		if (tb1) break;
		RTHOOK(8);
		tb2 = '\0';
		tr1 = F552_7131(loc6);
		tr1 = F12_208(Current, tr1);
		tr1 = F12_210(Current, tr1);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tb3 = F1091_9571(loc7, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(9);
			loc4 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = F552_7131(loc6);
			F9_99(RTCW(loc4), tr1);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(11);
				F950_7883(RTCW(loc5), loc8);
			} else {
				RTHOOK(12);
				tb2 = '\0';
				tr1 = F552_7131(loc6);
				tr1 = F12_208(Current, tr1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tr1 = F12_209(Current, loc9);
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				if (tb2) {
					RTHOOK(13);
					F950_7883(RTCW(loc5), loc10);
				}
			}
		}
		RTHOOK(14);
		F552_7146(loc6);
	}
	RTHOOK(15);
	loc11 = F950_7857(RTCV(F12_200(Current)));
	for (;;) {
		tb2 = F552_7140(loc11);
		if (tb2) break;
		RTHOOK(16);
		tb3 = '\01';
		tb4 = F757_7351(RTCW(loc5));
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb3) break;
		RTHOOK(17);
		F950_7874(RTCW(loc5));
		for (;;) {
			RTHOOK(18);
			tb4 = '\01';
			tb5 = F914_7703(RTCW(loc5));
			if (!tb5) {
				tb4 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb4) break;
			RTHOOK(19);
			tr1 = F552_7131(loc11);
			tr2 = F950_7848(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5831[Dtype(RTCW(tr1))-1102])(tr1, tr2);
			if (tb5) {
				RTHOOK(20);
				Result = F950_7848(RTCW(loc5));
				RTHOOK(21);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5884[Dtype(RTCW(loc5))-796])(loc5);
			} else {
				RTHOOK(22);
				F950_7876(RTCW(loc5));
			}
		}
		RTHOOK(23);
		F552_7146(loc11);
	}
	RTHOOK(24);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.file_content */
EIF_REFERENCE F12_208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("file_content", 11, Current, 1, 1, 201);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1006, 0x01).id, 1006, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1006_8552(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F1006_8586(RTCW(loc1));
	if (tb2) {
		tb2 = F1006_8605(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1006_8621(RTCW(loc1));
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1097_9826(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			RTHOOK(5);
			tb1 = F629_7216(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			F1006_8700(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
		}
		RTHOOK(8);
		F1006_8638(RTCW(loc1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repo_package_from_json_string */
EIF_REFERENCE F12_209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_from_json_string", 11, Current, 1, 1, 202);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(208, 0x01).id, 208, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = F209_2927(RTCW(loc1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.repo_package_identifier_from_json_string */
EIF_REFERENCE F12_210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_identifier_from_json_string", 11, Current, 1, 1, 203);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(208, 0x01).id, 208, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(3);
		tr1 = F209_2929(RTCW(loc1), arg1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
