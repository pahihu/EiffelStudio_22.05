/*
 * Code for class PATTERN_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa135.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PATTERN_MATCHER}.wipe_out */
void F158_2148 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("wipe_out", 157, Current, 0, 0, 2293);
	RTGC;
	RTHOOK(1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	tr1 = RTOSCF(2168,F158_2168, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {PATTERN_MATCHER}.no_subject */

EIF_REFERENCE F158_2168 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2168,RTMS_EX_H("",0,0));
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
