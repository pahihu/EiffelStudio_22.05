/*
 * Code for class I18N_LOCALE_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1106.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_INFO}.make */
void F129_1828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("make", 128, Current, 0, 0, 2016);
	RTGC;
	RTHOOK(1);
	F128_1788(Current);
	RTHOOK(2);
	F126_1758(Current);
	RTHOOK(3);
	F125_1710(Current);
	RTHOOK(4);
	{
		/* INLINED CODE (I18N_CODE_PAGE_INFO.initialize_code_page_info) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1257, 1).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1258_11921(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {I18N_LOCALE_INFO}.set_id */
void F129_1830 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_id", 128, Current, 0, 1, 2014);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit106 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
