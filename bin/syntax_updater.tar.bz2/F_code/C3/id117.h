
#ifndef _C3_id117_
#define _C3_id117_

#ifdef __cplusplus
extern "C" {
#endif

extern void F140_1960(EIF_REFERENCE);
extern void EIF_Minit117(void);
extern long O1931[];

#ifdef __cplusplus
}
#endif

#endif
