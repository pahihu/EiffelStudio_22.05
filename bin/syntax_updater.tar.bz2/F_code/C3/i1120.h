
#ifndef _C3_i1120_
#define _C3_i1120_

#ifdef __cplusplus
extern "C" {
#endif

extern void F143_1987(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
