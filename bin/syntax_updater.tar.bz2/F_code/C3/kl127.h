
#ifndef _C3_kl127_
#define _C3_kl127_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2029)
static EIF_REFERENCE F150_2029_body(EIF_REFERENCE);
extern EIF_REFERENCE F150_2029(EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
