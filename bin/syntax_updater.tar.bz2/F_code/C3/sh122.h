
#ifndef _C3_sh122_
#define _C3_sh122_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2004)
static EIF_REFERENCE F145_2004_body(EIF_REFERENCE);
extern EIF_REFERENCE F145_2004(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
