/*
 * Code for class KI_CHARACTER_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ki141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_CHARACTER_BUFFER}.unicode_item */
EIF_CHARACTER_32 F166_2200 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unicode_item", 165, Current, 0, 1, 2346);
	RTGC;
	RTHOOK(1);
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2149[Dtype(Current)-1001])(Current, arg1));
	Result = (EIF_CHARACTER_32) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {KI_CHARACTER_BUFFER}.item_code */
EIF_NATURAL_32 F166_2201 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item_code", 165, Current, 0, 1, 2332);
	RTGC;
	RTHOOK(1);
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2149[Dtype(Current)-1001])(Current, arg1));
	Result = (EIF_NATURAL_32) tc1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {KI_CHARACTER_BUFFER}.as_special */
EIF_REFERENCE F166_2207 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_special", 165, Current, 0, 0, 2337);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {KI_CHARACTER_BUFFER}.as_unicode_special */
EIF_REFERENCE F166_2208 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_unicode_special", 165, Current, 0, 0, 2338);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {KI_CHARACTER_BUFFER}.fill_from_string */
void F166_2212 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("fill_from_string", 165, Current, 0, 2, 2342);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R2172[Dtype(Current)-1001])(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
