/*
 * Code for class SHARED_CHARACTER_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh115.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_CHARACTER_SETS}.default_character_case_mapping */
static EIF_REFERENCE F138_1916_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("default_character_case_mapping", 137, Current, 0, 0, 2096);
	RTGC;
	RTOSP (1916);
#define Result RTOSR(1916)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(21, 0x01).id, 21, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	tr3 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F22_264(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1916);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1916 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1916,F138_1916_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.default_word_set */
static EIF_REFERENCE F138_1917_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("default_word_set", 137, Current, 0, 0, 2097);
	RTGC;
	RTOSP (1917);
#define Result RTOSR(1917)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_",63,1064094303);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1917);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1917 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1917,F138_1917_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.upper_set */
static EIF_REFERENCE F138_1918_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("upper_set", 137, Current, 0, 0, 2098);
	RTGC;
	RTOSP (1918);
#define Result RTOSR(1918)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1918);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1918 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1918,F138_1918_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.lower_set */
static EIF_REFERENCE F138_1919_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("lower_set", 137, Current, 0, 0, 2099);
	RTGC;
	RTOSP (1919);
#define Result RTOSR(1919)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1919);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1919 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1919,F138_1919_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alpha_set */
static EIF_REFERENCE F138_1920_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("alpha_set", 137, Current, 0, 0, 2100);
	RTGC;
	RTOSP (1920);
#define Result RTOSR(1920)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F21_253(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(1919,F138_1919, (Current));
	F21_259(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(1918,F138_1918, (Current));
	F21_259(RTCW(Result), tr1);
	RTOSE (1920);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1920 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1920,F138_1920_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.digit_set */
static EIF_REFERENCE F138_1921_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("digit_set", 137, Current, 0, 0, 2101);
	RTGC;
	RTOSP (1921);
#define Result RTOSR(1921)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789",10,593348409);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1921);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1921 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1921,F138_1921_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alnum_set */
static EIF_REFERENCE F138_1922_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("alnum_set", 137, Current, 0, 0, 2085);
	RTGC;
	RTOSP (1922);
#define Result RTOSR(1922)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F21_253(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(1920,F138_1920, (Current));
	F21_259(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(1921,F138_1921, (Current));
	F21_259(RTCW(Result), tr1);
	RTOSE (1922);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1922 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1922,F138_1922_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.xdigit_set */
static EIF_REFERENCE F138_1923_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("xdigit_set", 137, Current, 0, 0, 2086);
	RTGC;
	RTOSP (1923);
#define Result RTOSR(1923)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefABCDEF",22,1983803462);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1923);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1923 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1923,F138_1923_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.cntrl_set */
static EIF_REFERENCE F138_1924_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cntrl_set", 137, Current, 1, 0, 2087);
	RTGC;
	RTOSP (1924);
#define Result RTOSR(1924)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F21_253(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 31L))) break;
		RTHOOK(4);
		F21_258(RTCW(Result), loc1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	F21_258(RTCW(Result), ((EIF_INTEGER_32) 127L));
	RTOSE (1924);
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1924 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1924,F138_1924_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.graph_set */
static EIF_REFERENCE F138_1925_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("graph_set", 137, Current, 0, 0, 2088);
	RTGC;
	RTOSP (1925);
#define Result RTOSR(1925)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",94,554150526);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1925);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1925 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1925,F138_1925_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.print_set */
static EIF_REFERENCE F138_1926_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("print_set", 137, Current, 0, 0, 2089);
	RTGC;
	RTOSP (1926);
#define Result RTOSR(1926)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H(" !\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",95,1652388478);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1926);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1926 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1926,F138_1926_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.punct_set */
static EIF_REFERENCE F138_1927_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("punct_set", 137, Current, 0, 0, 2090);
	RTGC;
	RTOSP (1927);
#define Result RTOSR(1927)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./:;<=>\?@[\\]^_`{|}~",32,391924606);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1927);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1927 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1927,F138_1927_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.ascii_set */
static EIF_REFERENCE F138_1928_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ascii_set", 137, Current, 1, 0, 2091);
	RTGC;
	RTOSP (1928);
#define Result RTOSR(1928)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F21_253(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 127L))) break;
		RTHOOK(4);
		F21_258(RTCW(Result), loc1);
		RTHOOK(5);
		loc1++;
	}
	RTOSE (1928);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1928 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1928,F138_1928_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.space_set */
static EIF_REFERENCE F138_1929_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("space_set", 137, Current, 0, 0, 2092);
	RTGC;
	RTOSP (1929);
#define Result RTOSR(1929)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("\011\012\014\015\013 ",6,219952928);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1929);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1929 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1929,F138_1929_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.meta_set */
static EIF_REFERENCE F138_1930_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("meta_set", 137, Current, 0, 0, 2093);
	RTGC;
	RTOSP (1930);
#define Result RTOSR(1930)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(20, 0x01).id, 20, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*+\?{^.$|()[",11,572368475);
	F21_254(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1930);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1930 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1930,F138_1930_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_names */
static EIF_REFERENCE F138_1931_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("class_names", 137, Current, 0, 0, 2094);
	RTGC;
	RTOSP (1931);
#define Result RTOSR(1931)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,1098,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("alpha",5,1820051041);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("lower",5,1870925170);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("upper",5,1887312754);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("alnum",5,1819923309);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("ascii",5,1936639849);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("cntrl",5,1853885548);
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("digit",5,1769152884);
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("graph",5,1919779432);
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("print",5,1920372340);
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("punct",5,1971028852);
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("space",5,1886313829);
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("word",4,2003792484);
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("xdigit",6,2005082484);
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1931);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1931 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1931,F138_1931_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_sets */
static EIF_REFERENCE F138_1932_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("class_sets", 137, Current, 0, 0, 2095);
	RTGC;
	RTOSP (1932);
#define Result RTOSR(1932)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,20,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOSCF(1920,F138_1920, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1919,F138_1919, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1918,F138_1918, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1922,F138_1922, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1928,F138_1928, (Current));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1924,F138_1924, (Current));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1921,F138_1921, (Current));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1925,F138_1925, (Current));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1926,F138_1926, (Current));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1927,F138_1927, (Current));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1929,F138_1929, (Current));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1917,F138_1917, (Current));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1923,F138_1923, (Current));
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1932);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_1932 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1932,F138_1932_body,(Current));
}

void EIF_Minit115 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
