/*
 * Code for class OPTION_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "op116.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OPTION_ROUTINES}.is_option_caseless */
EIF_BOOLEAN F139_1934 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_caseless", 138, Current, 0, 1, 2103);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_multiline */
EIF_BOOLEAN F139_1935 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_multiline", 138, Current, 0, 1, 2104);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_dotall */
EIF_BOOLEAN F139_1936 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_dotall", 138, Current, 0, 1, 2105);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_undef */
EIF_BOOLEAN F139_1939 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_undef", 138, Current, 0, 1, 2108);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 32L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.set_option_caseless */
EIF_INTEGER_32 F139_1941 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_caseless", 138, Current, 0, 1, 2110);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_caseless */
EIF_INTEGER_32 F139_1942 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_caseless", 138, Current, 0, 1, 2111);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_multiline */
EIF_INTEGER_32 F139_1943 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_multiline", 138, Current, 0, 1, 2112);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_multiline */
EIF_INTEGER_32 F139_1944 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_multiline", 138, Current, 0, 1, 2113);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_dotall */
EIF_INTEGER_32 F139_1945 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_dotall", 138, Current, 0, 1, 2114);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 4L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_dotall */
EIF_INTEGER_32 F139_1946 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_dotall", 138, Current, 0, 1, 2115);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 4L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.to_option_ims */
EIF_INTEGER_32 F139_1953 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_option_ims", 138, Current, 0, 1, 2122);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		Result += ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(5);
		Result += ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(7);
		RTHOOK(8);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 4L));
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
