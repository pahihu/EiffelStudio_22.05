
#ifndef _C3_i1106_
#define _C3_i1106_

#ifdef __cplusplus
extern "C" {
#endif

extern void F129_1828(EIF_REFERENCE);
extern void F129_1830(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit106(void);
extern void F128_1788(EIF_REFERENCE);
extern void F1258_11921(EIF_REFERENCE, EIF_REFERENCE);
extern void F125_1710(EIF_REFERENCE);
extern void F126_1758(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
