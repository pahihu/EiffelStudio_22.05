
#ifndef _C3_pa135_
#define _C3_pa135_

#ifdef __cplusplus
extern "C" {
#endif

extern void F158_2148(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 2168)


extern EIF_REFERENCE F158_2168(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
