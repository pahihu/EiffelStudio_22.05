
#ifndef _C3_uc108_
#define _C3_uc108_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1853)
static EIF_REFERENCE F131_1853_body(EIF_REFERENCE);
extern EIF_REFERENCE F131_1853(EIF_REFERENCE);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
