/*
 * Code for class ARGUMENT_VALUE_VALIDATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar146.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_VALUE_VALIDATOR}.reason */
EIF_REFERENCE F171_2240 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("reason", 170, Current, 1, 0, 2372);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1094, 0x01).id, 1094, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1091_9529(RTCW(Result));
		RTHOOK(4);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_VALUE_VALIDATOR}.validate */
void F171_2244 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("validate", 170, Current, 0, 1, 2376);
	RTGC;
	RTHOOK(1);
	F171_2246(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	{
		/* INLINED CODE (ARGUMENT_VALUE_VALIDATOR.validate_value) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {ARGUMENT_VALUE_VALIDATOR}.reset */
void F171_2246 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset", 170, Current, 0, 0, 2377);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
