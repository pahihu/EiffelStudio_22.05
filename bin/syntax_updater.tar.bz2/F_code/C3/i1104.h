
#ifndef _C3_i1104_
#define _C3_i1104_

#ifdef __cplusplus
extern "C" {
#endif

extern void F127_1780(EIF_REFERENCE);
extern void F127_1785(EIF_REFERENCE, EIF_REFERENCE);
extern void F127_1786(EIF_REFERENCE, EIF_REFERENCE);
extern void F127_1787(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit104(void);
extern EIF_REFERENCE F1091_9582(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
