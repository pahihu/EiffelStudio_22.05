/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1103.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F126_1758 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 125, Current, 0, 0, 1956);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1766,F126_1766, (Current));
	F126_1773(Current, tr1);
	RTHOOK(2);
	F126_1774(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	tr1 = RTOSCF(1768,F126_1768, (Current));
	F126_1775(Current, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(1769,F126_1769, (Current));
	F126_1776(Current, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(1772,F126_1772, (Current));
	F126_1779(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(1770,F126_1770, (Current));
	F126_1777(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(1771,F126_1771, (Current));
	F126_1778(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F126_1766_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_decimal_separator", 125, Current, 0, 0, 1964);
	RTGC;
	RTOSP (1766);
#define Result RTOSR(1766)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1766);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1766 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1766,F126_1766_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F126_1768_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_group_separator", 125, Current, 0, 0, 1944);
	RTGC;
	RTOSP (1768);
#define Result RTOSR(1768)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1768);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1768 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1768,F126_1768_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F126_1769_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_number_list_separator", 125, Current, 0, 0, 1945);
	RTGC;
	RTOSP (1769);
#define Result RTOSR(1769)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1769);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1769 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1769,F126_1769_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F126_1770_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_positive_sign", 125, Current, 0, 0, 1946);
	RTGC;
	RTOSP (1770);
#define Result RTOSR(1770)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1770);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1770 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1770,F126_1770_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F126_1771_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_negative_sign", 125, Current, 0, 0, 1947);
	RTGC;
	RTOSP (1771);
#define Result RTOSR(1771)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1771);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1771 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1771,F126_1771_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F126_1772_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_value_grouping", 125, Current, 0, 0, 1948);
	RTGC;
	RTOSP (1772);
#define Result RTOSR(1772)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1153,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1154_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1772);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1772 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1772,F126_1772_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F126_1773 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_decimal_separator", 125, Current, 0, 1, 1949);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F126_1774 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_numbers_after_decimal_separator", 125, Current, 0, 1, 1950);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F126_1775 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_group_separator", 125, Current, 0, 1, 1951);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F126_1776 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_number_list_separator", 125, Current, 0, 1, 1952);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F126_1777 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_positive_sign", 125, Current, 0, 1, 1953);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F126_1778 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_negative_sign", 125, Current, 0, 1, 1954);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F126_1779 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_grouping", 125, Current, 0, 1, 1955);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit103 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
