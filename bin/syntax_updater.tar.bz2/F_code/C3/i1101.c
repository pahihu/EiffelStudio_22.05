/*
 * Code for class I18N_POSIX_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1101.h"
#include "eif_langinfo.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F124_1665
static EIF_INTEGER_32 inline_F124_1665 (void)
{
	return ABDAY_1;
	;
}
#define INLINE_F124_1665
#endif
#ifndef INLINE_F124_1672
static EIF_INTEGER_32 inline_F124_1672 (void)
{
	return DAY_1;
	;
}
#define INLINE_F124_1672
#endif
#ifndef INLINE_F124_1679
static EIF_INTEGER_32 inline_F124_1679 (void)
{
	return ABMON_1;
	;
}
#define INLINE_F124_1679
#endif
#ifndef INLINE_F124_1691
static EIF_INTEGER_32 inline_F124_1691 (void)
{
	return MON_1;
	;
}
#define INLINE_F124_1691
#endif
#ifndef INLINE_F124_1703
static EIF_INTEGER_32 inline_F124_1703 (void)
{
	return AM_STR;
	;
}
#define INLINE_F124_1703
#endif
#ifndef INLINE_F124_1704
static EIF_INTEGER_32 inline_F124_1704 (void)
{
	return PM_STR;
	;
}
#define INLINE_F124_1704
#endif
#ifndef INLINE_F124_1705
static EIF_INTEGER_32 inline_F124_1705 (void)
{
	return D_T_FMT;
	;
}
#define INLINE_F124_1705
#endif
#ifndef INLINE_F124_1706
static EIF_INTEGER_32 inline_F124_1706 (void)
{
	return D_FMT;
	;
}
#define INLINE_F124_1706
#endif
#ifndef INLINE_F124_1707
static EIF_INTEGER_32 inline_F124_1707 (void)
{
	return T_FMT;
	;
}
#define INLINE_F124_1707
#endif
#ifndef INLINE_F124_1709
static EIF_INTEGER_32 inline_F124_1709 (void)
{
	return CRNCYSTR;
	;
}
#define INLINE_F124_1709
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_POSIX_CONSTANTS}.abday_1 */
EIF_INTEGER_32 F124_1665 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abday_1", 123, Current, 0, 0, 1856);
	Result = inline_F124_1665 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.day_1 */
EIF_INTEGER_32 F124_1672 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("day_1", 123, Current, 0, 0, 1863);
	Result = inline_F124_1672 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.abmon_1 */
EIF_INTEGER_32 F124_1679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abmon_1", 123, Current, 0, 0, 1870);
	Result = inline_F124_1679 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.mon_1 */
EIF_INTEGER_32 F124_1691 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_1", 123, Current, 0, 0, 1882);
	Result = inline_F124_1691 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.am_str */
EIF_INTEGER_32 F124_1703 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("am_str", 123, Current, 0, 0, 1894);
	Result = inline_F124_1703 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.pm_str */
EIF_INTEGER_32 F124_1704 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pm_str", 123, Current, 0, 0, 1850);
	Result = inline_F124_1704 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_t_fmt */
EIF_INTEGER_32 F124_1705 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_t_fmt", 123, Current, 0, 0, 1851);
	Result = inline_F124_1705 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_fmt */
EIF_INTEGER_32 F124_1706 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_fmt", 123, Current, 0, 0, 1852);
	Result = inline_F124_1706 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.t_fmt */
EIF_INTEGER_32 F124_1707 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("t_fmt", 123, Current, 0, 0, 1853);
	Result = inline_F124_1707 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.crncystr */
EIF_INTEGER_32 F124_1709 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("crncystr", 123, Current, 0, 0, 1855);
	Result = inline_F124_1709 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
