
#ifndef _C3_i1121_
#define _C3_i1121_

#ifdef __cplusplus
extern "C" {
#endif

extern void F144_2002(EIF_REFERENCE, EIF_REFERENCE);
extern void F144_2003(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit121(void);
extern long O1694[];

#ifdef __cplusplus
}
#endif

#endif
