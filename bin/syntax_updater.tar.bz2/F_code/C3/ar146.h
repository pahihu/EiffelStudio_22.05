
#ifndef _C3_ar146_
#define _C3_ar146_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F171_2240(EIF_REFERENCE);
extern void F171_2244(EIF_REFERENCE, EIF_REFERENCE);
extern void F171_2246(EIF_REFERENCE);
extern void EIF_Minit146(void);
extern void F1091_9529(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
