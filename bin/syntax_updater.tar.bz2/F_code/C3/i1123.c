/*
 * Code for class I18N_DATASOURCE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATASOURCE_MANAGER}.make */
void F146_2005 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make", 145, Current, 0, 1, 2175);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1095, 1).id);
	F1096_9735(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATASOURCE_MANAGER}.has_locale */
EIF_BOOLEAN F146_2009 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_locale", 145, Current, 0, 1, 2176);
	RTGC;
	RTHOOK(1);
	tr1 = F147_2014(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5835[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_DATASOURCE_MANAGER}.has_language */
EIF_BOOLEAN F146_2010 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_language", 145, Current, 0, 1, 2177);
	RTGC;
	RTHOOK(1);
	tr1 = F147_2015(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5835[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
