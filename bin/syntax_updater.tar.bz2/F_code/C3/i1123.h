
#ifndef _C3_i1123_
#define _C3_i1123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F146_2005(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F146_2009(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F146_2010(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit123(void);
extern void F1096_9735(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F147_2015(EIF_REFERENCE);
extern EIF_REFERENCE F147_2014(EIF_REFERENCE);
extern char *(*R5835[])();

#ifdef __cplusplus
}
#endif

#endif
