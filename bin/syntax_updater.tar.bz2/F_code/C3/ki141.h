
#ifndef _C3_ki141_
#define _C3_ki141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F166_2200(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_NATURAL_32 F166_2201(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F166_2207(EIF_REFERENCE);
extern EIF_REFERENCE F166_2208(EIF_REFERENCE);
extern void F166_2212(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit141(void);
extern char *(*R2172[])();
extern char *(*R2149[])();

#ifdef __cplusplus
}
#endif

#endif
