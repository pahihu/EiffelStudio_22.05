/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F134_1855 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1855,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F134_1858 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1858,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F134_1859 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1859,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F134_1865 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1865,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F134_1873_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_major_version", 133, Current, 0, 0, 2036);
	RTGC;
	RTOSP (1873);
#define Result RTOSR(1873)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F134_1875(Current, ti4_1);
	RTOSE (1873);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1873 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1873,F134_1873_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F134_1874_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_minor_version", 133, Current, 0, 0, 2037);
	RTGC;
	RTOSP (1874);
#define Result RTOSR(1874)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F134_1875(Current, ti4_1);
	RTOSE (1874);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1874 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1874,F134_1874_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F134_1875 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("two_digit_minimum_string", 133, Current, 0, 1, 2038);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), ((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '0');
	}
	RTHOOK(4);
	F1099_9942(RTCW(Result), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
