/*
 * Code for class KL_SHARED_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl127.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_PLATFORM}.platform */
static EIF_REFERENCE F150_2029_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("platform", 149, Current, 0, 0, 2191);
	RTGC;
	RTOSP (2029);
#define Result RTOSR(2029)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(271, 0x01).id, 271, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2029);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F150_2029 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2029,F150_2029_body,(Current));
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
