
#ifndef _C3_do144_
#define _C3_do144_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F169_2234(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F169_2236(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit144(void);

#ifdef __cplusplus
}
#endif

#endif
