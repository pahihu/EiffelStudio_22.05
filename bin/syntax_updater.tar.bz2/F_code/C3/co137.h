
#ifndef _C3_co137_
#define _C3_co137_

#ifdef __cplusplus
extern "C" {
#endif

extern void F160_2172(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit137(void);

#ifdef __cplusplus
}
#endif

#endif
