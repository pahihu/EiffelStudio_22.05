/*
 * Code for class CONF_LOCATION_IRON_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co139.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_IRON_MAPPING}.make */
void F162_2176 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("make", 161, Current, 0, 2, 2313);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_IRON_MAPPING}.mapped_location */
EIF_REFERENCE F162_2179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("mapped_location", 161, Current, 2, 1, 2316);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tr1 = F1091_9588(RTMS_EX_H("iron:",5,1920711738));
	tb3 = F1094_9694(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = F1091_9588(RTMS_EX_H("http:",5,1954586682));
		tb3 = F1094_9694(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = F1091_9588(RTMS_EX_H("https:",6,11409978));
		tb2 = F1094_9694(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1094_9661(RTCW(loc1), arg1);
		RTHOOK(3);
		F162_2184(Current, loc1);
		RTHOOK(4);
		tr1 = F162_2182(Current);
		tr1 = F443_6208(RTCW(tr1), loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			tr1 = F1115_10507(loc2);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_LOCATION_IRON_MAPPING}.refresh */
void F162_2181 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("refresh", 161, Current, 1, 0, 2318);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = F443_6183(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_IRON_MAPPING}.iron_api */
EIF_REFERENCE F162_2182 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("iron_api", 161, Current, 2, 0, 2319);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F443_6183(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) NULL;
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(25, 0x01).id, 25, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(6);
		loc1 = F26_349(RTCW(loc2), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(7);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(8);
	RTHOOK(9);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_IRON_MAPPING}.update_location_to_uri */
void F162_2184 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("update_location_to_uri", 161, Current, 0, 1, 2321);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1096_9751(RTCW(arg1), tr1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit139 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
