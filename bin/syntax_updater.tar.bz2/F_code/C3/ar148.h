
#ifndef _C3_ar148_
#define _C3_ar148_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2249)
static EIF_REFERENCE F173_2249_body(EIF_REFERENCE);
extern EIF_REFERENCE F173_2249(EIF_REFERENCE);
extern void EIF_Minit148(void);
extern EIF_REFERENCE F502_7040(EIF_REFERENCE);
extern void F1115_10468(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,7040)

#ifdef __cplusplus
}
#endif

#endif
