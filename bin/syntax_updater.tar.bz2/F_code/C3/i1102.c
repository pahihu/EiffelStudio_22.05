/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1102.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F125_1710 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 124, Current, 0, 0, 1895);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1733,F125_1733, (Current));
	F125_1742(Current, tr1);
	RTHOOK(2);
	F125_1743(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	tr1 = RTOSCF(1734,F125_1734, (Current));
	F125_1744(Current, tr1);
	RTHOOK(4);
	F125_1745(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(5);
	tr1 = RTOSCF(1737,F125_1737, (Current));
	F125_1746(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(1738,F125_1738, (Current));
	F125_1747(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(1739,F125_1739, (Current));
	F125_1748(Current, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(1740,F125_1740, (Current));
	F125_1749(Current, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(1741,F125_1741, (Current));
	F125_1750(Current, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(1733,F125_1733, (Current));
	F125_1751(Current, tr1);
	RTHOOK(11);
	F125_1752(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(12);
	tr1 = RTOSCF(1734,F125_1734, (Current));
	F125_1753(Current, tr1);
	RTHOOK(13);
	F125_1754(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(14);
	tr1 = RTOSCF(1737,F125_1737, (Current));
	F125_1755(Current, tr1);
	RTHOOK(15);
	tr1 = RTOSCF(1738,F125_1738, (Current));
	F125_1756(Current, tr1);
	RTHOOK(16);
	tr1 = RTOSCF(1741,F125_1741, (Current));
	F125_1757(Current, tr1);
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F125_1733_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_symbol", 124, Current, 0, 0, 1918);
	RTGC;
	RTOSP (1733);
#define Result RTOSR(1733)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1733);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1733 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1733,F125_1733_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F125_1734_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_decimal_separator", 124, Current, 0, 0, 1919);
	RTGC;
	RTOSP (1734);
#define Result RTOSR(1734)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1734);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1734 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1734,F125_1734_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F125_1737_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_group_separator", 124, Current, 0, 0, 1922);
	RTGC;
	RTOSP (1737);
#define Result RTOSR(1737)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1737);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1737 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1737,F125_1737_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F125_1738_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_number_list_separator", 124, Current, 0, 0, 1923);
	RTGC;
	RTOSP (1738);
#define Result RTOSR(1738)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1738);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1738 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1738,F125_1738_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F125_1739_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_positive_sign", 124, Current, 0, 0, 1924);
	RTGC;
	RTOSP (1739);
#define Result RTOSR(1739)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1739);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1739 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1739,F125_1739_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F125_1740_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_negative_sign", 124, Current, 0, 0, 1925);
	RTGC;
	RTOSP (1740);
#define Result RTOSR(1740)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1740);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1740 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1740,F125_1740_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F125_1741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_currency_grouping", 124, Current, 0, 0, 1926);
	RTGC;
	RTOSP (1741);
#define Result RTOSR(1741)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1153,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1154_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1741);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1741,F125_1741_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F125_1742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_symbol", 124, Current, 0, 1, 1927);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F125_1743 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_symbol_location", 124, Current, 0, 1, 1928);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1689[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F125_1744 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_decimal_separator", 124, Current, 0, 1, 1929);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F125_1745 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_numbers_after_decimal_separator", 124, Current, 0, 1, 1930);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1694[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F125_1746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_group_separator", 124, Current, 0, 1, 1931);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F125_1747 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_number_list_separator", 124, Current, 0, 1, 1932);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F125_1748 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_positive_sign", 124, Current, 0, 1, 1933);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F125_1749 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_negative_sign", 124, Current, 0, 1, 1934);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F125_1750 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_grouping", 124, Current, 0, 1, 1935);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F125_1751 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_symbol", 124, Current, 0, 1, 1936);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F125_1752 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_symbol_location", 124, Current, 0, 1, 1937);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1701[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F125_1753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_decimal_separator", 124, Current, 0, 1, 1938);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F125_1754 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_numbers_after_decimal_separator", 124, Current, 0, 1, 1939);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1706[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F125_1755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_group_separator", 124, Current, 0, 1, 1940);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F125_1756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_number_list_separator", 124, Current, 0, 1, 1941);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F125_1757 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_grouping", 124, Current, 0, 1, 1942);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit102 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
