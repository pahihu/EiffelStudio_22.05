/*
 * Code for class ARGUMENT_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar148.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_SOURCE}.application */
static EIF_REFERENCE F173_2249_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("application", 172, Current, 0, 0, 2381);
	RTGC;
	RTOSP (2249);
#define Result RTOSR(2249)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1114, 0x01).id, 1114, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(501, 0x01).id, 501, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(7040,F502_7040, (RTCW(tr2)));
	F1115_10468(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2249);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_2249 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2249,F173_2249_body,(Current));
}

void EIF_Minit148 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
