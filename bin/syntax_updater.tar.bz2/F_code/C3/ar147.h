
#ifndef _C3_ar147_
#define _C3_ar147_

#ifdef __cplusplus
extern "C" {
#endif

extern void F172_2248(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit147(void);

#ifdef __cplusplus
}
#endif

#endif
