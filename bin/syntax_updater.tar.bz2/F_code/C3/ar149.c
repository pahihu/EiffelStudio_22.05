/*
 * Code for class ARGUMENT_TERMINAL_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar149.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_TERMINAL_SOURCE}.arguments */
static EIF_REFERENCE F174_2253_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("arguments", 173, Current, 3, 0, 2383);
	RTGC;
	RTOSP (2253);
#define Result RTOSR(2253)
	RTOC_NEW(Result);
	RTHOOK(1);
	loc1 = F502_7038(RTCV(RTOSCF(2254,F174_2254, (Current))));
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,1094,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F950_7843(RTCW(tr1), loc2);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc3 > loc2)) break;
		RTHOOK(6);
		tr1 = F873_7610(RTCW(loc1), loc3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(Result))-754])(Result, tr1);
		RTHOOK(7);
		loc3++;
	}
	RTOSE (2253);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F174_2253 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2253,F174_2253_body,(Current));
}

/* {ARGUMENT_TERMINAL_SOURCE}.terminal_arguments */
static EIF_REFERENCE F174_2254_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("terminal_arguments", 173, Current, 0, 0, 2384);
	RTGC;
	RTOSP (2254);
#define Result RTOSR(2254)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(501, 0x01).id, 501, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2254);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F174_2254 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2254,F174_2254_body,(Current));
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
