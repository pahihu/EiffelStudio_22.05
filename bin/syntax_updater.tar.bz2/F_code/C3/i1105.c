/*
 * Code for class I18N_DATE_TIME_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1105.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_TIME_INFO}.make */
void F128_1788 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 127, Current, 0, 0, 1973);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1815,F128_1815, (Current));
	F128_1806(Current, tr1);
	RTHOOK(2);
	tr1 = RTOSCF(1818,F128_1818, (Current));
	F128_1807(Current, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(1817,F128_1817, (Current));
	F128_1808(Current, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(1818,F128_1818, (Current));
	F128_1809(Current, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(1819,F128_1819, (Current));
	F128_1810(Current, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(1820,F128_1820, (Current));
	F128_1811(Current, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(1821,F128_1821, (Current));
	F128_1812(Current, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(1827,F128_1827, (Current));
	F128_1813(Current, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(1826,F128_1826, (Current));
	F128_1814(Current, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(1822,F128_1822, (Current));
	F128_1802(Current, tr1);
	RTHOOK(11);
	tr1 = RTOSCF(1823,F128_1823, (Current));
	F128_1804(Current, tr1);
	RTHOOK(12);
	tr1 = RTOSCF(1824,F128_1824, (Current));
	F128_1803(Current, tr1);
	RTHOOK(13);
	tr1 = RTOSCF(1825,F128_1825, (Current));
	F128_1805(Current, tr1);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_day_names */
void F128_1802 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_day_names", 127, Current, 0, 1, 1987);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_day_names */
void F128_1803 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_day_names", 127, Current, 0, 1, 1988);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_month_names */
void F128_1804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_month_names", 127, Current, 0, 1, 1989);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_month_names */
void F128_1805 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_month_names", 127, Current, 0, 1, 1990);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_time_format */
void F128_1806 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_time_format", 127, Current, 0, 1, 1991);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_date_format */
void F128_1807 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_date_format", 127, Current, 0, 1, 1992);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_date_format */
void F128_1808 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_date_format", 127, Current, 0, 1, 1993);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_time_format */
void F128_1809 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_time_format", 127, Current, 0, 1, 1994);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_time_format */
void F128_1810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_time_format", 127, Current, 0, 1, 1995);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_am_suffix */
void F128_1811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_am_suffix", 127, Current, 0, 1, 1996);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_pm_suffix */
void F128_1812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pm_suffix", 127, Current, 0, 1, 1997);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_time_separator */
void F128_1813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_time_separator", 127, Current, 0, 1, 1998);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_separator */
void F128_1814 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_separator", 127, Current, 0, 1, 1999);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9589(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.default_date_time_format */
static EIF_REFERENCE F128_1815_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_date_time_format", 127, Current, 0, 0, 2000);
	RTGC;
	RTOSP (1815);
#define Result RTOSR(1815)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(1816,F128_1816, (Current));
	F1096_9774(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'T';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(4);
	tr1 = RTOSCF(1818,F128_1818, (Current));
	F1096_9774(RTCW(Result), tr1);
	RTOSE (1815);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1815 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1815,F128_1815_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_date_format */
static EIF_REFERENCE F128_1816_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_date_format", 127, Current, 0, 0, 2001);
	RTGC;
	RTOSP (1816);
#define Result RTOSR(1816)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(7);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(8);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(9);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'e';
	F1096_9788(RTCW(Result), tw1);
	RTOSE (1816);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1816 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1816,F128_1816_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_date_format */
static EIF_REFERENCE F128_1817_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_date_format", 127, Current, 0, 0, 2002);
	RTGC;
	RTOSP (1817);
#define Result RTOSR(1817)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1096_9788(RTCW(Result), tw1);
	RTOSE (1817);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1817 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1817,F128_1817_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_time_format */
static EIF_REFERENCE F128_1818_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_time_format", 127, Current, 0, 0, 2003);
	RTGC;
	RTOSP (1818);
#define Result RTOSR(1818)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(1819,F128_1819, (Current));
	F1096_9774(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '5';
	F1096_9788(RTCW(Result), tw1);
	RTOSE (1818);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1818 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1818,F128_1818_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_time_format */
static EIF_REFERENCE F128_1819_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_time_format", 127, Current, 0, 0, 2004);
	RTGC;
	RTOSP (1819);
#define Result RTOSR(1819)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'k';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1096_9788(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'M';
	F1096_9788(RTCW(Result), tw1);
	RTOSE (1819);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1819 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1819,F128_1819_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_am_suffix */
static EIF_REFERENCE F128_1820_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_am_suffix", 127, Current, 0, 0, 2005);
	RTGC;
	RTOSP (1820);
#define Result RTOSR(1820)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("a\000\000\000m\000\000\000",2,24941);
	RTOSE (1820);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1820 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1820,F128_1820_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_pm_suffix */
static EIF_REFERENCE F128_1821_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_pm_suffix", 127, Current, 0, 0, 2006);
	RTGC;
	RTOSP (1821);
#define Result RTOSR(1821)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("p\000\000\000m\000\000\000",2,28781);
	RTOSE (1821);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1821 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1821,F128_1821_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_day_names */
static EIF_REFERENCE F128_1822_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_day_names", 127, Current, 0, 0, 2007);
	RTGC;
	RTOSP (1822);
#define Result RTOSR(1822)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,1095,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1091_9589(RTMS_EX_H("Monday",6,2004312953));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Tuesday",7,1495753593));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Wednesday",9,1804915065));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Thursday",8,844137593));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Friday",6,1906687353));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Saturday",8,1596931193));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Sunday",6,2016155513));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1822);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1822 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1822,F128_1822_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_month_names */
static EIF_REFERENCE F128_1823_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_month_names", 127, Current, 0, 0, 2008);
	RTGC;
	RTOSP (1823);
#define Result RTOSR(1823)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,1095,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1091_9589(RTMS_EX_H("January",7,751658105));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("February",8,1474449017));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("March",5,1635477864));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("April",5,1887045484));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("June",4,1249209957));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("July",4,1249209465));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("August",6,1864444276));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("September",9,1077346930));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("October",7,1024137842));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("November",8,2119563634));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("December",8,1341698930));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1823);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1823 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1823,F128_1823_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_day_names */
static EIF_REFERENCE F128_1824_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_day_names", 127, Current, 0, 0, 2009);
	RTGC;
	RTOSP (1824);
#define Result RTOSR(1824)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,1095,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1091_9589(RTMS_EX_H("Mon",3,5074798));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Tue",3,5535077));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Wed",3,5727588));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Thu",3,5531765));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Fri",3,4616809));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Sat",3,5464436));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Sun",3,5469550));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1824);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1824 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1824,F128_1824_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_month_names */
static EIF_REFERENCE F128_1825_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_month_names", 127, Current, 0, 0, 2010);
	RTGC;
	RTOSP (1825);
#define Result RTOSR(1825)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1150,0xFF01,1095,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1091_9589(RTMS_EX_H("Jan",3,4874606));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Feb",3,4613474));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Mar",3,5071218));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Apr",3,4288626));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Jun",3,4879726));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Jul",3,4879724));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Aug",3,4289895));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Sep",3,5465456));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Oct",3,5202804));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Nov",3,5140342));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1091_9589(RTMS_EX_H("Dec",3,4482403));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1151_10571)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1825);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1825 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1825,F128_1825_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_date_separator */
static EIF_REFERENCE F128_1826_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_date_separator", 127, Current, 0, 0, 2011);
	RTGC;
	RTOSP (1826);
#define Result RTOSR(1826)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H("/\000\000\000",1,47);
	RTOSE (1826);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1826 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1826,F128_1826_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_time_separator */
static EIF_REFERENCE F128_1827_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_time_separator", 127, Current, 0, 0, 2012);
	RTGC;
	RTOSP (1827);
#define Result RTOSR(1827)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS32_EX_H(":\000\000\000",1,58);
	RTOSE (1827);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_1827 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1827,F128_1827_body,(Current));
}

void EIF_Minit105 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
