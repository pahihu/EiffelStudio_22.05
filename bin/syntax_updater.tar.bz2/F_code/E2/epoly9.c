#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y5879_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype117[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype118[] = {0xFF01,37,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype120[] = {0xFF01,445,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype124[] = {0xFF01,968,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype126[] = {0xFF01,1085,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype130[] = {0xFF01,1376,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype131[] = {0xFF01,1385,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype132[] = {0xFF01,1386,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype133[] = {0xFF01,1369,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype134[] = {0xFF01,1378,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype135[] = {0xFF01,1374,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype136[] = {0xFF01,1375,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype137[] = {0xFF01,1512,0xFFFF};
static EIF_TYPE_INDEX Y5879_pgtype138[] = {0xFF01,1429,0xFFFF};
EIF_TYPE_INDEX *Y5879_gen_type [738];
EIF_TYPE_INDEX Y5879 [738];
void Y5879_init (void)
{
	egc_routines_types [5879] = Y5879;
	egc_routines_gen_types [5879] = Y5879_gen_type;
	egc_routines_offset [5879] = 710;
	Y5879_gen_type [0] = Y5879_pgtype0;
	Y5879_gen_type [1] = Y5879_pgtype1;
	Y5879_gen_type [2] = Y5879_pgtype2;
	Y5879_gen_type [3] = Y5879_pgtype3;
	Y5879_gen_type [4] = Y5879_pgtype4;
	Y5879_gen_type [5] = Y5879_pgtype5;
	Y5879_gen_type [6] = Y5879_pgtype6;
	Y5879_gen_type [7] = Y5879_pgtype7;
	Y5879_gen_type [8] = Y5879_pgtype8;
	Y5879_gen_type [9] = Y5879_pgtype9;
	Y5879_gen_type [10] = Y5879_pgtype10;
	Y5879_gen_type [11] = Y5879_pgtype11;
	Y5879_gen_type [12] = Y5879_pgtype12;
	Y5879_gen_type [13] = Y5879_pgtype13;
	Y5879_gen_type [14] = Y5879_pgtype14;
	Y5879_gen_type [15] = Y5879_pgtype15;
	Y5879_gen_type [16] = Y5879_pgtype16;
	Y5879_gen_type [17] = Y5879_pgtype17;
	Y5879_gen_type [18] = Y5879_pgtype18;
	Y5879_gen_type [19] = Y5879_pgtype19;
	Y5879_gen_type [20] = Y5879_pgtype20;
	Y5879_gen_type [21] = Y5879_pgtype21;
	Y5879_gen_type [22] = Y5879_pgtype22;
	Y5879_gen_type [23] = Y5879_pgtype23;
	Y5879_gen_type [43] = Y5879_pgtype24;
	Y5879_gen_type [82] = Y5879_pgtype25;
	Y5879_gen_type [83] = Y5879_pgtype26;
	Y5879_gen_type [84] = Y5879_pgtype27;
	Y5879_gen_type [85] = Y5879_pgtype28;
	Y5879_gen_type [86] = Y5879_pgtype29;
	Y5879_gen_type [87] = Y5879_pgtype30;
	Y5879_gen_type [88] = Y5879_pgtype31;
	Y5879_gen_type [89] = Y5879_pgtype32;
	Y5879_gen_type [90] = Y5879_pgtype33;
	Y5879_gen_type [91] = Y5879_pgtype34;
	Y5879_gen_type [92] = Y5879_pgtype35;
	Y5879_gen_type [93] = Y5879_pgtype36;
	Y5879_gen_type [94] = Y5879_pgtype37;
	Y5879_gen_type [95] = Y5879_pgtype38;
	Y5879_gen_type [96] = Y5879_pgtype39;
	Y5879_gen_type [97] = Y5879_pgtype40;
	Y5879_gen_type [98] = Y5879_pgtype41;
	Y5879_gen_type [99] = Y5879_pgtype42;
	Y5879_gen_type [100] = Y5879_pgtype43;
	Y5879_gen_type [101] = Y5879_pgtype44;
	Y5879_gen_type [179] = Y5879_pgtype45;
	Y5879_gen_type [180] = Y5879_pgtype46;
	Y5879_gen_type [181] = Y5879_pgtype47;
	Y5879_gen_type [182] = Y5879_pgtype48;
	Y5879_gen_type [183] = Y5879_pgtype49;
	Y5879_gen_type [184] = Y5879_pgtype50;
	Y5879_gen_type [185] = Y5879_pgtype51;
	Y5879_gen_type [186] = Y5879_pgtype52;
	Y5879_gen_type [187] = Y5879_pgtype53;
	Y5879_gen_type [188] = Y5879_pgtype54;
	Y5879_gen_type [189] = Y5879_pgtype55;
	Y5879_gen_type [190] = Y5879_pgtype56;
	Y5879_gen_type [191] = Y5879_pgtype57;
	Y5879_gen_type [192] = Y5879_pgtype58;
	Y5879_gen_type [193] = Y5879_pgtype59;
	Y5879_gen_type [194] = Y5879_pgtype60;
	Y5879_gen_type [195] = Y5879_pgtype61;
	Y5879_gen_type [196] = Y5879_pgtype62;
	Y5879_gen_type [197] = Y5879_pgtype63;
	Y5879_gen_type [198] = Y5879_pgtype64;
	Y5879_gen_type [199] = Y5879_pgtype65;
	Y5879_gen_type [200] = Y5879_pgtype66;
	Y5879_gen_type [201] = Y5879_pgtype67;
	Y5879_gen_type [202] = Y5879_pgtype68;
	Y5879_gen_type [203] = Y5879_pgtype69;
	Y5879_gen_type [204] = Y5879_pgtype70;
	Y5879_gen_type [205] = Y5879_pgtype71;
	Y5879_gen_type [206] = Y5879_pgtype72;
	Y5879_gen_type [207] = Y5879_pgtype73;
	Y5879_gen_type [208] = Y5879_pgtype74;
	Y5879_gen_type [209] = Y5879_pgtype75;
	Y5879_gen_type [210] = Y5879_pgtype76;
	Y5879_gen_type [211] = Y5879_pgtype77;
	Y5879_gen_type [212] = Y5879_pgtype78;
	Y5879_gen_type [213] = Y5879_pgtype79;
	Y5879_gen_type [214] = Y5879_pgtype80;
	Y5879_gen_type [215] = Y5879_pgtype81;
	Y5879_gen_type [216] = Y5879_pgtype82;
	Y5879_gen_type [217] = Y5879_pgtype83;
	Y5879_gen_type [218] = Y5879_pgtype84;
	Y5879_gen_type [219] = Y5879_pgtype85;
	Y5879_gen_type [220] = Y5879_pgtype86;
	Y5879_gen_type [221] = Y5879_pgtype87;
	Y5879_gen_type [222] = Y5879_pgtype88;
	Y5879_gen_type [223] = Y5879_pgtype89;
	Y5879_gen_type [224] = Y5879_pgtype90;
	Y5879_gen_type [225] = Y5879_pgtype91;
	Y5879_gen_type [226] = Y5879_pgtype92;
	Y5879_gen_type [227] = Y5879_pgtype93;
	Y5879_gen_type [228] = Y5879_pgtype94;
	Y5879_gen_type [229] = Y5879_pgtype95;
	Y5879_gen_type [230] = Y5879_pgtype96;
	Y5879_gen_type [231] = Y5879_pgtype97;
	Y5879_gen_type [232] = Y5879_pgtype98;
	Y5879_gen_type [233] = Y5879_pgtype99;
	Y5879_gen_type [234] = Y5879_pgtype100;
	Y5879_gen_type [235] = Y5879_pgtype101;
	Y5879_gen_type [236] = Y5879_pgtype102;
	Y5879_gen_type [237] = Y5879_pgtype103;
	Y5879_gen_type [238] = Y5879_pgtype104;
	Y5879_gen_type [239] = Y5879_pgtype105;
	Y5879_gen_type [240] = Y5879_pgtype106;
	Y5879_gen_type [241] = Y5879_pgtype107;
	Y5879_gen_type [242] = Y5879_pgtype108;
	Y5879_gen_type [243] = Y5879_pgtype109;
	Y5879_gen_type [244] = Y5879_pgtype110;
	Y5879_gen_type [245] = Y5879_pgtype111;
	Y5879_gen_type [246] = Y5879_pgtype112;
	Y5879_gen_type [247] = Y5879_pgtype113;
	Y5879_gen_type [248] = Y5879_pgtype114;
	Y5879_gen_type [249] = Y5879_pgtype115;
	Y5879_gen_type [250] = Y5879_pgtype116;
	Y5879_gen_type [251] = Y5879_pgtype117;
	Y5879_gen_type [252] = Y5879_pgtype118;
	Y5879_gen_type [253] = Y5879_pgtype119;
	Y5879_gen_type [254] = Y5879_pgtype120;
	Y5879_gen_type [255] = Y5879_pgtype121;
	Y5879_gen_type [256] = Y5879_pgtype122;
	Y5879_gen_type [257] = Y5879_pgtype123;
	Y5879_gen_type [258] = Y5879_pgtype124;
	Y5879_gen_type [259] = Y5879_pgtype125;
	Y5879_gen_type [260] = Y5879_pgtype126;
	Y5879_gen_type [261] = Y5879_pgtype127;
	Y5879_gen_type [262] = Y5879_pgtype128;
	Y5879_gen_type [728] = Y5879_pgtype129;
	Y5879_gen_type [729] = Y5879_pgtype130;
	Y5879_gen_type [730] = Y5879_pgtype131;
	Y5879_gen_type [731] = Y5879_pgtype132;
	Y5879_gen_type [732] = Y5879_pgtype133;
	Y5879_gen_type [733] = Y5879_pgtype134;
	Y5879_gen_type [734] = Y5879_pgtype135;
	Y5879_gen_type [735] = Y5879_pgtype136;
	Y5879_gen_type [736] = Y5879_pgtype137;
	Y5879_gen_type [737] = Y5879_pgtype138;
	{long i; for (i = 44; i < 46; i++) Y5879[i] = 1229;};
	Y5879[251] = 1320;
	Y5879[252] = 37;
	Y5879[254] = 445;
	Y5879[258] = 968;
	Y5879[260] = 1085;
	Y5879[263] = 1229;
	{long i; for (i = 295; i < 298; i++) Y5879[i] = 1048;};
	Y5879[559] = 1048;
	{long i; for (i = 593; i < 596; i++) Y5879[i] = 1048;};
	{long i; for (i = 597; i < 602; i++) Y5879[i] = 1048;};
	Y5879[729] = 1376;
	Y5879[730] = 1385;
	Y5879[731] = 1386;
	Y5879[732] = 1369;
	Y5879[733] = 1378;
	Y5879[734] = 1374;
	Y5879[735] = 1375;
	Y5879[736] = 1512;
	Y5879[737] = 1429;
}

char *(*R5883[509])();
void R5883_init () {
	R5883[0] = (char *(*)()) F940_7753;
	R5883[1] = (char *(*)()) F941_7753_5883_4;
	R5883[2] = (char *(*)()) F942_7753_5883_4;
	{long i; for (i = 3; i < 6; i++) R5883[i] = (char *(*)()) F940_7753;}
	R5883[6] = (char *(*)()) F942_7753_5883_4;
	R5883[7] = (char *(*)()) F941_7753_5883_4;
	R5883[9] = (char *(*)()) F940_7753;
	R5883[10] = (char *(*)()) F950_7887;
	R5883[11] = (char *(*)()) F951_7887_5883_4;
	R5883[12] = (char *(*)()) F952_7887_5883_4;
	R5883[13] = (char *(*)()) F953_7887_5883_4;
	R5883[14] = (char *(*)()) F954_7887_5883_4;
	R5883[15] = (char *(*)()) F955_7887_5883_4;
	R5883[16] = (char *(*)()) F956_7887_5883_4;
	R5883[17] = (char *(*)()) F957_7887_5883_4;
	R5883[18] = (char *(*)()) F958_7887_5883_4;
	R5883[19] = (char *(*)()) F959_7887_5883_4;
	R5883[20] = (char *(*)()) F960_7887_5883_4;
	R5883[21] = (char *(*)()) F961_7887_5883_4;
	R5883[22] = (char *(*)()) F950_7887;
	R5883[24] = (char *(*)()) F950_7887;
	R5883[26] = (char *(*)()) F950_7887;
	R5883[27] = (char *(*)()) F953_7887_5883_4;
	R5883[28] = (char *(*)()) F954_7887_5883_4;
	R5883[29] = (char *(*)()) F950_7887;
	R5883[31] = (char *(*)()) F970_7960;
	R5883[32] = (char *(*)()) F950_7887;
	{long i; for (i = 33; i < 35; i++) R5883[i] = (char *(*)()) F953_7887_5883_4;}
	{long i; for (i = 499; i < 509; i++) R5883[i] = (char *(*)()) F950_7887;}
}
static void F941_7753_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F941_7753(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F942_7753_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F942_7753(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7887(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F952_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7887(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F953_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7887(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7887(Current, *(EIF_BOOLEAN *)arg1);
}
static void F955_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7887(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F956_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7887(Current, *(EIF_POINTER *)arg1);
}
static void F957_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7887(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F958_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7887(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F959_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7887(Current, *(EIF_REAL_64 *)arg1);
}
static void F960_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7887(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F961_7887_5883_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F961_7887(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R5884[652])();
void R5884_init () {
	R5884[0] = (char *(*)()) F797_7387;
	R5884[143] = (char *(*)()) F940_7756;
	R5884[144] = (char *(*)()) F941_7756;
	R5884[145] = (char *(*)()) F942_7756;
	R5884[146] = (char *(*)()) F940_7757;
	R5884[147] = (char *(*)()) F940_7756;
	R5884[148] = (char *(*)()) F945_7803;
	R5884[149] = (char *(*)()) F946_7803;
	R5884[150] = (char *(*)()) F947_7803;
	R5884[152] = (char *(*)()) F948_7828;
	R5884[153] = (char *(*)()) F950_7897;
	R5884[154] = (char *(*)()) F951_7897;
	R5884[155] = (char *(*)()) F952_7897;
	R5884[156] = (char *(*)()) F953_7897;
	R5884[157] = (char *(*)()) F954_7897;
	R5884[158] = (char *(*)()) F955_7897;
	R5884[159] = (char *(*)()) F956_7897;
	R5884[160] = (char *(*)()) F957_7897;
	R5884[161] = (char *(*)()) F958_7897;
	R5884[162] = (char *(*)()) F959_7897;
	R5884[163] = (char *(*)()) F960_7897;
	R5884[164] = (char *(*)()) F961_7897;
	R5884[165] = (char *(*)()) F950_7897;
	R5884[167] = (char *(*)()) F950_7897;
	R5884[169] = (char *(*)()) F966_7932;
	R5884[170] = (char *(*)()) F967_7932;
	R5884[171] = (char *(*)()) F968_7932;
	R5884[172] = (char *(*)()) F950_7897;
	R5884[174] = (char *(*)()) F970_7961;
	R5884[175] = (char *(*)()) F950_7897;
	{long i; for (i = 176; i < 178; i++) R5884[i] = (char *(*)()) F953_7897;}
	{long i; for (i = 642; i < 652; i++) R5884[i] = (char *(*)()) F950_7897;}
}

char *(*R5885[509])();
void R5885_init () {
	R5885[0] = (char *(*)()) F940_7729;
	R5885[1] = (char *(*)()) F941_7729;
	R5885[2] = (char *(*)()) F942_7729;
	{long i; for (i = 3; i < 6; i++) R5885[i] = (char *(*)()) F940_7729;}
	R5885[6] = (char *(*)()) F942_7729;
	R5885[7] = (char *(*)()) F941_7729;
	R5885[9] = (char *(*)()) F948_7815;
	R5885[10] = (char *(*)()) F950_7854;
	R5885[11] = (char *(*)()) F951_7854;
	R5885[12] = (char *(*)()) F952_7854;
	R5885[13] = (char *(*)()) F953_7854;
	R5885[14] = (char *(*)()) F954_7854;
	R5885[15] = (char *(*)()) F955_7854;
	R5885[16] = (char *(*)()) F956_7854;
	R5885[17] = (char *(*)()) F957_7854;
	R5885[18] = (char *(*)()) F958_7854;
	R5885[19] = (char *(*)()) F959_7854;
	R5885[20] = (char *(*)()) F960_7854;
	R5885[21] = (char *(*)()) F961_7854;
	R5885[22] = (char *(*)()) F950_7854;
	R5885[24] = (char *(*)()) F950_7854;
	R5885[26] = (char *(*)()) F950_7854;
	R5885[27] = (char *(*)()) F953_7854;
	R5885[28] = (char *(*)()) F954_7854;
	R5885[29] = (char *(*)()) F950_7854;
	{long i; for (i = 31; i < 33; i++) R5885[i] = (char *(*)()) F950_7854;}
	{long i; for (i = 33; i < 35; i++) R5885[i] = (char *(*)()) F953_7854;}
	{long i; for (i = 499; i < 509; i++) R5885[i] = (char *(*)()) F950_7854;}
}

static EIF_TYPE_INDEX Y5885_pgtype0[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype1[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype2[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype3[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype4[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype5[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype6[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype7[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype8[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype9[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype10[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype11[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype12[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype13[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype14[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype15[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype16[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype17[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype18[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype19[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype20[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype21[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype22[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype23[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype24[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype25[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype26[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype27[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype28[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype29[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype30[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype31[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype32[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype33[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype34[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype35[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype36[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype37[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype38[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype39[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype40[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype41[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype42[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype43[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype44[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype45[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype46[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype47[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype48[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype49[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype50[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype51[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype52[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype53[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype54[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype55[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype56[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype57[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype58[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype59[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype60[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype61[] = {0xFF01,308,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype62[] = {0xFF01,311,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype63[] = {0xFF01,312,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype64[] = {0xFF01,313,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype65[] = {0xFF01,311,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype66[] = {0xFF01,311,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype67[] = {0xFF01,311,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype68[] = {0xFF01,313,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype69[] = {0xFF01,312,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype70[] = {0xFF01,314,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype71[] = {0xFF01,314,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype72[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype73[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype74[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype75[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype76[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype77[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype78[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype79[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype80[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype81[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype82[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype83[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype84[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype85[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype86[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype87[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype88[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype89[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype90[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype91[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype92[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype93[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype94[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype95[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype96[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype97[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype98[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype99[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype100[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype101[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype102[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype103[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype104[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype105[] = {0xFF01,310,0xFFFF};
static EIF_TYPE_INDEX Y5885_pgtype106[] = {0xFF01,310,0xFFFF};
EIF_TYPE_INDEX *Y5885_gen_type [726];
EIF_TYPE_INDEX Y5885 [726];
void Y5885_init (void)
{
	egc_routines_types [5885] = Y5885;
	egc_routines_gen_types [5885] = Y5885_gen_type;
	egc_routines_offset [5885] = 722;
	Y5885_gen_type [0] = Y5885_pgtype0;
	Y5885_gen_type [1] = Y5885_pgtype1;
	Y5885_gen_type [2] = Y5885_pgtype2;
	Y5885_gen_type [3] = Y5885_pgtype3;
	Y5885_gen_type [4] = Y5885_pgtype4;
	Y5885_gen_type [5] = Y5885_pgtype5;
	Y5885_gen_type [6] = Y5885_pgtype6;
	Y5885_gen_type [7] = Y5885_pgtype7;
	Y5885_gen_type [8] = Y5885_pgtype8;
	Y5885_gen_type [9] = Y5885_pgtype9;
	Y5885_gen_type [10] = Y5885_pgtype10;
	Y5885_gen_type [11] = Y5885_pgtype11;
	Y5885_gen_type [167] = Y5885_pgtype12;
	Y5885_gen_type [168] = Y5885_pgtype13;
	Y5885_gen_type [169] = Y5885_pgtype14;
	Y5885_gen_type [170] = Y5885_pgtype15;
	Y5885_gen_type [171] = Y5885_pgtype16;
	Y5885_gen_type [172] = Y5885_pgtype17;
	Y5885_gen_type [173] = Y5885_pgtype18;
	Y5885_gen_type [174] = Y5885_pgtype19;
	Y5885_gen_type [175] = Y5885_pgtype20;
	Y5885_gen_type [176] = Y5885_pgtype21;
	Y5885_gen_type [177] = Y5885_pgtype22;
	Y5885_gen_type [178] = Y5885_pgtype23;
	Y5885_gen_type [179] = Y5885_pgtype24;
	Y5885_gen_type [180] = Y5885_pgtype25;
	Y5885_gen_type [181] = Y5885_pgtype26;
	Y5885_gen_type [182] = Y5885_pgtype27;
	Y5885_gen_type [183] = Y5885_pgtype28;
	Y5885_gen_type [184] = Y5885_pgtype29;
	Y5885_gen_type [185] = Y5885_pgtype30;
	Y5885_gen_type [186] = Y5885_pgtype31;
	Y5885_gen_type [187] = Y5885_pgtype32;
	Y5885_gen_type [188] = Y5885_pgtype33;
	Y5885_gen_type [189] = Y5885_pgtype34;
	Y5885_gen_type [190] = Y5885_pgtype35;
	Y5885_gen_type [191] = Y5885_pgtype36;
	Y5885_gen_type [192] = Y5885_pgtype37;
	Y5885_gen_type [193] = Y5885_pgtype38;
	Y5885_gen_type [194] = Y5885_pgtype39;
	Y5885_gen_type [195] = Y5885_pgtype40;
	Y5885_gen_type [196] = Y5885_pgtype41;
	Y5885_gen_type [197] = Y5885_pgtype42;
	Y5885_gen_type [198] = Y5885_pgtype43;
	Y5885_gen_type [199] = Y5885_pgtype44;
	Y5885_gen_type [200] = Y5885_pgtype45;
	Y5885_gen_type [201] = Y5885_pgtype46;
	Y5885_gen_type [202] = Y5885_pgtype47;
	Y5885_gen_type [203] = Y5885_pgtype48;
	Y5885_gen_type [204] = Y5885_pgtype49;
	Y5885_gen_type [205] = Y5885_pgtype50;
	Y5885_gen_type [206] = Y5885_pgtype51;
	Y5885_gen_type [207] = Y5885_pgtype52;
	Y5885_gen_type [208] = Y5885_pgtype53;
	Y5885_gen_type [209] = Y5885_pgtype54;
	Y5885_gen_type [210] = Y5885_pgtype55;
	Y5885_gen_type [211] = Y5885_pgtype56;
	Y5885_gen_type [212] = Y5885_pgtype57;
	Y5885_gen_type [213] = Y5885_pgtype58;
	Y5885_gen_type [214] = Y5885_pgtype59;
	Y5885_gen_type [215] = Y5885_pgtype60;
	Y5885_gen_type [216] = Y5885_pgtype61;
	Y5885_gen_type [217] = Y5885_pgtype62;
	Y5885_gen_type [218] = Y5885_pgtype63;
	Y5885_gen_type [219] = Y5885_pgtype64;
	Y5885_gen_type [220] = Y5885_pgtype65;
	Y5885_gen_type [221] = Y5885_pgtype66;
	Y5885_gen_type [222] = Y5885_pgtype67;
	Y5885_gen_type [223] = Y5885_pgtype68;
	Y5885_gen_type [224] = Y5885_pgtype69;
	Y5885_gen_type [225] = Y5885_pgtype70;
	Y5885_gen_type [226] = Y5885_pgtype71;
	Y5885_gen_type [227] = Y5885_pgtype72;
	Y5885_gen_type [228] = Y5885_pgtype73;
	Y5885_gen_type [229] = Y5885_pgtype74;
	Y5885_gen_type [230] = Y5885_pgtype75;
	Y5885_gen_type [231] = Y5885_pgtype76;
	Y5885_gen_type [232] = Y5885_pgtype77;
	Y5885_gen_type [233] = Y5885_pgtype78;
	Y5885_gen_type [234] = Y5885_pgtype79;
	Y5885_gen_type [235] = Y5885_pgtype80;
	Y5885_gen_type [236] = Y5885_pgtype81;
	Y5885_gen_type [237] = Y5885_pgtype82;
	Y5885_gen_type [238] = Y5885_pgtype83;
	Y5885_gen_type [239] = Y5885_pgtype84;
	Y5885_gen_type [240] = Y5885_pgtype85;
	Y5885_gen_type [241] = Y5885_pgtype86;
	Y5885_gen_type [242] = Y5885_pgtype87;
	Y5885_gen_type [243] = Y5885_pgtype88;
	Y5885_gen_type [244] = Y5885_pgtype89;
	Y5885_gen_type [245] = Y5885_pgtype90;
	Y5885_gen_type [246] = Y5885_pgtype91;
	Y5885_gen_type [247] = Y5885_pgtype92;
	Y5885_gen_type [248] = Y5885_pgtype93;
	Y5885_gen_type [249] = Y5885_pgtype94;
	Y5885_gen_type [250] = Y5885_pgtype95;
	Y5885_gen_type [251] = Y5885_pgtype96;
	Y5885_gen_type [716] = Y5885_pgtype97;
	Y5885_gen_type [717] = Y5885_pgtype98;
	Y5885_gen_type [718] = Y5885_pgtype99;
	Y5885_gen_type [719] = Y5885_pgtype100;
	Y5885_gen_type [720] = Y5885_pgtype101;
	Y5885_gen_type [721] = Y5885_pgtype102;
	Y5885_gen_type [722] = Y5885_pgtype103;
	Y5885_gen_type [723] = Y5885_pgtype104;
	Y5885_gen_type [724] = Y5885_pgtype105;
	Y5885_gen_type [725] = Y5885_pgtype106;
	{long i; for (i = 0; i < 12; i++) Y5885[i] = 308;};
	{long i; for (i = 167; i < 217; i++) Y5885[i] = 308;};
	Y5885[217] = 311;
	Y5885[218] = 312;
	Y5885[219] = 313;
	{long i; for (i = 220; i < 223; i++) Y5885[i] = 311;};
	Y5885[223] = 313;
	Y5885[224] = 312;
	{long i; for (i = 225; i < 227; i++) Y5885[i] = 314;};
	{long i; for (i = 227; i < 252; i++) Y5885[i] = 310;};
	{long i; for (i = 716; i < 726; i++) Y5885[i] = 310;};
}

char *(*R5887[509])();
void R5887_init () {
	R5887[0] = (char *(*)()) F940_7748;
	R5887[1] = (char *(*)()) F941_7748;
	R5887[2] = (char *(*)()) F942_7748;
	{long i; for (i = 3; i < 6; i++) R5887[i] = (char *(*)()) F940_7748;}
	R5887[6] = (char *(*)()) F942_7748;
	R5887[7] = (char *(*)()) F941_7748;
	R5887[9] = (char *(*)()) F940_7748;
	R5887[10] = (char *(*)()) F950_7879;
	R5887[11] = (char *(*)()) F951_7879;
	R5887[12] = (char *(*)()) F952_7879;
	R5887[13] = (char *(*)()) F953_7879;
	R5887[14] = (char *(*)()) F954_7879;
	R5887[15] = (char *(*)()) F955_7879;
	R5887[16] = (char *(*)()) F956_7879;
	R5887[17] = (char *(*)()) F957_7879;
	R5887[18] = (char *(*)()) F958_7879;
	R5887[19] = (char *(*)()) F959_7879;
	R5887[20] = (char *(*)()) F960_7879;
	R5887[21] = (char *(*)()) F961_7879;
	R5887[22] = (char *(*)()) F950_7879;
	R5887[24] = (char *(*)()) F950_7879;
	R5887[26] = (char *(*)()) F950_7879;
	R5887[27] = (char *(*)()) F953_7879;
	R5887[28] = (char *(*)()) F954_7879;
	R5887[29] = (char *(*)()) F950_7879;
	{long i; for (i = 31; i < 33; i++) R5887[i] = (char *(*)()) F950_7879;}
	{long i; for (i = 33; i < 35; i++) R5887[i] = (char *(*)()) F953_7879;}
	{long i; for (i = 499; i < 509; i++) R5887[i] = (char *(*)()) F950_7879;}
}

char *(*R5913[2])();
void R5913_init () {
	R5913[0] = (char *(*)()) F755_7326;
	R5913[1] = (char *(*)()) F756_7345;
}

char *(*R5942[755])();
void R5942_init () {
	R5942[0] = (char *(*)()) F797_7374;
	R5942[49] = (char *(*)()) F846_7452;
	R5942[50] = (char *(*)()) F847_7452;
	R5942[51] = (char *(*)()) F848_7452;
	R5942[52] = (char *(*)()) F849_7452;
	R5942[53] = (char *(*)()) F850_7452;
	R5942[54] = (char *(*)()) F851_7452;
	R5942[55] = (char *(*)()) F852_7452;
	R5942[56] = (char *(*)()) F853_7452;
	{long i; for (i = 57; i < 59; i++) R5942[i] = (char *(*)()) F846_7452;}
	R5942[59] = (char *(*)()) F848_7452;
	R5942[60] = (char *(*)()) F852_7452;
	R5942[61] = (char *(*)()) F849_7452;
	R5942[62] = (char *(*)()) F853_7452;
	R5942[75] = (char *(*)()) F872_7577;
	R5942[76] = (char *(*)()) F873_7617;
	R5942[77] = (char *(*)()) F874_7617;
	R5942[78] = (char *(*)()) F875_7617;
	R5942[79] = (char *(*)()) F876_7617;
	R5942[80] = (char *(*)()) F877_7617;
	R5942[81] = (char *(*)()) F878_7617;
	R5942[82] = (char *(*)()) F879_7617;
	R5942[83] = (char *(*)()) F880_7617;
	R5942[84] = (char *(*)()) F881_7617;
	R5942[85] = (char *(*)()) F882_7617;
	R5942[86] = (char *(*)()) F883_7617;
	R5942[87] = (char *(*)()) F884_7617;
	R5942[143] = (char *(*)()) F940_7732;
	R5942[144] = (char *(*)()) F941_7732;
	R5942[145] = (char *(*)()) F942_7732;
	{long i; for (i = 146; i < 149; i++) R5942[i] = (char *(*)()) F940_7732;}
	R5942[149] = (char *(*)()) F942_7732;
	R5942[150] = (char *(*)()) F941_7732;
	R5942[152] = (char *(*)()) F940_7732;
	R5942[153] = (char *(*)()) F950_7864;
	R5942[154] = (char *(*)()) F951_7864;
	R5942[155] = (char *(*)()) F952_7864;
	R5942[156] = (char *(*)()) F953_7864;
	R5942[157] = (char *(*)()) F954_7864;
	R5942[158] = (char *(*)()) F955_7864;
	R5942[159] = (char *(*)()) F956_7864;
	R5942[160] = (char *(*)()) F957_7864;
	R5942[161] = (char *(*)()) F958_7864;
	R5942[162] = (char *(*)()) F959_7864;
	R5942[163] = (char *(*)()) F960_7864;
	R5942[164] = (char *(*)()) F961_7864;
	R5942[165] = (char *(*)()) F950_7864;
	R5942[167] = (char *(*)()) F950_7864;
	R5942[169] = (char *(*)()) F950_7864;
	R5942[170] = (char *(*)()) F953_7864;
	R5942[171] = (char *(*)()) F954_7864;
	R5942[172] = (char *(*)()) F950_7864;
	{long i; for (i = 174; i < 176; i++) R5942[i] = (char *(*)()) F950_7864;}
	{long i; for (i = 176; i < 178; i++) R5942[i] = (char *(*)()) F953_7864;}
	{long i; for (i = 210; i < 212; i++) R5942[i] = (char *(*)()) F1006_8581;}
	R5942[299] = (char *(*)()) F1094_9680;
	R5942[302] = (char *(*)()) F1097_9848;
	R5942[473] = (char *(*)()) F1270_12025;
	{long i; for (i = 642; i < 652; i++) R5942[i] = (char *(*)()) F950_7864;}
	R5942[754] = (char *(*)()) F1551_18504;
}

EIF_TYPE_INDEX *Y5942_gen_type [796];
EIF_TYPE_INDEX Y5942 [796];
void Y5942_init (void)
{
	egc_routines_types [5942] = Y5942;
	egc_routines_gen_types [5942] = Y5942_gen_type;
	egc_routines_offset [5942] = 756;
	{long i; for (i = 0; i < 68; i++) Y5942[i] = 1229;};
	{long i; for (i = 89; i < 103; i++) Y5942[i] = 1229;};
	{long i; for (i = 115; i < 218; i++) Y5942[i] = 1229;};
	{long i; for (i = 249; i < 252; i++) Y5942[i] = 1229;};
	Y5942[339] = 1229;
	{long i; for (i = 342; i < 344; i++) Y5942[i] = 1229;};
	Y5942[513] = 1229;
	{long i; for (i = 547; i < 550; i++) Y5942[i] = 1229;};
	{long i; for (i = 551; i < 556; i++) Y5942[i] = 1229;};
	{long i; for (i = 682; i < 692; i++) Y5942[i] = 1229;};
	{long i; for (i = 794; i < 796; i++) Y5942[i] = 1229;};
}

char *(*R5943[755])();
void R5943_init () {
	R5943[0] = (char *(*)()) F797_7375;
	R5943[75] = (char *(*)()) F872_7576;
	R5943[76] = (char *(*)()) F873_7618;
	R5943[77] = (char *(*)()) F874_7618;
	R5943[78] = (char *(*)()) F875_7618;
	R5943[79] = (char *(*)()) F876_7618;
	R5943[80] = (char *(*)()) F877_7618;
	R5943[81] = (char *(*)()) F878_7618;
	R5943[82] = (char *(*)()) F879_7618;
	R5943[83] = (char *(*)()) F880_7618;
	R5943[84] = (char *(*)()) F881_7618;
	R5943[85] = (char *(*)()) F882_7618;
	R5943[86] = (char *(*)()) F883_7618;
	R5943[87] = (char *(*)()) F884_7618;
	R5943[153] = (char *(*)()) F950_7865;
	R5943[154] = (char *(*)()) F951_7865;
	R5943[155] = (char *(*)()) F952_7865;
	R5943[156] = (char *(*)()) F953_7865;
	R5943[157] = (char *(*)()) F954_7865;
	R5943[158] = (char *(*)()) F955_7865;
	R5943[159] = (char *(*)()) F956_7865;
	R5943[160] = (char *(*)()) F957_7865;
	R5943[161] = (char *(*)()) F958_7865;
	R5943[162] = (char *(*)()) F959_7865;
	R5943[163] = (char *(*)()) F960_7865;
	R5943[164] = (char *(*)()) F961_7865;
	R5943[165] = (char *(*)()) F950_7865;
	R5943[167] = (char *(*)()) F950_7865;
	R5943[169] = (char *(*)()) F950_7865;
	R5943[170] = (char *(*)()) F953_7865;
	R5943[171] = (char *(*)()) F954_7865;
	R5943[172] = (char *(*)()) F950_7865;
	{long i; for (i = 174; i < 176; i++) R5943[i] = (char *(*)()) F950_7865;}
	{long i; for (i = 176; i < 178; i++) R5943[i] = (char *(*)()) F953_7865;}
	R5943[299] = (char *(*)()) F1094_9679;
	R5943[302] = (char *(*)()) F1097_9847;
	{long i; for (i = 642; i < 652; i++) R5943[i] = (char *(*)()) F950_7865;}
	R5943[754] = (char *(*)()) F1551_18506;
}

char *(*R5947[755])();
void R5947_init () {
	R5947[0] = (char *(*)()) F781_7357;
	R5947[75] = (char *(*)()) F784_7357;
	R5947[76] = (char *(*)()) F781_7357;
	R5947[77] = (char *(*)()) F782_7357;
	R5947[78] = (char *(*)()) F783_7357;
	R5947[79] = (char *(*)()) F784_7357;
	R5947[80] = (char *(*)()) F785_7357;
	R5947[81] = (char *(*)()) F786_7357;
	R5947[82] = (char *(*)()) F787_7357;
	R5947[83] = (char *(*)()) F788_7357;
	R5947[84] = (char *(*)()) F789_7357;
	R5947[85] = (char *(*)()) F790_7357;
	R5947[86] = (char *(*)()) F791_7357;
	R5947[87] = (char *(*)()) F792_7357;
	R5947[153] = (char *(*)()) F781_7357;
	R5947[154] = (char *(*)()) F782_7357;
	R5947[155] = (char *(*)()) F783_7357;
	R5947[156] = (char *(*)()) F784_7357;
	R5947[157] = (char *(*)()) F785_7357;
	R5947[158] = (char *(*)()) F786_7357;
	R5947[159] = (char *(*)()) F787_7357;
	R5947[160] = (char *(*)()) F788_7357;
	R5947[161] = (char *(*)()) F789_7357;
	R5947[162] = (char *(*)()) F790_7357;
	R5947[163] = (char *(*)()) F791_7357;
	R5947[164] = (char *(*)()) F792_7357;
	R5947[165] = (char *(*)()) F781_7357;
	R5947[167] = (char *(*)()) F781_7357;
	R5947[169] = (char *(*)()) F781_7357;
	R5947[170] = (char *(*)()) F784_7357;
	R5947[171] = (char *(*)()) F785_7357;
	R5947[172] = (char *(*)()) F781_7357;
	{long i; for (i = 174; i < 176; i++) R5947[i] = (char *(*)()) F781_7357;}
	{long i; for (i = 176; i < 178; i++) R5947[i] = (char *(*)()) F784_7357;}
	R5947[299] = (char *(*)()) F789_7357;
	R5947[302] = (char *(*)()) F791_7357;
	{long i; for (i = 642; i < 652; i++) R5947[i] = (char *(*)()) F781_7357;}
	R5947[754] = (char *(*)()) F791_7357;
}

char *(*R5949[755])();
void R5949_init () {
	R5949[0] = (char *(*)()) F797_7397;
	R5949[75] = (char *(*)()) F872_7587;
	R5949[76] = (char *(*)()) F873_7648;
	R5949[77] = (char *(*)()) F874_7648;
	R5949[78] = (char *(*)()) F875_7648;
	R5949[79] = (char *(*)()) F876_7648;
	R5949[80] = (char *(*)()) F877_7648;
	R5949[81] = (char *(*)()) F878_7648;
	R5949[82] = (char *(*)()) F879_7648;
	R5949[83] = (char *(*)()) F880_7648;
	R5949[84] = (char *(*)()) F881_7648;
	R5949[85] = (char *(*)()) F882_7648;
	R5949[86] = (char *(*)()) F883_7648;
	R5949[87] = (char *(*)()) F884_7648;
	R5949[153] = (char *(*)()) F950_7891;
	R5949[154] = (char *(*)()) F951_7891;
	R5949[155] = (char *(*)()) F952_7891;
	R5949[156] = (char *(*)()) F953_7891;
	R5949[157] = (char *(*)()) F954_7891;
	R5949[158] = (char *(*)()) F955_7891;
	R5949[159] = (char *(*)()) F956_7891;
	R5949[160] = (char *(*)()) F957_7891;
	R5949[161] = (char *(*)()) F958_7891;
	R5949[162] = (char *(*)()) F959_7891;
	R5949[163] = (char *(*)()) F960_7891;
	R5949[164] = (char *(*)()) F961_7891;
	R5949[165] = (char *(*)()) F950_7891;
	R5949[167] = (char *(*)()) F950_7891;
	R5949[169] = (char *(*)()) F950_7891;
	R5949[170] = (char *(*)()) F953_7891;
	R5949[171] = (char *(*)()) F954_7891;
	R5949[172] = (char *(*)()) F950_7891;
	{long i; for (i = 174; i < 176; i++) R5949[i] = (char *(*)()) F950_7891;}
	{long i; for (i = 176; i < 178; i++) R5949[i] = (char *(*)()) F953_7891;}
	R5949[299] = (char *(*)()) F1096_9807;
	R5949[302] = (char *(*)()) F1099_9972;
	{long i; for (i = 642; i < 652; i++) R5949[i] = (char *(*)()) F950_7891;}
	R5949[754] = (char *(*)()) F1099_9972;
}

char *(*R5963[509])();
void R5963_init () {
	R5963[0] = (char *(*)()) F801_7408;
	R5963[1] = (char *(*)()) F804_7408_5963_4;
	R5963[2] = (char *(*)()) F805_7408_5963_4;
	R5963[3] = (char *(*)()) F943_7774;
	R5963[4] = (char *(*)()) F801_7408;
	R5963[5] = (char *(*)()) F945_7800;
	R5963[6] = (char *(*)()) F946_7800_5963_4;
	R5963[7] = (char *(*)()) F947_7800_5963_4;
	R5963[9] = (char *(*)()) F801_7408;
	R5963[10] = (char *(*)()) F950_7883;
	R5963[11] = (char *(*)()) F951_7883_5963_4;
	R5963[12] = (char *(*)()) F952_7883_5963_4;
	R5963[13] = (char *(*)()) F953_7883_5963_4;
	R5963[14] = (char *(*)()) F954_7883_5963_4;
	R5963[15] = (char *(*)()) F955_7883_5963_4;
	R5963[16] = (char *(*)()) F956_7883_5963_4;
	R5963[17] = (char *(*)()) F957_7883_5963_4;
	R5963[18] = (char *(*)()) F958_7883_5963_4;
	R5963[19] = (char *(*)()) F959_7883_5963_4;
	R5963[20] = (char *(*)()) F960_7883_5963_4;
	R5963[21] = (char *(*)()) F961_7883_5963_4;
	R5963[22] = (char *(*)()) F950_7883;
	R5963[24] = (char *(*)()) F950_7883;
	R5963[26] = (char *(*)()) F950_7883;
	R5963[27] = (char *(*)()) F953_7883_5963_4;
	R5963[28] = (char *(*)()) F954_7883_5963_4;
	R5963[29] = (char *(*)()) F950_7883;
	{long i; for (i = 31; i < 33; i++) R5963[i] = (char *(*)()) F950_7883;}
	{long i; for (i = 33; i < 35; i++) R5963[i] = (char *(*)()) F953_7883_5963_4;}
	{long i; for (i = 67; i < 69; i++) R5963[i] = (char *(*)()) F806_7408_5963_4;}
	R5963[330] = (char *(*)()) F806_7408_5963_4;
	{long i; for (i = 499; i < 509; i++) R5963[i] = (char *(*)()) F950_7883;}
}
static void F804_7408_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F804_7408(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F805_7408_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F805_7408(Current, *(EIF_BOOLEAN *)arg1);
}
static void F946_7800_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F946_7800(Current, *(EIF_BOOLEAN *)arg1);
}
static void F947_7800_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_7800(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F951_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7883(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F952_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7883(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F953_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7883(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7883(Current, *(EIF_BOOLEAN *)arg1);
}
static void F955_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7883(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F956_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7883(Current, *(EIF_POINTER *)arg1);
}
static void F957_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7883(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F958_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7883(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F959_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7883(Current, *(EIF_REAL_64 *)arg1);
}
static void F960_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7883(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F961_7883_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F961_7883(Current, *(EIF_REAL_32 *)arg1);
}
static void F806_7408_5963_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F806_7408(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5964[509])();
void R5964_init () {
	R5964[0] = (char *(*)()) F890_7683;
	R5964[1] = (char *(*)()) F893_7683;
	R5964[2] = (char *(*)()) F894_7683;
	R5964[3] = (char *(*)()) F793_7364;
	R5964[4] = (char *(*)()) F890_7683;
	R5964[5] = (char *(*)()) F793_7364;
	R5964[6] = (char *(*)()) F795_7364;
	R5964[7] = (char *(*)()) F794_7364;
	R5964[9] = (char *(*)()) F890_7683;
	R5964[10] = (char *(*)()) F950_7890;
	R5964[11] = (char *(*)()) F951_7890;
	R5964[12] = (char *(*)()) F952_7890;
	R5964[13] = (char *(*)()) F953_7890;
	R5964[14] = (char *(*)()) F954_7890;
	R5964[15] = (char *(*)()) F955_7890;
	R5964[16] = (char *(*)()) F956_7890;
	R5964[17] = (char *(*)()) F957_7890;
	R5964[18] = (char *(*)()) F958_7890;
	R5964[19] = (char *(*)()) F959_7890;
	R5964[20] = (char *(*)()) F960_7890;
	R5964[21] = (char *(*)()) F961_7890;
	R5964[22] = (char *(*)()) F950_7890;
	R5964[24] = (char *(*)()) F950_7890;
	R5964[26] = (char *(*)()) F793_7364;
	R5964[27] = (char *(*)()) F794_7364;
	R5964[28] = (char *(*)()) F795_7364;
	R5964[29] = (char *(*)()) F950_7890;
	R5964[31] = (char *(*)()) F970_7956;
	R5964[32] = (char *(*)()) F950_7890;
	{long i; for (i = 33; i < 35; i++) R5964[i] = (char *(*)()) F953_7890;}
	{long i; for (i = 499; i < 509; i++) R5964[i] = (char *(*)()) F950_7890;}
}

char *(*R5979[706])();
void R5979_init () {
	R5979[0] = (char *(*)()) F846_7450;
	R5979[1] = (char *(*)()) F847_7450;
	R5979[2] = (char *(*)()) F848_7450_5979_20;
	R5979[3] = (char *(*)()) F849_7450_5979_20;
	R5979[4] = (char *(*)()) F850_7450_5979_20;
	R5979[5] = (char *(*)()) F851_7450_5979_20;
	R5979[6] = (char *(*)()) F852_7450_5979_20;
	R5979[7] = (char *(*)()) F853_7450_5979_20;
	{long i; for (i = 8; i < 10; i++) R5979[i] = (char *(*)()) F846_7450;}
	R5979[10] = (char *(*)()) F848_7450_5979_20;
	R5979[11] = (char *(*)()) F852_7450_5979_20;
	R5979[12] = (char *(*)()) F849_7450_5979_20;
	R5979[13] = (char *(*)()) F853_7450_5979_20;
	R5979[26] = (char *(*)()) F872_7571_5979_20;
	R5979[27] = (char *(*)()) F873_7610;
	R5979[28] = (char *(*)()) F874_7610_5979_20;
	R5979[29] = (char *(*)()) F875_7610_5979_20;
	R5979[30] = (char *(*)()) F876_7610_5979_20;
	R5979[31] = (char *(*)()) F877_7610_5979_20;
	R5979[32] = (char *(*)()) F878_7610_5979_20;
	R5979[33] = (char *(*)()) F879_7610_5979_20;
	R5979[34] = (char *(*)()) F880_7610_5979_20;
	R5979[35] = (char *(*)()) F881_7610_5979_20;
	R5979[36] = (char *(*)()) F882_7610_5979_20;
	R5979[37] = (char *(*)()) F883_7610_5979_20;
	R5979[38] = (char *(*)()) F884_7610_5979_20;
	R5979[94] = (char *(*)()) F890_7668;
	R5979[95] = (char *(*)()) F893_7668_5979_20;
	R5979[96] = (char *(*)()) F894_7668_5979_20;
	{long i; for (i = 97; i < 100; i++) R5979[i] = (char *(*)()) F890_7668;}
	R5979[100] = (char *(*)()) F894_7668_5979_20;
	R5979[101] = (char *(*)()) F893_7668_5979_20;
	R5979[103] = (char *(*)()) F890_7668;
	R5979[104] = (char *(*)()) F950_7849;
	R5979[105] = (char *(*)()) F951_7849_5979_20;
	R5979[106] = (char *(*)()) F952_7849_5979_20;
	R5979[107] = (char *(*)()) F953_7849_5979_20;
	R5979[108] = (char *(*)()) F954_7849_5979_20;
	R5979[109] = (char *(*)()) F955_7849_5979_20;
	R5979[110] = (char *(*)()) F956_7849_5979_20;
	R5979[111] = (char *(*)()) F957_7849_5979_20;
	R5979[112] = (char *(*)()) F958_7849_5979_20;
	R5979[113] = (char *(*)()) F959_7849_5979_20;
	R5979[114] = (char *(*)()) F960_7849_5979_20;
	R5979[115] = (char *(*)()) F961_7849_5979_20;
	R5979[116] = (char *(*)()) F950_7849;
	R5979[118] = (char *(*)()) F950_7849;
	R5979[120] = (char *(*)()) F950_7849;
	R5979[121] = (char *(*)()) F953_7849_5979_20;
	R5979[122] = (char *(*)()) F954_7849_5979_20;
	R5979[123] = (char *(*)()) F950_7849;
	{long i; for (i = 125; i < 127; i++) R5979[i] = (char *(*)()) F950_7849;}
	{long i; for (i = 127; i < 129; i++) R5979[i] = (char *(*)()) F953_7849_5979_20;}
	R5979[194] = (char *(*)()) F1040_9173;
	R5979[249] = (char *(*)()) F1095_9718_5979_20;
	R5979[250] = (char *(*)()) F1096_9741_5979_20;
	R5979[252] = (char *(*)()) F1098_9883_5979_20;
	R5979[253] = (char *(*)()) F1099_9905_5979_20;
	R5979[305] = (char *(*)()) F1151_10565;
	R5979[306] = (char *(*)()) F1152_10565_5979_20;
	R5979[307] = (char *(*)()) F1153_10565_5979_20;
	R5979[308] = (char *(*)()) F1154_10565_5979_20;
	R5979[309] = (char *(*)()) F1155_10565_5979_20;
	R5979[310] = (char *(*)()) F1156_10565_5979_20;
	R5979[311] = (char *(*)()) F1157_10565_5979_20;
	R5979[312] = (char *(*)()) F1158_10565_5979_20;
	R5979[313] = (char *(*)()) F1159_10565_5979_20;
	R5979[314] = (char *(*)()) F1160_10565_5979_20;
	R5979[315] = (char *(*)()) F1161_10565_5979_20;
	R5979[316] = (char *(*)()) F1162_10565_5979_20;
	{long i; for (i = 593; i < 603; i++) R5979[i] = (char *(*)()) F950_7849;}
	R5979[705] = (char *(*)()) F1551_18488_5979_20;
}
static EIF_REFERENCE F848_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F848_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F849_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F850_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F852_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_7450_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F853_7450(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_7571_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F872_7571(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F874_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F874_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F875_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F876_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F876_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F877_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F877_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F878_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F878_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F879_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F879_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F880_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F880_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F881_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F882_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_7610_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F884_7610(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_7668_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F893_7668(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_7668_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F894_7668(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F951_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F952_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F953_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F954_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F955_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F956_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F957_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F958_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F959_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F960_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7849_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F961_7849(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1095_9718_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1095_9718(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1096_9741_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1096_9741(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1098_9883_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1098_9883(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_9905_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1099_9905(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1152_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1152_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1153_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1153_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1154_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1154_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1155_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1155_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1156_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1156_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1157_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1157_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1158_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1158_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1159_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1159_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1160_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1160_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1161_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1161_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1162_10565_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1162_10565(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1551_18488_5979_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1551_18488(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5980[706])();
void R5980_init () {
	R5980[0] = (char *(*)()) F846_7455;
	R5980[1] = (char *(*)()) F847_7455;
	R5980[2] = (char *(*)()) F848_7455;
	R5980[3] = (char *(*)()) F849_7455;
	R5980[4] = (char *(*)()) F850_7455;
	R5980[5] = (char *(*)()) F851_7455;
	R5980[6] = (char *(*)()) F852_7455;
	R5980[7] = (char *(*)()) F853_7455;
	{long i; for (i = 8; i < 10; i++) R5980[i] = (char *(*)()) F846_7455;}
	R5980[10] = (char *(*)()) F848_7455;
	R5980[11] = (char *(*)()) F852_7455;
	R5980[12] = (char *(*)()) F849_7455;
	R5980[13] = (char *(*)()) F853_7455;
	R5980[26] = (char *(*)()) F872_7568;
	R5980[27] = (char *(*)()) F873_7615;
	R5980[28] = (char *(*)()) F874_7615;
	R5980[29] = (char *(*)()) F875_7615;
	R5980[30] = (char *(*)()) F876_7615;
	R5980[31] = (char *(*)()) F877_7615;
	R5980[32] = (char *(*)()) F878_7615;
	R5980[33] = (char *(*)()) F879_7615;
	R5980[34] = (char *(*)()) F880_7615;
	R5980[35] = (char *(*)()) F881_7615;
	R5980[36] = (char *(*)()) F882_7615;
	R5980[37] = (char *(*)()) F883_7615;
	R5980[38] = (char *(*)()) F884_7615;
	R5980[94] = (char *(*)()) F890_7671;
	R5980[95] = (char *(*)()) F893_7671;
	R5980[96] = (char *(*)()) F894_7671;
	{long i; for (i = 97; i < 100; i++) R5980[i] = (char *(*)()) F890_7671;}
	R5980[100] = (char *(*)()) F894_7671;
	R5980[101] = (char *(*)()) F893_7671;
	{long i; for (i = 103; i < 105; i++) R5980[i] = (char *(*)()) F890_7671;}
	R5980[105] = (char *(*)()) F891_7671;
	R5980[106] = (char *(*)()) F892_7671;
	R5980[107] = (char *(*)()) F893_7671;
	R5980[108] = (char *(*)()) F894_7671;
	R5980[109] = (char *(*)()) F895_7671;
	R5980[110] = (char *(*)()) F896_7671;
	R5980[111] = (char *(*)()) F897_7671;
	R5980[112] = (char *(*)()) F898_7671;
	R5980[113] = (char *(*)()) F899_7671;
	R5980[114] = (char *(*)()) F900_7671;
	R5980[115] = (char *(*)()) F901_7671;
	R5980[116] = (char *(*)()) F890_7671;
	R5980[118] = (char *(*)()) F890_7671;
	R5980[120] = (char *(*)()) F890_7671;
	R5980[121] = (char *(*)()) F893_7671;
	R5980[122] = (char *(*)()) F894_7671;
	R5980[123] = (char *(*)()) F890_7671;
	{long i; for (i = 125; i < 127; i++) R5980[i] = (char *(*)()) F890_7671;}
	{long i; for (i = 127; i < 129; i++) R5980[i] = (char *(*)()) F893_7671;}
	R5980[194] = (char *(*)()) F1040_9203;
	{long i; for (i = 249; i < 251; i++) R5980[i] = (char *(*)()) F1094_9682;}
	{long i; for (i = 252; i < 254; i++) R5980[i] = (char *(*)()) F1097_9850;}
	R5980[305] = (char *(*)()) F1151_10573;
	R5980[306] = (char *(*)()) F1152_10573;
	R5980[307] = (char *(*)()) F1153_10573;
	R5980[308] = (char *(*)()) F1154_10573;
	R5980[309] = (char *(*)()) F1155_10573;
	R5980[310] = (char *(*)()) F1156_10573;
	R5980[311] = (char *(*)()) F1157_10573;
	R5980[312] = (char *(*)()) F1158_10573;
	R5980[313] = (char *(*)()) F1159_10573;
	R5980[314] = (char *(*)()) F1160_10573;
	R5980[315] = (char *(*)()) F1161_10573;
	R5980[316] = (char *(*)()) F1162_10573;
	{long i; for (i = 593; i < 603; i++) R5980[i] = (char *(*)()) F890_7671;}
	R5980[705] = (char *(*)()) F1097_9850;
}

EIF_TYPE_INDEX *Y5980_gen_type [719];
EIF_TYPE_INDEX Y5980 [719];
void Y5980_init (void)
{
	egc_routines_types [5980] = Y5980;
	egc_routines_gen_types [5980] = Y5980_gen_type;
	egc_routines_offset [5980] = 833;
	{long i; for (i = 0; i < 141; i++) Y5980[i] = 1229;};
	Y5980[206] = 1229;
	{long i; for (i = 260; i < 267; i++) Y5980[i] = 1229;};
	{long i; for (i = 317; i < 329; i++) Y5980[i] = 1229;};
	{long i; for (i = 605; i < 615; i++) Y5980[i] = 1229;};
	{long i; for (i = 717; i < 719; i++) Y5980[i] = 1229;};
}


#ifdef __cplusplus
}
#endif
