#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1550])();
void R11_init () {
	{long i; for (i = 0; i < 3; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 4; i < 9; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 10; i < 18; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 19; i < 25; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 26; i < 30; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 31; i < 34; i++) R11[i] = (char *(*)()) F1_8;}
	R11[35] = (char *(*)()) F1_8;
	{long i; for (i = 38; i < 40; i++) R11[i] = (char *(*)()) F1_8;}
	R11[42] = (char *(*)()) F1_8;
	R11[44] = (char *(*)()) F1_8;
	R11[46] = (char *(*)()) F1_8;
	R11[48] = (char *(*)()) F1_8;
	R11[50] = (char *(*)()) F1_8;
	{long i; for (i = 52; i < 56; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 57; i < 66; i++) R11[i] = (char *(*)()) F1_8;}
	R11[66] = (char *(*)()) F68_860;
	{long i; for (i = 67; i < 72; i++) R11[i] = (char *(*)()) F1_8;}
	R11[73] = (char *(*)()) F1_8;
	{long i; for (i = 76; i < 79; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 91; i < 94; i++) R11[i] = (char *(*)()) F1_8;}
	R11[104] = (char *(*)()) F1_8;
	R11[107] = (char *(*)()) F1_8;
	R11[112] = (char *(*)()) F1_8;
	R11[123] = (char *(*)()) F1_8;
	R11[127] = (char *(*)()) F1_8;
	R11[132] = (char *(*)()) F1_8;
	{long i; for (i = 141; i < 143; i++) R11[i] = (char *(*)()) F1_8;}
	R11[145] = (char *(*)()) F1_8;
	R11[150] = (char *(*)()) F1_8;
	R11[160] = (char *(*)()) F1_8;
	R11[167] = (char *(*)()) F1_8;
	R11[170] = (char *(*)()) F1_8;
	R11[172] = (char *(*)()) F1_8;
	R11[174] = (char *(*)()) F1_8;
	R11[178] = (char *(*)()) F1_8;
	R11[180] = (char *(*)()) F1_8;
	{long i; for (i = 185; i < 188; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 189; i < 201; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 206; i < 208; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 209; i < 211; i++) R11[i] = (char *(*)()) F1_8;}
	R11[215] = (char *(*)()) F1_8;
	R11[222] = (char *(*)()) F1_8;
	{long i; for (i = 224; i < 226; i++) R11[i] = (char *(*)()) F1_8;}
	R11[236] = (char *(*)()) F1_8;
	{long i; for (i = 243; i < 245; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 246; i < 248; i++) R11[i] = (char *(*)()) F1_8;}
	R11[253] = (char *(*)()) F1_8;
	{long i; for (i = 261; i < 265; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 266; i < 271; i++) R11[i] = (char *(*)()) F1_8;}
	R11[275] = (char *(*)()) F1_8;
	R11[280] = (char *(*)()) F1_8;
	R11[282] = (char *(*)()) F1_8;
	R11[287] = (char *(*)()) F1_8;
	R11[292] = (char *(*)()) F1_8;
	{long i; for (i = 294; i < 296; i++) R11[i] = (char *(*)()) F1_8;}
	R11[299] = (char *(*)()) F1_8;
	R11[304] = (char *(*)()) F1_8;
	{long i; for (i = 309; i < 314; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 315; i < 317; i++) R11[i] = (char *(*)()) F1_8;}
	R11[319] = (char *(*)()) F1_8;
	{long i; for (i = 321; i < 327; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 328; i < 331; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 332; i < 334; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 336; i < 338; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 339; i < 342; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 343; i < 347; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 348; i < 350; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 351; i < 357; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 358; i < 362; i++) R11[i] = (char *(*)()) F1_8;}
	R11[363] = (char *(*)()) F1_8;
	R11[370] = (char *(*)()) F372_5102;
	R11[371] = (char *(*)()) F1_8;
	R11[379] = (char *(*)()) F380_5343;
	R11[387] = (char *(*)()) F1_8;
	R11[393] = (char *(*)()) F1_8;
	R11[401] = (char *(*)()) F403_5847;
	R11[402] = (char *(*)()) F1_8;
	{long i; for (i = 404; i < 411; i++) R11[i] = (char *(*)()) F1_8;}
	R11[425] = (char *(*)()) F1_8;
	R11[427] = (char *(*)()) F1_8;
	R11[429] = (char *(*)()) F431_5961;
	{long i; for (i = 430; i < 432; i++) R11[i] = (char *(*)()) F1_8;}
	R11[432] = (char *(*)()) F434_6050;
	R11[434] = (char *(*)()) F1_8;
	{long i; for (i = 436; i < 438; i++) R11[i] = (char *(*)()) F1_8;}
	R11[441] = (char *(*)()) F1_8;
	R11[443] = (char *(*)()) F1_8;
	R11[447] = (char *(*)()) F1_8;
	{long i; for (i = 450; i < 452; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 453; i < 455; i++) R11[i] = (char *(*)()) F1_8;}
	R11[456] = (char *(*)()) F1_8;
	R11[458] = (char *(*)()) F1_8;
	{long i; for (i = 471; i < 476; i++) R11[i] = (char *(*)()) F1_8;}
	R11[500] = (char *(*)()) F1_8;
	{long i; for (i = 526; i < 550; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 562; i < 600; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 753; i < 755; i++) R11[i] = (char *(*)()) F1_8;}
	R11[795] = (char *(*)()) F797_7373;
	R11[831] = (char *(*)()) F1_8;
	R11[844] = (char *(*)()) F846_7457;
	R11[845] = (char *(*)()) F847_7457;
	R11[846] = (char *(*)()) F848_7457;
	R11[847] = (char *(*)()) F849_7457;
	R11[848] = (char *(*)()) F850_7457;
	R11[849] = (char *(*)()) F851_7457;
	R11[850] = (char *(*)()) F852_7457;
	R11[851] = (char *(*)()) F853_7457;
	R11[852] = (char *(*)()) F846_7457;
	R11[853] = (char *(*)()) F855_7563;
	R11[854] = (char *(*)()) F856_7563;
	R11[855] = (char *(*)()) F857_7563;
	R11[856] = (char *(*)()) F858_7563;
	R11[857] = (char *(*)()) F859_7563;
	R11[870] = (char *(*)()) F872_7579;
	R11[871] = (char *(*)()) F873_7620;
	R11[872] = (char *(*)()) F874_7620;
	R11[873] = (char *(*)()) F875_7620;
	R11[874] = (char *(*)()) F876_7620;
	R11[875] = (char *(*)()) F877_7620;
	R11[876] = (char *(*)()) F878_7620;
	R11[877] = (char *(*)()) F879_7620;
	R11[878] = (char *(*)()) F880_7620;
	R11[879] = (char *(*)()) F881_7620;
	R11[880] = (char *(*)()) F882_7620;
	R11[881] = (char *(*)()) F883_7620;
	R11[882] = (char *(*)()) F884_7620;
	R11[938] = (char *(*)()) F914_7702;
	R11[939] = (char *(*)()) F917_7702;
	R11[940] = (char *(*)()) F918_7702;
	{long i; for (i = 941; i < 944; i++) R11[i] = (char *(*)()) F914_7702;}
	R11[944] = (char *(*)()) F918_7702;
	R11[945] = (char *(*)()) F917_7702;
	R11[947] = (char *(*)()) F914_7702;
	R11[948] = (char *(*)()) F950_7867;
	R11[949] = (char *(*)()) F951_7867;
	R11[950] = (char *(*)()) F952_7867;
	R11[951] = (char *(*)()) F953_7867;
	R11[952] = (char *(*)()) F954_7867;
	R11[953] = (char *(*)()) F955_7867;
	R11[954] = (char *(*)()) F956_7867;
	R11[955] = (char *(*)()) F957_7867;
	R11[956] = (char *(*)()) F958_7867;
	R11[957] = (char *(*)()) F959_7867;
	R11[958] = (char *(*)()) F960_7867;
	R11[959] = (char *(*)()) F961_7867;
	R11[960] = (char *(*)()) F950_7867;
	R11[962] = (char *(*)()) F950_7867;
	R11[964] = (char *(*)()) F950_7867;
	R11[965] = (char *(*)()) F953_7867;
	R11[966] = (char *(*)()) F954_7867;
	R11[967] = (char *(*)()) F950_7867;
	{long i; for (i = 969; i < 971; i++) R11[i] = (char *(*)()) F950_7867;}
	{long i; for (i = 971; i < 973; i++) R11[i] = (char *(*)()) F953_7867;}
	R11[974] = (char *(*)()) F1_8;
	R11[976] = (char *(*)()) F1_8;
	{long i; for (i = 977; i < 979; i++) R11[i] = (char *(*)()) F979_8257;}
	{long i; for (i = 987; i < 996; i++) R11[i] = (char *(*)()) F1_8;}
	R11[998] = (char *(*)()) F1_8;
	{long i; for (i = 1000; i < 1003; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1005; i < 1007; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1014] = (char *(*)()) F1_8;
	{long i; for (i = 1021; i < 1029; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1038] = (char *(*)()) F1040_9196;
	{long i; for (i = 1040; i < 1042; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1043; i < 1045; i++) R11[i] = (char *(*)()) F1044_9334;}
	{long i; for (i = 1046; i < 1048; i++) R11[i] = (char *(*)()) F1047_9374;}
	R11[1048] = (char *(*)()) F1_8;
	{long i; for (i = 1051; i < 1083; i++) R11[i] = (char *(*)()) F1052_9447;}
	R11[1084] = (char *(*)()) F1085_9484;
	R11[1085] = (char *(*)()) F1087_9522;
	R11[1086] = (char *(*)()) F1088_9522;
	R11[1087] = (char *(*)()) F1089_9522;
	R11[1088] = (char *(*)()) F1088_9522;
	{long i; for (i = 1093; i < 1095; i++) R11[i] = (char *(*)()) F1094_9683;}
	{long i; for (i = 1096; i < 1098; i++) R11[i] = (char *(*)()) F1097_9851;}
	R11[1101] = (char *(*)()) F1_8;
	R11[1102] = (char *(*)()) F1104_10053;
	{long i; for (i = 1103; i < 1106; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1107] = (char *(*)()) F1109_10203;
	{long i; for (i = 1109; i < 1113; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1113] = (char *(*)()) F1115_10501;
	R11[1114] = (char *(*)()) F1116_10538;
	R11[1115] = (char *(*)()) F1117_10538;
	R11[1116] = (char *(*)()) F1118_10538;
	R11[1117] = (char *(*)()) F1119_10538;
	R11[1118] = (char *(*)()) F1120_10538;
	R11[1119] = (char *(*)()) F1121_10538;
	R11[1120] = (char *(*)()) F1122_10538;
	R11[1121] = (char *(*)()) F1123_10538;
	R11[1122] = (char *(*)()) F1124_10538;
	R11[1123] = (char *(*)()) F1125_10538;
	R11[1124] = (char *(*)()) F1126_10538;
	R11[1125] = (char *(*)()) F1127_10538;
	R11[1126] = (char *(*)()) F1128_10538;
	R11[1127] = (char *(*)()) F1129_10538;
	R11[1128] = (char *(*)()) F1130_10538;
	R11[1129] = (char *(*)()) F1131_10538;
	R11[1130] = (char *(*)()) F1132_10538;
	R11[1131] = (char *(*)()) F1133_10538;
	R11[1132] = (char *(*)()) F1134_10538;
	R11[1133] = (char *(*)()) F1135_10538;
	R11[1134] = (char *(*)()) F1136_10538;
	R11[1135] = (char *(*)()) F1137_10538;
	R11[1136] = (char *(*)()) F1138_10538;
	R11[1137] = (char *(*)()) F1139_10538;
	R11[1138] = (char *(*)()) F1140_10538;
	R11[1139] = (char *(*)()) F1141_10538;
	R11[1140] = (char *(*)()) F1142_10538;
	R11[1141] = (char *(*)()) F1143_10538;
	R11[1142] = (char *(*)()) F1144_10538;
	R11[1143] = (char *(*)()) F1145_10538;
	R11[1144] = (char *(*)()) F1146_10538;
	R11[1145] = (char *(*)()) F1147_10538;
	R11[1146] = (char *(*)()) F1148_10538;
	R11[1147] = (char *(*)()) F1149_10538;
	{long i; for (i = 1149; i < 1161; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1164; i < 1167; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1168; i < 1171; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1218; i < 1220; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1220] = (char *(*)()) F1222_10905;
	R11[1221] = (char *(*)()) F1223_10937;
	{long i; for (i = 1224; i < 1226; i++) R11[i] = (char *(*)()) F1225_10962;}
	{long i; for (i = 1227; i < 1229; i++) R11[i] = (char *(*)()) F1228_11060;}
	{long i; for (i = 1230; i < 1232; i++) R11[i] = (char *(*)()) F1231_11159;}
	{long i; for (i = 1233; i < 1235; i++) R11[i] = (char *(*)()) F1234_11258;}
	{long i; for (i = 1236; i < 1238; i++) R11[i] = (char *(*)()) F1237_11357;}
	{long i; for (i = 1239; i < 1241; i++) R11[i] = (char *(*)()) F1240_11451;}
	{long i; for (i = 1242; i < 1244; i++) R11[i] = (char *(*)()) F1243_11545;}
	{long i; for (i = 1245; i < 1247; i++) R11[i] = (char *(*)()) F1246_11640;}
	{long i; for (i = 1248; i < 1250; i++) R11[i] = (char *(*)()) F1249_11739;}
	{long i; for (i = 1251; i < 1253; i++) R11[i] = (char *(*)()) F1252_11805;}
	{long i; for (i = 1253; i < 1255; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1255] = (char *(*)()) F1257_11918;
	R11[1256] = (char *(*)()) F1258_11929;
	{long i; for (i = 1257; i < 1265; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1265] = (char *(*)()) F1267_11975;
	R11[1266] = (char *(*)()) F1268_11975;
	R11[1267] = (char *(*)()) F1269_11975;
	{long i; for (i = 1268; i < 1270; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1278] = (char *(*)()) F1_8;
	R11[1283] = (char *(*)()) F1_8;
	{long i; for (i = 1292; i < 1294; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1295; i < 1298; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1312; i < 1314; i++) R11[i] = (char *(*)()) F1313_12911;}
	R11[1315] = (char *(*)()) F1_8;
	R11[1318] = (char *(*)()) F1_8;
	R11[1319] = (char *(*)()) F1321_13581;
	{long i; for (i = 1320; i < 1322; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1329] = (char *(*)()) F1_8;
	{long i; for (i = 1337; i < 1340; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1343] = (char *(*)()) F1_8;
	{long i; for (i = 1346; i < 1353; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1354] = (char *(*)()) F1_8;
	R11[1356] = (char *(*)()) F1_8;
	R11[1363] = (char *(*)()) F1_8;
	{long i; for (i = 1365; i < 1386; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1388; i < 1390; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1391; i < 1395; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1396; i < 1398; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1399; i < 1401; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1402] = (char *(*)()) F1_8;
	{long i; for (i = 1404; i < 1408; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1409; i < 1411; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1412; i < 1415; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1416; i < 1420; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1421; i < 1426; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1427] = (char *(*)()) F1_8;
	{long i; for (i = 1429; i < 1437; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1437; i < 1447; i++) R11[i] = (char *(*)()) F950_7867;}
	{long i; for (i = 1448; i < 1455; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1456; i < 1469; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1470; i < 1478; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1479; i < 1493; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1494; i < 1498; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1499; i < 1504; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1505; i < 1511; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1511; i < 1513; i++) R11[i] = (char *(*)()) F1513_18106;}
	{long i; for (i = 1513; i < 1517; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1518; i < 1529; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1530; i < 1534; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1535; i < 1544; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1544; i < 1546; i++) R11[i] = (char *(*)()) F1546_18384;}
	R11[1546] = (char *(*)()) F1_8;
	R11[1549] = (char *(*)()) F1551_18514;
}

char *(*R28[1550])();
void R28_init () {
	{long i; for (i = 0; i < 3; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 4; i < 9; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 10; i < 18; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 19; i < 25; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 26; i < 30; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 31; i < 34; i++) R28[i] = (char *(*)()) F1_25;}
	R28[35] = (char *(*)()) F1_25;
	{long i; for (i = 38; i < 40; i++) R28[i] = (char *(*)()) F1_25;}
	R28[42] = (char *(*)()) F1_25;
	R28[44] = (char *(*)()) F1_25;
	R28[46] = (char *(*)()) F1_25;
	R28[48] = (char *(*)()) F1_25;
	R28[50] = (char *(*)()) F1_25;
	{long i; for (i = 52; i < 56; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 57; i < 72; i++) R28[i] = (char *(*)()) F1_25;}
	R28[73] = (char *(*)()) F1_25;
	{long i; for (i = 76; i < 79; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 91; i < 94; i++) R28[i] = (char *(*)()) F1_25;}
	R28[104] = (char *(*)()) F1_25;
	R28[107] = (char *(*)()) F1_25;
	R28[112] = (char *(*)()) F1_25;
	R28[123] = (char *(*)()) F1_25;
	R28[127] = (char *(*)()) F1_25;
	R28[132] = (char *(*)()) F1_25;
	{long i; for (i = 141; i < 143; i++) R28[i] = (char *(*)()) F1_25;}
	R28[145] = (char *(*)()) F1_25;
	R28[150] = (char *(*)()) F1_25;
	R28[160] = (char *(*)()) F1_25;
	R28[167] = (char *(*)()) F1_25;
	R28[170] = (char *(*)()) F1_25;
	R28[172] = (char *(*)()) F1_25;
	R28[174] = (char *(*)()) F1_25;
	R28[178] = (char *(*)()) F1_25;
	R28[180] = (char *(*)()) F1_25;
	{long i; for (i = 185; i < 188; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 189; i < 201; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 206; i < 208; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 209; i < 211; i++) R28[i] = (char *(*)()) F1_25;}
	R28[215] = (char *(*)()) F1_25;
	R28[222] = (char *(*)()) F1_25;
	{long i; for (i = 224; i < 226; i++) R28[i] = (char *(*)()) F1_25;}
	R28[236] = (char *(*)()) F1_25;
	{long i; for (i = 243; i < 245; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 246; i < 248; i++) R28[i] = (char *(*)()) F1_25;}
	R28[253] = (char *(*)()) F1_25;
	{long i; for (i = 261; i < 265; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 266; i < 271; i++) R28[i] = (char *(*)()) F1_25;}
	R28[275] = (char *(*)()) F1_25;
	R28[280] = (char *(*)()) F1_25;
	R28[282] = (char *(*)()) F1_25;
	R28[287] = (char *(*)()) F1_25;
	R28[292] = (char *(*)()) F1_25;
	{long i; for (i = 294; i < 296; i++) R28[i] = (char *(*)()) F1_25;}
	R28[299] = (char *(*)()) F1_25;
	R28[304] = (char *(*)()) F1_25;
	{long i; for (i = 309; i < 314; i++) R28[i] = (char *(*)()) F1_25;}
	R28[315] = (char *(*)()) F1_25;
	R28[316] = (char *(*)()) F318_4912;
	R28[319] = (char *(*)()) F318_4912;
	{long i; for (i = 321; i < 327; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 328; i < 331; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 332; i < 334; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 336; i < 338; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 339; i < 342; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 343; i < 347; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 348; i < 350; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 351; i < 357; i++) R28[i] = (char *(*)()) F318_4912;}
	{long i; for (i = 358; i < 362; i++) R28[i] = (char *(*)()) F1_25;}
	R28[363] = (char *(*)()) F1_25;
	{long i; for (i = 370; i < 372; i++) R28[i] = (char *(*)()) F1_25;}
	R28[379] = (char *(*)()) F1_25;
	R28[387] = (char *(*)()) F1_25;
	R28[393] = (char *(*)()) F1_25;
	{long i; for (i = 401; i < 403; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 404; i < 411; i++) R28[i] = (char *(*)()) F1_25;}
	R28[425] = (char *(*)()) F1_25;
	R28[427] = (char *(*)()) F1_25;
	{long i; for (i = 429; i < 433; i++) R28[i] = (char *(*)()) F1_25;}
	R28[434] = (char *(*)()) F1_25;
	{long i; for (i = 436; i < 438; i++) R28[i] = (char *(*)()) F1_25;}
	R28[441] = (char *(*)()) F1_25;
	R28[443] = (char *(*)()) F1_25;
	R28[447] = (char *(*)()) F1_25;
	R28[450] = (char *(*)()) F452_6322;
	R28[451] = (char *(*)()) F1_25;
	{long i; for (i = 453; i < 455; i++) R28[i] = (char *(*)()) F1_25;}
	R28[456] = (char *(*)()) F1_25;
	R28[458] = (char *(*)()) F1_25;
	{long i; for (i = 471; i < 476; i++) R28[i] = (char *(*)()) F1_25;}
	R28[500] = (char *(*)()) F1_25;
	{long i; for (i = 526; i < 550; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 562; i < 600; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 753; i < 755; i++) R28[i] = (char *(*)()) F1_25;}
	R28[795] = (char *(*)()) F1_25;
	R28[831] = (char *(*)()) F1_25;
	{long i; for (i = 844; i < 852; i++) R28[i] = (char *(*)()) F1_25;}
	R28[852] = (char *(*)()) F854_7553;
	{long i; for (i = 853; i < 858; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 870; i < 883; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 938; i < 946; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 947; i < 961; i++) R28[i] = (char *(*)()) F1_25;}
	R28[962] = (char *(*)()) F1_25;
	{long i; for (i = 964; i < 968; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 969; i < 973; i++) R28[i] = (char *(*)()) F1_25;}
	R28[974] = (char *(*)()) F1_25;
	{long i; for (i = 976; i < 979; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 987; i < 996; i++) R28[i] = (char *(*)()) F982_8305;}
	R28[998] = (char *(*)()) F982_8305;
	{long i; for (i = 1000; i < 1003; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1005; i < 1007; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1014] = (char *(*)()) F1_25;
	{long i; for (i = 1021; i < 1029; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1038] = (char *(*)()) F1_25;
	{long i; for (i = 1040; i < 1042; i++) R28[i] = (char *(*)()) F1041_9318;}
	{long i; for (i = 1043; i < 1045; i++) R28[i] = (char *(*)()) F1044_9341;}
	{long i; for (i = 1046; i < 1048; i++) R28[i] = (char *(*)()) F1047_9381;}
	R28[1048] = (char *(*)()) F1_25;
	{long i; for (i = 1051; i < 1081; i++) R28[i] = (char *(*)()) F1052_9462;}
	R28[1081] = (char *(*)()) F1083_9475;
	R28[1082] = (char *(*)()) F1084_9475;
	{long i; for (i = 1084; i < 1089; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1093; i < 1095; i++) R28[i] = (char *(*)()) F1094_9703;}
	{long i; for (i = 1096; i < 1098; i++) R28[i] = (char *(*)()) F1097_9871;}
	{long i; for (i = 1101; i < 1106; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1107] = (char *(*)()) F1109_10216;
	R28[1109] = (char *(*)()) F1_25;
	R28[1110] = (char *(*)()) F1112_10307;
	{long i; for (i = 1111; i < 1113; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1113] = (char *(*)()) F1115_10505;
	R28[1114] = (char *(*)()) F1116_10546;
	R28[1115] = (char *(*)()) F1117_10546;
	R28[1116] = (char *(*)()) F1118_10546;
	R28[1117] = (char *(*)()) F1119_10546;
	R28[1118] = (char *(*)()) F1120_10546;
	R28[1119] = (char *(*)()) F1121_10546;
	R28[1120] = (char *(*)()) F1122_10546;
	R28[1121] = (char *(*)()) F1123_10546;
	R28[1122] = (char *(*)()) F1124_10546;
	R28[1123] = (char *(*)()) F1125_10546;
	R28[1124] = (char *(*)()) F1126_10546;
	R28[1125] = (char *(*)()) F1127_10546;
	R28[1126] = (char *(*)()) F1128_10546;
	R28[1127] = (char *(*)()) F1129_10546;
	R28[1128] = (char *(*)()) F1130_10546;
	R28[1129] = (char *(*)()) F1131_10546;
	R28[1130] = (char *(*)()) F1132_10546;
	R28[1131] = (char *(*)()) F1133_10546;
	R28[1132] = (char *(*)()) F1134_10546;
	R28[1133] = (char *(*)()) F1135_10546;
	R28[1134] = (char *(*)()) F1136_10546;
	R28[1135] = (char *(*)()) F1137_10546;
	R28[1136] = (char *(*)()) F1138_10546;
	R28[1137] = (char *(*)()) F1139_10546;
	R28[1138] = (char *(*)()) F1140_10546;
	R28[1139] = (char *(*)()) F1141_10546;
	R28[1140] = (char *(*)()) F1142_10546;
	R28[1141] = (char *(*)()) F1143_10546;
	R28[1142] = (char *(*)()) F1144_10546;
	R28[1143] = (char *(*)()) F1145_10546;
	R28[1144] = (char *(*)()) F1146_10546;
	R28[1145] = (char *(*)()) F1147_10546;
	R28[1146] = (char *(*)()) F1148_10546;
	R28[1147] = (char *(*)()) F1149_10546;
	{long i; for (i = 1149; i < 1161; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1164; i < 1167; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1168; i < 1171; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1218; i < 1222; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1224; i < 1226; i++) R28[i] = (char *(*)()) F1225_11021;}
	{long i; for (i = 1227; i < 1229; i++) R28[i] = (char *(*)()) F1228_11120;}
	{long i; for (i = 1230; i < 1232; i++) R28[i] = (char *(*)()) F1231_11219;}
	{long i; for (i = 1233; i < 1235; i++) R28[i] = (char *(*)()) F1234_11318;}
	{long i; for (i = 1236; i < 1238; i++) R28[i] = (char *(*)()) F1237_11414;}
	{long i; for (i = 1239; i < 1241; i++) R28[i] = (char *(*)()) F1240_11508;}
	{long i; for (i = 1242; i < 1244; i++) R28[i] = (char *(*)()) F1243_11603;}
	{long i; for (i = 1245; i < 1247; i++) R28[i] = (char *(*)()) F1246_11698;}
	R28[1248] = (char *(*)()) F1250_11791;
	R28[1249] = (char *(*)()) F1251_11791;
	R28[1251] = (char *(*)()) F1253_11857;
	R28[1252] = (char *(*)()) F1254_11857;
	{long i; for (i = 1253; i < 1270; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1278] = (char *(*)()) F1_25;
	R28[1283] = (char *(*)()) F1_25;
	{long i; for (i = 1292; i < 1294; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1295; i < 1298; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1312; i < 1314; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1315] = (char *(*)()) F1_25;
	{long i; for (i = 1318; i < 1322; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1329] = (char *(*)()) F1_25;
	{long i; for (i = 1337; i < 1340; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1343] = (char *(*)()) F1_25;
	{long i; for (i = 1346; i < 1353; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1354] = (char *(*)()) F1_25;
	R28[1356] = (char *(*)()) F1_25;
	R28[1363] = (char *(*)()) F1_25;
	{long i; for (i = 1365; i < 1386; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1388; i < 1390; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1391; i < 1395; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1396; i < 1398; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1399; i < 1401; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1402] = (char *(*)()) F1_25;
	{long i; for (i = 1404; i < 1408; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1409; i < 1411; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1412; i < 1415; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1416; i < 1420; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1421; i < 1426; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1427] = (char *(*)()) F1_25;
	{long i; for (i = 1429; i < 1447; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1448; i < 1455; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1456; i < 1469; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1470; i < 1478; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1479; i < 1493; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1494; i < 1498; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1499; i < 1504; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1505; i < 1517; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1518; i < 1529; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1530; i < 1534; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1535; i < 1547; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1549] = (char *(*)()) F1551_18559;
}

char *(*R836[5])();
void R836_init () {
	R836[0] = (char *(*)()) F60_836;
	R836[1] = (char *(*)()) F61_836;
	R836[2] = (char *(*)()) F62_836;
	R836[3] = (char *(*)()) F63_836;
	R836[4] = (char *(*)()) F64_836;
}

char *(*R841[5])();
void R841_init () {
	R841[0] = (char *(*)()) F60_841;
	R841[1] = (char *(*)()) F61_841_841_55;
	R841[2] = (char *(*)()) F62_841_841_55;
	R841[3] = (char *(*)()) F63_841_841_55;
	R841[4] = (char *(*)()) F64_841_841_55;
}
static void F61_841_841_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F61_841(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F62_841_841_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F62_841(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F63_841_841_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F63_841(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}
static void F64_841_841_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F64_841(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}

char *(*R844[5])();
void R844_init () {
	R844[0] = (char *(*)()) F60_844;
	R844[1] = (char *(*)()) F61_844;
	R844[2] = (char *(*)()) F62_844;
	R844[3] = (char *(*)()) F63_844;
	R844[4] = (char *(*)()) F64_844;
}

char *(*R1440[536])();
void R1440_init () {
	R1440[0] = (char *(*)()) F1016_8925;
	R1440[535] = (char *(*)()) F1551_18529;
}

char *(*R2149[2])();
void R2149_init () {
	R2149[0] = (char *(*)()) F1002_8375_2149_20;
	R2149[1] = (char *(*)()) F1003_8394_2149_20;
}
static EIF_REFERENCE F1002_8375_2149_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1002_8375(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1003_8394_2149_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1003_8394(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2150[2])();
void R2150_init () {
	R2150[0] = (char *(*)()) F1002_8379;
	R2150[1] = (char *(*)()) F1003_8402;
}

char *(*R2151[2])();
void R2151_init () {
	R2151[0] = (char *(*)()) F1002_8381_2151_156;
	R2151[1] = (char *(*)()) F1003_8406_2151_156;
}
static void F1002_8381_2151_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1002_8381(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1003_8406_2151_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1003_8406(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R2159[2])();
void R2159_init () {
	R2159[0] = (char *(*)()) F166_2200;
	R2159[1] = (char *(*)()) F1003_8395;
}

char *(*R2160[2])();
void R2160_init () {
	R2160[0] = (char *(*)()) F166_2201;
	R2160[1] = (char *(*)()) F1003_8396;
}

char *(*R2161[2])();
void R2161_init () {
	R2161[0] = (char *(*)()) F1002_8376;
	R2161[1] = (char *(*)()) F1003_8397;
}

char *(*R2162[2])();
void R2162_init () {
	R2162[0] = (char *(*)()) F1002_8377;
	R2162[1] = (char *(*)()) F1003_8398;
}

char *(*R2163[2])();
void R2163_init () {
	R2163[0] = (char *(*)()) F1002_8378;
	R2163[1] = (char *(*)()) F1003_8399;
}

char *(*R2166[2])();
void R2166_init () {
	R2166[0] = (char *(*)()) F1002_8380;
	R2166[1] = (char *(*)()) F166_2207;
}

char *(*R2167[2])();
void R2167_init () {
	R2167[0] = (char *(*)()) F166_2208;
	R2167[1] = (char *(*)()) F1003_8403;
}

char *(*R2168[2])();
void R2168_init () {
	R2168[0] = (char *(*)()) F1002_8382;
	R2168[1] = (char *(*)()) F1003_8408;
}

char *(*R2170[2])();
void R2170_init () {
	R2170[0] = (char *(*)()) F1002_8384;
	R2170[1] = (char *(*)()) F1003_8410;
}

char *(*R2172[2])();
void R2172_init () {
	R2172[0] = (char *(*)()) F1002_8385;
	R2172[1] = (char *(*)()) F1003_8413;
}

char *(*R2771[9])();
void R2771_init () {
	R2771[0] = (char *(*)()) F193_2834;
	R2771[1] = (char *(*)()) F194_2834_2771_1;
	R2771[2] = (char *(*)()) F195_2834_2771_1;
	R2771[3] = (char *(*)()) F196_2834_2771_1;
	R2771[4] = (char *(*)()) F197_2834_2771_1;
	R2771[5] = (char *(*)()) F193_2834;
	R2771[6] = (char *(*)()) F194_2834_2771_1;
	R2771[7] = (char *(*)()) F195_2834_2771_1;
	R2771[8] = (char *(*)()) F193_2834;
}
static EIF_REFERENCE F194_2834_2771_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F194_2834(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F195_2834_2771_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F195_2834(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F196_2834_2771_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F196_2834(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F197_2834_2771_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F197_2834(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R2772[9])();
void R2772_init () {
	R2772[0] = (char *(*)()) F193_2835;
	R2772[1] = (char *(*)()) F194_2835_2772_4;
	R2772[2] = (char *(*)()) F195_2835_2772_4;
	R2772[3] = (char *(*)()) F196_2835_2772_4;
	R2772[4] = (char *(*)()) F197_2835_2772_4;
	R2772[5] = (char *(*)()) F193_2835;
	R2772[6] = (char *(*)()) F194_2835_2772_4;
	R2772[7] = (char *(*)()) F195_2835_2772_4;
	R2772[8] = (char *(*)()) F193_2835;
}
static void F194_2835_2772_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F194_2835(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F195_2835_2772_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F195_2835(Current, *(EIF_BOOLEAN *)arg1);
}
static void F196_2835_2772_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F196_2835(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F197_2835_2772_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F197_2835(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R2776[4])();
void R2776_init () {
	R2776[0] = (char *(*)()) F198_2838;
	R2776[1] = (char *(*)()) F199_2838;
	R2776[2] = (char *(*)()) F200_2838;
	R2776[3] = (char *(*)()) F201_2841;
}

char *(*R2777[4])();
void R2777_init () {
	R2777[0] = (char *(*)()) F198_2839;
	R2777[1] = (char *(*)()) F199_2839;
	R2777[2] = (char *(*)()) F200_2839;
	R2777[3] = (char *(*)()) F201_2843;
}

char *(*R2883[2])();
void R2883_init () {
	R2883[0] = (char *(*)()) F211_2966;
	R2883[1] = (char *(*)()) F212_2987;
}

char *(*R3004[2])();
void R3004_init () {
	R3004[0] = (char *(*)()) F226_3130;
	R3004[1] = (char *(*)()) F227_3141;
}

char *(*R3011[2])();
void R3011_init () {
	R3011[0] = (char *(*)()) F226_3134;
	R3011[1] = (char *(*)()) F227_3143;
}

char *(*R3012[2])();
void R3012_init () {
	R3012[0] = (char *(*)()) F226_3135;
	R3012[1] = (char *(*)()) F227_3144;
}

char *(*R3042[9])();
void R3042_init () {
	R3042[0] = (char *(*)()) F238_3168;
	{long i; for (i = 7; i < 9; i++) R3042[i] = (char *(*)()) F244_3181;}
}

char *(*R3048[10])();
void R3048_init () {
	{long i; for (i = 0; i < 4; i++) R3048[i] = (char *(*)()) F240_3171;}
	{long i; for (i = 5; i < 10; i++) R3048[i] = (char *(*)()) F240_3171;}
}

char *(*R3051[2])();
void R3051_init () {
	R3051[0] = (char *(*)()) F245_3185;
	R3051[1] = (char *(*)()) F246_3187;
}

char *(*R3290[2])();
void R3290_init () {
	R3290[0] = (char *(*)()) F263_3434;
	R3290[1] = (char *(*)()) F264_3438;
}

char *(*R3292[2])();
void R3292_init () {
	R3292[0] = (char *(*)()) F263_3435;
	R3292[1] = (char *(*)()) F264_3439;
}

char *(*R3336[3])();
void R3336_init () {
	R3336[0] = (char *(*)()) F268_3493;
	R3336[1] = (char *(*)()) F269_3519;
	R3336[2] = (char *(*)()) F270_3543;
}

char *(*R3338[3])();
void R3338_init () {
	R3338[0] = (char *(*)()) F268_3494;
	R3338[1] = (char *(*)()) F269_3527;
	R3338[2] = (char *(*)()) F270_3539;
}

char *(*R3344[3])();
void R3344_init () {
	R3344[0] = (char *(*)()) F268_3496;
	R3344[1] = (char *(*)()) F269_3529;
	R3344[2] = (char *(*)()) F270_3548;
}

char *(*R3451[700])();
void R3451_init () {
	R3451[0] = (char *(*)()) F277_3653;
	R3451[19] = (char *(*)()) F296_4074;
	R3451[20] = (char *(*)()) F297_4094;
	R3451[699] = (char *(*)()) F397_5716;
}

char *(*R3452[700])();
void R3452_init () {
	R3452[0] = (char *(*)()) F277_3654;
	R3452[19] = (char *(*)()) F296_4075;
	R3452[20] = (char *(*)()) F297_4093;
	R3452[699] = (char *(*)()) F397_5717;
}

char *(*R3453[700])();
void R3453_init () {
	R3453[0] = (char *(*)()) F277_3655;
	{long i; for (i = 19; i < 21; i++) R3453[i] = (char *(*)()) F291_3942;}
	R3453[699] = (char *(*)()) F277_3655;
}

char *(*R3454[700])();
void R3454_init () {
	R3454[0] = (char *(*)()) F277_3656;
	{long i; for (i = 19; i < 21; i++) R3454[i] = (char *(*)()) F291_3943;}
	R3454[699] = (char *(*)()) F397_5715;
}

char *(*R3455[700])();
void R3455_init () {
	R3455[0] = (char *(*)()) F277_3657;
	{long i; for (i = 19; i < 21; i++) R3455[i] = (char *(*)()) F291_3944;}
	R3455[699] = (char *(*)()) F277_3657;
}

char *(*R3456[700])();
void R3456_init () {
	R3456[0] = (char *(*)()) F277_3658;
	{long i; for (i = 19; i < 21; i++) R3456[i] = (char *(*)()) F291_3945;}
	R3456[699] = (char *(*)()) F277_3658;
}

char *(*R3457[700])();
void R3457_init () {
	R3457[0] = (char *(*)()) F277_3659;
	R3457[19] = (char *(*)()) F296_4076;
	R3457[20] = (char *(*)()) F297_4097;
	R3457[699] = (char *(*)()) F976_8024;
}

char *(*R3458[700])();
void R3458_init () {
	R3458[0] = (char *(*)()) F277_3660;
	R3458[19] = (char *(*)()) F291_3947;
	R3458[20] = (char *(*)()) F297_4098;
	R3458[699] = (char *(*)()) F976_8025;
}

char *(*R3459[700])();
void R3459_init () {
	R3459[0] = (char *(*)()) F277_3661;
	R3459[19] = (char *(*)()) F291_3948;
	R3459[20] = (char *(*)()) F297_4099;
	R3459[699] = (char *(*)()) F976_8026;
}


#ifdef __cplusplus
}
#endif
