#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5856[694])();
void R5856_init () {
	{long i; for (i = 0; i < 2; i++) R5856[i] = (char *(*)()) F632_7216;}
	R5856[185] = (char *(*)()) F627_7216;
	R5856[186] = (char *(*)()) F632_7216;
	R5856[187] = (char *(*)()) F633_7216;
	{long i; for (i = 188; i < 191; i++) R5856[i] = (char *(*)()) F627_7216;}
	R5856[191] = (char *(*)()) F633_7216;
	R5856[192] = (char *(*)()) F632_7216;
	{long i; for (i = 194; i < 196; i++) R5856[i] = (char *(*)()) F627_7216;}
	R5856[196] = (char *(*)()) F628_7216;
	R5856[197] = (char *(*)()) F631_7216;
	R5856[198] = (char *(*)()) F632_7216;
	R5856[199] = (char *(*)()) F633_7216;
	R5856[200] = (char *(*)()) F634_7216;
	R5856[201] = (char *(*)()) F635_7216;
	R5856[202] = (char *(*)()) F636_7216;
	R5856[203] = (char *(*)()) F630_7216;
	R5856[204] = (char *(*)()) F637_7216;
	R5856[205] = (char *(*)()) F629_7216;
	R5856[206] = (char *(*)()) F638_7216;
	R5856[207] = (char *(*)()) F627_7216;
	R5856[209] = (char *(*)()) F627_7216;
	R5856[211] = (char *(*)()) F627_7216;
	R5856[212] = (char *(*)()) F632_7216;
	R5856[213] = (char *(*)()) F633_7216;
	R5856[214] = (char *(*)()) F627_7216;
	{long i; for (i = 216; i < 218; i++) R5856[i] = (char *(*)()) F627_7216;}
	{long i; for (i = 218; i < 220; i++) R5856[i] = (char *(*)()) F632_7216;}
	{long i; for (i = 252; i < 254; i++) R5856[i] = (char *(*)()) F629_7216;}
	R5856[515] = (char *(*)()) F629_7216;
	{long i; for (i = 684; i < 694; i++) R5856[i] = (char *(*)()) F627_7216;}
}

char *(*R5857[694])();
void R5857_init () {
	{long i; for (i = 0; i < 2; i++) R5857[i] = (char *(*)()) F754_7301;}
	R5857[185] = (char *(*)()) F940_7734;
	R5857[186] = (char *(*)()) F941_7734;
	R5857[187] = (char *(*)()) F942_7734;
	{long i; for (i = 188; i < 191; i++) R5857[i] = (char *(*)()) F940_7734;}
	R5857[191] = (char *(*)()) F942_7734;
	R5857[192] = (char *(*)()) F941_7734;
	R5857[194] = (char *(*)()) F940_7734;
	R5857[195] = (char *(*)()) F914_7703;
	R5857[196] = (char *(*)()) F915_7703;
	R5857[197] = (char *(*)()) F916_7703;
	R5857[198] = (char *(*)()) F917_7703;
	R5857[199] = (char *(*)()) F918_7703;
	R5857[200] = (char *(*)()) F919_7703;
	R5857[201] = (char *(*)()) F920_7703;
	R5857[202] = (char *(*)()) F921_7703;
	R5857[203] = (char *(*)()) F922_7703;
	R5857[204] = (char *(*)()) F923_7703;
	R5857[205] = (char *(*)()) F924_7703;
	R5857[206] = (char *(*)()) F925_7703;
	R5857[207] = (char *(*)()) F914_7703;
	R5857[209] = (char *(*)()) F914_7703;
	R5857[211] = (char *(*)()) F914_7703;
	R5857[212] = (char *(*)()) F917_7703;
	R5857[213] = (char *(*)()) F918_7703;
	R5857[214] = (char *(*)()) F914_7703;
	{long i; for (i = 216; i < 218; i++) R5857[i] = (char *(*)()) F914_7703;}
	{long i; for (i = 218; i < 220; i++) R5857[i] = (char *(*)()) F917_7703;}
	{long i; for (i = 252; i < 254; i++) R5857[i] = (char *(*)()) F1006_8582;}
	R5857[515] = (char *(*)()) F1006_8582;
	{long i; for (i = 684; i < 694; i++) R5857[i] = (char *(*)()) F914_7703;}
}

char *(*R5858[509])();
void R5858_init () {
	R5858[0] = (char *(*)()) F940_7743;
	R5858[1] = (char *(*)()) F941_7743;
	R5858[2] = (char *(*)()) F942_7743;
	{long i; for (i = 3; i < 6; i++) R5858[i] = (char *(*)()) F940_7743;}
	R5858[6] = (char *(*)()) F942_7743;
	R5858[7] = (char *(*)()) F941_7743;
	R5858[9] = (char *(*)()) F948_7820;
	R5858[10] = (char *(*)()) F950_7875;
	R5858[11] = (char *(*)()) F951_7875;
	R5858[12] = (char *(*)()) F952_7875;
	R5858[13] = (char *(*)()) F953_7875;
	R5858[14] = (char *(*)()) F954_7875;
	R5858[15] = (char *(*)()) F955_7875;
	R5858[16] = (char *(*)()) F956_7875;
	R5858[17] = (char *(*)()) F957_7875;
	R5858[18] = (char *(*)()) F958_7875;
	R5858[19] = (char *(*)()) F959_7875;
	R5858[20] = (char *(*)()) F960_7875;
	R5858[21] = (char *(*)()) F961_7875;
	R5858[22] = (char *(*)()) F950_7875;
	R5858[24] = (char *(*)()) F950_7875;
	R5858[26] = (char *(*)()) F950_7875;
	R5858[27] = (char *(*)()) F953_7875;
	R5858[28] = (char *(*)()) F954_7875;
	R5858[29] = (char *(*)()) F950_7875;
	{long i; for (i = 31; i < 33; i++) R5858[i] = (char *(*)()) F950_7875;}
	{long i; for (i = 33; i < 35; i++) R5858[i] = (char *(*)()) F953_7875;}
	{long i; for (i = 499; i < 509; i++) R5858[i] = (char *(*)()) F950_7875;}
}

char *(*R5859[694])();
void R5859_init () {
	{long i; for (i = 0; i < 2; i++) R5859[i] = (char *(*)()) F754_7307;}
	R5859[185] = (char *(*)()) F940_7744;
	R5859[186] = (char *(*)()) F941_7744;
	R5859[187] = (char *(*)()) F942_7744;
	{long i; for (i = 188; i < 191; i++) R5859[i] = (char *(*)()) F940_7744;}
	R5859[191] = (char *(*)()) F942_7744;
	R5859[192] = (char *(*)()) F941_7744;
	R5859[194] = (char *(*)()) F948_7818;
	R5859[195] = (char *(*)()) F950_7876;
	R5859[196] = (char *(*)()) F951_7876;
	R5859[197] = (char *(*)()) F952_7876;
	R5859[198] = (char *(*)()) F953_7876;
	R5859[199] = (char *(*)()) F954_7876;
	R5859[200] = (char *(*)()) F955_7876;
	R5859[201] = (char *(*)()) F956_7876;
	R5859[202] = (char *(*)()) F957_7876;
	R5859[203] = (char *(*)()) F958_7876;
	R5859[204] = (char *(*)()) F959_7876;
	R5859[205] = (char *(*)()) F960_7876;
	R5859[206] = (char *(*)()) F961_7876;
	R5859[207] = (char *(*)()) F950_7876;
	R5859[209] = (char *(*)()) F950_7876;
	R5859[211] = (char *(*)()) F950_7876;
	R5859[212] = (char *(*)()) F953_7876;
	R5859[213] = (char *(*)()) F954_7876;
	R5859[214] = (char *(*)()) F950_7876;
	{long i; for (i = 216; i < 218; i++) R5859[i] = (char *(*)()) F950_7876;}
	{long i; for (i = 218; i < 220; i++) R5859[i] = (char *(*)()) F953_7876;}
	{long i; for (i = 252; i < 254; i++) R5859[i] = (char *(*)()) F1006_8641;}
	R5859[515] = (char *(*)()) F1006_8641;
	{long i; for (i = 684; i < 694; i++) R5859[i] = (char *(*)()) F950_7876;}
}

char *(*R5860[509])();
void R5860_init () {
	R5860[0] = (char *(*)()) F940_7735;
	R5860[1] = (char *(*)()) F941_7735;
	R5860[2] = (char *(*)()) F942_7735;
	{long i; for (i = 3; i < 6; i++) R5860[i] = (char *(*)()) F940_7735;}
	R5860[6] = (char *(*)()) F942_7735;
	R5860[7] = (char *(*)()) F941_7735;
	R5860[9] = (char *(*)()) F940_7735;
	R5860[10] = (char *(*)()) F914_7704;
	R5860[11] = (char *(*)()) F915_7704;
	R5860[12] = (char *(*)()) F916_7704;
	R5860[13] = (char *(*)()) F917_7704;
	R5860[14] = (char *(*)()) F918_7704;
	R5860[15] = (char *(*)()) F919_7704;
	R5860[16] = (char *(*)()) F920_7704;
	R5860[17] = (char *(*)()) F921_7704;
	R5860[18] = (char *(*)()) F922_7704;
	R5860[19] = (char *(*)()) F923_7704;
	R5860[20] = (char *(*)()) F924_7704;
	R5860[21] = (char *(*)()) F925_7704;
	R5860[22] = (char *(*)()) F914_7704;
	R5860[24] = (char *(*)()) F914_7704;
	R5860[26] = (char *(*)()) F914_7704;
	R5860[27] = (char *(*)()) F917_7704;
	R5860[28] = (char *(*)()) F918_7704;
	R5860[29] = (char *(*)()) F914_7704;
	{long i; for (i = 31; i < 33; i++) R5860[i] = (char *(*)()) F914_7704;}
	{long i; for (i = 33; i < 35; i++) R5860[i] = (char *(*)()) F917_7704;}
	{long i; for (i = 67; i < 69; i++) R5860[i] = (char *(*)()) F1006_8583;}
	R5860[330] = (char *(*)()) F1006_8583;
	{long i; for (i = 499; i < 509; i++) R5860[i] = (char *(*)()) F914_7704;}
}

char *(*R5861[500])();
void R5861_init () {
	R5861[0] = (char *(*)()) F948_7819;
	R5861[1] = (char *(*)()) F950_7877;
	R5861[2] = (char *(*)()) F951_7877;
	R5861[3] = (char *(*)()) F952_7877;
	R5861[4] = (char *(*)()) F953_7877;
	R5861[5] = (char *(*)()) F954_7877;
	R5861[6] = (char *(*)()) F955_7877;
	R5861[7] = (char *(*)()) F956_7877;
	R5861[8] = (char *(*)()) F957_7877;
	R5861[9] = (char *(*)()) F958_7877;
	R5861[10] = (char *(*)()) F959_7877;
	R5861[11] = (char *(*)()) F960_7877;
	R5861[12] = (char *(*)()) F961_7877;
	R5861[13] = (char *(*)()) F950_7877;
	R5861[15] = (char *(*)()) F950_7877;
	R5861[17] = (char *(*)()) F950_7877;
	R5861[18] = (char *(*)()) F953_7877;
	R5861[19] = (char *(*)()) F954_7877;
	R5861[20] = (char *(*)()) F950_7877;
	{long i; for (i = 22; i < 24; i++) R5861[i] = (char *(*)()) F950_7877;}
	{long i; for (i = 24; i < 26; i++) R5861[i] = (char *(*)()) F953_7877;}
	{long i; for (i = 58; i < 60; i++) R5861[i] = (char *(*)()) F1006_8642;}
	R5861[321] = (char *(*)()) F1270_12027;
	{long i; for (i = 490; i < 500; i++) R5861[i] = (char *(*)()) F950_7877;}
}

char *(*R5862[797])();
void R5862_init () {
	{long i; for (i = 0; i < 2; i++) R5862[i] = (char *(*)()) F754_7302;}
	R5862[42] = (char *(*)()) F797_7380;
	R5862[91] = (char *(*)()) F846_7461;
	R5862[92] = (char *(*)()) F847_7461;
	R5862[93] = (char *(*)()) F848_7461;
	R5862[94] = (char *(*)()) F849_7461;
	R5862[95] = (char *(*)()) F850_7461;
	R5862[96] = (char *(*)()) F851_7461;
	R5862[97] = (char *(*)()) F852_7461;
	R5862[98] = (char *(*)()) F853_7461;
	{long i; for (i = 99; i < 101; i++) R5862[i] = (char *(*)()) F846_7461;}
	R5862[101] = (char *(*)()) F848_7461;
	R5862[102] = (char *(*)()) F852_7461;
	R5862[103] = (char *(*)()) F849_7461;
	R5862[104] = (char *(*)()) F853_7461;
	R5862[117] = (char *(*)()) F872_7581;
	R5862[118] = (char *(*)()) F873_7626;
	R5862[119] = (char *(*)()) F874_7626;
	R5862[120] = (char *(*)()) F875_7626;
	R5862[121] = (char *(*)()) F876_7626;
	R5862[122] = (char *(*)()) F877_7626;
	R5862[123] = (char *(*)()) F878_7626;
	R5862[124] = (char *(*)()) F879_7626;
	R5862[125] = (char *(*)()) F880_7626;
	R5862[126] = (char *(*)()) F881_7626;
	R5862[127] = (char *(*)()) F882_7626;
	R5862[128] = (char *(*)()) F883_7626;
	R5862[129] = (char *(*)()) F884_7626;
	R5862[185] = (char *(*)()) F902_7688;
	R5862[186] = (char *(*)()) F905_7688;
	R5862[187] = (char *(*)()) F906_7688;
	{long i; for (i = 188; i < 191; i++) R5862[i] = (char *(*)()) F902_7688;}
	R5862[191] = (char *(*)()) F906_7688;
	R5862[192] = (char *(*)()) F905_7688;
	{long i; for (i = 194; i < 196; i++) R5862[i] = (char *(*)()) F902_7688;}
	R5862[196] = (char *(*)()) F903_7688;
	R5862[197] = (char *(*)()) F904_7688;
	R5862[198] = (char *(*)()) F905_7688;
	R5862[199] = (char *(*)()) F906_7688;
	R5862[200] = (char *(*)()) F907_7688;
	R5862[201] = (char *(*)()) F908_7688;
	R5862[202] = (char *(*)()) F909_7688;
	R5862[203] = (char *(*)()) F910_7688;
	R5862[204] = (char *(*)()) F911_7688;
	R5862[205] = (char *(*)()) F912_7688;
	R5862[206] = (char *(*)()) F913_7688;
	R5862[207] = (char *(*)()) F902_7688;
	R5862[209] = (char *(*)()) F902_7688;
	R5862[211] = (char *(*)()) F902_7688;
	R5862[212] = (char *(*)()) F905_7688;
	R5862[213] = (char *(*)()) F906_7688;
	R5862[214] = (char *(*)()) F902_7688;
	{long i; for (i = 216; i < 218; i++) R5862[i] = (char *(*)()) F902_7688;}
	{long i; for (i = 218; i < 220; i++) R5862[i] = (char *(*)()) F905_7688;}
	{long i; for (i = 252; i < 254; i++) R5862[i] = (char *(*)()) F1006_8615;}
	R5862[341] = (char *(*)()) F1096_9746;
	R5862[344] = (char *(*)()) F1099_9911;
	R5862[515] = (char *(*)()) F1006_8615;
	{long i; for (i = 684; i < 694; i++) R5862[i] = (char *(*)()) F902_7688;}
	R5862[796] = (char *(*)()) F1099_9911;
}

char *(*R5866[797])();
void R5866_init () {
	{long i; for (i = 0; i < 2; i++) R5866[i] = (char *(*)()) F754_7309_5866_4;}
	R5866[42] = (char *(*)()) F797_7382;
	R5866[91] = (char *(*)()) F846_7545;
	R5866[92] = (char *(*)()) F847_7545;
	R5866[93] = (char *(*)()) F848_7545_5866_4;
	R5866[94] = (char *(*)()) F849_7545_5866_4;
	R5866[95] = (char *(*)()) F850_7545_5866_4;
	R5866[96] = (char *(*)()) F851_7545_5866_4;
	R5866[97] = (char *(*)()) F852_7545_5866_4;
	R5866[98] = (char *(*)()) F853_7545_5866_4;
	{long i; for (i = 99; i < 101; i++) R5866[i] = (char *(*)()) F846_7545;}
	R5866[101] = (char *(*)()) F848_7545_5866_4;
	R5866[102] = (char *(*)()) F852_7545_5866_4;
	R5866[103] = (char *(*)()) F849_7545_5866_4;
	R5866[104] = (char *(*)()) F853_7545_5866_4;
	R5866[117] = (char *(*)()) F872_7583_5866_4;
	R5866[118] = (char *(*)()) F873_7661;
	R5866[119] = (char *(*)()) F874_7661_5866_4;
	R5866[120] = (char *(*)()) F875_7661_5866_4;
	R5866[121] = (char *(*)()) F876_7661_5866_4;
	R5866[122] = (char *(*)()) F877_7661_5866_4;
	R5866[123] = (char *(*)()) F878_7661_5866_4;
	R5866[124] = (char *(*)()) F879_7661_5866_4;
	R5866[125] = (char *(*)()) F880_7661_5866_4;
	R5866[126] = (char *(*)()) F881_7661_5866_4;
	R5866[127] = (char *(*)()) F882_7661_5866_4;
	R5866[128] = (char *(*)()) F883_7661_5866_4;
	R5866[129] = (char *(*)()) F884_7661_5866_4;
	R5866[185] = (char *(*)()) F940_7750;
	R5866[186] = (char *(*)()) F941_7750_5866_4;
	R5866[187] = (char *(*)()) F942_7750_5866_4;
	R5866[188] = (char *(*)()) F943_7773;
	R5866[189] = (char *(*)()) F944_7790;
	R5866[190] = (char *(*)()) F945_7801;
	R5866[191] = (char *(*)()) F946_7801_5866_4;
	R5866[192] = (char *(*)()) F947_7801_5866_4;
	R5866[194] = (char *(*)()) F949_7838;
	R5866[195] = (char *(*)()) F950_7884;
	R5866[196] = (char *(*)()) F951_7884_5866_4;
	R5866[197] = (char *(*)()) F952_7884_5866_4;
	R5866[198] = (char *(*)()) F953_7884_5866_4;
	R5866[199] = (char *(*)()) F954_7884_5866_4;
	R5866[200] = (char *(*)()) F955_7884_5866_4;
	R5866[201] = (char *(*)()) F956_7884_5866_4;
	R5866[202] = (char *(*)()) F957_7884_5866_4;
	R5866[203] = (char *(*)()) F958_7884_5866_4;
	R5866[204] = (char *(*)()) F959_7884_5866_4;
	R5866[205] = (char *(*)()) F960_7884_5866_4;
	R5866[206] = (char *(*)()) F961_7884_5866_4;
	R5866[207] = (char *(*)()) F950_7884;
	R5866[209] = (char *(*)()) F964_7915;
	R5866[211] = (char *(*)()) F966_7929;
	R5866[212] = (char *(*)()) F967_7929_5866_4;
	R5866[213] = (char *(*)()) F968_7929_5866_4;
	R5866[214] = (char *(*)()) F950_7884;
	R5866[216] = (char *(*)()) F970_7955;
	R5866[217] = (char *(*)()) F950_7884;
	{long i; for (i = 218; i < 220; i++) R5866[i] = (char *(*)()) F953_7884_5866_4;}
	{long i; for (i = 252; i < 254; i++) R5866[i] = (char *(*)()) F1006_8648_5866_4;}
	R5866[341] = (char *(*)()) F1096_9788_5866_4;
	R5866[344] = (char *(*)()) F1099_9953_5866_4;
	R5866[515] = (char *(*)()) F1006_8648_5866_4;
	{long i; for (i = 684; i < 694; i++) R5866[i] = (char *(*)()) F950_7884;}
	R5866[796] = (char *(*)()) F1099_9953_5866_4;
}
static void F754_7309_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F754_7309(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F848_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F848_7545(Current, *(EIF_BOOLEAN *)arg1);
}
static void F849_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F849_7545(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F850_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_7545(Current, *(EIF_POINTER *)arg1);
}
static void F851_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_7545(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F852_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_7545(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F853_7545_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_7545(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F872_7583_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F872_7583(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F874_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F874_7661(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F875_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F875_7661(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F876_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F876_7661(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F877_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F877_7661(Current, *(EIF_BOOLEAN *)arg1);
}
static void F878_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F878_7661(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F879_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F879_7661(Current, *(EIF_POINTER *)arg1);
}
static void F880_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F880_7661(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F881_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F881_7661(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F882_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F882_7661(Current, *(EIF_REAL_64 *)arg1);
}
static void F883_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F883_7661(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F884_7661_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F884_7661(Current, *(EIF_REAL_32 *)arg1);
}
static void F941_7750_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F941_7750(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F942_7750_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F942_7750(Current, *(EIF_BOOLEAN *)arg1);
}
static void F946_7801_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F946_7801(Current, *(EIF_BOOLEAN *)arg1);
}
static void F947_7801_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_7801(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F951_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7884(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F952_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7884(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F953_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7884(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7884(Current, *(EIF_BOOLEAN *)arg1);
}
static void F955_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7884(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F956_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7884(Current, *(EIF_POINTER *)arg1);
}
static void F957_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7884(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F958_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7884(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F959_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7884(Current, *(EIF_REAL_64 *)arg1);
}
static void F960_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7884(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F961_7884_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F961_7884(Current, *(EIF_REAL_32 *)arg1);
}
static void F967_7929_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F967_7929(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F968_7929_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F968_7929(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1006_8648_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1006_8648(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1096_9788_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1096_9788(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1099_9953_5866_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1099_9953(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5867[797])();
void R5867_init () {
	{long i; for (i = 0; i < 2; i++) R5867[i] = (char *(*)()) F656_7235;}
	R5867[42] = (char *(*)()) F651_7235;
	{long i; for (i = 91; i < 93; i++) R5867[i] = (char *(*)()) F651_7235;}
	R5867[93] = (char *(*)()) F657_7235;
	R5867[94] = (char *(*)()) F656_7235;
	R5867[95] = (char *(*)()) F659_7235;
	R5867[96] = (char *(*)()) F656_7235;
	R5867[97] = (char *(*)()) F655_7235;
	R5867[98] = (char *(*)()) F652_7235;
	{long i; for (i = 99; i < 101; i++) R5867[i] = (char *(*)()) F651_7235;}
	R5867[101] = (char *(*)()) F657_7235;
	R5867[102] = (char *(*)()) F655_7235;
	R5867[103] = (char *(*)()) F656_7235;
	R5867[104] = (char *(*)()) F652_7235;
	R5867[117] = (char *(*)()) F656_7235;
	R5867[118] = (char *(*)()) F651_7235;
	R5867[119] = (char *(*)()) F652_7235;
	R5867[120] = (char *(*)()) F655_7235;
	R5867[121] = (char *(*)()) F656_7235;
	R5867[122] = (char *(*)()) F657_7235;
	R5867[123] = (char *(*)()) F658_7235;
	R5867[124] = (char *(*)()) F659_7235;
	R5867[125] = (char *(*)()) F660_7235;
	R5867[126] = (char *(*)()) F654_7235;
	R5867[127] = (char *(*)()) F661_7235;
	R5867[128] = (char *(*)()) F653_7235;
	R5867[129] = (char *(*)()) F662_7235;
	R5867[188] = (char *(*)()) F651_7235;
	R5867[190] = (char *(*)()) F798_7405;
	R5867[191] = (char *(*)()) F800_7405;
	R5867[192] = (char *(*)()) F799_7405;
	R5867[211] = (char *(*)()) F798_7405;
	R5867[212] = (char *(*)()) F799_7405;
	R5867[213] = (char *(*)()) F800_7405;
	{long i; for (i = 252; i < 254; i++) R5867[i] = (char *(*)()) F653_7235;}
	R5867[341] = (char *(*)()) F654_7235;
	R5867[344] = (char *(*)()) F653_7235;
	R5867[515] = (char *(*)()) F653_7235;
	R5867[796] = (char *(*)()) F653_7235;
}

char *(*R5870[755])();
void R5870_init () {
	R5870[0] = (char *(*)()) F797_7390;
	R5870[49] = (char *(*)()) F846_7488;
	R5870[50] = (char *(*)()) F847_7488;
	R5870[51] = (char *(*)()) F848_7488;
	R5870[52] = (char *(*)()) F849_7488;
	R5870[53] = (char *(*)()) F850_7488;
	R5870[54] = (char *(*)()) F851_7488;
	R5870[55] = (char *(*)()) F852_7488;
	R5870[56] = (char *(*)()) F853_7488;
	{long i; for (i = 57; i < 59; i++) R5870[i] = (char *(*)()) F846_7488;}
	R5870[59] = (char *(*)()) F848_7488;
	R5870[60] = (char *(*)()) F852_7488;
	R5870[61] = (char *(*)()) F849_7488;
	R5870[62] = (char *(*)()) F853_7488;
	R5870[143] = (char *(*)()) F940_7759;
	R5870[144] = (char *(*)()) F941_7759;
	R5870[145] = (char *(*)()) F942_7759;
	{long i; for (i = 146; i < 149; i++) R5870[i] = (char *(*)()) F940_7759;}
	R5870[149] = (char *(*)()) F942_7759;
	R5870[150] = (char *(*)()) F941_7759;
	R5870[152] = (char *(*)()) F948_7831;
	R5870[153] = (char *(*)()) F950_7902;
	R5870[154] = (char *(*)()) F951_7902;
	R5870[155] = (char *(*)()) F952_7902;
	R5870[156] = (char *(*)()) F953_7902;
	R5870[157] = (char *(*)()) F954_7902;
	R5870[158] = (char *(*)()) F955_7902;
	R5870[159] = (char *(*)()) F956_7902;
	R5870[160] = (char *(*)()) F957_7902;
	R5870[161] = (char *(*)()) F958_7902;
	R5870[162] = (char *(*)()) F959_7902;
	R5870[163] = (char *(*)()) F960_7902;
	R5870[164] = (char *(*)()) F961_7902;
	R5870[165] = (char *(*)()) F950_7902;
	R5870[167] = (char *(*)()) F950_7902;
	R5870[169] = (char *(*)()) F950_7902;
	R5870[170] = (char *(*)()) F953_7902;
	R5870[171] = (char *(*)()) F954_7902;
	R5870[172] = (char *(*)()) F950_7902;
	R5870[174] = (char *(*)()) F970_7967;
	R5870[175] = (char *(*)()) F950_7902;
	{long i; for (i = 176; i < 178; i++) R5870[i] = (char *(*)()) F953_7902;}
	R5870[299] = (char *(*)()) F1096_9803;
	R5870[302] = (char *(*)()) F1099_9968;
	{long i; for (i = 642; i < 652; i++) R5870[i] = (char *(*)()) F950_7902;}
	R5870[754] = (char *(*)()) F1551_18597;
}

char *(*R5872[680])();
void R5872_init () {
	R5872[0] = (char *(*)()) F872_7571_5872_5;
	R5872[1] = (char *(*)()) F873_7610_5872_5;
	R5872[2] = (char *(*)()) F874_7610_5872_5;
	R5872[3] = (char *(*)()) F875_7610_5872_5;
	R5872[4] = (char *(*)()) F876_7610_5872_5;
	R5872[5] = (char *(*)()) F877_7610_5872_5;
	R5872[6] = (char *(*)()) F878_7610_5872_5;
	R5872[7] = (char *(*)()) F879_7610_5872_5;
	R5872[8] = (char *(*)()) F880_7610_5872_5;
	R5872[9] = (char *(*)()) F881_7610_5872_5;
	R5872[10] = (char *(*)()) F882_7610_5872_5;
	R5872[11] = (char *(*)()) F883_7610_5872_5;
	R5872[12] = (char *(*)()) F884_7610_5872_5;
	R5872[68] = (char *(*)()) F890_7668_5872_5;
	R5872[69] = (char *(*)()) F893_7668_5872_5;
	R5872[70] = (char *(*)()) F894_7668_5872_5;
	{long i; for (i = 71; i < 74; i++) R5872[i] = (char *(*)()) F890_7668_5872_5;}
	R5872[74] = (char *(*)()) F894_7668_5872_5;
	R5872[75] = (char *(*)()) F893_7668_5872_5;
	R5872[77] = (char *(*)()) F890_7668_5872_5;
	R5872[78] = (char *(*)()) F950_7849_5872_5;
	R5872[79] = (char *(*)()) F951_7849_5872_5;
	R5872[80] = (char *(*)()) F952_7849_5872_5;
	R5872[81] = (char *(*)()) F953_7849_5872_5;
	R5872[82] = (char *(*)()) F954_7849_5872_5;
	R5872[83] = (char *(*)()) F955_7849_5872_5;
	R5872[84] = (char *(*)()) F956_7849_5872_5;
	R5872[85] = (char *(*)()) F957_7849_5872_5;
	R5872[86] = (char *(*)()) F958_7849_5872_5;
	R5872[87] = (char *(*)()) F959_7849_5872_5;
	R5872[88] = (char *(*)()) F960_7849_5872_5;
	R5872[89] = (char *(*)()) F961_7849_5872_5;
	R5872[90] = (char *(*)()) F950_7849_5872_5;
	R5872[92] = (char *(*)()) F950_7849_5872_5;
	R5872[94] = (char *(*)()) F950_7849_5872_5;
	R5872[95] = (char *(*)()) F953_7849_5872_5;
	R5872[96] = (char *(*)()) F954_7849_5872_5;
	R5872[97] = (char *(*)()) F950_7849_5872_5;
	{long i; for (i = 99; i < 101; i++) R5872[i] = (char *(*)()) F950_7849_5872_5;}
	{long i; for (i = 101; i < 103; i++) R5872[i] = (char *(*)()) F953_7849_5872_5;}
	R5872[224] = (char *(*)()) F1096_9741_5872_5;
	R5872[227] = (char *(*)()) F1099_9905_5872_5;
	{long i; for (i = 567; i < 577; i++) R5872[i] = (char *(*)()) F950_7849_5872_5;}
	R5872[679] = (char *(*)()) F1551_18488_5872_5;
}
static EIF_REFERENCE F872_7571_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F872_7571(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F873_7610(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F874_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F874_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F875_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F876_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F876_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F877_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F877_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F878_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F878_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F879_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F879_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F880_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F880_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F881_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F882_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_7610_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F884_7610(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_7668_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F890_7668(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F893_7668_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F893_7668(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_7668_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F894_7668(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F950_7849(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F951_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F951_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F952_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F953_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F954_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F955_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F956_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F957_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F958_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F959_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F960_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7849_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F961_7849(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1096_9741_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1096_9741(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_9905_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1099_9905(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1551_18488_5872_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1551_18488(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5875[706])();
void R5875_init () {
	R5875[0] = (char *(*)()) F846_7480;
	R5875[1] = (char *(*)()) F847_7480_5875_9;
	R5875[2] = (char *(*)()) F848_7480_5875_9;
	R5875[3] = (char *(*)()) F849_7480_5875_9;
	R5875[4] = (char *(*)()) F850_7480_5875_9;
	R5875[5] = (char *(*)()) F851_7480_5875_9;
	R5875[6] = (char *(*)()) F852_7480_5875_9;
	R5875[7] = (char *(*)()) F853_7480_5875_9;
	{long i; for (i = 8; i < 10; i++) R5875[i] = (char *(*)()) F846_7480;}
	R5875[10] = (char *(*)()) F848_7480_5875_9;
	R5875[11] = (char *(*)()) F852_7480_5875_9;
	R5875[12] = (char *(*)()) F849_7480_5875_9;
	R5875[13] = (char *(*)()) F853_7480_5875_9;
	R5875[26] = (char *(*)()) F872_7601_5875_9;
	R5875[27] = (char *(*)()) F873_7629_5875_9;
	R5875[28] = (char *(*)()) F874_7629_5875_9;
	R5875[29] = (char *(*)()) F875_7629_5875_9;
	R5875[30] = (char *(*)()) F876_7629_5875_9;
	R5875[31] = (char *(*)()) F877_7629_5875_9;
	R5875[32] = (char *(*)()) F878_7629_5875_9;
	R5875[33] = (char *(*)()) F879_7629_5875_9;
	R5875[34] = (char *(*)()) F880_7629_5875_9;
	R5875[35] = (char *(*)()) F881_7629_5875_9;
	R5875[36] = (char *(*)()) F882_7629_5875_9;
	R5875[37] = (char *(*)()) F883_7629_5875_9;
	R5875[38] = (char *(*)()) F884_7629_5875_9;
	R5875[94] = (char *(*)()) F890_7682_5875_9;
	R5875[95] = (char *(*)()) F893_7682_5875_9;
	R5875[96] = (char *(*)()) F894_7682_5875_9;
	{long i; for (i = 97; i < 100; i++) R5875[i] = (char *(*)()) F890_7682_5875_9;}
	R5875[100] = (char *(*)()) F894_7682_5875_9;
	R5875[101] = (char *(*)()) F893_7682_5875_9;
	R5875[103] = (char *(*)()) F890_7682_5875_9;
	R5875[104] = (char *(*)()) F950_7882_5875_9;
	R5875[105] = (char *(*)()) F951_7882_5875_9;
	R5875[106] = (char *(*)()) F952_7882_5875_9;
	R5875[107] = (char *(*)()) F953_7882_5875_9;
	R5875[108] = (char *(*)()) F954_7882_5875_9;
	R5875[109] = (char *(*)()) F955_7882_5875_9;
	R5875[110] = (char *(*)()) F956_7882_5875_9;
	R5875[111] = (char *(*)()) F957_7882_5875_9;
	R5875[112] = (char *(*)()) F958_7882_5875_9;
	R5875[113] = (char *(*)()) F959_7882_5875_9;
	R5875[114] = (char *(*)()) F960_7882_5875_9;
	R5875[115] = (char *(*)()) F961_7882_5875_9;
	R5875[116] = (char *(*)()) F950_7882_5875_9;
	R5875[118] = (char *(*)()) F950_7882_5875_9;
	R5875[120] = (char *(*)()) F950_7882_5875_9;
	R5875[121] = (char *(*)()) F953_7882_5875_9;
	R5875[122] = (char *(*)()) F954_7882_5875_9;
	R5875[123] = (char *(*)()) F950_7882_5875_9;
	R5875[125] = (char *(*)()) F970_7959_5875_9;
	R5875[126] = (char *(*)()) F950_7882_5875_9;
	{long i; for (i = 127; i < 129; i++) R5875[i] = (char *(*)()) F953_7882_5875_9;}
	R5875[250] = (char *(*)()) F1096_9761_5875_9;
	R5875[253] = (char *(*)()) F1099_9926_5875_9;
	{long i; for (i = 593; i < 603; i++) R5875[i] = (char *(*)()) F950_7882_5875_9;}
	R5875[705] = (char *(*)()) F1551_18523_5875_9;
}
static void F847_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F847_7480(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F848_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F848_7480(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F849_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F849_7480(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F850_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F850_7480(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F851_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F851_7480(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F852_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F852_7480(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F853_7480_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_7480(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F872_7601_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F872_7601(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F873_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F873_7629(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F874_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F874_7629(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F875_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F875_7629(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F876_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F876_7629(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F877_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F877_7629(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F878_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F878_7629(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F879_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F879_7629(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F880_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F880_7629(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F881_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F881_7629(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F882_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F882_7629(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F883_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F883_7629(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F884_7629_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F884_7629(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F890_7682_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F890_7682(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_7682_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_7682(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_7682_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_7682(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F950_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F950_7882(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F951_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F951_7882(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F952_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F952_7882(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F953_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F953_7882(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F954_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F954_7882(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F955_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F955_7882(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F956_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F956_7882(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F957_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F957_7882(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F958_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F958_7882(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F959_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F959_7882(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F960_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F960_7882(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F961_7882_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F961_7882(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F970_7959_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F970_7959(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1096_9761_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1096_9761(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1099_9926_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1099_9926(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1551_18523_5875_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1551_18523(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5876[706])();
void R5876_init () {
	R5876[0] = (char *(*)()) F846_7481;
	R5876[1] = (char *(*)()) F847_7481_5876_9;
	R5876[2] = (char *(*)()) F848_7481_5876_9;
	R5876[3] = (char *(*)()) F849_7481_5876_9;
	R5876[4] = (char *(*)()) F850_7481_5876_9;
	R5876[5] = (char *(*)()) F851_7481_5876_9;
	R5876[6] = (char *(*)()) F852_7481_5876_9;
	R5876[7] = (char *(*)()) F853_7481_5876_9;
	{long i; for (i = 8; i < 10; i++) R5876[i] = (char *(*)()) F846_7481;}
	R5876[10] = (char *(*)()) F848_7481_5876_9;
	R5876[11] = (char *(*)()) F852_7481_5876_9;
	R5876[12] = (char *(*)()) F849_7481_5876_9;
	R5876[13] = (char *(*)()) F853_7481_5876_9;
	R5876[26] = (char *(*)()) F872_7601_5876_9;
	R5876[27] = (char *(*)()) F873_7629_5876_9;
	R5876[28] = (char *(*)()) F874_7629_5876_9;
	R5876[29] = (char *(*)()) F875_7629_5876_9;
	R5876[30] = (char *(*)()) F876_7629_5876_9;
	R5876[31] = (char *(*)()) F877_7629_5876_9;
	R5876[32] = (char *(*)()) F878_7629_5876_9;
	R5876[33] = (char *(*)()) F879_7629_5876_9;
	R5876[34] = (char *(*)()) F880_7629_5876_9;
	R5876[35] = (char *(*)()) F881_7629_5876_9;
	R5876[36] = (char *(*)()) F882_7629_5876_9;
	R5876[37] = (char *(*)()) F883_7629_5876_9;
	R5876[38] = (char *(*)()) F884_7629_5876_9;
	R5876[94] = (char *(*)()) F890_7682_5876_9;
	R5876[95] = (char *(*)()) F893_7682_5876_9;
	R5876[96] = (char *(*)()) F894_7682_5876_9;
	{long i; for (i = 97; i < 100; i++) R5876[i] = (char *(*)()) F890_7682_5876_9;}
	R5876[100] = (char *(*)()) F894_7682_5876_9;
	R5876[101] = (char *(*)()) F893_7682_5876_9;
	R5876[103] = (char *(*)()) F890_7682_5876_9;
	R5876[104] = (char *(*)()) F950_7882_5876_9;
	R5876[105] = (char *(*)()) F951_7882_5876_9;
	R5876[106] = (char *(*)()) F952_7882_5876_9;
	R5876[107] = (char *(*)()) F953_7882_5876_9;
	R5876[108] = (char *(*)()) F954_7882_5876_9;
	R5876[109] = (char *(*)()) F955_7882_5876_9;
	R5876[110] = (char *(*)()) F956_7882_5876_9;
	R5876[111] = (char *(*)()) F957_7882_5876_9;
	R5876[112] = (char *(*)()) F958_7882_5876_9;
	R5876[113] = (char *(*)()) F959_7882_5876_9;
	R5876[114] = (char *(*)()) F960_7882_5876_9;
	R5876[115] = (char *(*)()) F961_7882_5876_9;
	R5876[116] = (char *(*)()) F950_7882_5876_9;
	R5876[118] = (char *(*)()) F950_7882_5876_9;
	R5876[120] = (char *(*)()) F950_7882_5876_9;
	R5876[121] = (char *(*)()) F953_7882_5876_9;
	R5876[122] = (char *(*)()) F954_7882_5876_9;
	R5876[123] = (char *(*)()) F950_7882_5876_9;
	R5876[125] = (char *(*)()) F970_7959_5876_9;
	R5876[126] = (char *(*)()) F950_7882_5876_9;
	{long i; for (i = 127; i < 129; i++) R5876[i] = (char *(*)()) F953_7882_5876_9;}
	R5876[250] = (char *(*)()) F1096_9761_5876_9;
	R5876[253] = (char *(*)()) F1099_9926_5876_9;
	{long i; for (i = 593; i < 603; i++) R5876[i] = (char *(*)()) F950_7882_5876_9;}
	R5876[705] = (char *(*)()) F1551_18523_5876_9;
}
static void F847_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F847_7481(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F848_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F848_7481(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F849_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F849_7481(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F850_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F850_7481(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F851_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F851_7481(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F852_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F852_7481(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F853_7481_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_7481(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F872_7601_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F872_7601(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F873_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F873_7629(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F874_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F874_7629(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F875_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F875_7629(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F876_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F876_7629(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F877_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F877_7629(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F878_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F878_7629(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F879_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F879_7629(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F880_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F880_7629(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F881_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F881_7629(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F882_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F882_7629(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F883_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F883_7629(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F884_7629_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F884_7629(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F890_7682_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F890_7682(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_7682_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_7682(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_7682_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_7682(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F950_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F950_7882(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F951_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F951_7882(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F952_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F952_7882(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F953_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F953_7882(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F954_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F954_7882(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F955_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F955_7882(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F956_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F956_7882(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F957_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F957_7882(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F958_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F958_7882(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F959_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F959_7882(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F960_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F960_7882(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F961_7882_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F961_7882(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F970_7959_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F970_7959(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1096_9761_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1096_9761(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1099_9926_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1099_9926(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1551_18523_5876_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1551_18523(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y5877_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype44[] = {0xFF01,1098,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype45[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype46[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype47[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype48[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype49[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype50[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype51[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype52[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype53[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype54[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype55[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype56[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype57[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype58[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype59[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype60[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype61[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype62[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype63[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype64[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype65[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype66[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype67[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype68[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype69[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype70[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype71[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype72[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype73[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype74[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype75[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype76[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype77[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype78[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype79[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype80[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype81[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype82[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype83[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype84[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype85[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype86[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype87[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype88[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype89[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype90[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype91[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype92[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype93[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype94[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype95[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype96[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype97[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype98[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype99[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype100[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype101[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype102[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype103[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype104[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype105[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype106[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype107[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype108[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype109[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype110[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype111[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype112[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype113[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype114[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype115[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype116[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype117[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype118[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype119[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype120[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype121[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype122[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype123[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype124[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype125[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype126[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype127[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype128[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype129[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype130[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype131[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype132[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype133[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype134[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype135[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype136[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype137[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype138[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype139[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype140[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype141[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype142[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype143[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype144[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype145[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype146[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype147[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype148[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype149[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype150[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype151[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype152[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype153[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype154[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype155[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype156[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype157[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype158[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype159[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype160[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype161[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype162[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype163[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype164[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype165[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype166[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype167[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype168[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype169[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype170[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype171[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype172[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype173[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype174[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype175[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype176[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype177[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype178[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype179[] = {1229,0xFFFF};
EIF_TYPE_INDEX *Y5877_gen_type [878];
EIF_TYPE_INDEX Y5877 [878];
void Y5877_init (void)
{
	egc_routines_types [5877] = Y5877;
	egc_routines_gen_types [5877] = Y5877_gen_type;
	egc_routines_offset [5877] = 674;
	Y5877_gen_type [0] = Y5877_pgtype0;
	Y5877_gen_type [1] = Y5877_pgtype1;
	Y5877_gen_type [2] = Y5877_pgtype2;
	Y5877_gen_type [3] = Y5877_pgtype3;
	Y5877_gen_type [4] = Y5877_pgtype4;
	Y5877_gen_type [5] = Y5877_pgtype5;
	Y5877_gen_type [6] = Y5877_pgtype6;
	Y5877_gen_type [7] = Y5877_pgtype7;
	Y5877_gen_type [8] = Y5877_pgtype8;
	Y5877_gen_type [9] = Y5877_pgtype9;
	Y5877_gen_type [10] = Y5877_pgtype10;
	Y5877_gen_type [11] = Y5877_pgtype11;
	Y5877_gen_type [12] = Y5877_pgtype12;
	Y5877_gen_type [13] = Y5877_pgtype13;
	Y5877_gen_type [14] = Y5877_pgtype14;
	Y5877_gen_type [15] = Y5877_pgtype15;
	Y5877_gen_type [16] = Y5877_pgtype16;
	Y5877_gen_type [17] = Y5877_pgtype17;
	Y5877_gen_type [18] = Y5877_pgtype18;
	Y5877_gen_type [19] = Y5877_pgtype19;
	Y5877_gen_type [20] = Y5877_pgtype20;
	Y5877_gen_type [21] = Y5877_pgtype21;
	Y5877_gen_type [22] = Y5877_pgtype22;
	Y5877_gen_type [23] = Y5877_pgtype23;
	Y5877_gen_type [24] = Y5877_pgtype24;
	Y5877_gen_type [25] = Y5877_pgtype25;
	Y5877_gen_type [26] = Y5877_pgtype26;
	Y5877_gen_type [27] = Y5877_pgtype27;
	Y5877_gen_type [28] = Y5877_pgtype28;
	Y5877_gen_type [29] = Y5877_pgtype29;
	Y5877_gen_type [30] = Y5877_pgtype30;
	Y5877_gen_type [31] = Y5877_pgtype31;
	Y5877_gen_type [32] = Y5877_pgtype32;
	Y5877_gen_type [33] = Y5877_pgtype33;
	Y5877_gen_type [34] = Y5877_pgtype34;
	Y5877_gen_type [35] = Y5877_pgtype35;
	Y5877_gen_type [171] = Y5877_pgtype36;
	Y5877_gen_type [172] = Y5877_pgtype37;
	Y5877_gen_type [173] = Y5877_pgtype38;
	Y5877_gen_type [174] = Y5877_pgtype39;
	Y5877_gen_type [175] = Y5877_pgtype40;
	Y5877_gen_type [176] = Y5877_pgtype41;
	Y5877_gen_type [177] = Y5877_pgtype42;
	Y5877_gen_type [178] = Y5877_pgtype43;
	Y5877_gen_type [179] = Y5877_pgtype44;
	Y5877_gen_type [180] = Y5877_pgtype45;
	Y5877_gen_type [181] = Y5877_pgtype46;
	Y5877_gen_type [182] = Y5877_pgtype47;
	Y5877_gen_type [183] = Y5877_pgtype48;
	Y5877_gen_type [184] = Y5877_pgtype49;
	Y5877_gen_type [185] = Y5877_pgtype50;
	Y5877_gen_type [186] = Y5877_pgtype51;
	Y5877_gen_type [187] = Y5877_pgtype52;
	Y5877_gen_type [188] = Y5877_pgtype53;
	Y5877_gen_type [189] = Y5877_pgtype54;
	Y5877_gen_type [190] = Y5877_pgtype55;
	Y5877_gen_type [191] = Y5877_pgtype56;
	Y5877_gen_type [192] = Y5877_pgtype57;
	Y5877_gen_type [193] = Y5877_pgtype58;
	Y5877_gen_type [194] = Y5877_pgtype59;
	Y5877_gen_type [195] = Y5877_pgtype60;
	Y5877_gen_type [196] = Y5877_pgtype61;
	Y5877_gen_type [197] = Y5877_pgtype62;
	Y5877_gen_type [198] = Y5877_pgtype63;
	Y5877_gen_type [199] = Y5877_pgtype64;
	Y5877_gen_type [200] = Y5877_pgtype65;
	Y5877_gen_type [201] = Y5877_pgtype66;
	Y5877_gen_type [202] = Y5877_pgtype67;
	Y5877_gen_type [203] = Y5877_pgtype68;
	Y5877_gen_type [204] = Y5877_pgtype69;
	Y5877_gen_type [205] = Y5877_pgtype70;
	Y5877_gen_type [206] = Y5877_pgtype71;
	Y5877_gen_type [207] = Y5877_pgtype72;
	Y5877_gen_type [208] = Y5877_pgtype73;
	Y5877_gen_type [209] = Y5877_pgtype74;
	Y5877_gen_type [210] = Y5877_pgtype75;
	Y5877_gen_type [211] = Y5877_pgtype76;
	Y5877_gen_type [212] = Y5877_pgtype77;
	Y5877_gen_type [213] = Y5877_pgtype78;
	Y5877_gen_type [214] = Y5877_pgtype79;
	Y5877_gen_type [215] = Y5877_pgtype80;
	Y5877_gen_type [216] = Y5877_pgtype81;
	Y5877_gen_type [217] = Y5877_pgtype82;
	Y5877_gen_type [218] = Y5877_pgtype83;
	Y5877_gen_type [219] = Y5877_pgtype84;
	Y5877_gen_type [220] = Y5877_pgtype85;
	Y5877_gen_type [221] = Y5877_pgtype86;
	Y5877_gen_type [222] = Y5877_pgtype87;
	Y5877_gen_type [223] = Y5877_pgtype88;
	Y5877_gen_type [224] = Y5877_pgtype89;
	Y5877_gen_type [225] = Y5877_pgtype90;
	Y5877_gen_type [226] = Y5877_pgtype91;
	Y5877_gen_type [227] = Y5877_pgtype92;
	Y5877_gen_type [228] = Y5877_pgtype93;
	Y5877_gen_type [229] = Y5877_pgtype94;
	Y5877_gen_type [230] = Y5877_pgtype95;
	Y5877_gen_type [231] = Y5877_pgtype96;
	Y5877_gen_type [232] = Y5877_pgtype97;
	Y5877_gen_type [233] = Y5877_pgtype98;
	Y5877_gen_type [234] = Y5877_pgtype99;
	Y5877_gen_type [235] = Y5877_pgtype100;
	Y5877_gen_type [236] = Y5877_pgtype101;
	Y5877_gen_type [237] = Y5877_pgtype102;
	Y5877_gen_type [238] = Y5877_pgtype103;
	Y5877_gen_type [239] = Y5877_pgtype104;
	Y5877_gen_type [240] = Y5877_pgtype105;
	Y5877_gen_type [241] = Y5877_pgtype106;
	Y5877_gen_type [242] = Y5877_pgtype107;
	Y5877_gen_type [243] = Y5877_pgtype108;
	Y5877_gen_type [244] = Y5877_pgtype109;
	Y5877_gen_type [245] = Y5877_pgtype110;
	Y5877_gen_type [246] = Y5877_pgtype111;
	Y5877_gen_type [247] = Y5877_pgtype112;
	Y5877_gen_type [248] = Y5877_pgtype113;
	Y5877_gen_type [249] = Y5877_pgtype114;
	Y5877_gen_type [250] = Y5877_pgtype115;
	Y5877_gen_type [251] = Y5877_pgtype116;
	Y5877_gen_type [252] = Y5877_pgtype117;
	Y5877_gen_type [253] = Y5877_pgtype118;
	Y5877_gen_type [254] = Y5877_pgtype119;
	Y5877_gen_type [255] = Y5877_pgtype120;
	Y5877_gen_type [256] = Y5877_pgtype121;
	Y5877_gen_type [257] = Y5877_pgtype122;
	Y5877_gen_type [258] = Y5877_pgtype123;
	Y5877_gen_type [259] = Y5877_pgtype124;
	Y5877_gen_type [260] = Y5877_pgtype125;
	Y5877_gen_type [261] = Y5877_pgtype126;
	Y5877_gen_type [262] = Y5877_pgtype127;
	Y5877_gen_type [263] = Y5877_pgtype128;
	Y5877_gen_type [264] = Y5877_pgtype129;
	Y5877_gen_type [265] = Y5877_pgtype130;
	Y5877_gen_type [266] = Y5877_pgtype131;
	Y5877_gen_type [267] = Y5877_pgtype132;
	Y5877_gen_type [268] = Y5877_pgtype133;
	Y5877_gen_type [269] = Y5877_pgtype134;
	Y5877_gen_type [270] = Y5877_pgtype135;
	Y5877_gen_type [271] = Y5877_pgtype136;
	Y5877_gen_type [272] = Y5877_pgtype137;
	Y5877_gen_type [273] = Y5877_pgtype138;
	Y5877_gen_type [274] = Y5877_pgtype139;
	Y5877_gen_type [275] = Y5877_pgtype140;
	Y5877_gen_type [276] = Y5877_pgtype141;
	Y5877_gen_type [277] = Y5877_pgtype142;
	Y5877_gen_type [278] = Y5877_pgtype143;
	Y5877_gen_type [279] = Y5877_pgtype144;
	Y5877_gen_type [280] = Y5877_pgtype145;
	Y5877_gen_type [281] = Y5877_pgtype146;
	Y5877_gen_type [282] = Y5877_pgtype147;
	Y5877_gen_type [283] = Y5877_pgtype148;
	Y5877_gen_type [284] = Y5877_pgtype149;
	Y5877_gen_type [285] = Y5877_pgtype150;
	Y5877_gen_type [286] = Y5877_pgtype151;
	Y5877_gen_type [287] = Y5877_pgtype152;
	Y5877_gen_type [288] = Y5877_pgtype153;
	Y5877_gen_type [289] = Y5877_pgtype154;
	Y5877_gen_type [290] = Y5877_pgtype155;
	Y5877_gen_type [291] = Y5877_pgtype156;
	Y5877_gen_type [292] = Y5877_pgtype157;
	Y5877_gen_type [293] = Y5877_pgtype158;
	Y5877_gen_type [294] = Y5877_pgtype159;
	Y5877_gen_type [295] = Y5877_pgtype160;
	Y5877_gen_type [296] = Y5877_pgtype161;
	Y5877_gen_type [297] = Y5877_pgtype162;
	Y5877_gen_type [298] = Y5877_pgtype163;
	Y5877_gen_type [299] = Y5877_pgtype164;
	Y5877_gen_type [421] = Y5877_pgtype165;
	Y5877_gen_type [424] = Y5877_pgtype166;
	Y5877_gen_type [425] = Y5877_pgtype167;
	Y5877_gen_type [764] = Y5877_pgtype168;
	Y5877_gen_type [765] = Y5877_pgtype169;
	Y5877_gen_type [766] = Y5877_pgtype170;
	Y5877_gen_type [767] = Y5877_pgtype171;
	Y5877_gen_type [768] = Y5877_pgtype172;
	Y5877_gen_type [769] = Y5877_pgtype173;
	Y5877_gen_type [770] = Y5877_pgtype174;
	Y5877_gen_type [771] = Y5877_pgtype175;
	Y5877_gen_type [772] = Y5877_pgtype176;
	Y5877_gen_type [773] = Y5877_pgtype177;
	Y5877_gen_type [876] = Y5877_pgtype178;
	Y5877_gen_type [877] = Y5877_pgtype179;
	Y5877[179] = 1098;
	{long i; for (i = 180; i < 185; i++) Y5877[i] = 1090;};
	{long i; for (i = 185; i < 300; i++) Y5877[i] = 1229;};
	Y5877[421] = 1229;
	{long i; for (i = 424; i < 426; i++) Y5877[i] = 1229;};
	{long i; for (i = 764; i < 774; i++) Y5877[i] = 1229;};
	{long i; for (i = 876; i < 878; i++) Y5877[i] = 1229;};
}

char *(*R5879[694])();
void R5879_init () {
	{long i; for (i = 0; i < 2; i++) R5879[i] = (char *(*)()) F754_7300_5879_1;}
	R5879[42] = (char *(*)()) F797_7370;
	R5879[185] = (char *(*)()) F940_7725;
	R5879[186] = (char *(*)()) F941_7725_5879_1;
	R5879[187] = (char *(*)()) F942_7725_5879_1;
	R5879[188] = (char *(*)()) F943_7771;
	R5879[189] = (char *(*)()) F940_7725;
	R5879[190] = (char *(*)()) F945_7799;
	R5879[191] = (char *(*)()) F946_7799_5879_1;
	R5879[192] = (char *(*)()) F947_7799_5879_1;
	R5879[194] = (char *(*)()) F940_7725;
	R5879[195] = (char *(*)()) F950_7848;
	R5879[196] = (char *(*)()) F951_7848_5879_1;
	R5879[197] = (char *(*)()) F952_7848_5879_1;
	R5879[198] = (char *(*)()) F953_7848_5879_1;
	R5879[199] = (char *(*)()) F954_7848_5879_1;
	R5879[200] = (char *(*)()) F955_7848_5879_1;
	R5879[201] = (char *(*)()) F956_7848_5879_1;
	R5879[202] = (char *(*)()) F957_7848_5879_1;
	R5879[203] = (char *(*)()) F958_7848_5879_1;
	R5879[204] = (char *(*)()) F959_7848_5879_1;
	R5879[205] = (char *(*)()) F960_7848_5879_1;
	R5879[206] = (char *(*)()) F961_7848_5879_1;
	R5879[207] = (char *(*)()) F950_7848;
	R5879[209] = (char *(*)()) F950_7848;
	R5879[211] = (char *(*)()) F950_7848;
	R5879[212] = (char *(*)()) F953_7848_5879_1;
	R5879[213] = (char *(*)()) F954_7848_5879_1;
	R5879[214] = (char *(*)()) F950_7848;
	{long i; for (i = 216; i < 218; i++) R5879[i] = (char *(*)()) F950_7848;}
	{long i; for (i = 218; i < 220; i++) R5879[i] = (char *(*)()) F953_7848_5879_1;}
	{long i; for (i = 252; i < 254; i++) R5879[i] = (char *(*)()) F1006_8563_5879_1;}
	R5879[515] = (char *(*)()) F1006_8563_5879_1;
	{long i; for (i = 684; i < 694; i++) R5879[i] = (char *(*)()) F950_7848;}
}
static EIF_REFERENCE F754_7300_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F754_7300(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_7725_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_7725_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_7799_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F946_7799(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_7799_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F947_7799(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F951_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F952_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F953_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F954_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F955_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F956_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F957_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F958_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F959_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F960_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7848_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F961_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8563_5879_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1006_8563(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
