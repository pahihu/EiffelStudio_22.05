#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5726[1050])();
void R5726_init () {
	R5726[0] = (char *(*)()) F502_7041;
	R5726[26] = (char *(*)()) F528_7097;
	R5726[27] = (char *(*)()) F529_7097;
	R5726[28] = (char *(*)()) F530_7097;
	R5726[29] = (char *(*)()) F531_7097;
	R5726[30] = (char *(*)()) F532_7097;
	R5726[31] = (char *(*)()) F533_7097;
	R5726[32] = (char *(*)()) F534_7097;
	R5726[33] = (char *(*)()) F535_7097;
	R5726[34] = (char *(*)()) F536_7097;
	R5726[35] = (char *(*)()) F537_7097;
	R5726[36] = (char *(*)()) F538_7097;
	R5726[37] = (char *(*)()) F539_7097;
	{long i; for (i = 38; i < 40; i++) R5726[i] = (char *(*)()) F528_7097;}
	R5726[40] = (char *(*)()) F534_7097;
	R5726[41] = (char *(*)()) F533_7097;
	R5726[42] = (char *(*)()) F536_7097;
	R5726[43] = (char *(*)()) F533_7097;
	R5726[44] = (char *(*)()) F532_7097;
	R5726[45] = (char *(*)()) F529_7097;
	R5726[46] = (char *(*)()) F528_7097;
	R5726[47] = (char *(*)()) F533_7097;
	R5726[48] = (char *(*)()) F534_7097;
	R5726[49] = (char *(*)()) F528_7097;
	R5726[62] = (char *(*)()) F564_7153;
	R5726[63] = (char *(*)()) F565_7159;
	R5726[64] = (char *(*)()) F566_7165;
	R5726[65] = (char *(*)()) F567_7165;
	R5726[66] = (char *(*)()) F568_7165;
	R5726[67] = (char *(*)()) F569_7165;
	R5726[68] = (char *(*)()) F570_7165;
	R5726[69] = (char *(*)()) F571_7165;
	R5726[70] = (char *(*)()) F572_7165;
	R5726[71] = (char *(*)()) F573_7165;
	R5726[72] = (char *(*)()) F574_7165;
	R5726[73] = (char *(*)()) F575_7165;
	R5726[74] = (char *(*)()) F576_7165;
	R5726[75] = (char *(*)()) F577_7165;
	R5726[76] = (char *(*)()) F578_7171;
	R5726[77] = (char *(*)()) F579_7171;
	R5726[78] = (char *(*)()) F580_7171;
	R5726[79] = (char *(*)()) F581_7171;
	R5726[80] = (char *(*)()) F582_7171;
	R5726[81] = (char *(*)()) F583_7171;
	R5726[82] = (char *(*)()) F584_7171;
	R5726[83] = (char *(*)()) F585_7171;
	R5726[84] = (char *(*)()) F586_7171;
	R5726[85] = (char *(*)()) F587_7171;
	R5726[86] = (char *(*)()) F588_7171;
	R5726[87] = (char *(*)()) F589_7171;
	R5726[88] = (char *(*)()) F590_7177;
	R5726[89] = (char *(*)()) F591_7177;
	R5726[90] = (char *(*)()) F592_7177;
	R5726[91] = (char *(*)()) F593_7177;
	R5726[92] = (char *(*)()) F594_7177;
	R5726[93] = (char *(*)()) F595_7177;
	R5726[94] = (char *(*)()) F596_7177;
	R5726[95] = (char *(*)()) F597_7177;
	R5726[96] = (char *(*)()) F598_7177;
	R5726[97] = (char *(*)()) F599_7177;
	R5726[98] = (char *(*)()) F600_7177;
	R5726[99] = (char *(*)()) F601_7177;
	R5726[253] = (char *(*)()) F755_7331;
	R5726[254] = (char *(*)()) F756_7346;
	R5726[295] = (char *(*)()) F797_7372;
	R5726[331] = (char *(*)()) F833_7420;
	R5726[344] = (char *(*)()) F846_7449;
	R5726[345] = (char *(*)()) F847_7449;
	R5726[346] = (char *(*)()) F848_7449;
	R5726[347] = (char *(*)()) F849_7449;
	R5726[348] = (char *(*)()) F850_7449;
	R5726[349] = (char *(*)()) F851_7449;
	R5726[350] = (char *(*)()) F852_7449;
	R5726[351] = (char *(*)()) F853_7449;
	{long i; for (i = 352; i < 354; i++) R5726[i] = (char *(*)()) F846_7449;}
	R5726[354] = (char *(*)()) F848_7449;
	R5726[355] = (char *(*)()) F852_7449;
	R5726[356] = (char *(*)()) F849_7449;
	R5726[357] = (char *(*)()) F853_7449;
	R5726[370] = (char *(*)()) F839_7429;
	R5726[371] = (char *(*)()) F873_7614;
	R5726[372] = (char *(*)()) F874_7614;
	R5726[373] = (char *(*)()) F875_7614;
	R5726[374] = (char *(*)()) F876_7614;
	R5726[375] = (char *(*)()) F877_7614;
	R5726[376] = (char *(*)()) F878_7614;
	R5726[377] = (char *(*)()) F879_7614;
	R5726[378] = (char *(*)()) F880_7614;
	R5726[379] = (char *(*)()) F881_7614;
	R5726[380] = (char *(*)()) F882_7614;
	R5726[381] = (char *(*)()) F883_7614;
	R5726[382] = (char *(*)()) F884_7614;
	R5726[438] = (char *(*)()) F940_7730;
	R5726[439] = (char *(*)()) F941_7730;
	R5726[440] = (char *(*)()) F942_7730;
	{long i; for (i = 441; i < 444; i++) R5726[i] = (char *(*)()) F940_7730;}
	R5726[444] = (char *(*)()) F942_7730;
	R5726[445] = (char *(*)()) F941_7730;
	R5726[447] = (char *(*)()) F948_7816;
	R5726[448] = (char *(*)()) F950_7857;
	R5726[449] = (char *(*)()) F951_7857;
	R5726[450] = (char *(*)()) F952_7857;
	R5726[451] = (char *(*)()) F953_7857;
	R5726[452] = (char *(*)()) F954_7857;
	R5726[453] = (char *(*)()) F955_7857;
	R5726[454] = (char *(*)()) F956_7857;
	R5726[455] = (char *(*)()) F957_7857;
	R5726[456] = (char *(*)()) F958_7857;
	R5726[457] = (char *(*)()) F959_7857;
	R5726[458] = (char *(*)()) F960_7857;
	R5726[459] = (char *(*)()) F961_7857;
	R5726[460] = (char *(*)()) F950_7857;
	R5726[462] = (char *(*)()) F950_7857;
	R5726[464] = (char *(*)()) F950_7857;
	R5726[465] = (char *(*)()) F953_7857;
	R5726[466] = (char *(*)()) F954_7857;
	R5726[467] = (char *(*)()) F950_7857;
	{long i; for (i = 469; i < 471; i++) R5726[i] = (char *(*)()) F950_7857;}
	{long i; for (i = 471; i < 473; i++) R5726[i] = (char *(*)()) F953_7857;}
	{long i; for (i = 505; i < 507; i++) R5726[i] = (char *(*)()) F1006_8647;}
	R5726[538] = (char *(*)()) F834_7429;
	{long i; for (i = 593; i < 595; i++) R5726[i] = (char *(*)()) F1094_9678;}
	{long i; for (i = 596; i < 598; i++) R5726[i] = (char *(*)()) F1097_9846;}
	R5726[601] = (char *(*)()) F602_7185;
	R5726[603] = (char *(*)()) F602_7185;
	R5726[649] = (char *(*)()) F1151_10572;
	R5726[650] = (char *(*)()) F1152_10572;
	R5726[651] = (char *(*)()) F1153_10572;
	R5726[652] = (char *(*)()) F1154_10572;
	R5726[653] = (char *(*)()) F1155_10572;
	R5726[654] = (char *(*)()) F1156_10572;
	R5726[655] = (char *(*)()) F1157_10572;
	R5726[656] = (char *(*)()) F1158_10572;
	R5726[657] = (char *(*)()) F1159_10572;
	R5726[658] = (char *(*)()) F1160_10572;
	R5726[659] = (char *(*)()) F1161_10572;
	R5726[660] = (char *(*)()) F1162_10572;
	R5726[753] = (char *(*)()) F1255_11866;
	R5726[754] = (char *(*)()) F1256_11909;
	R5726[765] = (char *(*)()) F1267_11974;
	R5726[766] = (char *(*)()) F1268_11974;
	R5726[767] = (char *(*)()) F1269_11974;
	R5726[768] = (char *(*)()) F1270_12028;
	{long i; for (i = 937; i < 947; i++) R5726[i] = (char *(*)()) F950_7857;}
	R5726[1049] = (char *(*)()) F1097_9846;
}

static EIF_TYPE_INDEX Y5727_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype12[] = {0xFF01,1098,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype13[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype14[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype75[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype76[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype113[] = {0xFF01,1103,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype266[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype267[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype344[] = {1093,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype365[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype383[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype473[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype474[] = {0xFF01,37,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype476[] = {0xFF01,445,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype480[] = {0xFF01,968,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype482[] = {0xFF01,1085,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype485[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype486[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype487[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype488[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype489[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype490[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype491[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype492[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype493[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype494[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype495[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype496[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype497[] = {0xFF01,1103,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype498[] = {0xFF01,1103,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype503[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype508[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype509[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype511[] = {0xFF01,1218,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype512[] = {0xFF01,1218,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype513[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype514[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype515[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype516[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype517[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype518[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype519[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype520[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype521[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype522[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype523[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype524[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype525[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype526[] = {0xFF01,1376,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype527[] = {0xFF01,1385,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype528[] = {0xFF01,1386,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype529[] = {0xFF01,1369,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype530[] = {0xFF01,1378,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype531[] = {0xFF01,1374,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype532[] = {0xFF01,1375,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype533[] = {0xFF01,1512,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype534[] = {0xFF01,1429,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype535[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5727_pgtype536[] = {1048,0xFFFF};
EIF_TYPE_INDEX *Y5727_gen_type [1064];
EIF_TYPE_INDEX Y5727 [1064];
void Y5727_init (void)
{
	egc_routines_types [5727] = Y5727;
	egc_routines_gen_types [5727] = Y5727_gen_type;
	egc_routines_offset [5727] = 488;
	Y5727_gen_type [0] = Y5727_pgtype0;
	Y5727_gen_type [1] = Y5727_pgtype1;
	Y5727_gen_type [2] = Y5727_pgtype2;
	Y5727_gen_type [3] = Y5727_pgtype3;
	Y5727_gen_type [4] = Y5727_pgtype4;
	Y5727_gen_type [5] = Y5727_pgtype5;
	Y5727_gen_type [6] = Y5727_pgtype6;
	Y5727_gen_type [7] = Y5727_pgtype7;
	Y5727_gen_type [8] = Y5727_pgtype8;
	Y5727_gen_type [9] = Y5727_pgtype9;
	Y5727_gen_type [10] = Y5727_pgtype10;
	Y5727_gen_type [11] = Y5727_pgtype11;
	Y5727_gen_type [12] = Y5727_pgtype12;
	Y5727_gen_type [13] = Y5727_pgtype13;
	Y5727_gen_type [14] = Y5727_pgtype14;
	Y5727_gen_type [15] = Y5727_pgtype15;
	Y5727_gen_type [16] = Y5727_pgtype16;
	Y5727_gen_type [17] = Y5727_pgtype17;
	Y5727_gen_type [18] = Y5727_pgtype18;
	Y5727_gen_type [19] = Y5727_pgtype19;
	Y5727_gen_type [20] = Y5727_pgtype20;
	Y5727_gen_type [21] = Y5727_pgtype21;
	Y5727_gen_type [22] = Y5727_pgtype22;
	Y5727_gen_type [23] = Y5727_pgtype23;
	Y5727_gen_type [24] = Y5727_pgtype24;
	Y5727_gen_type [25] = Y5727_pgtype25;
	Y5727_gen_type [26] = Y5727_pgtype26;
	Y5727_gen_type [27] = Y5727_pgtype27;
	Y5727_gen_type [28] = Y5727_pgtype28;
	Y5727_gen_type [29] = Y5727_pgtype29;
	Y5727_gen_type [30] = Y5727_pgtype30;
	Y5727_gen_type [31] = Y5727_pgtype31;
	Y5727_gen_type [32] = Y5727_pgtype32;
	Y5727_gen_type [33] = Y5727_pgtype33;
	Y5727_gen_type [34] = Y5727_pgtype34;
	Y5727_gen_type [35] = Y5727_pgtype35;
	Y5727_gen_type [36] = Y5727_pgtype36;
	Y5727_gen_type [37] = Y5727_pgtype37;
	Y5727_gen_type [38] = Y5727_pgtype38;
	Y5727_gen_type [39] = Y5727_pgtype39;
	Y5727_gen_type [40] = Y5727_pgtype40;
	Y5727_gen_type [41] = Y5727_pgtype41;
	Y5727_gen_type [42] = Y5727_pgtype42;
	Y5727_gen_type [43] = Y5727_pgtype43;
	Y5727_gen_type [44] = Y5727_pgtype44;
	Y5727_gen_type [45] = Y5727_pgtype45;
	Y5727_gen_type [46] = Y5727_pgtype46;
	Y5727_gen_type [47] = Y5727_pgtype47;
	Y5727_gen_type [48] = Y5727_pgtype48;
	Y5727_gen_type [49] = Y5727_pgtype49;
	Y5727_gen_type [50] = Y5727_pgtype50;
	Y5727_gen_type [51] = Y5727_pgtype51;
	Y5727_gen_type [52] = Y5727_pgtype52;
	Y5727_gen_type [53] = Y5727_pgtype53;
	Y5727_gen_type [54] = Y5727_pgtype54;
	Y5727_gen_type [55] = Y5727_pgtype55;
	Y5727_gen_type [56] = Y5727_pgtype56;
	Y5727_gen_type [57] = Y5727_pgtype57;
	Y5727_gen_type [58] = Y5727_pgtype58;
	Y5727_gen_type [59] = Y5727_pgtype59;
	Y5727_gen_type [60] = Y5727_pgtype60;
	Y5727_gen_type [61] = Y5727_pgtype61;
	Y5727_gen_type [62] = Y5727_pgtype62;
	Y5727_gen_type [63] = Y5727_pgtype63;
	Y5727_gen_type [64] = Y5727_pgtype64;
	Y5727_gen_type [65] = Y5727_pgtype65;
	Y5727_gen_type [66] = Y5727_pgtype66;
	Y5727_gen_type [67] = Y5727_pgtype67;
	Y5727_gen_type [68] = Y5727_pgtype68;
	Y5727_gen_type [69] = Y5727_pgtype69;
	Y5727_gen_type [70] = Y5727_pgtype70;
	Y5727_gen_type [71] = Y5727_pgtype71;
	Y5727_gen_type [72] = Y5727_pgtype72;
	Y5727_gen_type [73] = Y5727_pgtype73;
	Y5727_gen_type [74] = Y5727_pgtype74;
	Y5727_gen_type [75] = Y5727_pgtype75;
	Y5727_gen_type [76] = Y5727_pgtype76;
	Y5727_gen_type [77] = Y5727_pgtype77;
	Y5727_gen_type [78] = Y5727_pgtype78;
	Y5727_gen_type [79] = Y5727_pgtype79;
	Y5727_gen_type [80] = Y5727_pgtype80;
	Y5727_gen_type [81] = Y5727_pgtype81;
	Y5727_gen_type [82] = Y5727_pgtype82;
	Y5727_gen_type [83] = Y5727_pgtype83;
	Y5727_gen_type [84] = Y5727_pgtype84;
	Y5727_gen_type [85] = Y5727_pgtype85;
	Y5727_gen_type [86] = Y5727_pgtype86;
	Y5727_gen_type [87] = Y5727_pgtype87;
	Y5727_gen_type [88] = Y5727_pgtype88;
	Y5727_gen_type [89] = Y5727_pgtype89;
	Y5727_gen_type [90] = Y5727_pgtype90;
	Y5727_gen_type [91] = Y5727_pgtype91;
	Y5727_gen_type [92] = Y5727_pgtype92;
	Y5727_gen_type [93] = Y5727_pgtype93;
	Y5727_gen_type [94] = Y5727_pgtype94;
	Y5727_gen_type [95] = Y5727_pgtype95;
	Y5727_gen_type [96] = Y5727_pgtype96;
	Y5727_gen_type [97] = Y5727_pgtype97;
	Y5727_gen_type [98] = Y5727_pgtype98;
	Y5727_gen_type [99] = Y5727_pgtype99;
	Y5727_gen_type [100] = Y5727_pgtype100;
	Y5727_gen_type [101] = Y5727_pgtype101;
	Y5727_gen_type [102] = Y5727_pgtype102;
	Y5727_gen_type [103] = Y5727_pgtype103;
	Y5727_gen_type [104] = Y5727_pgtype104;
	Y5727_gen_type [105] = Y5727_pgtype105;
	Y5727_gen_type [106] = Y5727_pgtype106;
	Y5727_gen_type [107] = Y5727_pgtype107;
	Y5727_gen_type [108] = Y5727_pgtype108;
	Y5727_gen_type [109] = Y5727_pgtype109;
	Y5727_gen_type [110] = Y5727_pgtype110;
	Y5727_gen_type [111] = Y5727_pgtype111;
	Y5727_gen_type [112] = Y5727_pgtype112;
	Y5727_gen_type [113] = Y5727_pgtype113;
	Y5727_gen_type [114] = Y5727_pgtype114;
	Y5727_gen_type [115] = Y5727_pgtype115;
	Y5727_gen_type [116] = Y5727_pgtype116;
	Y5727_gen_type [117] = Y5727_pgtype117;
	Y5727_gen_type [118] = Y5727_pgtype118;
	Y5727_gen_type [119] = Y5727_pgtype119;
	Y5727_gen_type [120] = Y5727_pgtype120;
	Y5727_gen_type [121] = Y5727_pgtype121;
	Y5727_gen_type [122] = Y5727_pgtype122;
	Y5727_gen_type [123] = Y5727_pgtype123;
	Y5727_gen_type [124] = Y5727_pgtype124;
	Y5727_gen_type [125] = Y5727_pgtype125;
	Y5727_gen_type [126] = Y5727_pgtype126;
	Y5727_gen_type [127] = Y5727_pgtype127;
	Y5727_gen_type [128] = Y5727_pgtype128;
	Y5727_gen_type [129] = Y5727_pgtype129;
	Y5727_gen_type [130] = Y5727_pgtype130;
	Y5727_gen_type [131] = Y5727_pgtype131;
	Y5727_gen_type [132] = Y5727_pgtype132;
	Y5727_gen_type [133] = Y5727_pgtype133;
	Y5727_gen_type [134] = Y5727_pgtype134;
	Y5727_gen_type [135] = Y5727_pgtype135;
	Y5727_gen_type [136] = Y5727_pgtype136;
	Y5727_gen_type [137] = Y5727_pgtype137;
	Y5727_gen_type [138] = Y5727_pgtype138;
	Y5727_gen_type [139] = Y5727_pgtype139;
	Y5727_gen_type [140] = Y5727_pgtype140;
	Y5727_gen_type [141] = Y5727_pgtype141;
	Y5727_gen_type [142] = Y5727_pgtype142;
	Y5727_gen_type [143] = Y5727_pgtype143;
	Y5727_gen_type [144] = Y5727_pgtype144;
	Y5727_gen_type [145] = Y5727_pgtype145;
	Y5727_gen_type [146] = Y5727_pgtype146;
	Y5727_gen_type [147] = Y5727_pgtype147;
	Y5727_gen_type [148] = Y5727_pgtype148;
	Y5727_gen_type [149] = Y5727_pgtype149;
	Y5727_gen_type [150] = Y5727_pgtype150;
	Y5727_gen_type [151] = Y5727_pgtype151;
	Y5727_gen_type [152] = Y5727_pgtype152;
	Y5727_gen_type [153] = Y5727_pgtype153;
	Y5727_gen_type [154] = Y5727_pgtype154;
	Y5727_gen_type [155] = Y5727_pgtype155;
	Y5727_gen_type [156] = Y5727_pgtype156;
	Y5727_gen_type [157] = Y5727_pgtype157;
	Y5727_gen_type [158] = Y5727_pgtype158;
	Y5727_gen_type [159] = Y5727_pgtype159;
	Y5727_gen_type [160] = Y5727_pgtype160;
	Y5727_gen_type [161] = Y5727_pgtype161;
	Y5727_gen_type [162] = Y5727_pgtype162;
	Y5727_gen_type [163] = Y5727_pgtype163;
	Y5727_gen_type [164] = Y5727_pgtype164;
	Y5727_gen_type [165] = Y5727_pgtype165;
	Y5727_gen_type [166] = Y5727_pgtype166;
	Y5727_gen_type [167] = Y5727_pgtype167;
	Y5727_gen_type [168] = Y5727_pgtype168;
	Y5727_gen_type [169] = Y5727_pgtype169;
	Y5727_gen_type [170] = Y5727_pgtype170;
	Y5727_gen_type [171] = Y5727_pgtype171;
	Y5727_gen_type [172] = Y5727_pgtype172;
	Y5727_gen_type [173] = Y5727_pgtype173;
	Y5727_gen_type [174] = Y5727_pgtype174;
	Y5727_gen_type [175] = Y5727_pgtype175;
	Y5727_gen_type [176] = Y5727_pgtype176;
	Y5727_gen_type [177] = Y5727_pgtype177;
	Y5727_gen_type [178] = Y5727_pgtype178;
	Y5727_gen_type [179] = Y5727_pgtype179;
	Y5727_gen_type [180] = Y5727_pgtype180;
	Y5727_gen_type [181] = Y5727_pgtype181;
	Y5727_gen_type [182] = Y5727_pgtype182;
	Y5727_gen_type [183] = Y5727_pgtype183;
	Y5727_gen_type [184] = Y5727_pgtype184;
	Y5727_gen_type [185] = Y5727_pgtype185;
	Y5727_gen_type [186] = Y5727_pgtype186;
	Y5727_gen_type [187] = Y5727_pgtype187;
	Y5727_gen_type [188] = Y5727_pgtype188;
	Y5727_gen_type [189] = Y5727_pgtype189;
	Y5727_gen_type [190] = Y5727_pgtype190;
	Y5727_gen_type [191] = Y5727_pgtype191;
	Y5727_gen_type [192] = Y5727_pgtype192;
	Y5727_gen_type [193] = Y5727_pgtype193;
	Y5727_gen_type [194] = Y5727_pgtype194;
	Y5727_gen_type [195] = Y5727_pgtype195;
	Y5727_gen_type [196] = Y5727_pgtype196;
	Y5727_gen_type [197] = Y5727_pgtype197;
	Y5727_gen_type [198] = Y5727_pgtype198;
	Y5727_gen_type [199] = Y5727_pgtype199;
	Y5727_gen_type [200] = Y5727_pgtype200;
	Y5727_gen_type [201] = Y5727_pgtype201;
	Y5727_gen_type [202] = Y5727_pgtype202;
	Y5727_gen_type [203] = Y5727_pgtype203;
	Y5727_gen_type [204] = Y5727_pgtype204;
	Y5727_gen_type [205] = Y5727_pgtype205;
	Y5727_gen_type [206] = Y5727_pgtype206;
	Y5727_gen_type [207] = Y5727_pgtype207;
	Y5727_gen_type [208] = Y5727_pgtype208;
	Y5727_gen_type [209] = Y5727_pgtype209;
	Y5727_gen_type [210] = Y5727_pgtype210;
	Y5727_gen_type [211] = Y5727_pgtype211;
	Y5727_gen_type [212] = Y5727_pgtype212;
	Y5727_gen_type [213] = Y5727_pgtype213;
	Y5727_gen_type [214] = Y5727_pgtype214;
	Y5727_gen_type [215] = Y5727_pgtype215;
	Y5727_gen_type [216] = Y5727_pgtype216;
	Y5727_gen_type [217] = Y5727_pgtype217;
	Y5727_gen_type [218] = Y5727_pgtype218;
	Y5727_gen_type [219] = Y5727_pgtype219;
	Y5727_gen_type [220] = Y5727_pgtype220;
	Y5727_gen_type [221] = Y5727_pgtype221;
	Y5727_gen_type [222] = Y5727_pgtype222;
	Y5727_gen_type [223] = Y5727_pgtype223;
	Y5727_gen_type [224] = Y5727_pgtype224;
	Y5727_gen_type [225] = Y5727_pgtype225;
	Y5727_gen_type [226] = Y5727_pgtype226;
	Y5727_gen_type [227] = Y5727_pgtype227;
	Y5727_gen_type [228] = Y5727_pgtype228;
	Y5727_gen_type [229] = Y5727_pgtype229;
	Y5727_gen_type [230] = Y5727_pgtype230;
	Y5727_gen_type [231] = Y5727_pgtype231;
	Y5727_gen_type [232] = Y5727_pgtype232;
	Y5727_gen_type [233] = Y5727_pgtype233;
	Y5727_gen_type [234] = Y5727_pgtype234;
	Y5727_gen_type [235] = Y5727_pgtype235;
	Y5727_gen_type [236] = Y5727_pgtype236;
	Y5727_gen_type [237] = Y5727_pgtype237;
	Y5727_gen_type [238] = Y5727_pgtype238;
	Y5727_gen_type [239] = Y5727_pgtype239;
	Y5727_gen_type [240] = Y5727_pgtype240;
	Y5727_gen_type [241] = Y5727_pgtype241;
	Y5727_gen_type [242] = Y5727_pgtype242;
	Y5727_gen_type [243] = Y5727_pgtype243;
	Y5727_gen_type [244] = Y5727_pgtype244;
	Y5727_gen_type [245] = Y5727_pgtype245;
	Y5727_gen_type [246] = Y5727_pgtype246;
	Y5727_gen_type [247] = Y5727_pgtype247;
	Y5727_gen_type [248] = Y5727_pgtype248;
	Y5727_gen_type [249] = Y5727_pgtype249;
	Y5727_gen_type [250] = Y5727_pgtype250;
	Y5727_gen_type [251] = Y5727_pgtype251;
	Y5727_gen_type [252] = Y5727_pgtype252;
	Y5727_gen_type [253] = Y5727_pgtype253;
	Y5727_gen_type [254] = Y5727_pgtype254;
	Y5727_gen_type [255] = Y5727_pgtype255;
	Y5727_gen_type [256] = Y5727_pgtype256;
	Y5727_gen_type [257] = Y5727_pgtype257;
	Y5727_gen_type [258] = Y5727_pgtype258;
	Y5727_gen_type [259] = Y5727_pgtype259;
	Y5727_gen_type [260] = Y5727_pgtype260;
	Y5727_gen_type [261] = Y5727_pgtype261;
	Y5727_gen_type [262] = Y5727_pgtype262;
	Y5727_gen_type [263] = Y5727_pgtype263;
	Y5727_gen_type [264] = Y5727_pgtype264;
	Y5727_gen_type [265] = Y5727_pgtype265;
	Y5727_gen_type [266] = Y5727_pgtype266;
	Y5727_gen_type [267] = Y5727_pgtype267;
	Y5727_gen_type [268] = Y5727_pgtype268;
	Y5727_gen_type [269] = Y5727_pgtype269;
	Y5727_gen_type [270] = Y5727_pgtype270;
	Y5727_gen_type [271] = Y5727_pgtype271;
	Y5727_gen_type [272] = Y5727_pgtype272;
	Y5727_gen_type [273] = Y5727_pgtype273;
	Y5727_gen_type [274] = Y5727_pgtype274;
	Y5727_gen_type [275] = Y5727_pgtype275;
	Y5727_gen_type [276] = Y5727_pgtype276;
	Y5727_gen_type [277] = Y5727_pgtype277;
	Y5727_gen_type [278] = Y5727_pgtype278;
	Y5727_gen_type [279] = Y5727_pgtype279;
	Y5727_gen_type [280] = Y5727_pgtype280;
	Y5727_gen_type [281] = Y5727_pgtype281;
	Y5727_gen_type [282] = Y5727_pgtype282;
	Y5727_gen_type [283] = Y5727_pgtype283;
	Y5727_gen_type [284] = Y5727_pgtype284;
	Y5727_gen_type [285] = Y5727_pgtype285;
	Y5727_gen_type [286] = Y5727_pgtype286;
	Y5727_gen_type [287] = Y5727_pgtype287;
	Y5727_gen_type [288] = Y5727_pgtype288;
	Y5727_gen_type [289] = Y5727_pgtype289;
	Y5727_gen_type [290] = Y5727_pgtype290;
	Y5727_gen_type [291] = Y5727_pgtype291;
	Y5727_gen_type [292] = Y5727_pgtype292;
	Y5727_gen_type [293] = Y5727_pgtype293;
	Y5727_gen_type [294] = Y5727_pgtype294;
	Y5727_gen_type [295] = Y5727_pgtype295;
	Y5727_gen_type [296] = Y5727_pgtype296;
	Y5727_gen_type [297] = Y5727_pgtype297;
	Y5727_gen_type [298] = Y5727_pgtype298;
	Y5727_gen_type [299] = Y5727_pgtype299;
	Y5727_gen_type [300] = Y5727_pgtype300;
	Y5727_gen_type [301] = Y5727_pgtype301;
	Y5727_gen_type [302] = Y5727_pgtype302;
	Y5727_gen_type [303] = Y5727_pgtype303;
	Y5727_gen_type [304] = Y5727_pgtype304;
	Y5727_gen_type [305] = Y5727_pgtype305;
	Y5727_gen_type [306] = Y5727_pgtype306;
	Y5727_gen_type [307] = Y5727_pgtype307;
	Y5727_gen_type [308] = Y5727_pgtype308;
	Y5727_gen_type [309] = Y5727_pgtype309;
	Y5727_gen_type [310] = Y5727_pgtype310;
	Y5727_gen_type [311] = Y5727_pgtype311;
	Y5727_gen_type [312] = Y5727_pgtype312;
	Y5727_gen_type [313] = Y5727_pgtype313;
	Y5727_gen_type [314] = Y5727_pgtype314;
	Y5727_gen_type [315] = Y5727_pgtype315;
	Y5727_gen_type [316] = Y5727_pgtype316;
	Y5727_gen_type [317] = Y5727_pgtype317;
	Y5727_gen_type [318] = Y5727_pgtype318;
	Y5727_gen_type [319] = Y5727_pgtype319;
	Y5727_gen_type [320] = Y5727_pgtype320;
	Y5727_gen_type [321] = Y5727_pgtype321;
	Y5727_gen_type [322] = Y5727_pgtype322;
	Y5727_gen_type [323] = Y5727_pgtype323;
	Y5727_gen_type [324] = Y5727_pgtype324;
	Y5727_gen_type [325] = Y5727_pgtype325;
	Y5727_gen_type [326] = Y5727_pgtype326;
	Y5727_gen_type [327] = Y5727_pgtype327;
	Y5727_gen_type [328] = Y5727_pgtype328;
	Y5727_gen_type [329] = Y5727_pgtype329;
	Y5727_gen_type [330] = Y5727_pgtype330;
	Y5727_gen_type [331] = Y5727_pgtype331;
	Y5727_gen_type [332] = Y5727_pgtype332;
	Y5727_gen_type [333] = Y5727_pgtype333;
	Y5727_gen_type [334] = Y5727_pgtype334;
	Y5727_gen_type [335] = Y5727_pgtype335;
	Y5727_gen_type [336] = Y5727_pgtype336;
	Y5727_gen_type [337] = Y5727_pgtype337;
	Y5727_gen_type [338] = Y5727_pgtype338;
	Y5727_gen_type [339] = Y5727_pgtype339;
	Y5727_gen_type [340] = Y5727_pgtype340;
	Y5727_gen_type [341] = Y5727_pgtype341;
	Y5727_gen_type [342] = Y5727_pgtype342;
	Y5727_gen_type [343] = Y5727_pgtype343;
	Y5727_gen_type [344] = Y5727_pgtype344;
	Y5727_gen_type [345] = Y5727_pgtype345;
	Y5727_gen_type [346] = Y5727_pgtype346;
	Y5727_gen_type [347] = Y5727_pgtype347;
	Y5727_gen_type [348] = Y5727_pgtype348;
	Y5727_gen_type [349] = Y5727_pgtype349;
	Y5727_gen_type [350] = Y5727_pgtype350;
	Y5727_gen_type [351] = Y5727_pgtype351;
	Y5727_gen_type [352] = Y5727_pgtype352;
	Y5727_gen_type [353] = Y5727_pgtype353;
	Y5727_gen_type [354] = Y5727_pgtype354;
	Y5727_gen_type [355] = Y5727_pgtype355;
	Y5727_gen_type [356] = Y5727_pgtype356;
	Y5727_gen_type [357] = Y5727_pgtype357;
	Y5727_gen_type [358] = Y5727_pgtype358;
	Y5727_gen_type [359] = Y5727_pgtype359;
	Y5727_gen_type [360] = Y5727_pgtype360;
	Y5727_gen_type [361] = Y5727_pgtype361;
	Y5727_gen_type [362] = Y5727_pgtype362;
	Y5727_gen_type [363] = Y5727_pgtype363;
	Y5727_gen_type [364] = Y5727_pgtype364;
	Y5727_gen_type [365] = Y5727_pgtype365;
	Y5727_gen_type [366] = Y5727_pgtype366;
	Y5727_gen_type [367] = Y5727_pgtype367;
	Y5727_gen_type [368] = Y5727_pgtype368;
	Y5727_gen_type [369] = Y5727_pgtype369;
	Y5727_gen_type [370] = Y5727_pgtype370;
	Y5727_gen_type [371] = Y5727_pgtype371;
	Y5727_gen_type [372] = Y5727_pgtype372;
	Y5727_gen_type [373] = Y5727_pgtype373;
	Y5727_gen_type [374] = Y5727_pgtype374;
	Y5727_gen_type [375] = Y5727_pgtype375;
	Y5727_gen_type [376] = Y5727_pgtype376;
	Y5727_gen_type [377] = Y5727_pgtype377;
	Y5727_gen_type [378] = Y5727_pgtype378;
	Y5727_gen_type [379] = Y5727_pgtype379;
	Y5727_gen_type [380] = Y5727_pgtype380;
	Y5727_gen_type [381] = Y5727_pgtype381;
	Y5727_gen_type [382] = Y5727_pgtype382;
	Y5727_gen_type [383] = Y5727_pgtype383;
	Y5727_gen_type [384] = Y5727_pgtype384;
	Y5727_gen_type [385] = Y5727_pgtype385;
	Y5727_gen_type [386] = Y5727_pgtype386;
	Y5727_gen_type [387] = Y5727_pgtype387;
	Y5727_gen_type [388] = Y5727_pgtype388;
	Y5727_gen_type [389] = Y5727_pgtype389;
	Y5727_gen_type [390] = Y5727_pgtype390;
	Y5727_gen_type [391] = Y5727_pgtype391;
	Y5727_gen_type [392] = Y5727_pgtype392;
	Y5727_gen_type [393] = Y5727_pgtype393;
	Y5727_gen_type [394] = Y5727_pgtype394;
	Y5727_gen_type [395] = Y5727_pgtype395;
	Y5727_gen_type [396] = Y5727_pgtype396;
	Y5727_gen_type [397] = Y5727_pgtype397;
	Y5727_gen_type [398] = Y5727_pgtype398;
	Y5727_gen_type [399] = Y5727_pgtype399;
	Y5727_gen_type [400] = Y5727_pgtype400;
	Y5727_gen_type [401] = Y5727_pgtype401;
	Y5727_gen_type [402] = Y5727_pgtype402;
	Y5727_gen_type [403] = Y5727_pgtype403;
	Y5727_gen_type [404] = Y5727_pgtype404;
	Y5727_gen_type [405] = Y5727_pgtype405;
	Y5727_gen_type [406] = Y5727_pgtype406;
	Y5727_gen_type [407] = Y5727_pgtype407;
	Y5727_gen_type [408] = Y5727_pgtype408;
	Y5727_gen_type [409] = Y5727_pgtype409;
	Y5727_gen_type [410] = Y5727_pgtype410;
	Y5727_gen_type [411] = Y5727_pgtype411;
	Y5727_gen_type [412] = Y5727_pgtype412;
	Y5727_gen_type [413] = Y5727_pgtype413;
	Y5727_gen_type [414] = Y5727_pgtype414;
	Y5727_gen_type [415] = Y5727_pgtype415;
	Y5727_gen_type [416] = Y5727_pgtype416;
	Y5727_gen_type [417] = Y5727_pgtype417;
	Y5727_gen_type [418] = Y5727_pgtype418;
	Y5727_gen_type [419] = Y5727_pgtype419;
	Y5727_gen_type [420] = Y5727_pgtype420;
	Y5727_gen_type [421] = Y5727_pgtype421;
	Y5727_gen_type [422] = Y5727_pgtype422;
	Y5727_gen_type [423] = Y5727_pgtype423;
	Y5727_gen_type [424] = Y5727_pgtype424;
	Y5727_gen_type [425] = Y5727_pgtype425;
	Y5727_gen_type [426] = Y5727_pgtype426;
	Y5727_gen_type [427] = Y5727_pgtype427;
	Y5727_gen_type [428] = Y5727_pgtype428;
	Y5727_gen_type [429] = Y5727_pgtype429;
	Y5727_gen_type [430] = Y5727_pgtype430;
	Y5727_gen_type [431] = Y5727_pgtype431;
	Y5727_gen_type [432] = Y5727_pgtype432;
	Y5727_gen_type [433] = Y5727_pgtype433;
	Y5727_gen_type [434] = Y5727_pgtype434;
	Y5727_gen_type [435] = Y5727_pgtype435;
	Y5727_gen_type [436] = Y5727_pgtype436;
	Y5727_gen_type [437] = Y5727_pgtype437;
	Y5727_gen_type [438] = Y5727_pgtype438;
	Y5727_gen_type [439] = Y5727_pgtype439;
	Y5727_gen_type [440] = Y5727_pgtype440;
	Y5727_gen_type [441] = Y5727_pgtype441;
	Y5727_gen_type [442] = Y5727_pgtype442;
	Y5727_gen_type [443] = Y5727_pgtype443;
	Y5727_gen_type [444] = Y5727_pgtype444;
	Y5727_gen_type [445] = Y5727_pgtype445;
	Y5727_gen_type [446] = Y5727_pgtype446;
	Y5727_gen_type [447] = Y5727_pgtype447;
	Y5727_gen_type [448] = Y5727_pgtype448;
	Y5727_gen_type [449] = Y5727_pgtype449;
	Y5727_gen_type [450] = Y5727_pgtype450;
	Y5727_gen_type [451] = Y5727_pgtype451;
	Y5727_gen_type [452] = Y5727_pgtype452;
	Y5727_gen_type [453] = Y5727_pgtype453;
	Y5727_gen_type [454] = Y5727_pgtype454;
	Y5727_gen_type [455] = Y5727_pgtype455;
	Y5727_gen_type [456] = Y5727_pgtype456;
	Y5727_gen_type [457] = Y5727_pgtype457;
	Y5727_gen_type [458] = Y5727_pgtype458;
	Y5727_gen_type [459] = Y5727_pgtype459;
	Y5727_gen_type [460] = Y5727_pgtype460;
	Y5727_gen_type [461] = Y5727_pgtype461;
	Y5727_gen_type [462] = Y5727_pgtype462;
	Y5727_gen_type [463] = Y5727_pgtype463;
	Y5727_gen_type [464] = Y5727_pgtype464;
	Y5727_gen_type [465] = Y5727_pgtype465;
	Y5727_gen_type [466] = Y5727_pgtype466;
	Y5727_gen_type [467] = Y5727_pgtype467;
	Y5727_gen_type [468] = Y5727_pgtype468;
	Y5727_gen_type [469] = Y5727_pgtype469;
	Y5727_gen_type [470] = Y5727_pgtype470;
	Y5727_gen_type [471] = Y5727_pgtype471;
	Y5727_gen_type [472] = Y5727_pgtype472;
	Y5727_gen_type [473] = Y5727_pgtype473;
	Y5727_gen_type [474] = Y5727_pgtype474;
	Y5727_gen_type [475] = Y5727_pgtype475;
	Y5727_gen_type [476] = Y5727_pgtype476;
	Y5727_gen_type [477] = Y5727_pgtype477;
	Y5727_gen_type [478] = Y5727_pgtype478;
	Y5727_gen_type [479] = Y5727_pgtype479;
	Y5727_gen_type [480] = Y5727_pgtype480;
	Y5727_gen_type [481] = Y5727_pgtype481;
	Y5727_gen_type [482] = Y5727_pgtype482;
	Y5727_gen_type [483] = Y5727_pgtype483;
	Y5727_gen_type [484] = Y5727_pgtype484;
	Y5727_gen_type [485] = Y5727_pgtype485;
	Y5727_gen_type [517] = Y5727_pgtype486;
	Y5727_gen_type [518] = Y5727_pgtype487;
	Y5727_gen_type [519] = Y5727_pgtype488;
	Y5727_gen_type [551] = Y5727_pgtype489;
	Y5727_gen_type [605] = Y5727_pgtype490;
	Y5727_gen_type [606] = Y5727_pgtype491;
	Y5727_gen_type [607] = Y5727_pgtype492;
	Y5727_gen_type [608] = Y5727_pgtype493;
	Y5727_gen_type [609] = Y5727_pgtype494;
	Y5727_gen_type [610] = Y5727_pgtype495;
	Y5727_gen_type [611] = Y5727_pgtype496;
	Y5727_gen_type [614] = Y5727_pgtype497;
	Y5727_gen_type [616] = Y5727_pgtype498;
	Y5727_gen_type [662] = Y5727_pgtype499;
	Y5727_gen_type [663] = Y5727_pgtype500;
	Y5727_gen_type [664] = Y5727_pgtype501;
	Y5727_gen_type [665] = Y5727_pgtype502;
	Y5727_gen_type [666] = Y5727_pgtype503;
	Y5727_gen_type [667] = Y5727_pgtype504;
	Y5727_gen_type [668] = Y5727_pgtype505;
	Y5727_gen_type [669] = Y5727_pgtype506;
	Y5727_gen_type [670] = Y5727_pgtype507;
	Y5727_gen_type [671] = Y5727_pgtype508;
	Y5727_gen_type [672] = Y5727_pgtype509;
	Y5727_gen_type [673] = Y5727_pgtype510;
	Y5727_gen_type [766] = Y5727_pgtype511;
	Y5727_gen_type [767] = Y5727_pgtype512;
	Y5727_gen_type [778] = Y5727_pgtype513;
	Y5727_gen_type [779] = Y5727_pgtype514;
	Y5727_gen_type [780] = Y5727_pgtype515;
	Y5727_gen_type [781] = Y5727_pgtype516;
	Y5727_gen_type [815] = Y5727_pgtype517;
	Y5727_gen_type [816] = Y5727_pgtype518;
	Y5727_gen_type [817] = Y5727_pgtype519;
	Y5727_gen_type [819] = Y5727_pgtype520;
	Y5727_gen_type [820] = Y5727_pgtype521;
	Y5727_gen_type [821] = Y5727_pgtype522;
	Y5727_gen_type [822] = Y5727_pgtype523;
	Y5727_gen_type [823] = Y5727_pgtype524;
	Y5727_gen_type [950] = Y5727_pgtype525;
	Y5727_gen_type [951] = Y5727_pgtype526;
	Y5727_gen_type [952] = Y5727_pgtype527;
	Y5727_gen_type [953] = Y5727_pgtype528;
	Y5727_gen_type [954] = Y5727_pgtype529;
	Y5727_gen_type [955] = Y5727_pgtype530;
	Y5727_gen_type [956] = Y5727_pgtype531;
	Y5727_gen_type [957] = Y5727_pgtype532;
	Y5727_gen_type [958] = Y5727_pgtype533;
	Y5727_gen_type [959] = Y5727_pgtype534;
	Y5727_gen_type [1062] = Y5727_pgtype535;
	Y5727_gen_type [1063] = Y5727_pgtype536;
	Y5727[12] = 1098;
	Y5727[13] = 1094;
	Y5727[14] = 1045;
	Y5727[75] = 1045;
	Y5727[76] = 1048;
	Y5727[113] = 1103;
	{long i; for (i = 266; i < 268; i++) Y5727[i] = 1229;};
	Y5727[344] = 1093;
	Y5727[365] = 0;
	Y5727[383] = 1229;
	Y5727[473] = 1320;
	Y5727[474] = 37;
	Y5727[476] = 445;
	Y5727[480] = 968;
	Y5727[482] = 1085;
	Y5727[485] = 1229;
	{long i; for (i = 517; i < 520; i++) Y5727[i] = 1048;};
	Y5727[551] = 0;
	{long i; for (i = 605; i < 608; i++) Y5727[i] = 1045;};
	{long i; for (i = 608; i < 612; i++) Y5727[i] = 1048;};
	Y5727[614] = 1103;
	Y5727[616] = 1103;
	{long i; for (i = 766; i < 768; i++) Y5727[i] = 1218;};
	Y5727[781] = 1048;
	{long i; for (i = 815; i < 818; i++) Y5727[i] = 1048;};
	{long i; for (i = 819; i < 824; i++) Y5727[i] = 1048;};
	Y5727[951] = 1376;
	Y5727[952] = 1385;
	Y5727[953] = 1386;
	Y5727[954] = 1369;
	Y5727[955] = 1378;
	Y5727[956] = 1374;
	Y5727[957] = 1375;
	Y5727[958] = 1512;
	Y5727[959] = 1429;
	{long i; for (i = 1062; i < 1064; i++) Y5727[i] = 1048;};
}

char *(*R5779[74])();
void R5779_init () {
	R5779[0] = (char *(*)()) F528_7093;
	R5779[1] = (char *(*)()) F529_7093;
	R5779[2] = (char *(*)()) F530_7093;
	R5779[3] = (char *(*)()) F531_7093;
	R5779[4] = (char *(*)()) F532_7093;
	R5779[5] = (char *(*)()) F533_7093;
	R5779[6] = (char *(*)()) F534_7093;
	R5779[7] = (char *(*)()) F535_7093;
	R5779[8] = (char *(*)()) F536_7093;
	R5779[9] = (char *(*)()) F537_7093;
	R5779[10] = (char *(*)()) F538_7093;
	R5779[11] = (char *(*)()) F539_7093;
	{long i; for (i = 12; i < 14; i++) R5779[i] = (char *(*)()) F528_7093;}
	R5779[14] = (char *(*)()) F534_7093;
	R5779[15] = (char *(*)()) F533_7093;
	R5779[16] = (char *(*)()) F536_7093;
	R5779[17] = (char *(*)()) F533_7093;
	R5779[18] = (char *(*)()) F532_7093;
	R5779[19] = (char *(*)()) F529_7093;
	R5779[20] = (char *(*)()) F528_7093;
	R5779[21] = (char *(*)()) F533_7093;
	R5779[22] = (char *(*)()) F534_7093;
	R5779[23] = (char *(*)()) F528_7093;
	R5779[36] = (char *(*)()) F560_7133;
	R5779[37] = (char *(*)()) F562_7133;
	R5779[38] = (char *(*)()) F552_7133;
	R5779[39] = (char *(*)()) F553_7133;
	R5779[40] = (char *(*)()) F554_7133;
	R5779[41] = (char *(*)()) F555_7133;
	R5779[42] = (char *(*)()) F556_7133;
	R5779[43] = (char *(*)()) F557_7133;
	R5779[44] = (char *(*)()) F558_7133;
	R5779[45] = (char *(*)()) F559_7133;
	R5779[46] = (char *(*)()) F560_7133;
	R5779[47] = (char *(*)()) F561_7133;
	R5779[48] = (char *(*)()) F562_7133;
	R5779[49] = (char *(*)()) F563_7133;
	R5779[50] = (char *(*)()) F552_7133;
	R5779[51] = (char *(*)()) F553_7133;
	R5779[52] = (char *(*)()) F554_7133;
	R5779[53] = (char *(*)()) F555_7133;
	R5779[54] = (char *(*)()) F556_7133;
	R5779[55] = (char *(*)()) F557_7133;
	R5779[56] = (char *(*)()) F558_7133;
	R5779[57] = (char *(*)()) F559_7133;
	R5779[58] = (char *(*)()) F560_7133;
	R5779[59] = (char *(*)()) F561_7133;
	R5779[60] = (char *(*)()) F562_7133;
	R5779[61] = (char *(*)()) F563_7133;
	R5779[62] = (char *(*)()) F552_7133;
	R5779[63] = (char *(*)()) F553_7133;
	R5779[64] = (char *(*)()) F554_7133;
	R5779[65] = (char *(*)()) F555_7133;
	R5779[66] = (char *(*)()) F556_7133;
	R5779[67] = (char *(*)()) F557_7133;
	R5779[68] = (char *(*)()) F558_7133;
	R5779[69] = (char *(*)()) F559_7133;
	R5779[70] = (char *(*)()) F560_7133;
	R5779[71] = (char *(*)()) F561_7133;
	R5779[72] = (char *(*)()) F562_7133;
	R5779[73] = (char *(*)()) F563_7133;
}

char *(*R5780[74])();
void R5780_init () {
	R5780[0] = (char *(*)()) F528_7094;
	R5780[1] = (char *(*)()) F529_7094;
	R5780[2] = (char *(*)()) F530_7094;
	R5780[3] = (char *(*)()) F531_7094;
	R5780[4] = (char *(*)()) F532_7094;
	R5780[5] = (char *(*)()) F533_7094;
	R5780[6] = (char *(*)()) F534_7094;
	R5780[7] = (char *(*)()) F535_7094;
	R5780[8] = (char *(*)()) F536_7094;
	R5780[9] = (char *(*)()) F537_7094;
	R5780[10] = (char *(*)()) F538_7094;
	R5780[11] = (char *(*)()) F539_7094;
	{long i; for (i = 12; i < 14; i++) R5780[i] = (char *(*)()) F528_7094;}
	R5780[14] = (char *(*)()) F534_7094;
	R5780[15] = (char *(*)()) F533_7094;
	R5780[16] = (char *(*)()) F536_7094;
	R5780[17] = (char *(*)()) F533_7094;
	R5780[18] = (char *(*)()) F532_7094;
	R5780[19] = (char *(*)()) F529_7094;
	R5780[20] = (char *(*)()) F528_7094;
	R5780[21] = (char *(*)()) F533_7094;
	R5780[22] = (char *(*)()) F534_7094;
	R5780[23] = (char *(*)()) F528_7094;
	R5780[36] = (char *(*)()) F564_7152;
	R5780[37] = (char *(*)()) F565_7158;
	R5780[38] = (char *(*)()) F566_7164;
	R5780[39] = (char *(*)()) F567_7164;
	R5780[40] = (char *(*)()) F568_7164;
	R5780[41] = (char *(*)()) F569_7164;
	R5780[42] = (char *(*)()) F570_7164;
	R5780[43] = (char *(*)()) F571_7164;
	R5780[44] = (char *(*)()) F572_7164;
	R5780[45] = (char *(*)()) F573_7164;
	R5780[46] = (char *(*)()) F574_7164;
	R5780[47] = (char *(*)()) F575_7164;
	R5780[48] = (char *(*)()) F576_7164;
	R5780[49] = (char *(*)()) F577_7164;
	R5780[50] = (char *(*)()) F578_7170;
	R5780[51] = (char *(*)()) F579_7170;
	R5780[52] = (char *(*)()) F580_7170;
	R5780[53] = (char *(*)()) F581_7170;
	R5780[54] = (char *(*)()) F582_7170;
	R5780[55] = (char *(*)()) F583_7170;
	R5780[56] = (char *(*)()) F584_7170;
	R5780[57] = (char *(*)()) F585_7170;
	R5780[58] = (char *(*)()) F586_7170;
	R5780[59] = (char *(*)()) F587_7170;
	R5780[60] = (char *(*)()) F588_7170;
	R5780[61] = (char *(*)()) F589_7170;
	R5780[62] = (char *(*)()) F590_7176;
	R5780[63] = (char *(*)()) F591_7176;
	R5780[64] = (char *(*)()) F592_7176;
	R5780[65] = (char *(*)()) F593_7176;
	R5780[66] = (char *(*)()) F594_7176;
	R5780[67] = (char *(*)()) F595_7176;
	R5780[68] = (char *(*)()) F596_7176;
	R5780[69] = (char *(*)()) F597_7176;
	R5780[70] = (char *(*)()) F598_7176;
	R5780[71] = (char *(*)()) F599_7176;
	R5780[72] = (char *(*)()) F600_7176;
	R5780[73] = (char *(*)()) F601_7176;
}

char *(*R5788[24])();
void R5788_init () {
	R5788[0] = (char *(*)()) F528_7105;
	R5788[1] = (char *(*)()) F529_7105;
	R5788[2] = (char *(*)()) F530_7105;
	R5788[3] = (char *(*)()) F531_7105;
	R5788[4] = (char *(*)()) F532_7105;
	R5788[5] = (char *(*)()) F533_7105;
	R5788[6] = (char *(*)()) F534_7105;
	R5788[7] = (char *(*)()) F535_7105;
	R5788[8] = (char *(*)()) F536_7105;
	R5788[9] = (char *(*)()) F537_7105;
	R5788[10] = (char *(*)()) F538_7105;
	R5788[11] = (char *(*)()) F539_7105;
	{long i; for (i = 12; i < 14; i++) R5788[i] = (char *(*)()) F528_7105;}
	R5788[14] = (char *(*)()) F534_7105;
	R5788[15] = (char *(*)()) F533_7105;
	R5788[16] = (char *(*)()) F536_7105;
	R5788[17] = (char *(*)()) F533_7105;
	R5788[18] = (char *(*)()) F532_7105;
	R5788[19] = (char *(*)()) F529_7105;
	R5788[20] = (char *(*)()) F528_7105;
	R5788[21] = (char *(*)()) F533_7105;
	R5788[22] = (char *(*)()) F534_7105;
	R5788[23] = (char *(*)()) F528_7105;
}

char *(*R5790[74])();
void R5790_init () {
	R5790[0] = (char *(*)()) F528_7107;
	R5790[1] = (char *(*)()) F529_7107;
	R5790[2] = (char *(*)()) F530_7107;
	R5790[3] = (char *(*)()) F531_7107;
	R5790[4] = (char *(*)()) F532_7107;
	R5790[5] = (char *(*)()) F533_7107;
	R5790[6] = (char *(*)()) F534_7107;
	R5790[7] = (char *(*)()) F535_7107;
	R5790[8] = (char *(*)()) F536_7107;
	R5790[9] = (char *(*)()) F537_7107;
	R5790[10] = (char *(*)()) F538_7107;
	R5790[11] = (char *(*)()) F539_7107;
	{long i; for (i = 12; i < 14; i++) R5790[i] = (char *(*)()) F528_7107;}
	R5790[14] = (char *(*)()) F534_7107;
	R5790[15] = (char *(*)()) F533_7107;
	R5790[16] = (char *(*)()) F536_7107;
	R5790[17] = (char *(*)()) F533_7107;
	R5790[18] = (char *(*)()) F532_7107;
	R5790[19] = (char *(*)()) F529_7107;
	R5790[20] = (char *(*)()) F528_7107;
	R5790[21] = (char *(*)()) F533_7107;
	R5790[22] = (char *(*)()) F534_7107;
	R5790[23] = (char *(*)()) F528_7107;
	R5790[36] = (char *(*)()) F560_7144;
	R5790[37] = (char *(*)()) F562_7144;
	R5790[38] = (char *(*)()) F552_7144;
	R5790[39] = (char *(*)()) F553_7144;
	R5790[40] = (char *(*)()) F554_7144;
	R5790[41] = (char *(*)()) F555_7144;
	R5790[42] = (char *(*)()) F556_7144;
	R5790[43] = (char *(*)()) F557_7144;
	R5790[44] = (char *(*)()) F558_7144;
	R5790[45] = (char *(*)()) F559_7144;
	R5790[46] = (char *(*)()) F560_7144;
	R5790[47] = (char *(*)()) F561_7144;
	R5790[48] = (char *(*)()) F562_7144;
	R5790[49] = (char *(*)()) F563_7144;
	R5790[50] = (char *(*)()) F552_7144;
	R5790[51] = (char *(*)()) F553_7144;
	R5790[52] = (char *(*)()) F554_7144;
	R5790[53] = (char *(*)()) F555_7144;
	R5790[54] = (char *(*)()) F556_7144;
	R5790[55] = (char *(*)()) F557_7144;
	R5790[56] = (char *(*)()) F558_7144;
	R5790[57] = (char *(*)()) F559_7144;
	R5790[58] = (char *(*)()) F560_7144;
	R5790[59] = (char *(*)()) F561_7144;
	R5790[60] = (char *(*)()) F562_7144;
	R5790[61] = (char *(*)()) F563_7144;
	R5790[62] = (char *(*)()) F552_7144;
	R5790[63] = (char *(*)()) F553_7144;
	R5790[64] = (char *(*)()) F554_7144;
	R5790[65] = (char *(*)()) F555_7144;
	R5790[66] = (char *(*)()) F556_7144;
	R5790[67] = (char *(*)()) F557_7144;
	R5790[68] = (char *(*)()) F558_7144;
	R5790[69] = (char *(*)()) F559_7144;
	R5790[70] = (char *(*)()) F560_7144;
	R5790[71] = (char *(*)()) F561_7144;
	R5790[72] = (char *(*)()) F562_7144;
	R5790[73] = (char *(*)()) F563_7144;
}

char *(*R5791[74])();
void R5791_init () {
	R5791[0] = (char *(*)()) F528_7110;
	R5791[1] = (char *(*)()) F529_7110;
	R5791[2] = (char *(*)()) F530_7110;
	R5791[3] = (char *(*)()) F531_7110;
	R5791[4] = (char *(*)()) F532_7110;
	R5791[5] = (char *(*)()) F533_7110;
	R5791[6] = (char *(*)()) F534_7110;
	R5791[7] = (char *(*)()) F535_7110;
	R5791[8] = (char *(*)()) F536_7110;
	R5791[9] = (char *(*)()) F537_7110;
	R5791[10] = (char *(*)()) F538_7110;
	R5791[11] = (char *(*)()) F539_7110;
	{long i; for (i = 12; i < 14; i++) R5791[i] = (char *(*)()) F528_7110;}
	R5791[14] = (char *(*)()) F534_7110;
	R5791[15] = (char *(*)()) F533_7110;
	R5791[16] = (char *(*)()) F536_7110;
	R5791[17] = (char *(*)()) F533_7110;
	R5791[18] = (char *(*)()) F532_7110;
	R5791[19] = (char *(*)()) F529_7110;
	R5791[20] = (char *(*)()) F548_7121;
	R5791[21] = (char *(*)()) F549_7121;
	R5791[22] = (char *(*)()) F550_7121;
	R5791[23] = (char *(*)()) F551_7127;
	R5791[36] = (char *(*)()) F560_7145;
	R5791[37] = (char *(*)()) F562_7145;
	R5791[38] = (char *(*)()) F552_7145;
	R5791[39] = (char *(*)()) F553_7145;
	R5791[40] = (char *(*)()) F554_7145;
	R5791[41] = (char *(*)()) F555_7145;
	R5791[42] = (char *(*)()) F556_7145;
	R5791[43] = (char *(*)()) F557_7145;
	R5791[44] = (char *(*)()) F558_7145;
	R5791[45] = (char *(*)()) F559_7145;
	R5791[46] = (char *(*)()) F560_7145;
	R5791[47] = (char *(*)()) F561_7145;
	R5791[48] = (char *(*)()) F562_7145;
	R5791[49] = (char *(*)()) F563_7145;
	R5791[50] = (char *(*)()) F552_7145;
	R5791[51] = (char *(*)()) F553_7145;
	R5791[52] = (char *(*)()) F554_7145;
	R5791[53] = (char *(*)()) F555_7145;
	R5791[54] = (char *(*)()) F556_7145;
	R5791[55] = (char *(*)()) F557_7145;
	R5791[56] = (char *(*)()) F558_7145;
	R5791[57] = (char *(*)()) F559_7145;
	R5791[58] = (char *(*)()) F560_7145;
	R5791[59] = (char *(*)()) F561_7145;
	R5791[60] = (char *(*)()) F562_7145;
	R5791[61] = (char *(*)()) F563_7145;
	R5791[62] = (char *(*)()) F552_7145;
	R5791[63] = (char *(*)()) F553_7145;
	R5791[64] = (char *(*)()) F554_7145;
	R5791[65] = (char *(*)()) F555_7145;
	R5791[66] = (char *(*)()) F556_7145;
	R5791[67] = (char *(*)()) F557_7145;
	R5791[68] = (char *(*)()) F558_7145;
	R5791[69] = (char *(*)()) F559_7145;
	R5791[70] = (char *(*)()) F560_7145;
	R5791[71] = (char *(*)()) F561_7145;
	R5791[72] = (char *(*)()) F562_7145;
	R5791[73] = (char *(*)()) F563_7145;
}

char *(*R5792[74])();
void R5792_init () {
	R5792[0] = (char *(*)()) F528_7112;
	R5792[1] = (char *(*)()) F529_7112;
	R5792[2] = (char *(*)()) F530_7112;
	R5792[3] = (char *(*)()) F531_7112;
	R5792[4] = (char *(*)()) F532_7112;
	R5792[5] = (char *(*)()) F533_7112;
	R5792[6] = (char *(*)()) F534_7112;
	R5792[7] = (char *(*)()) F535_7112;
	R5792[8] = (char *(*)()) F536_7112;
	R5792[9] = (char *(*)()) F537_7112;
	R5792[10] = (char *(*)()) F538_7112;
	R5792[11] = (char *(*)()) F539_7112;
	R5792[12] = (char *(*)()) F540_7118;
	R5792[13] = (char *(*)()) F541_7118;
	R5792[14] = (char *(*)()) F542_7118;
	R5792[15] = (char *(*)()) F543_7118;
	R5792[16] = (char *(*)()) F544_7118;
	R5792[17] = (char *(*)()) F545_7118;
	R5792[18] = (char *(*)()) F546_7118;
	R5792[19] = (char *(*)()) F547_7118;
	R5792[20] = (char *(*)()) F548_7123;
	R5792[21] = (char *(*)()) F549_7123;
	R5792[22] = (char *(*)()) F550_7123;
	R5792[23] = (char *(*)()) F551_7129;
	R5792[36] = (char *(*)()) F564_7155;
	R5792[37] = (char *(*)()) F565_7161;
	R5792[38] = (char *(*)()) F566_7167;
	R5792[39] = (char *(*)()) F567_7167;
	R5792[40] = (char *(*)()) F568_7167;
	R5792[41] = (char *(*)()) F569_7167;
	R5792[42] = (char *(*)()) F570_7167;
	R5792[43] = (char *(*)()) F571_7167;
	R5792[44] = (char *(*)()) F572_7167;
	R5792[45] = (char *(*)()) F573_7167;
	R5792[46] = (char *(*)()) F574_7167;
	R5792[47] = (char *(*)()) F575_7167;
	R5792[48] = (char *(*)()) F576_7167;
	R5792[49] = (char *(*)()) F577_7167;
	R5792[50] = (char *(*)()) F578_7173;
	R5792[51] = (char *(*)()) F579_7173;
	R5792[52] = (char *(*)()) F580_7173;
	R5792[53] = (char *(*)()) F581_7173;
	R5792[54] = (char *(*)()) F582_7173;
	R5792[55] = (char *(*)()) F583_7173;
	R5792[56] = (char *(*)()) F584_7173;
	R5792[57] = (char *(*)()) F585_7173;
	R5792[58] = (char *(*)()) F586_7173;
	R5792[59] = (char *(*)()) F587_7173;
	R5792[60] = (char *(*)()) F588_7173;
	R5792[61] = (char *(*)()) F589_7173;
	R5792[62] = (char *(*)()) F552_7147;
	R5792[63] = (char *(*)()) F553_7147;
	R5792[64] = (char *(*)()) F554_7147;
	R5792[65] = (char *(*)()) F555_7147;
	R5792[66] = (char *(*)()) F556_7147;
	R5792[67] = (char *(*)()) F557_7147;
	R5792[68] = (char *(*)()) F558_7147;
	R5792[69] = (char *(*)()) F559_7147;
	R5792[70] = (char *(*)()) F560_7147;
	R5792[71] = (char *(*)()) F561_7147;
	R5792[72] = (char *(*)()) F562_7147;
	R5792[73] = (char *(*)()) F563_7147;
}

char *(*R5794[24])();
void R5794_init () {
	R5794[0] = (char *(*)()) F528_7091;
	R5794[1] = (char *(*)()) F529_7091;
	R5794[2] = (char *(*)()) F530_7091;
	R5794[3] = (char *(*)()) F531_7091;
	R5794[4] = (char *(*)()) F532_7091;
	R5794[5] = (char *(*)()) F533_7091;
	R5794[6] = (char *(*)()) F534_7091;
	R5794[7] = (char *(*)()) F535_7091;
	R5794[8] = (char *(*)()) F536_7091;
	R5794[9] = (char *(*)()) F537_7091;
	R5794[10] = (char *(*)()) F538_7091;
	R5794[11] = (char *(*)()) F539_7091;
	{long i; for (i = 12; i < 14; i++) R5794[i] = (char *(*)()) F528_7091;}
	R5794[14] = (char *(*)()) F534_7091;
	R5794[15] = (char *(*)()) F533_7091;
	R5794[16] = (char *(*)()) F536_7091;
	R5794[17] = (char *(*)()) F533_7091;
	R5794[18] = (char *(*)()) F532_7091;
	R5794[19] = (char *(*)()) F529_7091;
	R5794[20] = (char *(*)()) F528_7091;
	R5794[21] = (char *(*)()) F533_7091;
	R5794[22] = (char *(*)()) F534_7091;
	R5794[23] = (char *(*)()) F528_7091;
}

char *(*R5807[38])();
void R5807_init () {
	R5807[0] = (char *(*)()) F564_7156;
	R5807[1] = (char *(*)()) F565_7162;
	R5807[2] = (char *(*)()) F566_7168;
	R5807[3] = (char *(*)()) F567_7168;
	R5807[4] = (char *(*)()) F568_7168;
	R5807[5] = (char *(*)()) F569_7168;
	R5807[6] = (char *(*)()) F570_7168;
	R5807[7] = (char *(*)()) F571_7168;
	R5807[8] = (char *(*)()) F572_7168;
	R5807[9] = (char *(*)()) F573_7168;
	R5807[10] = (char *(*)()) F574_7168;
	R5807[11] = (char *(*)()) F575_7168;
	R5807[12] = (char *(*)()) F576_7168;
	R5807[13] = (char *(*)()) F577_7168;
	R5807[14] = (char *(*)()) F578_7174;
	R5807[15] = (char *(*)()) F579_7174;
	R5807[16] = (char *(*)()) F580_7174;
	R5807[17] = (char *(*)()) F581_7174;
	R5807[18] = (char *(*)()) F582_7174;
	R5807[19] = (char *(*)()) F583_7174;
	R5807[20] = (char *(*)()) F584_7174;
	R5807[21] = (char *(*)()) F585_7174;
	R5807[22] = (char *(*)()) F586_7174;
	R5807[23] = (char *(*)()) F587_7174;
	R5807[24] = (char *(*)()) F588_7174;
	R5807[25] = (char *(*)()) F589_7174;
	R5807[26] = (char *(*)()) F590_7178;
	R5807[27] = (char *(*)()) F591_7178;
	R5807[28] = (char *(*)()) F592_7178;
	R5807[29] = (char *(*)()) F593_7178;
	R5807[30] = (char *(*)()) F594_7178;
	R5807[31] = (char *(*)()) F595_7178;
	R5807[32] = (char *(*)()) F596_7178;
	R5807[33] = (char *(*)()) F597_7178;
	R5807[34] = (char *(*)()) F598_7178;
	R5807[35] = (char *(*)()) F599_7178;
	R5807[36] = (char *(*)()) F600_7178;
	R5807[37] = (char *(*)()) F601_7178;
}

char *(*R5815[12])();
void R5815_init () {
	R5815[0] = (char *(*)()) F566_7163;
	R5815[1] = (char *(*)()) F567_7163;
	R5815[2] = (char *(*)()) F568_7163;
	R5815[3] = (char *(*)()) F569_7163;
	R5815[4] = (char *(*)()) F570_7163;
	R5815[5] = (char *(*)()) F571_7163;
	R5815[6] = (char *(*)()) F572_7163;
	R5815[7] = (char *(*)()) F573_7163;
	R5815[8] = (char *(*)()) F574_7163;
	R5815[9] = (char *(*)()) F575_7163;
	R5815[10] = (char *(*)()) F576_7163;
	R5815[11] = (char *(*)()) F577_7163;
}

char *(*R5817[12])();
void R5817_init () {
	R5817[0] = (char *(*)()) F578_7169;
	R5817[1] = (char *(*)()) F579_7169;
	R5817[2] = (char *(*)()) F580_7169;
	R5817[3] = (char *(*)()) F581_7169;
	R5817[4] = (char *(*)()) F582_7169;
	R5817[5] = (char *(*)()) F583_7169;
	R5817[6] = (char *(*)()) F584_7169;
	R5817[7] = (char *(*)()) F585_7169;
	R5817[8] = (char *(*)()) F586_7169;
	R5817[9] = (char *(*)()) F587_7169;
	R5817[10] = (char *(*)()) F588_7169;
	R5817[11] = (char *(*)()) F589_7169;
}

char *(*R5820[12])();
void R5820_init () {
	R5820[0] = (char *(*)()) F590_7175;
	R5820[1] = (char *(*)()) F591_7175;
	R5820[2] = (char *(*)()) F592_7175;
	R5820[3] = (char *(*)()) F593_7175;
	R5820[4] = (char *(*)()) F594_7175;
	R5820[5] = (char *(*)()) F595_7175;
	R5820[6] = (char *(*)()) F596_7175;
	R5820[7] = (char *(*)()) F597_7175;
	R5820[8] = (char *(*)()) F598_7175;
	R5820[9] = (char *(*)()) F599_7175;
	R5820[10] = (char *(*)()) F600_7175;
	R5820[11] = (char *(*)()) F601_7175;
}

char *(*R5822[3])();
void R5822_init () {
	R5822[0] = (char *(*)()) F1103_10033;
	R5822[2] = (char *(*)()) F1105_10094;
}

char *(*R5826[3])();
void R5826_init () {
	R5826[0] = (char *(*)()) F1103_10035;
	R5826[2] = (char *(*)()) F1105_10095;
}

char *(*R5831[3])();
void R5831_init () {
	R5831[0] = (char *(*)()) F1103_10038;
	R5831[2] = (char *(*)()) F1105_10100;
}

char *(*R5835[797])();
void R5835_init () {
	R5835[0] = (char *(*)()) F755_7325_5835_2;
	R5835[1] = (char *(*)()) F756_7344_5835_2;
	R5835[118] = (char *(*)()) F873_7613;
	R5835[119] = (char *(*)()) F874_7613_5835_2;
	R5835[120] = (char *(*)()) F875_7613_5835_2;
	R5835[121] = (char *(*)()) F876_7613_5835_2;
	R5835[122] = (char *(*)()) F877_7613_5835_2;
	R5835[123] = (char *(*)()) F878_7613_5835_2;
	R5835[124] = (char *(*)()) F879_7613_5835_2;
	R5835[125] = (char *(*)()) F880_7613_5835_2;
	R5835[126] = (char *(*)()) F881_7613_5835_2;
	R5835[127] = (char *(*)()) F882_7613_5835_2;
	R5835[128] = (char *(*)()) F883_7613_5835_2;
	R5835[129] = (char *(*)()) F884_7613_5835_2;
	R5835[185] = (char *(*)()) F890_7666;
	R5835[186] = (char *(*)()) F893_7666_5835_2;
	R5835[187] = (char *(*)()) F894_7666_5835_2;
	{long i; for (i = 188; i < 191; i++) R5835[i] = (char *(*)()) F890_7666;}
	R5835[191] = (char *(*)()) F894_7666_5835_2;
	R5835[192] = (char *(*)()) F893_7666_5835_2;
	R5835[194] = (char *(*)()) F926_7706;
	R5835[195] = (char *(*)()) F950_7855;
	R5835[196] = (char *(*)()) F951_7855_5835_2;
	R5835[197] = (char *(*)()) F952_7855_5835_2;
	R5835[198] = (char *(*)()) F953_7855_5835_2;
	R5835[199] = (char *(*)()) F954_7855_5835_2;
	R5835[200] = (char *(*)()) F955_7855_5835_2;
	R5835[201] = (char *(*)()) F956_7855_5835_2;
	R5835[202] = (char *(*)()) F957_7855_5835_2;
	R5835[203] = (char *(*)()) F958_7855_5835_2;
	R5835[204] = (char *(*)()) F959_7855_5835_2;
	R5835[205] = (char *(*)()) F960_7855_5835_2;
	R5835[206] = (char *(*)()) F961_7855_5835_2;
	R5835[207] = (char *(*)()) F950_7855;
	R5835[209] = (char *(*)()) F950_7855;
	R5835[211] = (char *(*)()) F950_7855;
	R5835[212] = (char *(*)()) F953_7855_5835_2;
	R5835[213] = (char *(*)()) F954_7855_5835_2;
	R5835[214] = (char *(*)()) F950_7855;
	{long i; for (i = 216; i < 218; i++) R5835[i] = (char *(*)()) F950_7855;}
	{long i; for (i = 218; i < 220; i++) R5835[i] = (char *(*)()) F953_7855_5835_2;}
	{long i; for (i = 252; i < 254; i++) R5835[i] = (char *(*)()) F629_7210_5835_2;}
	R5835[341] = (char *(*)()) F1094_9693_5835_2;
	R5835[344] = (char *(*)()) F1097_9861_5835_2;
	R5835[515] = (char *(*)()) F629_7210_5835_2;
	{long i; for (i = 684; i < 694; i++) R5835[i] = (char *(*)()) F950_7855;}
	R5835[796] = (char *(*)()) F1551_18509_5835_2;
}
static EIF_BOOLEAN F755_7325_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F755_7325(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F756_7344_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F756_7344(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F874_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F874_7613(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F875_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F875_7613(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F876_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F876_7613(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F877_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F877_7613(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F878_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F878_7613(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F879_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F879_7613(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F880_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F880_7613(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F881_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F881_7613(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F882_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F882_7613(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F883_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F883_7613(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F884_7613_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F884_7613(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F893_7666_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F893_7666(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F894_7666_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F894_7666(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F951_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F951_7855(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F952_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F952_7855(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F953_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F953_7855(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F954_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F954_7855(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F955_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F955_7855(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F956_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F956_7855(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F957_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F957_7855(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F958_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F958_7855(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F959_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F959_7855(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F960_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F960_7855(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F961_7855_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F961_7855(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F629_7210_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F629_7210(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1094_9693_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1094_9693(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1097_9861_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1097_9861(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1551_18509_5835_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1551_18509(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5836[797])();
void R5836_init () {
	{long i; for (i = 0; i < 2; i++) R5836[i] = (char *(*)()) F752_7296;}
	R5836[42] = (char *(*)()) F797_7378;
	{long i; for (i = 91; i < 93; i++) R5836[i] = (char *(*)()) F757_7351;}
	R5836[93] = (char *(*)()) F763_7351;
	R5836[94] = (char *(*)()) F762_7351;
	R5836[95] = (char *(*)()) F765_7351;
	R5836[96] = (char *(*)()) F762_7351;
	R5836[97] = (char *(*)()) F761_7351;
	R5836[98] = (char *(*)()) F758_7351;
	{long i; for (i = 99; i < 101; i++) R5836[i] = (char *(*)()) F757_7351;}
	R5836[101] = (char *(*)()) F763_7351;
	R5836[102] = (char *(*)()) F761_7351;
	R5836[103] = (char *(*)()) F762_7351;
	R5836[104] = (char *(*)()) F758_7351;
	R5836[117] = (char *(*)()) F762_7351;
	R5836[118] = (char *(*)()) F757_7351;
	R5836[119] = (char *(*)()) F758_7351;
	R5836[120] = (char *(*)()) F761_7351;
	R5836[121] = (char *(*)()) F762_7351;
	R5836[122] = (char *(*)()) F763_7351;
	R5836[123] = (char *(*)()) F764_7351;
	R5836[124] = (char *(*)()) F765_7351;
	R5836[125] = (char *(*)()) F766_7351;
	R5836[126] = (char *(*)()) F760_7351;
	R5836[127] = (char *(*)()) F767_7351;
	R5836[128] = (char *(*)()) F759_7351;
	R5836[129] = (char *(*)()) F768_7351;
	R5836[185] = (char *(*)()) F757_7351;
	R5836[186] = (char *(*)()) F762_7351;
	R5836[187] = (char *(*)()) F763_7351;
	{long i; for (i = 188; i < 191; i++) R5836[i] = (char *(*)()) F757_7351;}
	R5836[191] = (char *(*)()) F763_7351;
	R5836[192] = (char *(*)()) F762_7351;
	{long i; for (i = 194; i < 196; i++) R5836[i] = (char *(*)()) F757_7351;}
	R5836[196] = (char *(*)()) F758_7351;
	R5836[197] = (char *(*)()) F761_7351;
	R5836[198] = (char *(*)()) F762_7351;
	R5836[199] = (char *(*)()) F763_7351;
	R5836[200] = (char *(*)()) F764_7351;
	R5836[201] = (char *(*)()) F765_7351;
	R5836[202] = (char *(*)()) F766_7351;
	R5836[203] = (char *(*)()) F760_7351;
	R5836[204] = (char *(*)()) F767_7351;
	R5836[205] = (char *(*)()) F759_7351;
	R5836[206] = (char *(*)()) F768_7351;
	R5836[207] = (char *(*)()) F757_7351;
	R5836[209] = (char *(*)()) F757_7351;
	R5836[211] = (char *(*)()) F757_7351;
	R5836[212] = (char *(*)()) F762_7351;
	R5836[213] = (char *(*)()) F763_7351;
	R5836[214] = (char *(*)()) F757_7351;
	{long i; for (i = 216; i < 218; i++) R5836[i] = (char *(*)()) F757_7351;}
	{long i; for (i = 218; i < 220; i++) R5836[i] = (char *(*)()) F762_7351;}
	{long i; for (i = 252; i < 254; i++) R5836[i] = (char *(*)()) F759_7351;}
	R5836[341] = (char *(*)()) F760_7351;
	R5836[344] = (char *(*)()) F759_7351;
	R5836[515] = (char *(*)()) F1270_12057;
	{long i; for (i = 684; i < 694; i++) R5836[i] = (char *(*)()) F757_7351;}
	R5836[796] = (char *(*)()) F759_7351;
}

char *(*R5840[797])();
void R5840_init () {
	{long i; for (i = 0; i < 2; i++) R5840[i] = (char *(*)()) F608_7199;}
	R5840[42] = (char *(*)()) F603_7199;
	{long i; for (i = 91; i < 93; i++) R5840[i] = (char *(*)()) F603_7199;}
	R5840[93] = (char *(*)()) F609_7199;
	R5840[94] = (char *(*)()) F608_7199;
	R5840[95] = (char *(*)()) F611_7199;
	R5840[96] = (char *(*)()) F608_7199;
	R5840[97] = (char *(*)()) F607_7199;
	R5840[98] = (char *(*)()) F604_7199;
	{long i; for (i = 99; i < 101; i++) R5840[i] = (char *(*)()) F603_7199;}
	R5840[101] = (char *(*)()) F609_7199;
	R5840[102] = (char *(*)()) F607_7199;
	R5840[103] = (char *(*)()) F608_7199;
	R5840[104] = (char *(*)()) F604_7199;
	R5840[117] = (char *(*)()) F608_7199;
	R5840[118] = (char *(*)()) F603_7199;
	R5840[119] = (char *(*)()) F604_7199;
	R5840[120] = (char *(*)()) F607_7199;
	R5840[121] = (char *(*)()) F608_7199;
	R5840[122] = (char *(*)()) F609_7199;
	R5840[123] = (char *(*)()) F610_7199;
	R5840[124] = (char *(*)()) F611_7199;
	R5840[125] = (char *(*)()) F612_7199;
	R5840[126] = (char *(*)()) F606_7199;
	R5840[127] = (char *(*)()) F613_7199;
	R5840[128] = (char *(*)()) F605_7199;
	R5840[129] = (char *(*)()) F614_7199;
	R5840[185] = (char *(*)()) F603_7199;
	R5840[186] = (char *(*)()) F608_7199;
	R5840[187] = (char *(*)()) F609_7199;
	{long i; for (i = 188; i < 191; i++) R5840[i] = (char *(*)()) F603_7199;}
	R5840[191] = (char *(*)()) F609_7199;
	R5840[192] = (char *(*)()) F608_7199;
	{long i; for (i = 194; i < 196; i++) R5840[i] = (char *(*)()) F603_7199;}
	R5840[196] = (char *(*)()) F604_7199;
	R5840[197] = (char *(*)()) F607_7199;
	R5840[198] = (char *(*)()) F608_7199;
	R5840[199] = (char *(*)()) F609_7199;
	R5840[200] = (char *(*)()) F610_7199;
	R5840[201] = (char *(*)()) F611_7199;
	R5840[202] = (char *(*)()) F612_7199;
	R5840[203] = (char *(*)()) F606_7199;
	R5840[204] = (char *(*)()) F613_7199;
	R5840[205] = (char *(*)()) F605_7199;
	R5840[206] = (char *(*)()) F614_7199;
	R5840[207] = (char *(*)()) F603_7199;
	R5840[209] = (char *(*)()) F603_7199;
	R5840[211] = (char *(*)()) F603_7199;
	R5840[212] = (char *(*)()) F608_7199;
	R5840[213] = (char *(*)()) F609_7199;
	R5840[214] = (char *(*)()) F603_7199;
	{long i; for (i = 216; i < 218; i++) R5840[i] = (char *(*)()) F603_7199;}
	{long i; for (i = 218; i < 220; i++) R5840[i] = (char *(*)()) F608_7199;}
	{long i; for (i = 252; i < 254; i++) R5840[i] = (char *(*)()) F605_7199;}
	R5840[341] = (char *(*)()) F606_7199;
	R5840[344] = (char *(*)()) F605_7199;
	R5840[515] = (char *(*)()) F605_7199;
	{long i; for (i = 684; i < 694; i++) R5840[i] = (char *(*)()) F603_7199;}
	R5840[796] = (char *(*)()) F605_7199;
}

char *(*R5842[797])();
void R5842_init () {
	{long i; for (i = 0; i < 2; i++) R5842[i] = (char *(*)()) F754_7311;}
	R5842[42] = (char *(*)()) F797_7392;
	R5842[91] = (char *(*)()) F846_7490;
	R5842[92] = (char *(*)()) F847_7490;
	R5842[93] = (char *(*)()) F848_7490;
	R5842[94] = (char *(*)()) F849_7490;
	R5842[95] = (char *(*)()) F850_7490;
	R5842[96] = (char *(*)()) F851_7490;
	R5842[97] = (char *(*)()) F852_7490;
	R5842[98] = (char *(*)()) F853_7490;
	{long i; for (i = 99; i < 101; i++) R5842[i] = (char *(*)()) F846_7490;}
	R5842[101] = (char *(*)()) F848_7490;
	R5842[102] = (char *(*)()) F852_7490;
	R5842[103] = (char *(*)()) F849_7490;
	R5842[104] = (char *(*)()) F853_7490;
	R5842[117] = (char *(*)()) F872_7592;
	R5842[118] = (char *(*)()) F873_7657;
	R5842[119] = (char *(*)()) F874_7657;
	R5842[120] = (char *(*)()) F875_7657;
	R5842[121] = (char *(*)()) F876_7657;
	R5842[122] = (char *(*)()) F877_7657;
	R5842[123] = (char *(*)()) F878_7657;
	R5842[124] = (char *(*)()) F879_7657;
	R5842[125] = (char *(*)()) F880_7657;
	R5842[126] = (char *(*)()) F881_7657;
	R5842[127] = (char *(*)()) F882_7657;
	R5842[128] = (char *(*)()) F883_7657;
	R5842[129] = (char *(*)()) F884_7657;
	R5842[185] = (char *(*)()) F627_7225;
	R5842[186] = (char *(*)()) F632_7225;
	R5842[187] = (char *(*)()) F633_7225;
	R5842[188] = (char *(*)()) F943_7775;
	R5842[189] = (char *(*)()) F627_7225;
	R5842[190] = (char *(*)()) F945_7804;
	R5842[191] = (char *(*)()) F946_7804;
	R5842[192] = (char *(*)()) F947_7804;
	{long i; for (i = 194; i < 196; i++) R5842[i] = (char *(*)()) F627_7225;}
	R5842[196] = (char *(*)()) F628_7225;
	R5842[197] = (char *(*)()) F631_7225;
	R5842[198] = (char *(*)()) F632_7225;
	R5842[199] = (char *(*)()) F633_7225;
	R5842[200] = (char *(*)()) F634_7225;
	R5842[201] = (char *(*)()) F635_7225;
	R5842[202] = (char *(*)()) F636_7225;
	R5842[203] = (char *(*)()) F630_7225;
	R5842[204] = (char *(*)()) F637_7225;
	R5842[205] = (char *(*)()) F629_7225;
	R5842[206] = (char *(*)()) F638_7225;
	R5842[207] = (char *(*)()) F627_7225;
	R5842[209] = (char *(*)()) F627_7225;
	R5842[211] = (char *(*)()) F966_7933;
	R5842[212] = (char *(*)()) F967_7933;
	R5842[213] = (char *(*)()) F968_7933;
	R5842[214] = (char *(*)()) F627_7225;
	{long i; for (i = 216; i < 218; i++) R5842[i] = (char *(*)()) F627_7225;}
	{long i; for (i = 218; i < 220; i++) R5842[i] = (char *(*)()) F632_7225;}
	{long i; for (i = 252; i < 254; i++) R5842[i] = (char *(*)()) F629_7225;}
	R5842[341] = (char *(*)()) F1096_9817;
	R5842[344] = (char *(*)()) F1099_9982;
	R5842[515] = (char *(*)()) F629_7225;
	{long i; for (i = 684; i < 694; i++) R5842[i] = (char *(*)()) F627_7225;}
	R5842[796] = (char *(*)()) F1099_9982;
}

char *(*R5843[797])();
void R5843_init () {
	{long i; for (i = 0; i < 2; i++) R5843[i] = (char *(*)()) F608_7202;}
	R5843[42] = (char *(*)()) F603_7202;
	{long i; for (i = 91; i < 93; i++) R5843[i] = (char *(*)()) F603_7202;}
	R5843[93] = (char *(*)()) F609_7202;
	R5843[94] = (char *(*)()) F608_7202;
	R5843[95] = (char *(*)()) F611_7202;
	R5843[96] = (char *(*)()) F608_7202;
	R5843[97] = (char *(*)()) F607_7202;
	R5843[98] = (char *(*)()) F604_7202;
	{long i; for (i = 99; i < 101; i++) R5843[i] = (char *(*)()) F603_7202;}
	R5843[101] = (char *(*)()) F609_7202;
	R5843[102] = (char *(*)()) F607_7202;
	R5843[103] = (char *(*)()) F608_7202;
	R5843[104] = (char *(*)()) F604_7202;
	R5843[117] = (char *(*)()) F608_7202;
	R5843[118] = (char *(*)()) F603_7202;
	R5843[119] = (char *(*)()) F604_7202;
	R5843[120] = (char *(*)()) F607_7202;
	R5843[121] = (char *(*)()) F608_7202;
	R5843[122] = (char *(*)()) F609_7202;
	R5843[123] = (char *(*)()) F610_7202;
	R5843[124] = (char *(*)()) F611_7202;
	R5843[125] = (char *(*)()) F612_7202;
	R5843[126] = (char *(*)()) F606_7202;
	R5843[127] = (char *(*)()) F613_7202;
	R5843[128] = (char *(*)()) F605_7202;
	R5843[129] = (char *(*)()) F614_7202;
	R5843[185] = (char *(*)()) F603_7202;
	R5843[186] = (char *(*)()) F608_7202;
	R5843[187] = (char *(*)()) F609_7202;
	{long i; for (i = 188; i < 191; i++) R5843[i] = (char *(*)()) F603_7202;}
	R5843[191] = (char *(*)()) F609_7202;
	R5843[192] = (char *(*)()) F608_7202;
	{long i; for (i = 194; i < 196; i++) R5843[i] = (char *(*)()) F603_7202;}
	R5843[196] = (char *(*)()) F604_7202;
	R5843[197] = (char *(*)()) F607_7202;
	R5843[198] = (char *(*)()) F608_7202;
	R5843[199] = (char *(*)()) F609_7202;
	R5843[200] = (char *(*)()) F610_7202;
	R5843[201] = (char *(*)()) F611_7202;
	R5843[202] = (char *(*)()) F612_7202;
	R5843[203] = (char *(*)()) F606_7202;
	R5843[204] = (char *(*)()) F613_7202;
	R5843[205] = (char *(*)()) F605_7202;
	R5843[206] = (char *(*)()) F614_7202;
	R5843[207] = (char *(*)()) F603_7202;
	R5843[209] = (char *(*)()) F603_7202;
	R5843[211] = (char *(*)()) F603_7202;
	R5843[212] = (char *(*)()) F608_7202;
	R5843[213] = (char *(*)()) F609_7202;
	R5843[214] = (char *(*)()) F603_7202;
	{long i; for (i = 216; i < 218; i++) R5843[i] = (char *(*)()) F603_7202;}
	{long i; for (i = 218; i < 220; i++) R5843[i] = (char *(*)()) F608_7202;}
	{long i; for (i = 252; i < 254; i++) R5843[i] = (char *(*)()) F605_7202;}
	R5843[341] = (char *(*)()) F606_7202;
	R5843[344] = (char *(*)()) F605_7202;
	R5843[515] = (char *(*)()) F605_7202;
	{long i; for (i = 684; i < 694; i++) R5843[i] = (char *(*)()) F603_7202;}
	R5843[796] = (char *(*)()) F605_7202;
}

char *(*R5844[694])();
void R5844_init () {
	{long i; for (i = 0; i < 2; i++) R5844[i] = (char *(*)()) F754_7300_5844_1;}
	R5844[185] = (char *(*)()) F940_7725;
	R5844[186] = (char *(*)()) F941_7725_5844_1;
	R5844[187] = (char *(*)()) F942_7725_5844_1;
	{long i; for (i = 188; i < 191; i++) R5844[i] = (char *(*)()) F940_7725;}
	R5844[191] = (char *(*)()) F942_7725_5844_1;
	R5844[192] = (char *(*)()) F941_7725_5844_1;
	R5844[194] = (char *(*)()) F940_7725;
	R5844[195] = (char *(*)()) F950_7848;
	R5844[196] = (char *(*)()) F951_7848_5844_1;
	R5844[197] = (char *(*)()) F952_7848_5844_1;
	R5844[198] = (char *(*)()) F953_7848_5844_1;
	R5844[199] = (char *(*)()) F954_7848_5844_1;
	R5844[200] = (char *(*)()) F955_7848_5844_1;
	R5844[201] = (char *(*)()) F956_7848_5844_1;
	R5844[202] = (char *(*)()) F957_7848_5844_1;
	R5844[203] = (char *(*)()) F958_7848_5844_1;
	R5844[204] = (char *(*)()) F959_7848_5844_1;
	R5844[205] = (char *(*)()) F960_7848_5844_1;
	R5844[206] = (char *(*)()) F961_7848_5844_1;
	R5844[207] = (char *(*)()) F950_7848;
	R5844[209] = (char *(*)()) F950_7848;
	R5844[211] = (char *(*)()) F950_7848;
	R5844[212] = (char *(*)()) F953_7848_5844_1;
	R5844[213] = (char *(*)()) F954_7848_5844_1;
	R5844[214] = (char *(*)()) F950_7848;
	{long i; for (i = 216; i < 218; i++) R5844[i] = (char *(*)()) F950_7848;}
	{long i; for (i = 218; i < 220; i++) R5844[i] = (char *(*)()) F953_7848_5844_1;}
	{long i; for (i = 252; i < 254; i++) R5844[i] = (char *(*)()) F1006_8563_5844_1;}
	R5844[515] = (char *(*)()) F1006_8563_5844_1;
	{long i; for (i = 684; i < 694; i++) R5844[i] = (char *(*)()) F950_7848;}
}
static EIF_REFERENCE F754_7300_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F754_7300(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_7725_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_7725_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F951_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F952_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F953_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F954_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F955_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F956_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F957_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F958_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F959_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F960_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7848_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F961_7848(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8563_5844_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1006_8563(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5845[694])();
void R5845_init () {
	{long i; for (i = 0; i < 2; i++) R5845[i] = (char *(*)()) F632_7218;}
	R5845[185] = (char *(*)()) F940_7736;
	R5845[186] = (char *(*)()) F941_7736;
	R5845[187] = (char *(*)()) F942_7736;
	{long i; for (i = 188; i < 191; i++) R5845[i] = (char *(*)()) F940_7736;}
	R5845[191] = (char *(*)()) F942_7736;
	R5845[192] = (char *(*)()) F941_7736;
	R5845[194] = (char *(*)()) F940_7736;
	R5845[195] = (char *(*)()) F890_7679;
	R5845[196] = (char *(*)()) F891_7679;
	R5845[197] = (char *(*)()) F892_7679;
	R5845[198] = (char *(*)()) F893_7679;
	R5845[199] = (char *(*)()) F894_7679;
	R5845[200] = (char *(*)()) F895_7679;
	R5845[201] = (char *(*)()) F896_7679;
	R5845[202] = (char *(*)()) F897_7679;
	R5845[203] = (char *(*)()) F898_7679;
	R5845[204] = (char *(*)()) F899_7679;
	R5845[205] = (char *(*)()) F900_7679;
	R5845[206] = (char *(*)()) F901_7679;
	R5845[207] = (char *(*)()) F890_7679;
	R5845[209] = (char *(*)()) F890_7679;
	R5845[211] = (char *(*)()) F890_7679;
	R5845[212] = (char *(*)()) F893_7679;
	R5845[213] = (char *(*)()) F894_7679;
	R5845[214] = (char *(*)()) F890_7679;
	{long i; for (i = 216; i < 218; i++) R5845[i] = (char *(*)()) F890_7679;}
	{long i; for (i = 218; i < 220; i++) R5845[i] = (char *(*)()) F893_7679;}
	{long i; for (i = 252; i < 254; i++) R5845[i] = (char *(*)()) F1006_8584;}
	R5845[515] = (char *(*)()) F1006_8584;
	{long i; for (i = 684; i < 694; i++) R5845[i] = (char *(*)()) F890_7679;}
}

char *(*R5846[694])();
void R5846_init () {
	{long i; for (i = 0; i < 2; i++) R5846[i] = (char *(*)()) F754_7308;}
	R5846[185] = (char *(*)()) F940_7742;
	R5846[186] = (char *(*)()) F941_7742;
	R5846[187] = (char *(*)()) F942_7742;
	{long i; for (i = 188; i < 191; i++) R5846[i] = (char *(*)()) F940_7742;}
	R5846[191] = (char *(*)()) F942_7742;
	R5846[192] = (char *(*)()) F941_7742;
	R5846[194] = (char *(*)()) F940_7742;
	R5846[195] = (char *(*)()) F950_7874;
	R5846[196] = (char *(*)()) F951_7874;
	R5846[197] = (char *(*)()) F952_7874;
	R5846[198] = (char *(*)()) F953_7874;
	R5846[199] = (char *(*)()) F954_7874;
	R5846[200] = (char *(*)()) F955_7874;
	R5846[201] = (char *(*)()) F956_7874;
	R5846[202] = (char *(*)()) F957_7874;
	R5846[203] = (char *(*)()) F958_7874;
	R5846[204] = (char *(*)()) F959_7874;
	R5846[205] = (char *(*)()) F960_7874;
	R5846[206] = (char *(*)()) F961_7874;
	R5846[207] = (char *(*)()) F950_7874;
	R5846[209] = (char *(*)()) F950_7874;
	R5846[211] = (char *(*)()) F950_7874;
	R5846[212] = (char *(*)()) F953_7874;
	R5846[213] = (char *(*)()) F954_7874;
	R5846[214] = (char *(*)()) F950_7874;
	{long i; for (i = 216; i < 218; i++) R5846[i] = (char *(*)()) F950_7874;}
	{long i; for (i = 218; i < 220; i++) R5846[i] = (char *(*)()) F953_7874;}
	{long i; for (i = 252; i < 254; i++) R5846[i] = (char *(*)()) F1006_8639;}
	R5846[515] = (char *(*)()) F1006_8639;
	{long i; for (i = 684; i < 694; i++) R5846[i] = (char *(*)()) F950_7874;}
}

char *(*R5852[694])();
void R5852_init () {
	{long i; for (i = 0; i < 2; i++) R5852[i] = (char *(*)()) F632_7212_5852_4;}
	R5852[185] = (char *(*)()) F639_7229;
	R5852[186] = (char *(*)()) F642_7229_5852_4;
	R5852[187] = (char *(*)()) F643_7229_5852_4;
	{long i; for (i = 188; i < 191; i++) R5852[i] = (char *(*)()) F639_7229;}
	R5852[191] = (char *(*)()) F643_7229_5852_4;
	R5852[192] = (char *(*)()) F642_7229_5852_4;
	R5852[194] = (char *(*)()) F639_7229;
	R5852[195] = (char *(*)()) F950_7880;
	R5852[196] = (char *(*)()) F951_7880_5852_4;
	R5852[197] = (char *(*)()) F952_7880_5852_4;
	R5852[198] = (char *(*)()) F953_7880_5852_4;
	R5852[199] = (char *(*)()) F954_7880_5852_4;
	R5852[200] = (char *(*)()) F955_7880_5852_4;
	R5852[201] = (char *(*)()) F956_7880_5852_4;
	R5852[202] = (char *(*)()) F957_7880_5852_4;
	R5852[203] = (char *(*)()) F958_7880_5852_4;
	R5852[204] = (char *(*)()) F959_7880_5852_4;
	R5852[205] = (char *(*)()) F960_7880_5852_4;
	R5852[206] = (char *(*)()) F961_7880_5852_4;
	R5852[207] = (char *(*)()) F950_7880;
	R5852[209] = (char *(*)()) F950_7880;
	R5852[211] = (char *(*)()) F950_7880;
	R5852[212] = (char *(*)()) F953_7880_5852_4;
	R5852[213] = (char *(*)()) F954_7880_5852_4;
	R5852[214] = (char *(*)()) F950_7880;
	{long i; for (i = 216; i < 218; i++) R5852[i] = (char *(*)()) F950_7880;}
	{long i; for (i = 218; i < 220; i++) R5852[i] = (char *(*)()) F953_7880_5852_4;}
	{long i; for (i = 252; i < 254; i++) R5852[i] = (char *(*)()) F644_7229_5852_4;}
	R5852[515] = (char *(*)()) F644_7229_5852_4;
	{long i; for (i = 684; i < 694; i++) R5852[i] = (char *(*)()) F950_7880;}
}
static void F632_7212_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F632_7212(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F642_7229_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F642_7229(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F643_7229_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_7229(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7880(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F952_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7880(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F953_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7880(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7880(Current, *(EIF_BOOLEAN *)arg1);
}
static void F955_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7880(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F956_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7880(Current, *(EIF_POINTER *)arg1);
}
static void F957_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7880(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F958_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7880(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F959_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7880(Current, *(EIF_REAL_64 *)arg1);
}
static void F960_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7880(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F961_7880_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F961_7880(Current, *(EIF_REAL_32 *)arg1);
}
static void F644_7229_5852_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_7229(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5853[694])();
void R5853_init () {
	{long i; for (i = 0; i < 2; i++) R5853[i] = (char *(*)()) F754_7299;}
	R5853[185] = (char *(*)()) F940_7728;
	R5853[186] = (char *(*)()) F941_7728;
	R5853[187] = (char *(*)()) F942_7728;
	{long i; for (i = 188; i < 191; i++) R5853[i] = (char *(*)()) F940_7728;}
	R5853[191] = (char *(*)()) F942_7728;
	R5853[192] = (char *(*)()) F941_7728;
	R5853[194] = (char *(*)()) F940_7728;
	R5853[195] = (char *(*)()) F950_7853;
	R5853[196] = (char *(*)()) F951_7853;
	R5853[197] = (char *(*)()) F952_7853;
	R5853[198] = (char *(*)()) F953_7853;
	R5853[199] = (char *(*)()) F954_7853;
	R5853[200] = (char *(*)()) F955_7853;
	R5853[201] = (char *(*)()) F956_7853;
	R5853[202] = (char *(*)()) F957_7853;
	R5853[203] = (char *(*)()) F958_7853;
	R5853[204] = (char *(*)()) F959_7853;
	R5853[205] = (char *(*)()) F960_7853;
	R5853[206] = (char *(*)()) F961_7853;
	R5853[207] = (char *(*)()) F950_7853;
	R5853[209] = (char *(*)()) F950_7853;
	R5853[211] = (char *(*)()) F950_7853;
	R5853[212] = (char *(*)()) F953_7853;
	R5853[213] = (char *(*)()) F954_7853;
	R5853[214] = (char *(*)()) F950_7853;
	{long i; for (i = 216; i < 218; i++) R5853[i] = (char *(*)()) F950_7853;}
	{long i; for (i = 218; i < 220; i++) R5853[i] = (char *(*)()) F953_7853;}
	{long i; for (i = 684; i < 694; i++) R5853[i] = (char *(*)()) F950_7853;}
}


#ifdef __cplusplus
}
#endif
