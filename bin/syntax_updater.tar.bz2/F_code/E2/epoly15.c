#include "epoly15.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7754[453])();
void R7754_init () {
	R7754[0] = (char *(*)()) F1099_9939;
	R7754[452] = (char *(*)()) F1551_18532;
}

char *(*R7756[453])();
void R7756_init () {
	R7756[0] = (char *(*)()) F1099_9941;
	R7756[452] = (char *(*)()) F1551_18530;
}

char *(*R7758[453])();
void R7758_init () {
	R7758[0] = (char *(*)()) F1099_9952;
	R7758[452] = (char *(*)()) F1551_18529;
}

char *(*R7760[453])();
void R7760_init () {
	R7760[0] = (char *(*)()) F1099_9956;
	R7760[452] = (char *(*)()) F1551_18546;
}

char *(*R7761[453])();
void R7761_init () {
	R7761[0] = (char *(*)()) F1099_9957;
	R7761[452] = (char *(*)()) F1551_18544;
}

char *(*R7770[453])();
void R7770_init () {
	R7770[0] = (char *(*)()) F1099_9980;
	R7770[452] = (char *(*)()) F1551_18563;
}

char *(*R7771[453])();
void R7771_init () {
	R7771[0] = (char *(*)()) F1099_9981;
	R7771[452] = (char *(*)()) F1551_18564;
}

char *(*R8260[34])();
void R8260_init () {
	R8260[0] = (char *(*)()) F1116_10528;
	R8260[1] = (char *(*)()) F1117_10528;
	R8260[2] = (char *(*)()) F1118_10528;
	R8260[3] = (char *(*)()) F1119_10528;
	R8260[4] = (char *(*)()) F1120_10528;
	R8260[5] = (char *(*)()) F1121_10528;
	R8260[6] = (char *(*)()) F1122_10528;
	R8260[7] = (char *(*)()) F1123_10528;
	R8260[8] = (char *(*)()) F1124_10528;
	R8260[9] = (char *(*)()) F1125_10528;
	R8260[10] = (char *(*)()) F1126_10528;
	R8260[11] = (char *(*)()) F1127_10528;
	R8260[12] = (char *(*)()) F1128_10528;
	R8260[13] = (char *(*)()) F1129_10528;
	R8260[14] = (char *(*)()) F1130_10528;
	R8260[15] = (char *(*)()) F1131_10528;
	R8260[16] = (char *(*)()) F1132_10528;
	R8260[17] = (char *(*)()) F1133_10528;
	R8260[18] = (char *(*)()) F1134_10528;
	R8260[19] = (char *(*)()) F1135_10528;
	R8260[20] = (char *(*)()) F1136_10528;
	R8260[21] = (char *(*)()) F1137_10528;
	R8260[22] = (char *(*)()) F1138_10528;
	R8260[23] = (char *(*)()) F1139_10528;
	R8260[24] = (char *(*)()) F1140_10528;
	R8260[25] = (char *(*)()) F1141_10528;
	R8260[26] = (char *(*)()) F1142_10528;
	R8260[27] = (char *(*)()) F1143_10528;
	R8260[28] = (char *(*)()) F1144_10528;
	R8260[29] = (char *(*)()) F1145_10528;
	R8260[30] = (char *(*)()) F1146_10528;
	R8260[31] = (char *(*)()) F1147_10528;
	R8260[32] = (char *(*)()) F1148_10528;
	R8260[33] = (char *(*)()) F1149_10528;
}

char *(*R8261[34])();
void R8261_init () {
	R8261[0] = (char *(*)()) F1116_10529;
	R8261[1] = (char *(*)()) F1117_10529;
	R8261[2] = (char *(*)()) F1118_10529;
	R8261[3] = (char *(*)()) F1119_10529;
	R8261[4] = (char *(*)()) F1120_10529;
	R8261[5] = (char *(*)()) F1121_10529;
	R8261[6] = (char *(*)()) F1122_10529;
	R8261[7] = (char *(*)()) F1123_10529;
	R8261[8] = (char *(*)()) F1124_10529;
	R8261[9] = (char *(*)()) F1125_10529;
	R8261[10] = (char *(*)()) F1126_10529;
	R8261[11] = (char *(*)()) F1127_10529;
	R8261[12] = (char *(*)()) F1128_10529;
	R8261[13] = (char *(*)()) F1129_10529;
	R8261[14] = (char *(*)()) F1130_10529;
	R8261[15] = (char *(*)()) F1131_10529;
	R8261[16] = (char *(*)()) F1132_10529;
	R8261[17] = (char *(*)()) F1133_10529;
	R8261[18] = (char *(*)()) F1134_10529;
	R8261[19] = (char *(*)()) F1135_10529;
	R8261[20] = (char *(*)()) F1136_10529;
	R8261[21] = (char *(*)()) F1137_10529;
	R8261[22] = (char *(*)()) F1138_10529;
	R8261[23] = (char *(*)()) F1139_10529;
	R8261[24] = (char *(*)()) F1140_10529;
	R8261[25] = (char *(*)()) F1141_10529;
	R8261[26] = (char *(*)()) F1142_10529;
	R8261[27] = (char *(*)()) F1143_10529;
	R8261[28] = (char *(*)()) F1144_10529;
	R8261[29] = (char *(*)()) F1145_10529;
	R8261[30] = (char *(*)()) F1146_10529;
	R8261[31] = (char *(*)()) F1147_10529;
	R8261[32] = (char *(*)()) F1148_10529;
	R8261[33] = (char *(*)()) F1149_10529;
}

char *(*R8263[34])();
void R8263_init () {
	R8263[0] = (char *(*)()) F1116_10531;
	R8263[1] = (char *(*)()) F1117_10531;
	R8263[2] = (char *(*)()) F1118_10531;
	R8263[3] = (char *(*)()) F1119_10531;
	R8263[4] = (char *(*)()) F1120_10531;
	R8263[5] = (char *(*)()) F1121_10531;
	R8263[6] = (char *(*)()) F1122_10531;
	R8263[7] = (char *(*)()) F1123_10531;
	R8263[8] = (char *(*)()) F1124_10531;
	R8263[9] = (char *(*)()) F1125_10531;
	R8263[10] = (char *(*)()) F1126_10531;
	R8263[11] = (char *(*)()) F1127_10531;
	R8263[12] = (char *(*)()) F1128_10531;
	R8263[13] = (char *(*)()) F1129_10531;
	R8263[14] = (char *(*)()) F1130_10531;
	R8263[15] = (char *(*)()) F1131_10531;
	R8263[16] = (char *(*)()) F1132_10531;
	R8263[17] = (char *(*)()) F1133_10531;
	R8263[18] = (char *(*)()) F1134_10531;
	R8263[19] = (char *(*)()) F1135_10531;
	R8263[20] = (char *(*)()) F1136_10531;
	R8263[21] = (char *(*)()) F1137_10531;
	R8263[22] = (char *(*)()) F1138_10531;
	R8263[23] = (char *(*)()) F1139_10531;
	R8263[24] = (char *(*)()) F1140_10531;
	R8263[25] = (char *(*)()) F1141_10531;
	R8263[26] = (char *(*)()) F1142_10531;
	R8263[27] = (char *(*)()) F1143_10531;
	R8263[28] = (char *(*)()) F1144_10531;
	R8263[29] = (char *(*)()) F1145_10531;
	R8263[30] = (char *(*)()) F1146_10531;
	R8263[31] = (char *(*)()) F1147_10531;
	R8263[32] = (char *(*)()) F1148_10531;
	R8263[33] = (char *(*)()) F1149_10531;
}

char *(*R8268[34])();
void R8268_init () {
	R8268[0] = (char *(*)()) F1116_10537;
	R8268[1] = (char *(*)()) F1117_10537;
	R8268[2] = (char *(*)()) F1118_10537;
	R8268[3] = (char *(*)()) F1119_10537;
	R8268[4] = (char *(*)()) F1120_10537;
	R8268[5] = (char *(*)()) F1121_10537;
	R8268[6] = (char *(*)()) F1122_10537;
	R8268[7] = (char *(*)()) F1123_10537;
	R8268[8] = (char *(*)()) F1124_10537;
	R8268[9] = (char *(*)()) F1125_10537;
	R8268[10] = (char *(*)()) F1126_10537;
	R8268[11] = (char *(*)()) F1127_10537;
	R8268[12] = (char *(*)()) F1128_10537;
	R8268[13] = (char *(*)()) F1129_10537;
	R8268[14] = (char *(*)()) F1130_10537;
	R8268[15] = (char *(*)()) F1131_10537;
	R8268[16] = (char *(*)()) F1132_10537;
	R8268[17] = (char *(*)()) F1133_10537;
	R8268[18] = (char *(*)()) F1134_10537;
	R8268[19] = (char *(*)()) F1135_10537;
	R8268[20] = (char *(*)()) F1136_10537;
	R8268[21] = (char *(*)()) F1137_10537;
	R8268[22] = (char *(*)()) F1138_10537;
	R8268[23] = (char *(*)()) F1139_10537;
	R8268[24] = (char *(*)()) F1140_10537;
	R8268[25] = (char *(*)()) F1141_10537;
	R8268[26] = (char *(*)()) F1142_10537;
	R8268[27] = (char *(*)()) F1143_10537;
	R8268[28] = (char *(*)()) F1144_10537;
	R8268[29] = (char *(*)()) F1145_10537;
	R8268[30] = (char *(*)()) F1146_10537;
	R8268[31] = (char *(*)()) F1147_10537;
	R8268[32] = (char *(*)()) F1148_10537;
	R8268[33] = (char *(*)()) F1149_10537;
}

char *(*R8273[34])();
void R8273_init () {
	R8273[0] = (char *(*)()) F1116_10545;
	R8273[1] = (char *(*)()) F1117_10545_8273_1;
	R8273[2] = (char *(*)()) F1118_10545_8273_1;
	R8273[3] = (char *(*)()) F1119_10545_8273_1;
	R8273[4] = (char *(*)()) F1120_10545_8273_1;
	R8273[5] = (char *(*)()) F1121_10545_8273_1;
	R8273[6] = (char *(*)()) F1122_10545_8273_1;
	R8273[7] = (char *(*)()) F1123_10545_8273_1;
	R8273[8] = (char *(*)()) F1124_10545_8273_1;
	R8273[9] = (char *(*)()) F1125_10545_8273_1;
	R8273[10] = (char *(*)()) F1126_10545_8273_1;
	R8273[11] = (char *(*)()) F1127_10545_8273_1;
	R8273[12] = (char *(*)()) F1128_10545_8273_1;
	R8273[13] = (char *(*)()) F1129_10545_8273_1;
	R8273[14] = (char *(*)()) F1130_10545_8273_1;
	R8273[15] = (char *(*)()) F1131_10545_8273_1;
	R8273[16] = (char *(*)()) F1132_10545;
	R8273[17] = (char *(*)()) F1133_10545;
	R8273[18] = (char *(*)()) F1134_10545;
	R8273[19] = (char *(*)()) F1135_10545_8273_1;
	R8273[20] = (char *(*)()) F1136_10545_8273_1;
	R8273[21] = (char *(*)()) F1137_10545_8273_1;
	R8273[22] = (char *(*)()) F1138_10545_8273_1;
	R8273[23] = (char *(*)()) F1139_10545_8273_1;
	R8273[24] = (char *(*)()) F1140_10545_8273_1;
	R8273[25] = (char *(*)()) F1141_10545_8273_1;
	R8273[26] = (char *(*)()) F1142_10545_8273_1;
	R8273[27] = (char *(*)()) F1143_10545_8273_1;
	R8273[28] = (char *(*)()) F1144_10545_8273_1;
	R8273[29] = (char *(*)()) F1145_10545_8273_1;
	R8273[30] = (char *(*)()) F1146_10545_8273_1;
	R8273[31] = (char *(*)()) F1147_10545_8273_1;
	R8273[32] = (char *(*)()) F1148_10545_8273_1;
	R8273[33] = (char *(*)()) F1149_10545;
}
static EIF_REFERENCE F1117_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1117_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1118_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1118_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1053,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1053, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1119_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1119_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1120_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1120_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1121_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1121_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1122_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1122_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1123_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1123_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1124_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1124_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1125_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1125_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1126_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1126_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1127_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1127_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1128_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1128_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1226, 0x00).id, 1226, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1129_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1129_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1130_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1130_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1131_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1131_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1135_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1135_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1055,1235,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1055, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1136_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1136_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1057,1229,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1057, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1137_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1137_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1059,1247,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1059, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1138_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1138_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1061,1238,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1061, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1139_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1139_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1063,1253,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1063, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1140_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1140_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1065,1048,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1065, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1141_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1141_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1067,1042,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1067, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1142_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1142_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1069,1083,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1069, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1143_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1143_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,1226,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1071, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1144_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1144_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1073,1241,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1073, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1145_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1145_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1075,1244,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1075, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1146_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1146_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1077,1232,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1077, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1147_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1079,1250,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1079, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_10545_8273_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1148_10545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1081,1045,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1081, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}

char *(*R8283[34])();
void R8283_init () {
	R8283[0] = (char *(*)()) F1116_10557;
	R8283[1] = (char *(*)()) F1117_10557;
	R8283[2] = (char *(*)()) F1118_10557;
	R8283[3] = (char *(*)()) F1119_10557;
	R8283[4] = (char *(*)()) F1120_10557;
	R8283[5] = (char *(*)()) F1121_10557;
	R8283[6] = (char *(*)()) F1122_10557;
	R8283[7] = (char *(*)()) F1123_10557;
	R8283[8] = (char *(*)()) F1124_10557;
	R8283[9] = (char *(*)()) F1125_10557;
	R8283[10] = (char *(*)()) F1126_10557;
	R8283[11] = (char *(*)()) F1127_10557;
	R8283[12] = (char *(*)()) F1128_10557;
	R8283[13] = (char *(*)()) F1129_10557;
	R8283[14] = (char *(*)()) F1130_10557;
	R8283[15] = (char *(*)()) F1131_10557;
	R8283[16] = (char *(*)()) F1132_10557;
	R8283[17] = (char *(*)()) F1133_10557;
	R8283[18] = (char *(*)()) F1134_10557;
	R8283[19] = (char *(*)()) F1135_10557;
	R8283[20] = (char *(*)()) F1136_10557;
	R8283[21] = (char *(*)()) F1137_10557;
	R8283[22] = (char *(*)()) F1138_10557;
	R8283[23] = (char *(*)()) F1139_10557;
	R8283[24] = (char *(*)()) F1140_10557;
	R8283[25] = (char *(*)()) F1141_10557;
	R8283[26] = (char *(*)()) F1142_10557;
	R8283[27] = (char *(*)()) F1143_10557;
	R8283[28] = (char *(*)()) F1144_10557;
	R8283[29] = (char *(*)()) F1145_10557;
	R8283[30] = (char *(*)()) F1146_10557;
	R8283[31] = (char *(*)()) F1147_10557;
	R8283[32] = (char *(*)()) F1148_10557;
	R8283[33] = (char *(*)()) F1149_10557;
}

char *(*R8285[12])();
void R8285_init () {
	R8285[0] = (char *(*)()) F1151_10575;
	R8285[1] = (char *(*)()) F1152_10575;
	R8285[2] = (char *(*)()) F1153_10575;
	R8285[3] = (char *(*)()) F1154_10575;
	R8285[4] = (char *(*)()) F1155_10575;
	R8285[5] = (char *(*)()) F1156_10575;
	R8285[6] = (char *(*)()) F1157_10575;
	R8285[7] = (char *(*)()) F1158_10575;
	R8285[8] = (char *(*)()) F1159_10575;
	R8285[9] = (char *(*)()) F1160_10575;
	R8285[10] = (char *(*)()) F1161_10575;
	R8285[11] = (char *(*)()) F1162_10575;
}

char *(*R8286[12])();
void R8286_init () {
	R8286[0] = (char *(*)()) F1151_10576;
	R8286[1] = (char *(*)()) F1152_10576;
	R8286[2] = (char *(*)()) F1153_10576;
	R8286[3] = (char *(*)()) F1154_10576;
	R8286[4] = (char *(*)()) F1155_10576;
	R8286[5] = (char *(*)()) F1156_10576;
	R8286[6] = (char *(*)()) F1157_10576;
	R8286[7] = (char *(*)()) F1158_10576;
	R8286[8] = (char *(*)()) F1159_10576;
	R8286[9] = (char *(*)()) F1160_10576;
	R8286[10] = (char *(*)()) F1161_10576;
	R8286[11] = (char *(*)()) F1162_10576;
}

char *(*R8288[12])();
void R8288_init () {
	R8288[0] = (char *(*)()) F1151_10562;
	R8288[1] = (char *(*)()) F1152_10562;
	R8288[2] = (char *(*)()) F1153_10562;
	R8288[3] = (char *(*)()) F1154_10562;
	R8288[4] = (char *(*)()) F1155_10562;
	R8288[5] = (char *(*)()) F1156_10562;
	R8288[6] = (char *(*)()) F1157_10562;
	R8288[7] = (char *(*)()) F1158_10562;
	R8288[8] = (char *(*)()) F1159_10562;
	R8288[9] = (char *(*)()) F1160_10562;
	R8288[10] = (char *(*)()) F1161_10562;
	R8288[11] = (char *(*)()) F1162_10562;
}

char *(*R8289[12])();
void R8289_init () {
	R8289[0] = (char *(*)()) F1151_10563;
	R8289[1] = (char *(*)()) F1152_10563_8289_156;
	R8289[2] = (char *(*)()) F1153_10563_8289_156;
	R8289[3] = (char *(*)()) F1154_10563_8289_156;
	R8289[4] = (char *(*)()) F1155_10563_8289_156;
	R8289[5] = (char *(*)()) F1156_10563_8289_156;
	R8289[6] = (char *(*)()) F1157_10563_8289_156;
	R8289[7] = (char *(*)()) F1158_10563_8289_156;
	R8289[8] = (char *(*)()) F1159_10563_8289_156;
	R8289[9] = (char *(*)()) F1160_10563_8289_156;
	R8289[10] = (char *(*)()) F1161_10563_8289_156;
	R8289[11] = (char *(*)()) F1162_10563_8289_156;
}
static void F1152_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_10563(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1153_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1153_10563(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1154_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1154_10563(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1155_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1155_10563(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1156_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1156_10563(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1157_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1157_10563(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1158_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1158_10563(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1159_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1159_10563(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1160_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1160_10563(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F1161_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1161_10563(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1162_10563_8289_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1162_10563(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R8298[12])();
void R8298_init () {
	R8298[0] = (char *(*)()) F1151_10578;
	R8298[1] = (char *(*)()) F1152_10578;
	R8298[2] = (char *(*)()) F1153_10578;
	R8298[3] = (char *(*)()) F1154_10578;
	R8298[4] = (char *(*)()) F1155_10578;
	R8298[5] = (char *(*)()) F1156_10578;
	R8298[6] = (char *(*)()) F1157_10578;
	R8298[7] = (char *(*)()) F1158_10578;
	R8298[8] = (char *(*)()) F1159_10578;
	R8298[9] = (char *(*)()) F1160_10578;
	R8298[10] = (char *(*)()) F1161_10578;
	R8298[11] = (char *(*)()) F1162_10578;
}

char *(*R8299[12])();
void R8299_init () {
	R8299[0] = (char *(*)()) F1151_10580;
	R8299[1] = (char *(*)()) F1152_10580_8299_156;
	R8299[2] = (char *(*)()) F1153_10580_8299_156;
	R8299[3] = (char *(*)()) F1154_10580_8299_156;
	R8299[4] = (char *(*)()) F1155_10580_8299_156;
	R8299[5] = (char *(*)()) F1156_10580_8299_156;
	R8299[6] = (char *(*)()) F1157_10580_8299_156;
	R8299[7] = (char *(*)()) F1158_10580_8299_156;
	R8299[8] = (char *(*)()) F1159_10580_8299_156;
	R8299[9] = (char *(*)()) F1160_10580_8299_156;
	R8299[10] = (char *(*)()) F1161_10580_8299_156;
	R8299[11] = (char *(*)()) F1162_10580_8299_156;
}
static void F1152_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_10580(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1153_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1153_10580(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1154_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1154_10580(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1155_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1155_10580(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1156_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1156_10580(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1157_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1157_10580(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1158_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1158_10580(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1159_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1159_10580(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1160_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1160_10580(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F1161_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1161_10580(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1162_10580_8299_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1162_10580(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R8300[12])();
void R8300_init () {
	R8300[0] = (char *(*)()) F1151_10581;
	R8300[1] = (char *(*)()) F1152_10581_8300_156;
	R8300[2] = (char *(*)()) F1153_10581_8300_156;
	R8300[3] = (char *(*)()) F1154_10581_8300_156;
	R8300[4] = (char *(*)()) F1155_10581_8300_156;
	R8300[5] = (char *(*)()) F1156_10581_8300_156;
	R8300[6] = (char *(*)()) F1157_10581_8300_156;
	R8300[7] = (char *(*)()) F1158_10581_8300_156;
	R8300[8] = (char *(*)()) F1159_10581_8300_156;
	R8300[9] = (char *(*)()) F1160_10581_8300_156;
	R8300[10] = (char *(*)()) F1161_10581_8300_156;
	R8300[11] = (char *(*)()) F1162_10581_8300_156;
}
static void F1152_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_10581(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1153_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1153_10581(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1154_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1154_10581(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1155_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1155_10581(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1156_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1156_10581(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1157_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1157_10581(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1158_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1158_10581(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1159_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1159_10581(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1160_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1160_10581(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F1161_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1161_10581(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1162_10581_8300_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1162_10581(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R8301[12])();
void R8301_init () {
	R8301[0] = (char *(*)()) F1151_10582;
	R8301[1] = (char *(*)()) F1152_10582_8301_4;
	R8301[2] = (char *(*)()) F1153_10582_8301_4;
	R8301[3] = (char *(*)()) F1154_10582_8301_4;
	R8301[4] = (char *(*)()) F1155_10582_8301_4;
	R8301[5] = (char *(*)()) F1156_10582_8301_4;
	R8301[6] = (char *(*)()) F1157_10582_8301_4;
	R8301[7] = (char *(*)()) F1158_10582_8301_4;
	R8301[8] = (char *(*)()) F1159_10582_8301_4;
	R8301[9] = (char *(*)()) F1160_10582_8301_4;
	R8301[10] = (char *(*)()) F1161_10582_8301_4;
	R8301[11] = (char *(*)()) F1162_10582_8301_4;
}
static void F1152_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1152_10582(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1153_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1153_10582(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1154_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1154_10582(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1155_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1155_10582(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1156_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1156_10582(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1157_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1157_10582(Current, *(EIF_POINTER *)arg1);
}
static void F1158_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1158_10582(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1159_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1159_10582(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1160_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1160_10582(Current, *(EIF_REAL_64 *)arg1);
}
static void F1161_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1161_10582(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1162_10582_8301_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1162_10582(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R8302[12])();
void R8302_init () {
	R8302[0] = (char *(*)()) F1151_10583;
	R8302[1] = (char *(*)()) F1152_10583_8302_4;
	R8302[2] = (char *(*)()) F1153_10583_8302_4;
	R8302[3] = (char *(*)()) F1154_10583_8302_4;
	R8302[4] = (char *(*)()) F1155_10583_8302_4;
	R8302[5] = (char *(*)()) F1156_10583_8302_4;
	R8302[6] = (char *(*)()) F1157_10583_8302_4;
	R8302[7] = (char *(*)()) F1158_10583_8302_4;
	R8302[8] = (char *(*)()) F1159_10583_8302_4;
	R8302[9] = (char *(*)()) F1160_10583_8302_4;
	R8302[10] = (char *(*)()) F1161_10583_8302_4;
	R8302[11] = (char *(*)()) F1162_10583_8302_4;
}
static void F1152_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1152_10583(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1153_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1153_10583(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1154_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1154_10583(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1155_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1155_10583(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1156_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1156_10583(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1157_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1157_10583(Current, *(EIF_POINTER *)arg1);
}
static void F1158_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1158_10583(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1159_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1159_10583(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1160_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1160_10583(Current, *(EIF_REAL_64 *)arg1);
}
static void F1161_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1161_10583(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1162_10583_8302_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1162_10583(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R8303[12])();
void R8303_init () {
	R8303[0] = (char *(*)()) F1151_10584;
	R8303[1] = (char *(*)()) F1152_10584_8303_57;
	R8303[2] = (char *(*)()) F1153_10584_8303_57;
	R8303[3] = (char *(*)()) F1154_10584_8303_57;
	R8303[4] = (char *(*)()) F1155_10584_8303_57;
	R8303[5] = (char *(*)()) F1156_10584_8303_57;
	R8303[6] = (char *(*)()) F1157_10584_8303_57;
	R8303[7] = (char *(*)()) F1158_10584_8303_57;
	R8303[8] = (char *(*)()) F1159_10584_8303_57;
	R8303[9] = (char *(*)()) F1160_10584_8303_57;
	R8303[10] = (char *(*)()) F1161_10584_8303_57;
	R8303[11] = (char *(*)()) F1162_10584_8303_57;
}
static void F1152_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1152_10584(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1153_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1153_10584(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1154_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1154_10584(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1155_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1155_10584(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1156_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1156_10584(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1157_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1157_10584(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1158_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1158_10584(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1159_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1159_10584(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1160_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1160_10584(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F1161_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1161_10584(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1162_10584_8303_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1162_10584(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}

char *(*R8304[12])();
void R8304_init () {
	R8304[0] = (char *(*)()) F1151_10585;
	R8304[1] = (char *(*)()) F1152_10585;
	R8304[2] = (char *(*)()) F1153_10585;
	R8304[3] = (char *(*)()) F1154_10585;
	R8304[4] = (char *(*)()) F1155_10585;
	R8304[5] = (char *(*)()) F1156_10585;
	R8304[6] = (char *(*)()) F1157_10585;
	R8304[7] = (char *(*)()) F1158_10585;
	R8304[8] = (char *(*)()) F1159_10585;
	R8304[9] = (char *(*)()) F1160_10585;
	R8304[10] = (char *(*)()) F1161_10585;
	R8304[11] = (char *(*)()) F1162_10585;
}

char *(*R8306[12])();
void R8306_init () {
	R8306[0] = (char *(*)()) F1151_10587;
	R8306[1] = (char *(*)()) F1152_10587;
	R8306[2] = (char *(*)()) F1153_10587;
	R8306[3] = (char *(*)()) F1154_10587;
	R8306[4] = (char *(*)()) F1155_10587;
	R8306[5] = (char *(*)()) F1156_10587;
	R8306[6] = (char *(*)()) F1157_10587;
	R8306[7] = (char *(*)()) F1158_10587;
	R8306[8] = (char *(*)()) F1159_10587;
	R8306[9] = (char *(*)()) F1160_10587;
	R8306[10] = (char *(*)()) F1161_10587;
	R8306[11] = (char *(*)()) F1162_10587;
}

char *(*R8307[12])();
void R8307_init () {
	R8307[0] = (char *(*)()) F1151_10588;
	R8307[1] = (char *(*)()) F1152_10588;
	R8307[2] = (char *(*)()) F1153_10588;
	R8307[3] = (char *(*)()) F1154_10588;
	R8307[4] = (char *(*)()) F1155_10588;
	R8307[5] = (char *(*)()) F1156_10588;
	R8307[6] = (char *(*)()) F1157_10588;
	R8307[7] = (char *(*)()) F1158_10588;
	R8307[8] = (char *(*)()) F1159_10588;
	R8307[9] = (char *(*)()) F1160_10588;
	R8307[10] = (char *(*)()) F1161_10588;
	R8307[11] = (char *(*)()) F1162_10588;
}

char *(*R8308[12])();
void R8308_init () {
	R8308[0] = (char *(*)()) F1151_10589;
	R8308[1] = (char *(*)()) F1152_10589;
	R8308[2] = (char *(*)()) F1153_10589;
	R8308[3] = (char *(*)()) F1154_10589;
	R8308[4] = (char *(*)()) F1155_10589;
	R8308[5] = (char *(*)()) F1156_10589;
	R8308[6] = (char *(*)()) F1157_10589;
	R8308[7] = (char *(*)()) F1158_10589;
	R8308[8] = (char *(*)()) F1159_10589;
	R8308[9] = (char *(*)()) F1160_10589;
	R8308[10] = (char *(*)()) F1161_10589;
	R8308[11] = (char *(*)()) F1162_10589;
}

char *(*R8309[12])();
void R8309_init () {
	R8309[0] = (char *(*)()) F1151_10590;
	R8309[1] = (char *(*)()) F1152_10590;
	R8309[2] = (char *(*)()) F1153_10590;
	R8309[3] = (char *(*)()) F1154_10590;
	R8309[4] = (char *(*)()) F1155_10590;
	R8309[5] = (char *(*)()) F1156_10590;
	R8309[6] = (char *(*)()) F1157_10590;
	R8309[7] = (char *(*)()) F1158_10590;
	R8309[8] = (char *(*)()) F1159_10590;
	R8309[9] = (char *(*)()) F1160_10590;
	R8309[10] = (char *(*)()) F1161_10590;
	R8309[11] = (char *(*)()) F1162_10590;
}

char *(*R8310[12])();
void R8310_init () {
	R8310[0] = (char *(*)()) F1151_10591;
	R8310[1] = (char *(*)()) F1152_10591;
	R8310[2] = (char *(*)()) F1153_10591;
	R8310[3] = (char *(*)()) F1154_10591;
	R8310[4] = (char *(*)()) F1155_10591;
	R8310[5] = (char *(*)()) F1156_10591;
	R8310[6] = (char *(*)()) F1157_10591;
	R8310[7] = (char *(*)()) F1158_10591;
	R8310[8] = (char *(*)()) F1159_10591;
	R8310[9] = (char *(*)()) F1160_10591;
	R8310[10] = (char *(*)()) F1161_10591;
	R8310[11] = (char *(*)()) F1162_10591;
}

char *(*R8313[12])();
void R8313_init () {
	R8313[0] = (char *(*)()) F1151_10594;
	R8313[1] = (char *(*)()) F1152_10594;
	R8313[2] = (char *(*)()) F1153_10594;
	R8313[3] = (char *(*)()) F1154_10594;
	R8313[4] = (char *(*)()) F1155_10594;
	R8313[5] = (char *(*)()) F1156_10594;
	R8313[6] = (char *(*)()) F1157_10594;
	R8313[7] = (char *(*)()) F1158_10594;
	R8313[8] = (char *(*)()) F1159_10594;
	R8313[9] = (char *(*)()) F1160_10594;
	R8313[10] = (char *(*)()) F1161_10594;
	R8313[11] = (char *(*)()) F1162_10594;
}

char *(*R8316[12])();
void R8316_init () {
	R8316[0] = (char *(*)()) F1151_10597;
	R8316[1] = (char *(*)()) F1152_10597;
	R8316[2] = (char *(*)()) F1153_10597;
	R8316[3] = (char *(*)()) F1154_10597;
	R8316[4] = (char *(*)()) F1155_10597;
	R8316[5] = (char *(*)()) F1156_10597;
	R8316[6] = (char *(*)()) F1157_10597;
	R8316[7] = (char *(*)()) F1158_10597;
	R8316[8] = (char *(*)()) F1159_10597;
	R8316[9] = (char *(*)()) F1160_10597;
	R8316[10] = (char *(*)()) F1161_10597;
	R8316[11] = (char *(*)()) F1162_10597;
}

char *(*R8317[12])();
void R8317_init () {
	R8317[0] = (char *(*)()) F1151_10598;
	R8317[1] = (char *(*)()) F1152_10598_8317_8;
	R8317[2] = (char *(*)()) F1153_10598_8317_8;
	R8317[3] = (char *(*)()) F1154_10598_8317_8;
	R8317[4] = (char *(*)()) F1155_10598_8317_8;
	R8317[5] = (char *(*)()) F1156_10598_8317_8;
	R8317[6] = (char *(*)()) F1157_10598_8317_8;
	R8317[7] = (char *(*)()) F1158_10598_8317_8;
	R8317[8] = (char *(*)()) F1159_10598_8317_8;
	R8317[9] = (char *(*)()) F1160_10598_8317_8;
	R8317[10] = (char *(*)()) F1161_10598_8317_8;
	R8317[11] = (char *(*)()) F1162_10598_8317_8;
}
static EIF_REFERENCE F1152_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1152_10598(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1153_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1153_10598(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1154_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1154_10598(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1155_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1155_10598(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1156_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1156_10598(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1157_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1157_10598(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1158_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1158_10598(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1159_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1159_10598(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1160_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1160_10598(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1161_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1161_10598(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1162_10598_8317_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1162_10598(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R8319[12])();
void R8319_init () {
	R8319[0] = (char *(*)()) F1151_10600;
	R8319[1] = (char *(*)()) F1152_10600;
	R8319[2] = (char *(*)()) F1153_10600;
	R8319[3] = (char *(*)()) F1154_10600;
	R8319[4] = (char *(*)()) F1155_10600;
	R8319[5] = (char *(*)()) F1156_10600;
	R8319[6] = (char *(*)()) F1157_10600;
	R8319[7] = (char *(*)()) F1158_10600;
	R8319[8] = (char *(*)()) F1159_10600;
	R8319[9] = (char *(*)()) F1160_10600;
	R8319[10] = (char *(*)()) F1161_10600;
	R8319[11] = (char *(*)()) F1162_10600;
}

char *(*R8321[12])();
void R8321_init () {
	R8321[0] = (char *(*)()) F1151_10602;
	R8321[1] = (char *(*)()) F1152_10602;
	R8321[2] = (char *(*)()) F1153_10602;
	R8321[3] = (char *(*)()) F1154_10602;
	R8321[4] = (char *(*)()) F1155_10602;
	R8321[5] = (char *(*)()) F1156_10602;
	R8321[6] = (char *(*)()) F1157_10602;
	R8321[7] = (char *(*)()) F1158_10602;
	R8321[8] = (char *(*)()) F1159_10602;
	R8321[9] = (char *(*)()) F1160_10602;
	R8321[10] = (char *(*)()) F1161_10602;
	R8321[11] = (char *(*)()) F1162_10602;
}

char *(*R8323[12])();
void R8323_init () {
	R8323[0] = (char *(*)()) F1151_10604;
	R8323[1] = (char *(*)()) F1152_10604;
	R8323[2] = (char *(*)()) F1153_10604;
	R8323[3] = (char *(*)()) F1154_10604;
	R8323[4] = (char *(*)()) F1155_10604;
	R8323[5] = (char *(*)()) F1156_10604;
	R8323[6] = (char *(*)()) F1157_10604;
	R8323[7] = (char *(*)()) F1158_10604;
	R8323[8] = (char *(*)()) F1159_10604;
	R8323[9] = (char *(*)()) F1160_10604;
	R8323[10] = (char *(*)()) F1161_10604;
	R8323[11] = (char *(*)()) F1162_10604;
}

char *(*R8324[12])();
void R8324_init () {
	R8324[0] = (char *(*)()) F1151_10605;
	R8324[1] = (char *(*)()) F1152_10605;
	R8324[2] = (char *(*)()) F1153_10605;
	R8324[3] = (char *(*)()) F1154_10605;
	R8324[4] = (char *(*)()) F1155_10605;
	R8324[5] = (char *(*)()) F1156_10605;
	R8324[6] = (char *(*)()) F1157_10605;
	R8324[7] = (char *(*)()) F1158_10605;
	R8324[8] = (char *(*)()) F1159_10605;
	R8324[9] = (char *(*)()) F1160_10605;
	R8324[10] = (char *(*)()) F1161_10605;
	R8324[11] = (char *(*)()) F1162_10605;
}

char *(*R8328[12])();
void R8328_init () {
	R8328[0] = (char *(*)()) F1151_10610;
	R8328[1] = (char *(*)()) F1152_10610;
	R8328[2] = (char *(*)()) F1153_10610;
	R8328[3] = (char *(*)()) F1154_10610;
	R8328[4] = (char *(*)()) F1155_10610;
	R8328[5] = (char *(*)()) F1156_10610;
	R8328[6] = (char *(*)()) F1157_10610;
	R8328[7] = (char *(*)()) F1158_10610;
	R8328[8] = (char *(*)()) F1159_10610;
	R8328[9] = (char *(*)()) F1160_10610;
	R8328[10] = (char *(*)()) F1161_10610;
	R8328[11] = (char *(*)()) F1162_10610;
}

char *(*R8332[7])();
void R8332_init () {
	{long i; for (i = 0; i < 3; i++) R8332[i] = (char *(*)()) F1163_10614;}
	R8332[4] = (char *(*)()) F1170_10750;
	{long i; for (i = 5; i < 7; i++) R8332[i] = (char *(*)()) F1163_10614;}
}

char *(*R8334[7])();
void R8334_init () {
	{long i; for (i = 0; i < 3; i++) R8334[i] = (char *(*)()) F1163_10616;}
	R8334[4] = (char *(*)()) F1163_10616;
	{long i; for (i = 5; i < 7; i++) R8334[i] = (char *(*)()) F1171_10778;}
}

char *(*R8336[7])();
void R8336_init () {
	{long i; for (i = 0; i < 3; i++) R8336[i] = (char *(*)()) F1163_10618;}
	R8336[4] = (char *(*)()) F1170_10751;
	{long i; for (i = 5; i < 7; i++) R8336[i] = (char *(*)()) F1163_10618;}
}

char *(*R8339[7])();
void R8339_init () {
	R8339[0] = (char *(*)()) F1163_10621;
	R8339[1] = (char *(*)()) F1167_10732;
	R8339[2] = (char *(*)()) F1163_10621;
	{long i; for (i = 4; i < 7; i++) R8339[i] = (char *(*)()) F1163_10621;}
}

char *(*R8347[7])();
void R8347_init () {
	{long i; for (i = 0; i < 3; i++) R8347[i] = (char *(*)()) F1166_10708;}
	R8347[4] = (char *(*)()) F1170_10754;
	{long i; for (i = 5; i < 7; i++) R8347[i] = (char *(*)()) F1171_10779;}
}

char *(*R8359[7])();
void R8359_init () {
	{long i; for (i = 0; i < 3; i++) R8359[i] = (char *(*)()) F1166_10704;}
	R8359[4] = (char *(*)()) F1170_10763;
	{long i; for (i = 5; i < 7; i++) R8359[i] = (char *(*)()) F1171_10784;}
}

char *(*R8360[7])();
void R8360_init () {
	{long i; for (i = 0; i < 3; i++) R8360[i] = (char *(*)()) F1166_10705;}
	R8360[4] = (char *(*)()) F1170_10764;
	{long i; for (i = 5; i < 7; i++) R8360[i] = (char *(*)()) F1163_10643;}
}

char *(*R8506[37])();
void R8506_init () {
	R8506[0] = (char *(*)()) F1220_10878;
	R8506[1] = (char *(*)()) F1221_10883;
	R8506[2] = (char *(*)()) F1222_10901;
	R8506[3] = (char *(*)()) F1223_10927;
	R8506[35] = (char *(*)()) F1255_11864;
	R8506[36] = (char *(*)()) F1256_11907;
}

char *(*R8565[29])();
void R8565_init () {
	R8565[0] = (char *(*)()) F1226_11029_8565_1;
	R8565[1] = (char *(*)()) F1227_11029_8565_1;
	R8565[3] = (char *(*)()) F1229_11128_8565_1;
	R8565[4] = (char *(*)()) F1230_11128_8565_1;
	R8565[6] = (char *(*)()) F1232_11227_8565_1;
	R8565[7] = (char *(*)()) F1233_11227_8565_1;
	R8565[9] = (char *(*)()) F1235_11326_8565_1;
	R8565[10] = (char *(*)()) F1236_11326_8565_1;
	R8565[27] = (char *(*)()) F1253_11849_8565_1;
	R8565[28] = (char *(*)()) F1254_11849_8565_1;
}
static EIF_REFERENCE F1226_11029_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1226_11029(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1226, 0x00).id, 1226, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_11029_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1227_11029(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1226, 0x00).id, 1226, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1229_11128_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1229_11128(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1230_11128_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1230_11128(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1232_11227_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1232_11227(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1233_11227_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1233_11227(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1235_11326_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1235_11326(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1236_11326_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1236_11326(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1253_11849_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1253_11849(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1254_11849_8565_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1254_11849(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R8584[2])();
void R8584_init () {
	R8584[0] = (char *(*)()) F1226_11035;
	R8584[1] = (char *(*)()) F1227_11035;
}

char *(*R8585[2])();
void R8585_init () {
	R8585[0] = (char *(*)()) F1226_11036;
	R8585[1] = (char *(*)()) F1227_11036;
}

char *(*R8588[2])();
void R8588_init () {
	R8588[0] = (char *(*)()) F1226_11039;
	R8588[1] = (char *(*)()) F1227_11039;
}

char *(*R8638[2])();
void R8638_init () {
	R8638[0] = (char *(*)()) F1229_11132;
	R8638[1] = (char *(*)()) F1230_11132;
}

char *(*R8639[2])();
void R8639_init () {
	R8639[0] = (char *(*)()) F1229_11133;
	R8639[1] = (char *(*)()) F1230_11133;
}

char *(*R8640[2])();
void R8640_init () {
	R8640[0] = (char *(*)()) F1229_11134;
	R8640[1] = (char *(*)()) F1230_11134;
}

char *(*R8641[2])();
void R8641_init () {
	R8641[0] = (char *(*)()) F1229_11135;
	R8641[1] = (char *(*)()) F1230_11135;
}

char *(*R8645[2])();
void R8645_init () {
	R8645[0] = (char *(*)()) F1229_11139;
	R8645[1] = (char *(*)()) F1230_11139;
}

char *(*R8697[2])();
void R8697_init () {
	R8697[0] = (char *(*)()) F1232_11234;
	R8697[1] = (char *(*)()) F1233_11234;
}

char *(*R8700[2])();
void R8700_init () {
	R8700[0] = (char *(*)()) F1232_11237;
	R8700[1] = (char *(*)()) F1233_11237;
}

char *(*R8750[2])();
void R8750_init () {
	R8750[0] = (char *(*)()) F1235_11330;
	R8750[1] = (char *(*)()) F1236_11330;
}

char *(*R8753[2])();
void R8753_init () {
	R8753[0] = (char *(*)()) F1235_11333;
	R8753[1] = (char *(*)()) F1236_11333;
}

char *(*R8756[2])();
void R8756_init () {
	R8756[0] = (char *(*)()) F1235_11336;
	R8756[1] = (char *(*)()) F1236_11336;
}

char *(*R8810[2])();
void R8810_init () {
	R8810[0] = (char *(*)()) F1238_11430;
	R8810[1] = (char *(*)()) F1239_11430;
}

char *(*R8856[2])();
void R8856_init () {
	R8856[0] = (char *(*)()) F1241_11518;
	R8856[1] = (char *(*)()) F1242_11518;
}

char *(*R8857[2])();
void R8857_init () {
	R8857[0] = (char *(*)()) F1241_11519;
	R8857[1] = (char *(*)()) F1242_11519;
}

char *(*R8859[2])();
void R8859_init () {
	R8859[0] = (char *(*)()) F1241_11521;
	R8859[1] = (char *(*)()) F1242_11521;
}

char *(*R8862[2])();
void R8862_init () {
	R8862[0] = (char *(*)()) F1241_11524;
	R8862[1] = (char *(*)()) F1242_11524;
}

char *(*R8863[2])();
void R8863_init () {
	R8863[0] = (char *(*)()) F1241_11525;
	R8863[1] = (char *(*)()) F1242_11525;
}

char *(*R8911[2])();
void R8911_init () {
	R8911[0] = (char *(*)()) F1244_11615;
	R8911[1] = (char *(*)()) F1245_11615;
}

char *(*R8912[2])();
void R8912_init () {
	R8912[0] = (char *(*)()) F1244_11616;
	R8912[1] = (char *(*)()) F1245_11616;
}

char *(*R8915[2])();
void R8915_init () {
	R8915[0] = (char *(*)()) F1244_11619;
	R8915[1] = (char *(*)()) F1245_11619;
}

char *(*R8963[2])();
void R8963_init () {
	R8963[0] = (char *(*)()) F1247_11709;
	R8963[1] = (char *(*)()) F1248_11709;
}

char *(*R8964[2])();
void R8964_init () {
	R8964[0] = (char *(*)()) F1247_11710;
	R8964[1] = (char *(*)()) F1248_11710;
}

char *(*R8965[2])();
void R8965_init () {
	R8965[0] = (char *(*)()) F1247_11711;
	R8965[1] = (char *(*)()) F1248_11711;
}

char *(*R8966[2])();
void R8966_init () {
	R8966[0] = (char *(*)()) F1247_11712;
	R8966[1] = (char *(*)()) F1248_11712;
}

char *(*R8968[2])();
void R8968_init () {
	R8968[0] = (char *(*)()) F1247_11714;
	R8968[1] = (char *(*)()) F1248_11714;
}

char *(*R9014[2])();
void R9014_init () {
	R9014[0] = (char *(*)()) F1250_11772;
	R9014[1] = (char *(*)()) F1251_11772;
}

char *(*R9048[2])();
void R9048_init () {
	R9048[0] = (char *(*)()) F1253_11838;
	R9048[1] = (char *(*)()) F1254_11838;
}

char *(*R9155[3])();
void R9155_init () {
	R9155[0] = (char *(*)()) F1267_11964;
	R9155[1] = (char *(*)()) F1268_11964;
	R9155[2] = (char *(*)()) F1269_11964;
}

char *(*R9157[3])();
void R9157_init () {
	R9157[0] = (char *(*)()) F1267_11966;
	R9157[1] = (char *(*)()) F1268_11966_9157_2;
	R9157[2] = (char *(*)()) F1269_11966_9157_2;
}
static EIF_BOOLEAN F1268_11966_9157_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1268_11966(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1269_11966_9157_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1269_11966(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R9162[3])();
void R9162_init () {
	R9162[0] = (char *(*)()) F1267_11971;
	R9162[1] = (char *(*)()) F1268_11971_9162_1;
	R9162[2] = (char *(*)()) F1269_11971_9162_1;
}
static EIF_REFERENCE F1268_11971_9162_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1268_11971(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1269_11971_9162_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1269_11971(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R9166[3])();
void R9166_init () {
	R9166[0] = (char *(*)()) F1267_11977;
	R9166[1] = (char *(*)()) F1268_11977_9166_3;
	R9166[2] = (char *(*)()) F1269_11977_9166_3;
}
static EIF_BOOLEAN F1268_11977_9166_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1268_11977(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}
static EIF_BOOLEAN F1269_11977_9166_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1269_11977(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R9167[3])();
void R9167_init () {
	R9167[0] = (char *(*)()) F1267_11978;
	R9167[1] = (char *(*)()) F1268_11978_9167_4;
	R9167[2] = (char *(*)()) F1269_11978_9167_4;
}
static void F1268_11978_9167_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1268_11978(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1269_11978_9167_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1269_11978(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R9175[3])();
void R9175_init () {
	R9175[0] = (char *(*)()) F1267_11986;
	R9175[1] = (char *(*)()) F1268_11986;
	R9175[2] = (char *(*)()) F1269_11986;
}

char *(*R9177[3])();
void R9177_init () {
	R9177[0] = (char *(*)()) F1267_11989;
	R9177[1] = (char *(*)()) F1268_11989;
	R9177[2] = (char *(*)()) F1269_11989;
}

char *(*R9180[3])();
void R9180_init () {
	R9180[0] = (char *(*)()) F1267_11992;
	R9180[1] = (char *(*)()) F1268_11992_9180_4;
	R9180[2] = (char *(*)()) F1269_11992_9180_4;
}
static void F1268_11992_9180_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1268_11992(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1269_11992_9180_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1269_11992(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R9181[3])();
void R9181_init () {
	R9181[0] = (char *(*)()) F1267_11993;
	R9181[1] = (char *(*)()) F1268_11993;
	R9181[2] = (char *(*)()) F1269_11993;
}

char *(*R9183[3])();
void R9183_init () {
	R9183[0] = (char *(*)()) F1267_11995;
	R9183[1] = (char *(*)()) F1268_11995;
	R9183[2] = (char *(*)()) F1269_11995;
}

char *(*R9184[3])();
void R9184_init () {
	R9184[0] = (char *(*)()) F1267_11996;
	R9184[1] = (char *(*)()) F1268_11996_9184_2;
	R9184[2] = (char *(*)()) F1269_11996_9184_2;
}
static EIF_BOOLEAN F1268_11996_9184_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1268_11996(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1269_11996_9184_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1269_11996(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R9198[3])();
void R9198_init () {
	R9198[0] = (char *(*)()) F1267_12010;
	R9198[1] = (char *(*)()) F1268_12010;
	R9198[2] = (char *(*)()) F1269_12010;
}

char *(*R9199[3])();
void R9199_init () {
	R9199[0] = (char *(*)()) F1267_12011;
	R9199[1] = (char *(*)()) F1268_12011;
	R9199[2] = (char *(*)()) F1269_12011;
}

char *(*R9746[252])();
void R9746_init () {
	R9746[0] = (char *(*)()) F1297_12700;
	{long i; for (i = 1; i < 3; i++) R9746[i] = (char *(*)()) F1298_12728;}
	R9746[251] = (char *(*)()) F1298_12728;
}

char *(*R9751[252])();
void R9751_init () {
	R9751[0] = (char *(*)()) F1297_12701;
	{long i; for (i = 1; i < 3; i++) R9751[i] = (char *(*)()) F1298_12723;}
	R9751[251] = (char *(*)()) F1298_12723;
}

char *(*R9753[252])();
void R9753_init () {
	R9753[0] = (char *(*)()) F1297_12702;
	{long i; for (i = 1; i < 3; i++) R9753[i] = (char *(*)()) F1298_12724;}
	R9753[251] = (char *(*)()) F1298_12724;
}

char *(*R10984[3])();
void R10984_init () {
	{long i; for (i = 0; i < 2; i++) R10984[i] = (char *(*)()) F1339_14133;}
	R10984[2] = (char *(*)()) F1341_14201;
}

static EIF_TYPE_INDEX Y11050_pgtype0[] = {0xFFF5,1,0xFF01,1361,11522,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype1[] = {0xFFF5,1,0xFF01,1361,11522,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype2[] = {0xFFF5,1,0xFF01,1361,11522,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype3[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype4[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype5[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype6[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype7[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype8[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype9[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype10[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype11[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y11050_pgtype12[] = {0xFFF5,1,0xFF01,1341,11050,0xFFFF};
EIF_TYPE_INDEX *Y11050_gen_type [13];
EIF_TYPE_INDEX Y11050 [13];
void Y11050_init (void)
{
	egc_routines_types [11050] = Y11050;
	egc_routines_gen_types [11050] = Y11050_gen_type;
	egc_routines_offset [11050] = 1341;
	Y11050_gen_type [0] = Y11050_pgtype0;
	Y11050_gen_type [1] = Y11050_pgtype1;
	Y11050_gen_type [2] = Y11050_pgtype2;
	Y11050_gen_type [3] = Y11050_pgtype3;
	Y11050_gen_type [4] = Y11050_pgtype4;
	Y11050_gen_type [5] = Y11050_pgtype5;
	Y11050_gen_type [6] = Y11050_pgtype6;
	Y11050_gen_type [7] = Y11050_pgtype7;
	Y11050_gen_type [8] = Y11050_pgtype8;
	Y11050_gen_type [9] = Y11050_pgtype9;
	Y11050_gen_type [10] = Y11050_pgtype10;
	Y11050_gen_type [11] = Y11050_pgtype11;
	Y11050_gen_type [12] = Y11050_pgtype12;
	{long i; for (i = 0; i < 13; i++) Y11050[i] = 1090;};
}

char *(*R13198[181])();
void R13198_init () {
	R13198[0] = (char *(*)()) F1367_16473;
	R13198[1] = (char *(*)()) F1368_16486;
	R13198[2] = (char *(*)()) F1369_16498;
	R13198[3] = (char *(*)()) F1370_16509;
	R13198[4] = (char *(*)()) F1371_16528;
	R13198[5] = (char *(*)()) F1372_16542;
	R13198[6] = (char *(*)()) F1373_16550;
	R13198[7] = (char *(*)()) F1374_16584;
	R13198[8] = (char *(*)()) F1375_16594;
	R13198[9] = (char *(*)()) F1376_16614;
	R13198[10] = (char *(*)()) F1377_16647;
	R13198[11] = (char *(*)()) F1378_16660;
	R13198[12] = (char *(*)()) F1379_16674;
	R13198[13] = (char *(*)()) F1380_16682;
	R13198[14] = (char *(*)()) F1381_16693;
	R13198[15] = (char *(*)()) F1382_16701;
	R13198[16] = (char *(*)()) F1383_16720;
	R13198[17] = (char *(*)()) F1384_16731;
	R13198[18] = (char *(*)()) F1385_16752;
	R13198[19] = (char *(*)()) F1386_16758;
	R13198[20] = (char *(*)()) F1387_16768;
	R13198[23] = (char *(*)()) F1390_16803;
	R13198[24] = (char *(*)()) F1391_16804;
	R13198[26] = (char *(*)()) F1393_16815;
	R13198[27] = (char *(*)()) F1394_16823;
	R13198[28] = (char *(*)()) F1395_16827;
	R13198[29] = (char *(*)()) F1396_16835;
	R13198[31] = (char *(*)()) F1398_16857;
	R13198[32] = (char *(*)()) F1399_16904;
	R13198[34] = (char *(*)()) F1401_16918;
	R13198[35] = (char *(*)()) F1402_16925;
	R13198[37] = (char *(*)()) F1404_16933;
	R13198[39] = (char *(*)()) F1406_16947;
	R13198[40] = (char *(*)()) F1407_16979;
	R13198[41] = (char *(*)()) F1408_16982;
	R13198[42] = (char *(*)()) F1409_16984;
	R13198[44] = (char *(*)()) F1411_16995;
	R13198[45] = (char *(*)()) F1412_17008;
	R13198[47] = (char *(*)()) F1414_17023;
	R13198[48] = (char *(*)()) F1415_17046;
	R13198[49] = (char *(*)()) F1416_17054;
	R13198[51] = (char *(*)()) F1418_17069;
	R13198[52] = (char *(*)()) F1419_17070;
	R13198[53] = (char *(*)()) F1420_17071;
	R13198[54] = (char *(*)()) F1421_17073;
	R13198[56] = (char *(*)()) F1423_17081;
	R13198[57] = (char *(*)()) F1424_17082;
	R13198[58] = (char *(*)()) F1425_17083;
	R13198[59] = (char *(*)()) F1426_17084;
	R13198[60] = (char *(*)()) F1427_17085;
	R13198[62] = (char *(*)()) F1429_17095;
	R13198[64] = (char *(*)()) F1431_17139;
	R13198[65] = (char *(*)()) F1432_17147;
	R13198[66] = (char *(*)()) F1433_17164;
	R13198[67] = (char *(*)()) F1434_17175;
	R13198[68] = (char *(*)()) F1435_17186;
	R13198[69] = (char *(*)()) F1436_17203;
	R13198[70] = (char *(*)()) F1437_17215;
	R13198[71] = (char *(*)()) F1438_17232;
	R13198[72] = (char *(*)()) F1439_17244;
	R13198[73] = (char *(*)()) F1440_17250;
	R13198[74] = (char *(*)()) F1441_17312;
	R13198[75] = (char *(*)()) F1442_17319;
	R13198[76] = (char *(*)()) F1443_17324;
	R13198[77] = (char *(*)()) F1439_17244;
	R13198[78] = (char *(*)()) F1445_17331;
	R13198[79] = (char *(*)()) F1446_17343;
	R13198[80] = (char *(*)()) F1447_17354;
	R13198[81] = (char *(*)()) F1448_17365;
	R13198[83] = (char *(*)()) F1450_17379;
	R13198[84] = (char *(*)()) F1451_17423;
	R13198[85] = (char *(*)()) F1452_17429;
	R13198[86] = (char *(*)()) F1453_17432;
	R13198[87] = (char *(*)()) F1454_17507;
	R13198[88] = (char *(*)()) F1455_17510;
	R13198[89] = (char *(*)()) F1456_17516;
	R13198[91] = (char *(*)()) F1458_17521;
	R13198[92] = (char *(*)()) F1459_17531;
	R13198[93] = (char *(*)()) F1460_17539;
	R13198[94] = (char *(*)()) F1461_17551;
	R13198[95] = (char *(*)()) F1462_17575;
	R13198[96] = (char *(*)()) F1463_17577;
	R13198[97] = (char *(*)()) F1464_17594;
	R13198[98] = (char *(*)()) F1465_17605;
	R13198[99] = (char *(*)()) F1466_17619;
	R13198[100] = (char *(*)()) F1467_17631;
	R13198[101] = (char *(*)()) F1468_17643;
	R13198[102] = (char *(*)()) F1469_17646;
	R13198[103] = (char *(*)()) F1470_17657;
	R13198[105] = (char *(*)()) F1472_17661;
	R13198[106] = (char *(*)()) F1473_17670;
	R13198[107] = (char *(*)()) F1474_17684;
	R13198[108] = (char *(*)()) F1475_17690;
	R13198[109] = (char *(*)()) F1476_17699;
	R13198[110] = (char *(*)()) F1477_17708;
	R13198[111] = (char *(*)()) F1478_17721;
	R13198[112] = (char *(*)()) F1479_17739;
	R13198[114] = (char *(*)()) F1481_17760;
	R13198[115] = (char *(*)()) F1482_17773;
	R13198[116] = (char *(*)()) F1483_17783;
	R13198[117] = (char *(*)()) F1484_17798;
	R13198[118] = (char *(*)()) F1485_17818;
	R13198[119] = (char *(*)()) F1486_17820;
	R13198[120] = (char *(*)()) F1487_17848;
	R13198[121] = (char *(*)()) F1488_17850;
	R13198[122] = (char *(*)()) F1489_17864;
	R13198[123] = (char *(*)()) F1490_17875;
	R13198[124] = (char *(*)()) F1491_17889;
	R13198[125] = (char *(*)()) F1492_17904;
	R13198[126] = (char *(*)()) F1493_17909;
	R13198[127] = (char *(*)()) F1494_17914;
	R13198[129] = (char *(*)()) F1496_17930;
	R13198[130] = (char *(*)()) F1497_17939;
	R13198[131] = (char *(*)()) F1498_17951;
	R13198[132] = (char *(*)()) F1499_17970;
	R13198[134] = (char *(*)()) F1501_17990;
	R13198[135] = (char *(*)()) F1502_17995;
	R13198[136] = (char *(*)()) F1503_17999;
	R13198[137] = (char *(*)()) F1504_18003;
	R13198[138] = (char *(*)()) F1505_18009;
	R13198[140] = (char *(*)()) F1507_18015;
	R13198[141] = (char *(*)()) F1508_18026;
	R13198[142] = (char *(*)()) F1509_18037;
	R13198[143] = (char *(*)()) F1510_18041;
	R13198[144] = (char *(*)()) F1511_18046;
	R13198[145] = (char *(*)()) F1512_18068;
	R13198[146] = (char *(*)()) F1513_18103;
	R13198[147] = (char *(*)()) F1514_18110;
	R13198[148] = (char *(*)()) F1515_18113;
	R13198[149] = (char *(*)()) F1516_18134;
	R13198[150] = (char *(*)()) F1517_18139;
	R13198[151] = (char *(*)()) F1518_18150;
	R13198[153] = (char *(*)()) F1520_18172;
	R13198[154] = (char *(*)()) F1521_18175;
	R13198[155] = (char *(*)()) F1522_18178;
	R13198[156] = (char *(*)()) F1523_18181;
	R13198[157] = (char *(*)()) F1524_18187;
	R13198[158] = (char *(*)()) F1525_18191;
	R13198[159] = (char *(*)()) F1526_18197;
	R13198[160] = (char *(*)()) F1527_18200;
	R13198[161] = (char *(*)()) F1528_18204;
	R13198[162] = (char *(*)()) F1529_18206;
	R13198[163] = (char *(*)()) F1530_18208;
	R13198[165] = (char *(*)()) F1532_18212;
	R13198[166] = (char *(*)()) F1533_18215;
	R13198[167] = (char *(*)()) F1534_18218;
	R13198[168] = (char *(*)()) F1535_18221;
	R13198[170] = (char *(*)()) F1537_18224;
	R13198[171] = (char *(*)()) F1538_18227;
	R13198[172] = (char *(*)()) F1539_18230;
	R13198[173] = (char *(*)()) F1540_18233;
	R13198[174] = (char *(*)()) F1541_18236;
	R13198[175] = (char *(*)()) F1542_18239;
	R13198[176] = (char *(*)()) F1543_18242;
	R13198[177] = (char *(*)()) F1544_18244;
	R13198[178] = (char *(*)()) F1545_18335;
	R13198[179] = (char *(*)()) F1546_18386;
	R13198[180] = (char *(*)()) F1547_18392;
}

char *(*R13213[181])();
void R13213_init () {
	R13213[0] = (char *(*)()) F1367_16479;
	R13213[1] = (char *(*)()) F1368_16494;
	R13213[2] = (char *(*)()) F1369_16503;
	R13213[3] = (char *(*)()) F1370_16524;
	R13213[4] = (char *(*)()) F1371_16536;
	R13213[5] = (char *(*)()) F1372_16545;
	R13213[6] = (char *(*)()) F1373_16566;
	R13213[7] = (char *(*)()) F1374_16590;
	R13213[8] = (char *(*)()) F1375_16609;
	R13213[9] = (char *(*)()) F1376_16631;
	R13213[10] = (char *(*)()) F1377_16653;
	R13213[11] = (char *(*)()) F1378_16667;
	R13213[12] = (char *(*)()) F1379_16677;
	R13213[13] = (char *(*)()) F1380_16684;
	R13213[14] = (char *(*)()) F1381_16695;
	R13213[15] = (char *(*)()) F1382_16707;
	R13213[16] = (char *(*)()) F1383_16722;
	R13213[17] = (char *(*)()) F1384_16747;
	R13213[18] = (char *(*)()) F1385_16754;
	R13213[19] = (char *(*)()) F1386_16764;
	R13213[20] = (char *(*)()) F1387_16773;
	{long i; for (i = 23; i < 25; i++) R13213[i] = (char *(*)()) F1389_16798;}
	{long i; for (i = 26; i < 28; i++) R13213[i] = (char *(*)()) F1393_16818;}
	{long i; for (i = 28; i < 30; i++) R13213[i] = (char *(*)()) F1395_16832;}
	R13213[31] = (char *(*)()) F1398_16874;
	R13213[32] = (char *(*)()) F1399_16907;
	R13213[34] = (char *(*)()) F1401_16921;
	R13213[35] = (char *(*)()) F1402_16930;
	R13213[37] = (char *(*)()) F1404_16939;
	{long i; for (i = 39; i < 43; i++) R13213[i] = (char *(*)()) F1385_16754;}
	{long i; for (i = 44; i < 46; i++) R13213[i] = (char *(*)()) F1411_17004;}
	R13213[47] = (char *(*)()) F1414_17039;
	R13213[48] = (char *(*)()) F1415_17050;
	R13213[49] = (char *(*)()) F1416_17058;
	{long i; for (i = 51; i < 55; i++) R13213[i] = (char *(*)()) F1417_17067;}
	{long i; for (i = 56; i < 61; i++) R13213[i] = (char *(*)()) F1422_17075;}
	R13213[62] = (char *(*)()) F1429_17104;
	R13213[64] = (char *(*)()) F1431_17142;
	R13213[65] = (char *(*)()) F1432_17157;
	R13213[66] = (char *(*)()) F1433_17170;
	R13213[67] = (char *(*)()) F1434_17180;
	R13213[68] = (char *(*)()) F1435_17194;
	R13213[69] = (char *(*)()) F1436_17209;
	{long i; for (i = 70; i < 72; i++) R13213[i] = (char *(*)()) F1437_17223;}
	R13213[72] = (char *(*)()) F1439_17246;
	R13213[73] = (char *(*)()) F1440_17251;
	R13213[74] = (char *(*)()) F1441_17310;
	R13213[75] = (char *(*)()) F1442_17317;
	R13213[76] = (char *(*)()) F1443_17325;
	R13213[77] = (char *(*)()) F1439_17246;
	R13213[78] = (char *(*)()) F1445_17332;
	R13213[79] = (char *(*)()) F1446_17345;
	R13213[80] = (char *(*)()) F1447_17355;
	R13213[81] = (char *(*)()) F1448_17363;
	{long i; for (i = 83; i < 90; i++) R13213[i] = (char *(*)()) F1449_17371;}
	R13213[91] = (char *(*)()) F1458_17526;
	R13213[92] = (char *(*)()) F1459_17534;
	R13213[93] = (char *(*)()) F1460_17547;
	R13213[94] = (char *(*)()) F1461_17571;
	R13213[95] = (char *(*)()) F1388_16787;
	R13213[96] = (char *(*)()) F1463_17590;
	R13213[97] = (char *(*)()) F1464_17601;
	R13213[98] = (char *(*)()) F1465_17615;
	R13213[99] = (char *(*)()) F1466_17628;
	R13213[100] = (char *(*)()) F1467_17641;
	R13213[101] = (char *(*)()) F1449_17371;
	{long i; for (i = 102; i < 104; i++) R13213[i] = (char *(*)()) F1469_17652;}
	R13213[105] = (char *(*)()) F1472_17666;
	R13213[106] = (char *(*)()) F1473_17672;
	R13213[107] = (char *(*)()) F1474_17686;
	R13213[108] = (char *(*)()) F1475_17695;
	R13213[109] = (char *(*)()) F1476_17704;
	R13213[110] = (char *(*)()) F1477_17717;
	R13213[111] = (char *(*)()) F1478_17731;
	R13213[112] = (char *(*)()) F1479_17747;
	R13213[114] = (char *(*)()) F1481_17764;
	R13213[115] = (char *(*)()) F1482_17771;
	R13213[116] = (char *(*)()) F1483_17792;
	R13213[117] = (char *(*)()) F1484_17815;
	R13213[118] = (char *(*)()) F1388_16787;
	R13213[119] = (char *(*)()) F1486_17834;
	R13213[120] = (char *(*)()) F1487_17845;
	R13213[121] = (char *(*)()) F1488_17859;
	R13213[122] = (char *(*)()) F1489_17872;
	R13213[123] = (char *(*)()) F1490_17882;
	R13213[124] = (char *(*)()) F1491_17901;
	{long i; for (i = 125; i < 128; i++) R13213[i] = (char *(*)()) F1449_17371;}
	R13213[129] = (char *(*)()) F1496_17936;
	R13213[130] = (char *(*)()) F1497_17947;
	R13213[131] = (char *(*)()) F1498_17962;
	R13213[132] = (char *(*)()) F1499_17969;
	{long i; for (i = 134; i < 139; i++) R13213[i] = (char *(*)()) F1500_17981;}
	R13213[140] = (char *(*)()) F1507_18021;
	R13213[141] = (char *(*)()) F1508_18027;
	{long i; for (i = 142; i < 144; i++) R13213[i] = (char *(*)()) F1449_17371;}
	R13213[144] = (char *(*)()) F1511_18050;
	R13213[145] = (char *(*)()) F1512_18063;
	{long i; for (i = 146; i < 148; i++) R13213[i] = (char *(*)()) F1449_17371;}
	{long i; for (i = 148; i < 150; i++) R13213[i] = (char *(*)()) F1515_18132;}
	R13213[150] = (char *(*)()) F1449_17371;
	R13213[151] = (char *(*)()) F1518_18148;
	{long i; for (i = 153; i < 164; i++) R13213[i] = (char *(*)()) F1519_18164;}
	{long i; for (i = 165; i < 169; i++) R13213[i] = (char *(*)()) F1519_18164;}
	{long i; for (i = 170; i < 177; i++) R13213[i] = (char *(*)()) F1519_18164;}
	R13213[177] = (char *(*)()) F1544_18312;
	R13213[178] = (char *(*)()) F1545_18341;
	R13213[179] = (char *(*)()) F1546_18389;
	R13213[180] = (char *(*)()) F1547_18409;
}

char *(*R13214[181])();
void R13214_init () {
	R13214[0] = (char *(*)()) F1367_16480;
	R13214[1] = (char *(*)()) F1368_16495;
	R13214[2] = (char *(*)()) F1369_16504;
	R13214[3] = (char *(*)()) F1370_16525;
	R13214[4] = (char *(*)()) F1371_16537;
	R13214[5] = (char *(*)()) F1372_16546;
	R13214[6] = (char *(*)()) F1373_16567;
	R13214[7] = (char *(*)()) F1374_16591;
	R13214[8] = (char *(*)()) F1375_16610;
	R13214[9] = (char *(*)()) F1376_16632;
	R13214[10] = (char *(*)()) F1377_16654;
	R13214[11] = (char *(*)()) F1378_16668;
	R13214[12] = (char *(*)()) F1379_16678;
	R13214[13] = (char *(*)()) F1380_16685;
	R13214[14] = (char *(*)()) F1381_16696;
	R13214[15] = (char *(*)()) F1382_16708;
	R13214[16] = (char *(*)()) F1383_16723;
	R13214[17] = (char *(*)()) F1384_16748;
	R13214[18] = (char *(*)()) F1385_16755;
	R13214[19] = (char *(*)()) F1386_16765;
	R13214[20] = (char *(*)()) F1387_16774;
	{long i; for (i = 23; i < 25; i++) R13214[i] = (char *(*)()) F1389_16799;}
	R13214[26] = (char *(*)()) F1393_16819;
	R13214[27] = (char *(*)()) F1394_16825;
	R13214[28] = (char *(*)()) F1395_16833;
	R13214[29] = (char *(*)()) F1396_16839;
	R13214[31] = (char *(*)()) F1398_16875;
	R13214[32] = (char *(*)()) F1399_16908;
	R13214[34] = (char *(*)()) F1401_16922;
	R13214[35] = (char *(*)()) F1402_16931;
	R13214[37] = (char *(*)()) F1404_16940;
	{long i; for (i = 39; i < 43; i++) R13214[i] = (char *(*)()) F1406_16962;}
	{long i; for (i = 44; i < 46; i++) R13214[i] = (char *(*)()) F1411_17005;}
	R13214[47] = (char *(*)()) F1414_17040;
	R13214[48] = (char *(*)()) F1415_17051;
	R13214[49] = (char *(*)()) F1416_17059;
	{long i; for (i = 51; i < 55; i++) R13214[i] = (char *(*)()) F1417_17068;}
	{long i; for (i = 56; i < 61; i++) R13214[i] = (char *(*)()) F1422_17076;}
	R13214[62] = (char *(*)()) F1429_17105;
	R13214[64] = (char *(*)()) F1431_17143;
	R13214[65] = (char *(*)()) F1432_17158;
	R13214[66] = (char *(*)()) F1433_17171;
	R13214[67] = (char *(*)()) F1434_17181;
	R13214[68] = (char *(*)()) F1435_17195;
	R13214[69] = (char *(*)()) F1436_17210;
	R13214[70] = (char *(*)()) F1437_17224;
	R13214[71] = (char *(*)()) F1438_17235;
	R13214[72] = (char *(*)()) F1439_17247;
	R13214[73] = (char *(*)()) F1440_17252;
	R13214[74] = (char *(*)()) F1441_17311;
	R13214[75] = (char *(*)()) F1442_17318;
	{long i; for (i = 76; i < 78; i++) R13214[i] = (char *(*)()) F1439_17247;}
	R13214[78] = (char *(*)()) F1445_17333;
	R13214[79] = (char *(*)()) F1446_17346;
	R13214[80] = (char *(*)()) F1447_17356;
	R13214[81] = (char *(*)()) F1448_17364;
	{long i; for (i = 83; i < 90; i++) R13214[i] = (char *(*)()) F1449_17372;}
	R13214[91] = (char *(*)()) F1458_17527;
	R13214[92] = (char *(*)()) F1459_17535;
	R13214[93] = (char *(*)()) F1460_17548;
	R13214[94] = (char *(*)()) F1461_17573;
	R13214[95] = (char *(*)()) F1388_16788;
	R13214[96] = (char *(*)()) F1463_17591;
	R13214[97] = (char *(*)()) F1464_17602;
	R13214[98] = (char *(*)()) F1465_17616;
	R13214[99] = (char *(*)()) F1466_17629;
	R13214[100] = (char *(*)()) F1467_17642;
	R13214[101] = (char *(*)()) F1449_17372;
	{long i; for (i = 102; i < 104; i++) R13214[i] = (char *(*)()) F1469_17653;}
	R13214[105] = (char *(*)()) F1472_17667;
	R13214[106] = (char *(*)()) F1473_17673;
	R13214[107] = (char *(*)()) F1474_17687;
	R13214[108] = (char *(*)()) F1475_17696;
	R13214[109] = (char *(*)()) F1476_17705;
	R13214[110] = (char *(*)()) F1477_17718;
	R13214[111] = (char *(*)()) F1478_17732;
	R13214[112] = (char *(*)()) F1479_17748;
	R13214[114] = (char *(*)()) F1481_17765;
	R13214[115] = (char *(*)()) F1482_17772;
	R13214[116] = (char *(*)()) F1483_17793;
	R13214[117] = (char *(*)()) F1484_17816;
	R13214[118] = (char *(*)()) F1388_16788;
	R13214[119] = (char *(*)()) F1486_17835;
	R13214[120] = (char *(*)()) F1487_17846;
	R13214[121] = (char *(*)()) F1488_17860;
	R13214[122] = (char *(*)()) F1489_17873;
	R13214[123] = (char *(*)()) F1490_17883;
	R13214[124] = (char *(*)()) F1491_17902;
	{long i; for (i = 125; i < 128; i++) R13214[i] = (char *(*)()) F1449_17372;}
	R13214[129] = (char *(*)()) F1496_17937;
	R13214[130] = (char *(*)()) F1497_17948;
	{long i; for (i = 131; i < 133; i++) R13214[i] = (char *(*)()) F1498_17963;}
	{long i; for (i = 134; i < 139; i++) R13214[i] = (char *(*)()) F1500_17982;}
	R13214[140] = (char *(*)()) F1507_18022;
	R13214[141] = (char *(*)()) F1406_16962;
	{long i; for (i = 142; i < 152; i++) R13214[i] = (char *(*)()) F1449_17372;}
	{long i; for (i = 153; i < 164; i++) R13214[i] = (char *(*)()) F1519_18165;}
	{long i; for (i = 165; i < 169; i++) R13214[i] = (char *(*)()) F1519_18165;}
	{long i; for (i = 170; i < 177; i++) R13214[i] = (char *(*)()) F1519_18165;}
	R13214[177] = (char *(*)()) F1544_18313;
	R13214[178] = (char *(*)()) F1545_18342;
	R13214[179] = (char *(*)()) F1546_18390;
	R13214[180] = (char *(*)()) F1547_18410;
}

char *(*R13234[181])();
void R13234_init () {
	{long i; for (i = 0; i < 21; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 23; i < 25; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 26; i < 30; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 31; i < 33; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 34; i < 36; i++) R13234[i] = (char *(*)()) F1366_16467;}
	R13234[37] = (char *(*)()) F1366_16467;
	{long i; for (i = 39; i < 43; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 44; i < 46; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 47; i < 50; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 51; i < 55; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 56; i < 61; i++) R13234[i] = (char *(*)()) F1366_16467;}
	R13234[62] = (char *(*)()) F1366_16467;
	{long i; for (i = 64; i < 82; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 83; i < 90; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 91; i < 104; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 105; i < 113; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 114; i < 128; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 129; i < 133; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 134; i < 139; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 140; i < 147; i++) R13234[i] = (char *(*)()) F1366_16467;}
	R13234[147] = (char *(*)()) F1514_18111;
	{long i; for (i = 148; i < 152; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 153; i < 164; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 165; i < 169; i++) R13234[i] = (char *(*)()) F1366_16467;}
	{long i; for (i = 170; i < 181; i++) R13234[i] = (char *(*)()) F1366_16467;}
}

char *(*R13481[2])();
void R13481_init () {
	R13481[0] = (char *(*)()) F1397_16841;
	R13481[1] = (char *(*)()) F1399_16910;
}

char *(*R13578[45])();
void R13578_init () {
	{long i; for (i = 0; i < 2; i++) R13578[i] = (char *(*)()) F1410_16990;}
	R13578[3] = (char *(*)()) F1414_17029;
	{long i; for (i = 4; i < 6; i++) R13578[i] = (char *(*)()) F1410_16990;}
	R13578[44] = (char *(*)()) F1410_16990;
}

char *(*R13660[8])();
void R13660_init () {
	R13660[0] = (char *(*)()) F1430_17129;
	R13660[1] = (char *(*)()) F1432_17148;
	R13660[2] = (char *(*)()) F1433_17163;
	R13660[3] = (char *(*)()) F1434_17174;
	R13660[4] = (char *(*)()) F1430_17129;
	R13660[5] = (char *(*)()) F1436_17201;
	R13660[6] = (char *(*)()) F1430_17129;
	R13660[7] = (char *(*)()) F1438_17230;
}

char *(*R13666[8])();
void R13666_init () {
	R13666[0] = (char *(*)()) F1431_17145;
	R13666[1] = (char *(*)()) F1432_17161;
	R13666[2] = (char *(*)()) F1433_17172;
	R13666[3] = (char *(*)()) F1434_17183;
	R13666[4] = (char *(*)()) F1435_17197;
	R13666[5] = (char *(*)()) F1436_17212;
	R13666[6] = (char *(*)()) F1437_17226;
	R13666[7] = (char *(*)()) F1438_17236;
}

char *(*R13702[2])();
void R13702_init () {
	R13702[0] = (char *(*)()) F1437_17217;
	R13702[1] = (char *(*)()) F1438_17233;
}

char *(*R13816[69])();
void R13816_init () {
	R13816[0] = (char *(*)()) F1450_17381;
	R13816[1] = (char *(*)()) F1449_17374;
	R13816[2] = (char *(*)()) F1452_17427;
	R13816[3] = (char *(*)()) F1453_17433;
	{long i; for (i = 4; i < 6; i++) R13816[i] = (char *(*)()) F1449_17374;}
	R13816[6] = (char *(*)()) F1452_17427;
	R13816[18] = (char *(*)()) F1449_17374;
	{long i; for (i = 42; i < 45; i++) R13816[i] = (char *(*)()) F1449_17374;}
	{long i; for (i = 59; i < 69; i++) R13816[i] = (char *(*)()) F1449_17374;}
}

char *(*R14025[72])();
void R14025_init () {
	{long i; for (i = 0; i < 7; i++) R14025[i] = (char *(*)()) F1471_17659;}
	R14025[7] = (char *(*)()) F1479_17746;
	R14025[9] = (char *(*)()) F1481_17762;
	R14025[10] = (char *(*)()) F1482_17769;
	{long i; for (i = 11; i < 14; i++) R14025[i] = (char *(*)()) F1471_17659;}
	R14025[14] = (char *(*)()) F1486_17821;
	R14025[15] = (char *(*)()) F1487_17843;
	R14025[16] = (char *(*)()) F1488_17851;
	R14025[17] = (char *(*)()) F1489_17863;
	{long i; for (i = 18; i < 21; i++) R14025[i] = (char *(*)()) F1471_17659;}
	R14025[21] = (char *(*)()) F1493_17908;
	R14025[22] = (char *(*)()) F1471_17659;
	{long i; for (i = 24; i < 26; i++) R14025[i] = (char *(*)()) F1471_17659;}
	{long i; for (i = 26; i < 28; i++) R14025[i] = (char *(*)()) F1498_17961;}
	{long i; for (i = 29; i < 34; i++) R14025[i] = (char *(*)()) F1500_17978;}
	R14025[35] = (char *(*)()) F1471_17659;
	R14025[36] = (char *(*)()) F1508_18033;
	{long i; for (i = 37; i < 41; i++) R14025[i] = (char *(*)()) F1471_17659;}
	{long i; for (i = 41; i < 43; i++) R14025[i] = (char *(*)()) F1513_18105;}
	{long i; for (i = 43; i < 47; i++) R14025[i] = (char *(*)()) F1471_17659;}
	{long i; for (i = 48; i < 59; i++) R14025[i] = (char *(*)()) F1519_18161;}
	{long i; for (i = 60; i < 64; i++) R14025[i] = (char *(*)()) F1519_18161;}
	{long i; for (i = 65; i < 72; i++) R14025[i] = (char *(*)()) F1519_18161;}
}

char *(*R14322[24])();
void R14322_init () {
	{long i; for (i = 0; i < 4; i++) R14322[i] = (char *(*)()) F1519_18159;}
	R14322[4] = (char *(*)()) F1524_18184;
	{long i; for (i = 5; i < 11; i++) R14322[i] = (char *(*)()) F1519_18159;}
	{long i; for (i = 12; i < 16; i++) R14322[i] = (char *(*)()) F1519_18159;}
	{long i; for (i = 17; i < 24; i++) R14322[i] = (char *(*)()) F1519_18159;}
}
char *(*R2[1552])();
void R2_init () {}
char *(*R6[1552])();
void R6_init () {}

char *(*R3[1552])();
void R3_init () {
	R3[371] = (char *(*)()) F372_5184;
	R3[435] = (char *(*)()) F436_6101;
	R3[476] = (char *(*)()) F477_6988;
	{long i; for (i = 1006; i < 1008; i++) R3[i] = (char *(*)()) F1005_8492;}
	R3[1269] = (char *(*)()) F1270_12026;
}

char *(*R4[1552])();
void R4_init () {
	{long i; for (i = 1; i < 4; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 5; i < 10; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 11; i < 19; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 20; i < 26; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 27; i < 31; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 32; i < 35; i++) R4[i] = (char *(*)()) F1_15;}
	R4[36] = (char *(*)()) F1_15;
	{long i; for (i = 39; i < 41; i++) R4[i] = (char *(*)()) F1_15;}
	R4[43] = (char *(*)()) F1_15;
	R4[45] = (char *(*)()) F1_15;
	R4[47] = (char *(*)()) F1_15;
	R4[49] = (char *(*)()) F1_15;
	R4[51] = (char *(*)()) F1_15;
	{long i; for (i = 53; i < 57; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 58; i < 73; i++) R4[i] = (char *(*)()) F1_15;}
	R4[74] = (char *(*)()) F1_15;
	{long i; for (i = 77; i < 80; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 92; i < 95; i++) R4[i] = (char *(*)()) F1_15;}
	R4[105] = (char *(*)()) F1_15;
	R4[108] = (char *(*)()) F1_15;
	R4[113] = (char *(*)()) F1_15;
	R4[124] = (char *(*)()) F1_15;
	R4[128] = (char *(*)()) F1_15;
	R4[133] = (char *(*)()) F1_15;
	{long i; for (i = 142; i < 144; i++) R4[i] = (char *(*)()) F1_15;}
	R4[146] = (char *(*)()) F1_15;
	R4[151] = (char *(*)()) F1_15;
	R4[161] = (char *(*)()) F1_15;
	R4[168] = (char *(*)()) F1_15;
	R4[171] = (char *(*)()) F1_15;
	R4[173] = (char *(*)()) F1_15;
	R4[175] = (char *(*)()) F1_15;
	R4[179] = (char *(*)()) F1_15;
	R4[181] = (char *(*)()) F1_15;
	{long i; for (i = 186; i < 189; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 190; i < 202; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 207; i < 209; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 210; i < 212; i++) R4[i] = (char *(*)()) F1_15;}
	R4[216] = (char *(*)()) F1_15;
	R4[223] = (char *(*)()) F1_15;
	{long i; for (i = 225; i < 227; i++) R4[i] = (char *(*)()) F1_15;}
	R4[237] = (char *(*)()) F1_15;
	{long i; for (i = 244; i < 246; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 247; i < 249; i++) R4[i] = (char *(*)()) F1_15;}
	R4[254] = (char *(*)()) F1_15;
	{long i; for (i = 262; i < 266; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 267; i < 272; i++) R4[i] = (char *(*)()) F1_15;}
	R4[276] = (char *(*)()) F1_15;
	R4[281] = (char *(*)()) F1_15;
	R4[283] = (char *(*)()) F1_15;
	R4[288] = (char *(*)()) F1_15;
	R4[293] = (char *(*)()) F1_15;
	{long i; for (i = 295; i < 297; i++) R4[i] = (char *(*)()) F1_15;}
	R4[300] = (char *(*)()) F1_15;
	R4[305] = (char *(*)()) F1_15;
	{long i; for (i = 310; i < 315; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 316; i < 318; i++) R4[i] = (char *(*)()) F1_15;}
	R4[320] = (char *(*)()) F1_15;
	{long i; for (i = 322; i < 328; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 329; i < 332; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 333; i < 335; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 337; i < 339; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 340; i < 343; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 344; i < 348; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 349; i < 351; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 352; i < 358; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 359; i < 363; i++) R4[i] = (char *(*)()) F1_15;}
	R4[364] = (char *(*)()) F1_15;
	R4[371] = (char *(*)()) F372_5103;
	R4[372] = (char *(*)()) F1_15;
	R4[380] = (char *(*)()) F1_15;
	R4[388] = (char *(*)()) F1_15;
	R4[394] = (char *(*)()) F1_15;
	{long i; for (i = 402; i < 404; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 405; i < 412; i++) R4[i] = (char *(*)()) F1_15;}
	R4[426] = (char *(*)()) F1_15;
	R4[428] = (char *(*)()) F1_15;
	{long i; for (i = 430; i < 433; i++) R4[i] = (char *(*)()) F1_15;}
	R4[433] = (char *(*)()) F434_6051;
	R4[435] = (char *(*)()) F1_15;
	{long i; for (i = 437; i < 439; i++) R4[i] = (char *(*)()) F1_15;}
	R4[442] = (char *(*)()) F1_15;
	R4[444] = (char *(*)()) F1_15;
	R4[448] = (char *(*)()) F1_15;
	{long i; for (i = 451; i < 453; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 454; i < 456; i++) R4[i] = (char *(*)()) F1_15;}
	R4[457] = (char *(*)()) F1_15;
	R4[459] = (char *(*)()) F1_15;
	{long i; for (i = 472; i < 477; i++) R4[i] = (char *(*)()) F1_15;}
	R4[501] = (char *(*)()) F1_15;
	{long i; for (i = 527; i < 551; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 563; i < 601; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 754; i < 756; i++) R4[i] = (char *(*)()) F1_15;}
	R4[796] = (char *(*)()) F797_7386;
	R4[832] = (char *(*)()) F1_15;
	R4[845] = (char *(*)()) F846_7491;
	R4[846] = (char *(*)()) F847_7491;
	R4[847] = (char *(*)()) F848_7491;
	R4[848] = (char *(*)()) F849_7491;
	R4[849] = (char *(*)()) F850_7491;
	R4[850] = (char *(*)()) F851_7491;
	R4[851] = (char *(*)()) F852_7491;
	R4[852] = (char *(*)()) F853_7491;
	{long i; for (i = 853; i < 855; i++) R4[i] = (char *(*)()) F846_7491;}
	R4[855] = (char *(*)()) F848_7491;
	R4[856] = (char *(*)()) F852_7491;
	R4[857] = (char *(*)()) F849_7491;
	R4[858] = (char *(*)()) F853_7491;
	R4[871] = (char *(*)()) F872_7593;
	R4[872] = (char *(*)()) F873_7658;
	R4[873] = (char *(*)()) F874_7658;
	R4[874] = (char *(*)()) F875_7658;
	R4[875] = (char *(*)()) F876_7658;
	R4[876] = (char *(*)()) F877_7658;
	R4[877] = (char *(*)()) F878_7658;
	R4[878] = (char *(*)()) F879_7658;
	R4[879] = (char *(*)()) F880_7658;
	R4[880] = (char *(*)()) F881_7658;
	R4[881] = (char *(*)()) F882_7658;
	R4[882] = (char *(*)()) F883_7658;
	R4[883] = (char *(*)()) F884_7658;
	R4[939] = (char *(*)()) F940_7760;
	R4[940] = (char *(*)()) F941_7760;
	R4[941] = (char *(*)()) F942_7760;
	R4[942] = (char *(*)()) F943_7777;
	{long i; for (i = 943; i < 945; i++) R4[i] = (char *(*)()) F940_7760;}
	R4[945] = (char *(*)()) F942_7760;
	R4[946] = (char *(*)()) F941_7760;
	R4[948] = (char *(*)()) F940_7760;
	R4[949] = (char *(*)()) F950_7894;
	R4[950] = (char *(*)()) F951_7894;
	R4[951] = (char *(*)()) F952_7894;
	R4[952] = (char *(*)()) F953_7894;
	R4[953] = (char *(*)()) F954_7894;
	R4[954] = (char *(*)()) F955_7894;
	R4[955] = (char *(*)()) F956_7894;
	R4[956] = (char *(*)()) F957_7894;
	R4[957] = (char *(*)()) F958_7894;
	R4[958] = (char *(*)()) F959_7894;
	R4[959] = (char *(*)()) F960_7894;
	R4[960] = (char *(*)()) F961_7894;
	R4[961] = (char *(*)()) F950_7894;
	R4[963] = (char *(*)()) F950_7894;
	R4[965] = (char *(*)()) F950_7894;
	R4[966] = (char *(*)()) F953_7894;
	R4[967] = (char *(*)()) F954_7894;
	R4[968] = (char *(*)()) F950_7894;
	{long i; for (i = 970; i < 972; i++) R4[i] = (char *(*)()) F950_7894;}
	{long i; for (i = 972; i < 974; i++) R4[i] = (char *(*)()) F953_7894;}
	R4[975] = (char *(*)()) F1_15;
	R4[977] = (char *(*)()) F1_15;
	R4[978] = (char *(*)()) F979_8256;
	R4[979] = (char *(*)()) F980_8292;
	{long i; for (i = 988; i < 997; i++) R4[i] = (char *(*)()) F1_15;}
	R4[999] = (char *(*)()) F1_15;
	{long i; for (i = 1001; i < 1004; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1006; i < 1008; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1015] = (char *(*)()) F1_15;
	{long i; for (i = 1022; i < 1030; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1039] = (char *(*)()) F1_15;
	{long i; for (i = 1041; i < 1043; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1044; i < 1046; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1047; i < 1050; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1052; i < 1084; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1085] = (char *(*)()) F1085_9491;
	R4[1086] = (char *(*)()) F1087_9523;
	R4[1087] = (char *(*)()) F1088_9523;
	R4[1088] = (char *(*)()) F1089_9523;
	R4[1089] = (char *(*)()) F1088_9523;
	R4[1094] = (char *(*)()) F1095_9717;
	R4[1095] = (char *(*)()) F1094_9698;
	R4[1097] = (char *(*)()) F1098_9882;
	R4[1098] = (char *(*)()) F1097_9866;
	{long i; for (i = 1102; i < 1107; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1108] = (char *(*)()) F1_15;
	{long i; for (i = 1110; i < 1114; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1114] = (char *(*)()) F1115_10504;
	{long i; for (i = 1115; i < 1149; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1150; i < 1162; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1165; i < 1168; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1169; i < 1172; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1219; i < 1223; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1225; i < 1227; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1228; i < 1230; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1231; i < 1233; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1234; i < 1236; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1237; i < 1239; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1240; i < 1242; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1243; i < 1245; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1246; i < 1248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1249; i < 1251; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1252; i < 1266; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1266] = (char *(*)()) F1267_11988;
	R4[1267] = (char *(*)()) F1268_11988;
	R4[1268] = (char *(*)()) F1269_11988;
	{long i; for (i = 1269; i < 1271; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1279] = (char *(*)()) F1_15;
	R4[1284] = (char *(*)()) F1_15;
	{long i; for (i = 1293; i < 1295; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1296; i < 1299; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1313; i < 1315; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1316] = (char *(*)()) F1_15;
	{long i; for (i = 1319; i < 1323; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1330] = (char *(*)()) F1_15;
	{long i; for (i = 1338; i < 1341; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1344] = (char *(*)()) F1_15;
	{long i; for (i = 1347; i < 1354; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1355] = (char *(*)()) F1_15;
	R4[1357] = (char *(*)()) F1_15;
	R4[1364] = (char *(*)()) F1_15;
	{long i; for (i = 1366; i < 1387; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1389; i < 1391; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1392; i < 1396; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1397; i < 1399; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1400; i < 1402; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1403] = (char *(*)()) F1_15;
	{long i; for (i = 1405; i < 1409; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1410; i < 1412; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1413; i < 1416; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1417; i < 1421; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1422; i < 1427; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1428] = (char *(*)()) F1_15;
	{long i; for (i = 1430; i < 1438; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1438; i < 1448; i++) R4[i] = (char *(*)()) F950_7894;}
	{long i; for (i = 1449; i < 1456; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1457; i < 1470; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1471; i < 1479; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1480; i < 1494; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1495; i < 1499; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1500; i < 1505; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1506; i < 1518; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1519; i < 1530; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1531; i < 1535; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1536; i < 1548; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1550] = (char *(*)()) F1551_18557;
}

char *(*R5[1552])();
void R5_init () {
	{long i; for (i = 1; i < 4; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 5; i < 10; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 11; i < 19; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 20; i < 26; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 27; i < 31; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 32; i < 35; i++) R5[i] = (char *(*)()) F1_8;}
	R5[36] = (char *(*)()) F1_8;
	{long i; for (i = 39; i < 41; i++) R5[i] = (char *(*)()) F1_8;}
	R5[43] = (char *(*)()) F1_8;
	R5[45] = (char *(*)()) F1_8;
	R5[47] = (char *(*)()) F1_8;
	R5[49] = (char *(*)()) F1_8;
	R5[51] = (char *(*)()) F1_8;
	{long i; for (i = 53; i < 57; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 58; i < 67; i++) R5[i] = (char *(*)()) F1_8;}
	R5[67] = (char *(*)()) F68_860;
	{long i; for (i = 68; i < 73; i++) R5[i] = (char *(*)()) F1_8;}
	R5[74] = (char *(*)()) F1_8;
	{long i; for (i = 77; i < 80; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 92; i < 95; i++) R5[i] = (char *(*)()) F1_8;}
	R5[105] = (char *(*)()) F1_8;
	R5[108] = (char *(*)()) F1_8;
	R5[113] = (char *(*)()) F1_8;
	R5[124] = (char *(*)()) F1_8;
	R5[128] = (char *(*)()) F1_8;
	R5[133] = (char *(*)()) F1_8;
	{long i; for (i = 142; i < 144; i++) R5[i] = (char *(*)()) F1_8;}
	R5[146] = (char *(*)()) F1_8;
	R5[151] = (char *(*)()) F1_8;
	R5[161] = (char *(*)()) F1_8;
	R5[168] = (char *(*)()) F1_8;
	R5[171] = (char *(*)()) F1_8;
	R5[173] = (char *(*)()) F1_8;
	R5[175] = (char *(*)()) F1_8;
	R5[179] = (char *(*)()) F1_8;
	R5[181] = (char *(*)()) F1_8;
	{long i; for (i = 186; i < 189; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 190; i < 202; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 207; i < 209; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 210; i < 212; i++) R5[i] = (char *(*)()) F1_8;}
	R5[216] = (char *(*)()) F1_8;
	R5[223] = (char *(*)()) F1_8;
	{long i; for (i = 225; i < 227; i++) R5[i] = (char *(*)()) F1_8;}
	R5[237] = (char *(*)()) F1_8;
	{long i; for (i = 244; i < 246; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 247; i < 249; i++) R5[i] = (char *(*)()) F1_8;}
	R5[254] = (char *(*)()) F1_8;
	{long i; for (i = 262; i < 266; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 267; i < 272; i++) R5[i] = (char *(*)()) F1_8;}
	R5[276] = (char *(*)()) F1_8;
	R5[281] = (char *(*)()) F1_8;
	R5[283] = (char *(*)()) F1_8;
	R5[288] = (char *(*)()) F1_8;
	R5[293] = (char *(*)()) F1_8;
	{long i; for (i = 295; i < 297; i++) R5[i] = (char *(*)()) F1_8;}
	R5[300] = (char *(*)()) F1_8;
	R5[305] = (char *(*)()) F1_8;
	{long i; for (i = 310; i < 315; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 316; i < 318; i++) R5[i] = (char *(*)()) F1_8;}
	R5[320] = (char *(*)()) F1_8;
	{long i; for (i = 322; i < 328; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 329; i < 332; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 333; i < 335; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 337; i < 339; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 340; i < 343; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 344; i < 348; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 349; i < 351; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 352; i < 358; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 359; i < 363; i++) R5[i] = (char *(*)()) F1_8;}
	R5[364] = (char *(*)()) F1_8;
	R5[371] = (char *(*)()) F372_5102;
	R5[372] = (char *(*)()) F1_8;
	R5[380] = (char *(*)()) F380_5343;
	R5[388] = (char *(*)()) F1_8;
	R5[394] = (char *(*)()) F1_8;
	R5[402] = (char *(*)()) F403_5847;
	R5[403] = (char *(*)()) F1_8;
	{long i; for (i = 405; i < 412; i++) R5[i] = (char *(*)()) F1_8;}
	R5[426] = (char *(*)()) F1_8;
	R5[428] = (char *(*)()) F1_8;
	R5[430] = (char *(*)()) F431_5961;
	{long i; for (i = 431; i < 433; i++) R5[i] = (char *(*)()) F1_8;}
	R5[433] = (char *(*)()) F434_6050;
	R5[435] = (char *(*)()) F1_8;
	{long i; for (i = 437; i < 439; i++) R5[i] = (char *(*)()) F1_8;}
	R5[442] = (char *(*)()) F1_8;
	R5[444] = (char *(*)()) F1_8;
	R5[448] = (char *(*)()) F1_8;
	{long i; for (i = 451; i < 453; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 454; i < 456; i++) R5[i] = (char *(*)()) F1_8;}
	R5[457] = (char *(*)()) F1_8;
	R5[459] = (char *(*)()) F1_8;
	{long i; for (i = 472; i < 477; i++) R5[i] = (char *(*)()) F1_8;}
	R5[501] = (char *(*)()) F1_8;
	{long i; for (i = 527; i < 551; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 563; i < 601; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 754; i < 756; i++) R5[i] = (char *(*)()) F1_8;}
	R5[796] = (char *(*)()) F797_7373;
	R5[832] = (char *(*)()) F1_8;
	R5[845] = (char *(*)()) F846_7457;
	R5[846] = (char *(*)()) F847_7457;
	R5[847] = (char *(*)()) F848_7457;
	R5[848] = (char *(*)()) F849_7457;
	R5[849] = (char *(*)()) F850_7457;
	R5[850] = (char *(*)()) F851_7457;
	R5[851] = (char *(*)()) F852_7457;
	R5[852] = (char *(*)()) F853_7457;
	R5[853] = (char *(*)()) F846_7457;
	R5[854] = (char *(*)()) F855_7563;
	R5[855] = (char *(*)()) F856_7563;
	R5[856] = (char *(*)()) F857_7563;
	R5[857] = (char *(*)()) F858_7563;
	R5[858] = (char *(*)()) F859_7563;
	R5[871] = (char *(*)()) F872_7579;
	R5[872] = (char *(*)()) F873_7620;
	R5[873] = (char *(*)()) F874_7620;
	R5[874] = (char *(*)()) F875_7620;
	R5[875] = (char *(*)()) F876_7620;
	R5[876] = (char *(*)()) F877_7620;
	R5[877] = (char *(*)()) F878_7620;
	R5[878] = (char *(*)()) F879_7620;
	R5[879] = (char *(*)()) F880_7620;
	R5[880] = (char *(*)()) F881_7620;
	R5[881] = (char *(*)()) F882_7620;
	R5[882] = (char *(*)()) F883_7620;
	R5[883] = (char *(*)()) F884_7620;
	R5[939] = (char *(*)()) F914_7702;
	R5[940] = (char *(*)()) F917_7702;
	R5[941] = (char *(*)()) F918_7702;
	{long i; for (i = 942; i < 945; i++) R5[i] = (char *(*)()) F914_7702;}
	R5[945] = (char *(*)()) F918_7702;
	R5[946] = (char *(*)()) F917_7702;
	R5[948] = (char *(*)()) F914_7702;
	R5[949] = (char *(*)()) F950_7867;
	R5[950] = (char *(*)()) F951_7867;
	R5[951] = (char *(*)()) F952_7867;
	R5[952] = (char *(*)()) F953_7867;
	R5[953] = (char *(*)()) F954_7867;
	R5[954] = (char *(*)()) F955_7867;
	R5[955] = (char *(*)()) F956_7867;
	R5[956] = (char *(*)()) F957_7867;
	R5[957] = (char *(*)()) F958_7867;
	R5[958] = (char *(*)()) F959_7867;
	R5[959] = (char *(*)()) F960_7867;
	R5[960] = (char *(*)()) F961_7867;
	R5[961] = (char *(*)()) F950_7867;
	R5[963] = (char *(*)()) F950_7867;
	R5[965] = (char *(*)()) F950_7867;
	R5[966] = (char *(*)()) F953_7867;
	R5[967] = (char *(*)()) F954_7867;
	R5[968] = (char *(*)()) F950_7867;
	{long i; for (i = 970; i < 972; i++) R5[i] = (char *(*)()) F950_7867;}
	{long i; for (i = 972; i < 974; i++) R5[i] = (char *(*)()) F953_7867;}
	R5[975] = (char *(*)()) F1_8;
	R5[977] = (char *(*)()) F1_8;
	{long i; for (i = 978; i < 980; i++) R5[i] = (char *(*)()) F979_8257;}
	{long i; for (i = 988; i < 997; i++) R5[i] = (char *(*)()) F1_8;}
	R5[999] = (char *(*)()) F1_8;
	{long i; for (i = 1001; i < 1004; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1006; i < 1008; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1015] = (char *(*)()) F1_8;
	{long i; for (i = 1022; i < 1030; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1039] = (char *(*)()) F1040_9196;
	{long i; for (i = 1041; i < 1043; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1044; i < 1046; i++) R5[i] = (char *(*)()) F1044_9334;}
	{long i; for (i = 1047; i < 1049; i++) R5[i] = (char *(*)()) F1047_9374;}
	R5[1049] = (char *(*)()) F1_8;
	{long i; for (i = 1052; i < 1084; i++) R5[i] = (char *(*)()) F1052_9447;}
	R5[1085] = (char *(*)()) F1085_9484;
	R5[1086] = (char *(*)()) F1087_9522;
	R5[1087] = (char *(*)()) F1088_9522;
	R5[1088] = (char *(*)()) F1089_9522;
	R5[1089] = (char *(*)()) F1088_9522;
	{long i; for (i = 1094; i < 1096; i++) R5[i] = (char *(*)()) F1094_9683;}
	{long i; for (i = 1097; i < 1099; i++) R5[i] = (char *(*)()) F1097_9851;}
	R5[1102] = (char *(*)()) F1_8;
	R5[1103] = (char *(*)()) F1104_10053;
	{long i; for (i = 1104; i < 1107; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1108] = (char *(*)()) F1109_10203;
	{long i; for (i = 1110; i < 1114; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1114] = (char *(*)()) F1115_10501;
	R5[1115] = (char *(*)()) F1116_10538;
	R5[1116] = (char *(*)()) F1117_10538;
	R5[1117] = (char *(*)()) F1118_10538;
	R5[1118] = (char *(*)()) F1119_10538;
	R5[1119] = (char *(*)()) F1120_10538;
	R5[1120] = (char *(*)()) F1121_10538;
	R5[1121] = (char *(*)()) F1122_10538;
	R5[1122] = (char *(*)()) F1123_10538;
	R5[1123] = (char *(*)()) F1124_10538;
	R5[1124] = (char *(*)()) F1125_10538;
	R5[1125] = (char *(*)()) F1126_10538;
	R5[1126] = (char *(*)()) F1127_10538;
	R5[1127] = (char *(*)()) F1128_10538;
	R5[1128] = (char *(*)()) F1129_10538;
	R5[1129] = (char *(*)()) F1130_10538;
	R5[1130] = (char *(*)()) F1131_10538;
	R5[1131] = (char *(*)()) F1132_10538;
	R5[1132] = (char *(*)()) F1133_10538;
	R5[1133] = (char *(*)()) F1134_10538;
	R5[1134] = (char *(*)()) F1135_10538;
	R5[1135] = (char *(*)()) F1136_10538;
	R5[1136] = (char *(*)()) F1137_10538;
	R5[1137] = (char *(*)()) F1138_10538;
	R5[1138] = (char *(*)()) F1139_10538;
	R5[1139] = (char *(*)()) F1140_10538;
	R5[1140] = (char *(*)()) F1141_10538;
	R5[1141] = (char *(*)()) F1142_10538;
	R5[1142] = (char *(*)()) F1143_10538;
	R5[1143] = (char *(*)()) F1144_10538;
	R5[1144] = (char *(*)()) F1145_10538;
	R5[1145] = (char *(*)()) F1146_10538;
	R5[1146] = (char *(*)()) F1147_10538;
	R5[1147] = (char *(*)()) F1148_10538;
	R5[1148] = (char *(*)()) F1149_10538;
	{long i; for (i = 1150; i < 1162; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1165; i < 1168; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1169; i < 1172; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1219; i < 1221; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1221] = (char *(*)()) F1222_10905;
	R5[1222] = (char *(*)()) F1223_10937;
	{long i; for (i = 1225; i < 1227; i++) R5[i] = (char *(*)()) F1225_10962;}
	{long i; for (i = 1228; i < 1230; i++) R5[i] = (char *(*)()) F1228_11060;}
	{long i; for (i = 1231; i < 1233; i++) R5[i] = (char *(*)()) F1231_11159;}
	{long i; for (i = 1234; i < 1236; i++) R5[i] = (char *(*)()) F1234_11258;}
	{long i; for (i = 1237; i < 1239; i++) R5[i] = (char *(*)()) F1237_11357;}
	{long i; for (i = 1240; i < 1242; i++) R5[i] = (char *(*)()) F1240_11451;}
	{long i; for (i = 1243; i < 1245; i++) R5[i] = (char *(*)()) F1243_11545;}
	{long i; for (i = 1246; i < 1248; i++) R5[i] = (char *(*)()) F1246_11640;}
	{long i; for (i = 1249; i < 1251; i++) R5[i] = (char *(*)()) F1249_11739;}
	{long i; for (i = 1252; i < 1254; i++) R5[i] = (char *(*)()) F1252_11805;}
	{long i; for (i = 1254; i < 1256; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1256] = (char *(*)()) F1257_11918;
	R5[1257] = (char *(*)()) F1258_11929;
	{long i; for (i = 1258; i < 1266; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1266] = (char *(*)()) F1267_11975;
	R5[1267] = (char *(*)()) F1268_11975;
	R5[1268] = (char *(*)()) F1269_11975;
	{long i; for (i = 1269; i < 1271; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1279] = (char *(*)()) F1_8;
	R5[1284] = (char *(*)()) F1_8;
	{long i; for (i = 1293; i < 1295; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1296; i < 1299; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1313; i < 1315; i++) R5[i] = (char *(*)()) F1313_12911;}
	R5[1316] = (char *(*)()) F1_8;
	R5[1319] = (char *(*)()) F1_8;
	R5[1320] = (char *(*)()) F1321_13581;
	{long i; for (i = 1321; i < 1323; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1330] = (char *(*)()) F1_8;
	{long i; for (i = 1338; i < 1341; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1344] = (char *(*)()) F1_8;
	{long i; for (i = 1347; i < 1354; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1355] = (char *(*)()) F1_8;
	R5[1357] = (char *(*)()) F1_8;
	R5[1364] = (char *(*)()) F1_8;
	{long i; for (i = 1366; i < 1387; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1389; i < 1391; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1392; i < 1396; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1397; i < 1399; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1400; i < 1402; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1403] = (char *(*)()) F1_8;
	{long i; for (i = 1405; i < 1409; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1410; i < 1412; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1413; i < 1416; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1417; i < 1421; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1422; i < 1427; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1428] = (char *(*)()) F1_8;
	{long i; for (i = 1430; i < 1438; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1438; i < 1448; i++) R5[i] = (char *(*)()) F950_7867;}
	{long i; for (i = 1449; i < 1456; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1457; i < 1470; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1471; i < 1479; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1480; i < 1494; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1495; i < 1499; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1500; i < 1505; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1506; i < 1512; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1512; i < 1514; i++) R5[i] = (char *(*)()) F1513_18106;}
	{long i; for (i = 1514; i < 1518; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1519; i < 1530; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1531; i < 1535; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1536; i < 1545; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1545; i < 1547; i++) R5[i] = (char *(*)()) F1546_18384;}
	R5[1547] = (char *(*)()) F1_8;
	R5[1550] = (char *(*)()) F1551_18514;
}


#ifdef __cplusplus
}
#endif
