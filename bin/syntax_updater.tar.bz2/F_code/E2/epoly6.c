#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4038[150])();
void R4038_init () {
	R4038[0] = (char *(*)()) F305_4633;
	R4038[149] = (char *(*)()) F307_4828;
}

char *(*R4039[150])();
void R4039_init () {
	R4039[0] = (char *(*)()) F305_4634;
	R4039[149] = (char *(*)()) F307_4829;
}

char *(*R4040[150])();
void R4040_init () {
	R4040[0] = (char *(*)()) F305_4635;
	R4040[149] = (char *(*)()) F307_4830;
}

char *(*R4085[4])();
void R4085_init () {
	R4085[0] = (char *(*)()) F312_4860;
	R4085[1] = (char *(*)()) F313_4860;
	R4085[2] = (char *(*)()) F314_4860;
	R4085[3] = (char *(*)()) F312_4860;
}

char *(*R4124[41])();
void R4124_init () {
	R4124[0] = (char *(*)()) F318_4899;
	R4124[3] = (char *(*)()) F321_4923;
	R4124[5] = (char *(*)()) F323_4925;
	R4124[6] = (char *(*)()) F324_4929;
	R4124[7] = (char *(*)()) F325_4935;
	{long i; for (i = 8; i < 11; i++) R4124[i] = (char *(*)()) F326_4952;}
	R4124[12] = (char *(*)()) F330_4956;
	R4124[13] = (char *(*)()) F331_4958;
	R4124[14] = (char *(*)()) F332_4960;
	R4124[16] = (char *(*)()) F334_4962;
	R4124[17] = (char *(*)()) F335_4966;
	R4124[20] = (char *(*)()) F338_4968;
	R4124[21] = (char *(*)()) F339_4970;
	R4124[23] = (char *(*)()) F341_4974;
	R4124[24] = (char *(*)()) F342_4976;
	R4124[25] = (char *(*)()) F343_4982;
	R4124[27] = (char *(*)()) F345_4984;
	R4124[28] = (char *(*)()) F346_4986;
	R4124[29] = (char *(*)()) F347_4990;
	R4124[30] = (char *(*)()) F348_4994;
	R4124[32] = (char *(*)()) F350_4996;
	R4124[33] = (char *(*)()) F351_4998;
	R4124[35] = (char *(*)()) F353_5000;
	R4124[36] = (char *(*)()) F354_5004;
	R4124[37] = (char *(*)()) F355_5006;
	R4124[38] = (char *(*)()) F356_5008;
	R4124[39] = (char *(*)()) F357_5010;
	R4124[40] = (char *(*)()) F358_5012;
}

char *(*R4254[60])();
void R4254_init () {
	R4254[0] = (char *(*)()) F1113_10436;
	R4254[53] = (char *(*)()) F1166_10724;
	R4254[54] = (char *(*)()) F1167_10733;
	R4254[55] = (char *(*)()) F1168_10742;
	R4254[57] = (char *(*)()) F1170_10776;
	R4254[58] = (char *(*)()) F1171_10792;
	R4254[59] = (char *(*)()) F1172_10799;
}

char *(*R4370[1171])();
void R4370_init () {
	R4370[0] = (char *(*)()) F381_5357;
	{long i; for (i = 664; i < 666; i++) R4370[i] = (char *(*)()) F1044_9333;}
	{long i; for (i = 667; i < 669; i++) R4370[i] = (char *(*)()) F1047_9373;}
	{long i; for (i = 714; i < 716; i++) R4370[i] = (char *(*)()) F1094_9688;}
	{long i; for (i = 717; i < 719; i++) R4370[i] = (char *(*)()) F1097_9856;}
	R4370[731] = (char *(*)()) F1112_10305;
	R4370[734] = (char *(*)()) F1115_10500;
	{long i; for (i = 785; i < 788; i++) R4370[i] = (char *(*)()) F1163_10649;}
	{long i; for (i = 789; i < 792; i++) R4370[i] = (char *(*)()) F1163_10649;}
	R4370[845] = (char *(*)()) F1226_11023_4370_2;
	R4370[846] = (char *(*)()) F1227_11023_4370_2;
	R4370[848] = (char *(*)()) F1229_11122_4370_2;
	R4370[849] = (char *(*)()) F1230_11122_4370_2;
	R4370[851] = (char *(*)()) F1232_11221_4370_2;
	R4370[852] = (char *(*)()) F1233_11221_4370_2;
	R4370[854] = (char *(*)()) F1235_11320_4370_2;
	R4370[855] = (char *(*)()) F1236_11320_4370_2;
	R4370[857] = (char *(*)()) F1238_11415_4370_2;
	R4370[858] = (char *(*)()) F1239_11415_4370_2;
	R4370[860] = (char *(*)()) F1241_11509_4370_2;
	R4370[861] = (char *(*)()) F1242_11509_4370_2;
	R4370[863] = (char *(*)()) F1244_11604_4370_2;
	R4370[864] = (char *(*)()) F1245_11604_4370_2;
	R4370[866] = (char *(*)()) F1247_11699_4370_2;
	R4370[867] = (char *(*)()) F1248_11699_4370_2;
	R4370[869] = (char *(*)()) F1250_11768_4370_2;
	R4370[870] = (char *(*)()) F1251_11768_4370_2;
	R4370[872] = (char *(*)()) F1253_11834_4370_2;
	R4370[873] = (char *(*)()) F1254_11834_4370_2;
	R4370[890] = (char *(*)()) F1271_12117;
	R4370[1164] = (char *(*)()) F1545_18369;
	{long i; for (i = 1165; i < 1167; i++) R4370[i] = (char *(*)()) F1546_18385;}
	R4370[1170] = (char *(*)()) F1551_18515;
}
static EIF_BOOLEAN F1226_11023_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1226_11023(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1227_11023_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1227_11023(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1229_11122_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1229_11122(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1230_11122_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1230_11122(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1232_11221_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1232_11221(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1233_11221_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1233_11221(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1235_11320_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1235_11320(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1236_11320_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1236_11320(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1238_11415_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1238_11415(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1239_11415_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1239_11415(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1241_11509_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1241_11509(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1242_11509_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1242_11509(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1244_11604_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1244_11604(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1245_11604_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1245_11604(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1247_11699_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1247_11699(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1248_11699_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1248_11699(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1250_11768_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1250_11768(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1251_11768_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1251_11768(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1253_11834_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1253_11834(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1254_11834_4370_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1254_11834(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4371[1171])();
void R4371_init () {
	R4371[0] = (char *(*)()) F380_5340;
	{long i; for (i = 664; i < 666; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 667; i < 669; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 714; i < 716; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 717; i < 719; i++) R4371[i] = (char *(*)()) F380_5340;}
	R4371[731] = (char *(*)()) F380_5340;
	R4371[734] = (char *(*)()) F380_5340;
	R4371[735] = (char *(*)()) F1116_10540;
	R4371[736] = (char *(*)()) F1117_10540;
	R4371[737] = (char *(*)()) F1118_10540;
	R4371[738] = (char *(*)()) F1119_10540;
	R4371[739] = (char *(*)()) F1120_10540;
	R4371[740] = (char *(*)()) F1121_10540;
	R4371[741] = (char *(*)()) F1122_10540;
	R4371[742] = (char *(*)()) F1123_10540;
	R4371[743] = (char *(*)()) F1124_10540;
	R4371[744] = (char *(*)()) F1125_10540;
	R4371[745] = (char *(*)()) F1126_10540;
	R4371[746] = (char *(*)()) F1127_10540;
	R4371[747] = (char *(*)()) F1128_10540;
	R4371[748] = (char *(*)()) F1129_10540;
	R4371[749] = (char *(*)()) F1130_10540;
	R4371[750] = (char *(*)()) F1131_10540;
	R4371[751] = (char *(*)()) F1132_10540;
	R4371[752] = (char *(*)()) F1133_10540;
	R4371[753] = (char *(*)()) F1134_10540;
	R4371[754] = (char *(*)()) F1135_10540;
	R4371[755] = (char *(*)()) F1136_10540;
	R4371[756] = (char *(*)()) F1137_10540;
	R4371[757] = (char *(*)()) F1138_10540;
	R4371[758] = (char *(*)()) F1139_10540;
	R4371[759] = (char *(*)()) F1140_10540;
	R4371[760] = (char *(*)()) F1141_10540;
	R4371[761] = (char *(*)()) F1142_10540;
	R4371[762] = (char *(*)()) F1143_10540;
	R4371[763] = (char *(*)()) F1144_10540;
	R4371[764] = (char *(*)()) F1145_10540;
	R4371[765] = (char *(*)()) F1146_10540;
	R4371[766] = (char *(*)()) F1147_10540;
	R4371[767] = (char *(*)()) F1148_10540;
	R4371[768] = (char *(*)()) F1149_10540;
	{long i; for (i = 785; i < 788; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 789; i < 792; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 845; i < 847; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 848; i < 850; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 851; i < 853; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 854; i < 856; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 857; i < 859; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 860; i < 862; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 863; i < 865; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 866; i < 868; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 869; i < 871; i++) R4371[i] = (char *(*)()) F380_5340;}
	{long i; for (i = 872; i < 874; i++) R4371[i] = (char *(*)()) F380_5340;}
	R4371[890] = (char *(*)()) F380_5340;
	{long i; for (i = 1164; i < 1167; i++) R4371[i] = (char *(*)()) F380_5340;}
	R4371[1170] = (char *(*)()) F380_5340;
}

char *(*R4956[7])();
void R4956_init () {
	{long i; for (i = 0; i < 3; i++) R4956[i] = (char *(*)()) F405_5868;}
	R4956[3] = (char *(*)()) F409_5886;
	{long i; for (i = 4; i < 7; i++) R4956[i] = (char *(*)()) F405_5868;}
}

char *(*R4969[1118])();
void R4969_init () {
	R4969[0] = (char *(*)()) F415_5890;
	R4969[439] = (char *(*)()) F413_5890;
	R4969[440] = (char *(*)()) F414_5890;
	R4969[441] = (char *(*)()) F415_5890;
	R4969[442] = (char *(*)()) F416_5890;
	R4969[443] = (char *(*)()) F417_5890;
	R4969[444] = (char *(*)()) F418_5890;
	R4969[445] = (char *(*)()) F419_5890;
	R4969[446] = (char *(*)()) F420_5890;
	R4969[447] = (char *(*)()) F421_5890;
	R4969[448] = (char *(*)()) F422_5890;
	R4969[449] = (char *(*)()) F423_5890;
	R4969[450] = (char *(*)()) F424_5890;
	R4969[516] = (char *(*)()) F413_5890;
	R4969[517] = (char *(*)()) F414_5890;
	R4969[518] = (char *(*)()) F415_5890;
	R4969[519] = (char *(*)()) F416_5890;
	R4969[520] = (char *(*)()) F417_5890;
	R4969[521] = (char *(*)()) F418_5890;
	R4969[522] = (char *(*)()) F419_5890;
	R4969[523] = (char *(*)()) F420_5890;
	R4969[524] = (char *(*)()) F421_5890;
	R4969[525] = (char *(*)()) F422_5890;
	R4969[526] = (char *(*)()) F423_5890;
	R4969[527] = (char *(*)()) F424_5890;
	R4969[528] = (char *(*)()) F413_5890;
	R4969[530] = (char *(*)()) F413_5890;
	R4969[532] = (char *(*)()) F413_5890;
	R4969[533] = (char *(*)()) F416_5890;
	R4969[534] = (char *(*)()) F417_5890;
	R4969[535] = (char *(*)()) F413_5890;
	{long i; for (i = 537; i < 539; i++) R4969[i] = (char *(*)()) F413_5890;}
	{long i; for (i = 539; i < 541; i++) R4969[i] = (char *(*)()) F416_5890;}
	R4969[662] = (char *(*)()) F421_5890;
	R4969[665] = (char *(*)()) F423_5890;
	{long i; for (i = 1005; i < 1015; i++) R4969[i] = (char *(*)()) F413_5890;}
	R4969[1117] = (char *(*)()) F423_5890;
}

char *(*R4970[1118])();
void R4970_init () {
	R4970[0] = (char *(*)()) F415_5891_4970_156;
	R4970[439] = (char *(*)()) F413_5891;
	R4970[440] = (char *(*)()) F414_5891_4970_156;
	R4970[441] = (char *(*)()) F415_5891_4970_156;
	R4970[442] = (char *(*)()) F416_5891_4970_156;
	R4970[443] = (char *(*)()) F417_5891_4970_156;
	R4970[444] = (char *(*)()) F418_5891_4970_156;
	R4970[445] = (char *(*)()) F419_5891_4970_156;
	R4970[446] = (char *(*)()) F420_5891_4970_156;
	R4970[447] = (char *(*)()) F421_5891_4970_156;
	R4970[448] = (char *(*)()) F422_5891_4970_156;
	R4970[449] = (char *(*)()) F423_5891_4970_156;
	R4970[450] = (char *(*)()) F424_5891_4970_156;
	R4970[516] = (char *(*)()) F413_5891;
	R4970[517] = (char *(*)()) F414_5891_4970_156;
	R4970[518] = (char *(*)()) F415_5891_4970_156;
	R4970[519] = (char *(*)()) F416_5891_4970_156;
	R4970[520] = (char *(*)()) F417_5891_4970_156;
	R4970[521] = (char *(*)()) F418_5891_4970_156;
	R4970[522] = (char *(*)()) F419_5891_4970_156;
	R4970[523] = (char *(*)()) F420_5891_4970_156;
	R4970[524] = (char *(*)()) F421_5891_4970_156;
	R4970[525] = (char *(*)()) F422_5891_4970_156;
	R4970[526] = (char *(*)()) F423_5891_4970_156;
	R4970[527] = (char *(*)()) F424_5891_4970_156;
	R4970[528] = (char *(*)()) F413_5891;
	R4970[530] = (char *(*)()) F413_5891;
	R4970[532] = (char *(*)()) F413_5891;
	R4970[533] = (char *(*)()) F416_5891_4970_156;
	R4970[534] = (char *(*)()) F417_5891_4970_156;
	R4970[535] = (char *(*)()) F413_5891;
	{long i; for (i = 537; i < 539; i++) R4970[i] = (char *(*)()) F413_5891;}
	{long i; for (i = 539; i < 541; i++) R4970[i] = (char *(*)()) F416_5891_4970_156;}
	R4970[662] = (char *(*)()) F421_5891_4970_156;
	R4970[665] = (char *(*)()) F423_5891_4970_156;
	{long i; for (i = 1005; i < 1015; i++) R4970[i] = (char *(*)()) F413_5891;}
	R4970[1117] = (char *(*)()) F423_5891_4970_156;
}
static void F415_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F415_5891(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F414_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F414_5891(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F416_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F416_5891(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F417_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F417_5891(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F418_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F418_5891(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F419_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F419_5891(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F420_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F420_5891(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F421_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F421_5891(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F422_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F422_5891(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F423_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F423_5891(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F424_5891_4970_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F424_5891(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R4976[1118])();
void R4976_init () {
	R4976[0] = (char *(*)()) F415_5897;
	R4976[439] = (char *(*)()) F413_5897;
	R4976[440] = (char *(*)()) F414_5897;
	R4976[441] = (char *(*)()) F415_5897;
	R4976[442] = (char *(*)()) F416_5897;
	R4976[443] = (char *(*)()) F417_5897;
	R4976[444] = (char *(*)()) F418_5897;
	R4976[445] = (char *(*)()) F419_5897;
	R4976[446] = (char *(*)()) F420_5897;
	R4976[447] = (char *(*)()) F421_5897;
	R4976[448] = (char *(*)()) F422_5897;
	R4976[449] = (char *(*)()) F423_5897;
	R4976[450] = (char *(*)()) F424_5897;
	R4976[516] = (char *(*)()) F413_5897;
	R4976[517] = (char *(*)()) F414_5897;
	R4976[518] = (char *(*)()) F415_5897;
	R4976[519] = (char *(*)()) F416_5897;
	R4976[520] = (char *(*)()) F417_5897;
	R4976[521] = (char *(*)()) F418_5897;
	R4976[522] = (char *(*)()) F419_5897;
	R4976[523] = (char *(*)()) F420_5897;
	R4976[524] = (char *(*)()) F421_5897;
	R4976[525] = (char *(*)()) F422_5897;
	R4976[526] = (char *(*)()) F423_5897;
	R4976[527] = (char *(*)()) F424_5897;
	R4976[528] = (char *(*)()) F413_5897;
	R4976[530] = (char *(*)()) F413_5897;
	R4976[532] = (char *(*)()) F413_5897;
	R4976[533] = (char *(*)()) F416_5897;
	R4976[534] = (char *(*)()) F417_5897;
	R4976[535] = (char *(*)()) F413_5897;
	{long i; for (i = 537; i < 539; i++) R4976[i] = (char *(*)()) F413_5897;}
	{long i; for (i = 539; i < 541; i++) R4976[i] = (char *(*)()) F416_5897;}
	R4976[662] = (char *(*)()) F421_5897;
	R4976[665] = (char *(*)()) F423_5897;
	{long i; for (i = 1005; i < 1015; i++) R4976[i] = (char *(*)()) F413_5897;}
	R4976[1117] = (char *(*)()) F423_5897;
}

static EIF_TYPE_INDEX Y4977_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype12[] = {1247,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype13[] = {1247,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype43[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype44[] = {0xFF01,37,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype46[] = {0xFF01,445,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype50[] = {0xFF01,968,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype52[] = {0xFF01,1085,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype55[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype56[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype57[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype58[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype60[] = {0xFF01,1376,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype61[] = {0xFF01,1385,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype62[] = {0xFF01,1386,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype63[] = {0xFF01,1369,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype64[] = {0xFF01,1378,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype65[] = {0xFF01,1374,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype66[] = {0xFF01,1375,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype67[] = {0xFF01,1512,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype68[] = {0xFF01,1429,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype69[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y4977_pgtype70[] = {1048,0xFFFF};
EIF_TYPE_INDEX *Y4977_gen_type [1140];
EIF_TYPE_INDEX Y4977 [1140];
void Y4977_init (void)
{
	egc_routines_types [4977] = Y4977;
	egc_routines_gen_types [4977] = Y4977_gen_type;
	egc_routines_offset [4977] = 412;
	Y4977_gen_type [0] = Y4977_pgtype0;
	Y4977_gen_type [1] = Y4977_pgtype1;
	Y4977_gen_type [2] = Y4977_pgtype2;
	Y4977_gen_type [3] = Y4977_pgtype3;
	Y4977_gen_type [4] = Y4977_pgtype4;
	Y4977_gen_type [5] = Y4977_pgtype5;
	Y4977_gen_type [6] = Y4977_pgtype6;
	Y4977_gen_type [7] = Y4977_pgtype7;
	Y4977_gen_type [8] = Y4977_pgtype8;
	Y4977_gen_type [9] = Y4977_pgtype9;
	Y4977_gen_type [10] = Y4977_pgtype10;
	Y4977_gen_type [11] = Y4977_pgtype11;
	Y4977_gen_type [21] = Y4977_pgtype12;
	Y4977_gen_type [22] = Y4977_pgtype13;
	Y4977_gen_type [460] = Y4977_pgtype14;
	Y4977_gen_type [461] = Y4977_pgtype15;
	Y4977_gen_type [462] = Y4977_pgtype16;
	Y4977_gen_type [463] = Y4977_pgtype17;
	Y4977_gen_type [464] = Y4977_pgtype18;
	Y4977_gen_type [465] = Y4977_pgtype19;
	Y4977_gen_type [466] = Y4977_pgtype20;
	Y4977_gen_type [467] = Y4977_pgtype21;
	Y4977_gen_type [468] = Y4977_pgtype22;
	Y4977_gen_type [469] = Y4977_pgtype23;
	Y4977_gen_type [470] = Y4977_pgtype24;
	Y4977_gen_type [471] = Y4977_pgtype25;
	Y4977_gen_type [472] = Y4977_pgtype26;
	Y4977_gen_type [473] = Y4977_pgtype27;
	Y4977_gen_type [474] = Y4977_pgtype28;
	Y4977_gen_type [475] = Y4977_pgtype29;
	Y4977_gen_type [476] = Y4977_pgtype30;
	Y4977_gen_type [537] = Y4977_pgtype31;
	Y4977_gen_type [538] = Y4977_pgtype32;
	Y4977_gen_type [539] = Y4977_pgtype33;
	Y4977_gen_type [540] = Y4977_pgtype34;
	Y4977_gen_type [541] = Y4977_pgtype35;
	Y4977_gen_type [542] = Y4977_pgtype36;
	Y4977_gen_type [543] = Y4977_pgtype37;
	Y4977_gen_type [544] = Y4977_pgtype38;
	Y4977_gen_type [545] = Y4977_pgtype39;
	Y4977_gen_type [546] = Y4977_pgtype40;
	Y4977_gen_type [547] = Y4977_pgtype41;
	Y4977_gen_type [548] = Y4977_pgtype42;
	Y4977_gen_type [549] = Y4977_pgtype43;
	Y4977_gen_type [550] = Y4977_pgtype44;
	Y4977_gen_type [551] = Y4977_pgtype45;
	Y4977_gen_type [552] = Y4977_pgtype46;
	Y4977_gen_type [553] = Y4977_pgtype47;
	Y4977_gen_type [554] = Y4977_pgtype48;
	Y4977_gen_type [555] = Y4977_pgtype49;
	Y4977_gen_type [556] = Y4977_pgtype50;
	Y4977_gen_type [557] = Y4977_pgtype51;
	Y4977_gen_type [558] = Y4977_pgtype52;
	Y4977_gen_type [559] = Y4977_pgtype53;
	Y4977_gen_type [560] = Y4977_pgtype54;
	Y4977_gen_type [561] = Y4977_pgtype55;
	Y4977_gen_type [683] = Y4977_pgtype56;
	Y4977_gen_type [686] = Y4977_pgtype57;
	Y4977_gen_type [687] = Y4977_pgtype58;
	Y4977_gen_type [1026] = Y4977_pgtype59;
	Y4977_gen_type [1027] = Y4977_pgtype60;
	Y4977_gen_type [1028] = Y4977_pgtype61;
	Y4977_gen_type [1029] = Y4977_pgtype62;
	Y4977_gen_type [1030] = Y4977_pgtype63;
	Y4977_gen_type [1031] = Y4977_pgtype64;
	Y4977_gen_type [1032] = Y4977_pgtype65;
	Y4977_gen_type [1033] = Y4977_pgtype66;
	Y4977_gen_type [1034] = Y4977_pgtype67;
	Y4977_gen_type [1035] = Y4977_pgtype68;
	Y4977_gen_type [1138] = Y4977_pgtype69;
	Y4977_gen_type [1139] = Y4977_pgtype70;
	{long i; for (i = 21; i < 23; i++) Y4977[i] = 1247;};
	Y4977[549] = 1320;
	Y4977[550] = 37;
	Y4977[552] = 445;
	Y4977[556] = 968;
	Y4977[558] = 1085;
	Y4977[561] = 1229;
	Y4977[683] = 1045;
	{long i; for (i = 686; i < 688; i++) Y4977[i] = 1048;};
	Y4977[1027] = 1376;
	Y4977[1028] = 1385;
	Y4977[1029] = 1386;
	Y4977[1030] = 1369;
	Y4977[1031] = 1378;
	Y4977[1032] = 1374;
	Y4977[1033] = 1375;
	Y4977[1034] = 1512;
	Y4977[1035] = 1429;
	{long i; for (i = 1138; i < 1140; i++) Y4977[i] = 1048;};
}

char *(*R5442[5])();
void R5442_init () {
	R5442[0] = (char *(*)()) F456_6428;
	R5442[2] = (char *(*)()) F457_6666;
	R5442[4] = (char *(*)()) F460_6935;
}

char *(*R5443[5])();
void R5443_init () {
	R5443[0] = (char *(*)()) F456_6429;
	R5443[2] = (char *(*)()) F457_6667;
	R5443[4] = (char *(*)()) F460_6936;
}

char *(*R5445[5])();
void R5445_init () {
	R5445[0] = (char *(*)()) F456_6431;
	R5445[2] = (char *(*)()) F457_6669;
	R5445[4] = (char *(*)()) F460_6938;
}

char *(*R5446[5])();
void R5446_init () {
	R5446[0] = (char *(*)()) F456_6432;
	R5446[2] = (char *(*)()) F457_6670;
	R5446[4] = (char *(*)()) F456_6432;
}

char *(*R5450[5])();
void R5450_init () {
	R5450[0] = (char *(*)()) F456_6436;
	R5450[2] = (char *(*)()) F457_6671;
	R5450[4] = (char *(*)()) F460_6939;
}

char *(*R5453[5])();
void R5453_init () {
	R5453[0] = (char *(*)()) F456_6439;
	R5453[2] = (char *(*)()) F456_6439;
	R5453[4] = (char *(*)()) F459_6901;
}

char *(*R5454[5])();
void R5454_init () {
	R5454[0] = (char *(*)()) F456_6440;
	R5454[2] = (char *(*)()) F456_6440;
	R5454[4] = (char *(*)()) F459_6902;
}

char *(*R5459[5])();
void R5459_init () {
	R5459[0] = (char *(*)()) F456_6445;
	R5459[2] = (char *(*)()) F457_6672;
	R5459[4] = (char *(*)()) F459_6903;
}

char *(*R5460[5])();
void R5460_init () {
	R5460[0] = (char *(*)()) F456_6446;
	R5460[2] = (char *(*)()) F457_6673;
	R5460[4] = (char *(*)()) F459_6904;
}

char *(*R5461[5])();
void R5461_init () {
	R5461[0] = (char *(*)()) F456_6447;
	R5461[2] = (char *(*)()) F457_6674;
	R5461[4] = (char *(*)()) F459_6905;
}

static EIF_TYPE_INDEX Y5465_pgtype0[] = {0xFF01,0xFFF9,5,1039,1450,1512,1229,1229,0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y5465_pgtype1[] = {0xFF01,0xFFF9,5,1039,1450,1512,1229,1229,0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y5465_pgtype2[] = {0xFF01,0xFFF9,5,1039,1450,1512,1229,1229,0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y5465_pgtype3[] = {0xFF01,0xFFF9,5,1039,1450,1512,1229,1229,0xFFF5,1,0xFF01,1341,11050,0xFFFF};
static EIF_TYPE_INDEX Y5465_pgtype4[] = {0xFF01,0xFFF9,5,1039,1450,1512,1229,1229,0xFFF5,1,0xFF01,1341,11050,0xFFFF};
EIF_TYPE_INDEX *Y5465_gen_type [5];
EIF_TYPE_INDEX Y5465 [5];
void Y5465_init (void)
{
	egc_routines_types [5465] = Y5465;
	egc_routines_gen_types [5465] = Y5465_gen_type;
	egc_routines_offset [5465] = 455;
	Y5465_gen_type [0] = Y5465_pgtype0;
	Y5465_gen_type [1] = Y5465_pgtype1;
	Y5465_gen_type [2] = Y5465_pgtype2;
	Y5465_gen_type [3] = Y5465_pgtype3;
	Y5465_gen_type [4] = Y5465_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5465[i] = 1039;};
}

char *(*R5466[5])();
void R5466_init () {
	R5466[0] = (char *(*)()) F456_6452;
	R5466[2] = (char *(*)()) F457_6675;
	R5466[4] = (char *(*)()) F456_6452;
}

char *(*R5467[5])();
void R5467_init () {
	R5467[0] = (char *(*)()) F456_6453;
	R5467[2] = (char *(*)()) F457_6676;
	R5467[4] = (char *(*)()) F456_6453;
}

char *(*R5468[5])();
void R5468_init () {
	R5468[0] = (char *(*)()) F456_6454;
	R5468[2] = (char *(*)()) F457_6677;
	R5468[4] = (char *(*)()) F456_6454;
}

char *(*R5469[5])();
void R5469_init () {
	R5469[0] = (char *(*)()) F456_6455;
	R5469[2] = (char *(*)()) F457_6678;
	R5469[4] = (char *(*)()) F456_6455;
}

char *(*R5470[5])();
void R5470_init () {
	R5470[0] = (char *(*)()) F456_6456;
	R5470[2] = (char *(*)()) F457_6679;
	R5470[4] = (char *(*)()) F456_6456;
}

char *(*R5471[5])();
void R5471_init () {
	R5471[0] = (char *(*)()) F456_6457;
	R5471[2] = (char *(*)()) F457_6680;
	R5471[4] = (char *(*)()) F456_6457;
}

char *(*R5472[5])();
void R5472_init () {
	R5472[0] = (char *(*)()) F456_6458;
	R5472[2] = (char *(*)()) F457_6681;
	R5472[4] = (char *(*)()) F456_6458;
}

char *(*R5473[5])();
void R5473_init () {
	R5473[0] = (char *(*)()) F456_6459;
	R5473[2] = (char *(*)()) F457_6682;
	R5473[4] = (char *(*)()) F456_6459;
}

char *(*R5474[5])();
void R5474_init () {
	R5474[0] = (char *(*)()) F456_6460;
	R5474[2] = (char *(*)()) F457_6683;
	R5474[4] = (char *(*)()) F456_6460;
}

char *(*R5476[5])();
void R5476_init () {
	R5476[0] = (char *(*)()) F456_6462;
	R5476[2] = (char *(*)()) F457_6684;
	R5476[4] = (char *(*)()) F456_6462;
}

char *(*R5477[5])();
void R5477_init () {
	R5477[0] = (char *(*)()) F456_6463;
	R5477[2] = (char *(*)()) F457_6685;
	R5477[4] = (char *(*)()) F456_6463;
}

char *(*R5478[5])();
void R5478_init () {
	R5478[0] = (char *(*)()) F456_6464;
	R5478[2] = (char *(*)()) F457_6686;
	R5478[4] = (char *(*)()) F456_6464;
}

char *(*R5479[5])();
void R5479_init () {
	R5479[0] = (char *(*)()) F456_6465;
	R5479[2] = (char *(*)()) F457_6687;
	R5479[4] = (char *(*)()) F456_6465;
}

char *(*R5480[5])();
void R5480_init () {
	R5480[0] = (char *(*)()) F456_6466;
	R5480[2] = (char *(*)()) F457_6688;
	R5480[4] = (char *(*)()) F456_6466;
}

char *(*R5481[5])();
void R5481_init () {
	R5481[0] = (char *(*)()) F456_6467;
	R5481[2] = (char *(*)()) F457_6689;
	R5481[4] = (char *(*)()) F456_6467;
}

char *(*R5482[5])();
void R5482_init () {
	R5482[0] = (char *(*)()) F456_6468;
	R5482[2] = (char *(*)()) F457_6693;
	R5482[4] = (char *(*)()) F459_6907;
}

char *(*R5483[5])();
void R5483_init () {
	R5483[0] = (char *(*)()) F456_6469;
	R5483[2] = (char *(*)()) F457_6694;
	R5483[4] = (char *(*)()) F456_6469;
}

char *(*R5487[5])();
void R5487_init () {
	R5487[0] = (char *(*)()) F456_6473;
	R5487[2] = (char *(*)()) F457_6690;
	R5487[4] = (char *(*)()) F456_6473;
}

char *(*R5488[5])();
void R5488_init () {
	R5488[0] = (char *(*)()) F456_6474;
	R5488[2] = (char *(*)()) F458_6892;
	R5488[4] = (char *(*)()) F456_6474;
}

char *(*R5489[5])();
void R5489_init () {
	R5489[0] = (char *(*)()) F456_6475;
	R5489[2] = (char *(*)()) F457_6691;
	R5489[4] = (char *(*)()) F459_6931;
}

char *(*R5490[5])();
void R5490_init () {
	R5490[0] = (char *(*)()) F456_6476;
	R5490[2] = (char *(*)()) F457_6692;
	R5490[4] = (char *(*)()) F459_6932;
}

char *(*R5494[5])();
void R5494_init () {
	R5494[0] = (char *(*)()) F456_6480;
	R5494[2] = (char *(*)()) F458_6886;
	R5494[4] = (char *(*)()) F460_6958;
}

char *(*R5495[5])();
void R5495_init () {
	R5495[0] = (char *(*)()) F456_6481;
	R5495[2] = (char *(*)()) F458_6887;
	R5495[4] = (char *(*)()) F460_6959;
}

char *(*R5496[5])();
void R5496_init () {
	R5496[0] = (char *(*)()) F456_6482;
	R5496[2] = (char *(*)()) F457_6698;
	R5496[4] = (char *(*)()) F456_6482;
}

char *(*R5497[5])();
void R5497_init () {
	R5497[0] = (char *(*)()) F456_6483;
	R5497[2] = (char *(*)()) F458_6884;
	R5497[4] = (char *(*)()) F456_6483;
}

char *(*R5498[5])();
void R5498_init () {
	R5498[0] = (char *(*)()) F456_6484;
	R5498[2] = (char *(*)()) F457_6701;
	R5498[4] = (char *(*)()) F456_6484;
}

char *(*R5499[5])();
void R5499_init () {
	R5499[0] = (char *(*)()) F456_6485;
	R5499[2] = (char *(*)()) F457_6702;
	R5499[4] = (char *(*)()) F456_6485;
}

char *(*R5500[5])();
void R5500_init () {
	R5500[0] = (char *(*)()) F456_6486;
	R5500[2] = (char *(*)()) F457_6703;
	R5500[4] = (char *(*)()) F456_6486;
}

char *(*R5501[5])();
void R5501_init () {
	R5501[0] = (char *(*)()) F456_6487;
	R5501[2] = (char *(*)()) F457_6704;
	R5501[4] = (char *(*)()) F460_6960;
}

char *(*R5502[5])();
void R5502_init () {
	R5502[0] = (char *(*)()) F456_6488;
	R5502[2] = (char *(*)()) F457_6705;
	R5502[4] = (char *(*)()) F460_6961;
}

char *(*R5503[5])();
void R5503_init () {
	R5503[0] = (char *(*)()) F456_6489;
	R5503[2] = (char *(*)()) F457_6706;
	R5503[4] = (char *(*)()) F460_6962;
}

char *(*R5504[5])();
void R5504_init () {
	R5504[0] = (char *(*)()) F456_6490;
	R5504[2] = (char *(*)()) F457_6707;
	R5504[4] = (char *(*)()) F456_6490;
}

char *(*R5505[5])();
void R5505_init () {
	R5505[0] = (char *(*)()) F456_6491;
	R5505[2] = (char *(*)()) F457_6708;
	R5505[4] = (char *(*)()) F460_6963;
}

char *(*R5506[5])();
void R5506_init () {
	R5506[0] = (char *(*)()) F456_6492;
	R5506[2] = (char *(*)()) F457_6709;
	R5506[4] = (char *(*)()) F460_6964;
}

char *(*R5507[5])();
void R5507_init () {
	R5507[0] = (char *(*)()) F456_6493;
	R5507[2] = (char *(*)()) F457_6710;
	R5507[4] = (char *(*)()) F456_6493;
}

char *(*R5508[5])();
void R5508_init () {
	R5508[0] = (char *(*)()) F456_6494;
	R5508[2] = (char *(*)()) F457_6711;
	R5508[4] = (char *(*)()) F456_6494;
}

char *(*R5509[5])();
void R5509_init () {
	R5509[0] = (char *(*)()) F456_6495;
	R5509[2] = (char *(*)()) F457_6712;
	R5509[4] = (char *(*)()) F456_6495;
}

char *(*R5510[5])();
void R5510_init () {
	R5510[0] = (char *(*)()) F456_6496;
	R5510[2] = (char *(*)()) F457_6713;
	R5510[4] = (char *(*)()) F456_6496;
}

char *(*R5511[5])();
void R5511_init () {
	R5511[0] = (char *(*)()) F456_6497;
	R5511[2] = (char *(*)()) F457_6714;
	R5511[4] = (char *(*)()) F456_6497;
}

char *(*R5512[5])();
void R5512_init () {
	R5512[0] = (char *(*)()) F456_6498;
	R5512[2] = (char *(*)()) F457_6715;
	R5512[4] = (char *(*)()) F456_6498;
}

char *(*R5513[5])();
void R5513_init () {
	R5513[0] = (char *(*)()) F456_6499;
	R5513[2] = (char *(*)()) F457_6716;
	R5513[4] = (char *(*)()) F456_6499;
}

char *(*R5514[5])();
void R5514_init () {
	R5514[0] = (char *(*)()) F456_6500;
	R5514[2] = (char *(*)()) F457_6717;
	R5514[4] = (char *(*)()) F456_6500;
}

char *(*R5515[5])();
void R5515_init () {
	R5515[0] = (char *(*)()) F456_6501;
	R5515[2] = (char *(*)()) F457_6718;
	R5515[4] = (char *(*)()) F456_6501;
}

char *(*R5516[5])();
void R5516_init () {
	R5516[0] = (char *(*)()) F456_6502;
	R5516[2] = (char *(*)()) F457_6719;
	R5516[4] = (char *(*)()) F456_6502;
}

char *(*R5517[5])();
void R5517_init () {
	R5517[0] = (char *(*)()) F456_6503;
	R5517[2] = (char *(*)()) F457_6720;
	R5517[4] = (char *(*)()) F456_6503;
}

char *(*R5518[5])();
void R5518_init () {
	R5518[0] = (char *(*)()) F456_6504;
	R5518[2] = (char *(*)()) F457_6721;
	R5518[4] = (char *(*)()) F456_6504;
}

char *(*R5519[5])();
void R5519_init () {
	R5519[0] = (char *(*)()) F456_6505;
	R5519[2] = (char *(*)()) F457_6722;
	R5519[4] = (char *(*)()) F456_6505;
}

char *(*R5520[5])();
void R5520_init () {
	R5520[0] = (char *(*)()) F456_6506;
	R5520[2] = (char *(*)()) F457_6723;
	R5520[4] = (char *(*)()) F459_6933;
}

char *(*R5521[5])();
void R5521_init () {
	R5521[0] = (char *(*)()) F456_6507;
	R5521[2] = (char *(*)()) F457_6724;
	R5521[4] = (char *(*)()) F456_6507;
}

char *(*R5522[5])();
void R5522_init () {
	R5522[0] = (char *(*)()) F456_6508;
	R5522[2] = (char *(*)()) F457_6725;
	R5522[4] = (char *(*)()) F456_6508;
}

char *(*R5523[5])();
void R5523_init () {
	R5523[0] = (char *(*)()) F456_6509;
	R5523[2] = (char *(*)()) F457_6726;
	R5523[4] = (char *(*)()) F456_6509;
}

char *(*R5524[5])();
void R5524_init () {
	R5524[0] = (char *(*)()) F456_6510;
	R5524[2] = (char *(*)()) F457_6727;
	R5524[4] = (char *(*)()) F456_6510;
}

char *(*R5525[5])();
void R5525_init () {
	R5525[0] = (char *(*)()) F456_6511;
	R5525[2] = (char *(*)()) F457_6728;
	R5525[4] = (char *(*)()) F456_6511;
}

char *(*R5526[5])();
void R5526_init () {
	R5526[0] = (char *(*)()) F456_6512;
	R5526[2] = (char *(*)()) F457_6729;
	R5526[4] = (char *(*)()) F456_6512;
}

char *(*R5527[5])();
void R5527_init () {
	R5527[0] = (char *(*)()) F456_6513;
	R5527[2] = (char *(*)()) F457_6730;
	R5527[4] = (char *(*)()) F456_6513;
}

char *(*R5528[5])();
void R5528_init () {
	R5528[0] = (char *(*)()) F456_6514;
	R5528[2] = (char *(*)()) F457_6731;
	R5528[4] = (char *(*)()) F456_6514;
}

char *(*R5529[5])();
void R5529_init () {
	R5529[0] = (char *(*)()) F456_6515;
	R5529[2] = (char *(*)()) F457_6732;
	R5529[4] = (char *(*)()) F456_6515;
}

char *(*R5530[5])();
void R5530_init () {
	R5530[0] = (char *(*)()) F456_6516;
	R5530[2] = (char *(*)()) F457_6733;
	R5530[4] = (char *(*)()) F456_6516;
}

char *(*R5531[5])();
void R5531_init () {
	R5531[0] = (char *(*)()) F456_6517;
	R5531[2] = (char *(*)()) F457_6734;
	R5531[4] = (char *(*)()) F456_6517;
}

char *(*R5532[5])();
void R5532_init () {
	R5532[0] = (char *(*)()) F456_6518;
	R5532[2] = (char *(*)()) F457_6735;
	R5532[4] = (char *(*)()) F456_6518;
}

char *(*R5533[5])();
void R5533_init () {
	R5533[0] = (char *(*)()) F456_6519;
	R5533[2] = (char *(*)()) F457_6736;
	R5533[4] = (char *(*)()) F456_6519;
}

char *(*R5534[5])();
void R5534_init () {
	R5534[0] = (char *(*)()) F456_6520;
	R5534[2] = (char *(*)()) F457_6737;
	R5534[4] = (char *(*)()) F459_6934;
}

char *(*R5535[5])();
void R5535_init () {
	R5535[0] = (char *(*)()) F456_6521;
	R5535[2] = (char *(*)()) F457_6738;
	R5535[4] = (char *(*)()) F456_6521;
}

char *(*R5536[5])();
void R5536_init () {
	R5536[0] = (char *(*)()) F456_6522;
	R5536[2] = (char *(*)()) F457_6739;
	R5536[4] = (char *(*)()) F456_6522;
}

char *(*R5537[5])();
void R5537_init () {
	R5537[0] = (char *(*)()) F456_6523;
	R5537[2] = (char *(*)()) F457_6740;
	R5537[4] = (char *(*)()) F456_6523;
}

char *(*R5538[5])();
void R5538_init () {
	R5538[0] = (char *(*)()) F456_6524;
	R5538[2] = (char *(*)()) F457_6741;
	R5538[4] = (char *(*)()) F456_6524;
}

char *(*R5539[5])();
void R5539_init () {
	R5539[0] = (char *(*)()) F456_6525;
	R5539[2] = (char *(*)()) F457_6742;
	R5539[4] = (char *(*)()) F456_6525;
}

char *(*R5540[5])();
void R5540_init () {
	R5540[0] = (char *(*)()) F456_6526;
	R5540[2] = (char *(*)()) F457_6743;
	R5540[4] = (char *(*)()) F456_6526;
}

char *(*R5541[5])();
void R5541_init () {
	R5541[0] = (char *(*)()) F456_6527;
	R5541[2] = (char *(*)()) F457_6744;
	R5541[4] = (char *(*)()) F456_6527;
}

char *(*R5542[5])();
void R5542_init () {
	R5542[0] = (char *(*)()) F456_6528;
	R5542[2] = (char *(*)()) F457_6745;
	R5542[4] = (char *(*)()) F456_6528;
}

char *(*R5543[5])();
void R5543_init () {
	R5543[0] = (char *(*)()) F456_6529;
	R5543[2] = (char *(*)()) F457_6746;
	R5543[4] = (char *(*)()) F460_6955;
}

char *(*R5544[5])();
void R5544_init () {
	R5544[0] = (char *(*)()) F456_6530;
	R5544[2] = (char *(*)()) F457_6747;
	R5544[4] = (char *(*)()) F456_6530;
}

char *(*R5545[5])();
void R5545_init () {
	R5545[0] = (char *(*)()) F456_6531;
	R5545[2] = (char *(*)()) F457_6748;
	R5545[4] = (char *(*)()) F456_6531;
}

char *(*R5546[5])();
void R5546_init () {
	R5546[0] = (char *(*)()) F456_6532;
	R5546[2] = (char *(*)()) F457_6749;
	R5546[4] = (char *(*)()) F456_6532;
}

char *(*R5547[5])();
void R5547_init () {
	R5547[0] = (char *(*)()) F456_6533;
	R5547[2] = (char *(*)()) F457_6750;
	R5547[4] = (char *(*)()) F460_6942;
}

char *(*R5548[5])();
void R5548_init () {
	R5548[0] = (char *(*)()) F456_6534;
	R5548[2] = (char *(*)()) F457_6751;
	R5548[4] = (char *(*)()) F456_6534;
}

char *(*R5549[5])();
void R5549_init () {
	R5549[0] = (char *(*)()) F456_6535;
	R5549[2] = (char *(*)()) F457_6752;
	R5549[4] = (char *(*)()) F456_6535;
}

char *(*R5550[5])();
void R5550_init () {
	R5550[0] = (char *(*)()) F456_6536;
	R5550[2] = (char *(*)()) F458_6891;
	R5550[4] = (char *(*)()) F456_6536;
}

char *(*R5552[5])();
void R5552_init () {
	R5552[0] = (char *(*)()) F456_6538;
	R5552[2] = (char *(*)()) F457_6754;
	R5552[4] = (char *(*)()) F456_6538;
}

char *(*R5553[5])();
void R5553_init () {
	R5553[0] = (char *(*)()) F456_6539;
	R5553[2] = (char *(*)()) F457_6755;
	R5553[4] = (char *(*)()) F456_6539;
}

char *(*R5554[5])();
void R5554_init () {
	R5554[0] = (char *(*)()) F456_6540;
	R5554[2] = (char *(*)()) F457_6756;
	R5554[4] = (char *(*)()) F456_6540;
}

char *(*R5555[5])();
void R5555_init () {
	R5555[0] = (char *(*)()) F456_6541;
	R5555[2] = (char *(*)()) F457_6757;
	R5555[4] = (char *(*)()) F456_6541;
}

char *(*R5556[5])();
void R5556_init () {
	R5556[0] = (char *(*)()) F456_6542;
	R5556[2] = (char *(*)()) F457_6758;
	R5556[4] = (char *(*)()) F456_6542;
}

char *(*R5557[5])();
void R5557_init () {
	R5557[0] = (char *(*)()) F456_6543;
	R5557[2] = (char *(*)()) F457_6759;
	R5557[4] = (char *(*)()) F460_6956;
}

char *(*R5558[5])();
void R5558_init () {
	R5558[0] = (char *(*)()) F456_6544;
	R5558[2] = (char *(*)()) F457_6760;
	R5558[4] = (char *(*)()) F456_6544;
}

char *(*R5559[5])();
void R5559_init () {
	R5559[0] = (char *(*)()) F456_6545;
	R5559[2] = (char *(*)()) F457_6761;
	R5559[4] = (char *(*)()) F456_6545;
}

char *(*R5560[5])();
void R5560_init () {
	R5560[0] = (char *(*)()) F456_6546;
	R5560[2] = (char *(*)()) F457_6762;
	R5560[4] = (char *(*)()) F460_6957;
}

char *(*R5561[5])();
void R5561_init () {
	R5561[0] = (char *(*)()) F456_6547;
	R5561[2] = (char *(*)()) F457_6763;
	R5561[4] = (char *(*)()) F456_6547;
}

char *(*R5562[5])();
void R5562_init () {
	R5562[0] = (char *(*)()) F456_6548;
	R5562[2] = (char *(*)()) F457_6764;
	R5562[4] = (char *(*)()) F456_6548;
}

char *(*R5563[5])();
void R5563_init () {
	R5563[0] = (char *(*)()) F456_6549;
	R5563[2] = (char *(*)()) F457_6765;
	R5563[4] = (char *(*)()) F456_6549;
}

char *(*R5564[5])();
void R5564_init () {
	R5564[0] = (char *(*)()) F456_6550;
	R5564[2] = (char *(*)()) F457_6766;
	R5564[4] = (char *(*)()) F456_6550;
}

char *(*R5565[5])();
void R5565_init () {
	R5565[0] = (char *(*)()) F456_6551;
	R5565[2] = (char *(*)()) F457_6767;
	R5565[4] = (char *(*)()) F456_6551;
}

char *(*R5566[5])();
void R5566_init () {
	R5566[0] = (char *(*)()) F456_6552;
	R5566[2] = (char *(*)()) F457_6768;
	R5566[4] = (char *(*)()) F456_6552;
}

char *(*R5567[5])();
void R5567_init () {
	R5567[0] = (char *(*)()) F456_6553;
	R5567[2] = (char *(*)()) F457_6769;
	R5567[4] = (char *(*)()) F456_6553;
}

char *(*R5568[5])();
void R5568_init () {
	R5568[0] = (char *(*)()) F456_6554;
	R5568[2] = (char *(*)()) F457_6770;
	R5568[4] = (char *(*)()) F456_6554;
}

char *(*R5569[5])();
void R5569_init () {
	R5569[0] = (char *(*)()) F456_6555;
	R5569[2] = (char *(*)()) F457_6771;
	R5569[4] = (char *(*)()) F456_6555;
}

char *(*R5570[5])();
void R5570_init () {
	R5570[0] = (char *(*)()) F456_6556;
	R5570[2] = (char *(*)()) F457_6772;
	R5570[4] = (char *(*)()) F456_6556;
}

char *(*R5571[5])();
void R5571_init () {
	R5571[0] = (char *(*)()) F456_6557;
	R5571[2] = (char *(*)()) F457_6773;
	R5571[4] = (char *(*)()) F456_6557;
}

char *(*R5572[5])();
void R5572_init () {
	R5572[0] = (char *(*)()) F456_6558;
	R5572[2] = (char *(*)()) F457_6774;
	R5572[4] = (char *(*)()) F456_6558;
}

char *(*R5573[5])();
void R5573_init () {
	R5573[0] = (char *(*)()) F456_6559;
	R5573[2] = (char *(*)()) F457_6775;
	R5573[4] = (char *(*)()) F456_6559;
}

char *(*R5574[5])();
void R5574_init () {
	R5574[0] = (char *(*)()) F456_6560;
	R5574[2] = (char *(*)()) F457_6776;
	R5574[4] = (char *(*)()) F456_6560;
}

char *(*R5575[5])();
void R5575_init () {
	R5575[0] = (char *(*)()) F456_6561;
	R5575[2] = (char *(*)()) F457_6777;
	R5575[4] = (char *(*)()) F456_6561;
}

char *(*R5576[5])();
void R5576_init () {
	R5576[0] = (char *(*)()) F456_6562;
	R5576[2] = (char *(*)()) F457_6778;
	R5576[4] = (char *(*)()) F456_6562;
}

char *(*R5577[5])();
void R5577_init () {
	R5577[0] = (char *(*)()) F456_6563;
	R5577[2] = (char *(*)()) F457_6779;
	R5577[4] = (char *(*)()) F456_6563;
}

char *(*R5578[5])();
void R5578_init () {
	R5578[0] = (char *(*)()) F456_6564;
	R5578[2] = (char *(*)()) F457_6780;
	R5578[4] = (char *(*)()) F456_6564;
}

char *(*R5579[5])();
void R5579_init () {
	R5579[0] = (char *(*)()) F456_6565;
	R5579[2] = (char *(*)()) F457_6781;
	R5579[4] = (char *(*)()) F456_6565;
}

char *(*R5580[5])();
void R5580_init () {
	R5580[0] = (char *(*)()) F456_6566;
	R5580[2] = (char *(*)()) F457_6782;
	R5580[4] = (char *(*)()) F456_6566;
}

char *(*R5581[5])();
void R5581_init () {
	R5581[0] = (char *(*)()) F456_6567;
	R5581[2] = (char *(*)()) F457_6783;
	R5581[4] = (char *(*)()) F456_6567;
}

char *(*R5582[5])();
void R5582_init () {
	R5582[0] = (char *(*)()) F456_6568;
	R5582[2] = (char *(*)()) F457_6784;
	R5582[4] = (char *(*)()) F456_6568;
}

char *(*R5583[5])();
void R5583_init () {
	R5583[0] = (char *(*)()) F456_6569;
	R5583[2] = (char *(*)()) F457_6785;
	R5583[4] = (char *(*)()) F456_6569;
}

char *(*R5584[5])();
void R5584_init () {
	R5584[0] = (char *(*)()) F456_6570;
	R5584[2] = (char *(*)()) F457_6786;
	R5584[4] = (char *(*)()) F456_6570;
}

char *(*R5585[5])();
void R5585_init () {
	R5585[0] = (char *(*)()) F456_6571;
	R5585[2] = (char *(*)()) F457_6787;
	R5585[4] = (char *(*)()) F456_6571;
}

char *(*R5586[5])();
void R5586_init () {
	R5586[0] = (char *(*)()) F456_6572;
	R5586[2] = (char *(*)()) F457_6788;
	R5586[4] = (char *(*)()) F456_6572;
}

char *(*R5587[5])();
void R5587_init () {
	R5587[0] = (char *(*)()) F456_6573;
	R5587[2] = (char *(*)()) F457_6789;
	R5587[4] = (char *(*)()) F456_6573;
}

char *(*R5588[5])();
void R5588_init () {
	R5588[0] = (char *(*)()) F456_6574;
	R5588[2] = (char *(*)()) F457_6790;
	R5588[4] = (char *(*)()) F456_6574;
}

char *(*R5589[5])();
void R5589_init () {
	R5589[0] = (char *(*)()) F456_6575;
	R5589[2] = (char *(*)()) F457_6791;
	R5589[4] = (char *(*)()) F456_6575;
}

char *(*R5591[5])();
void R5591_init () {
	R5591[0] = (char *(*)()) F456_6577;
	R5591[2] = (char *(*)()) F457_6792;
	R5591[4] = (char *(*)()) F456_6577;
}

char *(*R5592[5])();
void R5592_init () {
	R5592[0] = (char *(*)()) F456_6578;
	R5592[2] = (char *(*)()) F457_6793;
	R5592[4] = (char *(*)()) F456_6578;
}

char *(*R5593[5])();
void R5593_init () {
	R5593[0] = (char *(*)()) F456_6579;
	R5593[2] = (char *(*)()) F457_6794;
	R5593[4] = (char *(*)()) F456_6579;
}

char *(*R5594[5])();
void R5594_init () {
	R5594[0] = (char *(*)()) F456_6580;
	R5594[2] = (char *(*)()) F457_6795;
	R5594[4] = (char *(*)()) F456_6580;
}

char *(*R5595[5])();
void R5595_init () {
	R5595[0] = (char *(*)()) F456_6581;
	R5595[2] = (char *(*)()) F457_6796;
	R5595[4] = (char *(*)()) F456_6581;
}

char *(*R5596[5])();
void R5596_init () {
	R5596[0] = (char *(*)()) F456_6582;
	R5596[2] = (char *(*)()) F457_6797;
	R5596[4] = (char *(*)()) F456_6582;
}

char *(*R5597[5])();
void R5597_init () {
	R5597[0] = (char *(*)()) F456_6583;
	R5597[2] = (char *(*)()) F457_6798;
	R5597[4] = (char *(*)()) F456_6583;
}

char *(*R5598[5])();
void R5598_init () {
	R5598[0] = (char *(*)()) F456_6584;
	R5598[2] = (char *(*)()) F457_6799;
	R5598[4] = (char *(*)()) F456_6584;
}

char *(*R5599[5])();
void R5599_init () {
	R5599[0] = (char *(*)()) F456_6585;
	R5599[2] = (char *(*)()) F457_6800;
	R5599[4] = (char *(*)()) F456_6585;
}

char *(*R5600[5])();
void R5600_init () {
	R5600[0] = (char *(*)()) F456_6586;
	R5600[2] = (char *(*)()) F457_6801;
	R5600[4] = (char *(*)()) F456_6586;
}

char *(*R5601[5])();
void R5601_init () {
	R5601[0] = (char *(*)()) F456_6587;
	R5601[2] = (char *(*)()) F457_6802;
	R5601[4] = (char *(*)()) F456_6587;
}

char *(*R5602[5])();
void R5602_init () {
	R5602[0] = (char *(*)()) F456_6588;
	R5602[2] = (char *(*)()) F457_6803;
	R5602[4] = (char *(*)()) F456_6588;
}

char *(*R5603[5])();
void R5603_init () {
	R5603[0] = (char *(*)()) F456_6589;
	R5603[2] = (char *(*)()) F457_6804;
	R5603[4] = (char *(*)()) F456_6589;
}

char *(*R5604[5])();
void R5604_init () {
	R5604[0] = (char *(*)()) F456_6590;
	R5604[2] = (char *(*)()) F457_6805;
	R5604[4] = (char *(*)()) F456_6590;
}

char *(*R5605[5])();
void R5605_init () {
	R5605[0] = (char *(*)()) F456_6591;
	R5605[2] = (char *(*)()) F458_6890;
	R5605[4] = (char *(*)()) F460_6950;
}

char *(*R5607[5])();
void R5607_init () {
	R5607[0] = (char *(*)()) F456_6593;
	R5607[2] = (char *(*)()) F457_6808;
	R5607[4] = (char *(*)()) F456_6593;
}

char *(*R5608[5])();
void R5608_init () {
	R5608[0] = (char *(*)()) F456_6594;
	R5608[2] = (char *(*)()) F457_6809;
	R5608[4] = (char *(*)()) F456_6594;
}

char *(*R5609[5])();
void R5609_init () {
	R5609[0] = (char *(*)()) F456_6595;
	R5609[2] = (char *(*)()) F457_6810;
	R5609[4] = (char *(*)()) F456_6595;
}

char *(*R5610[5])();
void R5610_init () {
	R5610[0] = (char *(*)()) F456_6596;
	R5610[2] = (char *(*)()) F457_6811;
	R5610[4] = (char *(*)()) F456_6596;
}

char *(*R5611[5])();
void R5611_init () {
	R5611[0] = (char *(*)()) F456_6597;
	R5611[2] = (char *(*)()) F457_6812;
	R5611[4] = (char *(*)()) F456_6597;
}

char *(*R5612[5])();
void R5612_init () {
	R5612[0] = (char *(*)()) F456_6598;
	R5612[2] = (char *(*)()) F457_6813;
	R5612[4] = (char *(*)()) F456_6598;
}

char *(*R5613[5])();
void R5613_init () {
	R5613[0] = (char *(*)()) F456_6599;
	R5613[2] = (char *(*)()) F457_6814;
	R5613[4] = (char *(*)()) F456_6599;
}

char *(*R5614[5])();
void R5614_init () {
	R5614[0] = (char *(*)()) F456_6600;
	R5614[2] = (char *(*)()) F457_6815;
	R5614[4] = (char *(*)()) F456_6600;
}

char *(*R5615[5])();
void R5615_init () {
	R5615[0] = (char *(*)()) F456_6601;
	R5615[2] = (char *(*)()) F457_6816;
	R5615[4] = (char *(*)()) F460_6945;
}

char *(*R5616[5])();
void R5616_init () {
	R5616[0] = (char *(*)()) F456_6602;
	R5616[2] = (char *(*)()) F457_6817;
	R5616[4] = (char *(*)()) F460_6946;
}

char *(*R5617[5])();
void R5617_init () {
	R5617[0] = (char *(*)()) F456_6603;
	R5617[2] = (char *(*)()) F457_6818;
	R5617[4] = (char *(*)()) F460_6947;
}

char *(*R5618[5])();
void R5618_init () {
	R5618[0] = (char *(*)()) F456_6604;
	R5618[2] = (char *(*)()) F457_6819;
	R5618[4] = (char *(*)()) F460_6948;
}

char *(*R5619[5])();
void R5619_init () {
	R5619[0] = (char *(*)()) F456_6605;
	R5619[2] = (char *(*)()) F457_6820;
	R5619[4] = (char *(*)()) F456_6605;
}

char *(*R5620[5])();
void R5620_init () {
	R5620[0] = (char *(*)()) F456_6606;
	R5620[2] = (char *(*)()) F457_6821;
	R5620[4] = (char *(*)()) F456_6606;
}

char *(*R5621[5])();
void R5621_init () {
	R5621[0] = (char *(*)()) F456_6607;
	R5621[2] = (char *(*)()) F458_6885;
	R5621[4] = (char *(*)()) F456_6607;
}

char *(*R5623[5])();
void R5623_init () {
	R5623[0] = (char *(*)()) F456_6609;
	R5623[2] = (char *(*)()) F457_6823;
	R5623[4] = (char *(*)()) F456_6609;
}

char *(*R5624[5])();
void R5624_init () {
	R5624[0] = (char *(*)()) F456_6610;
	R5624[2] = (char *(*)()) F457_6824;
	R5624[4] = (char *(*)()) F456_6610;
}

char *(*R5626[5])();
void R5626_init () {
	R5626[0] = (char *(*)()) F456_6612;
	R5626[2] = (char *(*)()) F457_6826;
	R5626[4] = (char *(*)()) F456_6612;
}

char *(*R5627[5])();
void R5627_init () {
	R5627[0] = (char *(*)()) F456_6613;
	R5627[2] = (char *(*)()) F457_6827;
	R5627[4] = (char *(*)()) F456_6613;
}

char *(*R5628[5])();
void R5628_init () {
	R5628[0] = (char *(*)()) F456_6614;
	R5628[2] = (char *(*)()) F457_6828;
	R5628[4] = (char *(*)()) F456_6614;
}

char *(*R5629[5])();
void R5629_init () {
	R5629[0] = (char *(*)()) F456_6615;
	R5629[2] = (char *(*)()) F457_6829;
	R5629[4] = (char *(*)()) F456_6615;
}

char *(*R5630[5])();
void R5630_init () {
	R5630[0] = (char *(*)()) F456_6616;
	R5630[2] = (char *(*)()) F457_6830;
	R5630[4] = (char *(*)()) F456_6616;
}

char *(*R5631[5])();
void R5631_init () {
	R5631[0] = (char *(*)()) F456_6617;
	R5631[2] = (char *(*)()) F457_6831;
	R5631[4] = (char *(*)()) F456_6617;
}

char *(*R5632[5])();
void R5632_init () {
	R5632[0] = (char *(*)()) F456_6618;
	R5632[2] = (char *(*)()) F458_6888;
	R5632[4] = (char *(*)()) F456_6618;
}

char *(*R5633[5])();
void R5633_init () {
	R5633[0] = (char *(*)()) F456_6619;
	R5633[2] = (char *(*)()) F457_6833;
	R5633[4] = (char *(*)()) F456_6619;
}

char *(*R5634[5])();
void R5634_init () {
	R5634[0] = (char *(*)()) F456_6620;
	R5634[2] = (char *(*)()) F457_6834;
	R5634[4] = (char *(*)()) F456_6620;
}

char *(*R5635[5])();
void R5635_init () {
	R5635[0] = (char *(*)()) F456_6621;
	R5635[2] = (char *(*)()) F457_6835;
	R5635[4] = (char *(*)()) F456_6621;
}

char *(*R5636[5])();
void R5636_init () {
	R5636[0] = (char *(*)()) F456_6622;
	R5636[2] = (char *(*)()) F457_6836;
	R5636[4] = (char *(*)()) F456_6622;
}

char *(*R5637[5])();
void R5637_init () {
	R5637[0] = (char *(*)()) F456_6623;
	R5637[2] = (char *(*)()) F457_6837;
	R5637[4] = (char *(*)()) F456_6623;
}

char *(*R5638[5])();
void R5638_init () {
	R5638[0] = (char *(*)()) F456_6624;
	R5638[2] = (char *(*)()) F457_6840;
	R5638[4] = (char *(*)()) F456_6624;
}

char *(*R5639[5])();
void R5639_init () {
	R5639[0] = (char *(*)()) F456_6625;
	R5639[2] = (char *(*)()) F457_6838;
	R5639[4] = (char *(*)()) F456_6625;
}

char *(*R5640[5])();
void R5640_init () {
	R5640[0] = (char *(*)()) F456_6626;
	R5640[2] = (char *(*)()) F457_6839;
	R5640[4] = (char *(*)()) F456_6626;
}

char *(*R5641[5])();
void R5641_init () {
	R5641[0] = (char *(*)()) F456_6627;
	R5641[2] = (char *(*)()) F457_6841;
	R5641[4] = (char *(*)()) F460_6949;
}

char *(*R5642[5])();
void R5642_init () {
	R5642[0] = (char *(*)()) F456_6628;
	R5642[2] = (char *(*)()) F457_6842;
	R5642[4] = (char *(*)()) F456_6628;
}

char *(*R5643[5])();
void R5643_init () {
	R5643[0] = (char *(*)()) F456_6629;
	R5643[2] = (char *(*)()) F457_6843;
	R5643[4] = (char *(*)()) F456_6629;
}

char *(*R5644[5])();
void R5644_init () {
	R5644[0] = (char *(*)()) F456_6630;
	R5644[2] = (char *(*)()) F457_6844;
	R5644[4] = (char *(*)()) F456_6630;
}

char *(*R5645[5])();
void R5645_init () {
	R5645[0] = (char *(*)()) F456_6631;
	R5645[2] = (char *(*)()) F457_6845;
	R5645[4] = (char *(*)()) F460_6954;
}

char *(*R5646[5])();
void R5646_init () {
	R5646[0] = (char *(*)()) F456_6632;
	R5646[2] = (char *(*)()) F457_6846;
	R5646[4] = (char *(*)()) F460_6953;
}

char *(*R5647[5])();
void R5647_init () {
	R5647[0] = (char *(*)()) F456_6633;
	R5647[2] = (char *(*)()) F457_6847;
	R5647[4] = (char *(*)()) F456_6633;
}

char *(*R5648[5])();
void R5648_init () {
	R5648[0] = (char *(*)()) F456_6634;
	R5648[2] = (char *(*)()) F457_6848;
	R5648[4] = (char *(*)()) F456_6634;
}

char *(*R5649[5])();
void R5649_init () {
	R5649[0] = (char *(*)()) F456_6635;
	R5649[2] = (char *(*)()) F457_6849;
	R5649[4] = (char *(*)()) F456_6635;
}

char *(*R5650[5])();
void R5650_init () {
	R5650[0] = (char *(*)()) F456_6636;
	R5650[2] = (char *(*)()) F458_6889;
	R5650[4] = (char *(*)()) F456_6636;
}

char *(*R5651[5])();
void R5651_init () {
	R5651[0] = (char *(*)()) F456_6637;
	R5651[2] = (char *(*)()) F457_6851;
	R5651[4] = (char *(*)()) F460_6943;
}

char *(*R5652[5])();
void R5652_init () {
	R5652[0] = (char *(*)()) F456_6638;
	R5652[2] = (char *(*)()) F457_6852;
	R5652[4] = (char *(*)()) F456_6638;
}

char *(*R5653[5])();
void R5653_init () {
	R5653[0] = (char *(*)()) F456_6639;
	R5653[2] = (char *(*)()) F457_6853;
	R5653[4] = (char *(*)()) F456_6639;
}

char *(*R5654[5])();
void R5654_init () {
	R5654[0] = (char *(*)()) F456_6640;
	R5654[2] = (char *(*)()) F457_6854;
	R5654[4] = (char *(*)()) F456_6640;
}

char *(*R5655[5])();
void R5655_init () {
	R5655[0] = (char *(*)()) F456_6641;
	R5655[2] = (char *(*)()) F457_6855;
	R5655[4] = (char *(*)()) F456_6641;
}

char *(*R5656[5])();
void R5656_init () {
	R5656[0] = (char *(*)()) F456_6642;
	R5656[2] = (char *(*)()) F457_6856;
	R5656[4] = (char *(*)()) F456_6642;
}

char *(*R5657[5])();
void R5657_init () {
	R5657[0] = (char *(*)()) F456_6643;
	R5657[2] = (char *(*)()) F457_6857;
	R5657[4] = (char *(*)()) F456_6643;
}

char *(*R5658[5])();
void R5658_init () {
	R5658[0] = (char *(*)()) F456_6644;
	R5658[2] = (char *(*)()) F457_6858;
	R5658[4] = (char *(*)()) F456_6644;
}

char *(*R5659[5])();
void R5659_init () {
	R5659[0] = (char *(*)()) F456_6645;
	R5659[2] = (char *(*)()) F457_6859;
	R5659[4] = (char *(*)()) F456_6645;
}

char *(*R5660[5])();
void R5660_init () {
	R5660[0] = (char *(*)()) F456_6646;
	R5660[2] = (char *(*)()) F457_6860;
	R5660[4] = (char *(*)()) F456_6646;
}

char *(*R5661[5])();
void R5661_init () {
	R5661[0] = (char *(*)()) F456_6647;
	R5661[2] = (char *(*)()) F457_6861;
	R5661[4] = (char *(*)()) F456_6647;
}

char *(*R5662[5])();
void R5662_init () {
	R5662[0] = (char *(*)()) F456_6648;
	R5662[2] = (char *(*)()) F457_6862;
	R5662[4] = (char *(*)()) F456_6648;
}

char *(*R5663[5])();
void R5663_init () {
	R5663[0] = (char *(*)()) F456_6649;
	R5663[2] = (char *(*)()) F457_6863;
	R5663[4] = (char *(*)()) F460_6952;
}

char *(*R5664[5])();
void R5664_init () {
	R5664[0] = (char *(*)()) F456_6650;
	R5664[2] = (char *(*)()) F457_6864;
	R5664[4] = (char *(*)()) F456_6650;
}

char *(*R5665[5])();
void R5665_init () {
	R5665[0] = (char *(*)()) F456_6651;
	R5665[2] = (char *(*)()) F457_6865;
	R5665[4] = (char *(*)()) F460_6944;
}

char *(*R5666[5])();
void R5666_init () {
	R5666[0] = (char *(*)()) F456_6652;
	R5666[2] = (char *(*)()) F457_6866;
	R5666[4] = (char *(*)()) F460_6951;
}

char *(*R5667[5])();
void R5667_init () {
	R5667[0] = (char *(*)()) F456_6653;
	R5667[2] = (char *(*)()) F457_6867;
	R5667[4] = (char *(*)()) F456_6653;
}

char *(*R5668[5])();
void R5668_init () {
	R5668[0] = (char *(*)()) F456_6654;
	R5668[2] = (char *(*)()) F457_6868;
	R5668[4] = (char *(*)()) F456_6654;
}

char *(*R5669[5])();
void R5669_init () {
	R5669[0] = (char *(*)()) F456_6655;
	R5669[2] = (char *(*)()) F457_6869;
	R5669[4] = (char *(*)()) F456_6655;
}

char *(*R5670[5])();
void R5670_init () {
	R5670[0] = (char *(*)()) F456_6656;
	R5670[2] = (char *(*)()) F457_6870;
	R5670[4] = (char *(*)()) F456_6656;
}

char *(*R5671[5])();
void R5671_init () {
	R5671[0] = (char *(*)()) F456_6657;
	R5671[2] = (char *(*)()) F457_6871;
	R5671[4] = (char *(*)()) F456_6657;
}

char *(*R5672[5])();
void R5672_init () {
	R5672[0] = (char *(*)()) F456_6658;
	R5672[2] = (char *(*)()) F457_6872;
	R5672[4] = (char *(*)()) F456_6658;
}

char *(*R5673[5])();
void R5673_init () {
	R5673[0] = (char *(*)()) F456_6659;
	R5673[2] = (char *(*)()) F457_6873;
	R5673[4] = (char *(*)()) F456_6659;
}

char *(*R5674[5])();
void R5674_init () {
	R5674[0] = (char *(*)()) F456_6660;
	R5674[2] = (char *(*)()) F457_6874;
	R5674[4] = (char *(*)()) F456_6660;
}

char *(*R5675[5])();
void R5675_init () {
	R5675[0] = (char *(*)()) F456_6661;
	R5675[2] = (char *(*)()) F457_6875;
	R5675[4] = (char *(*)()) F456_6661;
}

char *(*R5676[5])();
void R5676_init () {
	R5676[0] = (char *(*)()) F456_6662;
	R5676[2] = (char *(*)()) F457_6876;
	R5676[4] = (char *(*)()) F456_6662;
}

char *(*R5677[5])();
void R5677_init () {
	R5677[0] = (char *(*)()) F456_6663;
	R5677[2] = (char *(*)()) F457_6877;
	R5677[4] = (char *(*)()) F456_6663;
}

char *(*R5695[284])();
void R5695_init () {
	R5695[0] = (char *(*)()) F473_6969;
	R5695[1] = (char *(*)()) F474_6969_5695_1;
	R5695[2] = (char *(*)()) F475_6969_5695_1;
	R5695[3] = (char *(*)()) F476_6975;
	R5695[4] = (char *(*)()) F477_6984_5695_1;
	R5695[55] = (char *(*)()) F516_7085;
	R5695[56] = (char *(*)()) F517_7085_5695_1;
	R5695[57] = (char *(*)()) F518_7085_5695_1;
	R5695[58] = (char *(*)()) F519_7085_5695_1;
	R5695[59] = (char *(*)()) F520_7085_5695_1;
	R5695[60] = (char *(*)()) F521_7085_5695_1;
	R5695[61] = (char *(*)()) F522_7085_5695_1;
	R5695[62] = (char *(*)()) F523_7085_5695_1;
	R5695[63] = (char *(*)()) F524_7085_5695_1;
	R5695[64] = (char *(*)()) F525_7085_5695_1;
	R5695[65] = (char *(*)()) F526_7085_5695_1;
	R5695[66] = (char *(*)()) F527_7085_5695_1;
	R5695[67] = (char *(*)()) F540_7113;
	R5695[68] = (char *(*)()) F541_7113;
	R5695[69] = (char *(*)()) F542_7113_5695_1;
	R5695[70] = (char *(*)()) F543_7113_5695_1;
	R5695[71] = (char *(*)()) F544_7113_5695_1;
	R5695[72] = (char *(*)()) F545_7113_5695_1;
	R5695[73] = (char *(*)()) F546_7113_5695_1;
	R5695[74] = (char *(*)()) F547_7113_5695_1;
	R5695[75] = (char *(*)()) F548_7119;
	R5695[76] = (char *(*)()) F549_7119_5695_1;
	R5695[77] = (char *(*)()) F550_7119_5695_1;
	R5695[78] = (char *(*)()) F551_7125;
	R5695[91] = (char *(*)()) F560_7131_5695_1;
	R5695[92] = (char *(*)()) F562_7131_5695_1;
	R5695[93] = (char *(*)()) F552_7131;
	R5695[94] = (char *(*)()) F553_7131_5695_1;
	R5695[95] = (char *(*)()) F554_7131_5695_1;
	R5695[96] = (char *(*)()) F555_7131_5695_1;
	R5695[97] = (char *(*)()) F556_7131_5695_1;
	R5695[98] = (char *(*)()) F557_7131_5695_1;
	R5695[99] = (char *(*)()) F558_7131_5695_1;
	R5695[100] = (char *(*)()) F559_7131_5695_1;
	R5695[101] = (char *(*)()) F560_7131_5695_1;
	R5695[102] = (char *(*)()) F561_7131_5695_1;
	R5695[103] = (char *(*)()) F562_7131_5695_1;
	R5695[104] = (char *(*)()) F563_7131_5695_1;
	R5695[105] = (char *(*)()) F552_7131;
	R5695[106] = (char *(*)()) F553_7131_5695_1;
	R5695[107] = (char *(*)()) F554_7131_5695_1;
	R5695[108] = (char *(*)()) F555_7131_5695_1;
	R5695[109] = (char *(*)()) F556_7131_5695_1;
	R5695[110] = (char *(*)()) F557_7131_5695_1;
	R5695[111] = (char *(*)()) F558_7131_5695_1;
	R5695[112] = (char *(*)()) F559_7131_5695_1;
	R5695[113] = (char *(*)()) F560_7131_5695_1;
	R5695[114] = (char *(*)()) F561_7131_5695_1;
	R5695[115] = (char *(*)()) F562_7131_5695_1;
	R5695[116] = (char *(*)()) F563_7131_5695_1;
	R5695[117] = (char *(*)()) F552_7131;
	R5695[118] = (char *(*)()) F553_7131_5695_1;
	R5695[119] = (char *(*)()) F554_7131_5695_1;
	R5695[120] = (char *(*)()) F555_7131_5695_1;
	R5695[121] = (char *(*)()) F556_7131_5695_1;
	R5695[122] = (char *(*)()) F557_7131_5695_1;
	R5695[123] = (char *(*)()) F558_7131_5695_1;
	R5695[124] = (char *(*)()) F559_7131_5695_1;
	R5695[125] = (char *(*)()) F560_7131_5695_1;
	R5695[126] = (char *(*)()) F561_7131_5695_1;
	R5695[127] = (char *(*)()) F562_7131_5695_1;
	R5695[128] = (char *(*)()) F563_7131_5695_1;
	{long i; for (i = 282; i < 284; i++) R5695[i] = (char *(*)()) F754_7300_5695_1;}
}
static EIF_REFERENCE F474_6969_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F474_6969(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F475_6969_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F475_6969(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F477_6984_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F477_6984(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F517_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F517_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F518_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F518_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F519_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F519_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F520_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F520_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F521_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F521_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F522_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F522_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F523_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F523_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F524_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F524_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F525_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F525_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F526_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F527_7085_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F527_7085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F542_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F542_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F543_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F543_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F544_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F544_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F545_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F545_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F546_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F546_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F547_7113_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F547_7113(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_7119_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F549_7119(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_7119_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F550_7119(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F560_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F560_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F562_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F562_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F553_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F553_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F554_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F554_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F555_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F555_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F556_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F557_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F558_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F558_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F559_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F559_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F561_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F561_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F563_7131_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F563_7131(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F754_7300_5695_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F754_7300(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5696[284])();
void R5696_init () {
	R5696[0] = (char *(*)()) F473_6970;
	R5696[1] = (char *(*)()) F474_6970;
	R5696[2] = (char *(*)()) F475_6970;
	R5696[3] = (char *(*)()) F476_6976;
	R5696[4] = (char *(*)()) F477_6986;
	R5696[55] = (char *(*)()) F528_7103;
	R5696[56] = (char *(*)()) F529_7103;
	R5696[57] = (char *(*)()) F530_7103;
	R5696[58] = (char *(*)()) F531_7103;
	R5696[59] = (char *(*)()) F532_7103;
	R5696[60] = (char *(*)()) F533_7103;
	R5696[61] = (char *(*)()) F534_7103;
	R5696[62] = (char *(*)()) F535_7103;
	R5696[63] = (char *(*)()) F536_7103;
	R5696[64] = (char *(*)()) F537_7103;
	R5696[65] = (char *(*)()) F538_7103;
	R5696[66] = (char *(*)()) F539_7103;
	R5696[67] = (char *(*)()) F540_7116;
	R5696[68] = (char *(*)()) F541_7116;
	R5696[69] = (char *(*)()) F542_7116;
	R5696[70] = (char *(*)()) F543_7116;
	R5696[71] = (char *(*)()) F544_7116;
	R5696[72] = (char *(*)()) F545_7116;
	R5696[73] = (char *(*)()) F546_7116;
	R5696[74] = (char *(*)()) F547_7116;
	R5696[75] = (char *(*)()) F548_7120;
	R5696[76] = (char *(*)()) F549_7120;
	R5696[77] = (char *(*)()) F550_7120;
	R5696[78] = (char *(*)()) F551_7126;
	R5696[91] = (char *(*)()) F560_7140;
	R5696[92] = (char *(*)()) F562_7140;
	R5696[93] = (char *(*)()) F552_7140;
	R5696[94] = (char *(*)()) F553_7140;
	R5696[95] = (char *(*)()) F554_7140;
	R5696[96] = (char *(*)()) F555_7140;
	R5696[97] = (char *(*)()) F556_7140;
	R5696[98] = (char *(*)()) F557_7140;
	R5696[99] = (char *(*)()) F558_7140;
	R5696[100] = (char *(*)()) F559_7140;
	R5696[101] = (char *(*)()) F560_7140;
	R5696[102] = (char *(*)()) F561_7140;
	R5696[103] = (char *(*)()) F562_7140;
	R5696[104] = (char *(*)()) F563_7140;
	R5696[105] = (char *(*)()) F552_7140;
	R5696[106] = (char *(*)()) F553_7140;
	R5696[107] = (char *(*)()) F554_7140;
	R5696[108] = (char *(*)()) F555_7140;
	R5696[109] = (char *(*)()) F556_7140;
	R5696[110] = (char *(*)()) F557_7140;
	R5696[111] = (char *(*)()) F558_7140;
	R5696[112] = (char *(*)()) F559_7140;
	R5696[113] = (char *(*)()) F560_7140;
	R5696[114] = (char *(*)()) F561_7140;
	R5696[115] = (char *(*)()) F562_7140;
	R5696[116] = (char *(*)()) F563_7140;
	R5696[117] = (char *(*)()) F552_7140;
	R5696[118] = (char *(*)()) F553_7140;
	R5696[119] = (char *(*)()) F554_7140;
	R5696[120] = (char *(*)()) F555_7140;
	R5696[121] = (char *(*)()) F556_7140;
	R5696[122] = (char *(*)()) F557_7140;
	R5696[123] = (char *(*)()) F558_7140;
	R5696[124] = (char *(*)()) F559_7140;
	R5696[125] = (char *(*)()) F560_7140;
	R5696[126] = (char *(*)()) F561_7140;
	R5696[127] = (char *(*)()) F562_7140;
	R5696[128] = (char *(*)()) F563_7140;
	{long i; for (i = 282; i < 284; i++) R5696[i] = (char *(*)()) F754_7301;}
}

char *(*R5697[284])();
void R5697_init () {
	R5697[0] = (char *(*)()) F473_6971;
	R5697[1] = (char *(*)()) F474_6971;
	R5697[2] = (char *(*)()) F475_6971;
	R5697[3] = (char *(*)()) F476_6977;
	R5697[4] = (char *(*)()) F477_6987;
	R5697[55] = (char *(*)()) F528_7111;
	R5697[56] = (char *(*)()) F529_7111;
	R5697[57] = (char *(*)()) F530_7111;
	R5697[58] = (char *(*)()) F531_7111;
	R5697[59] = (char *(*)()) F532_7111;
	R5697[60] = (char *(*)()) F533_7111;
	R5697[61] = (char *(*)()) F534_7111;
	R5697[62] = (char *(*)()) F535_7111;
	R5697[63] = (char *(*)()) F536_7111;
	R5697[64] = (char *(*)()) F537_7111;
	R5697[65] = (char *(*)()) F538_7111;
	R5697[66] = (char *(*)()) F539_7111;
	R5697[67] = (char *(*)()) F540_7117;
	R5697[68] = (char *(*)()) F541_7117;
	R5697[69] = (char *(*)()) F542_7117;
	R5697[70] = (char *(*)()) F543_7117;
	R5697[71] = (char *(*)()) F544_7117;
	R5697[72] = (char *(*)()) F545_7117;
	R5697[73] = (char *(*)()) F546_7117;
	R5697[74] = (char *(*)()) F547_7117;
	R5697[75] = (char *(*)()) F548_7122;
	R5697[76] = (char *(*)()) F549_7122;
	R5697[77] = (char *(*)()) F550_7122;
	R5697[78] = (char *(*)()) F551_7128;
	R5697[91] = (char *(*)()) F560_7146;
	R5697[92] = (char *(*)()) F562_7146;
	R5697[93] = (char *(*)()) F552_7146;
	R5697[94] = (char *(*)()) F553_7146;
	R5697[95] = (char *(*)()) F554_7146;
	R5697[96] = (char *(*)()) F555_7146;
	R5697[97] = (char *(*)()) F556_7146;
	R5697[98] = (char *(*)()) F557_7146;
	R5697[99] = (char *(*)()) F558_7146;
	R5697[100] = (char *(*)()) F559_7146;
	R5697[101] = (char *(*)()) F560_7146;
	R5697[102] = (char *(*)()) F561_7146;
	R5697[103] = (char *(*)()) F562_7146;
	R5697[104] = (char *(*)()) F563_7146;
	R5697[105] = (char *(*)()) F552_7146;
	R5697[106] = (char *(*)()) F553_7146;
	R5697[107] = (char *(*)()) F554_7146;
	R5697[108] = (char *(*)()) F555_7146;
	R5697[109] = (char *(*)()) F556_7146;
	R5697[110] = (char *(*)()) F557_7146;
	R5697[111] = (char *(*)()) F558_7146;
	R5697[112] = (char *(*)()) F559_7146;
	R5697[113] = (char *(*)()) F560_7146;
	R5697[114] = (char *(*)()) F561_7146;
	R5697[115] = (char *(*)()) F562_7146;
	R5697[116] = (char *(*)()) F563_7146;
	R5697[117] = (char *(*)()) F552_7146;
	R5697[118] = (char *(*)()) F553_7146;
	R5697[119] = (char *(*)()) F554_7146;
	R5697[120] = (char *(*)()) F555_7146;
	R5697[121] = (char *(*)()) F556_7146;
	R5697[122] = (char *(*)()) F557_7146;
	R5697[123] = (char *(*)()) F558_7146;
	R5697[124] = (char *(*)()) F559_7146;
	R5697[125] = (char *(*)()) F560_7146;
	R5697[126] = (char *(*)()) F561_7146;
	R5697[127] = (char *(*)()) F562_7146;
	R5697[128] = (char *(*)()) F563_7146;
	{long i; for (i = 282; i < 284; i++) R5697[i] = (char *(*)()) F754_7307;}
}

static EIF_TYPE_INDEX Y5698_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype16[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype25[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype86[] = {1045,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype87[] = {1048,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype124[] = {1229,0xFFFF};
static EIF_TYPE_INDEX Y5698_pgtype125[] = {1229,0xFFFF};
EIF_TYPE_INDEX *Y5698_gen_type [296];
EIF_TYPE_INDEX Y5698 [296];
void Y5698_init (void)
{
	egc_routines_types [5698] = Y5698;
	egc_routines_gen_types [5698] = Y5698_gen_type;
	egc_routines_offset [5698] = 460;
	Y5698_gen_type [0] = Y5698_pgtype0;
	Y5698_gen_type [1] = Y5698_pgtype1;
	Y5698_gen_type [2] = Y5698_pgtype2;
	Y5698_gen_type [3] = Y5698_pgtype3;
	Y5698_gen_type [4] = Y5698_pgtype4;
	Y5698_gen_type [5] = Y5698_pgtype5;
	Y5698_gen_type [6] = Y5698_pgtype6;
	Y5698_gen_type [7] = Y5698_pgtype7;
	Y5698_gen_type [8] = Y5698_pgtype8;
	Y5698_gen_type [9] = Y5698_pgtype9;
	Y5698_gen_type [10] = Y5698_pgtype10;
	Y5698_gen_type [11] = Y5698_pgtype11;
	Y5698_gen_type [12] = Y5698_pgtype12;
	Y5698_gen_type [13] = Y5698_pgtype13;
	Y5698_gen_type [14] = Y5698_pgtype14;
	Y5698_gen_type [15] = Y5698_pgtype15;
	Y5698_gen_type [16] = Y5698_pgtype16;
	Y5698_gen_type [17] = Y5698_pgtype17;
	Y5698_gen_type [18] = Y5698_pgtype18;
	Y5698_gen_type [19] = Y5698_pgtype19;
	Y5698_gen_type [20] = Y5698_pgtype20;
	Y5698_gen_type [21] = Y5698_pgtype21;
	Y5698_gen_type [22] = Y5698_pgtype22;
	Y5698_gen_type [23] = Y5698_pgtype23;
	Y5698_gen_type [24] = Y5698_pgtype24;
	Y5698_gen_type [42] = Y5698_pgtype25;
	Y5698_gen_type [43] = Y5698_pgtype26;
	Y5698_gen_type [44] = Y5698_pgtype27;
	Y5698_gen_type [45] = Y5698_pgtype28;
	Y5698_gen_type [46] = Y5698_pgtype29;
	Y5698_gen_type [47] = Y5698_pgtype30;
	Y5698_gen_type [48] = Y5698_pgtype31;
	Y5698_gen_type [49] = Y5698_pgtype32;
	Y5698_gen_type [50] = Y5698_pgtype33;
	Y5698_gen_type [51] = Y5698_pgtype34;
	Y5698_gen_type [52] = Y5698_pgtype35;
	Y5698_gen_type [53] = Y5698_pgtype36;
	Y5698_gen_type [54] = Y5698_pgtype37;
	Y5698_gen_type [55] = Y5698_pgtype38;
	Y5698_gen_type [56] = Y5698_pgtype39;
	Y5698_gen_type [57] = Y5698_pgtype40;
	Y5698_gen_type [58] = Y5698_pgtype41;
	Y5698_gen_type [59] = Y5698_pgtype42;
	Y5698_gen_type [60] = Y5698_pgtype43;
	Y5698_gen_type [61] = Y5698_pgtype44;
	Y5698_gen_type [62] = Y5698_pgtype45;
	Y5698_gen_type [63] = Y5698_pgtype46;
	Y5698_gen_type [64] = Y5698_pgtype47;
	Y5698_gen_type [65] = Y5698_pgtype48;
	Y5698_gen_type [66] = Y5698_pgtype49;
	Y5698_gen_type [67] = Y5698_pgtype50;
	Y5698_gen_type [68] = Y5698_pgtype51;
	Y5698_gen_type [69] = Y5698_pgtype52;
	Y5698_gen_type [70] = Y5698_pgtype53;
	Y5698_gen_type [71] = Y5698_pgtype54;
	Y5698_gen_type [72] = Y5698_pgtype55;
	Y5698_gen_type [73] = Y5698_pgtype56;
	Y5698_gen_type [74] = Y5698_pgtype57;
	Y5698_gen_type [75] = Y5698_pgtype58;
	Y5698_gen_type [76] = Y5698_pgtype59;
	Y5698_gen_type [77] = Y5698_pgtype60;
	Y5698_gen_type [78] = Y5698_pgtype61;
	Y5698_gen_type [79] = Y5698_pgtype62;
	Y5698_gen_type [80] = Y5698_pgtype63;
	Y5698_gen_type [81] = Y5698_pgtype64;
	Y5698_gen_type [82] = Y5698_pgtype65;
	Y5698_gen_type [83] = Y5698_pgtype66;
	Y5698_gen_type [84] = Y5698_pgtype67;
	Y5698_gen_type [85] = Y5698_pgtype68;
	Y5698_gen_type [86] = Y5698_pgtype69;
	Y5698_gen_type [87] = Y5698_pgtype70;
	Y5698_gen_type [88] = Y5698_pgtype71;
	Y5698_gen_type [89] = Y5698_pgtype72;
	Y5698_gen_type [90] = Y5698_pgtype73;
	Y5698_gen_type [91] = Y5698_pgtype74;
	Y5698_gen_type [92] = Y5698_pgtype75;
	Y5698_gen_type [93] = Y5698_pgtype76;
	Y5698_gen_type [94] = Y5698_pgtype77;
	Y5698_gen_type [95] = Y5698_pgtype78;
	Y5698_gen_type [96] = Y5698_pgtype79;
	Y5698_gen_type [97] = Y5698_pgtype80;
	Y5698_gen_type [98] = Y5698_pgtype81;
	Y5698_gen_type [99] = Y5698_pgtype82;
	Y5698_gen_type [100] = Y5698_pgtype83;
	Y5698_gen_type [101] = Y5698_pgtype84;
	Y5698_gen_type [102] = Y5698_pgtype85;
	Y5698_gen_type [103] = Y5698_pgtype86;
	Y5698_gen_type [104] = Y5698_pgtype87;
	Y5698_gen_type [105] = Y5698_pgtype88;
	Y5698_gen_type [106] = Y5698_pgtype89;
	Y5698_gen_type [107] = Y5698_pgtype90;
	Y5698_gen_type [108] = Y5698_pgtype91;
	Y5698_gen_type [109] = Y5698_pgtype92;
	Y5698_gen_type [110] = Y5698_pgtype93;
	Y5698_gen_type [111] = Y5698_pgtype94;
	Y5698_gen_type [112] = Y5698_pgtype95;
	Y5698_gen_type [113] = Y5698_pgtype96;
	Y5698_gen_type [114] = Y5698_pgtype97;
	Y5698_gen_type [115] = Y5698_pgtype98;
	Y5698_gen_type [116] = Y5698_pgtype99;
	Y5698_gen_type [117] = Y5698_pgtype100;
	Y5698_gen_type [118] = Y5698_pgtype101;
	Y5698_gen_type [119] = Y5698_pgtype102;
	Y5698_gen_type [120] = Y5698_pgtype103;
	Y5698_gen_type [121] = Y5698_pgtype104;
	Y5698_gen_type [122] = Y5698_pgtype105;
	Y5698_gen_type [123] = Y5698_pgtype106;
	Y5698_gen_type [124] = Y5698_pgtype107;
	Y5698_gen_type [125] = Y5698_pgtype108;
	Y5698_gen_type [126] = Y5698_pgtype109;
	Y5698_gen_type [127] = Y5698_pgtype110;
	Y5698_gen_type [128] = Y5698_pgtype111;
	Y5698_gen_type [129] = Y5698_pgtype112;
	Y5698_gen_type [130] = Y5698_pgtype113;
	Y5698_gen_type [131] = Y5698_pgtype114;
	Y5698_gen_type [132] = Y5698_pgtype115;
	Y5698_gen_type [133] = Y5698_pgtype116;
	Y5698_gen_type [134] = Y5698_pgtype117;
	Y5698_gen_type [135] = Y5698_pgtype118;
	Y5698_gen_type [136] = Y5698_pgtype119;
	Y5698_gen_type [137] = Y5698_pgtype120;
	Y5698_gen_type [138] = Y5698_pgtype121;
	Y5698_gen_type [139] = Y5698_pgtype122;
	Y5698_gen_type [140] = Y5698_pgtype123;
	Y5698_gen_type [294] = Y5698_pgtype124;
	Y5698_gen_type [295] = Y5698_pgtype125;
	Y5698[16] = 1048;
	Y5698[42] = 1045;
	Y5698[103] = 1045;
	Y5698[104] = 1048;
	{long i; for (i = 294; i < 296; i++) Y5698[i] = 1229;};
}

char *(*R5699[3])();
void R5699_init () {
	R5699[0] = (char *(*)()) F473_6968;
	R5699[1] = (char *(*)()) F474_6968;
	R5699[2] = (char *(*)()) F475_6968;
}

char *(*R5711[8])();
void R5711_init () {
	R5711[0] = (char *(*)()) F540_7114;
	R5711[1] = (char *(*)()) F541_7114_5711_1;
	R5711[2] = (char *(*)()) F542_7114;
	R5711[3] = (char *(*)()) F543_7114;
	R5711[4] = (char *(*)()) F544_7114;
	R5711[5] = (char *(*)()) F545_7114_5711_1;
	R5711[6] = (char *(*)()) F546_7114;
	R5711[7] = (char *(*)()) F547_7114;
}
static EIF_REFERENCE F541_7114_5711_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F541_7114(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F545_7114_5711_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F545_7114(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5713[755])();
void R5713_init () {
	R5713[0] = (char *(*)()) F797_7393;
	R5713[49] = (char *(*)()) F846_7493;
	R5713[50] = (char *(*)()) F847_7493;
	R5713[51] = (char *(*)()) F848_7493;
	R5713[52] = (char *(*)()) F849_7493;
	R5713[53] = (char *(*)()) F850_7493;
	R5713[54] = (char *(*)()) F851_7493;
	R5713[55] = (char *(*)()) F852_7493;
	R5713[56] = (char *(*)()) F853_7493;
	{long i; for (i = 57; i < 59; i++) R5713[i] = (char *(*)()) F846_7493;}
	R5713[59] = (char *(*)()) F848_7493;
	R5713[60] = (char *(*)()) F852_7493;
	R5713[61] = (char *(*)()) F849_7493;
	R5713[62] = (char *(*)()) F853_7493;
	R5713[153] = (char *(*)()) F950_7904;
	R5713[154] = (char *(*)()) F951_7904;
	R5713[155] = (char *(*)()) F952_7904;
	R5713[156] = (char *(*)()) F953_7904;
	R5713[157] = (char *(*)()) F954_7904;
	R5713[158] = (char *(*)()) F955_7904;
	R5713[159] = (char *(*)()) F956_7904;
	R5713[160] = (char *(*)()) F957_7904;
	R5713[161] = (char *(*)()) F958_7904;
	R5713[162] = (char *(*)()) F959_7904;
	R5713[163] = (char *(*)()) F960_7904;
	R5713[164] = (char *(*)()) F961_7904;
	R5713[165] = (char *(*)()) F950_7904;
	R5713[167] = (char *(*)()) F950_7904;
	R5713[169] = (char *(*)()) F950_7904;
	R5713[170] = (char *(*)()) F953_7904;
	R5713[171] = (char *(*)()) F954_7904;
	R5713[172] = (char *(*)()) F950_7904;
	{long i; for (i = 174; i < 176; i++) R5713[i] = (char *(*)()) F950_7904;}
	{long i; for (i = 176; i < 178; i++) R5713[i] = (char *(*)()) F953_7904;}
	R5713[243] = (char *(*)()) F1040_9281;
	{long i; for (i = 289; i < 294; i++) R5713[i] = (char *(*)()) F1085_9495;}
	R5713[298] = (char *(*)()) F1095_9734;
	R5713[299] = (char *(*)()) F1096_9825;
	R5713[302] = (char *(*)()) F1099_9989;
	{long i; for (i = 642; i < 652; i++) R5713[i] = (char *(*)()) F950_7904;}
	R5713[754] = (char *(*)()) F1099_9989;
}


#ifdef __cplusplus
}
#endif
