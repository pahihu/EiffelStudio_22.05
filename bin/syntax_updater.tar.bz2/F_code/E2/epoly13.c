#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3328[4];
void O3328_init () {
	O3328[0] = + _CHROFF_2_0_;
	O3328[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3328[i] = + _CHROFF_2_0_;}
}

long O3329[4];
void O3329_init () {
	O3329[0] = + _CHROFF_2_1_;
	O3329[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3329[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y3494_pgtype0[] = {0xFF01,165,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype1[] = {0xFF01,165,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype2[] = {0xFF01,1002,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype3[] = {0xFF01,165,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype4[] = {0xFF01,165,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype5[] = {0xFF01,1002,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype6[] = {0xFF01,1002,0xFFFF};
static EIF_TYPE_INDEX Y3494_pgtype7[] = {0xFF01,1002,0xFFFF};
EIF_TYPE_INDEX *Y3494_gen_type [1000];
EIF_TYPE_INDEX Y3494 [1000];
void Y3494_init (void)
{
	egc_routines_types [3494] = Y3494;
	egc_routines_gen_types [3494] = Y3494_gen_type;
	egc_routines_offset [3494] = 281;
	Y3494_gen_type [0] = Y3494_pgtype0;
	Y3494_gen_type [1] = Y3494_pgtype1;
	Y3494_gen_type [2] = Y3494_pgtype2;
	Y3494_gen_type [3] = Y3494_pgtype3;
	Y3494_gen_type [4] = Y3494_pgtype4;
	Y3494_gen_type [5] = Y3494_pgtype5;
	Y3494_gen_type [168] = Y3494_pgtype6;
	Y3494_gen_type [999] = Y3494_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y3494[i] = 165;};
	Y3494[2] = 1002;
	{long i; for (i = 3; i < 5; i++) Y3494[i] = 165;};
	Y3494[5] = 1002;
	Y3494[168] = 1002;
	Y3494[999] = 1002;
}

long O4801[890];
void O4801_init () {
	O4801[0] = 0;
	{long i; for (i = 1; i < 3; i++) O4801[i] =  + _REFACS_1_;}
	O4801[580] =  + _REFACS_1_;
	O4801[889] = 0;
}

long O4923[771];
void O4923_init () {
	{long i; for (i = 0; i < 11; i++) O4923[i] = 0;}
	{long i; for (i = 761; i < 771; i++) O4923[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y4971_pgtype0[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype1[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype2[] = {0xFF01,1152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype3[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype4[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype5[] = {0xFF01,1155,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype6[] = {0xFF01,1156,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype7[] = {0xFF01,1157,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype8[] = {0xFF01,1158,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype9[] = {0xFF01,1159,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype10[] = {0xFF01,1160,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype11[] = {0xFF01,1161,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype12[] = {0xFF01,1152,1247,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype13[] = {0xFF01,1152,1247,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype14[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype15[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype16[] = {0xFF01,1152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype17[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype18[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype19[] = {0xFF01,1155,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype20[] = {0xFF01,1156,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype21[] = {0xFF01,1157,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype22[] = {0xFF01,1158,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype23[] = {0xFF01,1159,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype24[] = {0xFF01,1160,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype25[] = {0xFF01,1161,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype26[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype27[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype28[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype29[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype30[] = {0xFF01,1160,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype31[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype32[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype33[] = {0xFF01,1152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype34[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype35[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype36[] = {0xFF01,1155,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype37[] = {0xFF01,1156,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype38[] = {0xFF01,1157,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype39[] = {0xFF01,1158,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype40[] = {0xFF01,1159,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype41[] = {0xFF01,1160,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype42[] = {0xFF01,1161,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype43[] = {0xFF01,1150,0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype44[] = {0xFF01,1150,0xFF01,37,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype45[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype46[] = {0xFF01,1150,0xFF01,445,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype47[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype48[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype49[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype50[] = {0xFF01,1150,0xFF01,968,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype51[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype52[] = {0xFF01,1150,0xFF01,1085,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype53[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype54[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype55[] = {0xFF01,1153,1229,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype56[] = {0xFF01,1158,1045,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype57[] = {0xFF01,1160,1048,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype58[] = {0xFF01,1160,1048,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype59[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype60[] = {0xFF01,1150,0xFF01,1376,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype61[] = {0xFF01,1150,0xFF01,1385,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype62[] = {0xFF01,1150,0xFF01,1386,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype63[] = {0xFF01,1150,0xFF01,1369,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype64[] = {0xFF01,1150,0xFF01,1378,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype65[] = {0xFF01,1150,0xFF01,1374,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype66[] = {0xFF01,1150,0xFF01,1375,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype67[] = {0xFF01,1150,0xFF01,1512,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype68[] = {0xFF01,1150,0xFF01,1429,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype69[] = {0xFF01,1160,1048,0xFFFF};
static EIF_TYPE_INDEX Y4971_pgtype70[] = {0xFF01,1160,1048,0xFFFF};
EIF_TYPE_INDEX *Y4971_gen_type [1140];
EIF_TYPE_INDEX Y4971 [1140];
void Y4971_init (void)
{
	egc_routines_types [4971] = Y4971;
	egc_routines_gen_types [4971] = Y4971_gen_type;
	egc_routines_offset [4971] = 412;
	Y4971_gen_type [0] = Y4971_pgtype0;
	Y4971_gen_type [1] = Y4971_pgtype1;
	Y4971_gen_type [2] = Y4971_pgtype2;
	Y4971_gen_type [3] = Y4971_pgtype3;
	Y4971_gen_type [4] = Y4971_pgtype4;
	Y4971_gen_type [5] = Y4971_pgtype5;
	Y4971_gen_type [6] = Y4971_pgtype6;
	Y4971_gen_type [7] = Y4971_pgtype7;
	Y4971_gen_type [8] = Y4971_pgtype8;
	Y4971_gen_type [9] = Y4971_pgtype9;
	Y4971_gen_type [10] = Y4971_pgtype10;
	Y4971_gen_type [11] = Y4971_pgtype11;
	Y4971_gen_type [21] = Y4971_pgtype12;
	Y4971_gen_type [22] = Y4971_pgtype13;
	Y4971_gen_type [460] = Y4971_pgtype14;
	Y4971_gen_type [461] = Y4971_pgtype15;
	Y4971_gen_type [462] = Y4971_pgtype16;
	Y4971_gen_type [463] = Y4971_pgtype17;
	Y4971_gen_type [464] = Y4971_pgtype18;
	Y4971_gen_type [465] = Y4971_pgtype19;
	Y4971_gen_type [466] = Y4971_pgtype20;
	Y4971_gen_type [467] = Y4971_pgtype21;
	Y4971_gen_type [468] = Y4971_pgtype22;
	Y4971_gen_type [469] = Y4971_pgtype23;
	Y4971_gen_type [470] = Y4971_pgtype24;
	Y4971_gen_type [471] = Y4971_pgtype25;
	Y4971_gen_type [472] = Y4971_pgtype26;
	Y4971_gen_type [473] = Y4971_pgtype27;
	Y4971_gen_type [474] = Y4971_pgtype28;
	Y4971_gen_type [475] = Y4971_pgtype29;
	Y4971_gen_type [476] = Y4971_pgtype30;
	Y4971_gen_type [537] = Y4971_pgtype31;
	Y4971_gen_type [538] = Y4971_pgtype32;
	Y4971_gen_type [539] = Y4971_pgtype33;
	Y4971_gen_type [540] = Y4971_pgtype34;
	Y4971_gen_type [541] = Y4971_pgtype35;
	Y4971_gen_type [542] = Y4971_pgtype36;
	Y4971_gen_type [543] = Y4971_pgtype37;
	Y4971_gen_type [544] = Y4971_pgtype38;
	Y4971_gen_type [545] = Y4971_pgtype39;
	Y4971_gen_type [546] = Y4971_pgtype40;
	Y4971_gen_type [547] = Y4971_pgtype41;
	Y4971_gen_type [548] = Y4971_pgtype42;
	Y4971_gen_type [549] = Y4971_pgtype43;
	Y4971_gen_type [550] = Y4971_pgtype44;
	Y4971_gen_type [551] = Y4971_pgtype45;
	Y4971_gen_type [552] = Y4971_pgtype46;
	Y4971_gen_type [553] = Y4971_pgtype47;
	Y4971_gen_type [554] = Y4971_pgtype48;
	Y4971_gen_type [555] = Y4971_pgtype49;
	Y4971_gen_type [556] = Y4971_pgtype50;
	Y4971_gen_type [557] = Y4971_pgtype51;
	Y4971_gen_type [558] = Y4971_pgtype52;
	Y4971_gen_type [559] = Y4971_pgtype53;
	Y4971_gen_type [560] = Y4971_pgtype54;
	Y4971_gen_type [561] = Y4971_pgtype55;
	Y4971_gen_type [683] = Y4971_pgtype56;
	Y4971_gen_type [686] = Y4971_pgtype57;
	Y4971_gen_type [687] = Y4971_pgtype58;
	Y4971_gen_type [1026] = Y4971_pgtype59;
	Y4971_gen_type [1027] = Y4971_pgtype60;
	Y4971_gen_type [1028] = Y4971_pgtype61;
	Y4971_gen_type [1029] = Y4971_pgtype62;
	Y4971_gen_type [1030] = Y4971_pgtype63;
	Y4971_gen_type [1031] = Y4971_pgtype64;
	Y4971_gen_type [1032] = Y4971_pgtype65;
	Y4971_gen_type [1033] = Y4971_pgtype66;
	Y4971_gen_type [1034] = Y4971_pgtype67;
	Y4971_gen_type [1035] = Y4971_pgtype68;
	Y4971_gen_type [1138] = Y4971_pgtype69;
	Y4971_gen_type [1139] = Y4971_pgtype70;
	Y4971[0] = 1150;
	Y4971[1] = 1151;
	Y4971[2] = 1152;
	Y4971[3] = 1153;
	Y4971[4] = 1154;
	Y4971[5] = 1155;
	Y4971[6] = 1156;
	Y4971[7] = 1157;
	Y4971[8] = 1158;
	Y4971[9] = 1159;
	Y4971[10] = 1160;
	Y4971[11] = 1161;
	{long i; for (i = 21; i < 23; i++) Y4971[i] = 1152;};
	Y4971[460] = 1150;
	Y4971[461] = 1151;
	Y4971[462] = 1152;
	Y4971[463] = 1153;
	Y4971[464] = 1154;
	Y4971[465] = 1155;
	Y4971[466] = 1156;
	Y4971[467] = 1157;
	Y4971[468] = 1158;
	Y4971[469] = 1159;
	Y4971[470] = 1160;
	Y4971[471] = 1161;
	Y4971[472] = 1150;
	Y4971[473] = 1151;
	Y4971[474] = 1153;
	Y4971[475] = 1154;
	Y4971[476] = 1160;
	Y4971[537] = 1150;
	Y4971[538] = 1151;
	Y4971[539] = 1152;
	Y4971[540] = 1153;
	Y4971[541] = 1154;
	Y4971[542] = 1155;
	Y4971[543] = 1156;
	Y4971[544] = 1157;
	Y4971[545] = 1158;
	Y4971[546] = 1159;
	Y4971[547] = 1160;
	Y4971[548] = 1161;
	{long i; for (i = 549; i < 554; i++) Y4971[i] = 1150;};
	Y4971[554] = 1153;
	Y4971[555] = 1154;
	{long i; for (i = 556; i < 560; i++) Y4971[i] = 1150;};
	{long i; for (i = 560; i < 562; i++) Y4971[i] = 1153;};
	Y4971[683] = 1158;
	{long i; for (i = 686; i < 688; i++) Y4971[i] = 1160;};
	{long i; for (i = 1026; i < 1036; i++) Y4971[i] = 1150;};
	{long i; for (i = 1138; i < 1140; i++) Y4971[i] = 1160;};
}

long O5795[24];
void O5795_init () {
	{long i; for (i = 0; i < 20; i++) O5795[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 20; i < 24; i++) O5795[i] = + _LNGOFF_2_1_0_0_;}
}

long O5799[24];
void O5799_init () {
	{long i; for (i = 0; i < 20; i++) O5799[i] = + _CHROFF_1_0_;}
	{long i; for (i = 20; i < 24; i++) O5799[i] = + _CHROFF_2_0_;}
}

long O5800[24];
void O5800_init () {
	{long i; for (i = 0; i < 20; i++) O5800[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 20; i < 24; i++) O5800[i] = + _LNGOFF_2_1_0_1_;}
}

long O5801[24];
void O5801_init () {
	{long i; for (i = 0; i < 20; i++) O5801[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 20; i < 24; i++) O5801[i] = + _LNGOFF_2_1_0_2_;}
}

long O5802[24];
void O5802_init () {
	{long i; for (i = 0; i < 20; i++) O5802[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 20; i < 24; i++) O5802[i] = + _LNGOFF_2_1_0_3_;}
}

long O5803[24];
void O5803_init () {
	{long i; for (i = 0; i < 20; i++) O5803[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 20; i < 24; i++) O5803[i] = + _LNGOFF_2_1_0_4_;}
}

long O5806[50];
void O5806_init () {
	{long i; for (i = 0; i < 12; i++) O5806[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5806[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5806[i] = + _LNGOFF_1_0_0_0_;}
}

long O5808[50];
void O5808_init () {
	{long i; for (i = 0; i < 12; i++) O5808[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5808[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5808[i] = + _LNGOFF_1_0_0_1_;}
}

static EIF_TYPE_INDEX Y5824_pgtype0[] = {0xFF01,488,0xFF01,1103,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype1[] = {0xFF01,949,0xFF01,1103,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype2[] = {0xFF01,949,0xFF01,1103,0xFFFF};
EIF_TYPE_INDEX *Y5824_gen_type [504];
EIF_TYPE_INDEX Y5824 [504];
void Y5824_init (void)
{
	egc_routines_types [5824] = Y5824;
	egc_routines_gen_types [5824] = Y5824_gen_type;
	egc_routines_offset [5824] = 601;
	Y5824_gen_type [0] = Y5824_pgtype0;
	Y5824_gen_type [501] = Y5824_pgtype1;
	Y5824_gen_type [503] = Y5824_pgtype2;
	Y5824[0] = 488;
	Y5824[501] = 949;
	Y5824[503] = 949;
}

long O5838[950];
void O5838_init () {
	{long i; for (i = 0; i < 194; i++) O5838[i] = + _CHROFF_0_0_;}
	O5838[194] = + _CHROFF_1_0_;
	{long i; for (i = 195; i < 222; i++) O5838[i] = + _CHROFF_0_0_;}
	O5838[243] = + _CHROFF_7_0_;
	O5838[244] = + _CHROFF_6_0_;
	{long i; for (i = 245; i < 248; i++) O5838[i] = + _CHROFF_5_0_;}
	O5838[248] = + _CHROFF_4_0_;
	{long i; for (i = 249; i < 251; i++) O5838[i] = + _CHROFF_5_0_;}
	O5838[251] = + _CHROFF_9_0_;
	O5838[252] = + _CHROFF_7_0_;
	{long i; for (i = 253; i < 257; i++) O5838[i] = + _CHROFF_5_0_;}
	{long i; for (i = 257; i < 270; i++) O5838[i] = + _CHROFF_0_0_;}
	{long i; for (i = 270; i < 287; i++) O5838[i] = + _CHROFF_1_0_;}
	{long i; for (i = 287; i < 337; i++) O5838[i] = + _CHROFF_0_0_;}
	{long i; for (i = 337; i < 345; i++) O5838[i] = + _CHROFF_2_0_;}
	{long i; for (i = 345; i < 347; i++) O5838[i] = + _CHROFF_4_0_;}
	{long i; for (i = 347; i < 366; i++) O5838[i] = + _CHROFF_1_0_;}
	O5838[366] = + _CHROFF_5_0_;
	O5838[367] = + _CHROFF_1_0_;
	O5838[368] = + _CHROFF_9_0_;
	{long i; for (i = 369; i < 371; i++) O5838[i] = + _CHROFF_1_0_;}
	O5838[371] = + _CHROFF_3_0_;
	O5838[403] = + _CHROFF_3_2_;
	O5838[404] = + _CHROFF_4_2_;
	O5838[405] = + _CHROFF_5_2_;
	O5838[493] = + _CHROFF_1_0_;
	{long i; for (i = 496; i < 498; i++) O5838[i] = + _CHROFF_1_0_;}
	O5838[667] = + _CHROFF_5_2_;
	{long i; for (i = 701; i < 704; i++) O5838[i] = + _CHROFF_5_2_;}
	O5838[705] = + _CHROFF_7_2_;
	{long i; for (i = 706; i < 710; i++) O5838[i] = + _CHROFF_6_2_;}
	{long i; for (i = 836; i < 846; i++) O5838[i] = + _CHROFF_2_0_;}
	{long i; for (i = 948; i < 950; i++) O5838[i] = + _CHROFF_1_0_;}
}

EIF_TYPE_INDEX *Y5962_gen_type [1];
EIF_TYPE_INDEX Y5962 [1];
void Y5962_init (void)
{
	egc_routines_types [5962] = Y5962;
	egc_routines_gen_types [5962] = Y5962_gen_type;
	egc_routines_offset [5962] = 796;
	Y5962[0] = 1229;
}

long O5988[14];
void O5988_init () {
	{long i; for (i = 0; i < 2; i++) O5988[i] = 0;}
	O5988[2] = + _CHROFF_5_1_;
	O5988[3] = + _LNGOFF_5_3_0_0_;
	O5988[4] = + _PTROFF_5_3_0_7_0_0_;
	O5988[5] = + _LNGOFF_4_3_0_0_;
	O5988[6] = + _CHROFF_5_3_;
	O5988[7] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 8; i < 10; i++) O5988[i] = 0;}
	O5988[10] = + _CHROFF_5_1_;
	O5988[11] = + _CHROFF_5_4_;
	{long i; for (i = 12; i < 14; i++) O5988[i] = + _LNGOFF_5_4_0_0_;}
}

long O5997[14];
void O5997_init () {
	O5997[0] = + _LNGOFF_7_3_0_0_;
	O5997[1] = + _LNGOFF_6_3_0_0_;
	O5997[2] = + _LNGOFF_5_5_0_0_;
	O5997[3] = + _LNGOFF_5_3_0_1_;
	O5997[4] = + _LNGOFF_5_3_0_0_;
	O5997[5] = + _LNGOFF_4_3_0_1_;
	O5997[6] = + _LNGOFF_5_5_0_0_;
	O5997[7] = + _LNGOFF_5_3_0_2_;
	O5997[8] = + _LNGOFF_9_3_0_0_;
	O5997[9] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 10; i < 12; i++) O5997[i] = + _LNGOFF_5_6_0_0_;}
	O5997[12] = + _LNGOFF_5_4_0_1_;
	O5997[13] = + _LNGOFF_5_4_0_2_;
}

long O6024[14];
void O6024_init () {
	{long i; for (i = 0; i < 2; i++) O6024[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 8; i++) O6024[i] = 0;}
	{long i; for (i = 8; i < 10; i++) O6024[i] =  + _REFACS_1_;}
	{long i; for (i = 10; i < 14; i++) O6024[i] = 0;}
}

static EIF_TYPE_INDEX Y6024_pgtype0[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype1[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype2[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype3[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype4[] = {0xFF01,1156,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype5[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype6[] = {0xFF01,1152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype7[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype8[] = {0xFF01,1150,0,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype9[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype10[] = {0xFF01,1154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype11[] = {0xFF01,1152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype12[] = {0xFF01,1153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6024_pgtype13[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6024_gen_type [14];
EIF_TYPE_INDEX Y6024 [14];
void Y6024_init (void)
{
	egc_routines_types [6024] = Y6024;
	egc_routines_gen_types [6024] = Y6024_gen_type;
	egc_routines_offset [6024] = 845;
	Y6024_gen_type [0] = Y6024_pgtype0;
	Y6024_gen_type [1] = Y6024_pgtype1;
	Y6024_gen_type [2] = Y6024_pgtype2;
	Y6024_gen_type [3] = Y6024_pgtype3;
	Y6024_gen_type [4] = Y6024_pgtype4;
	Y6024_gen_type [5] = Y6024_pgtype5;
	Y6024_gen_type [6] = Y6024_pgtype6;
	Y6024_gen_type [7] = Y6024_pgtype7;
	Y6024_gen_type [8] = Y6024_pgtype8;
	Y6024_gen_type [9] = Y6024_pgtype9;
	Y6024_gen_type [10] = Y6024_pgtype10;
	Y6024_gen_type [11] = Y6024_pgtype11;
	Y6024_gen_type [12] = Y6024_pgtype12;
	Y6024_gen_type [13] = Y6024_pgtype13;
	{long i; for (i = 0; i < 2; i++) Y6024[i] = 1150;};
	Y6024[2] = 1154;
	Y6024[3] = 1153;
	Y6024[4] = 1156;
	Y6024[5] = 1153;
	Y6024[6] = 1152;
	Y6024[7] = 1151;
	{long i; for (i = 8; i < 10; i++) Y6024[i] = 1150;};
	Y6024[10] = 1154;
	Y6024[11] = 1152;
	Y6024[12] = 1153;
	Y6024[13] = 1151;
}

long O6025[14];
void O6025_init () {
	{long i; for (i = 0; i < 2; i++) O6025[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 8; i++) O6025[i] =  + _REFACS_1_;}
	{long i; for (i = 8; i < 10; i++) O6025[i] =  + _REFACS_2_;}
	{long i; for (i = 10; i < 14; i++) O6025[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y6025_pgtype0[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype1[] = {0xFF01,1153,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype2[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype3[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype4[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype5[] = {0xFF01,1153,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype6[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype7[] = {0xFF01,1150,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype8[] = {0xFF01,1150,0xFF01,1098,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype9[] = {0xFF01,1150,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype10[] = {0xFF01,1150,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype11[] = {0xFF01,1150,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype12[] = {0xFF01,1150,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y6025_pgtype13[] = {0xFF01,1150,0xFF01,1090,0xFFFF};
EIF_TYPE_INDEX *Y6025_gen_type [14];
EIF_TYPE_INDEX Y6025 [14];
void Y6025_init (void)
{
	egc_routines_types [6025] = Y6025;
	egc_routines_gen_types [6025] = Y6025_gen_type;
	egc_routines_offset [6025] = 845;
	Y6025_gen_type [0] = Y6025_pgtype0;
	Y6025_gen_type [1] = Y6025_pgtype1;
	Y6025_gen_type [2] = Y6025_pgtype2;
	Y6025_gen_type [3] = Y6025_pgtype3;
	Y6025_gen_type [4] = Y6025_pgtype4;
	Y6025_gen_type [5] = Y6025_pgtype5;
	Y6025_gen_type [6] = Y6025_pgtype6;
	Y6025_gen_type [7] = Y6025_pgtype7;
	Y6025_gen_type [8] = Y6025_pgtype8;
	Y6025_gen_type [9] = Y6025_pgtype9;
	Y6025_gen_type [10] = Y6025_pgtype10;
	Y6025_gen_type [11] = Y6025_pgtype11;
	Y6025_gen_type [12] = Y6025_pgtype12;
	Y6025_gen_type [13] = Y6025_pgtype13;
	Y6025[0] = 1150;
	Y6025[1] = 1153;
	{long i; for (i = 2; i < 5; i++) Y6025[i] = 1150;};
	Y6025[5] = 1153;
	{long i; for (i = 6; i < 14; i++) Y6025[i] = 1150;};
}

long O6026[14];
void O6026_init () {
	{long i; for (i = 0; i < 2; i++) O6026[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 8; i++) O6026[i] =  + _REFACS_2_;}
	{long i; for (i = 8; i < 10; i++) O6026[i] =  + _REFACS_3_;}
	{long i; for (i = 10; i < 14; i++) O6026[i] =  + _REFACS_2_;}
}

long O6027[14];
void O6027_init () {
	{long i; for (i = 0; i < 2; i++) O6027[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 8; i++) O6027[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O6027[i] =  + _REFACS_4_;}
	{long i; for (i = 10; i < 14; i++) O6027[i] =  + _REFACS_3_;}
}

long O6028[14];
void O6028_init () {
	O6028[0] = + _LNGOFF_7_3_0_1_;
	O6028[1] = + _LNGOFF_6_3_0_1_;
	O6028[2] = + _LNGOFF_5_5_0_1_;
	O6028[3] = + _LNGOFF_5_3_0_2_;
	O6028[4] = + _LNGOFF_5_3_0_1_;
	O6028[5] = + _LNGOFF_4_3_0_2_;
	O6028[6] = + _LNGOFF_5_5_0_1_;
	O6028[7] = + _LNGOFF_5_3_0_3_;
	O6028[8] = + _LNGOFF_9_3_0_1_;
	O6028[9] = + _LNGOFF_7_4_0_1_;
	{long i; for (i = 10; i < 12; i++) O6028[i] = + _LNGOFF_5_6_0_1_;}
	O6028[12] = + _LNGOFF_5_4_0_2_;
	O6028[13] = + _LNGOFF_5_4_0_3_;
}

long O6029[14];
void O6029_init () {
	O6029[0] = + _CHROFF_7_2_;
	O6029[1] = + _CHROFF_6_2_;
	O6029[2] = + _CHROFF_5_3_;
	{long i; for (i = 3; i < 5; i++) O6029[i] = + _CHROFF_5_2_;}
	O6029[5] = + _CHROFF_4_2_;
	{long i; for (i = 6; i < 8; i++) O6029[i] = + _CHROFF_5_2_;}
	O6029[8] = + _CHROFF_9_2_;
	O6029[9] = + _CHROFF_7_2_;
	O6029[10] = + _CHROFF_5_3_;
	{long i; for (i = 11; i < 14; i++) O6029[i] = + _CHROFF_5_2_;}
}

long O6030[14];
void O6030_init () {
	O6030[0] = + _LNGOFF_7_3_0_2_;
	O6030[1] = + _LNGOFF_6_3_0_2_;
	O6030[2] = + _LNGOFF_5_5_0_2_;
	O6030[3] = + _LNGOFF_5_3_0_3_;
	O6030[4] = + _LNGOFF_5_3_0_2_;
	O6030[5] = + _LNGOFF_4_3_0_3_;
	O6030[6] = + _LNGOFF_5_5_0_2_;
	O6030[7] = + _LNGOFF_5_3_0_4_;
	O6030[8] = + _LNGOFF_9_3_0_2_;
	O6030[9] = + _LNGOFF_7_4_0_2_;
	{long i; for (i = 10; i < 12; i++) O6030[i] = + _LNGOFF_5_6_0_2_;}
	O6030[12] = + _LNGOFF_5_4_0_3_;
	O6030[13] = + _LNGOFF_5_4_0_4_;
}

long O6033[14];
void O6033_init () {
	O6033[0] = + _LNGOFF_7_3_0_3_;
	O6033[1] = + _LNGOFF_6_3_0_3_;
	O6033[2] = + _LNGOFF_5_5_0_3_;
	O6033[3] = + _LNGOFF_5_3_0_4_;
	O6033[4] = + _LNGOFF_5_3_0_3_;
	O6033[5] = + _LNGOFF_4_3_0_4_;
	O6033[6] = + _LNGOFF_5_5_0_3_;
	O6033[7] = + _LNGOFF_5_3_0_5_;
	O6033[8] = + _LNGOFF_9_3_0_3_;
	O6033[9] = + _LNGOFF_7_4_0_3_;
	{long i; for (i = 10; i < 12; i++) O6033[i] = + _LNGOFF_5_6_0_3_;}
	O6033[12] = + _LNGOFF_5_4_0_4_;
	O6033[13] = + _LNGOFF_5_4_0_5_;
}

long O6034[14];
void O6034_init () {
	O6034[0] = + _LNGOFF_7_3_0_4_;
	O6034[1] = + _LNGOFF_6_3_0_4_;
	O6034[2] = + _LNGOFF_5_5_0_4_;
	O6034[3] = + _LNGOFF_5_3_0_5_;
	O6034[4] = + _LNGOFF_5_3_0_4_;
	O6034[5] = + _LNGOFF_4_3_0_5_;
	O6034[6] = + _LNGOFF_5_5_0_4_;
	O6034[7] = + _LNGOFF_5_3_0_6_;
	O6034[8] = + _LNGOFF_9_3_0_4_;
	O6034[9] = + _LNGOFF_7_4_0_4_;
	{long i; for (i = 10; i < 12; i++) O6034[i] = + _LNGOFF_5_6_0_4_;}
	O6034[12] = + _LNGOFF_5_4_0_5_;
	O6034[13] = + _LNGOFF_5_4_0_6_;
}

long O6038[14];
void O6038_init () {
	O6038[0] = + _LNGOFF_7_3_0_5_;
	O6038[1] = + _LNGOFF_6_3_0_5_;
	O6038[2] = + _LNGOFF_5_5_0_5_;
	O6038[3] = + _LNGOFF_5_3_0_6_;
	O6038[4] = + _LNGOFF_5_3_0_5_;
	O6038[5] = + _LNGOFF_4_3_0_6_;
	O6038[6] = + _LNGOFF_5_5_0_5_;
	O6038[7] = + _LNGOFF_5_3_0_7_;
	O6038[8] = + _LNGOFF_9_3_0_5_;
	O6038[9] = + _LNGOFF_7_4_0_5_;
	{long i; for (i = 10; i < 12; i++) O6038[i] = + _LNGOFF_5_6_0_5_;}
	O6038[12] = + _LNGOFF_5_4_0_6_;
	O6038[13] = + _LNGOFF_5_4_0_7_;
}

long O6039[14];
void O6039_init () {
	{long i; for (i = 0; i < 2; i++) O6039[i] =  + _REFACS_5_;}
	O6039[2] = + _CHROFF_5_4_;
	O6039[3] = + _LNGOFF_5_3_0_7_;
	O6039[4] = + _PTROFF_5_3_0_7_0_1_;
	O6039[5] = + _LNGOFF_4_3_0_7_;
	O6039[6] = + _CHROFF_5_4_;
	O6039[7] = + _LNGOFF_5_3_0_1_;
	{long i; for (i = 8; i < 10; i++) O6039[i] =  + _REFACS_5_;}
	O6039[10] = + _CHROFF_5_4_;
	O6039[11] = + _CHROFF_5_5_;
	O6039[12] = + _LNGOFF_5_4_0_7_;
	O6039[13] = + _LNGOFF_5_4_0_1_;
}

long O6040[14];
void O6040_init () {
	O6040[0] =  + _REFACS_6_;
	O6040[1] = + _LNGOFF_6_3_0_6_;
	{long i; for (i = 2; i < 5; i++) O6040[i] =  + _REFACS_4_;}
	O6040[5] = + _LNGOFF_4_3_0_8_;
	{long i; for (i = 6; i < 8; i++) O6040[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O6040[i] =  + _REFACS_6_;}
	{long i; for (i = 10; i < 14; i++) O6040[i] =  + _REFACS_4_;}
}

long O6074[14];
void O6074_init () {
	O6074[0] = + _LNGOFF_7_3_0_6_;
	O6074[1] = + _LNGOFF_6_3_0_7_;
	O6074[2] = + _LNGOFF_5_5_0_6_;
	O6074[3] = + _LNGOFF_5_3_0_8_;
	O6074[4] = + _LNGOFF_5_3_0_6_;
	O6074[5] = + _LNGOFF_4_3_0_9_;
	O6074[6] = + _LNGOFF_5_5_0_6_;
	O6074[7] = + _LNGOFF_5_3_0_8_;
	O6074[8] = + _LNGOFF_9_3_0_6_;
	O6074[9] = + _LNGOFF_7_4_0_6_;
	{long i; for (i = 10; i < 12; i++) O6074[i] = + _LNGOFF_5_6_0_6_;}
	{long i; for (i = 12; i < 14; i++) O6074[i] = + _LNGOFF_5_4_0_8_;}
}

long O6087[5];
void O6087_init () {
	O6087[0] = + _CHROFF_7_3_;
	O6087[1] = + _CHROFF_5_5_;
	{long i; for (i = 2; i < 5; i++) O6087[i] = + _CHROFF_5_3_;}
}

long O6181[10];
void O6181_init () {
	{long i; for (i = 0; i < 8; i++) O6181[i] = + _CHROFF_2_1_;}
	{long i; for (i = 8; i < 10; i++) O6181[i] = + _CHROFF_4_1_;}
}

long O6182[10];
void O6182_init () {
	{long i; for (i = 0; i < 8; i++) O6182[i] = + _CHROFF_2_2_;}
	{long i; for (i = 8; i < 10; i++) O6182[i] = + _CHROFF_4_2_;}
}

long O6183[10];
void O6183_init () {
	{long i; for (i = 0; i < 8; i++) O6183[i] = + _LNGOFF_2_3_0_0_;}
	{long i; for (i = 8; i < 10; i++) O6183[i] = + _LNGOFF_4_3_0_0_;}
}

long O6215[499];
void O6215_init () {
	{long i; for (i = 0; i < 19; i++) O6215[i] = + _LNGOFF_1_1_0_0_;}
	O6215[19] = + _LNGOFF_5_1_0_0_;
	O6215[20] = + _LNGOFF_1_2_0_0_;
	O6215[21] = + _LNGOFF_9_2_0_0_;
	{long i; for (i = 22; i < 24; i++) O6215[i] = + _LNGOFF_1_1_0_0_;}
	O6215[24] = + _LNGOFF_3_1_0_0_;
	{long i; for (i = 489; i < 499; i++) O6215[i] = + _LNGOFF_2_1_0_0_;}
}

long O6280[477];
void O6280_init () {
	{long i; for (i = 0; i < 2; i++) O6280[i] = + _LNGOFF_1_1_0_1_;}
	O6280[2] = + _LNGOFF_3_1_0_1_;
	{long i; for (i = 467; i < 477; i++) O6280[i] = + _LNGOFF_2_1_0_1_;}
}

long O6430[2];
void O6430_init () {
	O6430[0] = + _CHROFF_12_0_;
	O6430[1] = + _CHROFF_18_0_;
}

long O6431[2];
void O6431_init () {
	O6431[0] = + _CHROFF_12_1_;
	O6431[1] = + _CHROFF_18_1_;
}

long O6432[2];
void O6432_init () {
	O6432[0] = + _CHROFF_12_2_;
	O6432[1] = + _CHROFF_18_2_;
}

long O6433[2];
void O6433_init () {
	O6433[0] = + _CHROFF_12_3_;
	O6433[1] = + _CHROFF_18_3_;
}

long O6434[2];
void O6434_init () {
	O6434[0] = + _CHROFF_12_4_;
	O6434[1] = + _CHROFF_18_4_;
}

long O6435[2];
void O6435_init () {
	O6435[0] = + _CHROFF_12_5_;
	O6435[1] = + _CHROFF_18_5_;
}

long O6436[2];
void O6436_init () {
	O6436[0] = + _CHROFF_12_6_;
	O6436[1] = + _CHROFF_18_6_;
}

long O6437[2];
void O6437_init () {
	O6437[0] = + _CHROFF_12_7_;
	O6437[1] = + _CHROFF_18_7_;
}

long O6438[2];
void O6438_init () {
	O6438[0] = + _CHROFF_12_8_;
	O6438[1] = + _CHROFF_18_8_;
}

long O6453[2];
void O6453_init () {
	O6453[0] = + _CHROFF_12_9_;
	O6453[1] = + _CHROFF_18_9_;
}

long O6454[2];
void O6454_init () {
	O6454[0] = + _CHROFF_12_10_;
	O6454[1] = + _CHROFF_18_10_;
}

long O6455[2];
void O6455_init () {
	O6455[0] = + _CHROFF_12_11_;
	O6455[1] = + _CHROFF_18_11_;
}

long O6456[2];
void O6456_init () {
	O6456[0] = + _CHROFF_12_12_;
	O6456[1] = + _CHROFF_18_12_;
}

long O6457[2];
void O6457_init () {
	O6457[0] = + _CHROFF_12_13_;
	O6457[1] = + _CHROFF_18_13_;
}

long O6458[2];
void O6458_init () {
	O6458[0] = + _CHROFF_12_14_;
	O6458[1] = + _CHROFF_18_14_;
}

long O6459[2];
void O6459_init () {
	O6459[0] = + _CHROFF_12_15_;
	O6459[1] = + _CHROFF_18_15_;
}

long O6460[2];
void O6460_init () {
	O6460[0] = + _CHROFF_12_16_;
	O6460[1] = + _CHROFF_18_16_;
}

long O6461[2];
void O6461_init () {
	O6461[0] = + _CHROFF_12_17_;
	O6461[1] = + _CHROFF_18_17_;
}

long O6594[8];
void O6594_init () {
	{long i; for (i = 0; i < 2; i++) O6594[i] = + _LNGOFF_2_0_0_0_;}
	O6594[2] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 3; i < 5; i++) O6594[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6594[i] = + _LNGOFF_3_0_0_0_;}
	O6594[7] = + _LNGOFF_2_0_0_0_;
}

long O6595[8];
void O6595_init () {
	{long i; for (i = 0; i < 2; i++) O6595[i] = + _LNGOFF_2_0_0_1_;}
	O6595[2] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 3; i < 5; i++) O6595[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6595[i] = + _LNGOFF_3_0_0_1_;}
	O6595[7] = + _LNGOFF_2_0_0_1_;
}

long O6596[8];
void O6596_init () {
	{long i; for (i = 0; i < 2; i++) O6596[i] = + _LNGOFF_2_0_0_2_;}
	O6596[2] = + _LNGOFF_3_0_0_2_;
	{long i; for (i = 3; i < 5; i++) O6596[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 5; i < 7; i++) O6596[i] = + _LNGOFF_3_0_0_2_;}
	O6596[7] = + _LNGOFF_2_0_0_2_;
}

long O6670[308];
void O6670_init () {
	O6670[0] = + _CHROFF_1_0_;
	O6670[1] = + _CHROFF_3_0_;
	O6670[2] = + _CHROFF_4_0_;
	O6670[3] = + _CHROFF_5_0_;
	O6670[265] = + _CHROFF_5_0_;
	{long i; for (i = 299; i < 302; i++) O6670[i] = + _CHROFF_5_0_;}
	O6670[303] = + _CHROFF_7_1_;
	{long i; for (i = 304; i < 308; i++) O6670[i] = + _CHROFF_6_1_;}
}

long O6672[308];
void O6672_init () {
	O6672[0] = + _LNGOFF_1_3_2_1_;
	O6672[1] = + _LNGOFF_3_6_2_1_;
	O6672[2] = + _LNGOFF_4_6_2_1_;
	O6672[3] = + _LNGOFF_5_7_2_1_;
	O6672[265] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 299; i < 302; i++) O6672[i] = + _LNGOFF_5_6_2_1_;}
	O6672[303] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 304; i < 308; i++) O6672[i] = + _LNGOFF_6_7_2_1_;}
}

long O6681[308];
void O6681_init () {
	O6681[0] = + _CHROFF_1_1_;
	O6681[1] = + _CHROFF_3_4_;
	O6681[2] = + _CHROFF_4_4_;
	O6681[3] = + _CHROFF_5_5_;
	O6681[265] = + _CHROFF_5_5_;
	{long i; for (i = 299; i < 302; i++) O6681[i] = + _CHROFF_5_4_;}
	O6681[303] = + _CHROFF_7_6_;
	{long i; for (i = 304; i < 308; i++) O6681[i] = + _CHROFF_6_5_;}
}

long O6769[307];
void O6769_init () {
	O6769[0] = + _PTROFF_3_6_2_4_1_0_;
	O6769[1] = + _PTROFF_4_6_2_4_1_0_;
	O6769[2] = + _PTROFF_5_7_2_4_1_0_;
	O6769[264] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 298; i < 301; i++) O6769[i] = + _PTROFF_5_6_2_4_1_0_;}
	O6769[302] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 303; i < 307; i++) O6769[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O6908[307];
void O6908_init () {
	O6908[0] = + _LNGOFF_3_6_2_3_;
	O6908[1] = + _LNGOFF_4_6_2_3_;
	O6908[2] = + _LNGOFF_5_7_2_3_;
	O6908[264] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 298; i < 301; i++) O6908[i] = + _LNGOFF_5_6_2_3_;}
	O6908[302] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 303; i < 307; i++) O6908[i] = + _LNGOFF_6_7_2_3_;}
}

long O6917[307];
void O6917_init () {
	O6917[0] = + _CHROFF_3_3_;
	O6917[1] = + _CHROFF_4_3_;
	O6917[2] = + _CHROFF_5_3_;
	O6917[264] = + _CHROFF_5_3_;
	{long i; for (i = 298; i < 301; i++) O6917[i] = + _CHROFF_5_3_;}
	O6917[302] = + _CHROFF_7_3_;
	{long i; for (i = 303; i < 307; i++) O6917[i] = + _CHROFF_6_3_;}
}

long O7457[6];
void O7457_init () {
	{long i; for (i = 0; i < 2; i++) O7457[i] = + _CHROFF_4_0_;}
	O7457[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O7457[i] = + _CHROFF_4_0_;}
}

long O7458[6];
void O7458_init () {
	{long i; for (i = 0; i < 2; i++) O7458[i] = + _LNGOFF_4_2_0_0_;}
	O7458[2] = + _LNGOFF_5_2_0_0_;
	O7458[3] = + _LNGOFF_4_3_0_0_;
	O7458[4] = + _LNGOFF_4_2_0_0_;
	O7458[5] = + _LNGOFF_4_3_0_0_;
}

long O7466[6];
void O7466_init () {
	{long i; for (i = 0; i < 2; i++) O7466[i] = + _PTROFF_4_2_0_3_0_0_;}
	O7466[2] = + _PTROFF_5_2_0_3_0_0_;
	O7466[3] = + _PTROFF_4_3_0_3_0_0_;
	O7466[4] = + _PTROFF_4_2_0_4_0_0_;
	O7466[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O7467[6];
void O7467_init () {
	{long i; for (i = 0; i < 2; i++) O7467[i] = + _PTROFF_4_2_0_3_0_1_;}
	O7467[2] = + _PTROFF_5_2_0_3_0_1_;
	O7467[3] = + _PTROFF_4_3_0_3_0_1_;
	O7467[4] = + _PTROFF_4_2_0_4_0_1_;
	O7467[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O7469[6];
void O7469_init () {
	{long i; for (i = 0; i < 2; i++) O7469[i] = + _PTROFF_4_2_0_3_0_2_;}
	O7469[2] = + _PTROFF_5_2_0_3_0_2_;
	O7469[3] = + _PTROFF_4_3_0_3_0_2_;
	O7469[4] = + _PTROFF_4_2_0_4_0_2_;
	O7469[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O7470[6];
void O7470_init () {
	{long i; for (i = 0; i < 2; i++) O7470[i] = + _LNGOFF_4_2_0_1_;}
	O7470[2] = + _LNGOFF_5_2_0_1_;
	O7470[3] = + _LNGOFF_4_3_0_1_;
	O7470[4] = + _LNGOFF_4_2_0_1_;
	O7470[5] = + _LNGOFF_4_3_0_1_;
}

long O7471[6];
void O7471_init () {
	{long i; for (i = 0; i < 2; i++) O7471[i] = + _CHROFF_4_1_;}
	O7471[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O7471[i] = + _CHROFF_4_1_;}
}

long O7472[6];
void O7472_init () {
	{long i; for (i = 0; i < 2; i++) O7472[i] = + _LNGOFF_4_2_0_2_;}
	O7472[2] = + _LNGOFF_5_2_0_2_;
	O7472[3] = + _LNGOFF_4_3_0_2_;
	O7472[4] = + _LNGOFF_4_2_0_2_;
	O7472[5] = + _LNGOFF_4_3_0_2_;
}

long O7485[4];
void O7485_init () {
	O7485[0] =  + _REFACS_4_;
	O7485[1] = + _CHROFF_4_2_;
	O7485[2] = + _LNGOFF_4_2_0_3_;
	O7485[3] = + _CHROFF_4_2_;
}

long O7584[462];
void O7584_init () {
	{long i; for (i = 0; i < 3; i++) O7584[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O7584[i] = + _LNGOFF_1_0_0_0_;}
	O7584[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O7584[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O7584[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 460; i < 462; i++) O7584[i] = + _LNGOFF_1_1_0_0_;}
}

long O7585[462];
void O7585_init () {
	{long i; for (i = 0; i < 3; i++) O7585[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O7585[i] = + _LNGOFF_1_0_0_1_;}
	O7585[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O7585[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O7585[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 460; i < 462; i++) O7585[i] = + _LNGOFF_1_1_0_1_;}
}

long O7650[3];
void O7650_init () {
	{long i; for (i = 0; i < 2; i++) O7650[i] = + _LNGOFF_1_0_0_2_;}
	O7650[2] = + _LNGOFF_1_1_0_2_;
}

long O7730[456];
void O7730_init () {
	{long i; for (i = 0; i < 2; i++) O7730[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O7730[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 454; i < 456; i++) O7730[i] = + _LNGOFF_1_1_0_2_;}
}


#ifdef __cplusplus
}
#endif
