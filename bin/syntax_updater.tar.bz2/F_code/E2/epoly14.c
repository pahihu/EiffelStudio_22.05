#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O8333[10];
void O8333_init () {
	{long i; for (i = 0; i < 2; i++) O8333[i] = + _CHROFF_16_0_;}
	O8333[2] = + _CHROFF_18_0_;
	{long i; for (i = 3; i < 5; i++) O8333[i] = + _CHROFF_27_0_;}
	O8333[5] = + _CHROFF_29_0_;
	O8333[6] = + _CHROFF_18_0_;
	O8333[7] = + _CHROFF_23_0_;
	O8333[8] = + _CHROFF_21_0_;
	O8333[9] = + _CHROFF_22_0_;
}

long O8344[10];
void O8344_init () {
	{long i; for (i = 0; i < 3; i++) O8344[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O8344[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O8344[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O8344[i] =  + _REFACS_5_;}
}

static EIF_TYPE_INDEX Y8344_pgtype0[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype1[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype2[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype3[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype4[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype5[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype6[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype7[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype8[] = {0xFF01,1093,0xFFFF};
static EIF_TYPE_INDEX Y8344_pgtype9[] = {0xFF01,1093,0xFFFF};
EIF_TYPE_INDEX *Y8344_gen_type [10];
EIF_TYPE_INDEX Y8344 [10];
void Y8344_init (void)
{
	egc_routines_types [8344] = Y8344;
	egc_routines_gen_types [8344] = Y8344_gen_type;
	egc_routines_offset [8344] = 1162;
	Y8344_gen_type [0] = Y8344_pgtype0;
	Y8344_gen_type [1] = Y8344_pgtype1;
	Y8344_gen_type [2] = Y8344_pgtype2;
	Y8344_gen_type [3] = Y8344_pgtype3;
	Y8344_gen_type [4] = Y8344_pgtype4;
	Y8344_gen_type [5] = Y8344_pgtype5;
	Y8344_gen_type [6] = Y8344_pgtype6;
	Y8344_gen_type [7] = Y8344_pgtype7;
	Y8344_gen_type [8] = Y8344_pgtype8;
	Y8344_gen_type [9] = Y8344_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y8344[i] = 1093;};
}

long O8345[10];
void O8345_init () {
	{long i; for (i = 0; i < 3; i++) O8345[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O8345[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O8345[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O8345[i] =  + _REFACS_6_;}
}

long O8346[10];
void O8346_init () {
	{long i; for (i = 0; i < 3; i++) O8346[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O8346[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O8346[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O8346[i] =  + _REFACS_7_;}
}

static EIF_TYPE_INDEX Y8346_pgtype0[] = {0xFF01,1312,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype1[] = {0xFF01,1312,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype2[] = {0xFF01,1312,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype3[] = {0xFF01,1314,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype4[] = {0xFF01,1314,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype5[] = {0xFF01,1314,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype6[] = {0xFF01,1312,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype7[] = {0xFF01,1313,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype8[] = {0xFF01,1312,0xFFFF};
static EIF_TYPE_INDEX Y8346_pgtype9[] = {0xFF01,1312,0xFFFF};
EIF_TYPE_INDEX *Y8346_gen_type [10];
EIF_TYPE_INDEX Y8346 [10];
void Y8346_init (void)
{
	egc_routines_types [8346] = Y8346;
	egc_routines_gen_types [8346] = Y8346_gen_type;
	egc_routines_offset [8346] = 1162;
	Y8346_gen_type [0] = Y8346_pgtype0;
	Y8346_gen_type [1] = Y8346_pgtype1;
	Y8346_gen_type [2] = Y8346_pgtype2;
	Y8346_gen_type [3] = Y8346_pgtype3;
	Y8346_gen_type [4] = Y8346_pgtype4;
	Y8346_gen_type [5] = Y8346_pgtype5;
	Y8346_gen_type [6] = Y8346_pgtype6;
	Y8346_gen_type [7] = Y8346_pgtype7;
	Y8346_gen_type [8] = Y8346_pgtype8;
	Y8346_gen_type [9] = Y8346_pgtype9;
	{long i; for (i = 0; i < 3; i++) Y8346[i] = 1312;};
	{long i; for (i = 3; i < 6; i++) Y8346[i] = 1314;};
	Y8346[6] = 1312;
	Y8346[7] = 1313;
	{long i; for (i = 8; i < 10; i++) Y8346[i] = 1312;};
}

long O8348[10];
void O8348_init () {
	{long i; for (i = 0; i < 3; i++) O8348[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O8348[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O8348[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O8348[i] =  + _REFACS_8_;}
}

long O8350[10];
void O8350_init () {
	{long i; for (i = 0; i < 3; i++) O8350[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O8350[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O8350[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O8350[i] =  + _REFACS_10_;}
}

long O8381[10];
void O8381_init () {
	{long i; for (i = 0; i < 2; i++) O8381[i] = + _CHROFF_16_1_;}
	O8381[2] = + _CHROFF_18_1_;
	{long i; for (i = 3; i < 5; i++) O8381[i] = + _CHROFF_27_1_;}
	O8381[5] = + _CHROFF_29_1_;
	O8381[6] = + _CHROFF_18_1_;
	O8381[7] = + _CHROFF_23_1_;
	O8381[8] = + _CHROFF_21_1_;
	O8381[9] = + _CHROFF_22_1_;
}

long O8382[10];
void O8382_init () {
	{long i; for (i = 0; i < 3; i++) O8382[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O8382[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O8382[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O8382[i] =  + _REFACS_11_;}
}

long O8384[10];
void O8384_init () {
	{long i; for (i = 0; i < 3; i++) O8384[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O8384[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O8384[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O8384[i] =  + _REFACS_13_;}
}

long O8392[10];
void O8392_init () {
	{long i; for (i = 0; i < 2; i++) O8392[i] = + _LNGOFF_16_3_0_0_;}
	O8392[2] = + _LNGOFF_18_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O8392[i] = + _LNGOFF_27_5_0_0_;}
	O8392[5] = + _LNGOFF_29_5_0_0_;
	O8392[6] = + _LNGOFF_18_3_0_0_;
	O8392[7] = + _LNGOFF_23_4_0_0_;
	O8392[8] = + _LNGOFF_21_4_0_0_;
	O8392[9] = + _LNGOFF_22_4_0_0_;
}

long O8393[10];
void O8393_init () {
	{long i; for (i = 0; i < 3; i++) O8393[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O8393[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O8393[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O8393[i] =  + _REFACS_16_;}
}

long O8395[10];
void O8395_init () {
	{long i; for (i = 0; i < 2; i++) O8395[i] = + _CHROFF_16_2_;}
	O8395[2] = + _CHROFF_18_2_;
	{long i; for (i = 3; i < 5; i++) O8395[i] = + _CHROFF_27_2_;}
	O8395[5] = + _CHROFF_29_2_;
	O8395[6] = + _CHROFF_18_2_;
	O8395[7] = + _CHROFF_23_2_;
	O8395[8] = + _CHROFF_21_2_;
	O8395[9] = + _CHROFF_22_2_;
}

long O8400[3];
void O8400_init () {
	{long i; for (i = 0; i < 2; i++) O8400[i] = + _CHROFF_27_3_;}
	O8400[2] = + _CHROFF_29_3_;
}

long O8401[3];
void O8401_init () {
	{long i; for (i = 0; i < 2; i++) O8401[i] = + _CHROFF_27_4_;}
	O8401[2] = + _CHROFF_29_4_;
}

static EIF_TYPE_INDEX Y8403_pgtype0[] = {949,0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y8403_pgtype1[] = {949,0xFF01,1166,0xFFFF};
static EIF_TYPE_INDEX Y8403_pgtype2[] = {949,0xFF01,1167,0xFFFF};
EIF_TYPE_INDEX *Y8403_gen_type [3];
EIF_TYPE_INDEX Y8403 [3];
void Y8403_init (void)
{
	egc_routines_types [8403] = Y8403;
	egc_routines_gen_types [8403] = Y8403_gen_type;
	egc_routines_offset [8403] = 1165;
	Y8403_gen_type [0] = Y8403_pgtype0;
	Y8403_gen_type [1] = Y8403_pgtype1;
	Y8403_gen_type [2] = Y8403_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y8403[i] = 949;};
}

long O8435[4];
void O8435_init () {
	{long i; for (i = 0; i < 2; i++) O8435[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O8435[i] =  + _REFACS_18_;}
}

long O8436[4];
void O8436_init () {
	{long i; for (i = 0; i < 2; i++) O8436[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O8436[i] =  + _REFACS_19_;}
}

long O8452[2];
void O8452_init () {
	O8452[0] = + _CHROFF_21_3_;
	O8452[1] = + _CHROFF_22_3_;
}

long O9162[3];
void O9162_init () {
	O9162[0] = 0;
	{long i; for (i = 1; i < 3; i++) O9162[i] = + _LNGOFF_3_1_0_0_;}
}

long O9164[3];
void O9164_init () {
	O9164[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O9164[i] = 0;}
}

long O9176[3];
void O9176_init () {
	O9176[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O9176[i] = + _LNGOFF_3_1_0_1_;}
}

long O9179[3];
void O9179_init () {
	O9179[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O9179[i] = + _LNGOFF_3_1_0_2_;}
}

long O9186[3];
void O9186_init () {
	O9186[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O9186[i] = + _LNGOFF_3_1_0_3_;}
}

long O9193[3];
void O9193_init () {
	O9193[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O9193[i] = + _CHROFF_3_0_;}
}

long O9194[3];
void O9194_init () {
	O9194[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O9194[i] = + _LNGOFF_3_1_0_4_;}
}

long O9195[3];
void O9195_init () {
	O9195[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O9195[i] =  + _REFACS_1_;}
}

long O9196[3];
void O9196_init () {
	O9196[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O9196[i] =  + _REFACS_2_;}
}

long O9205[3];
void O9205_init () {
	O9205[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O9205[i] = + _LNGOFF_3_1_0_5_;}
}

long O9680[3];
void O9680_init () {
	O9680[0] = + _CHROFF_2_1_;
	O9680[1] = + _CHROFF_16_1_;
	O9680[2] = + _CHROFF_5_1_;
}

long O9682[3];
void O9682_init () {
	O9682[0] = 0;
	O9682[1] =  + _REFACS_1_;
	O9682[2] = 0;
}

long O9683[3];
void O9683_init () {
	O9683[0] =  + _REFACS_1_;
	O9683[1] =  + _REFACS_2_;
	O9683[2] =  + _REFACS_1_;
}

long O9685[3];
void O9685_init () {
	O9685[0] = + _LNGOFF_2_2_0_0_;
	O9685[1] = + _LNGOFF_16_4_0_1_;
	O9685[2] = + _LNGOFF_5_2_0_0_;
}

long O9755[253];
void O9755_init () {
	{long i; for (i = 0; i < 4; i++) O9755[i] = + _CHROFF_1_0_;}
	O9755[252] = + _CHROFF_4_0_;
}

long O9756[253];
void O9756_init () {
	{long i; for (i = 0; i < 4; i++) O9756[i] = + _CHROFF_1_1_;}
	O9756[252] = + _CHROFF_4_1_;
}

long O10960[3];
void O10960_init () {
	{long i; for (i = 0; i < 2; i++) O10960[i] = + _CHROFF_6_0_;}
	O10960[2] = + _CHROFF_7_0_;
}

long O10961[3];
void O10961_init () {
	{long i; for (i = 0; i < 2; i++) O10961[i] = + _CHROFF_6_1_;}
	O10961[2] = + _CHROFF_7_1_;
}

long O10971[3];
void O10971_init () {
	{long i; for (i = 0; i < 2; i++) O10971[i] = + _LNGOFF_6_2_0_0_;}
	O10971[2] = + _LNGOFF_7_3_0_0_;
}

long O11048[13];
void O11048_init () {
	{long i; for (i = 0; i < 3; i++) O11048[i] = + _LNGOFF_4_0_0_0_;}
	O11048[3] = + _LNGOFF_6_0_0_0_;
	{long i; for (i = 4; i < 7; i++) O11048[i] = + _LNGOFF_5_0_0_0_;}
	{long i; for (i = 7; i < 13; i++) O11048[i] = + _LNGOFF_6_0_0_0_;}
}

long O11049[13];
void O11049_init () {
	{long i; for (i = 0; i < 3; i++) O11049[i] = + _LNGOFF_4_0_0_1_;}
	O11049[3] = + _LNGOFF_6_0_0_1_;
	{long i; for (i = 4; i < 7; i++) O11049[i] = + _LNGOFF_5_0_0_1_;}
	{long i; for (i = 7; i < 13; i++) O11049[i] = + _LNGOFF_6_0_0_1_;}
}

static EIF_TYPE_INDEX Y11522_pgtype0[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y11522_pgtype1[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y11522_pgtype2[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y11522_pgtype3[] = {0xFF01,1090,0xFFFF};
EIF_TYPE_INDEX *Y11522_gen_type [4];
EIF_TYPE_INDEX Y11522 [4];
void Y11522_init (void)
{
	egc_routines_types [11522] = Y11522;
	egc_routines_gen_types [11522] = Y11522_gen_type;
	egc_routines_offset [11522] = 1361;
	Y11522_gen_type [0] = Y11522_pgtype0;
	Y11522_gen_type [1] = Y11522_pgtype1;
	Y11522_gen_type [2] = Y11522_pgtype2;
	Y11522_gen_type [3] = Y11522_pgtype3;
	{long i; for (i = 0; i < 4; i++) Y11522[i] = 1090;};
}

long O13440[98];
void O13440_init () {
	O13440[0] = + _LNGOFF_4_0_0_0_;
	O13440[74] = + _LNGOFF_5_0_0_0_;
	O13440[97] = + _LNGOFF_4_0_0_0_;
}

long O13441[98];
void O13441_init () {
	O13441[0] = + _LNGOFF_4_0_0_1_;
	O13441[74] = + _LNGOFF_5_0_0_1_;
	O13441[97] = + _LNGOFF_4_0_0_1_;
}

long O13564[103];
void O13564_init () {
	{long i; for (i = 0; i < 4; i++) O13564[i] = + _CHROFF_3_0_;}
	O13564[102] = + _CHROFF_4_0_;
}

long O13583[2];
void O13583_init () {
	O13583[0] = + _LNGOFF_2_0_0_0_;
	O13583[1] = + _LNGOFF_3_0_0_0_;
}

long O13584[2];
void O13584_init () {
	O13584[0] = + _LNGOFF_2_0_0_1_;
	O13584[1] = + _LNGOFF_3_0_0_1_;
}

long O13589[2];
void O13589_init () {
	O13589[0] = + _LNGOFF_2_0_0_2_;
	O13589[1] = + _LNGOFF_3_0_0_2_;
}

long O13620[5];
void O13620_init () {
	{long i; for (i = 0; i < 4; i++) O13620[i] = + _LNGOFF_1_0_0_0_;}
	O13620[4] = + _LNGOFF_2_0_0_2_;
}

long O13621[5];
void O13621_init () {
	{long i; for (i = 0; i < 4; i++) O13621[i] = + _LNGOFF_1_0_0_1_;}
	O13621[4] = + _LNGOFF_2_0_0_3_;
}

long O13640[9];
void O13640_init () {
	O13640[0] = + _LNGOFF_0_6_0_0_;
	O13640[1] = + _LNGOFF_1_6_0_0_;
	O13640[2] = + _LNGOFF_2_6_0_0_;
	{long i; for (i = 3; i < 5; i++) O13640[i] = + _LNGOFF_1_6_0_0_;}
	O13640[5] = + _LNGOFF_1_8_0_0_;
	O13640[6] = + _LNGOFF_2_6_0_0_;
	O13640[7] = + _LNGOFF_1_7_0_0_;
	O13640[8] = + _LNGOFF_2_7_0_0_;
}

long O13641[9];
void O13641_init () {
	O13641[0] = + _LNGOFF_0_6_0_1_;
	O13641[1] = + _LNGOFF_1_6_0_1_;
	O13641[2] = + _LNGOFF_2_6_0_1_;
	{long i; for (i = 3; i < 5; i++) O13641[i] = + _LNGOFF_1_6_0_1_;}
	O13641[5] = + _LNGOFF_1_8_0_1_;
	O13641[6] = + _LNGOFF_2_6_0_1_;
	O13641[7] = + _LNGOFF_1_7_0_1_;
	O13641[8] = + _LNGOFF_2_7_0_1_;
}

long O13642[9];
void O13642_init () {
	O13642[0] = + _LNGOFF_0_6_0_2_;
	O13642[1] = + _LNGOFF_1_6_0_2_;
	O13642[2] = + _LNGOFF_2_6_0_2_;
	{long i; for (i = 3; i < 5; i++) O13642[i] = + _LNGOFF_1_6_0_2_;}
	O13642[5] = + _LNGOFF_1_8_0_2_;
	O13642[6] = + _LNGOFF_2_6_0_2_;
	O13642[7] = + _LNGOFF_1_7_0_2_;
	O13642[8] = + _LNGOFF_2_7_0_2_;
}

long O13643[9];
void O13643_init () {
	O13643[0] = + _LNGOFF_0_6_0_3_;
	O13643[1] = + _LNGOFF_1_6_0_3_;
	O13643[2] = + _LNGOFF_2_6_0_3_;
	{long i; for (i = 3; i < 5; i++) O13643[i] = + _LNGOFF_1_6_0_3_;}
	O13643[5] = + _LNGOFF_1_8_0_3_;
	O13643[6] = + _LNGOFF_2_6_0_3_;
	O13643[7] = + _LNGOFF_1_7_0_3_;
	O13643[8] = + _LNGOFF_2_7_0_3_;
}

long O13644[9];
void O13644_init () {
	O13644[0] = + _LNGOFF_0_6_0_4_;
	O13644[1] = + _LNGOFF_1_6_0_4_;
	O13644[2] = + _LNGOFF_2_6_0_4_;
	{long i; for (i = 3; i < 5; i++) O13644[i] = + _LNGOFF_1_6_0_4_;}
	O13644[5] = + _LNGOFF_1_8_0_4_;
	O13644[6] = + _LNGOFF_2_6_0_4_;
	O13644[7] = + _LNGOFF_1_7_0_4_;
	O13644[8] = + _LNGOFF_2_7_0_4_;
}

long O13654[9];
void O13654_init () {
	O13654[0] = + _CHROFF_0_0_;
	O13654[1] = + _CHROFF_1_0_;
	O13654[2] = + _CHROFF_2_0_;
	{long i; for (i = 3; i < 6; i++) O13654[i] = + _CHROFF_1_0_;}
	O13654[6] = + _CHROFF_2_0_;
	O13654[7] = + _CHROFF_1_0_;
	O13654[8] = + _CHROFF_2_0_;
}

long O13655[9];
void O13655_init () {
	O13655[0] = + _CHROFF_0_1_;
	O13655[1] = + _CHROFF_1_1_;
	O13655[2] = + _CHROFF_2_1_;
	{long i; for (i = 3; i < 6; i++) O13655[i] = + _CHROFF_1_1_;}
	O13655[6] = + _CHROFF_2_1_;
	O13655[7] = + _CHROFF_1_1_;
	O13655[8] = + _CHROFF_2_1_;
}

long O13657[9];
void O13657_init () {
	O13657[0] = + _CHROFF_0_3_;
	O13657[1] = + _CHROFF_1_3_;
	O13657[2] = + _CHROFF_2_3_;
	{long i; for (i = 3; i < 6; i++) O13657[i] = + _CHROFF_1_3_;}
	O13657[6] = + _CHROFF_2_3_;
	O13657[7] = + _CHROFF_1_3_;
	O13657[8] = + _CHROFF_2_3_;
}

long O13658[9];
void O13658_init () {
	O13658[0] = + _CHROFF_0_4_;
	O13658[1] = + _CHROFF_1_4_;
	O13658[2] = + _CHROFF_2_4_;
	{long i; for (i = 3; i < 6; i++) O13658[i] = + _CHROFF_1_4_;}
	O13658[6] = + _CHROFF_2_4_;
	O13658[7] = + _CHROFF_1_4_;
	O13658[8] = + _CHROFF_2_4_;
}

long O13659[9];
void O13659_init () {
	O13659[0] = + _CHROFF_0_5_;
	O13659[1] = + _CHROFF_1_5_;
	O13659[2] = + _CHROFF_2_5_;
	{long i; for (i = 3; i < 6; i++) O13659[i] = + _CHROFF_1_5_;}
	O13659[6] = + _CHROFF_2_5_;
	O13659[7] = + _CHROFF_1_5_;
	O13659[8] = + _CHROFF_2_5_;
}

long O13703[2];
void O13703_init () {
	O13703[0] = + _CHROFF_1_6_;
	O13703[1] = + _CHROFF_2_6_;
}

long O13704[2];
void O13704_init () {
	O13704[0] = + _LNGOFF_1_7_0_5_;
	O13704[1] = + _LNGOFF_2_7_0_5_;
}

long O13818[70];
void O13818_init () {
	O13818[0] = + _LNGOFF_0_0_3_3_;
	O13818[1] = + _LNGOFF_1_0_3_3_;
	O13818[2] = + _LNGOFF_0_0_3_3_;
	{long i; for (i = 3; i < 5; i++) O13818[i] = + _LNGOFF_1_0_3_3_;}
	{long i; for (i = 5; i < 7; i++) O13818[i] = + _LNGOFF_0_0_3_3_;}
	O13818[7] = + _LNGOFF_1_0_3_3_;
	O13818[19] = + _LNGOFF_1_0_3_3_;
	{long i; for (i = 43; i < 46; i++) O13818[i] = + _LNGOFF_0_0_3_3_;}
	O13818[60] = + _LNGOFF_0_1_3_3_;
	O13818[61] = + _LNGOFF_0_0_3_3_;
	O13818[62] = + _LNGOFF_2_0_3_3_;
	O13818[63] = + _LNGOFF_1_2_3_3_;
	{long i; for (i = 64; i < 66; i++) O13818[i] = + _LNGOFF_0_0_3_3_;}
	O13818[66] = + _LNGOFF_2_2_3_3_;
	O13818[67] = + _LNGOFF_3_3_3_3_;
	O13818[68] = + _LNGOFF_0_1_3_4_;
	O13818[69] = + _LNGOFF_1_1_3_4_;
}

long O13860[3];
void O13860_init () {
	O13860[0] = + _LNGOFF_0_0_3_4_;
	O13860[2] = + _LNGOFF_1_0_3_4_;
}

long O13937[57];
void O13937_init () {
	{long i; for (i = 0; i < 2; i++) O13937[i] = + _LNGOFF_0_0_3_4_;}
	O13937[2] = + _LNGOFF_1_0_3_4_;
	O13937[14] = + _LNGOFF_1_0_3_4_;
	{long i; for (i = 38; i < 41; i++) O13937[i] = + _LNGOFF_0_0_3_4_;}
	O13937[55] = + _LNGOFF_0_1_3_4_;
	O13937[56] = + _LNGOFF_0_0_3_4_;
}

long O13938[14];
void O13938_init () {
	{long i; for (i = 0; i < 5; i++) O13938[i] = 0;}
	O13938[5] =  + _REFACS_4_;
	{long i; for (i = 6; i < 14; i++) O13938[i] = 0;}
}

long O14168[3];
void O14168_init () {
	{long i; for (i = 0; i < 2; i++) O14168[i] = + _LNGOFF_4_1_0_2_;}
	O14168[2] = + _LNGOFF_5_1_0_2_;
}

long O14169[3];
void O14169_init () {
	{long i; for (i = 0; i < 2; i++) O14169[i] = + _LNGOFF_4_1_0_3_;}
	O14169[2] = + _LNGOFF_5_1_0_3_;
}

long O14177[3];
void O14177_init () {
	{long i; for (i = 0; i < 2; i++) O14177[i] = + _CHROFF_4_0_;}
	O14177[2] = + _CHROFF_5_0_;
}

long O14180[2];
void O14180_init () {
	O14180[0] = + _LNGOFF_4_1_0_4_;
	O14180[1] = + _LNGOFF_5_1_0_4_;
}

long O14181[2];
void O14181_init () {
	O14181[0] = + _LNGOFF_4_1_0_5_;
	O14181[1] = + _LNGOFF_5_1_0_5_;
}

long O14208[6];
void O14208_init () {
	{long i; for (i = 0; i < 4; i++) O14208[i] = + _LNGOFF_2_0_0_2_;}
	O14208[4] = + _LNGOFF_3_0_0_2_;
	O14208[5] = + _LNGOFF_2_0_0_2_;
}

EIF_TYPE_INDEX *Y14286_gen_type [2];
EIF_TYPE_INDEX Y14286 [2];
void Y14286_init (void)
{
	egc_routines_types [14286] = Y14286;
	egc_routines_gen_types [14286] = Y14286_gen_type;
	egc_routines_offset [14286] = 1512;
	{long i; for (i = 0; i < 2; i++) Y14286[i] = 1229;};
}

long O14289[2];
void O14289_init () {
	O14289[0] = + _CHROFF_2_1_;
	O14289[1] = + _CHROFF_3_1_;
}

long O14299[2];
void O14299_init () {
	O14299[0] = + _LNGOFF_2_2_3_4_;
	O14299[1] = + _LNGOFF_3_3_3_4_;
}

long O14309[2];
void O14309_init () {
	O14309[0] = + _LNGOFF_0_1_3_0_;
	O14309[1] = + _LNGOFF_1_1_3_0_;
}

long O14321[25];
void O14321_init () {
	{long i; for (i = 0; i < 5; i++) O14321[i] = + _LNGOFF_3_0_0_2_;}
	O14321[5] = + _LNGOFF_4_0_0_2_;
	{long i; for (i = 6; i < 25; i++) O14321[i] = + _LNGOFF_3_0_0_2_;}
}


#ifdef __cplusplus
}
#endif
