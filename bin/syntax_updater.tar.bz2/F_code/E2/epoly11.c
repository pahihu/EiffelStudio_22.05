#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6934[263])();
void R6934_init () {
	R6934[0] = (char *(*)()) F1008_8878;
	R6934[262] = (char *(*)()) F1270_12021;
}

char *(*R6940[263])();
void R6940_init () {
	R6940[0] = (char *(*)()) F1008_8884;
	R6940[262] = (char *(*)()) F1270_12059;
}

char *(*R6944[263])();
void R6944_init () {
	R6944[0] = (char *(*)()) F1008_8888;
	R6944[262] = (char *(*)()) F1270_12060;
}

char *(*R6953[536])();
void R6953_init () {
	R6953[0] = (char *(*)()) F1016_8926;
	R6953[535] = (char *(*)()) F1551_18531;
}

char *(*R6973[536])();
void R6973_init () {
	R6973[0] = (char *(*)()) F1016_8923;
	R6973[535] = (char *(*)()) F1551_18572;
}

char *(*R7172[512])();
void R7172_init () {
	R7172[0] = (char *(*)()) F1040_9199;
	{long i; for (i = 2; i < 4; i++) R7172[i] = (char *(*)()) F1041_9306;}
	{long i; for (i = 5; i < 7; i++) R7172[i] = (char *(*)()) F1044_9328;}
	{long i; for (i = 8; i < 10; i++) R7172[i] = (char *(*)()) F1047_9369;}
	R7172[10] = (char *(*)()) F1050_9423;
	{long i; for (i = 13; i < 43; i++) R7172[i] = (char *(*)()) F1052_9445;}
	R7172[43] = (char *(*)()) F1083_9471;
	R7172[44] = (char *(*)()) F1084_9471;
	{long i; for (i = 46; i < 51; i++) R7172[i] = (char *(*)()) F1085_9479;}
	{long i; for (i = 55; i < 57; i++) R7172[i] = (char *(*)()) F1091_9538;}
	{long i; for (i = 58; i < 60; i++) R7172[i] = (char *(*)()) F1091_9538;}
	R7172[72] = (char *(*)()) F1112_10302;
	R7172[73] = (char *(*)()) F1113_10435;
	R7172[75] = (char *(*)()) F1115_10490;
	R7172[76] = (char *(*)()) F1116_10532;
	R7172[77] = (char *(*)()) F1117_10532;
	R7172[78] = (char *(*)()) F1118_10532;
	R7172[79] = (char *(*)()) F1119_10532;
	R7172[80] = (char *(*)()) F1120_10532;
	R7172[81] = (char *(*)()) F1121_10532;
	R7172[82] = (char *(*)()) F1122_10532;
	R7172[83] = (char *(*)()) F1123_10532;
	R7172[84] = (char *(*)()) F1124_10532;
	R7172[85] = (char *(*)()) F1125_10532;
	R7172[86] = (char *(*)()) F1126_10532;
	R7172[87] = (char *(*)()) F1127_10532;
	R7172[88] = (char *(*)()) F1128_10532;
	R7172[89] = (char *(*)()) F1129_10532;
	R7172[90] = (char *(*)()) F1130_10532;
	R7172[91] = (char *(*)()) F1131_10532;
	R7172[92] = (char *(*)()) F1132_10532;
	R7172[93] = (char *(*)()) F1133_10532;
	R7172[94] = (char *(*)()) F1134_10532;
	R7172[95] = (char *(*)()) F1135_10532;
	R7172[96] = (char *(*)()) F1136_10532;
	R7172[97] = (char *(*)()) F1137_10532;
	R7172[98] = (char *(*)()) F1138_10532;
	R7172[99] = (char *(*)()) F1139_10532;
	R7172[100] = (char *(*)()) F1140_10532;
	R7172[101] = (char *(*)()) F1141_10532;
	R7172[102] = (char *(*)()) F1142_10532;
	R7172[103] = (char *(*)()) F1143_10532;
	R7172[104] = (char *(*)()) F1144_10532;
	R7172[105] = (char *(*)()) F1145_10532;
	R7172[106] = (char *(*)()) F1146_10532;
	R7172[107] = (char *(*)()) F1147_10532;
	R7172[108] = (char *(*)()) F1148_10532;
	R7172[109] = (char *(*)()) F1149_10532;
	{long i; for (i = 126; i < 129; i++) R7172[i] = (char *(*)()) F1163_10633;}
	{long i; for (i = 130; i < 133; i++) R7172[i] = (char *(*)()) F1163_10633;}
	R7172[180] = (char *(*)()) F1220_10877;
	R7172[181] = (char *(*)()) F1221_10882;
	R7172[182] = (char *(*)()) F1222_10911;
	R7172[183] = (char *(*)()) F1223_10926;
	{long i; for (i = 186; i < 188; i++) R7172[i] = (char *(*)()) F1225_10954;}
	{long i; for (i = 189; i < 191; i++) R7172[i] = (char *(*)()) F1228_11052;}
	{long i; for (i = 192; i < 194; i++) R7172[i] = (char *(*)()) F1231_11151;}
	{long i; for (i = 195; i < 197; i++) R7172[i] = (char *(*)()) F1234_11250;}
	{long i; for (i = 198; i < 200; i++) R7172[i] = (char *(*)()) F1237_11349;}
	{long i; for (i = 201; i < 203; i++) R7172[i] = (char *(*)()) F1240_11443;}
	{long i; for (i = 204; i < 206; i++) R7172[i] = (char *(*)()) F1243_11537;}
	{long i; for (i = 207; i < 209; i++) R7172[i] = (char *(*)()) F1246_11632;}
	{long i; for (i = 210; i < 212; i++) R7172[i] = (char *(*)()) F1249_11727;}
	{long i; for (i = 213; i < 215; i++) R7172[i] = (char *(*)()) F1252_11793;}
	R7172[215] = (char *(*)()) F1255_11875;
	R7172[216] = (char *(*)()) F1256_11913;
	R7172[217] = (char *(*)()) F1257_11919;
	R7172[218] = (char *(*)()) F1258_11928;
	{long i; for (i = 473; i < 475; i++) R7172[i] = (char *(*)()) F1513_18099;}
	R7172[511] = (char *(*)()) F1551_18499;
}

char *(*R7322[2])();
void R7322_init () {
	R7322[0] = (char *(*)()) F1045_9364;
	R7322[1] = (char *(*)()) F1046_9364;
}

char *(*R7485[4])();
void R7485_init () {
	R7485[0] = (char *(*)()) F1087_9518;
	R7485[1] = (char *(*)()) F1088_9518_7485_1;
	R7485[2] = (char *(*)()) F1089_9518_7485_1;
	R7485[3] = (char *(*)()) F1088_9518_7485_1;
}
static EIF_REFERENCE F1088_9518_7485_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1088_9518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1089_9518_7485_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1089_9518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7490[4])();
void R7490_init () {
	R7490[0] = (char *(*)()) F1087_9527;
	R7490[1] = (char *(*)()) F1088_9527_7490_407;
	R7490[2] = (char *(*)()) F1089_9527_7490_407;
	R7490[3] = (char *(*)()) F1088_9527_7490_407;
}
static EIF_REFERENCE F1088_9527_7490_407 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1088_9527(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1089_9527_7490_407 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1089_9527(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7491_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7491_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7491_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7491_pgtype3[] = {1042,0xFFFF};
EIF_TYPE_INDEX *Y7491_gen_type [4];
EIF_TYPE_INDEX Y7491 [4];
void Y7491_init (void)
{
	egc_routines_types [7491] = Y7491;
	egc_routines_gen_types [7491] = Y7491_gen_type;
	egc_routines_offset [7491] = 1086;
	Y7491_gen_type [0] = Y7491_pgtype0;
	Y7491_gen_type [1] = Y7491_pgtype1;
	Y7491_gen_type [2] = Y7491_pgtype2;
	Y7491_gen_type [3] = Y7491_pgtype3;
	Y7491[3] = 1042;
}

char *(*R7492[457])();
void R7492_init () {
	{long i; for (i = 0; i < 2; i++) R7492[i] = (char *(*)()) F1094_9659;}
	{long i; for (i = 3; i < 5; i++) R7492[i] = (char *(*)()) F1097_9826;}
	R7492[456] = (char *(*)()) F1551_18473;
}

char *(*R7494[457])();
void R7494_init () {
	R7494[0] = (char *(*)()) F1095_9720;
	R7494[1] = (char *(*)()) F1096_9743;
	R7494[3] = (char *(*)()) F1098_9886;
	R7494[4] = (char *(*)()) F1099_9908;
	R7494[456] = (char *(*)()) F1551_18601;
}

char *(*R7495[457])();
void R7495_init () {
	R7495[0] = (char *(*)()) F1095_9718;
	R7495[1] = (char *(*)()) F1096_9741;
	R7495[3] = (char *(*)()) F1098_9885;
	R7495[4] = (char *(*)()) F1099_9907;
	R7495[456] = (char *(*)()) F1099_9907;
}

char *(*R7496[457])();
void R7496_init () {
	{long i; for (i = 0; i < 2; i++) R7496[i] = (char *(*)()) F1094_9671;}
	{long i; for (i = 3; i < 5; i++) R7496[i] = (char *(*)()) F1091_9532;}
	R7496[456] = (char *(*)()) F1091_9532;
}

char *(*R7506[457])();
void R7506_init () {
	{long i; for (i = 0; i < 2; i++) R7506[i] = (char *(*)()) F1094_9689;}
	{long i; for (i = 3; i < 5; i++) R7506[i] = (char *(*)()) F1097_9857;}
	R7506[456] = (char *(*)()) F1097_9857;
}

char *(*R7508[457])();
void R7508_init () {
	{long i; for (i = 0; i < 2; i++) R7508[i] = (char *(*)()) F1094_9691;}
	{long i; for (i = 3; i < 5; i++) R7508[i] = (char *(*)()) F1097_9859;}
	R7508[456] = (char *(*)()) F1097_9859;
}

char *(*R7509[457])();
void R7509_init () {
	R7509[0] = (char *(*)()) F1095_9730;
	R7509[1] = (char *(*)()) F760_7351;
	R7509[3] = (char *(*)()) F1098_9895;
	R7509[4] = (char *(*)()) F759_7351;
	R7509[456] = (char *(*)()) F759_7351;
}

char *(*R7511[457])();
void R7511_init () {
	{long i; for (i = 0; i < 2; i++) R7511[i] = (char *(*)()) F1094_9692;}
	{long i; for (i = 3; i < 5; i++) R7511[i] = (char *(*)()) F1097_9860;}
	R7511[456] = (char *(*)()) F1097_9860;
}

char *(*R7512[457])();
void R7512_init () {
	{long i; for (i = 0; i < 2; i++) R7512[i] = (char *(*)()) F1094_9693;}
	{long i; for (i = 3; i < 5; i++) R7512[i] = (char *(*)()) F1091_9549;}
	R7512[456] = (char *(*)()) F1091_9549;
}

char *(*R7531[457])();
void R7531_init () {
	{long i; for (i = 0; i < 2; i++) R7531[i] = (char *(*)()) F1094_9680;}
	{long i; for (i = 3; i < 5; i++) R7531[i] = (char *(*)()) F1097_9848;}
	R7531[456] = (char *(*)()) F1551_18504;
}

char *(*R7532[457])();
void R7532_init () {
	{long i; for (i = 0; i < 2; i++) R7532[i] = (char *(*)()) F1094_9679;}
	{long i; for (i = 3; i < 5; i++) R7532[i] = (char *(*)()) F1097_9847;}
	R7532[456] = (char *(*)()) F1551_18506;
}

char *(*R7536[457])();
void R7536_init () {
	{long i; for (i = 0; i < 2; i++) R7536[i] = (char *(*)()) F1091_9573;}
	{long i; for (i = 3; i < 5; i++) R7536[i] = (char *(*)()) F1091_9573;}
	R7536[456] = (char *(*)()) F1551_18511;
}

char *(*R7537[457])();
void R7537_init () {
	{long i; for (i = 0; i < 2; i++) R7537[i] = (char *(*)()) F1091_9574;}
	{long i; for (i = 3; i < 5; i++) R7537[i] = (char *(*)()) F1091_9574;}
	R7537[456] = (char *(*)()) F1551_18517;
}

char *(*R7542[457])();
void R7542_init () {
	{long i; for (i = 0; i < 2; i++) R7542[i] = (char *(*)()) F1094_9676;}
	{long i; for (i = 3; i < 5; i++) R7542[i] = (char *(*)()) F1097_9844;}
	R7542[456] = (char *(*)()) F1551_18492;
}

char *(*R7553[457])();
void R7553_init () {
	R7553[0] = (char *(*)()) F1095_9725;
	R7553[1] = (char *(*)()) F1096_9809;
	R7553[3] = (char *(*)()) F1098_9891;
	R7553[4] = (char *(*)()) F1099_9974;
	R7553[456] = (char *(*)()) F1551_18561;
}

char *(*R7554[457])();
void R7554_init () {
	R7554[0] = (char *(*)()) F1095_9726;
	R7554[1] = (char *(*)()) F1096_9810;
	R7554[3] = (char *(*)()) F1098_9892;
	R7554[4] = (char *(*)()) F1099_9975;
	R7554[456] = (char *(*)()) F1551_18562;
}

char *(*R7572[457])();
void R7572_init () {
	R7572[0] = (char *(*)()) F1095_9727;
	R7572[1] = (char *(*)()) F1096_9821;
	R7572[3] = (char *(*)()) F1098_9893;
	R7572[4] = (char *(*)()) F1099_9986;
	R7572[456] = (char *(*)()) F1551_18490;
}


#ifdef __cplusplus
}
#endif
