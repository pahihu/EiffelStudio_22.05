#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5981[706])();
void R5981_init () {
	R5981[0] = (char *(*)()) F846_7456;
	R5981[1] = (char *(*)()) F847_7456;
	R5981[2] = (char *(*)()) F848_7456;
	R5981[3] = (char *(*)()) F849_7456;
	R5981[4] = (char *(*)()) F850_7456;
	R5981[5] = (char *(*)()) F851_7456;
	R5981[6] = (char *(*)()) F852_7456;
	R5981[7] = (char *(*)()) F853_7456;
	{long i; for (i = 8; i < 10; i++) R5981[i] = (char *(*)()) F846_7456;}
	R5981[10] = (char *(*)()) F848_7456;
	R5981[11] = (char *(*)()) F852_7456;
	R5981[12] = (char *(*)()) F849_7456;
	R5981[13] = (char *(*)()) F853_7456;
	R5981[26] = (char *(*)()) F872_7570;
	R5981[27] = (char *(*)()) F873_7616;
	R5981[28] = (char *(*)()) F874_7616;
	R5981[29] = (char *(*)()) F875_7616;
	R5981[30] = (char *(*)()) F876_7616;
	R5981[31] = (char *(*)()) F877_7616;
	R5981[32] = (char *(*)()) F878_7616;
	R5981[33] = (char *(*)()) F879_7616;
	R5981[34] = (char *(*)()) F880_7616;
	R5981[35] = (char *(*)()) F881_7616;
	R5981[36] = (char *(*)()) F882_7616;
	R5981[37] = (char *(*)()) F883_7616;
	R5981[38] = (char *(*)()) F884_7616;
	R5981[94] = (char *(*)()) F940_7732;
	R5981[95] = (char *(*)()) F941_7732;
	R5981[96] = (char *(*)()) F942_7732;
	{long i; for (i = 97; i < 100; i++) R5981[i] = (char *(*)()) F940_7732;}
	R5981[100] = (char *(*)()) F942_7732;
	R5981[101] = (char *(*)()) F941_7732;
	R5981[103] = (char *(*)()) F940_7732;
	R5981[104] = (char *(*)()) F950_7864;
	R5981[105] = (char *(*)()) F951_7864;
	R5981[106] = (char *(*)()) F952_7864;
	R5981[107] = (char *(*)()) F953_7864;
	R5981[108] = (char *(*)()) F954_7864;
	R5981[109] = (char *(*)()) F955_7864;
	R5981[110] = (char *(*)()) F956_7864;
	R5981[111] = (char *(*)()) F957_7864;
	R5981[112] = (char *(*)()) F958_7864;
	R5981[113] = (char *(*)()) F959_7864;
	R5981[114] = (char *(*)()) F960_7864;
	R5981[115] = (char *(*)()) F961_7864;
	R5981[116] = (char *(*)()) F950_7864;
	R5981[118] = (char *(*)()) F950_7864;
	R5981[120] = (char *(*)()) F950_7864;
	R5981[121] = (char *(*)()) F953_7864;
	R5981[122] = (char *(*)()) F954_7864;
	R5981[123] = (char *(*)()) F950_7864;
	{long i; for (i = 125; i < 127; i++) R5981[i] = (char *(*)()) F950_7864;}
	{long i; for (i = 127; i < 129; i++) R5981[i] = (char *(*)()) F953_7864;}
	R5981[194] = (char *(*)()) F1040_9202;
	{long i; for (i = 249; i < 251; i++) R5981[i] = (char *(*)()) F1094_9680;}
	{long i; for (i = 252; i < 254; i++) R5981[i] = (char *(*)()) F1097_9848;}
	R5981[305] = (char *(*)()) F1151_10574;
	R5981[306] = (char *(*)()) F1152_10574;
	R5981[307] = (char *(*)()) F1153_10574;
	R5981[308] = (char *(*)()) F1154_10574;
	R5981[309] = (char *(*)()) F1155_10574;
	R5981[310] = (char *(*)()) F1156_10574;
	R5981[311] = (char *(*)()) F1157_10574;
	R5981[312] = (char *(*)()) F1158_10574;
	R5981[313] = (char *(*)()) F1159_10574;
	R5981[314] = (char *(*)()) F1160_10574;
	R5981[315] = (char *(*)()) F1161_10574;
	R5981[316] = (char *(*)()) F1162_10574;
	{long i; for (i = 593; i < 603; i++) R5981[i] = (char *(*)()) F950_7864;}
	R5981[705] = (char *(*)()) F1551_18504;
}

char *(*R5983[706])();
void R5983_init () {
	R5983[0] = (char *(*)()) F846_7472;
	R5983[1] = (char *(*)()) F847_7472;
	R5983[2] = (char *(*)()) F848_7472;
	R5983[3] = (char *(*)()) F849_7472;
	R5983[4] = (char *(*)()) F850_7472;
	R5983[5] = (char *(*)()) F851_7472;
	R5983[6] = (char *(*)()) F852_7472;
	R5983[7] = (char *(*)()) F853_7472;
	{long i; for (i = 8; i < 10; i++) R5983[i] = (char *(*)()) F846_7472;}
	R5983[10] = (char *(*)()) F848_7472;
	R5983[11] = (char *(*)()) F852_7472;
	R5983[12] = (char *(*)()) F849_7472;
	R5983[13] = (char *(*)()) F853_7472;
	R5983[26] = (char *(*)()) F872_7574;
	R5983[27] = (char *(*)()) F873_7625;
	R5983[28] = (char *(*)()) F874_7625;
	R5983[29] = (char *(*)()) F875_7625;
	R5983[30] = (char *(*)()) F876_7625;
	R5983[31] = (char *(*)()) F877_7625;
	R5983[32] = (char *(*)()) F878_7625;
	R5983[33] = (char *(*)()) F879_7625;
	R5983[34] = (char *(*)()) F880_7625;
	R5983[35] = (char *(*)()) F881_7625;
	R5983[36] = (char *(*)()) F882_7625;
	R5983[37] = (char *(*)()) F883_7625;
	R5983[38] = (char *(*)()) F884_7625;
	R5983[94] = (char *(*)()) F890_7676;
	R5983[95] = (char *(*)()) F893_7676;
	R5983[96] = (char *(*)()) F894_7676;
	{long i; for (i = 97; i < 100; i++) R5983[i] = (char *(*)()) F890_7676;}
	R5983[100] = (char *(*)()) F894_7676;
	R5983[101] = (char *(*)()) F893_7676;
	R5983[103] = (char *(*)()) F890_7676;
	R5983[104] = (char *(*)()) F950_7870;
	R5983[105] = (char *(*)()) F951_7870;
	R5983[106] = (char *(*)()) F952_7870;
	R5983[107] = (char *(*)()) F953_7870;
	R5983[108] = (char *(*)()) F954_7870;
	R5983[109] = (char *(*)()) F955_7870;
	R5983[110] = (char *(*)()) F956_7870;
	R5983[111] = (char *(*)()) F957_7870;
	R5983[112] = (char *(*)()) F958_7870;
	R5983[113] = (char *(*)()) F959_7870;
	R5983[114] = (char *(*)()) F960_7870;
	R5983[115] = (char *(*)()) F961_7870;
	R5983[116] = (char *(*)()) F950_7870;
	R5983[118] = (char *(*)()) F950_7870;
	R5983[120] = (char *(*)()) F950_7870;
	R5983[121] = (char *(*)()) F953_7870;
	R5983[122] = (char *(*)()) F954_7870;
	R5983[123] = (char *(*)()) F950_7870;
	{long i; for (i = 125; i < 127; i++) R5983[i] = (char *(*)()) F950_7870;}
	{long i; for (i = 127; i < 129; i++) R5983[i] = (char *(*)()) F953_7870;}
	R5983[194] = (char *(*)()) F1040_9200;
	{long i; for (i = 249; i < 251; i++) R5983[i] = (char *(*)()) F1091_9541;}
	{long i; for (i = 252; i < 254; i++) R5983[i] = (char *(*)()) F1091_9541;}
	R5983[305] = (char *(*)()) F1151_10579;
	R5983[306] = (char *(*)()) F1152_10579;
	R5983[307] = (char *(*)()) F1153_10579;
	R5983[308] = (char *(*)()) F1154_10579;
	R5983[309] = (char *(*)()) F1155_10579;
	R5983[310] = (char *(*)()) F1156_10579;
	R5983[311] = (char *(*)()) F1157_10579;
	R5983[312] = (char *(*)()) F1158_10579;
	R5983[313] = (char *(*)()) F1159_10579;
	R5983[314] = (char *(*)()) F1160_10579;
	R5983[315] = (char *(*)()) F1161_10579;
	R5983[316] = (char *(*)()) F1162_10579;
	{long i; for (i = 593; i < 603; i++) R5983[i] = (char *(*)()) F950_7870;}
	R5983[705] = (char *(*)()) F1091_9541;
}

char *(*R5984[14])();
void R5984_init () {
	R5984[0] = (char *(*)()) F846_7434;
	R5984[1] = (char *(*)()) F847_7434;
	R5984[2] = (char *(*)()) F848_7434;
	R5984[3] = (char *(*)()) F849_7434;
	R5984[4] = (char *(*)()) F850_7434;
	R5984[5] = (char *(*)()) F851_7434;
	R5984[6] = (char *(*)()) F852_7434;
	R5984[7] = (char *(*)()) F853_7434;
	{long i; for (i = 8; i < 10; i++) R5984[i] = (char *(*)()) F846_7434;}
	R5984[10] = (char *(*)()) F848_7434;
	R5984[11] = (char *(*)()) F852_7434;
	R5984[12] = (char *(*)()) F849_7434;
	R5984[13] = (char *(*)()) F853_7434;
}

char *(*R5985[14])();
void R5985_init () {
	R5985[0] = (char *(*)()) F846_7435;
	R5985[1] = (char *(*)()) F847_7435;
	R5985[2] = (char *(*)()) F848_7435;
	R5985[3] = (char *(*)()) F849_7435;
	R5985[4] = (char *(*)()) F850_7435;
	R5985[5] = (char *(*)()) F851_7435;
	R5985[6] = (char *(*)()) F852_7435;
	R5985[7] = (char *(*)()) F853_7435;
	{long i; for (i = 8; i < 10; i++) R5985[i] = (char *(*)()) F846_7435;}
	R5985[10] = (char *(*)()) F848_7435;
	R5985[11] = (char *(*)()) F852_7435;
	R5985[12] = (char *(*)()) F849_7435;
	R5985[13] = (char *(*)()) F853_7435;
}

char *(*R5987[14])();
void R5987_init () {
	R5987[0] = (char *(*)()) F846_7437;
	R5987[1] = (char *(*)()) F847_7437;
	R5987[2] = (char *(*)()) F848_7437;
	R5987[3] = (char *(*)()) F849_7437;
	R5987[4] = (char *(*)()) F850_7437;
	R5987[5] = (char *(*)()) F851_7437;
	R5987[6] = (char *(*)()) F852_7437;
	R5987[7] = (char *(*)()) F853_7437;
	{long i; for (i = 8; i < 10; i++) R5987[i] = (char *(*)()) F846_7437;}
	R5987[10] = (char *(*)()) F848_7437;
	R5987[11] = (char *(*)()) F852_7437;
	R5987[12] = (char *(*)()) F849_7437;
	R5987[13] = (char *(*)()) F853_7437;
}

char *(*R5988[14])();
void R5988_init () {
	R5988[0] = (char *(*)()) F846_7438;
	R5988[1] = (char *(*)()) F847_7438;
	R5988[2] = (char *(*)()) F848_7438_5988_1;
	R5988[3] = (char *(*)()) F849_7438_5988_1;
	R5988[4] = (char *(*)()) F850_7438_5988_1;
	R5988[5] = (char *(*)()) F851_7438_5988_1;
	R5988[6] = (char *(*)()) F852_7438_5988_1;
	R5988[7] = (char *(*)()) F853_7438_5988_1;
	{long i; for (i = 8; i < 10; i++) R5988[i] = (char *(*)()) F846_7438;}
	R5988[10] = (char *(*)()) F848_7438_5988_1;
	R5988[11] = (char *(*)()) F852_7438_5988_1;
	R5988[12] = (char *(*)()) F849_7438_5988_1;
	R5988[13] = (char *(*)()) F853_7438_5988_1;
}
static EIF_REFERENCE F848_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F848_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F849_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F850_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F852_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_7438_5988_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F853_7438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5989_pgtype0[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype1[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype2[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype3[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype4[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype5[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype6[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype7[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype8[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype9[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype10[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype11[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5989_pgtype12[] = {0xFF02,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5989_gen_type [14];
EIF_TYPE_INDEX Y5989 [14];
void Y5989_init (void)
{
	egc_routines_types [5989] = Y5989;
	egc_routines_gen_types [5989] = Y5989_gen_type;
	egc_routines_offset [5989] = 845;
	Y5989_gen_type [0] = Y5989_pgtype0;
	Y5989_gen_type [1] = Y5989_pgtype1;
	Y5989_gen_type [2] = Y5989_pgtype2;
	Y5989_gen_type [3] = Y5989_pgtype3;
	Y5989_gen_type [4] = Y5989_pgtype4;
	Y5989_gen_type [5] = Y5989_pgtype5;
	Y5989_gen_type [6] = Y5989_pgtype6;
	Y5989_gen_type [7] = Y5989_pgtype7;
	Y5989_gen_type [9] = Y5989_pgtype8;
	Y5989_gen_type [10] = Y5989_pgtype9;
	Y5989_gen_type [11] = Y5989_pgtype10;
	Y5989_gen_type [12] = Y5989_pgtype11;
	Y5989_gen_type [13] = Y5989_pgtype12;
	Y5989[8] = 0;
}

char *(*R5993[14])();
void R5993_init () {
	R5993[0] = (char *(*)()) F846_7446;
	R5993[1] = (char *(*)()) F847_7446;
	R5993[2] = (char *(*)()) F848_7446_5993_1;
	R5993[3] = (char *(*)()) F849_7446_5993_1;
	R5993[4] = (char *(*)()) F850_7446_5993_1;
	R5993[5] = (char *(*)()) F851_7446_5993_1;
	R5993[6] = (char *(*)()) F852_7446_5993_1;
	R5993[7] = (char *(*)()) F853_7446_5993_1;
	{long i; for (i = 8; i < 10; i++) R5993[i] = (char *(*)()) F846_7446;}
	R5993[10] = (char *(*)()) F848_7446_5993_1;
	R5993[11] = (char *(*)()) F852_7446_5993_1;
	R5993[12] = (char *(*)()) F849_7446_5993_1;
	R5993[13] = (char *(*)()) F853_7446_5993_1;
}
static EIF_REFERENCE F848_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F848_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F849_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F850_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F852_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_7446_5993_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F853_7446(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5993_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5993_pgtype12[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5993_gen_type [14];
EIF_TYPE_INDEX Y5993 [14];
void Y5993_init (void)
{
	egc_routines_types [5993] = Y5993;
	egc_routines_gen_types [5993] = Y5993_gen_type;
	egc_routines_offset [5993] = 845;
	Y5993_gen_type [0] = Y5993_pgtype0;
	Y5993_gen_type [1] = Y5993_pgtype1;
	Y5993_gen_type [2] = Y5993_pgtype2;
	Y5993_gen_type [3] = Y5993_pgtype3;
	Y5993_gen_type [4] = Y5993_pgtype4;
	Y5993_gen_type [5] = Y5993_pgtype5;
	Y5993_gen_type [6] = Y5993_pgtype6;
	Y5993_gen_type [7] = Y5993_pgtype7;
	Y5993_gen_type [9] = Y5993_pgtype8;
	Y5993_gen_type [10] = Y5993_pgtype9;
	Y5993_gen_type [11] = Y5993_pgtype10;
	Y5993_gen_type [12] = Y5993_pgtype11;
	Y5993_gen_type [13] = Y5993_pgtype12;
	Y5993[8] = 0;
}

char *(*R5994[14])();
void R5994_init () {
	R5994[0] = (char *(*)()) F846_7447;
	R5994[1] = (char *(*)()) F847_7447_5994_1;
	R5994[2] = (char *(*)()) F848_7447;
	R5994[3] = (char *(*)()) F849_7447;
	R5994[4] = (char *(*)()) F850_7447;
	R5994[5] = (char *(*)()) F851_7447_5994_1;
	R5994[6] = (char *(*)()) F852_7447;
	R5994[7] = (char *(*)()) F853_7447;
	{long i; for (i = 8; i < 10; i++) R5994[i] = (char *(*)()) F846_7447;}
	R5994[10] = (char *(*)()) F848_7447;
	R5994[11] = (char *(*)()) F852_7447;
	R5994[12] = (char *(*)()) F849_7447;
	R5994[13] = (char *(*)()) F853_7447;
}
static EIF_REFERENCE F847_7447_5994_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F847_7447(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7447_5994_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7447(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5996[14])();
void R5996_init () {
	R5996[0] = (char *(*)()) F846_7451;
	R5996[1] = (char *(*)()) F847_7451_5996_38;
	R5996[2] = (char *(*)()) F848_7451;
	R5996[3] = (char *(*)()) F849_7451;
	R5996[4] = (char *(*)()) F850_7451;
	R5996[5] = (char *(*)()) F851_7451_5996_38;
	R5996[6] = (char *(*)()) F852_7451;
	R5996[7] = (char *(*)()) F853_7451;
	R5996[8] = (char *(*)()) F846_7451;
	R5996[9] = (char *(*)()) F855_7560;
	R5996[10] = (char *(*)()) F856_7560;
	R5996[11] = (char *(*)()) F857_7560;
	R5996[12] = (char *(*)()) F858_7560;
	R5996[13] = (char *(*)()) F859_7560;
}
static EIF_INTEGER_32 F847_7451_5996_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F847_7451(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F851_7451_5996_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F851_7451(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5998[14])();
void R5998_init () {
	R5998[0] = (char *(*)()) F846_7458;
	R5998[1] = (char *(*)()) F847_7458_5998_3;
	R5998[2] = (char *(*)()) F848_7458;
	R5998[3] = (char *(*)()) F849_7458;
	R5998[4] = (char *(*)()) F850_7458;
	R5998[5] = (char *(*)()) F851_7458_5998_3;
	R5998[6] = (char *(*)()) F852_7458;
	R5998[7] = (char *(*)()) F853_7458;
	R5998[8] = (char *(*)()) F846_7458;
	R5998[9] = (char *(*)()) F855_7562;
	R5998[10] = (char *(*)()) F856_7562;
	R5998[11] = (char *(*)()) F857_7562;
	R5998[12] = (char *(*)()) F858_7562;
	R5998[13] = (char *(*)()) F859_7562;
}
static EIF_BOOLEAN F847_7458_5998_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F847_7458(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F851_7458_5998_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F851_7458(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R6004[14])();
void R6004_init () {
	R6004[0] = (char *(*)()) F846_7466;
	R6004[1] = (char *(*)()) F847_7466;
	R6004[2] = (char *(*)()) F848_7466;
	R6004[3] = (char *(*)()) F849_7466;
	R6004[4] = (char *(*)()) F850_7466;
	R6004[5] = (char *(*)()) F851_7466;
	R6004[6] = (char *(*)()) F852_7466;
	R6004[7] = (char *(*)()) F853_7466;
	{long i; for (i = 8; i < 10; i++) R6004[i] = (char *(*)()) F846_7466;}
	R6004[10] = (char *(*)()) F848_7466;
	R6004[11] = (char *(*)()) F852_7466;
	R6004[12] = (char *(*)()) F849_7466;
	R6004[13] = (char *(*)()) F853_7466;
}

char *(*R6005[14])();
void R6005_init () {
	R6005[0] = (char *(*)()) F846_7467;
	R6005[1] = (char *(*)()) F847_7467;
	R6005[2] = (char *(*)()) F848_7467;
	R6005[3] = (char *(*)()) F849_7467;
	R6005[4] = (char *(*)()) F850_7467;
	R6005[5] = (char *(*)()) F851_7467;
	R6005[6] = (char *(*)()) F852_7467;
	R6005[7] = (char *(*)()) F853_7467;
	{long i; for (i = 8; i < 10; i++) R6005[i] = (char *(*)()) F846_7467;}
	R6005[10] = (char *(*)()) F848_7467;
	R6005[11] = (char *(*)()) F852_7467;
	R6005[12] = (char *(*)()) F849_7467;
	R6005[13] = (char *(*)()) F853_7467;
}

char *(*R6007[14])();
void R6007_init () {
	R6007[0] = (char *(*)()) F846_7469;
	R6007[1] = (char *(*)()) F847_7469;
	R6007[2] = (char *(*)()) F848_7469;
	R6007[3] = (char *(*)()) F849_7469;
	R6007[4] = (char *(*)()) F850_7469;
	R6007[5] = (char *(*)()) F851_7469;
	R6007[6] = (char *(*)()) F852_7469;
	R6007[7] = (char *(*)()) F853_7469;
	{long i; for (i = 8; i < 10; i++) R6007[i] = (char *(*)()) F846_7469;}
	R6007[10] = (char *(*)()) F848_7469;
	R6007[11] = (char *(*)()) F852_7469;
	R6007[12] = (char *(*)()) F849_7469;
	R6007[13] = (char *(*)()) F853_7469;
}

char *(*R6010[14])();
void R6010_init () {
	R6010[0] = (char *(*)()) F846_7473;
	R6010[1] = (char *(*)()) F847_7473;
	R6010[2] = (char *(*)()) F848_7473;
	R6010[3] = (char *(*)()) F849_7473;
	R6010[4] = (char *(*)()) F850_7473;
	R6010[5] = (char *(*)()) F851_7473;
	R6010[6] = (char *(*)()) F852_7473;
	R6010[7] = (char *(*)()) F853_7473;
	{long i; for (i = 8; i < 10; i++) R6010[i] = (char *(*)()) F846_7473;}
	R6010[10] = (char *(*)()) F848_7473;
	R6010[11] = (char *(*)()) F852_7473;
	R6010[12] = (char *(*)()) F849_7473;
	R6010[13] = (char *(*)()) F853_7473;
}

char *(*R6011[14])();
void R6011_init () {
	R6011[0] = (char *(*)()) F846_7474;
	R6011[1] = (char *(*)()) F847_7474;
	R6011[2] = (char *(*)()) F848_7474;
	R6011[3] = (char *(*)()) F849_7474;
	R6011[4] = (char *(*)()) F850_7474;
	R6011[5] = (char *(*)()) F851_7474;
	R6011[6] = (char *(*)()) F852_7474;
	R6011[7] = (char *(*)()) F853_7474;
	{long i; for (i = 8; i < 10; i++) R6011[i] = (char *(*)()) F846_7474;}
	R6011[10] = (char *(*)()) F848_7474;
	R6011[11] = (char *(*)()) F852_7474;
	R6011[12] = (char *(*)()) F849_7474;
	R6011[13] = (char *(*)()) F853_7474;
}

char *(*R6013[14])();
void R6013_init () {
	R6013[0] = (char *(*)()) F846_7476;
	R6013[1] = (char *(*)()) F847_7476_6013_4;
	R6013[2] = (char *(*)()) F848_7476;
	R6013[3] = (char *(*)()) F849_7476;
	R6013[4] = (char *(*)()) F850_7476;
	R6013[5] = (char *(*)()) F851_7476_6013_4;
	R6013[6] = (char *(*)()) F852_7476;
	R6013[7] = (char *(*)()) F853_7476;
	{long i; for (i = 8; i < 10; i++) R6013[i] = (char *(*)()) F846_7476;}
	R6013[10] = (char *(*)()) F848_7476;
	R6013[11] = (char *(*)()) F852_7476;
	R6013[12] = (char *(*)()) F849_7476;
	R6013[13] = (char *(*)()) F853_7476;
}
static void F847_7476_6013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_7476(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_7476_6013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_7476(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6015[14])();
void R6015_init () {
	R6015[0] = (char *(*)()) F846_7478;
	R6015[1] = (char *(*)()) F847_7478;
	R6015[2] = (char *(*)()) F848_7478;
	R6015[3] = (char *(*)()) F849_7478;
	R6015[4] = (char *(*)()) F850_7478;
	R6015[5] = (char *(*)()) F851_7478;
	R6015[6] = (char *(*)()) F852_7478;
	R6015[7] = (char *(*)()) F853_7478;
	{long i; for (i = 8; i < 10; i++) R6015[i] = (char *(*)()) F846_7478;}
	R6015[10] = (char *(*)()) F848_7478;
	R6015[11] = (char *(*)()) F852_7478;
	R6015[12] = (char *(*)()) F849_7478;
	R6015[13] = (char *(*)()) F853_7478;
}

char *(*R6016[14])();
void R6016_init () {
	R6016[0] = (char *(*)()) F846_7479;
	R6016[1] = (char *(*)()) F847_7479;
	R6016[2] = (char *(*)()) F848_7479;
	R6016[3] = (char *(*)()) F849_7479;
	R6016[4] = (char *(*)()) F850_7479;
	R6016[5] = (char *(*)()) F851_7479;
	R6016[6] = (char *(*)()) F852_7479;
	R6016[7] = (char *(*)()) F853_7479;
	{long i; for (i = 8; i < 10; i++) R6016[i] = (char *(*)()) F846_7479;}
	R6016[10] = (char *(*)()) F848_7479;
	R6016[11] = (char *(*)()) F852_7479;
	R6016[12] = (char *(*)()) F849_7479;
	R6016[13] = (char *(*)()) F853_7479;
}

char *(*R6022[14])();
void R6022_init () {
	R6022[0] = (char *(*)()) F846_7492;
	R6022[1] = (char *(*)()) F847_7492;
	R6022[2] = (char *(*)()) F848_7492;
	R6022[3] = (char *(*)()) F849_7492;
	R6022[4] = (char *(*)()) F850_7492;
	R6022[5] = (char *(*)()) F851_7492;
	R6022[6] = (char *(*)()) F852_7492;
	R6022[7] = (char *(*)()) F853_7492;
	R6022[8] = (char *(*)()) F846_7492;
	R6022[9] = (char *(*)()) F855_7564;
	R6022[10] = (char *(*)()) F856_7564;
	R6022[11] = (char *(*)()) F857_7564;
	R6022[12] = (char *(*)()) F858_7564;
	R6022[13] = (char *(*)()) F859_7564;
}

char *(*R6031[14])();
void R6031_init () {
	R6031[0] = (char *(*)()) F846_7502;
	R6031[1] = (char *(*)()) F847_7502;
	R6031[2] = (char *(*)()) F848_7502;
	R6031[3] = (char *(*)()) F849_7502;
	R6031[4] = (char *(*)()) F850_7502;
	R6031[5] = (char *(*)()) F851_7502;
	R6031[6] = (char *(*)()) F852_7502;
	R6031[7] = (char *(*)()) F853_7502;
	{long i; for (i = 8; i < 10; i++) R6031[i] = (char *(*)()) F846_7502;}
	R6031[10] = (char *(*)()) F848_7502;
	R6031[11] = (char *(*)()) F852_7502;
	R6031[12] = (char *(*)()) F849_7502;
	R6031[13] = (char *(*)()) F853_7502;
}

char *(*R6032[14])();
void R6032_init () {
	R6032[0] = (char *(*)()) F846_7503;
	R6032[1] = (char *(*)()) F847_7503;
	R6032[2] = (char *(*)()) F848_7503;
	R6032[3] = (char *(*)()) F849_7503;
	R6032[4] = (char *(*)()) F850_7503;
	R6032[5] = (char *(*)()) F851_7503;
	R6032[6] = (char *(*)()) F852_7503;
	R6032[7] = (char *(*)()) F853_7503;
	{long i; for (i = 8; i < 10; i++) R6032[i] = (char *(*)()) F846_7503;}
	R6032[10] = (char *(*)()) F848_7503;
	R6032[11] = (char *(*)()) F852_7503;
	R6032[12] = (char *(*)()) F849_7503;
	R6032[13] = (char *(*)()) F853_7503;
}

char *(*R6039[14])();
void R6039_init () {
	R6039[0] = (char *(*)()) F846_7510;
	R6039[1] = (char *(*)()) F847_7510;
	R6039[2] = (char *(*)()) F848_7510_6039_1;
	R6039[3] = (char *(*)()) F849_7510_6039_1;
	R6039[4] = (char *(*)()) F850_7510_6039_1;
	R6039[5] = (char *(*)()) F851_7510_6039_1;
	R6039[6] = (char *(*)()) F852_7510_6039_1;
	R6039[7] = (char *(*)()) F853_7510_6039_1;
	{long i; for (i = 8; i < 10; i++) R6039[i] = (char *(*)()) F846_7510;}
	R6039[10] = (char *(*)()) F848_7510_6039_1;
	R6039[11] = (char *(*)()) F852_7510_6039_1;
	R6039[12] = (char *(*)()) F849_7510_6039_1;
	R6039[13] = (char *(*)()) F853_7510_6039_1;
}
static EIF_REFERENCE F848_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F848_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F849_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F850_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F852_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_7510_6039_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F853_7510(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R6040[14])();
void R6040_init () {
	R6040[0] = (char *(*)()) F846_7511;
	R6040[1] = (char *(*)()) F847_7511_6040_1;
	R6040[2] = (char *(*)()) F848_7511;
	R6040[3] = (char *(*)()) F849_7511;
	R6040[4] = (char *(*)()) F850_7511;
	R6040[5] = (char *(*)()) F851_7511_6040_1;
	R6040[6] = (char *(*)()) F852_7511;
	R6040[7] = (char *(*)()) F853_7511;
	{long i; for (i = 8; i < 10; i++) R6040[i] = (char *(*)()) F846_7511;}
	R6040[10] = (char *(*)()) F848_7511;
	R6040[11] = (char *(*)()) F852_7511;
	R6040[12] = (char *(*)()) F849_7511;
	R6040[13] = (char *(*)()) F853_7511;
}
static EIF_REFERENCE F847_7511_6040_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F847_7511(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_7511_6040_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F851_7511(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6041[14])();
void R6041_init () {
	R6041[0] = (char *(*)()) F846_7512;
	R6041[1] = (char *(*)()) F847_7512;
	R6041[2] = (char *(*)()) F848_7512;
	R6041[3] = (char *(*)()) F849_7512;
	R6041[4] = (char *(*)()) F850_7512;
	R6041[5] = (char *(*)()) F851_7512;
	R6041[6] = (char *(*)()) F852_7512;
	R6041[7] = (char *(*)()) F853_7512;
	{long i; for (i = 8; i < 10; i++) R6041[i] = (char *(*)()) F846_7512;}
	R6041[10] = (char *(*)()) F848_7512;
	R6041[11] = (char *(*)()) F852_7512;
	R6041[12] = (char *(*)()) F849_7512;
	R6041[13] = (char *(*)()) F853_7512;
}

char *(*R6042[14])();
void R6042_init () {
	R6042[0] = (char *(*)()) F846_7513;
	R6042[1] = (char *(*)()) F847_7513;
	R6042[2] = (char *(*)()) F848_7513;
	R6042[3] = (char *(*)()) F849_7513;
	R6042[4] = (char *(*)()) F850_7513;
	R6042[5] = (char *(*)()) F851_7513;
	R6042[6] = (char *(*)()) F852_7513;
	R6042[7] = (char *(*)()) F853_7513;
	{long i; for (i = 8; i < 10; i++) R6042[i] = (char *(*)()) F846_7513;}
	R6042[10] = (char *(*)()) F848_7513;
	R6042[11] = (char *(*)()) F852_7513;
	R6042[12] = (char *(*)()) F849_7513;
	R6042[13] = (char *(*)()) F853_7513;
}

char *(*R6043[14])();
void R6043_init () {
	R6043[0] = (char *(*)()) F846_7514;
	R6043[1] = (char *(*)()) F847_7514;
	R6043[2] = (char *(*)()) F848_7514;
	R6043[3] = (char *(*)()) F849_7514;
	R6043[4] = (char *(*)()) F850_7514;
	R6043[5] = (char *(*)()) F851_7514;
	R6043[6] = (char *(*)()) F852_7514;
	R6043[7] = (char *(*)()) F853_7514;
	{long i; for (i = 8; i < 10; i++) R6043[i] = (char *(*)()) F846_7514;}
	R6043[10] = (char *(*)()) F848_7514;
	R6043[11] = (char *(*)()) F852_7514;
	R6043[12] = (char *(*)()) F849_7514;
	R6043[13] = (char *(*)()) F853_7514;
}

char *(*R6044[14])();
void R6044_init () {
	R6044[0] = (char *(*)()) F846_7515;
	R6044[1] = (char *(*)()) F847_7515;
	R6044[2] = (char *(*)()) F848_7515;
	R6044[3] = (char *(*)()) F849_7515;
	R6044[4] = (char *(*)()) F850_7515;
	R6044[5] = (char *(*)()) F851_7515;
	R6044[6] = (char *(*)()) F852_7515;
	R6044[7] = (char *(*)()) F853_7515;
	{long i; for (i = 8; i < 10; i++) R6044[i] = (char *(*)()) F846_7515;}
	R6044[10] = (char *(*)()) F848_7515;
	R6044[11] = (char *(*)()) F852_7515;
	R6044[12] = (char *(*)()) F849_7515;
	R6044[13] = (char *(*)()) F853_7515;
}

char *(*R6045[14])();
void R6045_init () {
	R6045[0] = (char *(*)()) F846_7516;
	R6045[1] = (char *(*)()) F847_7516;
	R6045[2] = (char *(*)()) F848_7516;
	R6045[3] = (char *(*)()) F849_7516;
	R6045[4] = (char *(*)()) F850_7516;
	R6045[5] = (char *(*)()) F851_7516;
	R6045[6] = (char *(*)()) F852_7516;
	R6045[7] = (char *(*)()) F853_7516;
	{long i; for (i = 8; i < 10; i++) R6045[i] = (char *(*)()) F846_7516;}
	R6045[10] = (char *(*)()) F848_7516;
	R6045[11] = (char *(*)()) F852_7516;
	R6045[12] = (char *(*)()) F849_7516;
	R6045[13] = (char *(*)()) F853_7516;
}

char *(*R6047[14])();
void R6047_init () {
	R6047[0] = (char *(*)()) F846_7518;
	R6047[1] = (char *(*)()) F847_7518;
	R6047[2] = (char *(*)()) F848_7518;
	R6047[3] = (char *(*)()) F849_7518;
	R6047[4] = (char *(*)()) F850_7518;
	R6047[5] = (char *(*)()) F851_7518;
	R6047[6] = (char *(*)()) F852_7518;
	R6047[7] = (char *(*)()) F853_7518;
	{long i; for (i = 8; i < 10; i++) R6047[i] = (char *(*)()) F846_7518;}
	R6047[10] = (char *(*)()) F848_7518;
	R6047[11] = (char *(*)()) F852_7518;
	R6047[12] = (char *(*)()) F849_7518;
	R6047[13] = (char *(*)()) F853_7518;
}

char *(*R6048[14])();
void R6048_init () {
	R6048[0] = (char *(*)()) F846_7519;
	R6048[1] = (char *(*)()) F847_7519;
	R6048[2] = (char *(*)()) F848_7519;
	R6048[3] = (char *(*)()) F849_7519;
	R6048[4] = (char *(*)()) F850_7519;
	R6048[5] = (char *(*)()) F851_7519;
	R6048[6] = (char *(*)()) F852_7519;
	R6048[7] = (char *(*)()) F853_7519;
	{long i; for (i = 8; i < 10; i++) R6048[i] = (char *(*)()) F846_7519;}
	R6048[10] = (char *(*)()) F848_7519;
	R6048[11] = (char *(*)()) F852_7519;
	R6048[12] = (char *(*)()) F849_7519;
	R6048[13] = (char *(*)()) F853_7519;
}

char *(*R6049[14])();
void R6049_init () {
	R6049[0] = (char *(*)()) F846_7520;
	R6049[1] = (char *(*)()) F847_7520;
	R6049[2] = (char *(*)()) F848_7520;
	R6049[3] = (char *(*)()) F849_7520;
	R6049[4] = (char *(*)()) F850_7520;
	R6049[5] = (char *(*)()) F851_7520;
	R6049[6] = (char *(*)()) F852_7520;
	R6049[7] = (char *(*)()) F853_7520;
	{long i; for (i = 8; i < 10; i++) R6049[i] = (char *(*)()) F846_7520;}
	R6049[10] = (char *(*)()) F848_7520;
	R6049[11] = (char *(*)()) F852_7520;
	R6049[12] = (char *(*)()) F849_7520;
	R6049[13] = (char *(*)()) F853_7520;
}

char *(*R6053[14])();
void R6053_init () {
	R6053[0] = (char *(*)()) F846_7524;
	R6053[1] = (char *(*)()) F847_7524_6053_4;
	R6053[2] = (char *(*)()) F848_7524;
	R6053[3] = (char *(*)()) F849_7524;
	R6053[4] = (char *(*)()) F850_7524;
	R6053[5] = (char *(*)()) F851_7524_6053_4;
	R6053[6] = (char *(*)()) F852_7524;
	R6053[7] = (char *(*)()) F853_7524;
	{long i; for (i = 8; i < 10; i++) R6053[i] = (char *(*)()) F846_7524;}
	R6053[10] = (char *(*)()) F848_7524;
	R6053[11] = (char *(*)()) F852_7524;
	R6053[12] = (char *(*)()) F849_7524;
	R6053[13] = (char *(*)()) F853_7524;
}
static void F847_7524_6053_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_7524(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_7524_6053_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_7524(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6054[14])();
void R6054_init () {
	R6054[0] = (char *(*)()) F846_7525;
	R6054[1] = (char *(*)()) F847_7525_6054_4;
	R6054[2] = (char *(*)()) F848_7525;
	R6054[3] = (char *(*)()) F849_7525;
	R6054[4] = (char *(*)()) F850_7525;
	R6054[5] = (char *(*)()) F851_7525_6054_4;
	R6054[6] = (char *(*)()) F852_7525;
	R6054[7] = (char *(*)()) F853_7525;
	{long i; for (i = 8; i < 10; i++) R6054[i] = (char *(*)()) F846_7525;}
	R6054[10] = (char *(*)()) F848_7525;
	R6054[11] = (char *(*)()) F852_7525;
	R6054[12] = (char *(*)()) F849_7525;
	R6054[13] = (char *(*)()) F853_7525;
}
static void F847_7525_6054_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_7525(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F851_7525_6054_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_7525(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6059[14])();
void R6059_init () {
	R6059[0] = (char *(*)()) F846_7530;
	R6059[1] = (char *(*)()) F847_7530;
	R6059[2] = (char *(*)()) F848_7530;
	R6059[3] = (char *(*)()) F849_7530;
	R6059[4] = (char *(*)()) F850_7530;
	R6059[5] = (char *(*)()) F851_7530;
	R6059[6] = (char *(*)()) F852_7530;
	R6059[7] = (char *(*)()) F853_7530;
	{long i; for (i = 8; i < 10; i++) R6059[i] = (char *(*)()) F846_7530;}
	R6059[10] = (char *(*)()) F848_7530;
	R6059[11] = (char *(*)()) F852_7530;
	R6059[12] = (char *(*)()) F849_7530;
	R6059[13] = (char *(*)()) F853_7530;
}

char *(*R6072[14])();
void R6072_init () {
	R6072[0] = (char *(*)()) F846_7543;
	R6072[1] = (char *(*)()) F847_7543;
	R6072[2] = (char *(*)()) F848_7543;
	R6072[3] = (char *(*)()) F849_7543;
	R6072[4] = (char *(*)()) F850_7543;
	R6072[5] = (char *(*)()) F851_7543;
	R6072[6] = (char *(*)()) F852_7543;
	R6072[7] = (char *(*)()) F853_7543;
	{long i; for (i = 8; i < 10; i++) R6072[i] = (char *(*)()) F846_7543;}
	R6072[10] = (char *(*)()) F848_7543;
	R6072[11] = (char *(*)()) F852_7543;
	R6072[12] = (char *(*)()) F849_7543;
	R6072[13] = (char *(*)()) F853_7543;
}

char *(*R6085[5])();
void R6085_init () {
	R6085[0] = (char *(*)()) F855_7558;
	R6085[1] = (char *(*)()) F856_7558;
	R6085[2] = (char *(*)()) F857_7558;
	R6085[3] = (char *(*)()) F858_7558;
	R6085[4] = (char *(*)()) F859_7558;
}

char *(*R6107[12])();
void R6107_init () {
	R6107[0] = (char *(*)()) F873_7604;
	R6107[1] = (char *(*)()) F874_7604;
	R6107[2] = (char *(*)()) F875_7604;
	R6107[3] = (char *(*)()) F876_7604;
	R6107[4] = (char *(*)()) F877_7604;
	R6107[5] = (char *(*)()) F878_7604;
	R6107[6] = (char *(*)()) F879_7604;
	R6107[7] = (char *(*)()) F880_7604;
	R6107[8] = (char *(*)()) F881_7604;
	R6107[9] = (char *(*)()) F882_7604;
	R6107[10] = (char *(*)()) F883_7604;
	R6107[11] = (char *(*)()) F884_7604;
}

char *(*R6108[12])();
void R6108_init () {
	R6108[0] = (char *(*)()) F873_7605;
	R6108[1] = (char *(*)()) F874_7605_6108_57;
	R6108[2] = (char *(*)()) F875_7605_6108_57;
	R6108[3] = (char *(*)()) F876_7605_6108_57;
	R6108[4] = (char *(*)()) F877_7605_6108_57;
	R6108[5] = (char *(*)()) F878_7605_6108_57;
	R6108[6] = (char *(*)()) F879_7605_6108_57;
	R6108[7] = (char *(*)()) F880_7605_6108_57;
	R6108[8] = (char *(*)()) F881_7605_6108_57;
	R6108[9] = (char *(*)()) F882_7605_6108_57;
	R6108[10] = (char *(*)()) F883_7605_6108_57;
	R6108[11] = (char *(*)()) F884_7605_6108_57;
}
static void F874_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F874_7605(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F875_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F875_7605(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F876_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F876_7605(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F877_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F877_7605(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F878_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F878_7605(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F879_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F879_7605(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F880_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F880_7605(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F881_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F881_7605(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F882_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F882_7605(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F883_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F883_7605(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F884_7605_6108_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F884_7605(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}

char *(*R6111[12])();
void R6111_init () {
	R6111[0] = (char *(*)()) F873_7608;
	R6111[1] = (char *(*)()) F874_7608;
	R6111[2] = (char *(*)()) F875_7608;
	R6111[3] = (char *(*)()) F876_7608;
	R6111[4] = (char *(*)()) F877_7608;
	R6111[5] = (char *(*)()) F878_7608;
	R6111[6] = (char *(*)()) F879_7608;
	R6111[7] = (char *(*)()) F880_7608;
	R6111[8] = (char *(*)()) F881_7608;
	R6111[9] = (char *(*)()) F882_7608;
	R6111[10] = (char *(*)()) F883_7608;
	R6111[11] = (char *(*)()) F884_7608;
}

char *(*R6121[12])();
void R6121_init () {
	R6121[0] = (char *(*)()) F873_7634;
	R6121[1] = (char *(*)()) F874_7634;
	R6121[2] = (char *(*)()) F875_7634;
	R6121[3] = (char *(*)()) F876_7634;
	R6121[4] = (char *(*)()) F877_7634;
	R6121[5] = (char *(*)()) F878_7634;
	R6121[6] = (char *(*)()) F879_7634;
	R6121[7] = (char *(*)()) F880_7634;
	R6121[8] = (char *(*)()) F881_7634;
	R6121[9] = (char *(*)()) F882_7634;
	R6121[10] = (char *(*)()) F883_7634;
	R6121[11] = (char *(*)()) F884_7634;
}

char *(*R6135[12])();
void R6135_init () {
	R6135[0] = (char *(*)()) F873_7650;
	R6135[1] = (char *(*)()) F874_7650_6135_57;
	R6135[2] = (char *(*)()) F875_7650_6135_57;
	R6135[3] = (char *(*)()) F876_7650_6135_57;
	R6135[4] = (char *(*)()) F877_7650_6135_57;
	R6135[5] = (char *(*)()) F878_7650_6135_57;
	R6135[6] = (char *(*)()) F879_7650_6135_57;
	R6135[7] = (char *(*)()) F880_7650_6135_57;
	R6135[8] = (char *(*)()) F881_7650_6135_57;
	R6135[9] = (char *(*)()) F882_7650_6135_57;
	R6135[10] = (char *(*)()) F883_7650_6135_57;
	R6135[11] = (char *(*)()) F884_7650_6135_57;
}
static void F874_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F874_7650(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F875_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F875_7650(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F876_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F876_7650(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F877_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F877_7650(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F878_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F878_7650(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F879_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F879_7650(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F880_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F880_7650(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F881_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F881_7650(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F882_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F882_7650(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F883_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F883_7650(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F884_7650_6135_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F884_7650(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}

char *(*R6142[12])();
void R6142_init () {
	R6142[0] = (char *(*)()) F873_7662;
	R6142[1] = (char *(*)()) F874_7662;
	R6142[2] = (char *(*)()) F875_7662;
	R6142[3] = (char *(*)()) F876_7662;
	R6142[4] = (char *(*)()) F877_7662;
	R6142[5] = (char *(*)()) F878_7662;
	R6142[6] = (char *(*)()) F879_7662;
	R6142[7] = (char *(*)()) F880_7662;
	R6142[8] = (char *(*)()) F881_7662;
	R6142[9] = (char *(*)()) F882_7662;
	R6142[10] = (char *(*)()) F883_7662;
	R6142[11] = (char *(*)()) F884_7662;
}

char *(*R6147[509])();
void R6147_init () {
	R6147[0] = (char *(*)()) F940_7727;
	R6147[1] = (char *(*)()) F941_7727_6147_1;
	R6147[2] = (char *(*)()) F942_7727_6147_1;
	{long i; for (i = 3; i < 6; i++) R6147[i] = (char *(*)()) F940_7727;}
	R6147[6] = (char *(*)()) F942_7727_6147_1;
	R6147[7] = (char *(*)()) F941_7727_6147_1;
	R6147[9] = (char *(*)()) F940_7727;
	R6147[10] = (char *(*)()) F950_7852;
	R6147[11] = (char *(*)()) F951_7852_6147_1;
	R6147[12] = (char *(*)()) F952_7852_6147_1;
	R6147[13] = (char *(*)()) F953_7852_6147_1;
	R6147[14] = (char *(*)()) F954_7852_6147_1;
	R6147[15] = (char *(*)()) F955_7852_6147_1;
	R6147[16] = (char *(*)()) F956_7852_6147_1;
	R6147[17] = (char *(*)()) F957_7852_6147_1;
	R6147[18] = (char *(*)()) F958_7852_6147_1;
	R6147[19] = (char *(*)()) F959_7852_6147_1;
	R6147[20] = (char *(*)()) F960_7852_6147_1;
	R6147[21] = (char *(*)()) F961_7852_6147_1;
	R6147[22] = (char *(*)()) F950_7852;
	R6147[24] = (char *(*)()) F950_7852;
	R6147[26] = (char *(*)()) F950_7852;
	R6147[27] = (char *(*)()) F953_7852_6147_1;
	R6147[28] = (char *(*)()) F954_7852_6147_1;
	R6147[29] = (char *(*)()) F950_7852;
	{long i; for (i = 31; i < 33; i++) R6147[i] = (char *(*)()) F950_7852;}
	{long i; for (i = 33; i < 35; i++) R6147[i] = (char *(*)()) F953_7852_6147_1;}
	{long i; for (i = 499; i < 509; i++) R6147[i] = (char *(*)()) F950_7852;}
}
static EIF_REFERENCE F941_7727_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_7727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_7727_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7727(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F951_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F952_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1247, 0x00).id, 1247, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F953_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F954_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F955_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F956_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F957_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F958_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F959_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F960_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7852_6147_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F961_7852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}

char *(*R6148[10])();
void R6148_init () {
	R6148[0] = (char *(*)()) F940_7746;
	R6148[1] = (char *(*)()) F941_7746;
	R6148[2] = (char *(*)()) F942_7746;
	{long i; for (i = 3; i < 6; i++) R6148[i] = (char *(*)()) F940_7746;}
	R6148[6] = (char *(*)()) F942_7746;
	R6148[7] = (char *(*)()) F941_7746;
	R6148[9] = (char *(*)()) F948_7821;
}

char *(*R6149[509])();
void R6149_init () {
	R6149[0] = (char *(*)()) F940_7747;
	R6149[1] = (char *(*)()) F941_7747;
	R6149[2] = (char *(*)()) F942_7747;
	{long i; for (i = 3; i < 6; i++) R6149[i] = (char *(*)()) F940_7747;}
	R6149[6] = (char *(*)()) F942_7747;
	R6149[7] = (char *(*)()) F941_7747;
	R6149[9] = (char *(*)()) F940_7747;
	R6149[10] = (char *(*)()) F950_7878;
	R6149[11] = (char *(*)()) F951_7878;
	R6149[12] = (char *(*)()) F952_7878;
	R6149[13] = (char *(*)()) F953_7878;
	R6149[14] = (char *(*)()) F954_7878;
	R6149[15] = (char *(*)()) F955_7878;
	R6149[16] = (char *(*)()) F956_7878;
	R6149[17] = (char *(*)()) F957_7878;
	R6149[18] = (char *(*)()) F958_7878;
	R6149[19] = (char *(*)()) F959_7878;
	R6149[20] = (char *(*)()) F960_7878;
	R6149[21] = (char *(*)()) F961_7878;
	R6149[22] = (char *(*)()) F950_7878;
	R6149[24] = (char *(*)()) F950_7878;
	R6149[26] = (char *(*)()) F950_7878;
	R6149[27] = (char *(*)()) F953_7878;
	R6149[28] = (char *(*)()) F954_7878;
	R6149[29] = (char *(*)()) F950_7878;
	{long i; for (i = 31; i < 33; i++) R6149[i] = (char *(*)()) F950_7878;}
	{long i; for (i = 33; i < 35; i++) R6149[i] = (char *(*)()) F953_7878;}
	{long i; for (i = 499; i < 509; i++) R6149[i] = (char *(*)()) F950_7878;}
}

char *(*R6150[509])();
void R6150_init () {
	R6150[0] = (char *(*)()) F940_7737;
	R6150[1] = (char *(*)()) F941_7737;
	R6150[2] = (char *(*)()) F942_7737;
	{long i; for (i = 3; i < 6; i++) R6150[i] = (char *(*)()) F940_7737;}
	R6150[6] = (char *(*)()) F942_7737;
	R6150[7] = (char *(*)()) F941_7737;
	R6150[9] = (char *(*)()) F940_7737;
	R6150[10] = (char *(*)()) F890_7677;
	R6150[11] = (char *(*)()) F891_7677;
	R6150[12] = (char *(*)()) F892_7677;
	R6150[13] = (char *(*)()) F893_7677;
	R6150[14] = (char *(*)()) F894_7677;
	R6150[15] = (char *(*)()) F895_7677;
	R6150[16] = (char *(*)()) F896_7677;
	R6150[17] = (char *(*)()) F897_7677;
	R6150[18] = (char *(*)()) F898_7677;
	R6150[19] = (char *(*)()) F899_7677;
	R6150[20] = (char *(*)()) F900_7677;
	R6150[21] = (char *(*)()) F901_7677;
	R6150[22] = (char *(*)()) F890_7677;
	R6150[24] = (char *(*)()) F890_7677;
	R6150[26] = (char *(*)()) F890_7677;
	R6150[27] = (char *(*)()) F893_7677;
	R6150[28] = (char *(*)()) F894_7677;
	R6150[29] = (char *(*)()) F890_7677;
	{long i; for (i = 31; i < 33; i++) R6150[i] = (char *(*)()) F890_7677;}
	{long i; for (i = 33; i < 35; i++) R6150[i] = (char *(*)()) F893_7677;}
	{long i; for (i = 499; i < 509; i++) R6150[i] = (char *(*)()) F890_7677;}
}

char *(*R6151[509])();
void R6151_init () {
	R6151[0] = (char *(*)()) F940_7738;
	R6151[1] = (char *(*)()) F941_7738;
	R6151[2] = (char *(*)()) F942_7738;
	{long i; for (i = 3; i < 6; i++) R6151[i] = (char *(*)()) F940_7738;}
	R6151[6] = (char *(*)()) F942_7738;
	R6151[7] = (char *(*)()) F941_7738;
	R6151[9] = (char *(*)()) F948_7817;
	R6151[10] = (char *(*)()) F890_7678;
	R6151[11] = (char *(*)()) F891_7678;
	R6151[12] = (char *(*)()) F892_7678;
	R6151[13] = (char *(*)()) F893_7678;
	R6151[14] = (char *(*)()) F894_7678;
	R6151[15] = (char *(*)()) F895_7678;
	R6151[16] = (char *(*)()) F896_7678;
	R6151[17] = (char *(*)()) F897_7678;
	R6151[18] = (char *(*)()) F898_7678;
	R6151[19] = (char *(*)()) F899_7678;
	R6151[20] = (char *(*)()) F900_7678;
	R6151[21] = (char *(*)()) F901_7678;
	R6151[22] = (char *(*)()) F890_7678;
	R6151[24] = (char *(*)()) F890_7678;
	R6151[26] = (char *(*)()) F890_7678;
	R6151[27] = (char *(*)()) F893_7678;
	R6151[28] = (char *(*)()) F894_7678;
	R6151[29] = (char *(*)()) F890_7678;
	{long i; for (i = 31; i < 33; i++) R6151[i] = (char *(*)()) F890_7678;}
	{long i; for (i = 33; i < 35; i++) R6151[i] = (char *(*)()) F893_7678;}
	{long i; for (i = 499; i < 509; i++) R6151[i] = (char *(*)()) F890_7678;}
}

char *(*R6156[509])();
void R6156_init () {
	R6156[0] = (char *(*)()) F940_7749;
	R6156[1] = (char *(*)()) F941_7749_6156_4;
	R6156[2] = (char *(*)()) F942_7749_6156_4;
	{long i; for (i = 3; i < 6; i++) R6156[i] = (char *(*)()) F940_7749;}
	R6156[6] = (char *(*)()) F942_7749_6156_4;
	R6156[7] = (char *(*)()) F941_7749_6156_4;
	R6156[9] = (char *(*)()) F948_7822;
	R6156[10] = (char *(*)()) F950_7881;
	R6156[11] = (char *(*)()) F951_7881_6156_4;
	R6156[12] = (char *(*)()) F952_7881_6156_4;
	R6156[13] = (char *(*)()) F953_7881_6156_4;
	R6156[14] = (char *(*)()) F954_7881_6156_4;
	R6156[15] = (char *(*)()) F955_7881_6156_4;
	R6156[16] = (char *(*)()) F956_7881_6156_4;
	R6156[17] = (char *(*)()) F957_7881_6156_4;
	R6156[18] = (char *(*)()) F958_7881_6156_4;
	R6156[19] = (char *(*)()) F959_7881_6156_4;
	R6156[20] = (char *(*)()) F960_7881_6156_4;
	R6156[21] = (char *(*)()) F961_7881_6156_4;
	R6156[22] = (char *(*)()) F950_7881;
	R6156[24] = (char *(*)()) F950_7881;
	R6156[26] = (char *(*)()) F950_7881;
	R6156[27] = (char *(*)()) F953_7881_6156_4;
	R6156[28] = (char *(*)()) F954_7881_6156_4;
	R6156[29] = (char *(*)()) F950_7881;
	R6156[32] = (char *(*)()) F950_7881;
	{long i; for (i = 33; i < 35; i++) R6156[i] = (char *(*)()) F953_7881_6156_4;}
	{long i; for (i = 499; i < 509; i++) R6156[i] = (char *(*)()) F950_7881;}
}
static void F941_7749_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F941_7749(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F942_7749_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F942_7749(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7881(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F952_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7881(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F953_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7881(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7881(Current, *(EIF_BOOLEAN *)arg1);
}
static void F955_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7881(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F956_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7881(Current, *(EIF_POINTER *)arg1);
}
static void F957_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7881(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F958_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7881(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F959_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7881(Current, *(EIF_REAL_64 *)arg1);
}
static void F960_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7881(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F961_7881_6156_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F961_7881(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R6162[10])();
void R6162_init () {
	R6162[0] = (char *(*)()) F940_7758;
	R6162[1] = (char *(*)()) F941_7758;
	R6162[2] = (char *(*)()) F942_7758;
	{long i; for (i = 3; i < 6; i++) R6162[i] = (char *(*)()) F940_7758;}
	R6162[6] = (char *(*)()) F942_7758;
	R6162[7] = (char *(*)()) F941_7758;
	R6162[9] = (char *(*)()) F948_7830;
}

char *(*R6174[10])();
void R6174_init () {
	R6174[0] = (char *(*)()) F940_7762;
	R6174[1] = (char *(*)()) F941_7762_6174_5;
	R6174[2] = (char *(*)()) F942_7762_6174_5;
	{long i; for (i = 3; i < 6; i++) R6174[i] = (char *(*)()) F940_7762;}
	R6174[6] = (char *(*)()) F942_7762_6174_5;
	R6174[7] = (char *(*)()) F941_7762_6174_5;
	R6174[9] = (char *(*)()) F948_7836;
}
static EIF_REFERENCE F941_7762_6174_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F941_7762(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F942_7762_6174_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F942_7762(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R6175[10])();
void R6175_init () {
	R6175[0] = (char *(*)()) F940_7763;
	R6175[1] = (char *(*)()) F941_7763;
	R6175[2] = (char *(*)()) F942_7763;
	{long i; for (i = 3; i < 6; i++) R6175[i] = (char *(*)()) F940_7763;}
	R6175[6] = (char *(*)()) F942_7763;
	R6175[7] = (char *(*)()) F941_7763;
	R6175[9] = (char *(*)()) F948_7837;
}

char *(*R6178[10])();
void R6178_init () {
	R6178[0] = (char *(*)()) F940_7766;
	R6178[1] = (char *(*)()) F941_7766;
	R6178[2] = (char *(*)()) F942_7766;
	{long i; for (i = 3; i < 6; i++) R6178[i] = (char *(*)()) F940_7766;}
	R6178[6] = (char *(*)()) F942_7766;
	R6178[7] = (char *(*)()) F941_7766;
	R6178[9] = (char *(*)()) F948_7813;
}

char *(*R6179[10])();
void R6179_init () {
	R6179[0] = (char *(*)()) F940_7767;
	R6179[1] = (char *(*)()) F941_7767;
	R6179[2] = (char *(*)()) F942_7767;
	{long i; for (i = 3; i < 6; i++) R6179[i] = (char *(*)()) F940_7767;}
	R6179[6] = (char *(*)()) F942_7767;
	R6179[7] = (char *(*)()) F941_7767;
	R6179[9] = (char *(*)()) F940_7767;
}

char *(*R6180[10])();
void R6180_init () {
	R6180[0] = (char *(*)()) F940_7768;
	R6180[1] = (char *(*)()) F941_7768;
	R6180[2] = (char *(*)()) F942_7768;
	{long i; for (i = 3; i < 6; i++) R6180[i] = (char *(*)()) F940_7768;}
	R6180[6] = (char *(*)()) F942_7768;
	R6180[7] = (char *(*)()) F941_7768;
	R6180[9] = (char *(*)()) F940_7768;
}

char *(*R6193[3])();
void R6193_init () {
	R6193[0] = (char *(*)()) F940_7725;
	R6193[1] = (char *(*)()) F942_7725_6193_1;
	R6193[2] = (char *(*)()) F941_7725_6193_1;
}
static EIF_REFERENCE F942_7725_6193_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1042, 0x00).id, 1042, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_7725_6193_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_7725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6194[3])();
void R6194_init () {
	R6194[0] = (char *(*)()) F940_7756;
	R6194[1] = (char *(*)()) F942_7756;
	R6194[2] = (char *(*)()) F941_7756;
}

char *(*R6201[499])();
void R6201_init () {
	R6201[0] = (char *(*)()) F950_7843;
	R6201[1] = (char *(*)()) F951_7843;
	R6201[2] = (char *(*)()) F952_7843;
	R6201[3] = (char *(*)()) F953_7843;
	R6201[4] = (char *(*)()) F954_7843;
	R6201[5] = (char *(*)()) F955_7843;
	R6201[6] = (char *(*)()) F956_7843;
	R6201[7] = (char *(*)()) F957_7843;
	R6201[8] = (char *(*)()) F958_7843;
	R6201[9] = (char *(*)()) F959_7843;
	R6201[10] = (char *(*)()) F960_7843;
	R6201[11] = (char *(*)()) F961_7843;
	R6201[12] = (char *(*)()) F962_7909;
	R6201[14] = (char *(*)()) F950_7843;
	R6201[16] = (char *(*)()) F950_7843;
	R6201[17] = (char *(*)()) F953_7843;
	R6201[18] = (char *(*)()) F954_7843;
	R6201[19] = (char *(*)()) F969_7941;
	R6201[21] = (char *(*)()) F950_7843;
	R6201[22] = (char *(*)()) F972_8009;
	{long i; for (i = 23; i < 25; i++) R6201[i] = (char *(*)()) F973_8009;}
	{long i; for (i = 489; i < 499; i++) R6201[i] = (char *(*)()) F1439_17237;}
}

char *(*R6205[499])();
void R6205_init () {
	R6205[0] = (char *(*)()) F950_7847;
	R6205[1] = (char *(*)()) F951_7847;
	R6205[2] = (char *(*)()) F952_7847;
	R6205[3] = (char *(*)()) F953_7847;
	R6205[4] = (char *(*)()) F954_7847;
	R6205[5] = (char *(*)()) F955_7847;
	R6205[6] = (char *(*)()) F956_7847;
	R6205[7] = (char *(*)()) F957_7847;
	R6205[8] = (char *(*)()) F958_7847;
	R6205[9] = (char *(*)()) F959_7847;
	R6205[10] = (char *(*)()) F960_7847;
	R6205[11] = (char *(*)()) F961_7847;
	R6205[12] = (char *(*)()) F950_7847;
	R6205[14] = (char *(*)()) F950_7847;
	R6205[16] = (char *(*)()) F950_7847;
	R6205[17] = (char *(*)()) F953_7847;
	R6205[18] = (char *(*)()) F954_7847;
	R6205[19] = (char *(*)()) F950_7847;
	{long i; for (i = 21; i < 23; i++) R6205[i] = (char *(*)()) F950_7847;}
	{long i; for (i = 23; i < 25; i++) R6205[i] = (char *(*)()) F953_7847;}
	{long i; for (i = 489; i < 499; i++) R6205[i] = (char *(*)()) F950_7847;}
}

char *(*R6209[499])();
void R6209_init () {
	R6209[0] = (char *(*)()) F950_7866;
	R6209[1] = (char *(*)()) F951_7866;
	R6209[2] = (char *(*)()) F952_7866;
	R6209[3] = (char *(*)()) F953_7866;
	R6209[4] = (char *(*)()) F954_7866;
	R6209[5] = (char *(*)()) F955_7866;
	R6209[6] = (char *(*)()) F956_7866;
	R6209[7] = (char *(*)()) F957_7866;
	R6209[8] = (char *(*)()) F958_7866;
	R6209[9] = (char *(*)()) F959_7866;
	R6209[10] = (char *(*)()) F960_7866;
	R6209[11] = (char *(*)()) F961_7866;
	R6209[12] = (char *(*)()) F950_7866;
	R6209[14] = (char *(*)()) F950_7866;
	R6209[16] = (char *(*)()) F950_7866;
	R6209[17] = (char *(*)()) F953_7866;
	R6209[18] = (char *(*)()) F954_7866;
	R6209[19] = (char *(*)()) F950_7866;
	{long i; for (i = 21; i < 23; i++) R6209[i] = (char *(*)()) F950_7866;}
	{long i; for (i = 23; i < 25; i++) R6209[i] = (char *(*)()) F953_7866;}
	{long i; for (i = 489; i < 499; i++) R6209[i] = (char *(*)()) F950_7866;}
}

char *(*R6213[499])();
void R6213_init () {
	R6213[0] = (char *(*)()) F950_7907;
	R6213[1] = (char *(*)()) F951_7907_6213_156;
	R6213[2] = (char *(*)()) F952_7907_6213_156;
	R6213[3] = (char *(*)()) F953_7907_6213_156;
	R6213[4] = (char *(*)()) F954_7907_6213_156;
	R6213[5] = (char *(*)()) F955_7907_6213_156;
	R6213[6] = (char *(*)()) F956_7907_6213_156;
	R6213[7] = (char *(*)()) F957_7907_6213_156;
	R6213[8] = (char *(*)()) F958_7907_6213_156;
	R6213[9] = (char *(*)()) F959_7907_6213_156;
	R6213[10] = (char *(*)()) F960_7907_6213_156;
	R6213[11] = (char *(*)()) F961_7907_6213_156;
	R6213[12] = (char *(*)()) F950_7907;
	R6213[14] = (char *(*)()) F950_7907;
	R6213[16] = (char *(*)()) F950_7907;
	R6213[17] = (char *(*)()) F953_7907_6213_156;
	R6213[18] = (char *(*)()) F954_7907_6213_156;
	R6213[19] = (char *(*)()) F950_7907;
	{long i; for (i = 21; i < 23; i++) R6213[i] = (char *(*)()) F950_7907;}
	{long i; for (i = 23; i < 25; i++) R6213[i] = (char *(*)()) F953_7907_6213_156;}
	{long i; for (i = 489; i < 499; i++) R6213[i] = (char *(*)()) F950_7907;}
}
static void F951_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F951_7907(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F952_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F952_7907(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F953_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F953_7907(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F954_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F954_7907(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F955_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F955_7907(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F956_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F956_7907(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F957_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F957_7907(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F958_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F958_7907(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F959_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F959_7907(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F960_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F960_7907(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F961_7907_6213_156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F961_7907(Current, *(EIF_REAL_32 *)arg1, arg2);
}

char *(*R6226[3])();
void R6226_init () {
	R6226[0] = (char *(*)()) F950_7884;
	R6226[1] = (char *(*)()) F953_7884_6226_4;
	R6226[2] = (char *(*)()) F954_7884_6226_4;
}
static void F953_7884_6226_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7884(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7884_6226_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7884(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R6227[3])();
void R6227_init () {
	R6227[0] = (char *(*)()) F950_7897;
	R6227[1] = (char *(*)()) F953_7897;
	R6227[2] = (char *(*)()) F954_7897;
}

char *(*R6419[2])();
void R6419_init () {
	R6419[0] = (char *(*)()) F979_8159;
	R6419[1] = (char *(*)()) F980_8264;
}

char *(*R6425[2])();
void R6425_init () {
	R6425[0] = (char *(*)()) F979_8165;
	R6425[1] = (char *(*)()) F980_8265;
}

char *(*R6427[2])();
void R6427_init () {
	R6427[0] = (char *(*)()) F979_8167;
	R6427[1] = (char *(*)()) F980_8266;
}

char *(*R6520[2])();
void R6520_init () {
	R6520[0] = (char *(*)()) F979_8262;
	R6520[1] = (char *(*)()) F980_8291;
}

char *(*R6556[12])();
void R6556_init () {
	R6556[0] = (char *(*)()) F989_8325;
	R6556[1] = (char *(*)()) F990_8329;
	R6556[2] = (char *(*)()) F991_8334;
	R6556[3] = (char *(*)()) F992_8342;
	{long i; for (i = 4; i < 6; i++) R6556[i] = (char *(*)()) F993_8351;}
	R6556[6] = (char *(*)()) F995_8362;
	{long i; for (i = 7; i < 9; i++) R6556[i] = (char *(*)()) F993_8351;}
	R6556[11] = (char *(*)()) F993_8351;
}

char *(*R6687[264])();
void R6687_init () {
	{long i; for (i = 0; i < 2; i++) R6687[i] = (char *(*)()) F1006_8586;}
	R6687[263] = (char *(*)()) F1270_12024;
}

char *(*R6698[264])();
void R6698_init () {
	{long i; for (i = 0; i < 2; i++) R6698[i] = (char *(*)()) F1006_8665;}
	R6698[263] = (char *(*)()) F1270_12055;
}

char *(*R6699[264])();
void R6699_init () {
	{long i; for (i = 0; i < 2; i++) R6699[i] = (char *(*)()) F1006_8666;}
	R6699[263] = (char *(*)()) F1270_12056;
}

char *(*R6700[264])();
void R6700_init () {
	{long i; for (i = 0; i < 2; i++) R6700[i] = (char *(*)()) F1006_8660;}
	R6700[263] = (char *(*)()) F1270_12047;
}

char *(*R6702[264])();
void R6702_init () {
	{long i; for (i = 0; i < 2; i++) R6702[i] = (char *(*)()) F1006_8663;}
	R6702[263] = (char *(*)()) F1270_12045;
}

char *(*R6730[264])();
void R6730_init () {
	{long i; for (i = 0; i < 2; i++) R6730[i] = (char *(*)()) F1006_8693;}
	R6730[263] = (char *(*)()) F1270_12042;
}

char *(*R6732[264])();
void R6732_init () {
	R6732[0] = (char *(*)()) F1007_8800;
	R6732[1] = (char *(*)()) F1008_8858;
	R6732[263] = (char *(*)()) F1008_8858;
}

char *(*R6738[264])();
void R6738_init () {
	R6738[0] = (char *(*)()) F1007_8806;
	R6738[1] = (char *(*)()) F1008_8867;
	R6738[263] = (char *(*)()) F1008_8867;
}

char *(*R6743[264])();
void R6743_init () {
	{long i; for (i = 0; i < 2; i++) R6743[i] = (char *(*)()) F1006_8700;}
	R6743[263] = (char *(*)()) F1270_12036;
}

char *(*R6746[264])();
void R6746_init () {
	{long i; for (i = 0; i < 2; i++) R6746[i] = (char *(*)()) F1006_8697;}
	R6746[263] = (char *(*)()) F1270_12033;
}

char *(*R6781[264])();
void R6781_init () {
	{long i; for (i = 0; i < 2; i++) R6781[i] = (char *(*)()) F1006_8585;}
	R6781[263] = (char *(*)()) F1270_12023;
}

char *(*R6850[264])();
void R6850_init () {
	R6850[0] = (char *(*)()) F1007_8826;
	R6850[1] = (char *(*)()) F1006_8709;
	R6850[263] = (char *(*)()) F1006_8709;
}

char *(*R6851[264])();
void R6851_init () {
	{long i; for (i = 0; i < 2; i++) R6851[i] = (char *(*)()) F1006_8710;}
	R6851[263] = (char *(*)()) F1270_12079;
}


#ifdef __cplusplus
}
#endif
