/*
 * Code for class XML_POSITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm512.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_POSITION}.make */
void F1114_10458 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 1113, Current, 1, 4, 14338);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) arg3;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) arg4;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {XML_POSITION}.row */
EIF_INTEGER_32 F1114_10463 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("row", 1113, Current, 0, 0, 14343);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_);
}

/* {XML_POSITION}.to_string_32 */
EIF_REFERENCE F1114_10464 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("to_string_32", 1113, Current, 1, 0, 14344);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(Result));
	RTHOOK(2);
	tr1 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000e\000\000\000:\000\000\000 \000\000\000",6,2065270816);
	F1096_9776(RTCW(Result), tr1);
	RTHOOK(3);
	F1096_9777(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_));
	RTHOOK(4);
	tr1 = RTMS32_EX_H(" \000\000\000c\000\000\000o\000\000\000l\000\000\000u\000\000\000m\000\000\000n\000\000\000:\000\000\000 \000\000\000",9,1845596448);
	F1096_9776(RTCW(Result), tr1);
	RTHOOK(5);
	F1096_9777(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
	RTHOOK(6);
	tr1 = RTMS32_EX_H(" \000\000\000b\000\000\000y\000\000\000t\000\000\000e\000\000\000_\000\000\000i\000\000\000n\000\000\000d\000\000\000e\000\000\000x\000\000\000:\000\000\000 \000\000\000",13,139811616);
	F1096_9776(RTCW(Result), tr1);
	RTHOOK(7);
	F1096_9777(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_));
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(9);
		tr1 = RTMS32_EX_H(" \000\000\000-\000\000\000>\000\000\000 \000\000\000",4,539835936);
		F1096_9776(RTCW(Result), tr1);
		RTHOOK(10);
		F1096_9776(RTCW(Result), loc1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
