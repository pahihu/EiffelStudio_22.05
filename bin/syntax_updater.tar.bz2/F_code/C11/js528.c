/*
 * Code for class JSON_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NULL}.hash_code */
EIF_INTEGER_32 F1221_10882 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1220, Current, 0, 0, 16977);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(10886,F1221_10886, (Current));
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7172[Dtype(RTCW(tr1))-1039])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NULL}.representation */
EIF_REFERENCE F1221_10883 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("representation", 1220, Current, 0, 0, 16978);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("null",4,1853189228);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NULL}.null_value */

EIF_REFERENCE F1221_10886 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10886,RTMS_EX_H("null",4,1853189228));
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
