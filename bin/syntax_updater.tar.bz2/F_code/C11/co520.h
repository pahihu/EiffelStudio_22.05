
#ifndef _C11_co520_
#define _C11_co520_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1168_10737(EIF_REFERENCE, EIF_REFERENCE);
extern void F1168_10739(EIF_REFERENCE, EIF_REFERENCE);
extern void F1168_10742(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit520(void);
extern void F950_7843(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F757_7351(EIF_REFERENCE);
extern void F1285_12311(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5866[])();

#ifdef __cplusplus
}
#endif

#endif
