/*
 * Code for class reference NATURAL_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_64}.is_less */
EIF_BOOLEAN F1238_11415 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1237, Current, 0, 1, 17656);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	Result = F1237_11356(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.plus */
EIF_NATURAL_64 F1238_11416 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1237, Current, 0, 1, 17657);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11365(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.product */
EIF_NATURAL_64 F1238_11418 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1237, Current, 0, 1, 17659);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11367(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.integer_quotient */
EIF_NATURAL_64 F1238_11421 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1237, Current, 0, 1, 17662);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11371(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.integer_remainder */
EIF_NATURAL_64 F1238_11422 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1237, Current, 0, 1, 17663);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11372(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.as_natural_8 */
EIF_NATURAL_8 F1238_11424 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1237, Current, 0, 0, 17665);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1237_11377(Current);
}

/* {NATURAL_64}.as_natural_16 */
EIF_NATURAL_16 F1238_11425 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_16", 1237, Current, 0, 0, 17666);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_16) F1237_11378(Current);
}

/* {NATURAL_64}.as_natural_32 */
EIF_NATURAL_32 F1238_11426 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1237, Current, 0, 0, 17667);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1237_11379(Current);
}

/* {NATURAL_64}.as_integer_32 */
EIF_INTEGER_32 F1238_11430 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1237, Current, 0, 0, 17671);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1237_11383(Current);
}

/* {NATURAL_64}.as_integer_64 */
EIF_INTEGER_64 F1238_11431 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_64", 1237, Current, 0, 0, 17645);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1237_11384(Current);
}

/* {NATURAL_64}.to_character_8 */
EIF_CHARACTER_8 F1238_11434 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1237, Current, 0, 0, 17648);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1237_11402(Current);
}

/* {NATURAL_64}.bit_and */
EIF_NATURAL_64 F1238_11436 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1237, Current, 0, 1, 17650);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11404(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_or */
EIF_NATURAL_64 F1238_11437 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 1237, Current, 0, 1, 17651);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11405(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_xor */
EIF_NATURAL_64 F1238_11438 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_xor", 1237, Current, 0, 1, 17652);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11406(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_shift_left */
EIF_NATURAL_64 F1238_11440 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_left", 1237, Current, 0, 1, 17654);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_64 *)F1237_11409(Current, arg1);
}

/* {NATURAL_64}.bit_shift_right */
EIF_NATURAL_64 F1238_11441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1237, Current, 0, 1, 17655);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_64 *)F1237_11410(Current, arg1);
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
