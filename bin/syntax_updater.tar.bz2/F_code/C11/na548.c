/*
 * Code for class NATURAL_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_32}.is_less */
EIF_BOOLEAN F1242_11509 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1241, Current, 0, 1, 17739);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	Result = F1240_11450(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.plus */
EIF_NATURAL_32 F1242_11510 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1241, Current, 0, 1, 17740);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11459(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.minus */
EIF_NATURAL_32 F1242_11511 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("minus", 1241, Current, 0, 1, 17741);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11460(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.product */
EIF_NATURAL_32 F1242_11512 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1241, Current, 0, 1, 17742);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11461(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.quotient */
EIF_REAL_64 F1242_11513 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("quotient", 1241, Current, 0, 1, 17743);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	Result = F1240_11462(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.integer_quotient */
EIF_NATURAL_32 F1242_11515 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1241, Current, 0, 1, 17745);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11465(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.integer_remainder */
EIF_NATURAL_32 F1242_11516 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1241, Current, 0, 1, 17746);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11466(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.as_natural_8 */
EIF_NATURAL_8 F1242_11518 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1241, Current, 0, 0, 17748);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1240_11471(Current);
}

/* {NATURAL_32}.as_natural_16 */
EIF_NATURAL_16 F1242_11519 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_16", 1241, Current, 0, 0, 17749);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_16) F1240_11472(Current);
}

/* {NATURAL_32}.as_natural_64 */
EIF_NATURAL_64 F1242_11521 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1241, Current, 0, 0, 17751);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1240_11474(Current);
}

/* {NATURAL_32}.as_integer_32 */
EIF_INTEGER_32 F1242_11524 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1241, Current, 0, 0, 17754);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1240_11477(Current);
}

/* {NATURAL_32}.as_integer_64 */
EIF_INTEGER_64 F1242_11525 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_64", 1241, Current, 0, 0, 17755);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1240_11478(Current);
}

/* {NATURAL_32}.to_real_64 */
EIF_REAL_64 F1242_11527 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_real_64", 1241, Current, 0, 0, 17757);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1240_11488(Current);
}

/* {NATURAL_32}.to_character_8 */
EIF_CHARACTER_8 F1242_11528 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1241, Current, 0, 0, 17758);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1240_11496(Current);
}

/* {NATURAL_32}.to_character_32 */
EIF_CHARACTER_32 F1242_11529 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 1241, Current, 0, 0, 17759);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F1240_11497(Current);
}

/* {NATURAL_32}.bit_and */
EIF_NATURAL_32 F1242_11530 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1241, Current, 0, 1, 17760);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11498(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.bit_or */
EIF_NATURAL_32 F1242_11531 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 1241, Current, 0, 1, 17761);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F1240_11499(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.bit_shift_left */
EIF_NATURAL_32 F1242_11534 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_left", 1241, Current, 0, 1, 17764);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_32 *)F1240_11503(Current, arg1);
}

/* {NATURAL_32}.bit_shift_right */
EIF_NATURAL_32 F1242_11535 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1241, Current, 0, 1, 17765);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_32 *)F1240_11504(Current, arg1);
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
