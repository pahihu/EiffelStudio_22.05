/*
 * Code for class NATURAL_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na545.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_64}.is_less */
EIF_BOOLEAN F1239_11415 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1238, Current, 0, 1, 17629);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	Result = F1237_11356(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.plus */
EIF_NATURAL_64 F1239_11416 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1238, Current, 0, 1, 17630);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11365(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.product */
EIF_NATURAL_64 F1239_11418 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1238, Current, 0, 1, 17632);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11367(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.integer_quotient */
EIF_NATURAL_64 F1239_11421 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1238, Current, 0, 1, 17635);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11371(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.integer_remainder */
EIF_NATURAL_64 F1239_11422 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1238, Current, 0, 1, 17636);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11372(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.as_natural_8 */
EIF_NATURAL_8 F1239_11424 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1238, Current, 0, 0, 17638);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1237_11377(Current);
}

/* {NATURAL_64}.as_natural_16 */
EIF_NATURAL_16 F1239_11425 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_16", 1238, Current, 0, 0, 17639);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_16) F1237_11378(Current);
}

/* {NATURAL_64}.as_natural_32 */
EIF_NATURAL_32 F1239_11426 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1238, Current, 0, 0, 17640);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1237_11379(Current);
}

/* {NATURAL_64}.as_integer_32 */
EIF_INTEGER_32 F1239_11430 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1238, Current, 0, 0, 17644);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1237_11383(Current);
}

/* {NATURAL_64}.as_integer_64 */
EIF_INTEGER_64 F1239_11431 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_64", 1238, Current, 0, 0, 17618);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1237_11384(Current);
}

/* {NATURAL_64}.to_character_8 */
EIF_CHARACTER_8 F1239_11434 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1238, Current, 0, 0, 17621);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1237_11402(Current);
}

/* {NATURAL_64}.bit_and */
EIF_NATURAL_64 F1239_11436 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1238, Current, 0, 1, 17623);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11404(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_or */
EIF_NATURAL_64 F1239_11437 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 1238, Current, 0, 1, 17624);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11405(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_xor */
EIF_NATURAL_64 F1239_11438 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_xor", 1238, Current, 0, 1, 17625);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1238, 0x00).id, 1238, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)tr1 = arg1;
	tr1 = F1237_11406(Current, tr1);
	Result = *(EIF_NATURAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_64}.bit_shift_left */
EIF_NATURAL_64 F1239_11440 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_left", 1238, Current, 0, 1, 17627);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_64 *)F1237_11409(Current, arg1);
}

/* {NATURAL_64}.bit_shift_right */
EIF_NATURAL_64 F1239_11441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1238, Current, 0, 1, 17628);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_64 *)F1237_11410(Current, arg1);
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
