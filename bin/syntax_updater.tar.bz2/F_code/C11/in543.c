/*
 * Code for class reference INTEGER_8
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_8}.is_less */
EIF_BOOLEAN F1235_11320 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1234, Current, 0, 1, 17523);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_INTEGER_8 *)tr1 = arg1;
	Result = F1234_11257(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8}.plus */
EIF_INTEGER_8 F1235_11321 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1234, Current, 0, 1, 17524);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_INTEGER_8 *)tr1 = arg1;
	tr1 = F1234_11267(Current, tr1);
	Result = *(EIF_INTEGER_8 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8}.opposite */
EIF_INTEGER_8 F1235_11326 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1234, Current, 0, 0, 17529);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_8 *)F1234_11272(Current);
}

/* {INTEGER_8}.integer_quotient */
EIF_INTEGER_8 F1235_11327 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1234, Current, 0, 1, 17530);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_INTEGER_8 *)tr1 = arg1;
	tr1 = F1234_11273(Current, tr1);
	Result = *(EIF_INTEGER_8 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8}.integer_remainder */
EIF_INTEGER_8 F1235_11328 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1234, Current, 0, 1, 17531);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1235, 0x00).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_INTEGER_8 *)tr1 = arg1;
	tr1 = F1234_11274(Current, tr1);
	Result = *(EIF_INTEGER_8 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8}.as_natural_8 */
EIF_NATURAL_8 F1235_11330 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1234, Current, 0, 0, 17533);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1234_11280(Current);
}

/* {INTEGER_8}.as_natural_64 */
EIF_NATURAL_64 F1235_11333 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1234, Current, 0, 0, 17536);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1234_11283(Current);
}

/* {INTEGER_8}.as_integer_32 */
EIF_INTEGER_32 F1235_11336 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1234, Current, 0, 0, 17539);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1234_11286(Current);
}

/* {INTEGER_8}.to_character_8 */
EIF_CHARACTER_8 F1235_11340 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1234, Current, 0, 0, 17543);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1234_11306(Current);
}

/* {INTEGER_8}.bit_shift_right */
EIF_INTEGER_8 F1235_11347 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1234, Current, 0, 1, 17550);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_8 *)F1234_11314(Current, arg1);
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
