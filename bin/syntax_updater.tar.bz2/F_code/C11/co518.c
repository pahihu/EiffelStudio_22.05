/*
 * Code for class CONF_CLUSTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CLUSTER}.make */
void F1166_10689 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("make", 1165, Current, 0, 3, 16116);
	RTGC;
	RTHOOK(1);
	F1163_10611(Current, arg1, arg2, arg3);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,402,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F603_7199(RTCW(tr1));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,943,0xFF01,1107,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,845,0xFF01,943,0xFF01,1090,0xFF01,1107,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.dependencies */
EIF_REFERENCE F1166_10696 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Result);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("dependencies", 1165, Current, 3, 0, 16123);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1166_10696(loc1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		Result = F1_14(loc2);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(Result != NULL)) {
			RTHOOK(5);
			F1267_11985(RTCW(Result), loc3);
		} else {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc3;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.file_rule */
EIF_REFERENCE F1166_10698 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("file_rule", 1165, Current, 1, 0, 16125);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1166_10698(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1113_10363(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.mapping */
EIF_REFERENCE F1166_10703 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("mapping", 1165, Current, 3, 0, 16130);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_23_) == NULL) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_18_) == NULL))) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1113_10376(RTCW(tr1));
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = F1113_10376(RTCW(tr1));
			loc1 = F1_14(tr1);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				RTHOOK(7);
				tr1 = F1166_10703(loc2);
				F846_7485(RTCW(loc1), tr1);
			}
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(9);
				F846_7485(RTCW(loc1), loc3);
			}
		}
		RTHOOK(10);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(11);
	RTHOOK(12);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_CLUSTER}.class_by_name */
EIF_REFERENCE F1166_10704 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,loc4);
	RTLR(6,Result);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc1);
	RTLIU(11);
	
	RTEAA("class_by_name", 1165, Current, 7, 2, 16131);
	RTGC;
	RTHOOK(1);
	tr1 = F1166_10703(Current);
	tr1 = F846_7440(RTCW(tr1), arg1);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		loc2 = (EIF_REFERENCE) loc3;
	} else {
		RTHOOK(3);
		loc2 = (EIF_REFERENCE) arg1;
	}
	RTHOOK(4);
	tb1 = '\0';
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		tr1 = F846_7440(RTCW(tr1), loc2);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc4;
	} else {
		RTHOOK(7);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1107,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 943, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F940_7723(RTCW(Result));
		RTHOOK(8);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = F846_7440(loc5, loc2);
			loc6 = tr1;
			tb2 = EIF_TEST(loc6);
		}
		if (tb2) {
			tb2 = (RTNA((loc6)), ((EIF_BOOLEAN) 0));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(9);
			F944_7790(RTCW(Result), loc6);
		}
		RTHOOK(10);
		if (arg2) {
			RTHOOK(11);
			loc7 = F1267_11974(RTCV(F1166_10706(Current)));
			for (;;) {
				tb1 = F473_6970(loc7);
				if (tb1) break;
				RTHOOK(12);
				loc1 = F473_6969(loc7);
				RTHOOK(13);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8332[Dtype(RTCW(loc1))-1165])(loc1);
				if (tb2) {
					RTHOOK(14);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8359[Dtype(RTCW(loc1))-1165])(loc1, loc2, (EIF_BOOLEAN) 0);
					F890_7683(RTCW(Result), tr1);
				}
				RTHOOK(15);
				F473_6971(loc7);
			}
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			F846_7481(RTCW(tr1), Result, loc2);
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.name_by_class */
EIF_REFERENCE F1166_10705 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTEAA("name_by_class", 1165, Current, 3, 2, 16132);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
		tr1 = F846_7440(RTCW(tr1), arg1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(4);
		Result = F1163_10643(Current, arg1, arg2);
		RTHOOK(5);
		if (arg2) {
			RTHOOK(6);
			loc3 = F1267_11974(RTCV(F1166_10706(Current)));
			for (;;) {
				tb1 = F473_6970(loc3);
				if (tb1) break;
				RTHOOK(7);
				loc1 = F473_6969(loc3);
				RTHOOK(8);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8332[Dtype(RTCW(loc1))-1165])(loc1);
				if (tb2) {
					RTHOOK(9);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8360[Dtype(RTCW(loc1))-1165])(loc1, arg1, (EIF_BOOLEAN) 0);
					F890_7683(RTCW(Result), tr1);
				}
				RTHOOK(10);
				F473_6971(loc3);
			}
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			F846_7481(RTCW(tr1), Result, arg1);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.accessible_groups */
EIF_REFERENCE F1166_10706 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLIU(10);
	
	RTEAA("accessible_groups", 1165, Current, 8, 0, 16133);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(3);
		tr1 = F1166_10696(Current);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			loc2 = (EIF_REFERENCE) loc3;
			RTHOOK(5);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1113_10359(RTCW(tr1));
			RTHOOK(7);
			{
				static EIF_TYPE_INDEX typarr0[] = {1266,0xFF01,1162,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNSMART(typres0.id);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1267_11963(RTCW(loc2), ti4_1);
			RTHOOK(8);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
			RTHOOK(9);
			loc4 = F846_7449(RTCW(loc1));
			for (;;) {
				tb1 = F540_7116(loc4);
				if (tb1) break;
				RTHOOK(10);
				tr1 = F540_7113(loc4);
				F1267_11979(RTCW(loc2), tr1);
				RTHOOK(11);
				F540_7117(loc4);
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1113_10357(RTCW(tr1));
			RTHOOK(13);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1166_10706(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1267_11986(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(14);
			loc5 = F846_7449(RTCW(loc1));
			for (;;) {
				tb2 = F540_7116(loc5);
				if (tb2) break;
				RTHOOK(15);
				tr1 = F540_7113(loc5);
				F1267_11979(RTCW(loc2), tr1);
				RTHOOK(16);
				F540_7117(loc5);
			}
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1113_10358(RTCW(tr1));
			RTHOOK(18);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1166_10706(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1267_11986(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(19);
			loc6 = F846_7449(RTCW(loc1));
			for (;;) {
				tb3 = F540_7116(loc6);
				if (tb3) break;
				RTHOOK(20);
				tr1 = F540_7113(loc6);
				F1267_11979(RTCW(loc2), tr1);
				RTHOOK(21);
				F540_7117(loc6);
			}
			RTHOOK(22);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1113_10360(RTCW(tr1));
			RTHOOK(23);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1166_10706(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1267_11986(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(24);
			loc7 = F846_7449(RTCW(loc1));
			for (;;) {
				tb4 = F540_7116(loc7);
				if (tb4) break;
				RTHOOK(25);
				tr1 = F540_7113(loc7);
				F1267_11979(RTCW(loc2), tr1);
				RTHOOK(26);
				F540_7117(loc7);
			}
			RTHOOK(27);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = F1113_10356(RTCW(tr1));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(28);
				F1267_11979(RTCW(loc2), loc8);
			}
			RTHOOK(29);
			F1267_11981(RTCW(loc2), Current);
		}
	}
	RTHOOK(30);
	RTHOOK(31);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc2;
}

/* {CONF_CLUSTER}.is_readonly */
EIF_BOOLEAN F1166_10708 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_readonly", 1165, Current, 1, 0, 16135);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_BOOLEAN *)(Current + O8395[Dtype(Current)-1162]);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !Result) {
		tb1 = F1163_10623(Current);
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(5);
			Result = F1171_10779(RTCW(loc1));
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) Result;
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
			Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_16_3_);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.set_parent */
void F1166_10709 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_parent", 1165, Current, 0, 1, 16136);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.add_child */
void F1166_10710 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_child", 1165, Current, 2, 1, 16137);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTLNSMART(eif_final_id(Y8403,Y8403_gen_type,Dftype(Current),1165).id);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6201[Dtype(RTCW(loc1))-949])(loc1, ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F950_7883(RTCW(loc1), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.set_recursive */
void F1166_10712 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_recursive", 1165, Current, 0, 1, 16139);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O8400[Dtype(Current)-1165]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.set_hidden */
void F1166_10713 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_hidden", 1165, Current, 0, 1, 16140);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O8401[Dtype(Current)-1165]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.set_dependencies */
void F1166_10714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_dependencies", 1165, Current, 0, 1, 16141);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.add_dependency_name */
void F1166_10716 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_dependency_name", 1165, Current, 2, 1, 16143);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {949,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(loc1), ((EIF_INTEGER_32) 0L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F950_7883(RTCW(loc1), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.add_file_rule */
void F1166_10718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_file_rule", 1165, Current, 0, 1, 16145);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F950_7883(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.add_mapping */
void F1166_10720 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("add_mapping", 1165, Current, 1, 2, 16147);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {854,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F846_7435(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	tr1 = F1096_9810(RTCW(arg2));
	tr2 = F1096_9810(RTCW(arg1));
	F846_7481(RTCW(loc1), tr1, tr2);
	RTHOOK(6);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.process */
void F1166_10724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1165, Current, 0, 1, 16107);
	RTGC;
	RTHOOK(1);
	F1163_10667(Current, arg1);
	RTHOOK(2);
	F1285_12310(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
