
#ifndef _C11_js527_
#define _C11_js527_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1220_10872(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1220_10873(EIF_REFERENCE);
extern void F1220_10874(EIF_REFERENCE);
extern EIF_INTEGER_32 F1220_10877(EIF_REFERENCE);
extern EIF_REFERENCE F1220_10878(EIF_REFERENCE);
extern void EIF_Minit527(void);

#ifdef __cplusplus
}
#endif

#endif
