/*
 * Code for class CONF_TARGET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co511.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TARGET}.make */
void F1113_10315 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make", 1112, Current, 0, 2, 14194);
	RTGC;
	RTHOOK(1);
	F401_5801(Current);
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7553[Dtype(RTCW(arg1))-1094])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1170,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1165,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1169,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,402,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F603_7199(RTCW(tr1));
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,408,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,405,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,406,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	RTHOOK(12);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,407,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(13);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,411,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,410,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(15);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,409,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTHOOK(16);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	RTHOOK(17);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	RTHOOK(18);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1093,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F855_7559(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	RTHOOK(19);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1093,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F846_7434(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(20);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg2;
	RTHOOK(23);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.namespace */
EIF_REFERENCE F1113_10324 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("namespace", 1112, Current, 0, 0, 14203);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
	Result = F1091_9588(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.record_environ_variable */
void F1113_10352 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("record_environ_variable", 1112, Current, 0, 2, 14231);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F846_7480(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.library_root */
EIF_REFERENCE F1113_10353 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("library_root", 1112, Current, 1, 0, 14232);
	RTGC;
	RTHOOK(1);
	tr1 = F1113_10365(Current);
	tr2 = RTOSCF(3858,F289_3858, (Current));
	tr1 = F846_7440(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1314, 0x01).id, 1314, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr2 = RTLNS(eif_new_type(394, 0x01).id, 394, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = RTMS32_EX_H("d\000\000\000u\000\000\000m\000\000\000m\000\000\000y\000\000\000",5,1970873721);
		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = F395_5680(RTCW(tr2), tr3, tr4);
		F1315_12919(RTCW(tr1), loc1, tr2);
		Result = F1313_12903(RTCW(tr1));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.precompile */
EIF_REFERENCE F1113_10356 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("precompile", 1112, Current, 2, 0, 14235);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && EIF_TEST(loc2))) {
		RTHOOK(3);
		tr1 = F1113_10356(loc2);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}/* NOTREACHED */
	
}

/* {CONF_TARGET}.libraries */
EIF_REFERENCE F1113_10357 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("libraries", 1112, Current, 1, 0, 14236);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10357(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F846_7485(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_13_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.assemblies */
EIF_REFERENCE F1113_10358 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("assemblies", 1112, Current, 1, 0, 14237);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10358(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F846_7485(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_16_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.clusters */
EIF_REFERENCE F1113_10359 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("clusters", 1112, Current, 1, 0, 14238);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10359(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F846_7485(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_15_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.overrides */
EIF_REFERENCE F1113_10360 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("overrides", 1112, Current, 1, 0, 14239);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10360(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F846_7485(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_14_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.file_rule */
EIF_REFERENCE F1113_10363 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("file_rule", 1112, Current, 1, 0, 14242);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10363(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.options */
EIF_REFERENCE F1113_10364 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("options", 1112, Current, 2, 0, 14243);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F1_14(F401_5802(Current));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			Result = F1_14(F401_5802(Current));
			RTHOOK(5);
			tr1 = F1113_10364(loc1);
			F980_8291(RTCW(Result), tr1);
		} else {
			RTHOOK(6);
			Result = F1113_10364(loc1);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.settings */
EIF_REFERENCE F1113_10365 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("settings", 1112, Current, 1, 0, 14244);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(loc1 != Current))) {
		RTHOOK(2);
		tr1 = F1113_10365(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		tr1 = F401_5804(Current);
		F846_7485(RTCW(Result), tr1);
	} else {
		RTHOOK(4);
		Result = F401_5804(Current);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_include */
EIF_REFERENCE F1113_10366 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_include", 1112, Current, 1, 0, 14245);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10366(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_cflag */
EIF_REFERENCE F1113_10367 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_cflag", 1112, Current, 1, 0, 14246);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10367(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_object */
EIF_REFERENCE F1113_10368 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_object", 1112, Current, 1, 0, 14247);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10368(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_library */
EIF_REFERENCE F1113_10369 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_library", 1112, Current, 1, 0, 14248);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10369(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_linker_flag */
EIF_REFERENCE F1113_10370 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_linker_flag", 1112, Current, 1, 0, 14249);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10370(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_make */
EIF_REFERENCE F1113_10371 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_make", 1112, Current, 1, 0, 14250);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10371(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_resource */
EIF_REFERENCE F1113_10372 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_resource", 1112, Current, 1, 0, 14251);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1113_10372(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.pre_compile_action */
EIF_REFERENCE F1113_10373 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("pre_compile_action", 1112, Current, 2, 0, 14252);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(2);
		Result = F1_14(loc1);
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F950_7843(RTCW(Result), ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = F1113_10373(loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.post_compile_action */
EIF_REFERENCE F1113_10374 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("post_compile_action", 1112, Current, 2, 0, 14253);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(2);
		Result = F1_14(loc1);
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 949, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F950_7843(RTCW(Result), ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = F1113_10374(loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5964[Dtype(RTCW(Result))-939])(Result, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.variables */
EIF_REFERENCE F1113_10375 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("variables", 1112, Current, 1, 0, 14254);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10375(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F846_7485(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_28_));
	} else {
		RTHOOK(4);
		Result = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.mapping */
EIF_REFERENCE F1113_10376 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("mapping", 1112, Current, 3, 0, 14255);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10376(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			F846_7485(RTCW(Result), loc2);
		}
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc3;
		} else {
			RTHOOK(8);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1093,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				Result = RTLNS(typres0.id, 854, _OBJSIZ_7_4_0_7_0_0_0_0_);
			}
			F846_7435(RTCW(Result), ((EIF_INTEGER_32) 5L));
			RTHOOK(9);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.set_description */
void F1113_10380 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_description", 1112, Current, 0, 1, 14259);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.set_parent */
void F1113_10381 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_parent", 1112, Current, 0, 1, 14260);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.reference_parent */
void F1113_10383 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("reference_parent", 1112, Current, 0, 1, 14262);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {CONF_TARGET}.set_version */
void F1113_10386 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_version", 1112, Current, 0, 1, 14265);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.set_precompile */
void F1113_10387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_precompile", 1112, Current, 0, 1, 14266);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.add_library */
void F1113_10388 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_library", 1112, Current, 0, 1, 14267);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F846_7481(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_assembly */
void F1113_10389 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_assembly", 1112, Current, 0, 1, 14268);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	F846_7481(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_cluster */
void F1113_10390 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_cluster", 1112, Current, 0, 1, 14269);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F846_7481(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_override */
void F1113_10391 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_override", 1112, Current, 0, 1, 14270);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F846_7481(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.set_root */
void F1113_10396 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_root", 1112, Current, 0, 1, 14275);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.add_file_rule */
void F1113_10399 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_file_rule", 1112, Current, 0, 1, 14278);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F950_7883(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_include */
void F1113_10407 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_include", 1112, Current, 0, 1, 14286);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_cflag */
void F1113_10408 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_cflag", 1112, Current, 0, 1, 14287);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_object */
void F1113_10409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_object", 1112, Current, 0, 1, 14288);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_library */
void F1113_10410 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_library", 1112, Current, 0, 1, 14289);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_resource */
void F1113_10411 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_resource", 1112, Current, 0, 1, 14290);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_23_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,411,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_linker_flag */
void F1113_10412 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_linker_flag", 1112, Current, 0, 1, 14291);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_make */
void F1113_10413 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_make", 1112, Current, 0, 1, 14292);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.remove_external_object */
void F1113_10416 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("remove_external_object", 1112, Current, 0, 1, 14295);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	F950_7874(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	F950_7880(RTCW(tr1), arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5884[Dtype(RTCW(tr1))-796])(tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.remove_external_library */
void F1113_10417 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("remove_external_library", 1112, Current, 0, 1, 14296);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F950_7874(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F950_7880(RTCW(tr1), arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5884[Dtype(RTCW(tr1))-796])(tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_pre_compile */
void F1113_10423 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_pre_compile", 1112, Current, 0, 1, 14302);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_26_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_post_compile */
void F1113_10424 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_post_compile", 1112, Current, 0, 1, 14303);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_27_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,403,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(tr1))-754])(tr1, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_variable */
void F1113_10426 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("add_variable", 1112, Current, 0, 2, 14305);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	F846_7481(RTCW(tr1), arg2, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_mapping */
void F1113_10428 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("add_mapping", 1112, Current, 1, 2, 14307);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {854,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F855_7559(RTCW(loc1), ((EIF_INTEGER_32) 15L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	tr1 = F1096_9810(RTCW(arg2));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7554[Dtype(RTCW(arg1))-1094])(arg1);
	F846_7481(RTCW(loc1), tr1, tr2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.set_abstract */
void F1113_10430 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abstract", 1112, Current, 0, 1, 14309);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_29_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.same_as */
EIF_BOOLEAN F1113_10432 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("same_as", 1112, Current, 2, 1, 14311);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg1 == Current)) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
			tb1 = F1091_9571(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
			if (tb1) {
				RTHOOK(6);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				loc1 = tr1;
				if ((EIF_TRUE)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
					loc2 = tr1;
					tb1 = (EIF_TRUE);
				}
				if (tb1) {
					RTHOOK(7);
					if ((EIF_BOOLEAN)(loc1 == loc2)) {
						RTHOOK(8);
						RTHOOK(9);
						RTLE;
						RTEE;
						return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(10);
						tb1 = '\0';
						tb2 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_16_2_);
						if (tb2) {
							tb2 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_16_2_);
							tb1 = tb2;
						}
						if (tb1) {
							RTHOOK(11);
							tr1 = F1293_12623(loc1);
							tr2 = F1293_12623(loc2);
							Result = F1115_10499(RTCW(tr1), tr2);
						} else {
							RTHOOK(12);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
							tr2 = *(EIF_REFERENCE *)(loc2 + _REFACS_5_);
							Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
						}
					}
				} else {
					RTHOOK(13);
					RTHOOK(14);
					RTLE;
					RTEE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.hash_code */
EIF_INTEGER_32 F1113_10435 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1112, Current, 0, 0, 14314);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = F1091_9538(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.process */
void F1113_10436 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1112, Current, 0, 1, 14315);
	RTHOOK(1);
	F1285_12306(RTCW(arg1), Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
