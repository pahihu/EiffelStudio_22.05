
#ifndef _C11_co521_
#define _C11_co521_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1169_10746(EIF_REFERENCE, EIF_REFERENCE);
extern void F1169_10748(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit521(void);
extern void F846_7481(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1094_9661(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_9816(EIF_REFERENCE);
extern void F846_7435(EIF_REFERENCE, EIF_INTEGER_32);
extern long O8435[];
extern long O8436[];

#ifdef __cplusplus
}
#endif

#endif
