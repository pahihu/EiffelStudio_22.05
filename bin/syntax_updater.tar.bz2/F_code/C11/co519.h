
#ifndef _C11_co519_
#define _C11_co519_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_BOOLEAN,10732)
static EIF_BOOLEAN F1167_10732_body(EIF_REFERENCE);
extern EIF_BOOLEAN F1167_10732(EIF_REFERENCE);
extern void F1167_10733(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit519(void);
extern void F1166_10724(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
