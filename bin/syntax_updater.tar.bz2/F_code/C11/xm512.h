
#ifndef _C11_xm512_
#define _C11_xm512_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1114_10458(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1114_10463(EIF_REFERENCE);
extern EIF_REFERENCE F1114_10464(EIF_REFERENCE);
extern void EIF_Minit512(void);
extern void F1096_9777(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1096_9776(EIF_REFERENCE, EIF_REFERENCE);
extern void F1091_9529(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
