/*
 * Code for class CONF_ORDERED_CAPABILITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ORDERED_CAPABILITY}.make */
void F1111_10275 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 1110, Current, 0, 1, 14156);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1111_10290(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.is_valid_item */
EIF_BOOLEAN F1111_10276 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_valid_item", 1110, Current, 0, 1, 14157);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1109_10201(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.is_capable */
EIF_BOOLEAN F1111_10278 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_capable", 1110, Current, 0, 1, 14159);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	ti4_1 = (EIF_INTEGER_32) arg1;
	if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) < ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
		Result = (EIF_BOOLEAN) (arg1 <= tu1_1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.is_root_set */
EIF_BOOLEAN F1111_10279 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTEAA("is_root_set", 1110, Current, 0, 0, 14160);
	RTHOOK(1);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.default_root_index */
EIF_NATURAL_8 F1111_10283 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("default_root_index", 1110, Current, 0, 0, 14164);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.root_index */
EIF_NATURAL_8 F1111_10285 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("root_index", 1110, Current, 0, 0, 14166);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F1111_10279(Current)) {
		tb1 = F1111_10278(Current, *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_));
	}
	if (tb1) {
		RTHOOK(2);
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_);
	} else {
		RTHOOK(3);
		tu1_1 = F1111_10283(Current);
	}
	Result = (EIF_NATURAL_8) tu1_1;
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.custom_root */
EIF_REFERENCE F1111_10286 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("custom_root", 1110, Current, 0, 0, 14167);
	RTGC;
	RTHOOK(1);
	if (F1111_10279(Current)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1109_10209(RTCW(tr1), *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_));
	} else {
		RTHOOK(3);
		Result = RTMS32_EX_H("",0,0);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.put_root */
void F1111_10288 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_root", 1110, Current, 0, 1, 14169);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tu1_1 = F1109_10210(RTCW(tr1), arg1);
	F1111_10289(Current, tu1_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.put_root_index */
void F1111_10289 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put_root_index", 1110, Current, 0, 1, 14170);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) arg1;
	RTHOOK(5);
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.unset_root */
void F1111_10290 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unset_root", 1110, Current, 0, 0, 14171);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.set_safely_root */
void F1111_10291 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_safely_root", 1110, Current, 0, 1, 14172);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN) !F1111_10279(Current)) {
		tb3 = F1111_10279(RTCW(arg1));
		tb2 = tb3;
	}
	if (tb2) {
		tu1_1 = F1111_10285(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F1111_10285(Current) != tu1_1);
	}
	if (tb1) {
		RTHOOK(2);
		tu1_1 = F1111_10285(RTCW(arg1));
		F1111_10289(Current, tu1_1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.set_safely */
void F1111_10292 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("set_safely", 1110, Current, 0, 1, 14153);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1109_10211(RTCW(tr1), tr2);
	RTHOOK(2);
	F1111_10291(Current, arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
