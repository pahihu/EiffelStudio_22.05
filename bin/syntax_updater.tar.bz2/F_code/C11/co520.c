/*
 * Code for class CONF_OVERRIDE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co520.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_OVERRIDE}.set_override */
void F1168_10737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_override", 1167, Current, 0, 1, 16153);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(arg1 == NULL)) {
		tb2 = F757_7351(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OVERRIDE}.add_override_group_name */
void F1168_10739 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_override_group_name", 1167, Current, 1, 1, 16155);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {949,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5866[Dtype(RTCW(loc1))-754])(loc1, arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_OVERRIDE}.process */
void F1168_10742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1167, Current, 0, 1, 16158);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (CONF_VISITOR.process_group) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F1285_12311(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit520 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
