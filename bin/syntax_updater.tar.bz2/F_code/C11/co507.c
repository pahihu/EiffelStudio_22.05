/*
 * Code for class CONF_VALUE_CHOICE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co507.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VALUE_CHOICE}.make */
void F1109_10200 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make", 1108, Current, 0, 2, 14075);
	RTGC;
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) = (EIF_NATURAL_8) arg2;
	RTHOOK(2);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) arg2;
	RTHOOK(3);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current);
	F603_7199(RTCW(tr1));
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {CONF_VALUE_CHOICE}.is_valid_item */
EIF_BOOLEAN F1109_10201 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_valid_item", 1108, Current, 0, 1, 14076);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F873_7613(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.is_equal */
EIF_BOOLEAN F1109_10203 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_equal", 1108, Current, 0, 1, 14078);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tu1_1 = *(EIF_NATURAL_8 *)(RTCW(arg1)+ _CHROFF_1_2_);
	if ((EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) == tu1_1)) {
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(arg1)+ _CHROFF_1_1_);
		tb2 = (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) == tu1_1);
	}
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) == tb2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		Result = RTEQ(*(EIF_REFERENCE *)(Current), tr1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.item */
EIF_REFERENCE F1109_10207 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 1108, Current, 0, 0, 14082);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_);
		ti4_1 = (EIF_INTEGER_32) tu1_1;
		Result = F873_7610(RTCW(tr1), ti4_1);
	} else {
		RTHOOK(3);
		Result = RTMS32_EX_H("",0,0);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.count */
EIF_NATURAL_8 F1109_10208 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("count", 1108, Current, 0, 0, 14083);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F873_7617(RTCW(tr1));
	Result = (EIF_NATURAL_8) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.i_th */
EIF_REFERENCE F1109_10209 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("i_th", 1108, Current, 0, 1, 14084);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (EIF_INTEGER_32) arg1;
	Result = F873_7610(RTCW(tr1), ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.index_of */
EIF_NATURAL_8 F1109_10210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("index_of", 1108, Current, 1, 1, 14085);
	RTGC;
	RTHOOK(1);
	Result = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) Result;
		tr1 = F873_7610(RTCW(tr1), ti4_1);
		tb1 = F1094_9686(RTCW(tr1), arg1);
		if (tb1) break;
		RTHOOK(8);
		Result += (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALUE_CHOICE}.set_safely */
void F1109_10211 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 loc1 = (EIF_NATURAL_8) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_safely", 1108, Current, 1, 1, 14086);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_);
	RTHOOK(2);
	F160_2172(Current, arg1);
	RTHOOK(3);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) = (EIF_NATURAL_8) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_VALUE_CHOICE}.put_default_index */
void F1109_10212 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_default_index", 1108, Current, 0, 1, 14087);
	RTGC;
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) = (EIF_NATURAL_8) arg1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTHOOK(3);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_VALUE_CHOICE}.put_index */
void F1109_10213 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_index", 1108, Current, 0, 1, 14088);
	RTGC;
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_VALUE_CHOICE}.put */
void F1109_10214 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("put", 1108, Current, 0, 1, 14089);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tu1_1 = F1109_10210(Current, arg1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) tu1_1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_VALUE_CHOICE}.out */
EIF_REFERENCE F1109_10216 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("out", 1108, Current, 0, 0, 14091);
	RTGC;
	RTHOOK(1);
	Result = F1094_9703(RTCV(F1109_10207(Current)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
