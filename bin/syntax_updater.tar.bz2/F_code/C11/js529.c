/*
 * Code for class JSON_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js529.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_STRING}.make_from_string */
void F1222_10887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_from_string", 1221, Current, 0, 1, 16982);
	RTGC;
	RTHOOK(1);
	tr1 = F1222_10915(Current, arg1);
	F1222_10890(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {JSON_STRING}.make_from_escaped_json_string */
void F1222_10890 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_from_escaped_json_string", 1221, Current, 0, 1, 16985);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9582(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {JSON_STRING}.unescaped_string_32 */
EIF_REFERENCE F1222_10900 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("unescaped_string_32", 1221, Current, 1, 0, 16995);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O7730[Dtype(loc1)-1096]);
	F1094_9659(RTCW(Result), ti4_1);
	RTHOOK(3);
	F1222_10903(Current, Result);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.representation */
EIF_REFERENCE F1222_10901 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("representation", 1221, Current, 0, 0, 16996);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1097_9826(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '\"');
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, *(EIF_REFERENCE *)(Current));
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '\"');
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.unescape_to_string_32 */
void F1222_10903 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc6);
	RTLIU(4);
	
	RTEAA("unescape_to_string_32", 1221, Current, 6, 1, 16998);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O7730[Dtype(loc1)-1096]);
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		RTHOOK(5);
		loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, loc2));
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '\\')) {
			RTHOOK(7);
			if ((EIF_BOOLEAN) (loc2 < loc3)) {
				RTHOOK(8);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc1))-845])(loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L))));
				switch (tc1) {
					case (EIF_CHARACTER_8) '\"':
						RTHOOK(9);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(10);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) '\\':
						RTHOOK(11);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(12);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) '/':
						RTHOOK(13);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(14);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'b':
						RTHOOK(15);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\010';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(16);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'f':
						RTHOOK(17);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\014';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(18);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'n':
						RTHOOK(19);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(20);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'r':
						RTHOOK(21);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\015';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(22);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 't':
						RTHOOK(23);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(24);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'u':
						RTHOOK(25);
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 5L)) <= loc3)) {
							RTHOOK(26);
							loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7572[Dtype(RTCW(loc1))-1094])(loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 5L)));
							
							RTHOOK(28);
							tu4_1 = F1222_10914(Current, loc6);
							F1093_9629(RTCW(arg1), tu4_1);
							RTHOOK(29);
							loc2 += ((EIF_INTEGER_32) 6L);
						} else {
							RTHOOK(30);
							tw1 = (EIF_CHARACTER_32) loc5;
							F1096_9787(RTCW(arg1), tw1);
							RTHOOK(31);
							loc2++;
						}
						break;
					default:
						RTHOOK(32);
						tw1 = (EIF_CHARACTER_32) loc5;
						F1096_9787(RTCW(arg1), tw1);
						RTHOOK(33);
						loc2++;
						break;
				}
			} else {
				RTHOOK(34);
				tw1 = (EIF_CHARACTER_32) loc5;
				F1096_9787(RTCW(arg1), tw1);
				RTHOOK(35);
				loc2++;
			}
		} else {
			RTHOOK(36);
			loc4 = (EIF_NATURAL_32) loc5;
			RTHOOK(37);
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
				
				RTHOOK(39);
				tw1 = (EIF_CHARACTER_32) loc5;
				F1096_9787(RTCW(arg1), tw1);
			} else {
				RTHOOK(40);
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 223L))) {
					RTHOOK(41);
					loc2++;
					RTHOOK(42);
					if ((EIF_BOOLEAN) (loc2 <= loc3)) {
						RTHOOK(43);
						tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
						tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, loc2);
						tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
						tu4_1 = eif_bit_or(tu4_1,tu4_2);
						F1093_9629(RTCW(arg1), tu4_1);
					}
				} else {
					RTHOOK(44);
					if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L))) {
						RTHOOK(45);
						loc2 += ((EIF_INTEGER_32) 2L);
						RTHOOK(46);
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							RTHOOK(47);
							tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
							tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
							tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, loc2);
							tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							F1093_9629(RTCW(arg1), tu4_1);
						}
					} else {
						RTHOOK(48);
						if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 247L))) {
							RTHOOK(49);
							loc2 += ((EIF_INTEGER_32) 3L);
							RTHOOK(50);
							if ((EIF_BOOLEAN) (loc2 <= loc3)) {
								RTHOOK(51);
								tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
								tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L)));
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(loc1))-1094])(loc1, loc2);
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								F1093_9629(RTCW(arg1), tu4_1);
							}
						}
					}
				}
			}
			RTHOOK(52);
			loc2++;
		}
	}
	RTHOOK(53);
	RTLE;
	RTEE;
}

/* {JSON_STRING}.is_equal */
EIF_BOOLEAN F1222_10905 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 1221, Current, 0, 1, 17000);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7715[Dtype(RTCW(tr1))-1097])(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.hash_code */
EIF_INTEGER_32 F1222_10911 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1221, Current, 0, 0, 17006);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7172[Dtype(RTCW(tr1))-1039])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.hexadecimal_to_natural_32 */
EIF_NATURAL_32 F1222_10914 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("hexadecimal_to_natural_32", 1221, Current, 3, 1, 17009);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 2L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg1))-845])(arg1, ((EIF_INTEGER_32) 2L)));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'x');
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		RTHOOK(4);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(6);
		Result *= (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L);
		RTHOOK(7);
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg1))-845])(arg1, loc1));
		RTHOOK(8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) '0') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) '9'))) {
			RTHOOK(9);
			tr1 = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = loc3;
			ti4_1 = F1047_9377(RTCW(tr1), (EIF_CHARACTER_8) '0');
			tu4_1 = (EIF_NATURAL_32) ti4_1;
			Result += tu4_1;
		} else {
			RTHOOK(10);
			tc1 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc3);
			tr1 = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = tc1;
			ti4_1 = F1047_9377(RTCW(tr1), (EIF_CHARACTER_8) 'a');
			tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 10L));
			Result += tu4_1;
		}
		RTHOOK(11);
		loc1++;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.escaped_json_string */
EIF_REFERENCE F1222_10915 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("escaped_json_string", 1221, Current, 7, 1, 17010);
	RTGC;
	RTHOOK(1);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), (EIF_INTEGER_32) (loc3 + (EIF_INTEGER_32) (loc3 / ((EIF_INTEGER_32) 10L))));
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		RTHOOK(5);
		loc4 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, loc1);
		RTHOOK(6);
		tb1 = (loc4 <= 0xFF);
		if (tb1) {
			RTHOOK(7);
			loc5 = (EIF_CHARACTER_8) loc4;
			RTHOOK(8);
			switch (loc5) {
				case (EIF_CHARACTER_8) '\000':
					RTHOOK(9);
					tr1 = RTMS_EX_H("\\u0000",6,990242352);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\"':
					RTHOOK(10);
					tr1 = RTMS_EX_H("\\\"",2,23586);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\\':
					RTHOOK(11);
					tr1 = RTMS_EX_H("\\\\",2,23644);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '/':
					RTHOOK(12);
					tb1 = '\0';
					tb2 = F1091_9541(RTCW(arg1), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
					if (tb2) {
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						RTHOOK(13);
						tr1 = RTMS_EX_H("\\/",2,23599);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					} else {
						RTHOOK(14);
						tr1 = RTMS_EX_H("/",1,47);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					}
					break;
				case (EIF_CHARACTER_8) '\010':
					RTHOOK(15);
					tr1 = RTMS_EX_H("\\b",2,23650);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\014':
					RTHOOK(16);
					tr1 = RTMS_EX_H("\\f",2,23654);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\012':
					RTHOOK(17);
					tr1 = RTMS_EX_H("\\n",2,23662);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\015':
					RTHOOK(18);
					tr1 = RTMS_EX_H("\\r",2,23666);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\011':
					RTHOOK(19);
					tr1 = RTMS_EX_H("\\t",2,23668);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
					break;
				default:
					RTHOOK(20);
					tu4_1 = (EIF_NATURAL_32) loc4;
					if ((EIF_BOOLEAN) (tu4_1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
						RTHOOK(21);
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					RTHOOK(22);
					F1099_9953(RTCW(Result), loc5);
					break;
			}
		} else {
			RTHOOK(23);
			tr1 = RTMS_EX_H("\\u",2,23669);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
			RTHOOK(24);
			ti4_1 = (EIF_INTEGER_32) (loc4);
			tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)tr1 = ti4_1;
			loc6 = F1228_11105(RTCW(tr1));
			RTHOOK(25);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				RTHOOK(26);
				tb1 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(loc6))-845])(loc6, loc2));
						tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
					}
					tb1 = tb2;
				}
				if (tb1) break;
				RTHOOK(27);
				loc2++;
			}
			RTHOOK(28);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7572[Dtype(RTCW(loc6))-1094])(loc6, loc2, ti4_1);
			loc6 = (EIF_REFERENCE) tr1;
			for (;;) {
				RTHOOK(29);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 4L))) break;
				RTHOOK(30);
				F1099_9935(RTCW(loc6), ((EIF_INTEGER_32) 0L));
			}
			
			RTHOOK(32);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, loc6);
		}
		RTHOOK(33);
		loc1++;
	}
	RTHOOK(34);
	if (loc7) {
		RTHOOK(35);
		tr1 = RTOSCF(10916,F1222_10916, (Current));
		tr1 = F79_1088(RTCW(tr1), Result);
		Result = (EIF_REFERENCE) tr1;
		
	}
	RTHOOK(37);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_STRING}.utf_converter */
static EIF_REFERENCE F1222_10916_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("utf_converter", 1221, Current, 0, 0, 17011);
	RTGC;
	RTOSP (10916);
#define Result RTOSR(10916)
	RTOC_NEW(Result);
	Result= RTLN(eif_new_type(78, 0x00).id);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(78, 0x00).id, 78, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = (tr1);
	RTXA(tr1, Result);
	RTOSE (10916);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1222_10916 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10916,F1222_10916_body,(Current));
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
