
#ifndef _C11_ir503_
#define _C11_ir503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1105_10092(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1105_10093(EIF_REFERENCE, EIF_REFERENCE);
extern void F1105_10094(EIF_REFERENCE);
extern EIF_REFERENCE F1105_10095(EIF_REFERENCE);
extern EIF_BOOLEAN F1105_10100(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit503(void);
extern void F1097_9828(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F602_7183(EIF_REFERENCE);
extern EIF_BOOLEAN F1097_9863(EIF_REFERENCE, EIF_REFERENCE);
extern void F1339_14105(EIF_REFERENCE, EIF_REFERENCE);
extern void F1339_14146(EIF_REFERENCE, EIF_REFERENCE);
extern void F602_7179(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_REFERENCE F1339_14125(EIF_REFERENCE);
extern EIF_REFERENCE F1091_9610(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1091_9529(EIF_REFERENCE);
extern EIF_REFERENCE F1339_14139(EIF_REFERENCE);
extern char *(*R7715[])();
extern char *(*R6201[])();
extern char *(*R5942[])();
extern char *(*R7572[])();
extern char *(*R6147[])();
extern char *(*R5884[])();
extern char *(*R5726[])();
extern char *(*R7754[])();
extern char *(*R7758[])();
extern char *(*R5858[])();
extern char *(*R5695[])();
extern char *(*R5696[])();
extern char *(*R5697[])();
extern char *(*R7720[])();
extern long O7730[];
extern EIF_TYPE_INDEX Y5824[];
extern EIF_TYPE_INDEX *Y5824_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
