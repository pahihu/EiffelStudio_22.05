/*
 * Code for class XML_STRING_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STRING_INPUT_STREAM}.make */
void F1107_10133 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make", 1106, Current, 0, 1, 14020);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("S\000\000\000T\000\000\000R\000\000\000I\000\000\000N\000\000\000G\000\000\000",6,1544365639);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	F1107_10145(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {XML_STRING_INPUT_STREAM}.make_empty */
void F1107_10134 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_empty", 1106, Current, 0, 0, 14021);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("",0,0);
	F1107_10133(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STRING_INPUT_STREAM}.name */
EIF_REFERENCE F1107_10135 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {XML_STRING_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F1107_10137 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
}


/* {XML_STRING_INPUT_STREAM}.index */
EIF_INTEGER_32 F1107_10139 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("index", 1106, Current, 0, 0, 14008);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_) - ((EIF_INTEGER_32) 1L));
}

/* {XML_STRING_INPUT_STREAM}.line */
EIF_INTEGER_32 F1107_10140 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_3_);
}


/* {XML_STRING_INPUT_STREAM}.column */
EIF_INTEGER_32 F1107_10141 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_2_);
}


/* {XML_STRING_INPUT_STREAM}.last_character */
EIF_CHARACTER_8 F1107_10142 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
}


/* {XML_STRING_INPUT_STREAM}.set_name */
void F1107_10143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_name", 1106, Current, 0, 1, 14012);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {XML_STRING_INPUT_STREAM}.read_character */
void F1107_10144 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character", 1106, Current, 1, 0, 14013);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(tr1))-845])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_)));
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_))++;
		RTHOOK(5);
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) '\012')) {
			RTHOOK(6);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_3_))++;
			RTHOOK(7);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(8);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_2_))++;
		}
		RTHOOK(9);
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) loc1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {XML_STRING_INPUT_STREAM}.start */
void F1107_10145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start", 1106, Current, 0, 0, 14014);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_1_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
