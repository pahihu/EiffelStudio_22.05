/*
 * Code for class CONF_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co515.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_GROUP}.make */
void F1163_10611 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("make", 1162, Current, 0, 3, 16033);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + O8348[dtype-1162]) = (EIF_REFERENCE) arg3;
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7553[Dtype(RTCW(arg1))-1094])(arg1);
	F1163_10652(Current, tr1);
	RTHOOK(3);
	F1163_10654(Current, arg2);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current + O8333[dtype-1162]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.classes_set */
EIF_BOOLEAN F1163_10614 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("classes_set", 1162, Current, 0, 0, 16036);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8350[Dtype(Current)-1162]) != NULL);
}

/* {CONF_GROUP}.is_library */
static EIF_BOOLEAN F1163_10616_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_library", 1162, Current, 0, 0, 16038);
	RTGC;
	RTOSP (10616);
	RTOSE (10616);
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
#undef Result
}

EIF_BOOLEAN F1163_10616 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10616,F1163_10616_body,(Current));
}

/* {CONF_GROUP}.is_assembly */
static EIF_BOOLEAN F1163_10618_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_assembly", 1162, Current, 0, 0, 16040);
	RTGC;
	RTOSP (10618);
	RTOSE (10618);
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
#undef Result
}

EIF_BOOLEAN F1163_10618 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10618,F1163_10618_body,(Current));
}

/* {CONF_GROUP}.is_test_cluster */
static EIF_BOOLEAN F1163_10621_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_test_cluster", 1162, Current, 0, 0, 16043);
	RTGC;
	RTOSP (10621);
	RTOSE (10621);
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
#undef Result
}

EIF_BOOLEAN F1163_10621 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10621,F1163_10621_body,(Current));
}

/* {CONF_GROUP}.is_used_in_library */
EIF_BOOLEAN F1163_10623 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_used_in_library", 1162, Current, 1, 0, 16045);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O8348[dtype-1162]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_8_);
		tr2 = *(EIF_REFERENCE *)(Current + O8348[dtype-1162]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_8_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.classes */
EIF_REFERENCE F1163_10632 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8350[Dtype(Current)-1162]);
}


/* {CONF_GROUP}.hash_code */
EIF_INTEGER_32 F1163_10633 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1162, Current, 0, 0, 16055);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8392[dtype-1162]) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O8344[dtype-1162]);
		ti4_1 = F1091_9538(RTCW(tr1));
		*(EIF_INTEGER_32 *)(Current + O8392[dtype-1162]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O8392[dtype-1162]);
}

/* {CONF_GROUP}.default_options */
EIF_REFERENCE F1163_10641 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("default_options", 1162, Current, 0, 0, 16058);
	RTGC;
	RTHOOK(1);
	tr2 = F1163_10648(Current);
	tr1 = RTLNS(eif_new_type(978, 0x01).id, 978, _OBJSIZ_12_18_0_0_0_0_0_0_);
	Result = F979_8157(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.class_by_name */
EIF_REFERENCE F1163_10642 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("class_by_name", 1162, Current, 2, 2, 16059);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1107,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 943, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F940_7723(RTCW(Result));
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8350[Dtype(Current)-1162]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F846_7440(loc1, arg1);
		loc2 = tr1;
		tb2 = EIF_TEST(loc2);
	}
	if (tb2) {
		tb2 = (RTNA((loc2)), ((EIF_BOOLEAN) 0));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F944_7790(RTCW(Result), loc2);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.name_by_class */
EIF_REFERENCE F1163_10643 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTEAA("name_by_class", 1162, Current, 4, 2, 16060);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1090,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 943, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F940_7723(RTCW(Result));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O8350[dtype-1162]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		loc1 = *(EIF_REFERENCE *)(Current + O8393[dtype-1162]);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {845,0xFF01,1090,0xFF01,1107,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNSMART(typres0.id);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_7_4_0_6_);
			F846_7434(RTCW(loc1), ti4_1);
			RTHOOK(6);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O8393[dtype-1162]) = (EIF_REFERENCE) loc1;
			RTHOOK(7);
			loc3 = F846_7449(loc2);
			for (;;) {
				tb1 = F540_7116(loc3);
				if (tb1) break;
				RTHOOK(8);
				tr1 = F540_7114(loc3);
				tr2 = F540_7113(loc3);
				F846_7481(RTCW(loc1), tr1, tr2);
				RTHOOK(9);
				F540_7117(loc3);
			}
		}
		RTHOOK(10);
		tr1 = F846_7440(RTCW(loc1), arg1);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(11);
			F801_7408(RTCW(Result), loc4);
		}
	} else {
		
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.namespace */
EIF_REFERENCE F1163_10648 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("namespace", 1162, Current, 0, 0, 16064);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O8348[Dtype(Current)-1162]);
	Result = F1113_10324(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.is_less */
EIF_BOOLEAN F1163_10649 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_less", 1162, Current, 0, 1, 16065);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O8344[Dtype(Current)-1162]);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + O8344[Dtype(arg1)-1162]);
	Result = F1094_9688(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.set_name */
void F1163_10652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_name", 1162, Current, 0, 1, 16068);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O8344[Dtype(Current)-1162]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_GROUP}.set_description */
void F1163_10653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_description", 1162, Current, 1, 1, 16069);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1096_9735(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8345[dtype-1162]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		*(EIF_REFERENCE *)(Current + O8345[dtype-1162]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.set_location */
void F1163_10654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_location", 1162, Current, 0, 1, 16070);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O8346[Dtype(Current)-1162]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_GROUP}.set_readonly */
void F1163_10655 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_readonly", 1162, Current, 0, 1, 16071);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O8381[dtype-1162]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O8395[dtype-1162]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.merge_options */
void F1163_10658 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("merge_options", 1162, Current, 1, 1, 16074);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O8382[dtype-1162]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6520[Dtype(loc1)-978])(loc1, arg1);
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O8382[dtype-1162]) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.add_class_options */
void F1163_10660 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("add_class_options", 1162, Current, 2, 2, 16076);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O8384[dtype-1162]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {854,0xFF01,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F855_7558(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8384[dtype-1162]) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F846_7481(RTCW(loc1), arg1, arg2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.add_condition */
void F1163_10661 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("add_condition", 1162, Current, 1, 1, 16077);
	RTGC;
	RTHOOK(1);
	F402_5832(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O8348[Dtype(Current)-1162]);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(3);
		F1321_13559(RTCW(arg1), loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.process */
void F1163_10667 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1162, Current, 0, 1, 16083);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (CONF_VISITOR.process_group) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.class_type */
EIF_REFERENCE F1163_10679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("class_type", 1162, Current, 0, 0, 16095);
	RTGC;
	RTHOOK(1);
	RTCT0("False", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit515 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
