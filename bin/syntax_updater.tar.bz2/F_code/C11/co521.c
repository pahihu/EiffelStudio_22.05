/*
 * Code for class CONF_VIRTUAL_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co521.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VIRTUAL_GROUP}.set_name_prefix */
void F1169_10746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_name_prefix", 1168, Current, 1, 1, 16162);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1094_9661(RTCW(loc1), arg1);
		RTHOOK(3);
		F1096_9816(RTCW(loc1));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8436[dtype-1168]) = (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(5);
		*(EIF_REFERENCE *)(Current + O8436[dtype-1168]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_VIRTUAL_GROUP}.add_renaming */
void F1169_10748 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("add_renaming", 1168, Current, 2, 2, 16164);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O8435[dtype-1168]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {854,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F846_7435(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8435[dtype-1168]) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F846_7481(RTCW(loc1), arg2, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
