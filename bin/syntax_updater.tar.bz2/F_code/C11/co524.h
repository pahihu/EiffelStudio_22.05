
#ifndef _C11_co524_
#define _C11_co524_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1172_10795(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1172_10798(EIF_REFERENCE, EIF_REFERENCE);
extern void F1172_10799(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit524(void);
extern void F1163_10652(EIF_REFERENCE, EIF_REFERENCE);
extern void F1285_12309(EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_10654(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R7553[])();

#ifdef __cplusplus
}
#endif

#endif
