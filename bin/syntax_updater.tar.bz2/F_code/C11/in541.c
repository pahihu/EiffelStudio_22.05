/*
 * Code for class INTEGER_8_REF
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in541.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_8_REF}.hash_code */
EIF_INTEGER_32 F1234_11250 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hash_code", 1233, Current, 0, 0, 17424);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	ti4_1 = (EIF_INTEGER_32) ti1_1;
	Result = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti4_1)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.is_less */
EIF_BOOLEAN F1234_11257 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_INTEGER_8 ti1_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_less", 1233, Current, 0, 1, 17431);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	ti1_2 = *(EIF_INTEGER_8 *)(RTCW(arg1)+ _CHROFF_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti1_1 < ti1_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.is_equal */
EIF_BOOLEAN F1234_11258 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_INTEGER_8 ti1_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 1233, Current, 0, 1, 17432);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(RTCW(arg1)+ _CHROFF_0_0_);
	ti1_2 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti1_1 == ti1_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.set_item */
void F1234_11259 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_item", 1233, Current, 0, 1, 17433);
	RTHOOK(1);
	*(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_) = (EIF_INTEGER_8) arg1;
	RTHOOK(3);
	RTEE;
}

/* {INTEGER_8_REF}.plus */
EIF_REFERENCE F1234_11267 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("plus", 1233, Current, 0, 1, 17441);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(RTCW(arg1)+ _CHROFF_0_0_);
	F1234_11259(RTCW(Result), (EIF_INTEGER_8) (*(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_) + ti1_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.opposite */
EIF_REFERENCE F1234_11272 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("opposite", 1233, Current, 0, 0, 17446);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	F1234_11259(RTCW(Result), (EIF_INTEGER_8) -*(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.integer_quotient */
EIF_REFERENCE F1234_11273 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("integer_quotient", 1233, Current, 0, 1, 17447);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(RTCW(arg1)+ _CHROFF_0_0_);
	F1234_11259(RTCW(Result), (EIF_INTEGER_8) (*(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_) / ti1_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.integer_remainder */
EIF_REFERENCE F1234_11274 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("integer_remainder", 1233, Current, 0, 1, 17448);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(RTCW(arg1)+ _CHROFF_0_0_);
	F1234_11259(RTCW(Result), (EIF_INTEGER_8) (*(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_) % ti1_1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.as_natural_8 */
EIF_NATURAL_8 F1234_11280 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_natural_8", 1233, Current, 0, 0, 17454);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	Result = (EIF_NATURAL_8) ti1_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.as_natural_64 */
EIF_NATURAL_64 F1234_11283 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_natural_64", 1233, Current, 0, 0, 17457);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	Result = (EIF_NATURAL_64) ti1_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.as_integer_32 */
EIF_INTEGER_32 F1234_11286 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_integer_32", 1233, Current, 0, 0, 17460);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	Result = (EIF_INTEGER_32) ti1_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.to_natural_8 */
EIF_NATURAL_8 F1234_11288 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_natural_8", 1233, Current, 0, 0, 17462);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) (FUNCTION_CAST(EIF_NATURAL_8, (EIF_REFERENCE)) R8750[Dtype(Current)-1234])(Current);
}

/* {INTEGER_8_REF}.to_natural_64 */
EIF_NATURAL_64 F1234_11291 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_natural_64", 1233, Current, 0, 0, 17465);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) (FUNCTION_CAST(EIF_NATURAL_64, (EIF_REFERENCE)) R8753[Dtype(Current)-1234])(Current);
}

/* {INTEGER_8_REF}.to_integer */
EIF_INTEGER_32 F1234_11294 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_integer", 1233, Current, 0, 0, 17468);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8756[Dtype(Current)-1234])(Current);
}

/* {INTEGER_8_REF}.to_character_8 */
EIF_CHARACTER_8 F1234_11306 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_character_8", 1233, Current, 0, 0, 17480);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	Result = (EIF_CHARACTER_8) ti1_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.bit_shift_right */
EIF_REFERENCE F1234_11314 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("bit_shift_right", 1233, Current, 0, 1, 17488);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_);
	ti1_1 = eif_bit_shift_right(ti1_1,arg1);
	F1234_11259(RTCW(Result), ti1_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_8_REF}.out */
EIF_REFERENCE F1234_11318 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("out", 1233, Current, 0, 0, 17492);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	F1099_9943(RTCW(Result), *(EIF_INTEGER_8 *)(Current+ _CHROFF_0_0_));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
