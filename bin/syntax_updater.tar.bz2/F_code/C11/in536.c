/*
 * Code for class INTEGER_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_32}.is_less */
EIF_BOOLEAN F1230_11122 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1229, Current, 0, 1, 17242);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	Result = F1228_11059(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.plus */
EIF_INTEGER_32 F1230_11123 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1229, Current, 0, 1, 17243);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11069(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.minus */
EIF_INTEGER_32 F1230_11124 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("minus", 1229, Current, 0, 1, 17244);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11070(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.product */
EIF_INTEGER_32 F1230_11125 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1229, Current, 0, 1, 17245);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11071(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.opposite */
EIF_INTEGER_32 F1230_11128 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1229, Current, 0, 0, 17248);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1228_11074(Current);
}

/* {INTEGER_32}.integer_quotient */
EIF_INTEGER_32 F1230_11129 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1229, Current, 0, 1, 17249);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11075(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.integer_remainder */
EIF_INTEGER_32 F1230_11130 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1229, Current, 0, 1, 17250);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11076(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.as_natural_8 */
EIF_NATURAL_8 F1230_11132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1229, Current, 0, 0, 17252);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1228_11082(Current);
}

/* {INTEGER_32}.as_natural_16 */
EIF_NATURAL_16 F1230_11133 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_16", 1229, Current, 0, 0, 17253);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_16) F1228_11083(Current);
}

/* {INTEGER_32}.as_natural_32 */
EIF_NATURAL_32 F1230_11134 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1229, Current, 0, 0, 17254);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1228_11084(Current);
}

/* {INTEGER_32}.as_natural_64 */
EIF_NATURAL_64 F1230_11135 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1229, Current, 0, 0, 17255);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1228_11085(Current);
}

/* {INTEGER_32}.as_integer_64 */
EIF_INTEGER_64 F1230_11139 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_64", 1229, Current, 0, 0, 17259);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1228_11089(Current);
}

/* {INTEGER_32}.to_double */
EIF_REAL_64 F1230_11141 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_double", 1229, Current, 0, 0, 17261);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1228_11100(Current);
}

/* {INTEGER_32}.to_character_8 */
EIF_CHARACTER_8 F1230_11142 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1229, Current, 0, 0, 17262);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1228_11108(Current);
}

/* {INTEGER_32}.to_character_32 */
EIF_CHARACTER_32 F1230_11143 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 1229, Current, 0, 0, 17263);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F1228_11109(Current);
}

/* {INTEGER_32}.bit_and */
EIF_INTEGER_32 F1230_11144 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1229, Current, 0, 1, 17264);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11110(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_or */
EIF_INTEGER_32 F1230_11145 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 1229, Current, 0, 1, 17265);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11111(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_xor */
EIF_INTEGER_32 F1230_11146 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_xor", 1229, Current, 0, 1, 17266);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1229, 0x00).id, 1229, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1228_11112(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_shift_left */
EIF_INTEGER_32 F1230_11148 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_left", 1229, Current, 0, 1, 17240);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1228_11115(Current, arg1);
}

/* {INTEGER_32}.bit_shift_right */
EIF_INTEGER_32 F1230_11149 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1229, Current, 0, 1, 17241);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1228_11116(Current, arg1);
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
