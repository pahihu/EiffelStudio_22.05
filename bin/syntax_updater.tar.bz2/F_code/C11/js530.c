/*
 * Code for class JSON_NUMBER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js530.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NUMBER}.make_integer */
void F1223_10917 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_integer", 1222, Current, 0, 1, 17023);
	RTGC;
	RTHOOK(1);
	tr1 = eif_out__i8_s1(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {JSON_NUMBER}.make_real */
void F1223_10919 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_real", 1222, Current, 0, 1, 17025);
	RTGC;
	RTHOOK(1);
	tb1 = eif_is_nan_real_64 (arg1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTOSCF(10921,F1223_10921, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tb1 = eif_is_negative_infinity_real_64 (arg1);
		if (tb1) {
			RTHOOK(4);
			tr1 = RTOSCF(10922,F1223_10922, (Current));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tb1 = eif_is_positive_infinity_real_64 (arg1);
			if (tb1) {
				RTHOOK(6);
				tr1 = RTOSCF(10923,F1223_10923, (Current));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			} else {
				RTHOOK(7);
				tr1 = eif_out__r8_s1(arg1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {JSON_NUMBER}.nan_real_value */
static EIF_REFERENCE F1223_10921_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("nan_real_value", 1222, Current, 0, 0, 17027);
	RTGC;
	RTOSP (10921);
#define Result RTOSR(10921)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("NaN",3,5136718);
	F1097_9828(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10921);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1223_10921 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10921,F1223_10921_body,(Current));
}

/* {JSON_NUMBER}.negative_infinity_real_value */
static EIF_REFERENCE F1223_10922_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("negative_infinity_real_value", 1222, Current, 0, 0, 17028);
	RTGC;
	RTOSP (10922);
#define Result RTOSR(10922)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("-Infinity",9,2107636601);
	F1097_9828(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10922);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1223_10922 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10922,F1223_10922_body,(Current));
}

/* {JSON_NUMBER}.positive_infinity_real_value */
static EIF_REFERENCE F1223_10923_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("positive_infinity_real_value", 1222, Current, 0, 0, 17029);
	RTGC;
	RTOSP (10923);
#define Result RTOSR(10923)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Infinity",8,1600908409);
	F1097_9828(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10923);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1223_10923 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10923,F1223_10923_body,(Current));
}

/* {JSON_NUMBER}.hash_code */
EIF_INTEGER_32 F1223_10926 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1222, Current, 0, 0, 17032);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7172[Dtype(RTCW(tr1))-1039])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NUMBER}.representation */
EIF_REFERENCE F1223_10927 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("representation", 1222, Current, 1, 0, 17033);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	tb1 = '\0';
	if (F1223_10935(Current)) {
		tb2 = '\01';
		tb3 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == RTOSCF(10921,F1223_10921, (Current)))) {
			tb3 = (EIF_BOOLEAN)(loc1 == RTOSCF(10922,F1223_10922, (Current)));
		}
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(loc1 == RTOSCF(10923,F1223_10923, (Current)));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1221_10883(RTCW(tr1));
	} else {
		RTHOOK(5);
		tr1 = F1091_9582(RTCW(loc1));
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {JSON_NUMBER}.is_real */
EIF_BOOLEAN F1223_10935 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_real", 1222, Current, 0, 0, 17014);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) == ((EIF_INTEGER_32) 2L));
}

/* {JSON_NUMBER}.is_equal */
EIF_BOOLEAN F1223_10937 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 1222, Current, 0, 1, 17016);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-1])(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
