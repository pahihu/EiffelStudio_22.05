/*
 * Code for class CONF_TEST_CLUSTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TEST_CLUSTER}.is_test_cluster */
static EIF_BOOLEAN F1167_10732_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("is_test_cluster", 1166, Current, 0, 0, 16148);
	RTOSP (10732);
#define Result RTOSR(10732)
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (10732);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1167_10732 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10732,F1167_10732_body,(Current));
}

/* {CONF_TEST_CLUSTER}.process */
void F1167_10733 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1166, Current, 0, 1, 16149);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (CONF_VISITOR.process_test_cluster) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F1166_10724(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
