
#ifndef _C11_js528_
#define _C11_js528_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1221_10882(EIF_REFERENCE);
extern EIF_REFERENCE F1221_10883(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 10886)


extern EIF_REFERENCE F1221_10886(EIF_REFERENCE);
extern void EIF_Minit528(void);
extern char *(*R7172[])();

#ifdef __cplusplus
}
#endif

#endif
