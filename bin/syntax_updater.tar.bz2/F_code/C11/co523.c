/*
 * Code for class CONF_LIBRARY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LIBRARY}.make */
void F1171_10777 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("make", 1170, Current, 0, 3, 16202);
	RTGC;
	RTHOOK(1);
	F1163_10611(Current, arg1, arg2, arg3);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O8395[Dtype(Current)-1162]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LIBRARY}.is_library */
EIF_BOOLEAN F1171_10778 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {CONF_LIBRARY}.is_readonly */
EIF_BOOLEAN F1171_10779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_readonly", 1170, Current, 1, 0, 16204);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O8381[dtype-1162])) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current + O8395[dtype-1162]);
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_8_);
			Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_16_3_);
		} else {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LIBRARY}.mapping */
EIF_REFERENCE F1171_10782 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("mapping", 1170, Current, 1, 0, 16207);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1113_10376(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,854,0xFF01,1093,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 854, _OBJSIZ_7_4_0_7_0_0_0_0_);
		}
		F846_7435(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_LIBRARY}.class_by_name */
EIF_REFERENCE F1171_10784 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTEAA("class_by_name", 1170, Current, 5, 2, 16209);
	RTGC;
	RTHOOK(1);
	loc2 = F1171_10782(Current);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = F846_7440(RTCW(loc2), arg1);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) loc3;
	} else {
		RTHOOK(4);
		loc1 = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1107,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 943, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F940_7723(RTCW(Result));
	RTHOOK(6);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = F846_7440(loc4, loc1);
		loc5 = tr1;
		tb2 = EIF_TEST(loc5);
	}
	if (tb2) {
		tb2 = (RTNA((loc5)), ((EIF_BOOLEAN) 0));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(7);
		F944_7790(RTCW(Result), loc5);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LIBRARY}.set_use_application_options */
void F1171_10790 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_use_application_options", 1170, Current, 0, 1, 16196);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O8452[Dtype(Current)-1170]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_LIBRARY}.process */
void F1171_10792 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1170, Current, 0, 1, 16198);
	RTGC;
	RTHOOK(1);
	F1163_10667(Current, arg1);
	RTHOOK(2);
	F1285_12308(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
