/*
 * Code for class INTEGER_16
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in539.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_16}.is_less */
EIF_BOOLEAN F1233_11221 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1232, Current, 0, 1, 17367);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
	*(EIF_INTEGER_16 *)tr1 = arg1;
	Result = F1231_11158(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_16}.plus */
EIF_INTEGER_16 F1233_11222 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1232, Current, 0, 1, 17368);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
	*(EIF_INTEGER_16 *)tr1 = arg1;
	tr1 = F1231_11168(Current, tr1);
	Result = *(EIF_INTEGER_16 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_16}.opposite */
EIF_INTEGER_16 F1233_11227 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1232, Current, 0, 0, 17373);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_16 *)F1231_11173(Current);
}

/* {INTEGER_16}.integer_quotient */
EIF_INTEGER_16 F1233_11228 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1232, Current, 0, 1, 17374);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
	*(EIF_INTEGER_16 *)tr1 = arg1;
	tr1 = F1231_11174(Current, tr1);
	Result = *(EIF_INTEGER_16 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_16}.integer_remainder */
EIF_INTEGER_16 F1233_11229 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1232, Current, 0, 1, 17375);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1232, 0x00).id, 1232, _OBJSIZ_0_0_1_0_0_0_0_0_);
	*(EIF_INTEGER_16 *)tr1 = arg1;
	tr1 = F1231_11175(Current, tr1);
	Result = *(EIF_INTEGER_16 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_16}.as_natural_64 */
EIF_NATURAL_64 F1233_11234 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1232, Current, 0, 0, 17380);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1231_11184(Current);
}

/* {INTEGER_16}.as_integer_32 */
EIF_INTEGER_32 F1233_11237 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1232, Current, 0, 0, 17383);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1231_11187(Current);
}

/* {INTEGER_16}.to_character_8 */
EIF_CHARACTER_8 F1233_11241 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1232, Current, 0, 0, 17387);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1231_11207(Current);
}

void EIF_Minit539 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
