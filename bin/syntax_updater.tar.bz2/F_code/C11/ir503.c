/*
 * Code for class IRON_WEB_REPOSITORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_WEB_REPOSITORY}.make */
void F1105_10092 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("make", 1104, Current, 2, 2, 13964);
	RTGC;
	RTHOOK(1);
	tr1 = F1_14(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	RTHOOK(3);
	tr1 = RTMS_EX_H("/",1,47);
	tb1 = F1097_9863(RTCW(loc1), tr1);
	if (tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O7730[Dtype(loc1)-1096]);
		tr2 = F1091_9610(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		F1339_14146(RTCW(tr1), tr2);
	}
	RTHOOK(5);
	loc2 = arg2;
	loc2 = RTRV(eif_new_type(1097, 1),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(6);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(7);
		tr1 = RTLNSMART(eif_new_type(1097, 1).id);
		F1097_9828(RTCW(tr1), arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1338, 1).id);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F1339_14139(RTCW(tr2));
	tr3 = RTMS_EX_H("/",1,47);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7720[Dtype(RTCW(tr2))-1097])(tr2, tr3);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7720[Dtype(RTCW(tr2))-1097])(tr2, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1339_14105(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	F602_7179(Current);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.make_from_version_uri */
void F1105_10093 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,Current);
	RTLIU(8);
	
	RTEAA("make_from_version_uri", 1104, Current, 5, 1, 13965);
	RTGC;
	RTHOOK(1);
	tr1 = F1339_14125(RTCW(arg1));
	loc1 = F1_14(tr1);
	RTHOOK(2);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6147[Dtype(RTCW(loc1))-939])(loc1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5858[Dtype(RTCW(loc1))-939])(loc1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5884[Dtype(RTCW(loc1))-796])(loc1);
	RTHOOK(5);
	loc3 = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(loc3));
	RTHOOK(6);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5942[Dtype(RTCW(loc1))-796])(loc1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(7);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5726[Dtype(RTCW(loc1))-501])(loc1);
		loc5 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5696[Dtype(loc5)-472])(loc5);
			if (tb1) break;
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(loc3))-1098])(loc3, (EIF_CHARACTER_8) '/');
			RTHOOK(9);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5695[Dtype(loc5)-472])(loc5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(loc3))-1098])(loc3, tr1);
			RTHOOK(10);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5697[Dtype(loc5)-472])(loc5);
		}
	}
	RTHOOK(11);
	loc4 = RTLNS(eif_new_type(1338, 0x01).id, 1338, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = F1339_14139(RTCW(arg1));
	F1339_14105(RTCW(loc4), tr1);
	RTHOOK(12);
	F1339_14146(RTCW(loc4), loc3);
	RTHOOK(13);
	tr1 = RTMS_EX_H("/",1,47);
	tb2 = F1097_9863(RTCW(loc2), tr1);
	if (tb2) {
		RTHOOK(14);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O7730[Dtype(loc2)-1096]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7572[Dtype(RTCW(loc2))-1094])(loc2, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(15);
	F1105_10092(Current, loc4, loc2);
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.create_available_packages */
void F1105_10094 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_available_packages", 1104, Current, 0, 0, 13966);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_final_id(Y5824,Y5824_gen_type,Dftype(Current),601).id);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6201[Dtype(RTCW(tr1))-949])(tr1, ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.location */
EIF_REFERENCE F1105_10095 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {IRON_WEB_REPOSITORY}.is_same_repository */
EIF_BOOLEAN F1105_10100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("is_same_repository", 1104, Current, 1, 1, 13972);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1104, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F602_7183(Current);
		tr2 = F602_7183(loc1);
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7715[Dtype(RTCW(tr1))-1097])(tr1, tr2);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
