/*
 * Code for class CONF_ASSEMBLY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co522.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ASSEMBLY}.make_from_gac */
void F1170_10749 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg6);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("make_from_gac", 1169, Current, 0, 6, 16166);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg6;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7553[Dtype(RTCW(arg1))-1094])(arg1);
	F1163_10652(Current, tr1);
	RTHOOK(4);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg2;
	RTHOOK(5);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg3;
	RTHOOK(6);
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg4;
	RTHOOK(7);
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg5;
	RTHOOK(8);
	tr1 = RTLNSMART(eif_final_id(Y8346,Y8346_gen_type,Dftype(Current),1162).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1314_12916(RTCW(tr1), tr2, arg6);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {CONF_ASSEMBLY}.classes_set */
EIF_BOOLEAN F1170_10750 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("classes_set", 1169, Current, 0, 0, 16167);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL);
}

/* {CONF_ASSEMBLY}.is_assembly */
static EIF_BOOLEAN F1170_10751_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("is_assembly", 1169, Current, 0, 0, 16168);
	RTOSP (10751);
#define Result RTOSR(10751)
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (10751);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1170_10751 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10751,F1170_10751_body,(Current));
}

/* {CONF_ASSEMBLY}.is_readonly */
EIF_BOOLEAN F1170_10754 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {CONF_ASSEMBLY}.accessible_groups */
EIF_REFERENCE F1170_10761 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("accessible_groups", 1169, Current, 1, 0, 16178);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = (RTNA((loc1)), ((EIF_REFERENCE) 0));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1266,0xFF01,1162,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1266, _OBJSIZ_4_1_0_5_0_0_0_0_);
		}
		F1267_11963(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_ASSEMBLY}.class_by_name */
EIF_REFERENCE F1170_10763 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("class_by_name", 1169, Current, 2, 2, 16180);
	RTGC;
	RTHOOK(1);
	Result = F1163_10642(Current, arg1, arg2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		loc2 = F1267_11974(RTCV(F1170_10761(Current)));
		for (;;) {
			tb1 = F473_6970(loc2);
			if (tb1) break;
			RTHOOK(4);
			loc1 = F473_6969(loc2);
			RTHOOK(5);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8332[Dtype(RTCW(loc1))-1165])(loc1);
			if (tb2) {
				RTHOOK(6);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8359[Dtype(RTCW(loc1))-1165])(loc1, arg1, (EIF_BOOLEAN) 0);
				F890_7683(RTCW(Result), tr1);
			}
			RTHOOK(7);
			F473_6971(loc2);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ASSEMBLY}.name_by_class */
EIF_REFERENCE F1170_10764 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("name_by_class", 1169, Current, 2, 2, 16181);
	RTGC;
	RTHOOK(1);
	Result = F1163_10643(Current, arg1, arg2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		loc2 = F1170_10761(Current);
		RTHOOK(4);
		F1267_12009(RTCW(loc2));
		for (;;) {
			RTHOOK(5);
			tb1 = F1267_12012(RTCW(loc2));
			if (tb1) break;
			RTHOOK(6);
			loc1 = F1267_12014(RTCW(loc2));
			RTHOOK(7);
			F1267_12010(RTCW(loc2));
			RTHOOK(8);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8332[Dtype(RTCW(loc1))-1165])(loc1);
			if (tb2) {
				RTHOOK(9);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8360[Dtype(RTCW(loc1))-1165])(loc1, arg1, (EIF_BOOLEAN) 0);
				F890_7683(RTCW(Result), tr1);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ASSEMBLY}.process */
void F1170_10776 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1169, Current, 0, 1, 16193);
	RTGC;
	RTHOOK(1);
	F1163_10667(Current, arg1);
	RTHOOK(2);
	F1285_12307(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
