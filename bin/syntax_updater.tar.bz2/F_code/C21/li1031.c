/*
 * Code for class LIST [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1031.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST}.is_equal */
EIF_BOOLEAN F916_7702 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("is_equal", 915, Current, 2, 1, 10725);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		Result = '\0';
		tb1 = '\0';
		tb2 = F761_7351(RTCW(arg1));
		if ((EIF_BOOLEAN)(F761_7351(Current) == tb2)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5838[Dtype(arg1)-602]);
			tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5838[dtype-602]) == tb2);
		}
		if (tb1) {
			ti4_1 = F952_7864(RTCW(arg1));
			Result = (EIF_BOOLEAN)(F952_7864(Current) == ti4_1);
		}
		RTHOOK(5);
		tb1 = '\0';
		if (Result) {
			tb1 = (EIF_BOOLEAN) !F761_7351(Current);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = F952_7854(Current);
			loc1 = tr1;
			if ((EIF_TRUE)) {
				tr1 = F952_7854(RTCW(arg1));
				loc2 = tr1;
				tb1 = (EIF_TRUE);
			}
			if (tb1) {
				RTHOOK(7);
				F952_7874(Current);
				RTHOOK(8);
				F952_7874(RTCW(arg1));
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!F916_7703(Current)) {
						tb1 = (EIF_BOOLEAN) !Result;
					}
					if (tb1) break;
					RTHOOK(10);
					if (*(EIF_BOOLEAN *)(Current + O5838[dtype-602])) {
						RTHOOK(11);
						tu1_1 = F952_7848(Current);
						tu1_2 = F952_7848(RTCW(arg1));
						Result = (EIF_BOOLEAN) (tu1_1 == tu1_2);
					} else {
						RTHOOK(12);
						tu1_1 = F952_7848(Current);
						tu1_2 = F952_7848(RTCW(arg1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 == tu1_2);
					}
					RTHOOK(13);
					F952_7876(Current);
					RTHOOK(14);
					F952_7876(RTCW(arg1));
				}
				RTHOOK(15);
				F952_7879(Current, loc1);
				RTHOOK(16);
				F952_7879(RTCW(arg1), loc2);
			} else {
				
			}
		} else {
			RTHOOK(18);
			tb2 = '\0';
			tb3 = '\0';
			if (F761_7351(Current)) {
				tb4 = F761_7351(RTCW(arg1));
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5838[Dtype(arg1)-602]);
				tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5838[dtype-602]) == tb3);
			}
			if (tb2) {
				RTHOOK(19);
				RTHOOK(20);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.after */
EIF_BOOLEAN F916_7703 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("after", 915, Current, 0, 0, 10726);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_2 = F952_7864(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LIST}.before */
EIF_BOOLEAN F916_7704 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("before", 915, Current, 0, 0, 10727);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit1031 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
