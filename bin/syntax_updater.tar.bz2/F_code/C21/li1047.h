
#ifndef _C21_li1047_
#define _C21_li1047_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F632_7210(EIF_REFERENCE, EIF_INTEGER_32);
extern void F632_7212(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F632_7216(EIF_REFERENCE);
extern EIF_BOOLEAN F632_7218(EIF_REFERENCE);
extern EIF_REFERENCE F632_7225(EIF_REFERENCE);
extern void EIF_Minit1047(void);
extern char *(*R5844[])();
extern char *(*R5845[])();
extern char *(*R5846[])();
extern char *(*R5836[])();
extern char *(*R5852[])();
extern char *(*R5857[])();
extern char *(*R5859[])();
extern long O5838[];

#ifdef __cplusplus
}
#endif

#endif
