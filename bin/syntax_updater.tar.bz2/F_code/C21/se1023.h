
#ifndef _C21_se1023_
#define _C21_se1023_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F803_7406(EIF_REFERENCE);
extern void F803_7408(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1023(void);
extern EIF_BOOLEAN F892_7679(EIF_REFERENCE);
extern void F952_7884(EIF_REFERENCE, EIF_NATURAL_8);

#ifdef __cplusplus
}
#endif

#endif
