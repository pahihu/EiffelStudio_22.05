
#ifndef _C21_ar1035_
#define _C21_ar1035_

#ifdef __cplusplus
extern "C" {
#endif

extern void F569_7163(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F569_7164(EIF_REFERENCE);
extern EIF_REFERENCE F569_7165(EIF_REFERENCE);
extern EIF_REFERENCE F569_7167(EIF_REFERENCE);
extern EIF_INTEGER_32 F569_7168(EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern EIF_REFERENCE F953_7847(EIF_REFERENCE);
extern EIF_INTEGER_32 F953_7866(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5698[];
extern EIF_TYPE_INDEX *Y5698_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
