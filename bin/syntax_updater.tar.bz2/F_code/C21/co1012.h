
#ifndef _C21_co1012_
#define _C21_co1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F655_7235(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern void F952_7874(EIF_REFERENCE);
extern void F952_7876(EIF_REFERENCE);
extern EIF_NATURAL_8 F952_7848(EIF_REFERENCE);
extern EIF_BOOLEAN F892_7679(EIF_REFERENCE);
extern char *(*R5842[])();
extern char *(*R5862[])();
extern char *(*R5866[])();

#ifdef __cplusplus
}
#endif

#endif
