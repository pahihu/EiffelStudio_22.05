
#ifndef _C21_to1032_
#define _C21_to1032_

#ifdef __cplusplus
extern "C" {
#endif

extern void F415_5890(EIF_REFERENCE, EIF_INTEGER_32);
extern void F415_5891(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F415_5897(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1032(void);
extern void F1153_10563(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4971[];
extern EIF_TYPE_INDEX *Y4971_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
