/*
 * Code for class READABLE_INDEXABLE_ITERATION_CURSOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re1040.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.make */
void F533_7091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("make", 532, Current, 1, 1, 7194);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(41, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tu4_1 = *(EIF_NATURAL_32 *)(loc1);
		*(EIF_NATURAL_32 *)(Current + O5795[dtype-527]) = (EIF_NATURAL_32) tu4_1;
	} else {
		RTHOOK(4);
		*(EIF_NATURAL_32 *)(Current + O5795[dtype-527]) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current + O5800[dtype-527]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(6);
	*(EIF_BOOLEAN *)(Current + O5799[dtype-527]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.target_index */
EIF_INTEGER_32 F533_7093 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5803[Dtype(Current)-527]);
}


/* {READABLE_INDEXABLE_ITERATION_CURSOR}.first_index */
EIF_INTEGER_32 F533_7094 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5802[Dtype(Current)-527]);
}


/* {READABLE_INDEXABLE_ITERATION_CURSOR}.last_index */
EIF_INTEGER_32 F533_7095 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5801[Dtype(Current)-527]);
}


/* {READABLE_INDEXABLE_ITERATION_CURSOR}.step */
EIF_INTEGER_32 F533_7096 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5800[Dtype(Current)-527]);
}


/* {READABLE_INDEXABLE_ITERATION_CURSOR}.new_cursor */
EIF_REFERENCE F533_7097 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 532, Current, 0, 0, 7200);
	RTGC;
	RTHOOK(1);
	Result = F1_14(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5791[Dtype(RTCW(Result))-527])(Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.after */
EIF_BOOLEAN F533_7103 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("after", 532, Current, 0, 0, 7184);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN) !F533_7105(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5983[Dtype(RTCW(tr1))-845])(tr1, *(EIF_INTEGER_32 *)(Current + O5803[Dtype(Current)-527]));
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.is_reversed */
EIF_BOOLEAN F533_7104 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O5799[Dtype(Current)-527]);
}


/* {READABLE_INDEXABLE_ITERATION_CURSOR}.is_valid */
EIF_BOOLEAN F533_7105 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_valid", 532, Current, 1, 0, 7186);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(41, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tu4_1 = *(EIF_NATURAL_32 *)(loc1);
		Result = (EIF_BOOLEAN)(tu4_1 == *(EIF_NATURAL_32 *)(Current + O5795[Dtype(Current)-527]));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.is_last */
EIF_BOOLEAN F533_7107 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_last", 532, Current, 0, 0, 7188);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5803[dtype-527]) == *(EIF_INTEGER_32 *)(Current + O5801[dtype-527]))) {
		Result = F533_7105(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.start */
void F533_7110 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("start", 532, Current, 1, 0, 7191);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current + O5799[dtype-527])) {
		RTHOOK(3);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5981[Dtype(RTCW(loc1))-845])(loc1);
		*(EIF_INTEGER_32 *)(Current + O5802[dtype-527]) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(4);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5980[Dtype(RTCW(loc1))-845])(loc1);
		*(EIF_INTEGER_32 *)(Current + O5801[dtype-527]) = (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(5);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5981[Dtype(RTCW(loc1))-845])(loc1);
		*(EIF_INTEGER_32 *)(Current + O5801[dtype-527]) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(6);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5980[Dtype(RTCW(loc1))-845])(loc1);
		*(EIF_INTEGER_32 *)(Current + O5802[dtype-527]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5803[dtype-527]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5802[dtype-527]);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.forth */
void F533_7111 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("forth", 532, Current, 0, 0, 7192);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5799[dtype-527])) {
		RTHOOK(2);
		(*(EIF_INTEGER_32 *)(Current + O5803[dtype-527])) -= *(EIF_INTEGER_32 *)(Current + O5800[dtype-527]);
	} else {
		RTHOOK(3);
		(*(EIF_INTEGER_32 *)(Current + O5803[dtype-527])) += *(EIF_INTEGER_32 *)(Current + O5800[dtype-527]);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {READABLE_INDEXABLE_ITERATION_CURSOR}.target */
EIF_REFERENCE F533_7112 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


void EIF_Minit1040 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
