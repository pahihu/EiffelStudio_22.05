
#ifndef _C21_ar1033_
#define _C21_ar1033_

#ifdef __cplusplus
extern "C" {
#endif

extern void F580_7169(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F580_7170(EIF_REFERENCE);
extern EIF_REFERENCE F580_7171(EIF_REFERENCE);
extern EIF_REFERENCE F580_7173(EIF_REFERENCE);
extern EIF_INTEGER_32 F580_7174(EIF_REFERENCE);
extern void EIF_Minit1033(void);
extern EIF_TYPE_INDEX Y5698[];
extern EIF_TYPE_INDEX *Y5698_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
