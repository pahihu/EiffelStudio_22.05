
#ifndef _C21_re1014_
#define _C21_re1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F783_7357(EIF_REFERENCE);
extern void F783_7359(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern char *(*R5943[])();
extern char *(*R5949[])();

#ifdef __cplusplus
}
#endif

#endif
