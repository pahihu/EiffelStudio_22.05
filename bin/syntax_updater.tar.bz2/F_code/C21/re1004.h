
#ifndef _C21_re1004_
#define _C21_re1004_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F838_7429(EIF_REFERENCE);
extern void EIF_Minit1004(void);
extern void F532_7091(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5791[])();
extern EIF_TYPE_INDEX Y5727[];
extern EIF_TYPE_INDEX *Y5727_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
