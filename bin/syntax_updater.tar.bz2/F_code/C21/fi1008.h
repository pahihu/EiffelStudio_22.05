
#ifndef _C21_fi1008_
#define _C21_fi1008_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F761_7351(EIF_REFERENCE);
extern void EIF_Minit1008(void);
extern char *(*R5942[])();

#ifdef __cplusplus
}
#endif

#endif
