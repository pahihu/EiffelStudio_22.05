
#ifndef _C21_co1049_
#define _C21_co1049_

#ifdef __cplusplus
extern "C" {
#endif

extern void F608_7199(EIF_REFERENCE);
extern EIF_INTEGER_32 F608_7202(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1049(void);
extern char *(*R5942[])();
extern char *(*R5980[])();
extern char *(*R5981[])();
extern long O5838[];
extern EIF_TYPE_INDEX Y5727[];
extern EIF_TYPE_INDEX *Y5727_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
