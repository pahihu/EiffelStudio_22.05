
#ifndef _C21_bi1024_
#define _C21_bi1024_

#ifdef __cplusplus
extern "C" {
#endif

extern void F641_7229(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1024(void);
extern void F631_7212(EIF_REFERENCE, EIF_NATURAL_8);
extern void F952_7876(EIF_REFERENCE);
extern EIF_BOOLEAN F761_7351(EIF_REFERENCE);
extern EIF_BOOLEAN F916_7704(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
