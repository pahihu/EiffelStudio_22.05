/*
 * Code for class BILINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1024.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F641_7229 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 640, Current, 0, 1, 8142);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F916_7704(Current)) {
		tb1 = (EIF_BOOLEAN) !F761_7351(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F952_7876(Current);
	}
	RTHOOK(3);
	F631_7212(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1024 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
