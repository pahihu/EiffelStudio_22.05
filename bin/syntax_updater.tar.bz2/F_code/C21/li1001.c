/*
 * Code for class LINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1001.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F631_7210 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 630, Current, 0, 1, 8035);
	RTGC;
	RTHOOK(1);
	F952_7874(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F892_7679(Current)) {
		RTHOOK(3);
		F952_7880(Current, arg1);
	}
	RTHOOK(4);
	Result = F631_7216(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.search */
void F631_7212 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 630, Current, 0, 1, 8037);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5838[Dtype(Current)-602])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F631_7216(Current)) {
				tb1 = (arg1 == F952_7848(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F952_7876(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F631_7216(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F952_7848(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F952_7876(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F631_7216 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 630, Current, 0, 0, 8040);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F892_7679(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F631_7218 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 630, Current, 0, 0, 8041);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F761_7351(Current)) {
		Result = F916_7703(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F631_7225 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 630, Current, 0, 0, 8033);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1001 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
