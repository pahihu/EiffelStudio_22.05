
#ifndef _C21_ty1006_
#define _C21_ty1006_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F520_7085(EIF_REFERENCE);
extern void EIF_Minit1006(void);
extern char *(*R5792[])();
extern char *(*R5979[])();
extern char *(*R5779[])();

#ifdef __cplusplus
}
#endif

#endif
