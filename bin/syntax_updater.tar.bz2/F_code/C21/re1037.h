
#ifndef _C21_re1037_
#define _C21_re1037_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F839_7429(EIF_REFERENCE);
extern void EIF_Minit1037(void);
extern void F533_7091(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5791[])();
extern EIF_TYPE_INDEX Y5727[];
extern EIF_TYPE_INDEX *Y5727_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
