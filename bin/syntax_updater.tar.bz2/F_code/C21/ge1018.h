
#ifndef _C21_ge1018_
#define _C21_ge1018_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F554_7131(EIF_REFERENCE);
extern EIF_INTEGER_32 F554_7133(EIF_REFERENCE);
extern EIF_BOOLEAN F554_7140(EIF_REFERENCE);
extern EIF_BOOLEAN F554_7143(EIF_REFERENCE);
extern EIF_BOOLEAN F554_7144(EIF_REFERENCE);
extern void F554_7145(EIF_REFERENCE);
extern void F554_7146(EIF_REFERENCE);
extern EIF_REFERENCE F554_7147(EIF_REFERENCE);
extern void EIF_Minit1018(void);
extern char *(*R5780[])();
extern char *(*R5807[])();
extern long O5806[];
extern long O5808[];

#ifdef __cplusplus
}
#endif

#endif
