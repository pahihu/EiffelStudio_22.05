
#ifndef _C21_ar1017_
#define _C21_ar1017_

#ifdef __cplusplus
extern "C" {
#endif

extern void F568_7163(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F568_7164(EIF_REFERENCE);
extern EIF_REFERENCE F568_7165(EIF_REFERENCE);
extern EIF_REFERENCE F568_7167(EIF_REFERENCE);
extern EIF_INTEGER_32 F568_7168(EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern EIF_REFERENCE F952_7847(EIF_REFERENCE);
extern EIF_INTEGER_32 F952_7866(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5698[];
extern EIF_TYPE_INDEX *Y5698_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
