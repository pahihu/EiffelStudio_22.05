
#ifndef _C21_sp1020_
#define _C21_sp1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F592_7175(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F592_7176(EIF_REFERENCE);
extern EIF_REFERENCE F592_7177(EIF_REFERENCE);
extern EIF_INTEGER_32 F592_7178(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern EIF_INTEGER_32 F1153_10574(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5698[];
extern EIF_TYPE_INDEX *Y5698_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
