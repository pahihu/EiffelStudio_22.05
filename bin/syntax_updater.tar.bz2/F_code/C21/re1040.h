
#ifndef _C21_re1040_
#define _C21_re1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F533_7091(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F533_7093(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_7094(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_7095(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_7096(EIF_REFERENCE);
extern EIF_REFERENCE F533_7097(EIF_REFERENCE);
extern EIF_BOOLEAN F533_7103(EIF_REFERENCE);
extern EIF_BOOLEAN F533_7104(EIF_REFERENCE);
extern EIF_BOOLEAN F533_7105(EIF_REFERENCE);
extern EIF_BOOLEAN F533_7107(EIF_REFERENCE);
extern void F533_7110(EIF_REFERENCE);
extern void F533_7111(EIF_REFERENCE);
extern EIF_REFERENCE F533_7112(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5791[])();
extern char *(*R5980[])();
extern char *(*R5981[])();
extern char *(*R5983[])();
extern long O5795[];
extern long O5799[];
extern long O5800[];
extern long O5801[];
extern long O5802[];
extern long O5803[];

#ifdef __cplusplus
}
#endif

#endif
