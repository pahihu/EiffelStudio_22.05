
#ifndef _C21_ge1036_
#define _C21_ge1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F555_7131(EIF_REFERENCE);
extern EIF_INTEGER_32 F555_7133(EIF_REFERENCE);
extern EIF_BOOLEAN F555_7140(EIF_REFERENCE);
extern EIF_BOOLEAN F555_7143(EIF_REFERENCE);
extern EIF_BOOLEAN F555_7144(EIF_REFERENCE);
extern void F555_7145(EIF_REFERENCE);
extern void F555_7146(EIF_REFERENCE);
extern EIF_REFERENCE F555_7147(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern char *(*R5780[])();
extern char *(*R5807[])();
extern long O5806[];
extern long O5808[];

#ifdef __cplusplus
}
#endif

#endif
