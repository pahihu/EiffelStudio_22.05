
#ifndef _C21_ty1041_
#define _C21_ty1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F521_7085(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern char *(*R5792[])();
extern char *(*R5979[])();
extern char *(*R5779[])();

#ifdef __cplusplus
}
#endif

#endif
