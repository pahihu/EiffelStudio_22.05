
#ifndef _C21_sp1044_
#define _C21_sp1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F593_7175(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F593_7176(EIF_REFERENCE);
extern EIF_REFERENCE F593_7177(EIF_REFERENCE);
extern EIF_INTEGER_32 F593_7178(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern EIF_INTEGER_32 F1154_10574(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5698[];
extern EIF_TYPE_INDEX *Y5698_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
