/*
 * Code for class ACCESS_ID_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac706.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_ID_AS}.make_inline_local */
void F1409_16983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_inline_local", 1408, Current, 0, 1, 23346);
	RTGC;
	RTHOOK(1);
	F1406_16946(Current, arg1, NULL);
	RTHOOK(2);
	F1406_16969(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ACCESS_ID_AS}.process */
void F1409_16984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1408, Current, 0, 1, 23347);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3911[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit706 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
