
#ifndef _C15_ac704_
#define _C15_ac704_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1407_16977(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1407_16979(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1407_16981(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit704(void);
extern EIF_REFERENCE F1366_16452(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1406_16946(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3910[])();
extern long O13818[];

#ifdef __cplusplus
}
#endif

#endif
