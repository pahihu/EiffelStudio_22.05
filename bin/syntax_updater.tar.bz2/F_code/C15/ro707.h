
#ifndef _C15_ro707_
#define _C15_ro707_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1410_16990(EIF_REFERENCE);
extern void EIF_Minit707(void);

#ifdef __cplusplus
}
#endif

#endif
