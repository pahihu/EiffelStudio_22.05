/*
 * Code for class ACCESS_FEAT_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac703.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_FEAT_AS}.initialize */
void F1406_16946 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("initialize", 1405, Current, 0, 2, 23317);
	RTGC;
	RTHOOK(1);
	F1406_16965(Current, arg2);
	RTHOOK(2);
	F1385_16750(Current, arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {ACCESS_FEAT_AS}.process */
void F1406_16947 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1405, Current, 0, 1, 23318);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3909[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {ACCESS_FEAT_AS}.parameters */
EIF_REFERENCE F1406_16948 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("parameters", 1405, Current, 1, 0, 23319);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		RTHOOK(3);
		F950_7874(RTCW(Result));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {ACCESS_FEAT_AS}.index */
EIF_INTEGER_32 F1406_16961 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("index", 1405, Current, 1, 0, 23332);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = F1417_17065(loc1);
	} else {
		RTHOOK(3);
		ti4_1 = F1385_16753(Current);
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {ACCESS_FEAT_AS}.last_token */
EIF_REFERENCE F1406_16962 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("last_token", 1405, Current, 2, 1, 23333);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = F1406_16948(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13214[Dtype(loc1)-1366])(loc1, arg1);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1385_16755(Current, arg1);
		}
	} else {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(8);
			tr1 = F1417_17068(loc2, arg1);
			RTHOOK(9);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(10);
			RTHOOK(11);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1385_16755(Current, arg1);
		}
	}/* NOTREACHED */
	
}

/* {ACCESS_FEAT_AS}.set_parameters */
void F1406_16965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_parameters", 1405, Current, 0, 1, 23336);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {ACCESS_FEAT_AS}.enable_inline_local */
void F1406_16969 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_inline_local", 1405, Current, 0, 0, 23308);
	RTGC;
	RTHOOK(1);
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O13564[dtype-1405]);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 8U));
	*(EIF_NATURAL_8 *)(Current + O13564[dtype-1405]) = (EIF_NATURAL_8) tu1_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit703 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
