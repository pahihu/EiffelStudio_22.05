/*
 * Code for class PRECURSOR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr724.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRECURSOR_AS}.initialize */
void F1429_17094 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("initialize", 1428, Current, 0, 3, 23459);
	RTGC;
	RTHOOK(1);
	F140_1960(Current);
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTHOOK(4);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {PRECURSOR_AS}.process */
void F1429_17095 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1428, Current, 0, 1, 23460);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3913[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {PRECURSOR_AS}.parameters */
EIF_REFERENCE F1429_17098 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("parameters", 1428, Current, 2, 0, 23463);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		RTHOOK(3);
		F950_7874(RTCW(Result));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {PRECURSOR_AS}.first_token */
EIF_REFERENCE F1429_17104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("first_token", 1428, Current, 0, 1, 23469);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1449_17371(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PRECURSOR_AS}.last_token */
EIF_REFERENCE F1429_17105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("last_token", 1428, Current, 4, 1, 23470);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = F1429_17098(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13214[Dtype(loc1)-1366])(loc1, arg1);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				RTHOOK(6);
				tr1 = F1437_17223(loc2, arg1);
				RTHOOK(7);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) tr1;
			} else {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				Result = F1449_17372(RTCW(tr1), arg1);
			}
		}
	} else {
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(10);
			Result = F1417_17068(loc3, arg1);
			RTHOOK(11);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		} else {
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(13);
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13214[Dtype(loc4)-1366])(loc4, arg1);
				RTHOOK(14);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			} else {
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				Result = F1449_17372(RTCW(tr1), arg1);
			}
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit724 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
