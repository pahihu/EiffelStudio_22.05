/*
 * Code for class QUALIFIED_ANCHORED_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "qu731.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {QUALIFIED_ANCHORED_TYPE_AS}.make_anchored */
void F1436_17199 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("make_anchored", 1435, Current, 3, 3, 23578);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1438,0xFF01,1384,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1439_17237(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F1436_17202(Current, arg2, arg3);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.make_explicit */
void F1436_17200 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTEAA("make_explicit", 1435, Current, 1, 4, 23579);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(3);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1438,0xFF01,1384,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1439_17237(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	F1436_17202(Current, arg3, arg4);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.has_anchor */
EIF_BOOLEAN F1436_17201 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.extend */
void F1436_17202 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("extend", 1435, Current, 1, 2, 23581);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1439_17243(RTCW(tr1), arg1);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTLNS(eif_new_type(1384, 0x01).id, 1384, _OBJSIZ_2_0_0_2_0_0_0_0_);
	F1385_16750(RTCW(tr2), arg2);
	F950_7884(RTCW(tr1), tr2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.process */
void F1436_17203 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1435, Current, 0, 1, 23582);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3933[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.like_keyword */
EIF_REFERENCE F1436_17205 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("like_keyword", 1435, Current, 2, 1, 23568);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_6_0_5_);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		tb3 = F452_6293(RTCW(arg1), loc1);
		tb2 = tb3;
	}
	if (tb2) {
		tr1 = F452_6288(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1453, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.first_token */
EIF_REFERENCE F1436_17209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("first_token", 1435, Current, 0, 1, 23572);
	RTGC;
	RTHOOK(1);
	Result = F1430_17121(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			RTHOOK(4);
			Result = F1436_17205(Current, arg1);
		}
		RTHOOK(5);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(RTCW(tr1))-1366])(tr1, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.last_token */
EIF_REFERENCE F1436_17210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("last_token", 1435, Current, 0, 1, 23573);
	RTGC;
	RTHOOK(1);
	Result = F1430_17122(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1439_17247(RTCW(tr1), arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.dump */
EIF_REFERENCE F1436_17212 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLIU(9);
	
	RTEAA("dump", 1435, Current, 2, 0, 23575);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), ((EIF_INTEGER_32) 8L));
	RTHOOK(2);
	F1430_17136(Current, Result);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1432, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(4);
		tr1 = F1433_17172(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1433, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			RTHOOK(6);
			tr1 = F1434_17183(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
		} else {
			RTHOOK(7);
			tr1 = RTMS_EX_H("like {",6,2014932603);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13666[Dtype(RTCW(tr1))-1430])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '}');
		}
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1039,0xFF01,0,0xFF01,1098,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = Result;
	RTAR(tr2,Result);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1085,0xFF01,0xFFF9,1,1039,0xFF01,1384,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A731_115_2, (EIF_POINTER) _A731_115_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	F950_7858(RTCW(tr1), tr5);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.inline-agent#1 of dump */
void F1436_18851 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("inline-agent#1 of dump", 1435, Current, 0, 2, 23571);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(arg2))-1098])(arg2, (EIF_CHARACTER_8) '.');
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = F1513_18102(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(arg2))-1098])(arg2, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit731 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
