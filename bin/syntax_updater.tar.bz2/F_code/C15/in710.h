
#ifndef _C15_in710_
#define _C15_in710_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1413_17013(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit710(void);

#ifdef __cplusplus
}
#endif

#endif
