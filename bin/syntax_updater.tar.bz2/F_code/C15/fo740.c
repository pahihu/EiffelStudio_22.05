/*
 * Code for class FORMAL_GENERIC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo740.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_GENERIC_LIST_AS}.process */
void F1446_17343 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1445, Current, 0, 1, 23715);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3963[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {FORMAL_GENERIC_LIST_AS}.transform_class_types_to_formals_and_record_suppliers */
void F1446_17344 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,tr1);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTEAA("transform_class_types_to_formals_and_record_suppliers", 1445, Current, 3, 3, 23716);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(305, 0x01).id, 305, _OBJSIZ_5_0_0_0_0_0_0_0_);
	F306_4651(RTCW(loc2), arg1, arg2, arg3);
	RTHOOK(2);
	F950_7874(Current);
	for (;;) {
		RTHOOK(3);
		if (F914_7703(Current)) break;
		RTHOOK(4);
		loc1 = *(EIF_REFERENCE *)(RTCV(F950_7848(Current)) + _REFACS_1_);
		RTHOOK(5);
		F950_7874(RTCW(loc1));
		for (;;) {
			RTHOOK(6);
			tb1 = F914_7703(RTCW(loc1));
			if (tb1) break;
			RTHOOK(7);
			tr1 = F950_7848(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13198[Dtype(RTCW(tr1))-1366])(tr1, loc2);
			RTHOOK(8);
			tb2 = F306_4652(RTCW(loc2));
			if (tb2) {
				RTHOOK(9);
				F306_4653(RTCW(loc2));
				RTHOOK(10);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTHOOK(11);
					tr1 = F950_7848(RTCW(loc1));
					F1379_16671(RTCW(tr1), loc3);
				}
			}
			RTHOOK(12);
			F950_7876(RTCW(loc1));
		}
		RTHOOK(13);
		F950_7876(Current);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {FORMAL_GENERIC_LIST_AS}.first_token */
EIF_REFERENCE F1446_17345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("first_token", 1445, Current, 0, 1, 23717);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1439_17246(Current, arg1);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1446_17349(Current, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.last_token */
EIF_REFERENCE F1446_17346 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("last_token", 1445, Current, 0, 1, 23718);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1439_17247(Current, arg1);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1446_17350(Current, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.lsqure_symbol */
EIF_REFERENCE F1446_17349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("lsqure_symbol", 1445, Current, 0, 1, 23721);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16452(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {FORMAL_GENERIC_LIST_AS}.rsqure_symbol */
EIF_REFERENCE F1446_17350 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("rsqure_symbol", 1445, Current, 0, 1, 23722);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16452(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {FORMAL_GENERIC_LIST_AS}.set_lsqure_symbol */
void F1446_17351 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_lsqure_symbol", 1445, Current, 0, 1, 23723);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_rsqure_symbol */
void F1446_17352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_rsqure_symbol", 1445, Current, 0, 1, 23724);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_squre_symbols */
void F1446_17353 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("set_squre_symbols", 1445, Current, 0, 2, 23725);
	RTGC;
	RTHOOK(1);
	F1446_17351(Current, arg1);
	RTHOOK(2);
	F1446_17352(Current, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit740 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
