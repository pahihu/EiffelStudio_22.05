
#ifndef _C15_un720_
#define _C15_un720_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1425_17083(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit720(void);
extern char *(*R3960[])();

#ifdef __cplusplus
}
#endif

#endif
