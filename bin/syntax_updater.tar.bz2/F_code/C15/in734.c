/*
 * Code for class INDEXING_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in734.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INDEXING_CLAUSE_AS}.process */
void F1440_17250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1439, Current, 0, 1, 23654);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3919[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {INDEXING_CLAUSE_AS}.first_token */
EIF_REFERENCE F1440_17251 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("first_token", 1439, Current, 0, 1, 23655);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1439_17246(Current, arg1);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1440_17306(Current, arg1);
	}/* NOTREACHED */
	
}

/* {INDEXING_CLAUSE_AS}.last_token */
EIF_REFERENCE F1440_17252 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("last_token", 1439, Current, 0, 1, 23656);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1439_17247(Current, arg1);
	} else {
		RTHOOK(4);
		Result = F1440_17307(Current, arg1);
		RTHOOK(5);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) !F757_7351(Current)) {
				RTHOOK(7);
				Result = F1439_17247(Current, arg1);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			} else {
				RTHOOK(9);
				Result = F1440_17306(Current, arg1);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.has_global_once */
EIF_BOOLEAN F1440_17258 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("has_global_once", 1439, Current, 0, 0, 23662);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(17285,F1440_17285, (Current));
	tr2 = RTOSCF(17292,F1440_17292, (Current));
	Result = F1440_17302(Current, tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.index_as_of_tag_name */
EIF_REFERENCE F1440_17270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("index_as_of_tag_name", 1439, Current, 4, 1, 23674);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = F950_7866(Current);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		loc3 = F950_7849(Current, loc1);
		RTHOOK(5);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = F1513_18102(loc4);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
			tb2 = F1091_9572(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_1, ((EIF_INTEGER_32) 1L));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(6);
			Result = (EIF_REFERENCE) loc3;
			RTHOOK(7);
			loc1 = (EIF_INTEGER_32) loc2;
		}
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.once_status_index_as */
EIF_REFERENCE F1440_17271 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("once_status_index_as", 1439, Current, 0, 0, 23675);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(17285,F1440_17285, (Current));
	Result = F1440_17270(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.once_status_header */

EIF_REFERENCE F1440_17285 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (17285,RTMS_EX_H("once_status",11,1414855283));
}

/* {INDEXING_CLAUSE_AS}.global_value */

EIF_REFERENCE F1440_17292 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (17292,RTMS_EX_H("global",6,2072054124));
}

/* {INDEXING_CLAUSE_AS}.has_tag_value */
EIF_BOOLEAN F1440_17302 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("has_tag_value", 1439, Current, 4, 2, 23646);
	RTGC;
	RTHOOK(1);
	tr1 = F1440_17270(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		loc2 = F950_7857(RTCW(tr1));
		for (;;) {
			tb1 = F552_7140(loc2);
			if (tb1) break;
			RTHOOK(3);
			if (Result) break;
			RTHOOK(4);
			Result = '\01';
			tb2 = '\0';
			tr1 = F552_7131(loc2);
			loc3 = tr1;
			loc3 = RTRV(eif_new_type(1514, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(loc3);
				tb3 = F1097_9852(RTCW(tr1), arg2);
				tb2 = tb3;
			}
			if (!tb2) {
				tb2 = '\0';
				tr1 = F552_7131(loc2);
				loc4 = tr1;
				loc4 = RTRV(eif_new_type(1512, 0x01),loc4);
				if (EIF_TEST(loc4)) {
					tr1 = F1513_18102(loc4);
					tb3 = F1097_9852(RTCW(tr1), arg2);
					tb2 = tb3;
				}
				Result = tb2;
			}
			RTHOOK(5);
			F552_7146(loc2);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.indexing_keyword */
EIF_REFERENCE F1440_17306 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("indexing_keyword", 1439, Current, 0, 1, 23650);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {INDEXING_CLAUSE_AS}.end_keyword */
EIF_REFERENCE F1440_17307 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("end_keyword", 1439, Current, 0, 1, 23651);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {INDEXING_CLAUSE_AS}.set_indexing_keyword */
void F1440_17308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_indexing_keyword", 1439, Current, 0, 1, 23652);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INDEXING_CLAUSE_AS}.set_end_keyword */
void F1440_17309 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_end_keyword", 1439, Current, 0, 1, 23653);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit734 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
