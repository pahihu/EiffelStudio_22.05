/*
 * Code for class KEYWORD_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ke748.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KEYWORD_AS}.make */
void F1454_17441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1453, Current, 0, 9, 23816);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O13937[Dtype(Current)-1453]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	F182_2299(Current, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {KEYWORD_AS}.is_is_keyword */
EIF_BOOLEAN F1454_17476 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_is_keyword", 1453, Current, 0, 0, 23851);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O13937[Dtype(Current)-1453]) == ((EIF_INTEGER_32) 379L));
}

/* {KEYWORD_AS}.process */
void F1454_17507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1453, Current, 0, 1, 23882);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3885[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit748 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
