
#ifndef _C15_de749_
#define _C15_de749_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1455_17510(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit749(void);
extern char *(*R3925[])();

#ifdef __cplusplus
}
#endif

#endif
