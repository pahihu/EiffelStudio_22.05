
#ifndef _C15_de716_
#define _C15_de716_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1420_17071(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit716(void);
extern char *(*R3955[])();

#ifdef __cplusplus
}
#endif

#endif
