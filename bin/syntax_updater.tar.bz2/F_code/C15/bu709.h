
#ifndef _C15_bu709_
#define _C15_bu709_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1412_17008(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit709(void);
extern char *(*R3906[])();

#ifdef __cplusplus
}
#endif

#endif
