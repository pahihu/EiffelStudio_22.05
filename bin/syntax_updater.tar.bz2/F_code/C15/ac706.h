
#ifndef _C15_ac706_
#define _C15_ac706_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1409_16983(EIF_REFERENCE, EIF_REFERENCE);
extern void F1409_16984(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit706(void);
extern void F1406_16946(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1406_16969(EIF_REFERENCE);
extern char *(*R3911[])();

#ifdef __cplusplus
}
#endif

#endif
