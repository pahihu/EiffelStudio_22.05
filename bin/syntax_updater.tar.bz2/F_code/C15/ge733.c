/*
 * Code for class GENERIC_CLASS_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge733.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERIC_CLASS_TYPE_AS}.initialize */
void F1438_17229 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("initialize", 1437, Current, 0, 2, 23602);
	RTGC;
	RTHOOK(1);
	F1437_17213(Current, arg1);
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {GENERIC_CLASS_TYPE_AS}.has_anchor */
EIF_BOOLEAN F1438_17230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTEAA("has_anchor", 1437, Current, 1, 0, 23603);
	RTGC;
	RTHOOK(1);
	tr1 = F1438_17233(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,1039,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1089,0xFF01,0xFFF9,1,1039,0xFF01,1429,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A725_97_1, (EIF_POINTER) _A725_97_1, 0, tr1, 0, 1);
		}
		Result = F950_7860(loc1, tr4);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.process */
void F1438_17232 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1437, Current, 0, 1, 23605);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4034[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {GENERIC_CLASS_TYPE_AS}.generics */
EIF_REFERENCE F1438_17233 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("generics", 1437, Current, 0, 0, 23606);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	tb1 = F757_7351(RTCW(Result));
	if (tb1) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) NULL;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.last_token */
EIF_REFERENCE F1438_17235 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("last_token", 1437, Current, 0, 1, 23608);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_7_0_1_) != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(3);
			Result = F1430_17113(Current, arg1);
		}
		RTHOOK(4);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1448_17364(RTCW(tr1), arg1);
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1449_17372(RTCW(tr1), arg1);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.dump */
EIF_REFERENCE F1438_17236 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("dump", 1437, Current, 1, 0, 23600);
	RTGC;
	RTHOOK(1);
	Result = F1437_17226(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F950_7857(RTCW(tr1));
	RTHOOK(3);
	tr1 = RTMS_EX_H(" [",2,8283);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
	for (;;) {
		tb1 = F552_7140(loc1);
		if (tb1) break;
		RTHOOK(4);
		tr1 = F552_7131(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13666[Dtype(RTCW(tr1))-1430])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
		RTHOOK(5);
		tb2 = F552_7144(loc1);
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(6);
			tr1 = RTMS_EX_H(", ",2,11296);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
		}
		RTHOOK(7);
		F552_7146(loc1);
	}
	RTHOOK(8);
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit733 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
