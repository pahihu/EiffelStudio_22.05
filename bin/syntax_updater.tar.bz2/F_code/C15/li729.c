/*
 * Code for class LIKE_ID_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li729.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIKE_ID_AS}.initialize */
void F1434_17173 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("initialize", 1433, Current, 0, 2, 23553);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O13818[Dtype(arg2)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {LIKE_ID_AS}.has_anchor */
EIF_BOOLEAN F1434_17174 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {LIKE_ID_AS}.process */
void F1434_17175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1433, Current, 0, 1, 23543);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3931[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {LIKE_ID_AS}.like_keyword */
EIF_REFERENCE F1434_17177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("like_keyword", 1433, Current, 0, 1, 23545);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_));
}

/* {LIKE_ID_AS}.first_token */
EIF_REFERENCE F1434_17180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("first_token", 1433, Current, 0, 1, 23548);
	RTGC;
	RTHOOK(1);
	Result = F1430_17121(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_) != ((EIF_INTEGER_32) 0L)))) {
			RTHOOK(4);
			Result = F1434_17177(Current, arg1);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = F1449_17371(RTCW(tr1), arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {LIKE_ID_AS}.last_token */
EIF_REFERENCE F1434_17181 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("last_token", 1433, Current, 0, 1, 23549);
	RTGC;
	RTHOOK(1);
	Result = F1430_17122(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1449_17372(RTCW(tr1), arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {LIKE_ID_AS}.dump */
EIF_REFERENCE F1434_17183 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("dump", 1433, Current, 0, 0, 23551);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1513_18102(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1097_9826(RTCW(Result), (EIF_INTEGER_32) (((EIF_INTEGER_32) 7L) + ti4_1));
	RTHOOK(2);
	F1430_17136(Current, Result);
	RTHOOK(3);
	tr1 = RTMS_EX_H("like ",5,1769475360);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1513_18102(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(Result))-1098])(Result, tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit729 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
