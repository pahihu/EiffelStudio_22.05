/*
 * Code for class LEAF_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "le743.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LEAF_AS}.first_token */
EIF_REFERENCE F1449_17371 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("first_token", 1448, Current, 0, 1, 23745);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.last_token */
EIF_REFERENCE F1449_17372 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("last_token", 1448, Current, 0, 1, 23746);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.literal_text */
EIF_REFERENCE F1449_17374 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("literal_text", 1448, Current, 0, 1, 23748);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = F452_6288(RTCW(arg1), *(EIF_INTEGER_32 *)(Current + O13818[Dtype(Current)-1448]));
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13816[Dtype(RTCW(tr1))-1449])(tr1, NULL);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {LEAF_AS}.index */
EIF_INTEGER_32 F1449_17375 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O13818[Dtype(Current)-1448]);
}


/* {LEAF_AS}.set_index */
void F1449_17376 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_index", 1448, Current, 0, 1, 23750);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O13818[Dtype(Current)-1448]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit743 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
