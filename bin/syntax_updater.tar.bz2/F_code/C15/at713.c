/*
 * Code for class ATTRIBUTE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "at713.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ATTRIBUTE_AS}.make */
void F1416_17052 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("make", 1415, Current, 0, 2, 23416);
	RTGC;
	RTHOOK(1);
	F1413_17013(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O13818[Dtype(arg2)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {ATTRIBUTE_AS}.process */
void F1416_17054 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1415, Current, 0, 1, 23418);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3924[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {ATTRIBUTE_AS}.attribute_keyword */
EIF_REFERENCE F1416_17056 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("attribute_keyword", 1415, Current, 0, 1, 23420);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
}

/* {ATTRIBUTE_AS}.first_token */
EIF_REFERENCE F1416_17058 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("first_token", 1415, Current, 1, 1, 23422);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			tr1 = F1439_17246(loc1, arg1);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1416_17056(Current, arg1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {ATTRIBUTE_AS}.last_token */
EIF_REFERENCE F1416_17059 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("last_token", 1415, Current, 1, 1, 23423);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1439_17247(loc1, arg1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			RTHOOK(5);
			Result = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
				RTHOOK(7);
				Result = F1416_17056(Current, arg1);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit713 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
