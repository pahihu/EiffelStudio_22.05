
#ifndef _C17_bi816_
#define _C17_bi816_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1522_18178(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R3986[])();

#ifdef __cplusplus
}
#endif

#endif
