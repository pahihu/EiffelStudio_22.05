
#ifndef _C17_bi827_
#define _C17_bi827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1533_18215(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit827(void);
extern char *(*R3992[])();

#ifdef __cplusplus
}
#endif

#endif
