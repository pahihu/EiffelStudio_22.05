
#ifndef _C17_bi831_
#define _C17_bi831_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1537_18224(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit831(void);
extern char *(*R3998[])();

#ifdef __cplusplus
}
#endif

#endif
