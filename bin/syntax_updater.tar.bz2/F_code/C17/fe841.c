/*
 * Code for class FEATURE_NAME_ALIAS_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fe841.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FEATURE_NAME_ALIAS_AS}.initialize_with_list */
void F1547_18391 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("initialize_with_list", 1546, Current, 4, 3, 24802);
	RTGC;
	RTHOOK(1);
	F1546_18372(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O13818[Dtype(arg3)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(5);
	loc4 = arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,452,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTRV(typres0,loc4);
	}
	if (EIF_TEST(loc4)) {
		RTHOOK(6);
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc4;
	} else {
		RTHOOK(7);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,949,0xFF01,452,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F950_7846(RTCW(tr1), arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {FEATURE_NAME_ALIAS_AS}.process */
void F1547_18392 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1546, Current, 0, 1, 24803);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3921[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {FEATURE_NAME_ALIAS_AS}.keyword_at */
EIF_REFERENCE F1547_18394 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("keyword_at", 1546, Current, 1, 2, 24805);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = F452_6293(RTCW(arg1), arg2);
	if (tb2) {
		tr1 = F452_6288(RTCW(arg1), arg2);
		loc1 = tr1;
		loc1 = RTRV(eif_new_type(1453, 0x01),loc1);
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {FEATURE_NAME_ALIAS_AS}.convert_keyword */
EIF_REFERENCE F1547_18395 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("convert_keyword", 1546, Current, 0, 1, 24806);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1547_18394(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {FEATURE_NAME_ALIAS_AS}.first_token */
EIF_REFERENCE F1547_18409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("first_token", 1546, Current, 0, 1, 24820);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(Result == NULL)) {
		tb2 = F182_2323(RTCW(Result));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1449_17371(RTCW(tr1), arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_NAME_ALIAS_AS}.last_token */
EIF_REFERENCE F1547_18410 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLR(6,loc4);
	RTLR(7,Result);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTEAA("last_token", 1546, Current, 5, 1, 24821);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_) > ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1547_18394(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_));
	} else {
		RTHOOK(4);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		RTHOOK(5);
		loc1 = F950_7854(RTCW(loc2));
		RTHOOK(6);
		F950_7875(RTCW(loc2));
		for (;;) {
			RTHOOK(7);
			tb1 = '\01';
			tb2 = F890_7679(RTCW(loc2));
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb1) break;
			RTHOOK(8);
			tr1 = F950_7848(RTCW(loc2));
			loc3 = tr1;
			if ((EIF_TRUE)) {
				RTHOOK(9);
				if ((EIF_BOOLEAN)(arg1 == NULL)) {
					RTHOOK(10);
					tr1 = *(EIF_REFERENCE *)(loc3);
					loc4 = tr1;
					if ((EIF_TRUE)) {
						RTHOOK(11);
						Result = F1449_17372(loc4, arg1);
					}
				} else {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(loc3);
					loc5 = tr1;
					if ((EIF_TRUE)) {
						RTHOOK(13);
						Result = F1449_17372(loc5, arg1);
					} else {
						RTHOOK(14);
						tb2 = '\0';
						if ((EIF_BOOLEAN)(arg1 != NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_0_);
							tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
						}
						if (tb2) {
							RTHOOK(15);
							ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_0_);
							Result = F1547_18394(Current, arg1, ti4_1);
						}
					}
				}
			}
			RTHOOK(16);
			F950_7877(RTCW(loc2));
		}
		RTHOOK(17);
		F950_7879(RTCW(loc2), loc1);
	}
	RTHOOK(18);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit841 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
