/*
 * Code for class BIN_AND_THEN_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi819.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BIN_AND_THEN_AS}.make */
void F1525_18188 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTEAA("make", 1524, Current, 0, 4, 24595);
	RTGC;
	RTHOOK(1);
	F1519_18151(Current, arg1, arg2, arg3);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O13818[Dtype(arg4)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {BIN_AND_THEN_AS}.process */
void F1525_18191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1524, Current, 0, 1, 24598);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3983[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {BIN_AND_THEN_AS}.then_keyword */
EIF_REFERENCE F1525_18193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("then_keyword", 1524, Current, 1, 1, 24600);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_);
	RTHOOK(2);
	tb1 = F452_6293(RTCW(arg1), loc1);
	if (tb1) {
		RTHOOK(3);
		tr1 = F452_6288(RTCW(arg1), loc1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
