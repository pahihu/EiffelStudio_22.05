
#ifndef _C17_bi828_
#define _C17_bi828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1534_18218(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R3991[])();

#ifdef __cplusplus
}
#endif

#endif
