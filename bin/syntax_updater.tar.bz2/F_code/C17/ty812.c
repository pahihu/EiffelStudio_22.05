/*
 * Code for class TYPED_CHAR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty812.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPED_CHAR_AS}.initialize */
void F1518_18145 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("initialize", 1517, Current, 0, 9, 24552);
	RTGC;
	RTHOOK(1);
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_1_3_0_) = (EIF_CHARACTER_32) arg2;
	RTHOOK(2);
	F182_2312(Current, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTHOOK(3);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {TYPED_CHAR_AS}.type */
EIF_REFERENCE F1518_18146 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {TYPED_CHAR_AS}.first_token */
EIF_REFERENCE F1518_18148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("first_token", 1517, Current, 1, 1, 24555);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(RTCW(tr1))-1366])(tr1, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Current;
	}/* NOTREACHED */
	
}

/* {TYPED_CHAR_AS}.character_text */
EIF_REFERENCE F1518_18149 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("character_text", 1517, Current, 0, 1, 24556);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(53, 0x01).id, 53, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F54_785(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_3_4_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_3_4_));
	Result = F452_6319(RTCW(arg1), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {TYPED_CHAR_AS}.process */
void F1518_18150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1517, Current, 0, 1, 24557);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3882[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
