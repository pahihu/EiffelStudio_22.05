/*
 * Code for class CLASS_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl838.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLASS_AS}.initialize */
void F1544_18243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_BOOLEAN arg5, EIF_BOOLEAN arg6, EIF_BOOLEAN arg7, EIF_BOOLEAN arg8, EIF_REFERENCE arg9, EIF_REFERENCE arg10, EIF_REFERENCE arg11, EIF_REFERENCE arg12, EIF_REFERENCE arg13, EIF_REFERENCE arg14, EIF_REFERENCE arg15, EIF_REFERENCE arg16, EIF_REFERENCE arg17, EIF_REFERENCE arg18, EIF_REFERENCE arg19, EIF_REFERENCE arg20)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg9);
	RTLR(4,arg10);
	RTLR(5,arg11);
	RTLR(6,arg12);
	RTLR(7,arg13);
	RTLR(8,arg14);
	RTLR(9,arg15);
	RTLR(10,arg16);
	RTLR(11,arg17);
	RTLR(12,tr1);
	RTLR(13,arg18);
	RTLR(14,arg19);
	RTLR(15,arg20);
	RTLIU(16);
	
	RTEAA("initialize", 1543, Current, 0, 20, 24729);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_0_) = (EIF_BOOLEAN) arg3;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_1_) = (EIF_BOOLEAN) arg4;
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_3_) = (EIF_BOOLEAN) arg5;
	RTHOOK(6);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_4_) = (EIF_BOOLEAN) arg6;
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_5_) = (EIF_BOOLEAN) arg7;
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_18_2_) = (EIF_BOOLEAN) arg8;
	RTHOOK(9);
	RTAR(Current, arg9);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg9;
	RTHOOK(10);
	RTAR(Current, arg10);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg10;
	RTHOOK(11);
	RTAR(Current, arg11);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg11;
	RTHOOK(12);
	RTAR(Current, arg12);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg12;
	RTHOOK(13);
	RTAR(Current, arg13);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg13;
	RTHOOK(14);
	RTAR(Current, arg14);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg14;
	RTHOOK(15);
	RTAR(Current, arg15);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg15;
	RTHOOK(16);
	RTAR(Current, arg16);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg16;
	RTHOOK(17);
	RTAR(Current, arg17);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg17;
	RTHOOK(18);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg17 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg17) + _REFACS_1_);
		tb1 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb1) {
		RTHOOK(19);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
		RTHOOK(20);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_18_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(21);
		RTAR(Current, arg17);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg17;
	}
	RTHOOK(22);
	RTAR(Current, arg18);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg18;
	RTHOOK(23);
	RTAR(Current, arg19);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg19;
	RTHOOK(24);
	RTAR(Current, arg20);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg20;
	RTHOOK(25);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(26);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1544,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F847_7434(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(49);
	RTLE;
	RTEE;
}

/* {CLASS_AS}.process */
void F1544_18244 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1543, Current, 0, 1, 24730);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4032[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {CLASS_AS}.alias_keyword */
EIF_REFERENCE F1544_18253 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("alias_keyword", 1543, Current, 0, 1, 24739);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_1_));
}

/* {CLASS_AS}.class_keyword */
EIF_REFERENCE F1544_18254 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("class_keyword", 1543, Current, 0, 1, 24740);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_2_));
}

/* {CLASS_AS}.obsolete_keyword */
EIF_REFERENCE F1544_18255 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("obsolete_keyword", 1543, Current, 0, 1, 24741);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_3_));
}

/* {CLASS_AS}.frozen_keyword */
EIF_REFERENCE F1544_18256 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("frozen_keyword", 1543, Current, 0, 1, 24650);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_4_));
}

/* {CLASS_AS}.expanded_keyword */
EIF_REFERENCE F1544_18257 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("expanded_keyword", 1543, Current, 0, 1, 24651);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_5_));
}

/* {CLASS_AS}.deferred_keyword */
EIF_REFERENCE F1544_18258 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("deferred_keyword", 1543, Current, 0, 1, 24652);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_6_));
}

/* {CLASS_AS}.once_keyword */
EIF_REFERENCE F1544_18259 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("once_keyword", 1543, Current, 0, 1, 24653);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_7_));
}

/* {CLASS_AS}.external_keyword */
EIF_REFERENCE F1544_18260 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("external_keyword", 1543, Current, 0, 1, 24654);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_8_));
}

/* {CLASS_AS}.set_header_mark */
void F1544_18261 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLIU(6);
	
	RTEAA("set_header_mark", 1543, Current, 0, 5, 24655);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_4_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(3);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O13818[Dtype(arg2)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		RTHOOK(6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O13818[Dtype(arg3)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_6_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(7);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		RTHOOK(8);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O13818[Dtype(arg4)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_7_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(9);
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		RTHOOK(10);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O13818[Dtype(arg5)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_8_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {CLASS_AS}.set_class_keyword */
void F1544_18262 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_class_keyword", 1543, Current, 0, 1, 24656);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CLASS_AS}.set_alias_keyword */
void F1544_18263 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_alias_keyword", 1543, Current, 0, 1, 24657);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CLASS_AS}.set_obsolete_keyword */
void F1544_18264 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_obsolete_keyword", 1543, Current, 0, 1, 24658);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CLASS_AS}.first_header_mark */
EIF_REFERENCE F1544_18265 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("first_header_mark", 1543, Current, 0, 1, 24659);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_4_) != ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1544_18256(Current, arg1);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_6_) != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			Result = F1544_18258(Current, arg1);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_5_) != ((EIF_INTEGER_32) 0L))) {
				RTHOOK(7);
				Result = F1544_18257(Current, arg1);
			} else {
				RTHOOK(8);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_7_) != ((EIF_INTEGER_32) 0L))) {
					RTHOOK(9);
					Result = F1544_18259(Current, arg1);
				} else {
					RTHOOK(10);
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_8_) != ((EIF_INTEGER_32) 0L))) {
						RTHOOK(11);
						Result = F1544_18260(Current, arg1);
						RTHOOK(12);
						RTLE;
						RTEE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_AS}.class_name */
EIF_REFERENCE F1544_18274 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_17_);
}


/* {CLASS_AS}.top_indexes */
EIF_REFERENCE F1544_18277 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("top_indexes", 1543, Current, 1, 0, 24671);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F757_7351(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CLASS_AS}.generics */
EIF_REFERENCE F1544_18282 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("generics", 1543, Current, 1, 0, 24676);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F757_7351(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CLASS_AS}.first_token */
EIF_REFERENCE F1544_18312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTEAA("first_token", 1543, Current, 3, 1, 24706);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = F1544_18277(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			tr1 = F1440_17251(loc1, arg1);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			Result = F1449_17371(RTCW(tr1), arg1);
		}
	} else {
		RTHOOK(6);
		tb1 = '\0';
		tb2 = F452_6292(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F452_6290(RTCW(arg1));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(RTCW(tr1))-1366])(tr1, arg1);
			loc2 = tr1;
			loc2 = RTRV(eif_new_type(1449, 0x01),loc2);
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc2;
		} else {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(10);
				Result = F1440_17251(loc3, arg1);
				RTHOOK(11);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			} else {
				RTHOOK(12);
				Result = F1544_18265(Current, arg1);
				RTHOOK(13);
				if ((EIF_BOOLEAN)(Result == NULL)) {
					RTHOOK(14);
					Result = F1544_18254(Current, arg1);
					RTHOOK(15);
					RTLE;
					RTEE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_AS}.last_token */
EIF_REFERENCE F1544_18313 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("last_token", 1543, Current, 1, 1, 24707);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		Result = F1449_17372(RTCW(tr1), arg1);
	} else {
		RTHOOK(3);
		tb1 = '\0';
		tb2 = F452_6292(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F452_6291(RTCW(arg1));
			tr1 = F1449_17372(RTCW(tr1), arg1);
			loc1 = tr1;
			loc1 = RTRV(eif_new_type(1449, 0x01),loc1);
			tb1 = EIF_TEST(loc1);
		}
		if (tb1) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc1;
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			Result = F1449_17372(RTCW(tr1), arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_AS}.set_text_positions */
void F1544_18314 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_text_positions", 1543, Current, 0, 8, 24708);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_13_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_10_) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_11_) = (EIF_INTEGER_32) arg3;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_9_) = (EIF_INTEGER_32) arg4;
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_18_) = (EIF_INTEGER_32) arg5;
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_15_) = (EIF_INTEGER_32) arg6;
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_16_) = (EIF_INTEGER_32) arg7;
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_18_7_0_14_) = (EIF_INTEGER_32) arg8;
	RTHOOK(17);
	RTLE;
	RTEE;
}

void EIF_Minit838 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
