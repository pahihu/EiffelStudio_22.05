
#ifndef _C17_bi833_
#define _C17_bi833_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1539_18230(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R3997[])();

#ifdef __cplusplus
}
#endif

#endif
