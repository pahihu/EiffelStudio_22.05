/*
 * Code for class UC_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc845.h"
#include "eif_copy.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_STRING}.make */
void F1551_18473 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1550, Current, 0, 1, 24878);
	RTGC;
	RTHOOK(1);
	F1551_18583(Current);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(4);
		F1097_9826(Current, ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(5);
		F1097_9826(Current, arg1);
	}
	RTHOOK(6);
	ti4_1 = F1551_18506(Current);
	F1551_18591(Current, ti4_1);
	RTHOOK(7);
	ti4_1 = F1551_18506(Current);
	F1099_9988(Current, ti4_1);
	RTHOOK(8);
	F1551_18591(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {UC_STRING}.make_from_string */
void F1551_18474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_from_string", 1550, Current, 0, 1, 24879);
	RTHOOK(1);
	F1551_18476(Current, arg1);
	RTHOOK(3);
	RTEE;
}

/* {UC_STRING}.make_empty */
void F1551_18475 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_empty", 1550, Current, 0, 0, 24880);
	RTHOOK(1);
	F1551_18473(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTEE;
}

/* {UC_STRING}.make_from_string_general */
void F1551_18476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("make_from_string_general", 1550, Current, 2, 1, 24881);
	RTGC;
	RTHOOK(1);
	loc2 = arg1;
	loc2 = RTRV(eif_new_type(1550, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) loc2;
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 != Current)) {
			RTHOOK(5);
			loc1 = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(8);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
		F1551_18478(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {UC_STRING}.make_from_substring */
void F1551_18477 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_from_substring", 1550, Current, 0, 3, 24882);
	RTHOOK(1);
	F1551_18478(Current, arg1, arg2, arg3);
	RTHOOK(3);
	RTEE;
}

/* {UC_STRING}.make_from_substring_general */
void F1551_18478 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("make_from_substring_general", 1550, Current, 4, 3, 24883);
	RTGC;
	RTHOOK(1);
	loc4 = arg1;
	loc4 = RTRV(eif_new_type(1550, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc3 = (EIF_REFERENCE) loc4;
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 != Current)) {
			RTHOOK(5);
			loc3 = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) && (EIF_BOOLEAN)(arg3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_)))) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(8);
		if ((EIF_BOOLEAN) (arg3 < arg2)) {
			RTHOOK(9);
			F1551_18473(Current, ((EIF_INTEGER_32) 0L));
		} else {
			RTHOOK(10);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(11);
				loc2 = F1551_18558(RTCW(loc3));
			} else {
				RTHOOK(12);
				loc2 = (EIF_REFERENCE) arg1;
			}
			RTHOOK(13);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc1 = F1025_9067(RTCW(tr1), loc2, arg2, arg3);
			RTHOOK(14);
			F1551_18473(Current, loc1);
			RTHOOK(15);
			F1551_18591(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
			RTHOOK(16);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc1;
			RTHOOK(17);
			F1551_18594(Current, loc2, arg2, arg3, loc1, ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {UC_STRING}.make_filled */
void F1551_18481 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_filled", 1550, Current, 3, 2, 24886);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	loc2 = F1025_9068(RTCW(tr1), arg1);
	RTHOOK(2);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * arg2);
	RTHOOK(3);
	F1551_18473(Current, loc3);
	RTHOOK(4);
	F1551_18591(Current, arg2);
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(7);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			RTHOOK(9);
			F1551_18586(Current, arg1, loc1);
			RTHOOK(10);
			loc1++;
		}
	} else {
		RTHOOK(11);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(12);
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			RTHOOK(13);
			F1551_18593(Current, arg1, loc2, loc1);
			RTHOOK(14);
			loc1 += loc2;
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {UC_STRING}.item_code */
EIF_INTEGER_32 F1551_18487 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item_code", 1550, Current, 1, 1, 24892);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(2);
		tc1 = F1551_18585(Current, arg1);
		Result = (EIF_INTEGER_32) (tc1);
	} else {
		RTHOOK(3);
		loc1 = F1551_18579(Current, arg1);
		RTHOOK(4);
		Result = F1551_18575(Current, loc1);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.item */
EIF_CHARACTER_8 F1551_18488 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item", 1550, Current, 1, 1, 24893);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_CHARACTER_8) F1551_18585(Current, arg1);
	} else {
		RTHOOK(4);
		loc1 = F1551_18579(Current, arg1);
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_CHARACTER_8) F1551_18576(Current, loc1);
	}/* NOTREACHED */
	
}

/* {UC_STRING}.substring */
EIF_REFERENCE F1551_18490 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("substring", 1550, Current, 0, 2, 24895);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg2 < arg1)) {
		RTHOOK(2);
		tr1 = RTLNSMART(dftype);
		F1551_18473(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTLNSMART(dftype);
		F1551_18477(RTCW(tr1), Current, arg1, arg2);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {UC_STRING}.substring_index */
EIF_INTEGER_32 F1551_18492 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc12);
	RTLIU(4);
	
	RTEAA("substring_index", 1550, Current, 12, 2, 24897);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		RTHOOK(5);
		loc10 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc10 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) arg2;
		} else {
			RTHOOK(9);
			loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 - loc10) + ((EIF_INTEGER_32) 1L));
			RTHOOK(10);
			if ((EIF_BOOLEAN) (arg2 <= loc8)) {
				RTHOOK(11);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
					RTHOOK(12);
					loc11 = arg1;
					loc11 = RTRV(eif_new_type(1550, 0x01),loc11);
					if (EIF_TEST(loc11)) {
						RTHOOK(13);
						loc3 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_1_1_0_3_);
						RTHOOK(14);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							RTHOOK(15);
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							RTHOOK(16);
							loc2 = (EIF_INTEGER_32) loc6;
							RTHOOK(17);
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(18);
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								RTHOOK(19);
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								RTHOOK(20);
								loc4 = F1551_18575(loc11, loc1);
								RTHOOK(21);
								ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									RTHOOK(22);
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								RTHOOK(23);
								tc1 = F1551_18585(Current, loc2);
								ti4_1 = (EIF_INTEGER_32) (tc1);
								if ((EIF_BOOLEAN)(ti4_1 != loc4)) {
									RTHOOK(24);
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									RTHOOK(25);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									RTHOOK(26);
									loc2++;
									RTHOOK(27);
									ti4_1 = F1551_18577(loc11, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							RTHOOK(28);
							if (loc9) {
								RTHOOK(29);
								Result = (EIF_INTEGER_32) loc6;
								RTHOOK(30);
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								RTHOOK(31);
								loc6++;
							}
						}
					} else {
						RTHOOK(32);
						loc3 = (EIF_INTEGER_32) loc10;
						RTHOOK(33);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							RTHOOK(34);
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							RTHOOK(35);
							loc2 = (EIF_INTEGER_32) loc6;
							RTHOOK(36);
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(37);
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								RTHOOK(38);
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								RTHOOK(39);
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg1))-845])(arg1, loc1));
								if ((EIF_BOOLEAN)(F1551_18585(Current, loc2) != tc1)) {
									RTHOOK(40);
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									RTHOOK(41);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									RTHOOK(42);
									loc2++;
									RTHOOK(43);
									loc1++;
								}
							}
							RTHOOK(44);
							if (loc9) {
								RTHOOK(45);
								Result = (EIF_INTEGER_32) loc6;
								RTHOOK(46);
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								RTHOOK(47);
								loc6++;
							}
						}
					}
				} else {
					RTHOOK(48);
					loc7 = F1551_18579(Current, arg2);
					RTHOOK(49);
					loc12 = arg1;
					loc12 = RTRV(eif_new_type(1550, 0x01),loc12);
					if (EIF_TEST(loc12)) {
						RTHOOK(50);
						loc3 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_1_1_0_3_);
						RTHOOK(51);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							RTHOOK(52);
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							RTHOOK(53);
							loc2 = (EIF_INTEGER_32) loc7;
							RTHOOK(54);
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(55);
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								RTHOOK(56);
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								RTHOOK(57);
								loc4 = F1551_18575(Current, loc2);
								RTHOOK(58);
								ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									RTHOOK(59);
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								RTHOOK(60);
								loc5 = F1551_18575(loc12, loc1);
								RTHOOK(61);
								ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
								if ((EIF_BOOLEAN) (loc5 > ti4_1)) {
									RTHOOK(62);
									loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								RTHOOK(63);
								if ((EIF_BOOLEAN)(loc4 != loc5)) {
									RTHOOK(64);
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									RTHOOK(65);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									RTHOOK(66);
									ti4_1 = F1551_18577(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									RTHOOK(67);
									ti4_1 = F1551_18577(loc12, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							RTHOOK(68);
							if (loc9) {
								RTHOOK(69);
								Result = (EIF_INTEGER_32) loc6;
								RTHOOK(70);
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								RTHOOK(71);
								ti4_1 = F1551_18577(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								RTHOOK(72);
								loc6++;
							}
						}
					} else {
						RTHOOK(73);
						loc3 = (EIF_INTEGER_32) loc10;
						RTHOOK(74);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							RTHOOK(75);
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							RTHOOK(76);
							loc2 = (EIF_INTEGER_32) loc7;
							RTHOOK(77);
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(78);
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								RTHOOK(79);
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								RTHOOK(80);
								loc4 = F1551_18575(Current, loc2);
								RTHOOK(81);
								ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									RTHOOK(82);
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								RTHOOK(83);
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg1))-845])(arg1, loc1));
								ti4_1 = (EIF_INTEGER_32) (tc1);
								if ((EIF_BOOLEAN)(loc4 != ti4_1)) {
									RTHOOK(84);
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									RTHOOK(85);
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									RTHOOK(86);
									ti4_1 = F1551_18577(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									RTHOOK(87);
									loc1++;
								}
							}
							RTHOOK(88);
							if (loc9) {
								RTHOOK(89);
								Result = (EIF_INTEGER_32) loc6;
								RTHOOK(90);
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								RTHOOK(91);
								ti4_1 = F1551_18577(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								RTHOOK(92);
								loc6++;
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(93);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.string */
EIF_REFERENCE F1551_18493 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("string", 1550, Current, 3, 0, 24898);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), loc2);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc2 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(4);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(5);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(6);
			tc1 = F1551_18585(Current, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, tc1);
			RTHOOK(7);
			loc1++;
		}
	} else {
		RTHOOK(8);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		RTHOOK(9);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(10);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(11);
			loc3 = F1551_18575(Current, loc1);
			RTHOOK(12);
			ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
			if ((EIF_BOOLEAN) (loc3 <= ti4_1)) {
				RTHOOK(13);
				tr1 = RTOSCF(7011,F488_7011, (Current));
				tc1 = F1023_8985(RTCW(tr1), loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, tc1);
			} else {
				RTHOOK(14);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '\000');
			}
			RTHOOK(15);
			ti4_1 = F1551_18577(Current, loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.plus */
EIF_REFERENCE F1551_18494 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("plus", 1550, Current, 0, 1, 24899);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
	ti4_2 = F1025_9067(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_2);
	F1551_18473(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ti4_2));
	RTHOOK(2);
	F1551_18530(RTCW(Result), Current);
	RTHOOK(3);
	F1551_18530(RTCW(Result), arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.index_of_item_code */
EIF_INTEGER_32 F1551_18497 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("index_of_item_code", 1550, Current, 3, 2, 24902);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 127L))) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(6);
			loc1 = (EIF_INTEGER_32) arg2;
			for (;;) {
				RTHOOK(7);
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				RTHOOK(8);
				tc1 = F1551_18585(Current, loc1);
				ti4_1 = (EIF_INTEGER_32) (tc1);
				if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
					RTHOOK(9);
					Result = (EIF_INTEGER_32) loc1;
					RTHOOK(10);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				} else {
					RTHOOK(11);
					loc1++;
				}
			}
		}
	} else {
		RTHOOK(12);
		if ((EIF_BOOLEAN) (arg2 <= loc3)) {
			RTHOOK(13);
			loc2 = F1551_18579(Current, arg2);
			RTHOOK(14);
			loc1 = (EIF_INTEGER_32) arg2;
			for (;;) {
				RTHOOK(15);
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				RTHOOK(16);
				if ((EIF_BOOLEAN)(F1551_18575(Current, loc2) == arg1)) {
					RTHOOK(17);
					Result = (EIF_INTEGER_32) loc1;
					RTHOOK(18);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				} else {
					RTHOOK(19);
					ti4_1 = F1551_18577(Current, loc2);
					loc2 = (EIF_INTEGER_32) ti4_1;
					RTHOOK(20);
					loc1++;
				}
			}
		}
	}
	RTHOOK(25);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.index_of */
EIF_INTEGER_32 F1551_18498 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("index_of", 1550, Current, 5, 2, 24903);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			RTHOOK(5);
			if ((EIF_BOOLEAN)(F1551_18585(Current, loc1) == arg1)) {
				RTHOOK(6);
				Result = (EIF_INTEGER_32) loc1;
				RTHOOK(7);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			} else {
				RTHOOK(8);
				loc1++;
			}
		}
	} else {
		RTHOOK(9);
		if ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\000')) {
			RTHOOK(10);
			if ((EIF_BOOLEAN) (arg2 <= loc3)) {
				RTHOOK(11);
				loc4 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
				RTHOOK(12);
				loc2 = F1551_18579(Current, arg2);
				RTHOOK(13);
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					RTHOOK(14);
					if ((EIF_BOOLEAN) (loc1 > loc3)) break;
					RTHOOK(15);
					loc5 = F1551_18575(Current, loc2);
					RTHOOK(16);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc5 > loc4))) {
						RTHOOK(17);
						Result = (EIF_INTEGER_32) loc1;
						RTHOOK(18);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
					} else {
						RTHOOK(19);
						ti4_1 = F1551_18577(Current, loc2);
						loc2 = (EIF_INTEGER_32) ti4_1;
						RTHOOK(20);
						loc1++;
					}
				}
			}
		} else {
			RTHOOK(21);
			ti4_1 = (EIF_INTEGER_32) (arg1);
			Result = F1551_18497(Current, ti4_1, arg2);
		}
	}
	RTHOOK(22);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.hash_code */
EIF_INTEGER_32 F1551_18499 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1550, Current, 4, 0, 24904);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc2 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(4);
		Result = F1091_9538(Current);
	} else {
		RTHOOK(5);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(6);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		RTHOOK(7);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(9);
			loc3 = F1551_18575(Current, loc1);
			RTHOOK(10);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 5L) * Result) + loc3);
			RTHOOK(11);
			ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
			if ((EIF_BOOLEAN) (loc3 > ti4_1)) {
				RTHOOK(12);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(13);
			ti4_1 = F1551_18577(Current, loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
		RTHOOK(14);
		if (loc4) {
			RTHOOK(15);
			tr1 = F1551_18493(Current);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7172[Dtype(RTCW(tr1))-1039])(tr1);
		}
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTHOOK(17);
		RTHOOK(18);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.count */
EIF_INTEGER_32 F1551_18504 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
}


/* {UC_STRING}.byte_capacity */
EIF_INTEGER_32 F1551_18506 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("byte_capacity", 1550, Current, 0, 0, 24911);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1097_9847(Current);
}

/* {UC_STRING}.has */
EIF_BOOLEAN F1551_18509 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 1550, Current, 0, 1, 24914);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1551_18498(Current, arg1, ((EIF_INTEGER_32) 1L));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.has_substring */
EIF_BOOLEAN F1551_18511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("has_substring", 1550, Current, 0, 1, 24916);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
		if ((EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			RTHOOK(5);
			ti4_1 = F1551_18492(Current, arg1, ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.is_empty */
EIF_BOOLEAN F1551_18512 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_empty", 1550, Current, 0, 0, 24917);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == ((EIF_INTEGER_32) 0L));
}

/* {UC_STRING}.is_equal */
EIF_BOOLEAN F1551_18514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_equal", 1550, Current, 2, 1, 24919);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tr1 = RTOSCF(8944,F1020_8944, (Current));
		tb2 = F17_231(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
		}
		if (tb1) {
			RTHOOK(5);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(7);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				RTHOOK(9);
				tc1 = F1551_18585(RTCW(arg1), loc1);
				if ((EIF_BOOLEAN)(F1551_18585(Current, loc1) != tc1)) {
					RTHOOK(10);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(11);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					RTHOOK(12);
					loc1++;
				}
			}
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.is_less */
EIF_BOOLEAN F1551_18515 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1550, Current, 0, 1, 24920);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1551_18519(Current, arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -1L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.same_string */
EIF_BOOLEAN F1551_18516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_string", 1550, Current, 0, 1, 24921);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
		if ((EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			RTHOOK(5);
			ti4_1 = F1551_18492(Current, arg1, ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.same_string_general */
EIF_BOOLEAN F1551_18517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_string_general", 1550, Current, 4, 1, 24922);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
		if ((EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			RTHOOK(5);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(7);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				RTHOOK(9);
				loc3 = F1551_18601(Current, loc1);
				RTHOOK(10);
				ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
				tu4_1 = (EIF_NATURAL_32) ti4_1;
				if ((EIF_BOOLEAN) (loc3 > tu4_1)) {
					RTHOOK(11);
					loc3 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
				RTHOOK(12);
				loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(arg1))-1094])(arg1, loc1);
				RTHOOK(13);
				ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
				tu4_1 = (EIF_NATURAL_32) ti4_1;
				if ((EIF_BOOLEAN) (loc4 > tu4_1)) {
					RTHOOK(14);
					loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc3 != loc4)) {
					RTHOOK(16);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(17);
					loc1 = (EIF_INTEGER_32) loc2;
				}
				RTHOOK(18);
				loc1++;
			}
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.three_way_comparison */
EIF_INTEGER_32 F1551_18519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("three_way_comparison", 1550, Current, 7, 1, 24924);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		tr1 = RTOSCF(8944,F1020_8944, (Current));
		tb2 = F17_231(RTCW(tr1), Current, arg1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		RTHOOK(3);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc3 < loc4)) {
			RTHOOK(5);
			loc2 = (EIF_INTEGER_32) loc3;
		} else {
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) loc4;
		}
		RTHOOK(7);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(9);
			loc5 = F1551_18585(Current, loc1);
			RTHOOK(10);
			loc6 = F1551_18585(RTCW(arg1), loc1);
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc5 == loc6)) {
				RTHOOK(12);
				loc1++;
			} else {
				RTHOOK(13);
				if ((EIF_BOOLEAN) (loc5 < loc6)) {
					RTHOOK(14);
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(15);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					RTHOOK(16);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					RTHOOK(17);
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(18);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(19);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				}
			}
		}
		RTHOOK(20);
		if ((EIF_BOOLEAN) !loc7) {
			RTHOOK(21);
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				RTHOOK(22);
				RTHOOK(23);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				RTHOOK(24);
				if ((EIF_BOOLEAN)(loc3 != loc4)) {
					RTHOOK(25);
					RTHOOK(26);
					RTLE;
					RTEE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
	}
	RTHOOK(27);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.put_item_code */
void F1551_18522 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("put_item_code", 1550, Current, 6, 2, 24927);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(3);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		loc1 = F1551_18579(Current, arg2);
		RTHOOK(5);
		loc6 = F1551_18585(Current, loc1);
		RTHOOK(6);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		loc3 = F1025_9065(RTCW(tr1), loc6);
	}
	RTHOOK(7);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	loc4 = F1025_9071(RTCW(tr1), arg1);
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc4 == loc3)) {
	} else {
		RTHOOK(9);
		if ((EIF_BOOLEAN) (loc4 < loc3)) {
			RTHOOK(10);
			F1551_18589(Current, (EIF_INTEGER_32) (loc1 + loc3), (EIF_INTEGER_32) (loc3 - loc4));
		} else {
			RTHOOK(11);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
			RTHOOK(12);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc2);
			RTHOOK(13);
			if ((EIF_BOOLEAN) (loc5 > F1551_18506(Current))) {
				RTHOOK(14);
				F1551_18587(Current, loc5);
			}
			RTHOOK(15);
			F1551_18588(Current, (EIF_INTEGER_32) (loc1 + loc3), loc2);
		}
	}
	RTHOOK(16);
	F1551_18592(Current, arg1, loc4, loc1);
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {UC_STRING}.put */
void F1551_18523 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("put", 1550, Current, 6, 2, 24928);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(3);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		loc1 = F1551_18579(Current, arg2);
		RTHOOK(5);
		loc3 = F1551_18585(Current, loc1);
		RTHOOK(6);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		loc4 = F1025_9065(RTCW(tr1), loc3);
	}
	RTHOOK(7);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	loc5 = F1025_9068(RTCW(tr1), arg1);
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc5 == loc4)) {
	} else {
		RTHOOK(9);
		if ((EIF_BOOLEAN) (loc5 < loc4)) {
			RTHOOK(10);
			F1551_18589(Current, (EIF_INTEGER_32) (loc1 + loc4), (EIF_INTEGER_32) (loc4 - loc5));
		} else {
			RTHOOK(11);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc4);
			RTHOOK(12);
			loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + loc2);
			RTHOOK(13);
			if ((EIF_BOOLEAN) (loc6 > F1551_18506(Current))) {
				RTHOOK(14);
				F1551_18587(Current, loc6);
			}
			RTHOOK(15);
			F1551_18588(Current, (EIF_INTEGER_32) (loc1 + loc4), loc2);
		}
	}
	RTHOOK(16);
	F1551_18593(Current, arg1, loc5, loc1);
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {UC_STRING}.prepend */
void F1551_18524 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("prepend", 1550, Current, 0, 1, 24929);
	RTHOOK(1);
	F1551_18546(Current, arg1, ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	RTEE;
}

/* {UC_STRING}.append_string_general */
void F1551_18526 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("append_string_general", 1550, Current, 1, 1, 24931);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1098, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F1551_18532(Current, loc1);
	} else {
		RTHOOK(3);
		F1099_9938(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {UC_STRING}.append_item_code */
void F1551_18528 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("append_item_code", 1550, Current, 3, 1, 24933);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	loc2 = F1025_9071(RTCW(tr1), arg1);
	RTHOOK(2);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
	RTHOOK(4);
	if ((EIF_BOOLEAN) (loc3 > F1551_18506(Current))) {
		RTHOOK(5);
		F1551_18587(Current, loc3);
	}
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	RTHOOK(7);
	F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)));
	RTHOOK(8);
	F1551_18592(Current, arg1, loc2, loc1);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {UC_STRING}.append_character */
void F1551_18529 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("append_character", 1550, Current, 4, 1, 24934);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		RTHOOK(2);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(3);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		loc2 = F1025_9068(RTCW(tr1), arg1);
	}
	RTHOOK(4);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
	RTHOOK(6);
	if ((EIF_BOOLEAN) (loc3 > F1551_18506(Current))) {
		RTHOOK(7);
		F1551_18587(Current, loc3);
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	RTHOOK(9);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(10);
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		RTHOOK(11);
		F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
		RTHOOK(12);
		F1099_9926(Current, arg1, loc1);
		RTHOOK(13);
		F1551_18591(Current, loc4);
	} else {
		RTHOOK(14);
		F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(15);
		F1551_18593(Current, arg1, loc2, loc1);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {UC_STRING}.append_string */
void F1551_18530 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append_string", 1550, Current, 0, 1, 24935);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		F1551_18532(Current, arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {UC_STRING}.put_string */
void F1551_18531 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put_string", 1550, Current, 0, 1, 24936);
	RTHOOK(1);
	F1551_18532(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {UC_STRING}.append */
void F1551_18532 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLIU(6);
	
	RTEAA("append", 1550, Current, 8, 1, 24937);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(8944,F1020_8944, (Current));
	tr2 = RTOSCF(18595,F1551_18595, (Current));
	tb1 = F17_231(RTCW(tr1), arg1, tr2);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
		loc1 = F1025_9067(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
		if ((EIF_BOOLEAN)(loc1 == ti4_1)) {
			RTHOOK(4);
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc1);
			RTHOOK(5);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc1);
			RTHOOK(6);
			F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
			RTHOOK(7);
			F1099_9988(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
			RTHOOK(8);
			loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
			RTHOOK(9);
			F1099_9939(Current, arg1);
			RTHOOK(10);
			tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
			loc6 = (EIF_BOOLEAN) tb1;
			RTHOOK(11);
			ti4_1 = F1551_18506(Current);
			F1551_18591(Current, ti4_1);
			RTHOOK(12);
			ti4_1 = F1551_18506(Current);
			F1099_9988(Current, ti4_1);
			RTHOOK(13);
			F1551_18591(Current, loc5);
			RTHOOK(14);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
		} else {
			RTHOOK(15);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
			F1551_18533(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	} else {
		RTHOOK(16);
		loc7 = arg1;
		loc7 = RTRV(eif_new_type(1550, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			RTHOOK(17);
			tb1 = '\01';
			loc8 = arg1;
			loc8 = RTRV(eif_new_type(1551, 0x01),loc8);
			if (!(EIF_TEST(loc8))) {
				tr1 = RTOSCF(8944,F1020_8944, (Current));
				tr2 = RTOSCF(18596,F1551_18596, (Current));
				tb2 = F17_231(RTCW(tr1), loc7, tr2);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(18);
				if ((EIF_BOOLEAN)(loc7 == Current)) {
					RTHOOK(19);
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc4);
					RTHOOK(20);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc5);
					RTHOOK(21);
					F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					RTHOOK(22);
					F1099_9988(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					RTHOOK(23);
					loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
					RTHOOK(24);
					F1099_9939(Current, arg1);
					RTHOOK(25);
					tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
					loc6 = (EIF_BOOLEAN) tb1;
					RTHOOK(26);
					ti4_1 = F1551_18506(Current);
					F1551_18591(Current, ti4_1);
					RTHOOK(27);
					ti4_1 = F1551_18506(Current);
					F1099_9988(Current, ti4_1);
					RTHOOK(28);
					F1551_18591(Current, loc5);
					RTHOOK(29);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
				} else {
					RTHOOK(30);
					loc3 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_2_);
					RTHOOK(31);
					loc2 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_3_);
					RTHOOK(32);
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc2);
					RTHOOK(33);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc3);
					RTHOOK(34);
					F1551_18591(loc7, loc2);
					RTHOOK(35);
					F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					RTHOOK(36);
					F1099_9988(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					RTHOOK(37);
					loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
					RTHOOK(38);
					F1099_9939(Current, arg1);
					RTHOOK(39);
					tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
					loc6 = (EIF_BOOLEAN) tb1;
					RTHOOK(40);
					ti4_1 = F1551_18506(Current);
					F1551_18591(Current, ti4_1);
					RTHOOK(41);
					ti4_1 = F1551_18506(Current);
					F1099_9988(Current, ti4_1);
					RTHOOK(42);
					F1551_18591(Current, loc5);
					RTHOOK(43);
					F1551_18591(loc7, loc3);
					RTHOOK(44);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
				}
			} else {
				RTHOOK(45);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
				F1551_18533(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
			}
		} else {
			RTHOOK(46);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
			F1551_18533(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTHOOK(47);
	RTLE;
	RTEE;
}

/* {UC_STRING}.gobo_append_substring */
void F1551_18533 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("gobo_append_substring", 1550, Current, 5, 3, 24938);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 == Current)) {
			RTHOOK(4);
			loc5 = F1551_18558(Current);
		} else {
			RTHOOK(5);
			loc5 = (EIF_REFERENCE) arg1;
		}
		RTHOOK(6);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		loc3 = F1025_9067(RTCW(tr1), loc5, arg2, arg3);
		RTHOOK(7);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		RTHOOK(8);
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc3);
		RTHOOK(9);
		if ((EIF_BOOLEAN) (loc4 > F1551_18506(Current))) {
			RTHOOK(10);
			F1551_18587(Current, loc4);
		}
		RTHOOK(11);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
		RTHOOK(12);
		F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + loc1));
		RTHOOK(13);
		F1551_18594(Current, loc5, arg2, arg3, loc3, loc2);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {UC_STRING}.insert_character */
void F1551_18544 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("insert_character", 1550, Current, 3, 2, 24949);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)))) {
		RTHOOK(2);
		F1551_18529(Current, arg1);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
			RTHOOK(4);
			loc1 = (EIF_INTEGER_32) arg2;
		} else {
			RTHOOK(5);
			loc1 = F1551_18579(Current, arg2);
		}
		RTHOOK(6);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		loc2 = F1025_9068(RTCW(tr1), arg1);
		RTHOOK(7);
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc3 > F1551_18506(Current))) {
			RTHOOK(9);
			F1551_18587(Current, loc3);
		}
		RTHOOK(10);
		F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(11);
		F1551_18588(Current, loc1, loc2);
		RTHOOK(12);
		F1551_18593(Current, arg1, loc2, loc1);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {UC_STRING}.insert_string */
void F1551_18546 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("insert_string", 1550, Current, 5, 2, 24951);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7730[Dtype(arg1)-1096]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)))) {
			RTHOOK(4);
			F1551_18530(Current, arg1);
		} else {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(arg1 == Current)) {
				RTHOOK(6);
				loc5 = F1551_18558(Current);
			} else {
				RTHOOK(7);
				loc5 = (EIF_REFERENCE) arg1;
			}
			RTHOOK(8);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
				RTHOOK(9);
				loc2 = (EIF_INTEGER_32) arg2;
			} else {
				RTHOOK(10);
				loc2 = F1551_18579(Current, arg2);
			}
			RTHOOK(11);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc3 = F1025_9067(RTCW(tr1), loc5, ((EIF_INTEGER_32) 1L), loc1);
			RTHOOK(12);
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc3);
			RTHOOK(13);
			if ((EIF_BOOLEAN) (loc4 > F1551_18506(Current))) {
				RTHOOK(14);
				F1551_18587(Current, loc4);
			}
			RTHOOK(15);
			F1551_18588(Current, loc2, loc3);
			RTHOOK(16);
			F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + loc1));
			RTHOOK(17);
			F1551_18594(Current, loc5, ((EIF_INTEGER_32) 1L), loc1, loc3, loc2);
		}
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {UC_STRING}.replace_substring_all */
void F1551_18549 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("replace_substring_all", 1550, Current, 8, 2, 24954);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1551_18512(Current)) {
		RTHOOK(2);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		RTHOOK(4);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
		RTHOOK(5);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_3_);
		RTHOOK(6);
		loc4 = *(EIF_REFERENCE *)(Current);
		RTHOOK(7);
		loc5 = *(EIF_REFERENCE *)(RTCW(arg1));
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + loc2) - ((EIF_INTEGER_32) 1L)) > loc1)) break;
			RTHOOK(9);
			tb1 = F1161_10578(RTCW(loc4), loc5, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L)), loc2);
			if (tb1) {
				RTHOOK(10);
				if ((EIF_BOOLEAN)(loc3 == loc2)) {
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN) (loc3 < loc2)) {
						RTHOOK(12);
						F1551_18589(Current, (EIF_INTEGER_32) (loc6 + loc2), (EIF_INTEGER_32) (loc2 - loc3));
					} else {
						RTHOOK(13);
						loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - loc2);
						RTHOOK(14);
						loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc8);
						RTHOOK(15);
						if ((EIF_BOOLEAN) (loc7 > F1551_18506(Current))) {
							RTHOOK(16);
							F1551_18587(Current, loc7);
							RTHOOK(17);
							loc4 = *(EIF_REFERENCE *)(Current);
						}
						RTHOOK(18);
						F1551_18588(Current, (EIF_INTEGER_32) (loc6 + loc2), loc8);
					}
				}
				RTHOOK(19);
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
				RTHOOK(20);
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
				/* INLINED CODE (SPECIAL.copy_data) */
				memmove((EIF_CHARACTER_8 *)RTCW(loc4) + ((EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L))),(EIF_CHARACTER_8 *)tr1 + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_CHARACTER_8) * (rt_uint_ptr)loc3);
				RT_SPECIAL_COUNT(loc4) = eif_max_int32(RT_SPECIAL_COUNT(loc4), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L)) + loc3);
				/* END INLINED CODE */
				;
				RTHOOK(21);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				F1551_18591(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - ti4_1) + ti4_2));
				RTHOOK(22);
				loc6 += loc3;
			} else {
				RTHOOK(23);
				ti4_1 = F1551_18577(Current, loc6);
				loc6 = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {UC_STRING}.keep_head */
void F1551_18550 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("keep_head", 1550, Current, 0, 1, 24955);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(3);
		F1551_18591(Current, ((EIF_INTEGER_32) 0L));
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
				RTHOOK(6);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) arg1;
			} else {
				RTHOOK(7);
				ti4_1 = F1551_18579(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
			}
			RTHOOK(8);
			F1551_18591(Current, arg1);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {UC_STRING}.keep_tail */
void F1551_18551 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("keep_tail", 1550, Current, 1, 1, 24956);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(3);
		F1551_18591(Current, ((EIF_INTEGER_32) 0L));
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
				RTHOOK(6);
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - arg1);
			} else {
				RTHOOK(7);
				loc1 = F1551_18579(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1) + ((EIF_INTEGER_32) 1L)));
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
			}
			RTHOOK(8);
			F1551_18589(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc1);
			RTHOOK(9);
			F1551_18591(Current, arg1);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {UC_STRING}.remove_head */
void F1551_18552 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_head", 1550, Current, 0, 1, 24957);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		RTHOOK(2);
		F1551_18556(Current);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			F1551_18551(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1));
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {UC_STRING}.remove_tail */
void F1551_18553 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_tail", 1550, Current, 0, 1, 24958);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		RTHOOK(2);
		F1551_18556(Current);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			F1551_18550(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1));
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {UC_STRING}.remove */
void F1551_18554 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove", 1550, Current, 2, 1, 24959);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) arg1;
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		loc1 = F1551_18579(Current, arg1);
		RTHOOK(5);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		tc1 = F1551_18585(Current, loc1);
		loc2 = F1025_9065(RTCW(tr1), tc1);
	}
	RTHOOK(6);
	F1551_18589(Current, (EIF_INTEGER_32) (loc1 + loc2), loc2);
	RTHOOK(7);
	F1551_18591(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - ((EIF_INTEGER_32) 1L)));
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {UC_STRING}.wipe_out */
void F1551_18556 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wipe_out", 1550, Current, 0, 0, 24961);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	F1551_18591(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {UC_STRING}.copy */
void F1551_18557 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("copy", 1550, Current, 1, 1, 24962);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
		F1551_18591(RTCW(arg1), ti4_1);
		RTHOOK(4);
		F1097_9866(Current, arg1);
		RTHOOK(5);
		F1551_18591(Current, loc1);
		RTHOOK(6);
		F1551_18591(RTCW(arg1), loc1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {UC_STRING}.cloned_string */
EIF_REFERENCE F1551_18558 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("cloned_string", 1550, Current, 0, 0, 24963);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1_14(Current);
}

/* {UC_STRING}.out */
EIF_REFERENCE F1551_18559 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("out", 1550, Current, 6, 0, 24964);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), loc2);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc2 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTHOOK(4);
		loc5 = (EIF_CHARACTER_8) '';
		RTHOOK(5);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(7);
			loc4 = F1551_18585(Current, loc1);
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc4 <= loc5)) {
				RTHOOK(9);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, loc4);
			} else {
				RTHOOK(10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '%');
				RTHOOK(11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '/');
				RTHOOK(12);
				ti4_1 = (EIF_INTEGER_32) (loc4);
				tr1 = eif_out__i4_s1(ti4_1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
				RTHOOK(13);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '/');
			}
			RTHOOK(14);
			loc1++;
		}
	} else {
		RTHOOK(15);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		RTHOOK(16);
		loc6 = ((EIF_INTEGER_32) 127L);
		RTHOOK(17);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(18);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(19);
			loc3 = F1551_18575(Current, loc1);
			RTHOOK(20);
			if ((EIF_BOOLEAN) (loc3 <= loc6)) {
				RTHOOK(21);
				tr1 = RTOSCF(7011,F488_7011, (Current));
				tc1 = F1023_8985(RTCW(tr1), loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, tc1);
			} else {
				RTHOOK(22);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '%');
				RTHOOK(23);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '/');
				RTHOOK(24);
				tr1 = eif_out__i4_s1(loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7756[Dtype(RTCW(Result))-1098])(Result, tr1);
				RTHOOK(25);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, (EIF_CHARACTER_8) '/');
			}
			RTHOOK(26);
			ti4_1 = F1551_18577(Current, loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(27);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.as_lower */
EIF_REFERENCE F1551_18561 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("as_lower", 1550, Current, 0, 0, 24966);
	RTGC;
	RTHOOK(1);
	Result = F1551_18558(Current);
	RTHOOK(2);
	F1551_18563(RTCW(Result));
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.as_upper */
EIF_REFERENCE F1551_18562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("as_upper", 1550, Current, 0, 0, 24967);
	RTGC;
	RTHOOK(1);
	Result = F1551_18558(Current);
	RTHOOK(2);
	F1551_18564(RTCW(Result));
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.to_lower */
void F1551_18563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("to_lower", 1550, Current, 7, 0, 24968);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		loc6 = F1551_18575(Current, loc1);
		RTHOOK(5);
		tr1 = RTOSCF(5374,F386_5374, (Current));
		loc7 = F1276_12226(RTCW(tr1), loc6);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc7 != loc6)) {
			RTHOOK(7);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc3 = F1025_9071(RTCW(tr1), loc6);
			RTHOOK(8);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc4 = F1025_9071(RTCW(tr1), loc7);
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc4 == loc3)) {
			} else {
				RTHOOK(10);
				if ((EIF_BOOLEAN) (loc4 < loc3)) {
					RTHOOK(11);
					F1551_18589(Current, (EIF_INTEGER_32) (loc1 + loc3), (EIF_INTEGER_32) (loc3 - loc4));
				} else {
					RTHOOK(12);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
					RTHOOK(13);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc2);
					RTHOOK(14);
					if ((EIF_BOOLEAN) (loc5 > F1551_18506(Current))) {
						RTHOOK(15);
						F1551_18587(Current, loc5);
					}
					RTHOOK(16);
					F1551_18588(Current, (EIF_INTEGER_32) (loc1 + loc3), loc2);
				}
			}
			RTHOOK(17);
			F1551_18592(Current, loc7, loc4, loc1);
		}
		RTHOOK(18);
		ti4_1 = F1551_18577(Current, loc1);
		loc1 = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {UC_STRING}.to_upper */
void F1551_18564 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("to_upper", 1550, Current, 7, 0, 24969);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		loc6 = F1551_18575(Current, loc1);
		RTHOOK(5);
		tr1 = RTOSCF(5374,F386_5374, (Current));
		loc7 = F1276_12227(RTCW(tr1), loc6);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc7 != loc6)) {
			RTHOOK(7);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc3 = F1025_9071(RTCW(tr1), loc6);
			RTHOOK(8);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc4 = F1025_9071(RTCW(tr1), loc7);
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc4 == loc3)) {
			} else {
				RTHOOK(10);
				if ((EIF_BOOLEAN) (loc4 < loc3)) {
					RTHOOK(11);
					F1551_18589(Current, (EIF_INTEGER_32) (loc1 + loc3), (EIF_INTEGER_32) (loc3 - loc4));
				} else {
					RTHOOK(12);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
					RTHOOK(13);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc2);
					RTHOOK(14);
					if ((EIF_BOOLEAN) (loc5 > F1551_18506(Current))) {
						RTHOOK(15);
						F1551_18587(Current, loc5);
					}
					RTHOOK(16);
					F1551_18588(Current, (EIF_INTEGER_32) (loc1 + loc3), loc2);
				}
			}
			RTHOOK(17);
			F1551_18592(Current, loc7, loc4, loc1);
		}
		RTHOOK(18);
		ti4_1 = F1551_18577(Current, loc1);
		loc1 = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {UC_STRING}.to_utf8 */
EIF_REFERENCE F1551_18565 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("to_utf8", 1550, Current, 2, 0, 24970);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1097_9826(RTCW(Result), loc2);
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(5);
		tc1 = F1551_18585(Current, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7758[Dtype(RTCW(Result))-1098])(Result, tc1);
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.as_string */
EIF_REFERENCE F1551_18570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_string", 1550, Current, 0, 0, 24975);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1551_18565(Current);
}

/* {UC_STRING}.eol */

EIF_REFERENCE F1551_18572 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (18572,RTMS_EX_H("\012",1,10));
}

/* {UC_STRING}.item_code_at_byte_index */
EIF_INTEGER_32 F1551_18575 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item_code_at_byte_index", 1550, Current, 3, 1, 24980);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	loc3 = F1551_18585(Current, loc1);
	RTHOOK(3);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	Result = F1025_9059(RTCW(tr1), loc3);
	RTHOOK(4);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	loc2 = F1025_9065(RTCW(tr1), loc3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) - ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	loc1++;
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(7);
		loc3 = F1551_18585(Current, loc1);
		RTHOOK(8);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		ti4_1 = F1025_9060(RTCW(tr1), loc3);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 64L)) + ti4_1);
		RTHOOK(9);
		loc1++;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.character_item_at_byte_index */
EIF_CHARACTER_8 F1551_18576 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("character_item_at_byte_index", 1550, Current, 2, 1, 24981);
	RTGC;
	RTHOOK(1);
	loc1 = F1551_18585(Current, arg1);
	RTHOOK(2);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	ti4_1 = F1025_9065(RTCW(tr1), loc1);
	switch (ti4_1) {
		case 1L:
			RTHOOK(3);
			Result = (EIF_CHARACTER_8) loc1;
			break;
		case 2L:
			RTHOOK(4);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			loc2 = F1025_9059(RTCW(tr1), loc1);
			RTHOOK(5);
			loc1 = F1551_18585(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
			RTHOOK(6);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			ti4_1 = F1025_9060(RTCW(tr1), loc1);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 64L)) + ti4_1);
			RTHOOK(7);
			ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
			if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
				RTHOOK(8);
				tr1 = RTOSCF(7011,F488_7011, (Current));
				Result = F1023_8985(RTCW(tr1), loc2);
			} else {
				RTHOOK(9);
				Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
			}
			break;
		default:
			RTHOOK(10);
			loc2 = F1551_18575(Current, arg1);
			RTHOOK(11);
			ti4_1 = RTOSCF(3627,F272_3627, (RTCV(RTOSCF(2029,F150_2029, (Current)))));
			if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
				RTHOOK(12);
				tr1 = RTOSCF(7011,F488_7011, (Current));
				Result = F1023_8985(RTCW(tr1), loc2);
			} else {
				RTHOOK(13);
				Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
			}
			break;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.next_byte_index */
EIF_INTEGER_32 F1551_18577 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_byte_index", 1550, Current, 0, 1, 24982);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1853,F131_1853, (Current));
	tc1 = F1551_18585(Current, arg1);
	Result = F1025_9065(RTCW(tr1), tc1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + Result);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.shifted_byte_index */
EIF_INTEGER_32 F1551_18578 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("shifted_byte_index", 1550, Current, 1, 2, 24983);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		RTHOOK(4);
		tr1 = RTOSCF(1853,F131_1853, (Current));
		tc1 = F1551_18585(Current, Result);
		ti4_1 = F1025_9065(RTCW(tr1), tc1);
		Result += ti4_1;
		RTHOOK(5);
		if ((EIF_BOOLEAN) (Result > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
			RTHOOK(6);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
		} else {
			RTHOOK(7);
			loc1++;
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.byte_index */
EIF_INTEGER_32 F1551_18579 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("byte_index", 1550, Current, 2, 1, 24984);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		RTHOOK(2);
		Result = (EIF_INTEGER_32) arg1;
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_))) {
			RTHOOK(4);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(6);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_);
			RTHOOK(7);
			Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_);
		}
		for (;;) {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc1 == arg1)) break;
			RTHOOK(10);
			loc2 = F1551_18585(Current, Result);
			RTHOOK(11);
			tr1 = RTOSCF(1853,F131_1853, (Current));
			ti4_1 = F1025_9065(RTCW(tr1), loc2);
			Result += ti4_1;
			RTHOOK(12);
			loc1++;
		}
	}
	RTHOOK(13);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(14);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) = (EIF_INTEGER_32) Result;
	RTHOOK(18);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.reset_byte_index_cache */
void F1551_18583 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_byte_index_cache", 1550, Current, 0, 0, 24988);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {UC_STRING}.byte_item */
EIF_CHARACTER_8 F1551_18585 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("byte_item", 1550, Current, 1, 1, 24990);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	RTHOOK(3);
	Result = F1099_9905(Current, arg1);
	RTHOOK(4);
	F1551_18591(Current, loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.put_byte */
void F1551_18586 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_byte", 1550, Current, 1, 2, 24991);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	RTHOOK(3);
	F1099_9926(Current, arg1, arg2);
	RTHOOK(4);
	F1551_18591(Current, loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {UC_STRING}.resize_byte_storage */
void F1551_18587 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("resize_byte_storage", 1550, Current, 1, 1, 24992);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > F1551_18506(Current))) {
		RTHOOK(2);
		F1099_9971(Current, arg1);
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
		RTHOOK(4);
		F1551_18591(Current, arg1);
		RTHOOK(5);
		F1099_9988(Current, arg1);
		RTHOOK(6);
		F1551_18591(Current, loc1);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {UC_STRING}.move_bytes_right */
void F1551_18588 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_bytes_right", 1550, Current, 3, 2, 24993);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) > arg1)) {
		RTHOOK(2);
		F1551_18583(Current);
	}
	RTHOOK(3);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	RTHOOK(4);
	loc2 = (EIF_INTEGER_32) arg1;
	RTHOOK(5);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_)) += arg2;
	RTHOOK(6);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(7);
	F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	for (;;) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		RTHOOK(9);
		tc1 = F1099_9905(Current, loc1);
		F1099_9926(Current, tc1, (EIF_INTEGER_32) (loc1 + arg2));
		RTHOOK(10);
		loc1--;
	}
	RTHOOK(11);
	F1551_18591(Current, loc3);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {UC_STRING}.move_bytes_left */
void F1551_18589 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_bytes_left", 1550, Current, 3, 2, 24994);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) > (EIF_INTEGER_32) (arg1 - arg2))) {
		RTHOOK(2);
		F1551_18583(Current);
	}
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(4);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	RTHOOK(5);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(6);
	F1551_18591(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(8);
		tc1 = F1099_9905(Current, loc1);
		F1099_9926(Current, tc1, (EIF_INTEGER_32) (loc1 - arg2));
		RTHOOK(9);
		loc1++;
	}
	RTHOOK(10);
	F1551_18591(Current, loc3);
	RTHOOK(11);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_)) -= arg2;
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {UC_STRING}.set_count */
void F1551_18591 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_count", 1550, Current, 0, 1, 24996);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) > arg1)) {
		RTHOOK(2);
		F1551_18583(Current);
	}
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {UC_STRING}.put_code_at_byte_index */
void F1551_18592 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("put_code_at_byte_index", 1550, Current, 3, 3, 24997);
	RTGC;
	
	RTHOOK(2);
	loc3 = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 + arg2) - ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == arg3)) break;
		RTHOOK(5);
		tr1 = RTOSCF(7011,F488_7011, (Current));
		loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
		RTHOOK(6);
		F1551_18586(Current, loc2, loc1);
		RTHOOK(7);
		loc3 /= ((EIF_INTEGER_32) 64L);
		RTHOOK(8);
		loc1--;
	}
	RTHOOK(9);
	switch (arg2) {
		case 1L:
			RTHOOK(10);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), loc3);
			break;
		case 2L:
			RTHOOK(11);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 192L)));
			break;
		case 3L:
			RTHOOK(12);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 224L)));
			break;
		case 4L:
			RTHOOK(13);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 240L)));
			break;
		case 5L:
			RTHOOK(14);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 248L)));
			break;
		case 6L:
			RTHOOK(15);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc2 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 252L)));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(16);
	F1551_18586(Current, loc2, arg3);
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {UC_STRING}.put_character_at_byte_index */
void F1551_18593 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("put_character_at_byte_index", 1550, Current, 2, 3, 24998);
	RTGC;
	
	RTHOOK(2);
	switch (arg2) {
		case 1L:
			RTHOOK(3);
			F1551_18586(Current, arg1, arg3);
			break;
		case 2L:
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) (arg1);
			RTHOOK(5);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc1 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 192L)));
			RTHOOK(6);
			F1551_18586(Current, loc1, arg3);
			RTHOOK(7);
			tr1 = RTOSCF(7011,F488_7011, (Current));
			loc1 = F1023_8985(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
			RTHOOK(8);
			F1551_18586(Current, loc1, (EIF_INTEGER_32) (arg3 + ((EIF_INTEGER_32) 1L)));
			break;
		default:
			RTHOOK(9);
			ti4_1 = (EIF_INTEGER_32) (arg1);
			F1551_18592(Current, ti4_1, arg2, arg3);
			break;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {UC_STRING}.put_substring_at_byte_index */
void F1551_18594 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,loc10);
	RTLIU(8);
	
	RTEAA("put_substring_at_byte_index", 1550, Current, 10, 5, 24999);
	RTGC;
	
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		tb1 = '\0';
		loc7 = arg1;
		loc7 = RTRV(eif_new_type(1098, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = RTOSCF(8944,F1020_8944, (Current));
			tr2 = RTOSCF(18595,F1551_18595, (Current));
			tb2 = F17_231(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L));
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc2 == arg4)) {
				RTHOOK(6);
				loc3 = (EIF_INTEGER_32) arg5;
				RTHOOK(7);
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					RTHOOK(8);
					if ((EIF_BOOLEAN) (loc1 > arg3)) break;
					RTHOOK(9);
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(loc7)-845])(loc7, loc1));
					F1551_18586(Current, tc1, loc3);
					RTHOOK(10);
					loc3++;
					RTHOOK(11);
					loc1++;
				}
			} else {
				RTHOOK(12);
				loc3 = (EIF_INTEGER_32) arg5;
				RTHOOK(13);
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					RTHOOK(14);
					if ((EIF_BOOLEAN) (loc1 > arg3)) break;
					RTHOOK(15);
					loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(loc7)-845])(loc7, loc1));
					RTHOOK(16);
					tr1 = RTOSCF(1853,F131_1853, (Current));
					loc4 = F1025_9068(RTCW(tr1), loc5);
					RTHOOK(17);
					F1551_18593(Current, loc5, loc4, loc3);
					RTHOOK(18);
					loc3 += loc4;
					RTHOOK(19);
					loc1++;
				}
			}
		} else {
			RTHOOK(20);
			tb1 = '\0';
			tr1 = RTOSCF(8944,F1020_8944, (Current));
			tb2 = F17_231(RTCW(tr1), arg1, Current);
			if (tb2) {
				loc8 = arg1;
				loc8 = RTRV(eif_new_type(1550, 0x01),loc8);
				tb1 = EIF_TEST(loc8);
			}
			if (tb1) {
				RTHOOK(21);
				loc3 = (EIF_INTEGER_32) arg5;
				RTHOOK(22);
				loc1 = F1551_18579(loc8, arg2);
				RTHOOK(23);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
				for (;;) {
					RTHOOK(24);
					if ((EIF_BOOLEAN) (loc1 > loc2)) break;
					RTHOOK(25);
					tc1 = F1551_18585(loc8, loc1);
					F1551_18586(Current, tc1, loc3);
					RTHOOK(26);
					loc3++;
					RTHOOK(27);
					loc1++;
				}
			} else {
				RTHOOK(28);
				loc9 = arg1;
				loc9 = RTRV(eif_new_type(1551, 0x01),loc9);
				if (EIF_TEST(loc9)) {
					RTHOOK(29);
					loc3 = (EIF_INTEGER_32) arg5;
					RTHOOK(30);
					loc1 = (RTNA((loc9, arg2)), ((EIF_INTEGER_32) 0));
					RTHOOK(31);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
					for (;;) {
						RTHOOK(32);
						if ((EIF_BOOLEAN) (loc1 > loc2)) break;
						RTHOOK(33);
						tc1 = (RTNA((loc9, loc1)), ((EIF_CHARACTER_8) 0));
						F1551_18586(Current, tc1, loc3);
						RTHOOK(34);
						loc3++;
						RTHOOK(35);
						loc1++;
					}
				} else {
					RTHOOK(36);
					loc10 = arg1;
					loc10 = RTRV(eif_new_type(1550, 0x01),loc10);
					if (EIF_TEST(loc10)) {
						RTHOOK(37);
						loc3 = (EIF_INTEGER_32) arg5;
						RTHOOK(38);
						loc1 = F1551_18579(loc10, arg2);
						RTHOOK(39);
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
						for (;;) {
							RTHOOK(40);
							if ((EIF_BOOLEAN) (loc1 > loc2)) break;
							RTHOOK(41);
							loc6 = F1551_18575(loc10, loc1);
							RTHOOK(42);
							tr1 = RTOSCF(1853,F131_1853, (Current));
							loc4 = F1025_9071(RTCW(tr1), loc6);
							RTHOOK(43);
							F1551_18592(Current, loc6, loc4, loc3);
							RTHOOK(44);
							loc3 += loc4;
							RTHOOK(45);
							ti4_1 = F1551_18577(loc10, loc1);
							loc1 = (EIF_INTEGER_32) ti4_1;
						}
					} else {
						RTHOOK(46);
						loc3 = (EIF_INTEGER_32) arg5;
						RTHOOK(47);
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							RTHOOK(48);
							if ((EIF_BOOLEAN) (loc1 > arg3)) break;
							RTHOOK(49);
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7494[Dtype(RTCW(arg1))-1094])(arg1, loc1);
							loc6 = (EIF_INTEGER_32) tu4_1;
							RTHOOK(50);
							tr1 = RTOSCF(1853,F131_1853, (Current));
							loc4 = F1025_9071(RTCW(tr1), loc6);
							RTHOOK(51);
							F1551_18592(Current, loc6, loc4, loc3);
							RTHOOK(52);
							loc3 += loc4;
							RTHOOK(53);
							loc1++;
						}
					}
				}
			}
		}
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {UC_STRING}.dummy_string */

EIF_REFERENCE F1551_18595 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (18595,RTMS_EX_H("",0,0));
}

/* {UC_STRING}.dummy_uc_string */
static EIF_REFERENCE F1551_18596_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("dummy_uc_string", 1550, Current, 0, 0, 25001);
	RTGC;
	RTOSP (18596);
#define Result RTOSR(18596)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1550, 0x01).id, 1550, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F1551_18475(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18596);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1551_18596 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18596,F1551_18596_body,(Current));
}

/* {UC_STRING}.old_wipe_out */
void F1551_18597 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("old_wipe_out", 1550, Current, 0, 0, 25002);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	F1099_9968(Current);
	RTHOOK(3);
	F1551_18556(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {UC_STRING}.old_left_adjust */
void F1551_18599 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("old_left_adjust", 1550, Current, 2, 0, 25004);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		switch (F1551_18488(Current, loc1)) {
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) '\012':
			case (EIF_CHARACTER_8) '\015':
			case (EIF_CHARACTER_8) ' ':
				RTHOOK(5);
				loc1++;
				break;
			default:
				RTHOOK(6);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				break;
		}
	}
	RTHOOK(7);
	F1551_18552(Current, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {UC_STRING}.old_right_adjust */
void F1551_18600 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("old_right_adjust", 1550, Current, 2, 0, 25005);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		switch (F1551_18488(Current, loc2)) {
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) '\012':
			case (EIF_CHARACTER_8) '\015':
			case (EIF_CHARACTER_8) ' ':
				RTHOOK(5);
				loc2--;
				break;
			default:
				RTHOOK(6);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				break;
		}
	}
	RTHOOK(7);
	F1551_18550(Current, loc2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {UC_STRING}.code */
EIF_NATURAL_32 F1551_18601 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("code", 1550, Current, 0, 1, 25006);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1551_18487(Current, arg1);
	Result = (EIF_NATURAL_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_STRING}.put_code */
void F1551_18603 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_code", 1550, Current, 0, 2, 25008);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) arg1;
	F1551_18522(Current, ti4_1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {UC_STRING}.append_code */
void F1551_18604 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("append_code", 1550, Current, 0, 1, 25009);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) arg1;
	F1551_18528(Current, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
