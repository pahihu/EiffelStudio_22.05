
#ifndef _C17_bi835_
#define _C17_bi835_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1541_18236(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit835(void);
extern char *(*R3995[])();

#ifdef __cplusplus
}
#endif

#endif
