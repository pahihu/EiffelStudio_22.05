/*
 * Code for class STRING_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st809.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_AS}.initialize */
void F1515_18112 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("initialize", 1514, Current, 0, 8, 24516);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F182_2312(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {STRING_AS}.process */
void F1515_18113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1514, Current, 0, 1, 24517);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3903[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {STRING_AS}.value_32 */
EIF_REFERENCE F1515_18115 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("value_32", 1514, Current, 0, 0, 24519);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(78, 0x00).id, 78, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F79_1102(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {STRING_AS}.value_to_lower */
void F1515_18120 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("value_to_lower", 1514, Current, 1, 0, 24524);
	RTGC;
	RTHOOK(1);
	tr2 = F1096_9809(RTCV(F1515_18115(Current)));
	tr1 = RTLNS(eif_new_type(78, 0x00).id, 78, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc1 = F79_1088(RTCW(tr1), tr2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7619[Dtype(RTCW(tr1))-1095])(tr1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(tr1))-1098])(tr1, loc1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {STRING_AS}.string_text */
EIF_REFERENCE F1515_18121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("string_text", 1514, Current, 0, 1, 24525);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(53, 0x01).id, 53, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F54_785(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O13818[dtype-1448]), *(EIF_INTEGER_32 *)(Current + O13818[dtype-1448]));
	Result = F452_6319(RTCW(arg1), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {STRING_AS}.set_is_once_string */
void F1515_18122 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_once_string", 1514, Current, 0, 1, 24526);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14289[Dtype(Current)-1514]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {STRING_AS}.once_string_keyword */
EIF_REFERENCE F1515_18128 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("once_string_keyword", 1514, Current, 2, 1, 24532);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current + O14299[Dtype(Current)-1514]);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F452_6293(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F452_6288(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1453, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {STRING_AS}.set_once_string_keyword */
void F1515_18129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_once_string_keyword", 1514, Current, 0, 1, 24533);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current + O14299[Dtype(Current)-1514]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {STRING_AS}.set_type */
void F1515_18131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_type", 1514, Current, 0, 1, 24535);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {STRING_AS}.first_token */
EIF_REFERENCE F1515_18132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("first_token", 1514, Current, 1, 1, 24536);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		Result = F1515_18128(Current, arg1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL) && EIF_TEST(loc1))) {
			RTHOOK(4);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(loc1)-1366])(loc1, arg1);
		}
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(6);
		RTHOOK(7);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Current;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit809 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
