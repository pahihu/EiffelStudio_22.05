
#ifndef _C17_bi815_
#define _C17_bi815_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1521_18175(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R3988[])();

#ifdef __cplusplus
}
#endif

#endif
