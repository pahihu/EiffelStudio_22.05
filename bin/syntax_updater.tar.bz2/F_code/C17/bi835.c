/*
 * Code for class BIN_MOD_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi835.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BIN_MOD_AS}.process */
void F1541_18236 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1540, Current, 0, 1, 24643);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3995[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit835 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
