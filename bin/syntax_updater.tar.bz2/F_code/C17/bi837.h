
#ifndef _C17_bi837_
#define _C17_bi837_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1543_18242(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit837(void);
extern char *(*R3993[])();

#ifdef __cplusplus
}
#endif

#endif
