
#ifndef _C17_bi818_
#define _C17_bi818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1524_18182(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1524_18183(EIF_REFERENCE);
extern EIF_REFERENCE F1524_18184(EIF_REFERENCE, EIF_REFERENCE);
extern void F1524_18187(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern void F140_1960(EIF_REFERENCE);
extern void F1519_18151(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3984[])();

#ifdef __cplusplus
}
#endif

#endif
