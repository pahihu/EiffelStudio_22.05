
#ifndef _C17_bi823_
#define _C17_bi823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1529_18206(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit823(void);
extern char *(*R4002[])();

#ifdef __cplusplus
}
#endif

#endif
