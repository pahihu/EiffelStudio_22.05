
#ifndef _C17_bi826_
#define _C17_bi826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1532_18212(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit826(void);
extern char *(*R3989[])();

#ifdef __cplusplus
}
#endif

#endif
