/*
 * Code for class INTEGER_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in806.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_AS}.make_from_string */
void F1512_18056 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("make_from_string", 1511, Current, 0, 3, 24459);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1512_18090(Current, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.make_from_hexa_string */
void F1512_18057 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("make_from_hexa_string", 1511, Current, 0, 3, 24460);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1512_18086(Current, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.make_from_octal_string */
void F1512_18058 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("make_from_octal_string", 1511, Current, 0, 3, 24461);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1512_18087(Current, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.make_from_binary_string */
void F1512_18059 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("make_from_binary_string", 1511, Current, 0, 3, 24462);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1512_18088(Current, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.sign_symbol */
EIF_REFERENCE F1512_18061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("sign_symbol", 1511, Current, 2, 1, 24464);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_4_);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F452_6293(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F452_6288(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1450, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {INTEGER_AS}.set_sign_symbol */
void F1512_18062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_sign_symbol", 1511, Current, 0, 1, 24465);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13818[Dtype(arg1)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_4_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.first_token */
EIF_REFERENCE F1512_18063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("first_token", 1511, Current, 3, 1, 24466);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Current;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(loc1)-1366])(loc1, arg1);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc2;
		} else {
			RTHOOK(7);
			tr1 = F1512_18061(Current, arg1);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(8);
				RTHOOK(9);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) loc3;
			} else {
				RTHOOK(10);
				RTHOOK(11);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Current;
			}
		}
	}/* NOTREACHED */
	
}

/* {INTEGER_AS}.number_text */
EIF_REFERENCE F1512_18064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("number_text", 1511, Current, 0, 1, 24467);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(53, 0x01).id, 53, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F54_785(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_3_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_3_));
	Result = F452_6319(RTCW(arg1), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_AS}.has_constant_type */
EIF_BOOLEAN F1512_18066 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("has_constant_type", 1511, Current, 0, 0, 24469);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL);
}

/* {INTEGER_AS}.process */
void F1512_18068 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1511, Current, 0, 1, 24471);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3894[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {INTEGER_AS}.natural_32_value */
EIF_NATURAL_32 F1512_18071 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_32_value", 1511, Current, 0, 0, 24474);
	RTGC;
	RTHOOK(1);
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_);
	Result = (EIF_NATURAL_32) tu8_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_AS}.natural_64_value */
EIF_NATURAL_64 F1512_18072 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("natural_64_value", 1511, Current, 0, 0, 24475);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_);
}

/* {INTEGER_AS}.read_hexadecimal_value */
void F1512_18086 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_64 loc5 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTEAA("read_hexadecimal_value", 1511, Current, 5, 2, 24489);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg2));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc1) < ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 16L)))) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc3) + ((EIF_INTEGER_32) (loc2 - loc1)));
		/* END INLINED CODE */
		tc1 = tc2;
		loc4 = eif_builtin_CHARACTER_8_as_lower__c1_c1(tc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc4 >= (EIF_CHARACTER_8) 'a')) {
			RTHOOK(7);
			ti4_1 = (EIF_INTEGER_32) (loc4);
			tu8_1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 87L));
			tu8_1 = eif_bit_shift_left(tu8_1,(EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
			tu8_1 = eif_bit_or(loc5,tu8_1);
			loc5 = (EIF_NATURAL_64) tu8_1;
		} else {
			RTHOOK(8);
			ti4_1 = (EIF_INTEGER_32) (loc4);
			tu8_1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 48L));
			tu8_1 = eif_bit_shift_left(tu8_1,(EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
			tu8_1 = eif_bit_or(loc5,tu8_1);
			loc5 = (EIF_NATURAL_64) tu8_1;
		}
		RTHOOK(9);
		loc1++;
	}
	RTHOOK(10);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	for (;;) {
		RTHOOK(11);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg2))-845])(arg2, loc1));
			tb1 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
		}
		if (tb1) break;
		RTHOOK(12);
		loc1++;
	}
	RTHOOK(13);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc1) + ((EIF_INTEGER_32) 2L));
	RTHOOK(14);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 16L))) {
		RTHOOK(15);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(16);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '-');
		RTHOOK(17);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_) = (EIF_NATURAL_64) loc5;
		RTHOOK(18);
		F1512_18091(Current);
		RTHOOK(19);
		if ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\000')) {
			RTHOOK(20);
			switch (loc1) {
				case 2L:
					RTHOOK(21);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 1L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 4L:
					RTHOOK(22);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 2L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 8L:
					RTHOOK(23);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 4L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 16L:
					RTHOOK(24);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
			}
		}
	}
	RTHOOK(25);
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = F1512_18066(Current);
	}
	if (tb2) {
		RTHOOK(26);
		F1512_18092(Current);
	}
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.read_octal_value */
void F1512_18087 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_64 loc5 = (EIF_NATURAL_64) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTEAA("read_octal_value", 1511, Current, 6, 2, 24490);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg2));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc1) < ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 21L)))) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc3) + ((EIF_INTEGER_32) (loc2 - loc1)));
		/* END INLINED CODE */
		loc4 = tc2;
		RTHOOK(6);
		ti4_1 = (EIF_INTEGER_32) (loc4);
		tu8_1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 48L));
		tu8_1 = eif_bit_shift_left(tu8_1,(EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 3L)));
		tu8_1 = eif_bit_or(loc5,tu8_1);
		loc5 = (EIF_NATURAL_64) tu8_1;
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 21L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 21L)) >= ((EIF_INTEGER_32) 2L)))) {
		RTHOOK(9);
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc3) + ((EIF_INTEGER_32) (loc2 - loc1)));
		/* END INLINED CODE */
		loc4 = tc2;
		RTHOOK(10);
		if ((EIF_BOOLEAN)(loc4 == (EIF_CHARACTER_8) '1')) {
			RTHOOK(11);
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(12);
			tu8_1 = eif_bit_or(loc5,((EIF_NATURAL_64) RTU64C(9223372036854775808)));
			loc5 = (EIF_NATURAL_64) tu8_1;
		}
		RTHOOK(13);
		loc1++;
	}
	RTHOOK(14);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	for (;;) {
		RTHOOK(15);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg2))-845])(arg2, loc1));
			tb1 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
		}
		if (tb1) break;
		RTHOOK(16);
		loc1++;
	}
	RTHOOK(17);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc1) + ((EIF_INTEGER_32) 2L));
	RTHOOK(18);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 22L)) && (EIF_BOOLEAN) !loc6)) {
		RTHOOK(19);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(20);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '-');
		RTHOOK(21);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_) = (EIF_NATURAL_64) loc5;
		RTHOOK(22);
		F1512_18091(Current);
	}
	RTHOOK(23);
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = F1512_18066(Current);
	}
	if (tb2) {
		RTHOOK(24);
		F1512_18092(Current);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.read_binary_value */
void F1512_18088 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 loc4 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTEAA("read_binary_value", 1511, Current, 4, 2, 24491);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg2));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc1) < ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 64L)))) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc3) + ((EIF_INTEGER_32) (loc2 - loc1)));
		/* END INLINED CODE */
		tc1 = tc2;
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '1')) {
			RTHOOK(6);
			tu8_1 = (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L);
			tu8_1 = eif_bit_shift_left(tu8_1,loc1);
			tu8_1 = eif_bit_or(loc4,tu8_1);
			loc4 = (EIF_NATURAL_64) tu8_1;
		}
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	for (;;) {
		RTHOOK(9);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg2))-845])(arg2, loc1));
			tb1 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
		}
		if (tb1) break;
		RTHOOK(10);
		loc1++;
	}
	RTHOOK(11);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc1) + ((EIF_INTEGER_32) 2L));
	RTHOOK(12);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 64L))) {
		RTHOOK(13);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(14);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '-');
		RTHOOK(15);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_) = (EIF_NATURAL_64) loc4;
		RTHOOK(16);
		F1512_18091(Current);
		RTHOOK(17);
		if ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\000')) {
			RTHOOK(18);
			switch (loc1) {
				case 8L:
					RTHOOK(19);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 1L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 16L:
					RTHOOK(20);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 2L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 32L:
					RTHOOK(21);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 4L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
				case 64L:
					RTHOOK(22);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					break;
			}
		}
	}
	RTHOOK(23);
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = F1512_18066(Current);
	}
	if (tb2) {
		RTHOOK(24);
		F1512_18092(Current);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.largest_natural_64 */

EIF_REFERENCE F1512_18089 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (18089,RTMS_EX_H("18446744073709551615",20,750660917));
}

/* {INTEGER_AS}.read_decimal_value */
void F1512_18090 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc4 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("read_decimal_value", 1511, Current, 4, 2, 24493);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc2 >= loc3)) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(arg2))-845])(arg2, loc2));
			tb1 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
		}
		if (tb1) break;
		RTHOOK(5);
		loc2++;
	}
	RTHOOK(6);
	loc2--;
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7616[Dtype(RTCW(arg2))-1095])(arg2, loc2);
	RTHOOK(8);
	loc3 -= loc2;
	RTHOOK(9);
	tb2 = '\01';
	if (!(EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 20L))) {
		tb3 = '\0';
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 20L))) {
			tr1 = RTOSCF(18089,F1512_18089, (Current));
			tb4 = F380_5341(RTCW(arg2), tr1);
			tb3 = tb4;
		}
		tb2 = tb3;
	}
	if (tb2) {
		RTHOOK(10);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(11);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(12);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(13);
		loc1 = *(EIF_REFERENCE *)(RTCW(arg2));
		RTHOOK(14);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			RTHOOK(15);
			if ((EIF_BOOLEAN) (loc2 >= loc3)) break;
			RTHOOK(16);
			/* INLINED CODE (SPECIAL.item) */
			tc2 = *((EIF_CHARACTER_8 *)RTCW(loc1) + (loc2));
			/* END INLINED CODE */
			tc1 = tc2;
			ti4_1 = (EIF_INTEGER_32) (tc1);
			tu8_1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 48L));
			loc4 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) (loc4 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L)) + tu8_1);
			RTHOOK(17);
			loc2++;
		}
		RTHOOK(18);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_) = (EIF_NATURAL_64) loc4;
		RTHOOK(19);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
		RTHOOK(20);
		F1512_18091(Current);
	}
	RTHOOK(21);
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = F1512_18066(Current);
	}
	if (tb2) {
		RTHOOK(22);
		F1512_18092(Current);
	}
	RTHOOK(23);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.compute_type */
void F1512_18091 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("compute_type", 1511, Current, 1, 0, 24494);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_3_7_0_0_0_);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) && (EIF_BOOLEAN)(loc1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 128L))) {
			RTHOOK(4);
			ti4_1 = eif_bit_or(((EIF_INTEGER_32) 1L),((EIF_INTEGER_32) 2L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 4L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
		} else {
			RTHOOK(5);
			if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 32768L))) {
				RTHOOK(6);
				ti4_1 = eif_bit_or(((EIF_INTEGER_32) 2L),((EIF_INTEGER_32) 4L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
			} else {
				RTHOOK(7);
				if ((EIF_BOOLEAN) (loc1 <= ((EIF_NATURAL_64) RTU64C(2147483648)))) {
					RTHOOK(8);
					ti4_1 = eif_bit_or(((EIF_INTEGER_32) 4L),((EIF_INTEGER_32) 8L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
				} else {
					RTHOOK(9);
					if ((EIF_BOOLEAN) (loc1 <= ((EIF_NATURAL_64) RTU64C(9223372036854775808)))) {
						RTHOOK(10);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
					} else {
						RTHOOK(11);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
			}
		}
	} else {
		RTHOOK(12);
		if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 127L))) {
			RTHOOK(13);
			ti4_1 = eif_bit_or(((EIF_INTEGER_32) 1L),((EIF_INTEGER_32) 2L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 4L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 16L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 32L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 64L));
			ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
		} else {
			RTHOOK(14);
			if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 255L))) {
				RTHOOK(15);
				ti4_1 = eif_bit_or(((EIF_INTEGER_32) 2L),((EIF_INTEGER_32) 4L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 16L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 32L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 64L));
				ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
			} else {
				RTHOOK(16);
				if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 32767L))) {
					RTHOOK(17);
					ti4_1 = eif_bit_or(((EIF_INTEGER_32) 2L),((EIF_INTEGER_32) 4L));
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 8L));
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 32L));
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 64L));
					ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
				} else {
					RTHOOK(18);
					if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 65535L))) {
						RTHOOK(19);
						ti4_1 = eif_bit_or(((EIF_INTEGER_32) 4L),((EIF_INTEGER_32) 8L));
						ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 32L));
						ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 64L));
						ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
					} else {
						RTHOOK(20);
						if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_32) 2147483647L))) {
							RTHOOK(21);
							ti4_1 = eif_bit_or(((EIF_INTEGER_32) 4L),((EIF_INTEGER_32) 8L));
							ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 64L));
							ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
						} else {
							RTHOOK(22);
							if ((EIF_BOOLEAN) (loc1 <= ((EIF_NATURAL_64) RTU64C(4294967295)))) {
								RTHOOK(23);
								ti4_1 = eif_bit_or(((EIF_INTEGER_32) 8L),((EIF_INTEGER_32) 64L));
								ti4_1 = eif_bit_or(ti4_1,((EIF_INTEGER_32) 128L));
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
							} else {
								RTHOOK(24);
								if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(9223372036854775807)))) {
									RTHOOK(25);
									ti4_1 = eif_bit_or(((EIF_INTEGER_32) 8L),((EIF_INTEGER_32) 128L));
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ti4_1;
								} else {
									
									RTHOOK(27);
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
								}
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(28);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
	ti4_1 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 4L));
	if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
		RTHOOK(29);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	} else {
		RTHOOK(30);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
		ti4_1 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 8L));
		if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(31);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
		} else {
			RTHOOK(32);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_6_);
			ti4_1 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 128L));
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
				RTHOOK(33);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
			} else {
				RTHOOK(34);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				RTHOOK(35);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	RTHOOK(36);
	RTLE;
	RTEE;
}

/* {INTEGER_AS}.adjust_type */
void F1512_18092 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("adjust_type", 1511, Current, 0, 0, 24495);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_3_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
