
#ifndef _C17_bi817_
#define _C17_bi817_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1523_18181(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit817(void);
extern char *(*R3985[])();

#ifdef __cplusplus
}
#endif

#endif
