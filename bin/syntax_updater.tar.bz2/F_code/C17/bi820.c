/*
 * Code for class BIN_OR_ELSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi820.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BIN_OR_ELSE_AS}.make */
void F1526_18194 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTEAA("make", 1525, Current, 0, 4, 24604);
	RTGC;
	RTHOOK(1);
	F1519_18151(Current, arg1, arg2, arg3);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O13818[Dtype(arg4)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {BIN_OR_ELSE_AS}.process */
void F1526_18197 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1525, Current, 0, 1, 24601);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3987[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {BIN_OR_ELSE_AS}.else_keyword */
EIF_REFERENCE F1526_18199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("else_keyword", 1525, Current, 1, 1, 24603);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_);
	RTHOOK(2);
	tb1 = F452_6293(RTCW(arg1), loc1);
	if (tb1) {
		RTHOOK(3);
		tr1 = F452_6288(RTCW(arg1), loc1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit820 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
