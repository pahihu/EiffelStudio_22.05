/*
 * Code for class FEATURE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fe839.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FEATURE_AS}.initialize */
void F1545_18334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("initialize", 1544, Current, 0, 5, 24743);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) arg4;
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) arg5;
	RTHOOK(6);
	F1545_18344(Current, (EIF_BOOLEAN) 1);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {FEATURE_AS}.process */
void F1545_18335 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1544, Current, 0, 1, 24744);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4036[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {FEATURE_AS}.first_token */
EIF_REFERENCE F1545_18341 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("first_token", 1544, Current, 0, 1, 24750);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1439_17246(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_AS}.last_token */
EIF_REFERENCE F1545_18342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("last_token", 1544, Current, 0, 1, 24751);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1373_16567(RTCW(tr1), arg1);
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(Result == NULL)) {
			tb2 = F182_2323(RTCW(Result));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = F1439_17247(RTCW(tr1), arg1);
		}
	} else {
		RTHOOK(5);
		tb1 = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
			tb2 = '\01';
			if (!F1545_18348(Current)) {
				tb2 = F1545_18352(Current);
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(6);
			Result = F452_6304(RTCW(arg1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) - ((EIF_INTEGER_32) 1L)));
			RTHOOK(7);
			if ((EIF_BOOLEAN)(Result == NULL)) {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				Result = F1373_16567(RTCW(tr1), arg1);
			}
		} else {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1373_16567(RTCW(tr1), arg1);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_AS}.set_break_included */
void F1545_18344 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_break_included", 1544, Current, 0, 1, 24753);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {FEATURE_AS}.is_attribute */
EIF_BOOLEAN F1545_18348 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_attribute", 1544, Current, 0, 0, 24757);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_AS}.is_constant */
EIF_BOOLEAN F1545_18352 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_constant", 1544, Current, 1, 0, 24761);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1398, 0x01),loc1);
	Result = (EIF_BOOLEAN) EIF_TEST(loc1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_AS}.once_as */
EIF_REFERENCE F1545_18366 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("once_as", 1544, Current, 3, 0, 24775);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1397, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1411, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			RTHOOK(3);
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_2_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(4);
				tr1 = F1545_18366(loc3);
				RTHOOK(5);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) tr1;
			}
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13578[Dtype(RTCW(tr1))-1410])(tr1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {FEATURE_AS}.is_less */
EIF_BOOLEAN F1545_18369 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_less", 1544, Current, 0, 1, 24778);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F950_7851(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			tr2 = F950_7851(RTCW(tr2));
			Result = F1546_18385(RTCW(tr1), tr2);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
