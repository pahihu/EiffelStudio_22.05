/*
 * Code for class STATIC_ACCESS_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st802.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STATIC_ACCESS_AS}.initialize */
void F1508_18025 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLIU(6);
	
	RTEAA("initialize", 1507, Current, 0, 5, 24427);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1406_16946(Current, arg2, arg3);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O13818[Dtype(arg4)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		RTHOOK(6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O13818[Dtype(arg5)-1448]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {STATIC_ACCESS_AS}.process */
void F1508_18026 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1507, Current, 0, 1, 24428);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3895[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {STATIC_ACCESS_AS}.first_token */
EIF_REFERENCE F1508_18027 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("first_token", 1507, Current, 0, 1, 24429);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_2_) != ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1508_18030(Current, arg1);
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13213[Dtype(RTCW(tr1))-1366])(tr1, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {STATIC_ACCESS_AS}.feature_keyword */
EIF_REFERENCE F1508_18030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("feature_keyword", 1507, Current, 0, 1, 24432);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16451(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_2_));
}

/* {STATIC_ACCESS_AS}.dot_symbol */
EIF_REFERENCE F1508_18031 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("dot_symbol", 1507, Current, 0, 1, 24433);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1366_16452(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_3_));
}

/* {STATIC_ACCESS_AS}.is_detachable_expression */
EIF_BOOLEAN F1508_18033 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
