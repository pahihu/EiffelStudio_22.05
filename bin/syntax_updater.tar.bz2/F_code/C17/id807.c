/*
 * Code for class ID_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "id807.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ID_AS}.initialize */
void F1513_18093 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("initialize", 1512, Current, 0, 1, 24502);
	RTGC;
	RTHOOK(1);
	tr1 = F426_5899(Current);
	F445_6226(RTCW(tr1), arg1);
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F426_5899(Current))+ _LNGOFF_2_1_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ID_AS}.initialize_from_id */
void F1513_18094 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("initialize_from_id", 1512, Current, 0, 1, 24503);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {ID_AS}.set_name */
void F1513_18095 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_name", 1512, Current, 0, 1, 24504);
	RTHOOK(1);
	F1513_18093(Current, arg1);
	RTHOOK(3);
	RTEE;
}

/* {ID_AS}.to_upper */
void F1513_18097 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("to_upper", 1512, Current, 4, 0, 24506);
	RTGC;
	RTHOOK(1);
	loc4 = F1513_18100(Current);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc4));
	RTHOOK(3);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc3));
		/* END INLINED CODE */
		loc1 = tw2;
		RTHOOK(6);
		loc3--;
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = loc1;
		tw1 = F1044_9346(RTCW(tr1));
		if ((EIF_BOOLEAN)(loc1 != tw1)) {
			RTHOOK(8);
			tr2 = F1096_9810(RTCW(loc4));
			tr1 = RTLNS(eif_new_type(78, 0x00).id, 78, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr2 = F79_1086(RTCW(tr1), tr2);
			F1513_18093(Current, tr2);
			RTHOOK(9);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {ID_AS}.to_lower */
void F1513_18098 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("to_lower", 1512, Current, 4, 0, 24507);
	RTGC;
	RTHOOK(1);
	loc4 = F1513_18100(Current);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc4));
	RTHOOK(3);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc3));
		/* END INLINED CODE */
		loc1 = tw2;
		RTHOOK(6);
		loc3--;
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = loc1;
		tw1 = F1044_9348(RTCW(tr1));
		if ((EIF_BOOLEAN)(loc1 != tw1)) {
			RTHOOK(8);
			tr2 = F1096_9809(RTCW(loc4));
			tr1 = RTLNS(eif_new_type(78, 0x00).id, 78, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr2 = F79_1086(RTCW(tr1), tr2);
			F1513_18093(Current, tr2);
			RTHOOK(9);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {ID_AS}.name_id */
EIF_INTEGER_32 F1513_18099 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_);
}


/* {ID_AS}.name_32 */
EIF_REFERENCE F1513_18100 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("name_32", 1512, Current, 0, 0, 24509);
	RTGC;
	RTHOOK(1);
	tr1 = F426_5899(Current);
	Result = F445_6221(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_));
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
			RTCF0;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {ID_AS}.name */
EIF_REFERENCE F1513_18102 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("name", 1512, Current, 0, 0, 24511);
	RTGC;
	RTHOOK(1);
	tr1 = F426_5899(Current);
	Result = F445_6223(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_));
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
			RTCF0;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {ID_AS}.process */
void F1513_18103 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1512, Current, 0, 1, 24512);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3893[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {ID_AS}.is_detachable_expression */
EIF_BOOLEAN F1513_18105 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ID_AS}.is_equal */
EIF_BOOLEAN F1513_18106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 1512, Current, 0, 1, 24498);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_3_4_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_4_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
