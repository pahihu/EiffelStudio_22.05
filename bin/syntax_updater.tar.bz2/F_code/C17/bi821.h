
#ifndef _C17_bi821_
#define _C17_bi821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1527_18200(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit821(void);
extern char *(*R4001[])();

#ifdef __cplusplus
}
#endif

#endif
