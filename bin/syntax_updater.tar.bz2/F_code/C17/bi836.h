
#ifndef _C17_bi836_
#define _C17_bi836_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1542_18239(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit836(void);
extern char *(*R3994[])();

#ifdef __cplusplus
}
#endif

#endif
