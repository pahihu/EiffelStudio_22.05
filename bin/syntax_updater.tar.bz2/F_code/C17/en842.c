/*
 * Code for class ENCODING_CONVERTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en842.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENCODING_CONVERTER}.make */
void F1548_18412 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1547, Current, 0, 0, 24844);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1098, 1).id);
	F1097_9826(RTCW(tr1), ((EIF_INTEGER_32) 50000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {ENCODING_CONVERTER}.input_buffer_from_string_of_encoding */
EIF_REFERENCE F1548_18416 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("input_buffer_from_string_of_encoding", 1547, Current, 0, 2, 24825);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(6275,F449_6275, (Current));
	F95_1352(RTCW(arg2), tr1, arg1);
	RTHOOK(2);
	tb1 = F95_1353(RTCW(arg2));
	if (tb1) {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(283, 0x01).id, 283, _OBJSIZ_1_3_0_6_0_0_0_0_);
		tr1 = F95_1348(RTCW(arg2));
		F284_3734(RTCW(Result), tr1);
	}
	RTHOOK(4);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTHOOK(5);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_CONVERTER}.input_buffer_from_string */
EIF_REFERENCE F1548_18417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,arg2);
	RTLR(6,loc4);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc2);
	RTLR(10,loc5);
	RTLR(11,Result);
	RTLIU(12);
	
	RTEAA("input_buffer_from_string", 1547, Current, 5, 2, 24826);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	tr1 = RTOSCF(18431,F1548_18431, (Current));
	F1280_12236(RTCW(tr1), arg1);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(18431,F1548_18431, (Current))) + _REFACS_1_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(5);
		loc1 = (EIF_REFERENCE) loc3;
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(18431,F1548_18431, (Current))));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(7);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tr1 = RTCCL(arg2);
			{
				/* INLINED CODE (ENCODING_CONVERTER.encoding_from_class) */
				tr2 = (EIF_REFERENCE)  0;
				/* END INLINED CODE */
			}
			tr3 = tr2;
			loc4 = tr3;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			RTHOOK(8);
			loc1 = (EIF_REFERENCE) loc4;
		} else {
			RTHOOK(9);
			loc1 = RTOSCF(6278,F449_6278, (Current));
		}
	}
	RTHOOK(10);
	loc2 = (EIF_REFERENCE) arg1;
	RTHOOK(11);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F759_7351(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(12);
		ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7572[Dtype(RTCW(loc2))-1094])(loc2, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(13);
	tr1 = RTOSCF(6275,F449_6275, (Current));
	F95_1352(RTCW(loc1), tr1, loc2);
	RTHOOK(14);
	tb1 = F95_1353(RTCW(loc1));
	if (tb1) {
		RTHOOK(15);
		Result = RTLNS(eif_new_type(283, 0x01).id, 283, _OBJSIZ_1_3_0_6_0_0_0_0_);
		tr1 = F95_1348(RTCW(loc1));
		F284_3734(RTCW(Result), tr1);
	}
	RTHOOK(16);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_CONVERTER}.encoding_from_class */
EIF_REFERENCE F1548_18429 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("encoding_from_class", 1547, Current, 0, 1, 24838);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {ENCODING_CONVERTER}.bom_detector */
static EIF_REFERENCE F1548_18431_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bom_detector", 1547, Current, 0, 0, 24840);
	RTGC;
	RTOSP (18431);
#define Result RTOSR(18431)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_1_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18431);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1548_18431 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18431,F1548_18431_body,(Current));
}

void EIF_Minit842 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
