
#ifndef _C17_un804_
#define _C17_un804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1510_18041(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit804(void);
extern char *(*R3897[])();

#ifdef __cplusplus
}
#endif

#endif
