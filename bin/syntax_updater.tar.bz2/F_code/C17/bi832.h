
#ifndef _C17_bi832_
#define _C17_bi832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1538_18227(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit832(void);
extern char *(*R3999[])();

#ifdef __cplusplus
}
#endif

#endif
