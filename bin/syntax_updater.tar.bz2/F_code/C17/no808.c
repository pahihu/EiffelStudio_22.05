/*
 * Code for class NONE_ID_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "no808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NONE_ID_AS}.make */
void F1514_18109 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 1513, Current, 0, 0, 24513);
	RTHOOK(1);
	F1513_18094(Current, ((EIF_INTEGER_32) 170L));
	RTHOOK(2);
	RTEE;
}

/* {NONE_ID_AS}.process */
void F1514_18110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1513, Current, 0, 1, 24514);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3881[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

/* {NONE_ID_AS}.text */
EIF_REFERENCE F1514_18111 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("text", 1513, Current, 0, 1, 24515);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("",0,0);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
