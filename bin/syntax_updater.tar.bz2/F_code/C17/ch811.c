/*
 * Code for class CHAR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch811.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHAR_AS}.initialize */
void F1517_18138 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize", 1516, Current, 0, 8, 24544);
	RTGC;
	RTHOOK(1);
	*(EIF_CHARACTER_32 *)(Current + O14309[Dtype(Current)-1516]) = (EIF_CHARACTER_32) arg1;
	RTHOOK(2);
	F182_2312(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CHAR_AS}.process */
void F1517_18139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1516, Current, 0, 1, 24545);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3902[Dtype(RTCW(arg1))-305])(arg1, Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
