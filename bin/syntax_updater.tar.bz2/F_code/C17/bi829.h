
#ifndef _C17_bi829_
#define _C17_bi829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1535_18221(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit829(void);
extern char *(*R3990[])();

#ifdef __cplusplus
}
#endif

#endif
