
#ifndef _C17_bi834_
#define _C17_bi834_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1540_18233(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit834(void);
extern char *(*R3996[])();

#ifdef __cplusplus
}
#endif

#endif
