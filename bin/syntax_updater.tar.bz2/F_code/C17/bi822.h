
#ifndef _C17_bi822_
#define _C17_bi822_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1528_18204(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern char *(*R4003[])();

#ifdef __cplusplus
}
#endif

#endif
