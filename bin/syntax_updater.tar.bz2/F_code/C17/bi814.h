
#ifndef _C17_bi814_
#define _C17_bi814_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1520_18172(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit814(void);
extern char *(*R4000[])();

#ifdef __cplusplus
}
#endif

#endif
