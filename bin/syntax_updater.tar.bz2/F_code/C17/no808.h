
#ifndef _C17_no808_
#define _C17_no808_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1514_18109(EIF_REFERENCE);
extern void F1514_18110(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1514_18111(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit808(void);
extern void F1513_18094(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R3881[])();

#ifdef __cplusplus
}
#endif

#endif
