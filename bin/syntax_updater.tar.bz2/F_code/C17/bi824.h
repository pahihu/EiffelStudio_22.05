
#ifndef _C17_bi824_
#define _C17_bi824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1530_18208(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit824(void);
extern char *(*R4004[])();

#ifdef __cplusplus
}
#endif

#endif
