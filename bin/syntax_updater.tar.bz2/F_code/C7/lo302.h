
#ifndef _C7_lo302_
#define _C7_lo302_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F356_5008(EIF_REFERENCE);
extern void EIF_Minit302(void);

#ifdef __cplusplus
}
#endif

#endif
