
#ifndef _C7_co349_
#define _C7_co349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F404_5858(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE);
extern void F404_5866(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit349(void);

#ifdef __cplusplus
}
#endif

#endif
