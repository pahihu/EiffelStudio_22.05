
#ifndef _C7_ei314_
#define _C7_ei314_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F368_5085(EIF_REFERENCE);
extern EIF_REFERENCE F368_5087(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,5088)
static EIF_REFERENCE F368_5088_body(EIF_REFERENCE);
extern EIF_REFERENCE F368_5088(EIF_REFERENCE);
extern void EIF_Minit314(void);
extern void F193_2835(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
