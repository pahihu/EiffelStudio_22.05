
#ifndef _C7_pr304_
#define _C7_pr304_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F358_5012(EIF_REFERENCE);
extern void EIF_Minit304(void);

#ifdef __cplusplus
}
#endif

#endif
