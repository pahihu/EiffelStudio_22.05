/*
 * Code for class CONF_NAMESPACE_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co341.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_NAMESPACE_TESTER}.includes_this_or_before */
EIF_BOOLEAN F396_5707 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("includes_this_or_before", 395, Current, 0, 1, 5583);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F394_5673(Current, *(EIF_REFERENCE *)(Current + O4801[Dtype(Current)-395]), arg1);
}

/* {CONF_NAMESPACE_TESTER}.includes_this_or_after */
EIF_BOOLEAN F396_5708 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("includes_this_or_after", 395, Current, 0, 1, 5584);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F394_5674(Current, *(EIF_REFERENCE *)(Current + O4801[Dtype(Current)-395]), arg1);
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
