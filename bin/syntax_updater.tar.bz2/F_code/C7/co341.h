
#ifndef _C7_co341_
#define _C7_co341_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F396_5707(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F396_5708(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit341(void);
extern EIF_BOOLEAN F394_5674(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F394_5673(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O4801[];

#ifdef __cplusplus
}
#endif

#endif
