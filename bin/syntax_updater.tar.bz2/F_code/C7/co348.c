/*
 * Code for class CONF_FILE_RULE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co348.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_FILE_RULE}.make */
void F403_5835 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 402, Current, 0, 0, 5716);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CONF_FILE_RULE}.is_empty */
EIF_BOOLEAN F403_5836 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("is_empty", 402, Current, 2, 0, 5717);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(3);
	Result = '\0';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1267_11968(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb2 = F1267_11968(RTCW(loc2));
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_FILE_RULE}.add_exclude */
void F403_5841 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_exclude", 402, Current, 1, 1, 5722);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {1266,0xFF01,1095,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1267_11962(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F1267_11978(RTCW(loc1), arg1);
	RTHOOK(6);
	F403_5851(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_FILE_RULE}.add_include */
void F403_5842 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_include", 402, Current, 1, 1, 5723);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {1266,0xFF01,1095,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1267_11962(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F1267_11978(RTCW(loc1), arg1);
	RTHOOK(6);
	F403_5851(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_FILE_RULE}.set_description */
void F403_5845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_description", 402, Current, 0, 1, 5726);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_FILE_RULE}.is_equal */
EIF_BOOLEAN F403_5847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_equal", 402, Current, 0, 1, 5728);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if (F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_FILE_RULE}.ordered_exclude */
EIF_REFERENCE F403_5849 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("ordered_exclude", 402, Current, 1, 0, 5730);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F1267_11990(loc1);
		RTHOOK(3);
		tr1 = RTOSCF(5857,F403_5857, (Current));
		F179_2281(RTCW(tr1), Result);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_FILE_RULE}.ordered_include */
EIF_REFERENCE F403_5850 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("ordered_include", 402, Current, 1, 0, 5731);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F1267_11990(loc1);
		RTHOOK(3);
		tr1 = RTOSCF(5857,F403_5857, (Current));
		F179_2281(RTCW(tr1), Result);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_FILE_RULE}.compile */
void F403_5851 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("compile", 402, Current, 11, 0, 5732);
	RTGC;
	RTHOOK(1);
	tr1 = F403_5852(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	RTHOOK(3);
	tr1 = F403_5852(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {CONF_FILE_RULE}.compile_list */
EIF_REFERENCE F403_5852 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	struct eif_ex_71 sloc4;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) sloc4.data;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc4.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc4.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc4.overhead, eif_new_type(78, 0x00).id);
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTEAA("compile_list", 402, Current, 6, 1, 5733);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F1267_11968(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1098, 0x01).id, 1098, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1097_9826(RTCW(loc1), ((EIF_INTEGER_32) 50L));
		RTHOOK(4);
		loc2 = RTMS_EX_H("(",1,40);
		RTHOOK(5);
		loc3 = RTMS_EX_H(")|",2,10620);
		RTHOOK(6);
		F1267_12009(RTCW(arg1));
		for (;;) {
			RTHOOK(7);
			tb1 = F1267_12012(RTCW(arg1));
			if (tb1) break;
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(loc1))-1098])(loc1, loc2);
			RTHOOK(9);
			tr1 = F1267_12014(RTCW(arg1));
			F79_1089(RTCW(loc4), tr1, loc1);
			RTHOOK(10);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7754[Dtype(RTCW(loc1))-1098])(loc1, loc3);
			RTHOOK(11);
			F1267_12010(RTCW(arg1));
		}
		RTHOOK(12);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7618[Dtype(RTCW(loc1))-1095])(loc1, ((EIF_INTEGER_32) 1L));
		RTHOOK(13);
		Result = RTLNS(eif_new_type(1330, 0x01).id, 1330, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1331_13911(RTCW(Result));
		RTHOOK(14);
		tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
		F1330_13848(RTCW(Result), tb2);
		RTHOOK(15);
		F1331_13914(RTCW(Result), loc1);
		RTHOOK(16);
		tb2 = F1330_13832(RTCW(Result));
		if (tb2) {
			RTHOOK(17);
			F1330_13863(RTCW(Result));
		} else {
			RTHOOK(18);
			tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_4_);
			tr1 = F1091_9588(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
			RTHOOK(19);
			RTHOOK(20);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_FILE_RULE}.sorter */
static EIF_REFERENCE F403_5857_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("sorter", 402, Current, 0, 0, 5738);
	RTGC;
	RTOSP (5857);
#define Result RTOSR(5857)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,179,0xFF01,1090,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 179, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	tr2 = RTLNS(eif_new_type(244, 0x01).id, 244, _OBJSIZ_0_1_0_0_0_0_0_0_);
	F245_3182(RTCW(tr2));
	F179_2272(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5857);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F403_5857 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5857,F403_5857_body,(Current));
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
