
#ifndef _C7_i1306_
#define _C7_i1306_

#ifdef __cplusplus
extern "C" {
#endif

extern void F360_5015(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit306(void);
extern EIF_REFERENCE F1091_9588(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
