
#ifndef _C7_i1308_
#define _C7_i1308_

#ifdef __cplusplus
extern "C" {
#endif

extern void F362_5021(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit308(void);

#ifdef __cplusplus
}
#endif

#endif
