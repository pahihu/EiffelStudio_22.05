
#ifndef _C7_uc331_
#define _C7_uc331_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,5374)
static EIF_REFERENCE F386_5374_body(EIF_REFERENCE);
extern EIF_REFERENCE F386_5374(EIF_REFERENCE);
extern void EIF_Minit331(void);

#ifdef __cplusplus
}
#endif

#endif
