/*
 * Code for class CLASS_TYPE_NAME_SYNTAX_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl311.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.default_create */
void F365_5039 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("default_create", 364, Current, 0, 0, 4934);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1091_9529(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.is_valid_class_type_name */
EIF_BOOLEAN F365_5040 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_valid_class_type_name", 364, Current, 0, 1, 4935);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	F365_5041(Current);
	RTHOOK(5);
	Result = '\0';
	if (F365_5055(Current)) {
		Result = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) == ((EIF_INTEGER_32) 6L));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_start */
void F365_5041 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("consume_start", 364, Current, 0, 0, 4936);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'S';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_CHARACTER_32) tw1;
	RTHOOK(2);
	F365_5059(Current);
	RTHOOK(3);
	F365_5060(Current);
	RTHOOK(4);
	F365_5042(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_type */
void F365_5042 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("consume_type", 364, Current, 0, 0, 4937);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) == ((EIF_INTEGER_32) 2L))) {
		RTHOOK(2);
		F365_5060(Current);
		RTHOOK(3);
		F365_5043(Current);
	} else {
		RTHOOK(4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_generics */
void F365_5043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("consume_generics", 364, Current, 0, 0, 4938);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) == ((EIF_INTEGER_32) 3L))) {
		RTHOOK(2);
		F365_5060(Current);
		RTHOOK(3);
		F365_5042(Current);
		RTHOOK(4);
		F365_5044(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_type_list */
void F365_5044 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("consume_type_list", 364, Current, 0, 0, 4939);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) == ((EIF_INTEGER_32) 4L))) {
		RTHOOK(2);
		F365_5060(Current);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) == ((EIF_INTEGER_32) 5L))) {
			RTHOOK(4);
			F365_5060(Current);
			RTHOOK(5);
			F365_5042(Current);
			RTHOOK(6);
			F365_5044(Current);
		} else {
			RTHOOK(7);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.is_end_of_input */
EIF_BOOLEAN F365_5055 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_end_of_input", 364, Current, 0, 0, 4928);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(tr1))-1094])(tr1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.is_eof */
EIF_BOOLEAN F365_5058 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_eof", 364, Current, 0, 0, 4931);
	RTGC;
	RTHOOK(1);
	tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_current_character */
void F365_5059 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("consume_current_character", 364, Current, 0, 0, 4932);
	RTGC;
	RTHOOK(1);
	if (F365_5055(Current)) {
		RTHOOK(2);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_CHARACTER_32) tw1;
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(tr1))-1094])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
		*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_CHARACTER_32) tw1;
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_))++;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CLASS_TYPE_NAME_SYNTAX_CHECKER}.consume_current_token */
void F365_5060 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("consume_current_token", 364, Current, 1, 0, 4933);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) != ((EIF_INTEGER_32) 7L))) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_);
			tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb2 = F1044_9358(RTCW(tr1));
			if (!(EIF_BOOLEAN) !tb2) {
				tb1 = F365_5058(Current);
			}
			if (tb1) break;
			RTHOOK(3);
			F365_5059(Current);
		}
		RTHOOK(4);
		if ((EIF_BOOLEAN) !F365_5058(Current)) {
			RTHOOK(5);
			switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_)) {
				case (EIF_CHARACTER_8) '[':
					RTHOOK(6);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					RTHOOK(7);
					F365_5059(Current);
					break;
				case (EIF_CHARACTER_8) ']':
					RTHOOK(8);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
					RTHOOK(9);
					F365_5059(Current);
					break;
				case (EIF_CHARACTER_8) ',':
					RTHOOK(10);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
					RTHOOK(11);
					F365_5059(Current);
					break;
				default:
					RTHOOK(12);
					tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_);
					tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb2 = F1044_9352(RTCW(tr1));
					if (tb2) {
						RTHOOK(13);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						RTHOOK(14);
						loc1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1094_9659(RTCW(loc1), ((EIF_INTEGER_32) 20L));
						for (;;) {
							RTHOOK(15);
							tb2 = '\01';
							if (!F365_5058(Current)) {
								tb3 = '\01';
								tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_);
								tr1 = RTLNS(eif_new_type(1045, 0x00).id, 1045, _OBJSIZ_0_0_0_1_0_0_0_0_);
								*(EIF_CHARACTER_32 *)tr1 = tw1;
								tb4 = F1044_9360(RTCW(tr1));
								if (!tb4) {
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
									tb3 = (EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_) == tw1);
								}
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							if (tb2) break;
							RTHOOK(16);
							F1096_9787(RTCW(loc1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_0_0_0_));
							RTHOOK(17);
							F365_5059(Current);
						}
						RTHOOK(18);
						tr1 = RTOSCF(5027,F364_5027, (Current));
						tb3 = F848_7442(RTCW(tr1), loc1);
						if (tb3) {
							RTHOOK(19);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
						}
					} else {
						RTHOOK(20);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
					}
					break;
			}
		} else {
			RTHOOK(21);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
		}
	}
	RTHOOK(22);
	RTLE;
	RTEE;
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
