
#ifndef _C7_i1307_
#define _C7_i1307_

#ifdef __cplusplus
extern "C" {
#endif

extern void F361_5018(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit307(void);

#ifdef __cplusplus
}
#endif

#endif
