/*
 * Code for class CONF_PARSE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PARSE_FACTORY}.new_redirection_with_file_name */
EIF_REFERENCE F395_5677 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_redirection_with_file_name", 394, Current, 0, 3, 5579);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1294, 0x01).id, 1294, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1295_12680(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_system_generate_uuid_with_file_name */
EIF_REFERENCE F395_5678 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_system_generate_uuid_with_file_name", 394, Current, 0, 3, 5580);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1293, 0x01).id, 1293, _OBJSIZ_16_4_0_2_0_0_0_0_);
	tr1 = F69_869(RTCV(RTOSCF(5705,F395_5705, (Current))));
	F1294_12630(RTCW(Result), arg1, arg2, tr1, arg3);
	RTHOOK(2);
	F1294_12665(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_system_with_file_name */
EIF_REFERENCE F395_5679 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("new_system_with_file_name", 394, Current, 0, 4, 5581);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1293, 0x01).id, 1293, _OBJSIZ_16_4_0_2_0_0_0_0_);
	F1294_12630(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_target */
EIF_REFERENCE F395_5680 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_target", 394, Current, 0, 2, 5553);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_29_1_0_0_0_0_0_0_);
	F1113_10315(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_path */
EIF_REFERENCE F395_5681 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_location_from_path", 394, Current, 0, 2, 5554);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1314, 0x01).id, 1314, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1315_12919(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_full_path */
EIF_REFERENCE F395_5683 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_location_from_full_path", 394, Current, 0, 2, 5556);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1314_12916(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_root */
EIF_REFERENCE F395_5684 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_root", 394, Current, 0, 4, 5557);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(67, 0x01).id, 67, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F68_859(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_version */
EIF_REFERENCE F395_5685 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_16 arg2, EIF_NATURAL_16 arg3, EIF_NATURAL_16 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_version", 394, Current, 0, 4, 5558);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1270, 0x01).id, 1270, _OBJSIZ_4_5_4_0_0_0_0_0_);
	F1271_12081(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_option */
EIF_REFERENCE F395_5686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_option", 394, Current, 0, 1, 5559);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(978, 0x01).id, 978, _OBJSIZ_12_18_0_0_0_0_0_0_);
	Result = F979_8157(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_target_option */
EIF_REFERENCE F395_5687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_target_option", 394, Current, 0, 1, 5560);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(979, 0x01).id, 979, _OBJSIZ_18_18_0_0_0_0_0_0_);
	Result = F979_8157(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_file_rule */
EIF_REFERENCE F395_5688 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_file_rule", 394, Current, 0, 0, 5561);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_7_0_0_0_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_external_include */
EIF_REFERENCE F395_5689 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_include", 394, Current, 0, 2, 5562);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(408, 0x01).id, 408, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_cflag */
EIF_REFERENCE F395_5690 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_cflag", 394, Current, 0, 2, 5563);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(405, 0x01).id, 405, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_object */
EIF_REFERENCE F395_5691 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_object", 394, Current, 0, 2, 5564);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(406, 0x01).id, 406, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_library */
EIF_REFERENCE F395_5692 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_library", 394, Current, 0, 2, 5565);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(407, 0x01).id, 407, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_resource */
EIF_REFERENCE F395_5693 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_resource", 394, Current, 0, 2, 5566);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(411, 0x01).id, 411, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_linker_flag */
EIF_REFERENCE F395_5694 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_linker_flag", 394, Current, 0, 2, 5567);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(410, 0x01).id, 410, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_make */
EIF_REFERENCE F395_5695 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_make", 394, Current, 0, 2, 5568);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(409, 0x01).id, 409, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F405_5867(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_action */
EIF_REFERENCE F395_5696 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_action", 394, Current, 0, 3, 5569);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(403, 0x01).id, 403, _OBJSIZ_4_1_0_0_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg1));
	F404_5858(RTCW(Result), tr1, arg2, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_assertions */
EIF_REFERENCE F395_5697 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_assertions", 394, Current, 0, 0, 5570);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly */
EIF_REFERENCE F395_5698 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("new_assembly", 394, Current, 1, 3, 5571);
	RTGC;
	RTHOOK(1);
	tr1 = F1091_9588(RTCW(arg2));
	loc1 = F395_5683(Current, tr1, arg3);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1169, 0x01).id, 1169, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1163_10611(RTCW(tr1), arg1, loc1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly_from_gac */
EIF_REFERENCE F395_5699 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,arg6);
	RTLR(7,Current);
	RTLIU(8);
	
	RTEAA("new_assembly_from_gac", 394, Current, 0, 6, 5572);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1169, 0x01).id, 1169, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1170_10749(RTCW(tr1), arg1, arg2, arg3, arg4, arg5, arg6);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_library */
EIF_REFERENCE F395_5700 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_library", 394, Current, 0, 3, 5573);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1170, 0x01).id, 1170, _OBJSIZ_21_4_0_1_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg2));
	tr1 = F395_5683(Current, tr1, arg3);
	F1171_10777(RTCW(Result), arg1, tr1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_precompile */
EIF_REFERENCE F395_5701 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_precompile", 394, Current, 0, 3, 5574);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_22_4_0_1_0_0_0_0_);
	tr1 = F1091_9588(RTCW(arg2));
	tr1 = F395_5683(Current, tr1, arg3);
	F1172_10795(RTCW(Result), arg1, tr1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_cluster */
EIF_REFERENCE F395_5702 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_cluster", 394, Current, 0, 3, 5575);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1165, 0x01).id, 1165, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1166_10689(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_test_cluster */
EIF_REFERENCE F395_5703 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_test_cluster", 394, Current, 0, 3, 5576);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1166, 0x01).id, 1166, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1166_10689(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_override */
EIF_REFERENCE F395_5704 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_override", 394, Current, 0, 3, 5577);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_29_5_0_1_0_0_0_0_);
	F1166_10689(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.uuid_generator */
static EIF_REFERENCE F395_5705_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("uuid_generator", 394, Current, 0, 0, 5578);
	RTGC;
	RTOSP (5705);
#define Result RTOSR(5705)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(68, 0x01).id, 68, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5705);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F395_5705 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5705,F395_5705_body,(Current));
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
