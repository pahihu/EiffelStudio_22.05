
#ifndef _C7_co315_
#define _C7_co315_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,5089)
static EIF_REFERENCE F369_5089_body(EIF_REFERENCE);
extern EIF_REFERENCE F369_5089(EIF_REFERENCE);
extern void EIF_Minit315(void);

#ifdef __cplusplus
}
#endif

#endif
