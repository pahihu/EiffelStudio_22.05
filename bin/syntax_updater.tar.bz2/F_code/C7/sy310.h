
#ifndef _C7_sy310_
#define _C7_sy310_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,5027)
static EIF_REFERENCE F364_5027_body(EIF_REFERENCE);
extern EIF_REFERENCE F364_5027(EIF_REFERENCE);
extern void EIF_Minit310(void);
extern void F848_7480(EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE);
extern void F856_7558(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
