/*
 * Code for class EIFFEL_SYNTAX_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei312.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_class_type_name */
EIF_BOOLEAN F366_5061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_valid_class_type_name", 365, Current, 0, 1, 4948);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(364, 0x01).id, 364, _OBJSIZ_1_0_0_3_0_0_0_0_);
	F365_5039(RTCW(tr1));
	Result = F365_5040(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_class_name */
EIF_BOOLEAN F366_5062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_valid_class_name", 365, Current, 0, 1, 4949);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (F366_5067(Current, arg1)) {
		tr1 = RTOSCF(5027,F364_5027, (Current));
		tb1 = F848_7442(RTCW(tr1), arg1);
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_group_name */
EIF_BOOLEAN F366_5063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_group_name", 365, Current, 0, 1, 4950);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F366_5068(Current, arg1);
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_target_name */
EIF_BOOLEAN F366_5065 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_target_name", 365, Current, 0, 1, 4952);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F366_5068(Current, arg1);
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_system_name */
EIF_BOOLEAN F366_5066 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_system_name", 365, Current, 0, 1, 4953);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F366_5068(Current, arg1);
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_identifier */
EIF_BOOLEAN F366_5067 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_valid_identifier", 365, Current, 2, 1, 4954);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(arg1))-1094])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, ((EIF_INTEGER_32) 1L));
		Result = F366_5081(Current, tw1);
	}
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !Result) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		RTHOOK(4);
		loc2 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, loc1);
		RTHOOK(5);
		Result = '\01';
		tb2 = '\01';
		if (!F366_5081(Current, loc2)) {
			tb2 = F366_5082(Current, loc2);
		}
		if (!tb2) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			Result = (EIF_BOOLEAN)(loc2 == tw1);
		}
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_config_identifier */
EIF_BOOLEAN F366_5068 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_valid_config_identifier", 365, Current, 2, 1, 4955);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7509[Dtype(RTCW(arg1))-1094])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, ((EIF_INTEGER_32) 1L));
		Result = F366_5081(Current, tw1);
	}
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !Result) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7531[Dtype(RTCW(arg1))-1094])(arg1);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		RTHOOK(4);
		loc2 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7495[Dtype(RTCW(arg1))-1094])(arg1, loc1);
		RTHOOK(5);
		Result = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		if (!F366_5081(Current, loc2)) {
			tb4 = F366_5082(Current, loc2);
		}
		if (!tb4) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			tb3 = (EIF_BOOLEAN)(loc2 == tw1);
		}
		if (!tb3) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
			tb2 = (EIF_BOOLEAN)(loc2 == tw1);
		}
		if (!tb2) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			Result = (EIF_BOOLEAN)(loc2 == tw1);
		}
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_feature_name */
EIF_BOOLEAN F366_5080 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_valid_feature_name", 365, Current, 0, 1, 4967);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(5027,F364_5027, (Current));
		tb2 = F848_7442(RTCW(tr1), arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		Result = F366_5067(Current, arg1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_alpha */
EIF_BOOLEAN F366_5081 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_alpha", 365, Current, 0, 1, 4968);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = (arg1 <= 0xFF);
	if (tb1) {
		tc1 = (EIF_CHARACTER_8) arg1;
		tr1 = RTLNS(eif_new_type(1048, 0x00).id, 1048, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)tr1 = tc1;
		tb1 = F1047_9391(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_digit */
EIF_BOOLEAN F366_5082 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_digit", 365, Current, 0, 1, 4969);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = (arg1 <= 0xFF);
	if (tb1) {
		tc1 = (EIF_CHARACTER_8) arg1;
		tb1 = EIF_TEST(isdigit(tc1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit312 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
