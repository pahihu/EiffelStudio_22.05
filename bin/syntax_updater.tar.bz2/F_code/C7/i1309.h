
#ifndef _C7_i1309_
#define _C7_i1309_

#ifdef __cplusplus
extern "C" {
#endif

extern void F363_5024(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit309(void);
extern void F1323_13636(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1323_13637(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
