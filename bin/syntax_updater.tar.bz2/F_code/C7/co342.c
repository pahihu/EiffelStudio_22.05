/*
 * Code for class CONF_LOAD_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co342.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_CALLBACKS}.on_error */
void F397_5715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("on_error", 396, Current, 0, 1, 5591);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F397_5723(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.on_start */
void F397_5716 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("on_start", 396, Current, 0, 0, 5592);
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.on_finish */
void F397_5717 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("on_finish", 396, Current, 0, 0, 5593);
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.set_internal_error */
void F397_5718 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_internal_error", 396, Current, 1, 0, 5594);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_2_0_0_3_0_0_0_0_);
	RTHOOK(2);
	tr1 = F1320_13440(RTCV(RTOSCF(5089,F369_5089, (Current))));
	F993_8356(RTCW(loc1), tr1);
	RTHOOK(3);
	F993_8353(RTCW(loc1));
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.is_valid_uuid */
EIF_BOOLEAN F397_5719 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_valid_uuid", 396, Current, 1, 1, 5595);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1111, 0x01).id, 1111, _OBJSIZ_0_0_3_1_0_0_1_0_);
	RTHOOK(2);
	tb1 = F1112_10304(RTCW(loc1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) tb1;
}

/* {CONF_LOAD_CALLBACKS}.check_version */
void F397_5720 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("check_version", 396, Current, 1, 1, 5596);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(993, 0x01).id, 993, _OBJSIZ_2_0_0_3_0_0_0_0_);
		F994_8360(RTCW(tr1));
		F397_5721(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			RTHOOK(4);
			tr1 = F394_5672(Current, arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tb1 = F1094_9686(RTCW(arg1), loc1);
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(6);
				tr1 = RTLNS(eif_new_type(993, 0x01).id, 993, _OBJSIZ_2_0_0_3_0_0_0_0_);
				F994_8360(RTCW(tr1));
				F397_5721(Current, tr1);
			}
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.set_error */
void F397_5721 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("set_error", 396, Current, 1, 1, 5597);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(326, 0x01).id, 326, _OBJSIZ_5_1_0_1_0_0_0_0_);
	RTHOOK(4);
	tr1 = RTMS_EX_H("Parse error",11,62499698);
	F318_4907(RTCW(loc1), tr1);
	RTHOOK(5);
	F318_4892(RTCW(loc1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_error_message */
void F397_5723 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTEAA("set_parse_error_message", 396, Current, 5, 1, 5599);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_2_)) {
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc4))) {
			tb2 = (EIF_BOOLEAN) !F394_5671(Current, loc4);
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		F397_5724(Current, arg1);
	} else {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_2_0_0_3_0_0_0_0_);
		RTHOOK(4);
		F993_8356(RTCW(loc1), arg1);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(6);
			loc3 = F293_3984(loc5);
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_1_);
			F993_8355(RTCW(loc1), tr1, ti4_1, ti4_2);
		}
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		RTHOOK(10);
		loc2 = RTLNS(eif_new_type(326, 0x01).id, 326, _OBJSIZ_5_1_0_1_0_0_0_0_);
		RTHOOK(11);
		tr1 = RTMS_EX_H("Parse error",11,62499698);
		F318_4907(RTCW(loc2), tr1);
		RTHOOK(12);
		F318_4892(RTCW(loc2));
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_warning_message */
void F397_5724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTEAA("set_parse_warning_message", 396, Current, 4, 1, 5600);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_2_0_0_3_0_0_0_0_);
	RTHOOK(2);
	F993_8356(RTCW(loc1), arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(4);
		loc2 = F293_3984(loc4);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
		F993_8355(RTCW(loc1), tr1, ti4_1, ti4_2);
	}
	RTHOOK(6);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(7);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		RTHOOK(9);
		{
			static EIF_TYPE_INDEX typarr0[] = {949,0xFF01,981,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc3 = RTLNSMART(typres0.id);
		}
		F950_7843(RTCW(loc3), ((EIF_INTEGER_32) 1L));
		RTHOOK(10);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc3;
	}
	RTHOOK(11);
	F950_7883(RTCW(loc3), loc1);
	RTHOOK(12);
	RTLE;
	RTEE;
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
