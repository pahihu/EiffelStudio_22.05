
#ifndef _C7_va300_
#define _C7_va300_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F354_5004(EIF_REFERENCE);
extern void EIF_Minit300(void);

#ifdef __cplusplus
}
#endif

#endif
