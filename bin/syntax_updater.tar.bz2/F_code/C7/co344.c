/*
 * Code for class CONF_VALIDITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co344.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VALIDITY}.valid_platform */
EIF_BOOLEAN F399_5735 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_platform", 398, Current, 0, 1, 5653);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5758,F399_5758, (Current));
	Result = F847_7442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_build */
EIF_BOOLEAN F399_5736 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_build", 398, Current, 0, 1, 5654);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5759,F399_5759, (Current));
	Result = F847_7442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_concurrency */
EIF_BOOLEAN F399_5737 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_concurrency", 398, Current, 0, 1, 5655);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5760,F399_5760, (Current));
	Result = F847_7442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_void_safety */
EIF_BOOLEAN F399_5738 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_void_safety", 398, Current, 0, 1, 5656);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5761,F399_5761, (Current));
	Result = F847_7442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_warning */
EIF_BOOLEAN F399_5740 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("valid_warning", 398, Current, 0, 2, 5658);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\0';
	tr1 = RTOSCF(5665,F394_5665, (Current));
	if (F394_5674(Current, arg2, tr1)) {
		tr1 = RTOSCF(5773,F399_5773, (Current));
		tb5 = F848_7440(RTCW(tr1), arg1);
		tb4 = tb5;
	}
	if (!tb4) {
		tb4 = '\0';
		tr1 = RTOSCF(5659,F394_5659, (Current));
		tr2 = RTOSCF(5663,F394_5663, (Current));
		if (F394_5675(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(5772,F399_5772, (Current));
			tb5 = F848_7440(RTCW(tr1), arg1);
			tb4 = tb5;
		}
		tb3 = tb4;
	}
	if (!tb3) {
		tb3 = '\0';
		tr1 = RTOSCF(5657,F394_5657, (Current));
		tr2 = RTOSCF(5657,F394_5657, (Current));
		if (F394_5675(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(5771,F399_5771, (Current));
			tb4 = F848_7440(RTCW(tr1), arg1);
			tb3 = tb4;
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tr1 = RTOSCF(5643,F394_5643, (Current));
		tr2 = RTOSCF(5655,F394_5655, (Current));
		if (F394_5675(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(5770,F399_5770, (Current));
			tb3 = F848_7440(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tr1 = RTOSCF(5641,F394_5641, (Current));
		if (F394_5673(Current, arg2, tr1)) {
			tr1 = RTOSCF(5769,F399_5769, (Current));
			tb2 = F848_7440(RTCW(tr1), arg1);
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.regexp_error */
EIF_REFERENCE F399_5742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_71 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(78, 0x00).id);
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("regexp_error", 398, Current, 2, 1, 5660);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1330, 0x01).id, 1330, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1331_13911(RTCW(loc1));
		RTHOOK(3);
		tr1 = F79_1088(RTCW(loc2), arg1);
		F1331_13914(RTCW(loc1), tr1);
		RTHOOK(4);
		tb1 = F1330_13832(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1039,0xFF01,1098,1229,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
			RTAR(tr1,tr2);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_11_16_0_14_);
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_setting */
EIF_BOOLEAN F399_5745 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("valid_setting", 398, Current, 1, 2, 5663);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7508[Dtype(RTCW(arg1))-1094])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = F1091_9582(RTCW(arg1));
		RTHOOK(3);
		Result = '\01';
		tb1 = '\01';
		tb2 = '\0';
		tr1 = RTOSCF(5659,F394_5659, (Current));
		if (F394_5674(Current, arg2, tr1)) {
			tr1 = RTOSCF(5778,F399_5778, (Current));
			tb3 = F1267_11966(RTCW(tr1), loc1);
			tb2 = tb3;
		}
		if (!tb2) {
			tb2 = '\0';
			tr1 = RTOSCF(5657,F394_5657, (Current));
			tr2 = RTOSCF(5657,F394_5657, (Current));
			if (F394_5675(Current, arg2, tr1, tr2)) {
				tr1 = RTOSCF(5777,F399_5777, (Current));
				tb3 = F1267_11966(RTCW(tr1), loc1);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (!tb1) {
			tb1 = '\0';
			tr1 = RTOSCF(5655,F394_5655, (Current));
			if (F394_5673(Current, arg2, tr1)) {
				tr1 = RTOSCF(5776,F399_5776, (Current));
				tb2 = F1267_11966(RTCW(tr1), loc1);
				tb1 = tb2;
			}
			Result = tb1;
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.valid_version_type */
EIF_BOOLEAN F399_5746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("valid_version_type", 398, Current, 0, 1, 5664);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(5774,F399_5774, (Current));
		tb1 = F848_7442(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_platform_name */
EIF_REFERENCE F399_5749 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("get_platform_name", 398, Current, 1, 1, 5667);
	RTGC;
	RTHOOK(1);
	RTCT0("valid_platform", EX_CHECK);
	tr1 = RTOSCF(5758,F399_5758, (Current));
	tr1 = F847_7440(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_build_name */
EIF_REFERENCE F399_5750 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("get_build_name", 398, Current, 1, 1, 5668);
	RTGC;
	RTHOOK(1);
	RTCT0("valid_build", EX_CHECK);
	tr1 = RTOSCF(5759,F399_5759, (Current));
	tr1 = F847_7440(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_concurrency_name */
EIF_REFERENCE F399_5751 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("get_concurrency_name", 398, Current, 1, 1, 5612);
	RTGC;
	RTHOOK(1);
	RTCT0("valid_index", EX_CHECK);
	tr1 = RTOSCF(5760,F399_5760, (Current));
	tr1 = F847_7440(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_void_safety_name */
EIF_REFERENCE F399_5752 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("get_void_safety_name", 398, Current, 1, 1, 5613);
	RTGC;
	RTHOOK(1);
	RTCT0("valid_index", EX_CHECK);
	tr1 = RTOSCF(5761,F399_5761, (Current));
	tr1 = F847_7440(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_platform */
EIF_INTEGER_32 F399_5753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("get_platform", 398, Current, 0, 1, 5614);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		F847_7473(RTCV(RTOSCF(5758,F399_5758, (Current))));
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F847_7468(RTCV(RTOSCF(5758,F399_5758, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(4);
			tr1 = F847_7446(RTCV(RTOSCF(5758,F399_5758, (Current))));
			tb2 = F1091_9571(RTCW(arg1), tr1);
			if (tb2) {
				RTHOOK(5);
				Result = F847_7447(RTCV(RTOSCF(5758,F399_5758, (Current))));
			}
			RTHOOK(6);
			F847_7474(RTCV(RTOSCF(5758,F399_5758, (Current))));
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_build */
EIF_INTEGER_32 F399_5754 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("get_build", 398, Current, 0, 1, 5615);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		F847_7473(RTCV(RTOSCF(5759,F399_5759, (Current))));
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F847_7468(RTCV(RTOSCF(5759,F399_5759, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(4);
			tr1 = F847_7446(RTCV(RTOSCF(5759,F399_5759, (Current))));
			tb2 = F1091_9571(RTCW(arg1), tr1);
			if (tb2) {
				RTHOOK(5);
				Result = F847_7447(RTCV(RTOSCF(5759,F399_5759, (Current))));
			}
			RTHOOK(6);
			F847_7474(RTCV(RTOSCF(5759,F399_5759, (Current))));
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_concurrency */
EIF_INTEGER_32 F399_5755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("get_concurrency", 398, Current, 0, 1, 5616);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		F847_7473(RTCV(RTOSCF(5760,F399_5760, (Current))));
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F847_7468(RTCV(RTOSCF(5760,F399_5760, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(4);
			tr1 = F847_7446(RTCV(RTOSCF(5760,F399_5760, (Current))));
			tb2 = F1091_9571(RTCW(arg1), tr1);
			if (tb2) {
				RTHOOK(5);
				Result = F847_7447(RTCV(RTOSCF(5760,F399_5760, (Current))));
			}
			RTHOOK(6);
			F847_7474(RTCV(RTOSCF(5760,F399_5760, (Current))));
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.get_void_safety */
EIF_INTEGER_32 F399_5756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("get_void_safety", 398, Current, 0, 1, 5617);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		F847_7473(RTCV(RTOSCF(5761,F399_5761, (Current))));
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F847_7468(RTCV(RTOSCF(5761,F399_5761, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(4);
			tr1 = F847_7446(RTCV(RTOSCF(5761,F399_5761, (Current))));
			tb2 = F1091_9571(RTCW(arg1), tr1);
			if (tb2) {
				RTHOOK(5);
				Result = F847_7447(RTCV(RTOSCF(5761,F399_5761, (Current))));
			}
			RTHOOK(6);
			F847_7474(RTCV(RTOSCF(5761,F399_5761, (Current))));
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_VALIDITY}.platform_names */
static EIF_REFERENCE F399_5758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("platform_names", 398, Current, 0, 0, 5619);
	RTGC;
	RTOSP (5758);
#define Result RTOSR(5758)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1098,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F847_7434(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3787,F289_3787, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	tr1 = RTOSCF(3788,F289_3788, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	RTHOOK(4);
	tr1 = RTOSCF(3789,F289_3789, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	RTHOOK(5);
	tr1 = RTOSCF(3790,F289_3790, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 15L));
	RTOSE (5758);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5758 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5758,F399_5758_body,(Current));
}

/* {CONF_VALIDITY}.build_names */
static EIF_REFERENCE F399_5759_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("build_names", 398, Current, 0, 0, 5620);
	RTGC;
	RTOSP (5759);
#define Result RTOSR(5759)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1098,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F847_7434(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3793,F289_3793, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 256L));
	RTHOOK(3);
	tr1 = RTOSCF(3794,F289_3794, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 512L));
	RTOSE (5759);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5759 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5759,F399_5759_body,(Current));
}

/* {CONF_VALIDITY}.concurrency_names */
static EIF_REFERENCE F399_5760_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("concurrency_names", 398, Current, 0, 0, 5621);
	RTGC;
	RTOSP (5760);
#define Result RTOSR(5760)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1098,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F847_7434(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3798,F289_3798, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 2048L));
	RTHOOK(3);
	tr1 = RTOSCF(3799,F289_3799, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 3840L));
	RTHOOK(4);
	tr1 = RTOSCF(3800,F289_3800, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 4096L));
	RTOSE (5760);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5760 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5760,F399_5760_body,(Current));
}

/* {CONF_VALIDITY}.void_safety_names */
static EIF_REFERENCE F399_5761_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("void_safety_names", 398, Current, 0, 0, 5622);
	RTGC;
	RTOSP (5761);
#define Result RTOSR(5761)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,846,0xFF01,1098,1229,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 846, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F847_7434(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3806,F289_3806, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 4352L));
	RTHOOK(3);
	tr1 = RTOSCF(3807,F289_3807, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 4608L));
	RTHOOK(4);
	tr1 = RTOSCF(3808,F289_3808, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 4864L));
	RTHOOK(5);
	tr1 = RTOSCF(3809,F289_3809, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 5120L));
	RTHOOK(6);
	tr1 = RTOSCF(3810,F289_3810, (Current));
	F847_7481(RTCW(Result), tr1, ((EIF_INTEGER_32) 5376L));
	RTOSE (5761);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5761 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5761,F399_5761_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_default */
static EIF_REFERENCE F399_5769_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_warnings_default", 398, Current, 0, 0, 5630);
	RTGC;
	RTOSP (5769);
#define Result RTOSR(5769)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,855,1042,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 855, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F848_7434(RTCW(tr1), ((EIF_INTEGER_32) 13L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3819,F289_3819, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3821,F289_3821, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3822,F289_3822, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3824,F289_3824, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3825,F289_3825, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3826,F289_3826, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3827,F289_3827, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3828,F289_3828, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3829,F289_3829, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(11);
	tr1 = RTOSCF(3830,F289_3830, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(12);
	tr1 = RTOSCF(3831,F289_3831, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(13);
	tr1 = RTOSCF(3832,F289_3832, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(14);
	tr1 = RTOSCF(3833,F289_3833, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (5769);
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5769 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5769,F399_5769_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_10_0 */
static EIF_REFERENCE F399_5770_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_warnings_1_10_0", 398, Current, 0, 0, 5631);
	RTGC;
	RTOSP (5770);
#define Result RTOSR(5770)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5769,F399_5769, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3820,F289_3820, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (5770);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5770 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5770,F399_5770_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_17_0 */
static EIF_REFERENCE F399_5771_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_warnings_1_17_0", 398, Current, 0, 0, 5632);
	RTGC;
	RTOSP (5771);
#define Result RTOSR(5771)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5770,F399_5770, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3823,F289_3823, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (5771);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5771 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5771,F399_5771_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_18_0 */
static EIF_REFERENCE F399_5772_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_warnings_1_18_0", 398, Current, 0, 0, 5633);
	RTGC;
	RTOSP (5772);
#define Result RTOSR(5772)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5771,F399_5771, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3823,F289_3823, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (5772);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5772 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5772,F399_5772_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_21_0 */
static EIF_REFERENCE F399_5773_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_warnings_1_21_0", 398, Current, 0, 0, 5634);
	RTGC;
	RTOSP (5773);
#define Result RTOSR(5773)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5772,F399_5772, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3822,F289_3822, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (5773);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5773 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5773,F399_5773_body,(Current));
}

/* {CONF_VALIDITY}.valid_version_types */
static EIF_REFERENCE F399_5774_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_version_types", 398, Current, 0, 0, 5635);
	RTGC;
	RTOSP (5774);
#define Result RTOSR(5774)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,855,1042,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 855, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F848_7434(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3814,F289_3814, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3815,F289_3815, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (5774);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5774 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5774,F399_5774_body,(Current));
}

/* {CONF_VALIDITY}.known_settings */
static EIF_REFERENCE F399_5775_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("known_settings", 398, Current, 4, 0, 5636);
	RTGC;
	RTOSP (5775);
#define Result RTOSR(5775)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5777,F399_5777, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(5778,F399_5778, (Current));
	F1267_11985(RTCW(Result), tr1);
	RTOSE (5775);
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5775 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5775,F399_5775_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings */
static EIF_REFERENCE F399_5776_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_settings", 398, Current, 0, 0, 5637);
	RTGC;
	RTOSP (5776);
#define Result RTOSR(5776)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1266,0xFF01,1098,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1266, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1267_11962(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3834,F289_3834, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3835,F289_3835, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3836,F289_3836, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3838,F289_3838, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3839,F289_3839, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3840,F289_3840, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3841,F289_3841, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3842,F289_3842, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3843,F289_3843, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(11);
	tr1 = RTOSCF(3845,F289_3845, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(12);
	tr1 = RTOSCF(3846,F289_3846, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(13);
	tr1 = RTOSCF(3847,F289_3847, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(14);
	tr1 = RTOSCF(3848,F289_3848, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(15);
	tr1 = RTOSCF(3849,F289_3849, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(16);
	tr1 = RTOSCF(3850,F289_3850, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(17);
	tr1 = RTOSCF(3851,F289_3851, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(18);
	tr1 = RTOSCF(3853,F289_3853, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(19);
	tr1 = RTOSCF(3854,F289_3854, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(20);
	tr1 = RTOSCF(3855,F289_3855, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(21);
	tr1 = RTOSCF(3856,F289_3856, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(22);
	tr1 = RTOSCF(3857,F289_3857, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(23);
	tr1 = RTOSCF(3858,F289_3858, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(24);
	tr1 = RTOSCF(3859,F289_3859, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(25);
	tr1 = RTOSCF(3861,F289_3861, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(26);
	tr1 = RTOSCF(3862,F289_3862, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(27);
	tr1 = RTOSCF(3863,F289_3863, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(28);
	tr1 = RTOSCF(3864,F289_3864, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(29);
	tr1 = RTOSCF(3865,F289_3865, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(30);
	tr1 = RTOSCF(3866,F289_3866, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(31);
	tr1 = RTOSCF(3867,F289_3867, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(32);
	tr1 = RTOSCF(3868,F289_3868, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(33);
	tr1 = RTOSCF(3869,F289_3869, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(34);
	tr1 = RTOSCF(3870,F289_3870, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(35);
	tr1 = RTOSCF(3871,F289_3871, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(36);
	tr1 = RTOSCF(3873,F289_3873, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(37);
	tr1 = RTOSCF(3852,F289_3852, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(38);
	tr1 = RTOSCF(3874,F289_3874, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(39);
	tr1 = RTOSCF(3875,F289_3875, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(40);
	tr1 = RTOSCF(3876,F289_3876, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(41);
	tr1 = RTOSCF(3877,F289_3877, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(42);
	tr1 = RTOSCF(3872,F289_3872, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTOSE (5776);
	RTHOOK(44);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5776 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5776,F399_5776_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_17_0 */
static EIF_REFERENCE F399_5777_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_settings_1_17_0", 398, Current, 1, 0, 5638);
	RTGC;
	RTOSP (5777);
#define Result RTOSR(5777)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5776,F399_5776, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3837,F289_3837, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTOSE (5777);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5777 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5777,F399_5777_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_18_0 */
static EIF_REFERENCE F399_5778_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("valid_settings_1_18_0", 398, Current, 0, 0, 5639);
	RTGC;
	RTOSP (5778);
#define Result RTOSR(5778)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5777,F399_5777, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3862,F289_3862, (Current));
	F1267_11981(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3860,F289_3860, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTOSE (5778);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5778 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5778,F399_5778_body,(Current));
}

/* {CONF_VALIDITY}.boolean_settings */
static EIF_REFERENCE F399_5779_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("boolean_settings", 398, Current, 0, 0, 5640);
	RTGC;
	RTOSP (5779);
#define Result RTOSR(5779)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,855,1042,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 855, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F848_7434(RTCW(tr1), ((EIF_INTEGER_32) 28L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3834,F289_3834, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3835,F289_3835, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3836,F289_3836, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3837,F289_3837, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3839,F289_3839, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3838,F289_3838, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3840,F289_3840, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3841,F289_3841, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3842,F289_3842, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(11);
	tr1 = RTOSCF(3845,F289_3845, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(12);
	tr1 = RTOSCF(3847,F289_3847, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(13);
	tr1 = RTOSCF(3848,F289_3848, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(14);
	tr1 = RTOSCF(3849,F289_3849, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(15);
	tr1 = RTOSCF(3850,F289_3850, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(16);
	tr1 = RTOSCF(3853,F289_3853, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(17);
	tr1 = RTOSCF(3854,F289_3854, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(18);
	tr1 = RTOSCF(3855,F289_3855, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(19);
	tr1 = RTOSCF(3857,F289_3857, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(20);
	tr1 = RTOSCF(3859,F289_3859, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(21);
	tr1 = RTOSCF(3866,F289_3866, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(22);
	tr1 = RTOSCF(3869,F289_3869, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(23);
	tr1 = RTOSCF(3870,F289_3870, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(24);
	tr1 = RTOSCF(3872,F289_3872, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(25);
	tr1 = RTOSCF(3871,F289_3871, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(26);
	tr1 = RTOSCF(3875,F289_3875, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(27);
	tr1 = RTOSCF(3877,F289_3877, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTHOOK(28);
	tr1 = RTOSCF(3876,F289_3876, (Current));
	F848_7481(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (5779);
	RTHOOK(30);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5779 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5779,F399_5779_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_19_0_and_below */
static EIF_REFERENCE F399_5780_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("true_boolean_settings_1_19_0_and_below", 398, Current, 0, 0, 5641);
	RTGC;
	RTOSP (5780);
#define Result RTOSR(5780)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1266,0xFF01,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1266, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1267_11962(RTCW(tr1), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(3840,F289_3840, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(3841,F289_3841, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(4);
	tr1 = RTOSCF(3838,F289_3838, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(5);
	tr1 = RTOSCF(3839,F289_3839, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(6);
	tr1 = RTOSCF(3842,F289_3842, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(7);
	tr1 = RTOSCF(3855,F289_3855, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(8);
	tr1 = RTOSCF(3854,F289_3854, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(9);
	tr1 = RTOSCF(3876,F289_3876, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTHOOK(10);
	tr1 = RTOSCF(3877,F289_3877, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTOSE (5780);
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5780 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5780,F399_5780_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_20_0_and_above */
static EIF_REFERENCE F399_5781_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("true_boolean_settings_1_20_0_and_above", 398, Current, 0, 0, 5642);
	RTGC;
	RTOSP (5781);
#define Result RTOSR(5781)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = F1_14(RTOSCF(5780,F399_5780, (Current)));
	RTHOOK(2);
	tr1 = RTOSCF(3875,F289_3875, (Current));
	F1267_11979(RTCW(Result), tr1);
	RTOSE (5781);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F399_5781 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5781,F399_5781_body,(Current));
}

/* {CONF_VALIDITY}.is_boolean_setting_true */
EIF_BOOLEAN F399_5782 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("is_boolean_setting_true", 398, Current, 0, 2, 5643);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5661,F394_5661, (Current));
	if (F394_5673(Current, arg2, tr1)) {
		RTHOOK(2);
		tr1 = RTOSCF(5780,F399_5780, (Current));
	} else {
		RTHOOK(3);
		tr1 = RTOSCF(5781,F399_5781, (Current));
	}
	Result = F1267_11966(RTCV(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit344 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
