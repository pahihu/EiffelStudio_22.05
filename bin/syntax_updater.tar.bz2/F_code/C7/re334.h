
#ifndef _C7_re334_
#define _C7_re334_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F389_5468(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit334(void);

#ifdef __cplusplus
}
#endif

#endif
