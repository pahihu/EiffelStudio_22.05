
#ifndef _C7_po303_
#define _C7_po303_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F357_5010(EIF_REFERENCE);
extern void EIF_Minit303(void);

#ifdef __cplusplus
}
#endif

#endif
