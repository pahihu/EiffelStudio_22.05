/*
 * Code for class CONF_CONDITIONED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITIONED}.add_condition */
void F402_5832 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_condition", 401, Current, 2, 1, 5712);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O4923[dtype-401]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTLNSMART(eif_new_type(961, 0).id);
		F962_7909(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O4923[dtype-401]) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F950_7883(RTCW(loc1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITIONED}.set_conditions */
void F402_5833 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_conditions", 401, Current, 0, 1, 5713);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F757_7351(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		*(EIF_REFERENCE *)(Current + O4923[dtype-401]) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O4923[dtype-401]) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
