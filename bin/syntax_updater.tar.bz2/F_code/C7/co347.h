
#ifndef _C7_co347_
#define _C7_co347_

#ifdef __cplusplus
extern "C" {
#endif

extern void F402_5832(EIF_REFERENCE, EIF_REFERENCE);
extern void F402_5833(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit347(void);
extern EIF_BOOLEAN F757_7351(EIF_REFERENCE);
extern void F962_7909(EIF_REFERENCE, EIF_INTEGER_32);
extern void F950_7883(EIF_REFERENCE, EIF_REFERENCE);
extern long O4923[];

#ifdef __cplusplus
}
#endif

#endif
