
#ifndef _C7_ch301_
#define _C7_ch301_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F355_5006(EIF_REFERENCE);
extern void EIF_Minit301(void);

#ifdef __cplusplus
}
#endif

#endif
