/*
 * Code for class EIFFEL_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei314.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_LAYOUT}.is_eiffel_layout_defined */
EIF_BOOLEAN F368_5085 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_eiffel_layout_defined", 367, Current, 0, 0, 4972);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(5088,F368_5088, (Current))));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_LAYOUT}.eiffel_layout */
EIF_REFERENCE F368_5087 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("eiffel_layout", 367, Current, 1, 0, 4974);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(5088,F368_5088, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(1357, 0x01).id, 1357, _OBJSIZ_0_3_0_0_0_0_0_0_);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {EIFFEL_LAYOUT}.eiffel_layout_cell */
static EIF_REFERENCE F368_5088_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("eiffel_layout_cell", 367, Current, 0, 0, 4975);
	RTGC;
	RTOSP (5088);
#define Result RTOSR(5088)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,192,1356,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 192, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F193_2835(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5088);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F368_5088 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5088,F368_5088_body,(Current));
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
