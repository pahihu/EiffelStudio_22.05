
#ifndef _C13_ds601_
#define _C13_ds601_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1032_6885(EIF_REFERENCE);
extern void EIF_Minit601(void);
extern long O5525[];

#ifdef __cplusplus
}
#endif

#endif
