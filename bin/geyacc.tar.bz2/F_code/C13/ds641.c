/*
 * Code for class DS_LINEAR_CURSOR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds641.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR_CURSOR}.start */
void F981_6782 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTLE;
}

/* {DS_LINEAR_CURSOR}.forth */
void F981_6783 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTLE;
}

/* {DS_LINEAR_CURSOR}.go_after */
void F981_6785 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTLE;
}

void EIF_Minit641 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
