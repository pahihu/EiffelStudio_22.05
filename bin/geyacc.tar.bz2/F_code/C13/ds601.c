/*
 * Code for class DS_CONTAINER [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds601.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CONTAINER}.is_empty */
EIF_BOOLEAN F1032_6885 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5525[Dtype(Current)-1083]) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit601 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
