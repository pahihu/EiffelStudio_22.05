
#ifndef _C13_ds644_
#define _C13_ds644_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1033_6885(EIF_REFERENCE);
extern void EIF_Minit644(void);

#ifdef __cplusplus
}
#endif

#endif
