
#ifndef _C13_re626_
#define _C13_re626_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F610_3166(EIF_REFERENCE);
extern void EIF_Minit626(void);
extern EIF_INTEGER_32 F686_3632(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
