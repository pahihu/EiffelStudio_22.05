
#ifndef _C13_co613_
#define _C13_co613_

#ifdef __cplusplus
extern "C" {
#endif

extern void F441_3055(EIF_REFERENCE);
extern void EIF_Minit613(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
