
#ifndef _C13_ds640_
#define _C13_ds640_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F987_6792(EIF_REFERENCE);
extern void EIF_Minit640(void);

#ifdef __cplusplus
}
#endif

#endif
