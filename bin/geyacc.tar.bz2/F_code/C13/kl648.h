
#ifndef _C13_kl648_
#define _C13_kl648_

#ifdef __cplusplus
extern "C" {
#endif

extern void F697_3677(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit648(void);

#ifdef __cplusplus
}
#endif

#endif
