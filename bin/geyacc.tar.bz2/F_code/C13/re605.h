
#ifndef _C13_re605_
#define _C13_re605_

#ifdef __cplusplus
extern "C" {
#endif

extern void F372_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F372_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F372_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F372_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F372_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F372_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F372_2982(EIF_REFERENCE);
extern void F372_2987(EIF_REFERENCE);
extern void EIF_Minit605(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
