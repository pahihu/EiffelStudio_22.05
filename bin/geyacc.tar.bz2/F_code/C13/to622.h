
#ifndef _C13_to622_
#define _C13_to622_

#ifdef __cplusplus
extern "C" {
#endif

extern void F233_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F233_2365(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F233_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit622(void);
extern void F661_3531(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
