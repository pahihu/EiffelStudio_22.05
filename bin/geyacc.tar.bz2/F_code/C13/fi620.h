
#ifndef _C13_fi620_
#define _C13_fi620_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F584_3153(EIF_REFERENCE);
extern void EIF_Minit620(void);
extern EIF_INTEGER_32 F686_3631(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
