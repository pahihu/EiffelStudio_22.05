
#ifndef _C13_ds641_
#define _C13_ds641_

#ifdef __cplusplus
extern "C" {
#endif

extern void F981_6782(EIF_REFERENCE);
extern void F981_6783(EIF_REFERENCE);
extern void F981_6785(EIF_REFERENCE);
extern void EIF_Minit641(void);

#ifdef __cplusplus
}
#endif

#endif
