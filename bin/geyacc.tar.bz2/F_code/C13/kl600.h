
#ifndef _C13_kl600_
#define _C13_kl600_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F214_2106(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64);
extern void EIF_Minit600(void);

#ifdef __cplusplus
}
#endif

#endif
