
#ifndef _C13_ds649_
#define _C13_ds649_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1048_6933(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit649(void);

#ifdef __cplusplus
}
#endif

#endif
