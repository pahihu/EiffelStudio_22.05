
#ifndef _C15_re738_
#define _C15_re738_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F612_3166(EIF_REFERENCE);
extern void EIF_Minit738(void);
extern char *(*R2799[])();

#ifdef __cplusplus
}
#endif

#endif
