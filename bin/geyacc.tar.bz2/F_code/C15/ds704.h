
#ifndef _C15_ds704_
#define _C15_ds704_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1080_7219(EIF_REFERENCE);
extern EIF_INTEGER_32 F1080_7221(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit704(void);
extern long O5524[];
extern long O5525[];

#ifdef __cplusplus
}
#endif

#endif
