/*
 * Code for class DS_SPARSE_CONTAINER [NATURAL_64, NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds703.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F1088_7335 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O5524[dtype-1083]) = (EIF_INTEGER_32) arg1;
	F1104_7541(Current, arg1);
	F1104_7547(Current, arg1);
	F1104_7554(Current, arg1);
	ti4_1 = F1088_7425(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]) = (EIF_INTEGER_32) ti4_1;
	F1104_7560(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current + O5474[dtype-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O5510[dtype-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F1088_7354(Current);
	tr1 = F1109_7570(Current);
	F1088_7405(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_NATURAL_64 F1088_7336 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F1104_7536(Current, *(EIF_INTEGER_32 *)(Current + O5514[Dtype(Current)-1083]));
}

/* {DS_SPARSE_CONTAINER}.first */
EIF_NATURAL_64 F1088_7337 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (F1104_7539(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
		loc1++;
	}
	RTLE;
	return (EIF_NATURAL_64) F1104_7536(Current, loc1);
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F1088_7340 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5525[Dtype(Current)-1083]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F1088_7341 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5524[Dtype(Current)-1083]);
}


/* {DS_SPARSE_CONTAINER}.has */
EIF_BOOLEAN F1088_7343 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O5474[Dtype(Current)-1083]);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tb1 = '\0';
			if ((EIF_BOOLEAN) (F1104_7539(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				tu8_1 = F1104_7536(Current, loc1);
				tb2 = F214_2106(loc2, tu8_1, arg1);
				tb1 = tb2;
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tb1 = '\0';
			if ((EIF_BOOLEAN) (F1104_7539(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				tb1 = (EIF_BOOLEAN)(F1104_7536(Current, loc1) == arg1);
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F1088_7344 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5514[Dtype(Current)-1083]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F1088_7354 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O5514[Dtype(Current)-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F1088_7355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1088_7407(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F1044_6920(Current, loc1);
		}
		if (tb1) {
			F1088_7405(Current, loc1);
		} else {
			tr1 = F1109_7570(Current);
			F1088_7405(Current, tr1);
		}
		F1088_7354(Current);
		F1104_7542(Current);
		F1104_7549(Current);
		F1104_7563(Current);
		F1104_7556(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F1088_7359 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1088_7354(Current);
	loc1 = F1088_7425(Current, arg1);
	F1104_7564(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		F1104_7562(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current + O5474[dtype-1083]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) (F1104_7539(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			tu4_1 = F1104_7538(Current, loc2);
			loc3 = F1109_7573(Current, tu4_1);
			ti4_1 = F1104_7561(Current, loc3);
			F1104_7555(Current, ti4_1, loc2);
			F1104_7562(Current, loc2, loc3);
		}
		loc2--;
	}
	F1104_7543(Current, arg1);
	F1104_7550(Current, arg1);
	F1104_7557(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O5524[dtype-1083]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F1088_7368 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		ti4_1 = F1104_7561(Current, *(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]));
		*(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current + O5512[dtype-1083]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5509[dtype-1083]);
		*(EIF_INTEGER_32 *)(Current + O5513[dtype-1083]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current + O5512[dtype-1083]);
			loc2 = *(EIF_INTEGER_32 *)(Current + O5513[dtype-1083]);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F1104_7539(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tu4_1 = F1104_7538(Current, loc3);
				tb2 = F215_2106(loc5, arg1, tu4_1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc4 = F1109_7573(Current, arg1);
				loc1 = F1104_7561(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					tu4_1 = F1104_7538(Current, loc1);
					tb1 = F215_2106(loc5, arg1, tu4_1);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F1104_7539(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current + O5512[dtype-1083]) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current + O5513[dtype-1083]) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F1104_7539(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(arg1 != F1104_7538(Current, loc3));
			}
			if (tb1) {
				loc4 = F1109_7573(Current, arg1);
				loc1 = F1104_7561(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if ((EIF_BOOLEAN)(arg1 == F1104_7538(Current, loc1))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F1104_7539(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current + O5511[dtype-1083]) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current + O5512[dtype-1083]) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current + O5513[dtype-1083]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F1088_7405 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F1088_7406 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F1088_7407 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1003_6815(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F973_6771(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_NATURAL_64 F1088_7411 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = F1104_7536(Current, ti4_1);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F1088_7414 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F1088_7415 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1032_6885(Current)) {
		F1003_6815(RTCW(arg1));
	} else {
		loc3 = F1044_6925(Current, arg1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = *(EIF_INTEGER_32 *)(Current + O5474[Dtype(Current)-1083]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) (F1104_7539(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			F1003_6815(RTCW(arg1));
			if ((EIF_BOOLEAN) !loc3) {
				F1044_6929(Current, arg1);
			}
		} else {
			F1003_6814(RTCW(arg1), loc1);
			if (loc3) {
				F1044_6928(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F1088_7417 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O5474[Dtype(Current)-1083]);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) (F1104_7539(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		F1003_6815(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc3) {
			F1044_6929(Current, arg1);
		}
	} else {
		F1003_6814(RTCW(arg1), loc1);
		if (loc3) {
			F1044_6928(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F1088_7421 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1044_6925(Current, arg1);
	F1003_6815(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1044_6929(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F1088_7424 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F1088_7425 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit703 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
