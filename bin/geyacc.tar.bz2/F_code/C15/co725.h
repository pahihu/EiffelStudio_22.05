
#ifndef _C15_co725_
#define _C15_co725_

#ifdef __cplusplus
extern "C" {
#endif

extern void F443_3055(EIF_REFERENCE);
extern void EIF_Minit725(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
