
#ifndef _C15_to734_
#define _C15_to734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F235_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F235_2365(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F235_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F663_3531(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
