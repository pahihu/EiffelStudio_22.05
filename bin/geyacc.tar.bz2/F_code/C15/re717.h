
#ifndef _C15_re717_
#define _C15_re717_

#ifdef __cplusplus
extern "C" {
#endif

extern void F374_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F374_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F374_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F374_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F374_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F374_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F374_2982(EIF_REFERENCE);
extern void F374_2987(EIF_REFERENCE);
extern void EIF_Minit717(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
