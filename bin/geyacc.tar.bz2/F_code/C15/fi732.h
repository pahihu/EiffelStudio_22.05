
#ifndef _C15_fi732_
#define _C15_fi732_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F586_3153(EIF_REFERENCE);
extern void EIF_Minit732(void);
extern char *(*R2796[])();

#ifdef __cplusplus
}
#endif

#endif
