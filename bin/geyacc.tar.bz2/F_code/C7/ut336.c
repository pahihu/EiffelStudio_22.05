/*
 * Code for class UT_STRING_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_STRING_FORMATTER}.put_eiffel_string */
void F1131_8305 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(arg2))-656])(arg2, loc1));
		switch (loc3) {
			case (EIF_CHARACTER_8) ' ':
			case (EIF_CHARACTER_8) '!':
			case (EIF_CHARACTER_8) '#':
			case (EIF_CHARACTER_8) '$':
			case (EIF_CHARACTER_8) '&':
			case (EIF_CHARACTER_8) '(':
			case (EIF_CHARACTER_8) ')':
			case (EIF_CHARACTER_8) '*':
			case (EIF_CHARACTER_8) '+':
			case (EIF_CHARACTER_8) ',':
			case (EIF_CHARACTER_8) '-':
			case (EIF_CHARACTER_8) '.':
			case (EIF_CHARACTER_8) '/':
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
			case (EIF_CHARACTER_8) '8':
			case (EIF_CHARACTER_8) '9':
			case (EIF_CHARACTER_8) ':':
			case (EIF_CHARACTER_8) ';':
			case (EIF_CHARACTER_8) '<':
			case (EIF_CHARACTER_8) '=':
			case (EIF_CHARACTER_8) '>':
			case (EIF_CHARACTER_8) '\?':
			case (EIF_CHARACTER_8) '@':
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'F':
			case (EIF_CHARACTER_8) 'G':
			case (EIF_CHARACTER_8) 'H':
			case (EIF_CHARACTER_8) 'I':
			case (EIF_CHARACTER_8) 'J':
			case (EIF_CHARACTER_8) 'K':
			case (EIF_CHARACTER_8) 'L':
			case (EIF_CHARACTER_8) 'M':
			case (EIF_CHARACTER_8) 'N':
			case (EIF_CHARACTER_8) 'O':
			case (EIF_CHARACTER_8) 'P':
			case (EIF_CHARACTER_8) 'Q':
			case (EIF_CHARACTER_8) 'R':
			case (EIF_CHARACTER_8) 'S':
			case (EIF_CHARACTER_8) 'T':
			case (EIF_CHARACTER_8) 'U':
			case (EIF_CHARACTER_8) 'V':
			case (EIF_CHARACTER_8) 'W':
			case (EIF_CHARACTER_8) 'X':
			case (EIF_CHARACTER_8) 'Y':
			case (EIF_CHARACTER_8) 'Z':
			case (EIF_CHARACTER_8) '[':
			case (EIF_CHARACTER_8) '\\':
			case (EIF_CHARACTER_8) ']':
			case (EIF_CHARACTER_8) '^':
			case (EIF_CHARACTER_8) '_':
			case (EIF_CHARACTER_8) '`':
			case (EIF_CHARACTER_8) 'a':
			case (EIF_CHARACTER_8) 'b':
			case (EIF_CHARACTER_8) 'c':
			case (EIF_CHARACTER_8) 'd':
			case (EIF_CHARACTER_8) 'e':
			case (EIF_CHARACTER_8) 'f':
			case (EIF_CHARACTER_8) 'g':
			case (EIF_CHARACTER_8) 'h':
			case (EIF_CHARACTER_8) 'i':
			case (EIF_CHARACTER_8) 'j':
			case (EIF_CHARACTER_8) 'k':
			case (EIF_CHARACTER_8) 'l':
			case (EIF_CHARACTER_8) 'm':
			case (EIF_CHARACTER_8) 'n':
			case (EIF_CHARACTER_8) 'o':
			case (EIF_CHARACTER_8) 'p':
			case (EIF_CHARACTER_8) 'q':
			case (EIF_CHARACTER_8) 'r':
			case (EIF_CHARACTER_8) 's':
			case (EIF_CHARACTER_8) 't':
			case (EIF_CHARACTER_8) 'u':
			case (EIF_CHARACTER_8) 'v':
			case (EIF_CHARACTER_8) 'w':
			case (EIF_CHARACTER_8) 'x':
			case (EIF_CHARACTER_8) 'y':
			case (EIF_CHARACTER_8) 'z':
			case (EIF_CHARACTER_8) '{':
			case (EIF_CHARACTER_8) '|':
			case (EIF_CHARACTER_8) '}':
			case (EIF_CHARACTER_8) '~':
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, loc3);
				break;
			case (EIF_CHARACTER_8) '\010':
				tr1 = RTMS_EX_H("%B",2,9538);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\014':
				tr1 = RTMS_EX_H("%F",2,9542);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\012':
				tr1 = RTMS_EX_H("%N",2,9550);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\015':
				tr1 = RTMS_EX_H("%R",2,9554);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\011':
				tr1 = RTMS_EX_H("%T",2,9556);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\000':
				tr1 = RTMS_EX_H("%U",2,9557);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '%':
				tr1 = RTMS_EX_H("%%",2,9509);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\'':
				tr1 = RTMS_EX_H("%\'",2,9511);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case (EIF_CHARACTER_8) '\"':
				tr1 = RTMS_EX_H("%\"",2,9506);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			default:
				tr1 = RTMS_EX_H("%/",2,9519);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				tr1 = RTOSCF(2101,F211_2101, (Current));
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4381[Dtype(RTCW(arg2))-894])(arg2, loc1);
				F935_6237(RTCW(tr1), arg1, ti4_1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) '/');
				break;
		}
		loc1++;
	}
	RTLE;
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
