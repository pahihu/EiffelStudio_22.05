/*
 * Code for class KL_OUTPUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl305.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_OUTPUT_FILE}.is_open_write */
EIF_BOOLEAN F960_6702 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F642_3240(Current);
}

/* {KL_OUTPUT_FILE}.put_character */
void F960_6703 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	F642_3291(Current, arg1);
}

/* {KL_OUTPUT_FILE}.put_string */
void F960_6704 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(5830,F897_5830, (Current));
	tr1 = F924_6065(RTCW(tr1), arg1);
	F642_3288(Current, tr1);
	RTLE;
}

/* {KL_OUTPUT_FILE}.open_write */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F960_6705 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = F642_3190(Current);
		if ((EIF_BOOLEAN)(tr1 != RTOSCF(6686,F959_6686, (Current)))) {
			F961_6719(Current);
		}
	} else {
		if ((EIF_BOOLEAN) !F959_6678(Current)) {
			F959_6680(Current);
		}
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit305 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
