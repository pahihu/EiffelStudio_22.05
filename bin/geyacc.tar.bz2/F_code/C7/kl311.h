
#ifndef _C7_kl311_
#define _C7_kl311_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F966_6747(EIF_REFERENCE);
extern EIF_REFERENCE F966_6748(EIF_REFERENCE);
extern void F966_6752(EIF_REFERENCE);
extern void EIF_Minit311(void);
extern void F642_3249(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
