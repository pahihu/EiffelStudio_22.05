/*
 * Code for class PR_GRAMMAR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr320.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_GRAMMAR}.make */
void F1115_7681 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,140,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,139,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 300L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 300L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,146,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 500L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(7715,F1115_7715, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PR_GRAMMAR}.max_rhs */
EIF_INTEGER_32 F1115_7688 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (ti4_1 > Result)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = F1082_7260(RTCW(tr1), loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		}
		loc1--;
	}
	RTLE;
	return Result;
}

/* {PR_GRAMMAR}.set_start_symbol */
void F1115_7692 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {PR_GRAMMAR}.set_eiffel_code */
void F1115_7693 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {PR_GRAMMAR}.set_expected_conflicts */
void F1115_7694 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_1_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {PR_GRAMMAR}.set_has_utf8_enconding */
void F1115_7695 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) arg1;
}

/* {PR_GRAMMAR}.put_token */
void F1115_7696 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1078_7219(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 100L)));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	F1082_7273(RTCW(tr1), arg1);
	RTLE;
}

/* {PR_GRAMMAR}.put_variable */
void F1115_7697 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1078_7219(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 300L)));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1082_7273(RTCW(tr1), arg1);
	RTLE;
}

/* {PR_GRAMMAR}.put_type */
void F1115_7698 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1078_7219(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 300L)));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1082_7273(RTCW(tr1), arg1);
	RTLE;
}

/* {PR_GRAMMAR}.put_rule */
void F1115_7699 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1078_7219(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 500L)));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1082_7273(RTCW(tr1), arg1);
	RTLE;
}

/* {PR_GRAMMAR}.print_grammar */
void F1115_7700 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Grammar\012\012",9,1198722826);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		F147_1647(RTCW(tr1), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) '\012');
		loc1++;
	}
	tr1 = RTMS_EX_H("\012Terminals, with rules where they appear\012\012",42,1482720010);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = RTMS_EX_H("$ (token 0)\012",12,1368139274);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		F141_1583(RTCW(tr1), Current, arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) '\012');
		loc1++;
	}
	tr1 = RTMS_EX_H("\012Nonterminals, with rules where they appear\012\012",45,433586442);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		F140_1560(RTCW(tr1), Current, arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) '\012');
		loc1++;
	}
	RTLE;
}

/* {PR_GRAMMAR}.reduce */
void F1115_7701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	F1115_7704(Current);
	F1115_7705(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = F1082_7260(RTCW(tr1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_4_0_);
		if (tb1) {
			F147_1635(RTCW(loc3), loc1);
			loc1++;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1082_7294(RTCW(tr1), loc1);
			loc7++;
		}
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc1 > ti4_2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = F1082_7260(RTCW(tr1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_6_0_);
		if (tb1) {
			F139_1546(RTCW(loc4), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			loc5 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
				tr1 = F1082_7260(RTCW(loc5), loc2);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_4_0_);
				if ((EIF_BOOLEAN) !tb1) {
					F1082_7294(RTCW(loc5), loc2);
				}
				loc2--;
			}
			loc1++;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1082_7294(RTCW(tr1), loc1);
			loc6++;
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
		loc8 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5664(RTCW(loc8), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("Parser contains ",16,1225786912);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
		if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 useless nonterminal",21,593516);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc6, loc8);
				tr1 = RTMS_EX_H(" useless nonterminals",21,1188104307);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTMS_EX_H(" and ",5,1634870304);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
		}
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 useless rule",14,1302007909);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc7, loc8);
				tr1 = RTMS_EX_H(" useless rules",14,2076341875);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
			}
		}
		tr1 = RTMS_EX_H(".\012",2,11786);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc8))-894])(loc8, tr1);
		loc9 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1165_8410(RTCW(loc9), loc8);
		F1114_7662(RTCW(arg1), loc9);
	}
	RTLE;
}

/* {PR_GRAMMAR}.reduce_verbose */
void F1115_7702 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLR(9,loc9);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F953_6588(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F953_6588(RTCW(tr1));
	F1115_7701(Current, arg1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ti4_1);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ti4_1);
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Useless nonterminals:\012\012",23,1834742026);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
		loc12 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
		loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc10 > loc12)) break;
			loc6 = F1082_7260(RTCW(loc1), loc10);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_6_0_);
			if ((EIF_BOOLEAN) !tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\011');
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
			}
			loc10++;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 > loc12)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc7 = F1082_7260(RTCW(tr1), loc10);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb1) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("Terminals which are not used:\012\012",31,360966666);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
			}
			loc4++;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\011');
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
		}
		loc10++;
	}
	if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
	}
	if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Useless rules:\012\012",16,1818944010);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
		loc12 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
		loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc10 > loc12)) break;
			loc8 = F1082_7260(RTCW(loc2), loc10);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc8)+ _CHROFF_4_0_);
			if ((EIF_BOOLEAN) !tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '#');
				F904_5915(RTCW(arg2), loc10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\011');
				tr1 = *(EIF_REFERENCE *)(RTCW(loc8));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				tr1 = RTMS_EX_H(": ",2,14880);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				loc9 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
				loc13 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
				loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc11 > loc13)) break;
					tr1 = F1082_7260(RTCW(loc9), loc11);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) ' ');
					loc11++;
				}
				tr1 = RTMS_EX_H(";\012",2,15114);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
			}
			loc10++;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\012');
	}
	RTLE;
}

/* {PR_GRAMMAR}.set_nullable */
void F1115_7703 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc11);
	RTLR(3,loc4);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,loc13);
	RTLR(8,loc10);
	RTLR(9,loc12);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,1081,0xFF01,139,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc11 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1082_7254(RTCW(loc11), loc3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc4 = F1082_7260(RTCW(tr1), loc1);
		loc7 = *(EIF_REFERENCE *)(RTCW(loc4));
		loc8 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
		tb1 = F1030_6885(RTCW(loc8));
		if (tb1) {
			F140_1557(RTCW(loc7));
		} else {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_6_1_);
			if ((EIF_BOOLEAN) !tb1) {
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_4_0_0_1_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,139,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc9 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
				}
				F1082_7254(RTCW(loc9), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				F1082_7272(RTCW(loc9), loc7);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L)))) break;
					tr1 = F1082_7260(RTCW(loc8), loc2);
					loc13 = tr1;
					loc13 = RTRV(eif_new_type(139, 0x01),loc13);
					if ((EIF_BOOLEAN) !EIF_TEST(loc13)) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tb1 = *(EIF_BOOLEAN *)(loc13+ _CHROFF_6_1_);
						if ((EIF_BOOLEAN) !tb1) {
							F1082_7273(RTCW(loc9), loc13);
						}
					}
					loc2--;
				}
				if ((EIF_BOOLEAN) !loc5) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
						F1082_7273(RTCW(loc11), loc9);
					} else {
						F140_1557(RTCW(loc7));
					}
				}
			}
		}
		loc1++;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,1081,0xFF01,139,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc10 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_4_0_0_1_);
	F1082_7254(RTCW(loc10), ti4_1);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_4_0_0_1_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) break;
		loc12 = (EIF_REFERENCE) loc10;
		loc10 = (EIF_REFERENCE) loc11;
		loc11 = (EIF_REFERENCE) loc12;
		F1082_7306(RTCW(loc11));
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc9 = F1082_7260(RTCW(loc10), loc1);
			tr1 = F1082_7261(RTCW(loc9));
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_6_1_);
			if ((EIF_BOOLEAN) !tb1) {
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					if ((EIF_BOOLEAN) (loc6 || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L)))) break;
					tr1 = F1082_7262(RTCW(loc9));
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_6_1_);
					if (tb1) {
						F1082_7293(RTCW(loc9));
						loc2--;
					} else {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				if ((EIF_BOOLEAN) !loc6) {
					tr1 = F1082_7261(RTCW(loc9));
					F140_1557(RTCW(tr1));
				} else {
					F1082_7273(RTCW(loc11), loc9);
				}
			}
			loc1++;
		}
	}
	RTLE;
}

/* {PR_GRAMMAR}.mark_useful_variables */
void F1115_7704 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		if ((EIF_BOOLEAN) !loc7) break;
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 > loc8)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc4 = F1082_7260(RTCW(tr1), loc5);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_4_0_);
			if ((EIF_BOOLEAN) !tb1) {
				F147_1645(RTCW(loc4), (EIF_BOOLEAN) 1);
				loc1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
				for (;;) {
					if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 1L))) break;
					loc3 = F1082_7260(RTCW(loc1), loc6);
					tb1 = '\01';
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1499[Dtype(RTCW(loc3))-139])(loc3);
					if (!tb2) {
						tb2 = *(EIF_BOOLEAN *)(RTCW(loc3) + O1500[Dtype(loc3)-138]);
						tb1 = tb2;
					}
					if (tb1) {
						loc6--;
					} else {
						F147_1645(RTCW(loc4), (EIF_BOOLEAN) 0);
						loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
				tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_4_0_);
				if (tb1) {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc4));
					tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_6_0_);
					if ((EIF_BOOLEAN) !tb1) {
						F139_1544(RTCW(loc2), (EIF_BOOLEAN) 1);
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				loc6--;
			}
			loc5++;
		}
	}
	RTLE;
}

/* {PR_GRAMMAR}.mark_useful_rules */
void F1115_7705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_6_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1082_7260(RTCW(tr1), loc2);
		F139_1544(RTCW(tr1), (EIF_BOOLEAN) 0);
		loc2--;
	}
	if (loc1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F139_1544(RTCW(tr1), (EIF_BOOLEAN) 1);
		F1115_7706(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = F1082_7260(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_6_0_);
		if ((EIF_BOOLEAN) !tb1) {
			F147_1645(RTCW(loc3), (EIF_BOOLEAN) 0);
		}
		loc2--;
	}
	RTLE;
}

/* {PR_GRAMMAR}.traverse_variable */
void F1115_7706 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc7);
	RTLR(6,Current);
	RTLIU(7);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 1L))) break;
		loc4 = F1082_7260(RTCW(loc2), loc5);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_4_0_);
		if (tb1) {
			loc1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
			for (;;) {
				if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 1L))) break;
				loc3 = F1082_7260(RTCW(loc1), loc6);
				loc7 = loc3;
				loc7 = RTRV(eif_new_type(139, 0x01),loc7);
				if (EIF_TEST(loc7)) {
					tb1 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_6_0_);
					if ((EIF_BOOLEAN) !tb1) {
						F139_1544(loc7, (EIF_BOOLEAN) 1);
						F1115_7706(Current, loc7);
					}
				} else {
					F139_1544(RTCW(loc3), (EIF_BOOLEAN) 1);
				}
				loc6--;
			}
		}
		loc5--;
	}
	RTLE;
}

/* {PR_GRAMMAR}.dummy_variable */
static EIF_REFERENCE F1115_7715_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (7715);
#define Result RTOSR(7715)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(139, 0x01).id, 139, _OBJSIZ_6_2_0_2_0_0_0_0_);
	tr2 = RTMS_EX_H("dummy",5,1970873721);
	tr3 = RTOSCF(7716,F1115_7716, (Current));
	F140_1548(RTCW(tr1), ((EIF_INTEGER_32) 0L), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7715);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1115_7715 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7715,F1115_7715_body,(Current));
}

/* {PR_GRAMMAR}.dummy_type */
static EIF_REFERENCE F1115_7716_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7716);
#define Result RTOSR(7716)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("detachable",10,1071588197);
	tr3 = RTMS_EX_H("ANY",3,4279897);
	F902_5889(RTCW(tr1), ((EIF_INTEGER_32) 0L), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7716);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1115_7716 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7716,F1115_7716_body,(Current));
}

void EIF_Minit320 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
