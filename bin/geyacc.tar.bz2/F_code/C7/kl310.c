/*
 * Code for class KL_INPUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl310.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_INPUT_FILE}.make */
void F965_6725 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(894, 1).id);
	F887_5367(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F959_6672(Current, arg1);
	RTLE;
}

/* {KL_INPUT_FILE}.is_open_read */
EIF_BOOLEAN F965_6728 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F642_3239(Current);
}

/* {KL_INPUT_FILE}.end_of_file */
EIF_BOOLEAN F965_6729 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_);
}


/* {KL_INPUT_FILE}.read_character */
void F965_6730 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tc1 = (RTNA((RTCW(loc1))), ((EIF_CHARACTER_8) 0));
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_7_1_) = (EIF_CHARACTER_8) tc1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	} else {
		if (F642_3213(Current)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			F642_3321(Current);
			tb1 = F642_3213(Current);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_) = (EIF_BOOLEAN) tb1;
		}
	}
	RTLE;
}

/* {KL_INPUT_FILE}.read_to_string */
EIF_INTEGER_32 F965_6733 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg2;
	loc6 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == arg3) || (EIF_BOOLEAN)(loc6 == NULL))) break;
		loc5++;
		tc1 = (RTNA((RTCW(loc6))), ((EIF_CHARACTER_8) 0));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2772[Dtype(RTCW(arg1))-681])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
		loc6 = (EIF_REFERENCE) tr1;
		loc1++;
	}
	RTAR(Current, loc6);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc6;
	if ((EIF_BOOLEAN) (loc5 < arg3)) {
		if ((EIF_BOOLEAN) !F642_3213(Current)) {
			tr1 = RTOSCF(5958,F912_5958, (Current));
			tr2 = RTOSCF(6740,F965_6740, (Current));
			tb1 = F6_74(RTCW(tr1), arg1, tr2);
			if (tb1) {
				loc5 += F644_3502(Current, arg1, loc1, (EIF_INTEGER_32) (arg3 - loc5));
				F889_5465(RTCW(arg1));
			} else {
				tr1 = RTOSCF(5958,F912_5958, (Current));
				tr2 = RTOSCF(6741,F965_6741, (Current));
				tb1 = F6_74(RTCW(tr1), arg1, tr2);
				if (tb1) {
					loc5 += F644_3502(Current, arg1, loc1, (EIF_INTEGER_32) (arg3 - loc5));
					F889_5465(RTCW(arg1));
				} else {
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - loc5);
					loc2 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F893_5664(RTCW(loc2), loc4);
					F895_5826(RTCW(loc2), loc4);
					ti4_1 = F644_3502(Current, loc2, ((EIF_INTEGER_32) 1L), loc4);
					loc4 = (EIF_INTEGER_32) ti4_1;
					F889_5465(RTCW(loc2));
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 > loc4)) break;
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(loc2))-656])(loc2, loc3));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2772[Dtype(RTCW(arg1))-681])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
						loc1++;
						loc3++;
					}
					loc5 += loc4;
				}
			}
		}
		tb1 = F642_3213(Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_) = (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_INTEGER_32) loc5;
}

/* {KL_INPUT_FILE}.open_read */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F965_6735 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = F642_3190(Current);
		if ((EIF_BOOLEAN)(tr1 != RTOSCF(6686,F959_6686, (Current)))) {
			*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tb1 = '\0';
			if (F642_3214(Current)) {
				tb1 = F642_3217(Current);
			}
			if (tb1) {
				F966_6752(Current);
			}
		}
	} else {
		if ((EIF_BOOLEAN) !F959_6678(Current)) {
			F965_6736(Current);
		}
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {KL_INPUT_FILE}.close */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F965_6736 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		F642_3266(Current);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {KL_INPUT_FILE}.dummy_string */

EIF_REFERENCE F965_6740 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6740,RTMS_EX_H("",0,0));
}

/* {KL_INPUT_FILE}.dummy_kl_character_buffer */
static EIF_REFERENCE F965_6741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6741);
#define Result RTOSR(6741)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(250, 0x01).id, 250, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F251_2588(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6741);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F965_6741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6741,F965_6741_body,(Current));
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
