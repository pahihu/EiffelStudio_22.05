
#ifndef _C7_uc328_
#define _C7_uc328_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1123_7901(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit328(void);

#ifdef __cplusplus
}
#endif

#endif
