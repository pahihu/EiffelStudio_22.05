/*
 * Code for class UT_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut337.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_ERROR}.message */
EIF_REFERENCE F1132_8308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	tr1 = RTOSCF(5830,F897_5830, (Current));
	Result = F924_6042(RTCW(tr1), arg1, loc4);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc4)) break;
		loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(arg1))-656])(arg1, loc2));
		loc2++;
		if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '$')) {
			if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '\000')) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, loc5);
			} else {
				tr1 = RTOSCF(5830,F897_5830, (Current));
				tr1 = F924_6060(RTCW(tr1), Result, arg1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				Result = (EIF_REFERENCE) tr1;
			}
		} else {
			if ((EIF_BOOLEAN) (loc2 > loc4)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '$');
			} else {
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(arg1))-656])(arg1, loc2));
				if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '$')) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '$');
					loc2++;
				} else {
					tr1 = RTOSCF(5830,F897_5830, (Current));
					loc1 = F924_6042(RTCW(tr1), arg1, ((EIF_INTEGER_32) 5L));
					if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '{')) {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc2++;
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > loc4) || loc8)) break;
							loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(arg1))-656])(arg1, loc2));
							if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '}')) {
								loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '\000')) {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, loc5);
								} else {
									tr1 = RTOSCF(5830,F897_5830, (Current));
									F924_6062(RTCW(tr1), loc1, arg1, loc2, loc2);
								}
							}
							loc2++;
						}
					} else {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > loc4) || loc6)) break;
							loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3006[Dtype(RTCW(arg1))-656])(arg1, loc2));
							switch (loc5) {
								case (EIF_CHARACTER_8) '0':
								case (EIF_CHARACTER_8) '1':
								case (EIF_CHARACTER_8) '2':
								case (EIF_CHARACTER_8) '3':
								case (EIF_CHARACTER_8) '4':
								case (EIF_CHARACTER_8) '5':
								case (EIF_CHARACTER_8) '6':
								case (EIF_CHARACTER_8) '7':
								case (EIF_CHARACTER_8) '8':
								case (EIF_CHARACTER_8) '9':
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, loc5);
									loc2++;
									break;
								default:
									loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									break;
							}
						}
					}
					tb1 = F887_5398(RTCW(loc1));
					if (tb1) {
						loc3 = F887_5432(RTCW(loc1));
						tr1 = *(EIF_REFERENCE *)(Current);
						tb1 = F682_3639(RTCW(tr1), loc3);
						if (tb1) {
							tr1 = RTOSCF(5830,F897_5830, (Current));
							tr2 = *(EIF_REFERENCE *)(Current);
							tr2 = F682_3624(RTCW(tr2), loc3);
							tr1 = F924_6059(RTCW(tr1), Result, tr2);
							Result = (EIF_REFERENCE) tr1;
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								tr1 = RTOSCF(5830,F897_5830, (Current));
								tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(1724,F150_1724, (Current))));
								tr1 = F924_6059(RTCW(tr1), Result, tr2);
								Result = (EIF_REFERENCE) tr1;
							} else {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '$');
								if (loc7) {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '{');
								}
								tr1 = RTOSCF(5830,F897_5830, (Current));
								tr1 = F924_6059(RTCW(tr1), Result, loc1);
								Result = (EIF_REFERENCE) tr1;
								if (loc8) {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '}');
								}
							}
						}
					} else {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '$');
						if (loc7) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '{');
						}
						tr1 = RTOSCF(5830,F897_5830, (Current));
						tr1 = F924_6059(RTCW(tr1), Result, loc1);
						Result = (EIF_REFERENCE) tr1;
						if (loc8) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(Result))-894])(Result, (EIF_CHARACTER_8) '}');
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UT_ERROR}.default_message */
EIF_REFERENCE F1132_8310 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6176[Dtype(Current)-1132])(Current);
	Result = F1132_8308(Current, tr1);
	RTLE;
	return Result;
}

/* {UT_ERROR}.empty_string */

EIF_REFERENCE F1132_8313 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (8313,RTMS_EX_H("",0,0));
}

void EIF_Minit337 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
