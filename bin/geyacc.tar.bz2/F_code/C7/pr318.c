/*
 * Code for class PR_FSM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_FSM}.make */
void F1113_7637 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	F1115_7701(RTCW(arg1), arg2);
	F1115_7703(RTCW(arg1));
	F1113_7639(Current, arg1);
	F1113_7642(Current, arg2);
	F1113_7644(Current, arg2);
	RTLE;
}

/* {PR_FSM}.make_verbose */
void F1113_7638 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	F1115_7702(RTCW(arg1), arg2, arg3);
	F1115_7703(RTCW(arg1));
	F1113_7639(Current, arg1);
	F1113_7643(Current, arg2, arg3);
	F1113_7645(Current, arg2, arg3);
	F1113_7646(Current, arg3);
	RTLE;
}

/* {PR_FSM}.make_default */
void F1113_7639 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,925,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1082_7254(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1106,0xFF01,1081,0xFF01,925,814,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1097_7490(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1113_7647(Current);
	F1113_7655(Current);
	RTLE;
}

/* {PR_FSM}.resolve_conflicts */
void F1113_7642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,loc10);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F1082_7260(RTCW(tr1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_6_0_);
		if (tb1) {
			loc8 = F926_6157(RTCW(loc3));
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_6_1_);
			if (tb1) {
				loc4 = F926_6158(RTCW(loc3));
				loc6 = F926_6159(RTCW(loc3));
				loc5 += loc4;
				loc7 += loc6;
			}
		}
		loc1++;
	}
	tb1 = '\01';
	tb2 = '\0';
	if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_1_0_0_);
		tb2 = (EIF_BOOLEAN)(loc5 != ti4_1);
	}
	if (!tb2) {
		tb1 = (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc9 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5664(RTCW(loc9), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("Parser contains ",16,1225786912);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 shift/reduce conflict",23,427650164);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc5, loc9);
				tr1 = RTMS_EX_H(" shift/reduce conflicts",23,548158579);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTMS_EX_H(" and ",5,1634870304);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
		}
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 reduce/reduce conflict",24,913691764);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc7, loc9);
				tr1 = RTMS_EX_H(" reduce/reduce conflicts",24,849998195);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
			}
		}
		tr1 = RTMS_EX_H(".\012",2,11786);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc9))-894])(loc9, tr1);
		loc10 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1165_8410(RTCW(loc10), loc9);
		F1114_7662(RTCW(arg1), loc10);
	}
	RTLE;
}

/* {PR_FSM}.resolve_conflicts_verbose */
void F1113_7643 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,arg2);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F1082_7260(RTCW(tr1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_6_0_);
		if (tb1) {
			loc8 = F926_6157(RTCW(loc3));
			loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5278[Dtype(RTCW(loc8))-1076])(loc8);
			F979_6782(RTCW(loc9));
			for (;;) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2618[Dtype(RTCW(loc9))-381])(loc9);
				if (tb1) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2617[Dtype(RTCW(loc9))-381])(loc9);
				F47_567(RTCW(tr1), arg2);
				F979_6783(RTCW(loc9));
			}
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_6_1_);
			if (tb2) {
				loc4 = F926_6158(RTCW(loc3));
				loc6 = F926_6159(RTCW(loc3));
				loc5 += loc4;
				loc7 += loc6;
				tr1 = RTMS_EX_H("State ",6,1799093536);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_6_2_0_0_);
				F904_5915(RTCW(arg2), ti4_1);
				tr1 = RTMS_EX_H(" contains ",10,951250720);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
					tr1 = RTMS_EX_H("1 shift/reduce conflict",23,427650164);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 1L))) {
						F904_5915(RTCW(arg2), loc4);
						tr1 = RTMS_EX_H(" shift/reduce conflicts",23,548158579);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
					}
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L)))) {
					tr1 = RTMS_EX_H(" and ",5,1634870304);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				}
				if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 1L))) {
					tr1 = RTMS_EX_H("1 reduce/reduce conflict",24,913691764);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L))) {
						F904_5915(RTCW(arg2), loc6);
						tr1 = RTMS_EX_H(" reduce/reduce conflicts",24,849998195);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '.');
				F907_5933(RTCW(arg2));
			}
		}
		loc1++;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
		F907_5933(RTCW(arg2));
	}
	tb2 = '\01';
	tb3 = '\0';
	if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_1_0_0_);
		tb3 = (EIF_BOOLEAN)(loc5 != ti4_1);
	}
	if (!tb3) {
		tb2 = (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L));
	}
	if (tb2) {
		loc10 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5664(RTCW(loc10), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("Parser contains ",16,1225786912);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 shift/reduce conflict",23,427650164);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc5, loc10);
				tr1 = RTMS_EX_H(" shift/reduce conflicts",23,548158579);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)))) {
			tr1 = RTMS_EX_H(" and ",5,1634870304);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
		}
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 reduce/reduce conflict",24,913691764);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
		} else {
			if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(4027,F774_4027, (Current));
				F923_6022(RTCW(tr1), loc7, loc10);
				tr1 = RTMS_EX_H(" reduce/reduce conflicts",24,849998195);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
			}
		}
		tr1 = RTMS_EX_H(".\012",2,11786);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc10))-894])(loc10, tr1);
		loc11 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1165_8410(RTCW(loc11), loc10);
		F1114_7662(RTCW(arg1), loc11);
	}
	RTLE;
}

/* {PR_FSM}.set_error_actions */
void F1113_7644 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLR(6,loc11);
	RTLR(7,loc12);
	RTLR(8,loc13);
	RTLR(9,loc14);
	RTLR(10,loc18);
	RTLR(11,loc19);
	RTLR(12,arg1);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = F1082_7260(RTCW(tr1), loc1);
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc6 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			loc7 = F1082_7260(RTCW(loc6), loc3);
			tb1 = F777_4099(RTCW(loc7));
			if ((EIF_BOOLEAN) !tb1) {
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tb1 = F777_4100(RTCW(loc7));
				if ((EIF_BOOLEAN) !tb1) {
					if ((EIF_BOOLEAN)(loc8 != NULL)) {
						loc11 = F777_4097(RTCW(loc7));
						loc12 = F777_4097(RTCW(loc8));
						if (!RTEQ(loc11, loc12)) {
							loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
						if ((EIF_BOOLEAN)(loc11 != NULL)) {
							loc15 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_0_0_0_);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
							loc15 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
						}
						if ((EIF_BOOLEAN)(loc12 != NULL)) {
							loc16 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_0_);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc8));
							loc16 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
						}
						if ((EIF_BOOLEAN) (loc15 < loc16)) {
							loc8 = (EIF_REFERENCE) loc7;
						}
					} else {
						loc8 = (EIF_REFERENCE) loc7;
					}
				} else {
					loc8 = (EIF_REFERENCE) NULL;
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
				}
			}
			loc3++;
		}
		if (loc9) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			loc13 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,776,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				loc14 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			F1082_7254(RTCW(loc14), loc4);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				loc7 = F1082_7260(RTCW(loc6), loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
				tb1 = F1082_7267(RTCW(loc13), tr1);
				if (tb1) {
					F1082_7273(RTCW(loc14), loc7);
				}
				loc3++;
			}
			loc4 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_4_0_0_1_);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				loc7 = F1082_7260(RTCW(loc14), loc3);
				if ((EIF_BOOLEAN)(loc8 != NULL)) {
					loc11 = F777_4097(RTCW(loc7));
					loc12 = F777_4097(RTCW(loc8));
					if (!RTEQ(loc11, loc12)) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						loc15 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_0_0_0_);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
						loc15 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
					}
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						loc16 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_0_);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc8));
						loc16 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
					}
					if ((EIF_BOOLEAN) (loc15 < loc16)) {
						loc8 = (EIF_REFERENCE) loc7;
					}
				} else {
					loc8 = (EIF_REFERENCE) loc7;
				}
				loc3++;
			}
		}
		if (loc10) {
			loc17++;
			loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			tr1 = F777_4097(RTCW(loc8));
			F926_6156(RTCW(loc5), tr1);
			loc8 = (EIF_REFERENCE) NULL;
		}
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc17 >= ((EIF_INTEGER_32) 1L))) {
		loc18 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5664(RTCW(loc18), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("Parser contains ",16,1225786912);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc18))-894])(loc18, tr1);
		if ((EIF_BOOLEAN)(loc17 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 error action conflict.\012",25,242750474);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc18))-894])(loc18, tr1);
		} else {
			tr1 = RTOSCF(4027,F774_4027, (Current));
			F923_6022(RTCW(tr1), loc17, loc18);
			tr1 = RTMS_EX_H(" error action conflicts.\012",25,1199306762);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc18))-894])(loc18, tr1);
		}
		loc19 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1165_8410(RTCW(loc19), loc18);
		F1114_7662(RTCW(arg1), loc19);
	}
	RTLE;
}

/* {PR_FSM}.set_error_actions_verbose */
void F1113_7645 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc7);
	RTLR(3,loc8);
	RTLR(4,loc10);
	RTLR(5,loc11);
	RTLR(6,loc13);
	RTLR(7,loc14);
	RTLR(8,loc9);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,arg2);
	RTLR(12,loc20);
	RTLR(13,loc21);
	RTLR(14,arg1);
	RTLIU(15);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc7 = F1082_7260(RTCW(tr1), loc1);
		loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc8 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_1_);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_4_0_0_1_);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			loc10 = F1082_7260(RTCW(loc8), loc3);
			tb1 = F777_4099(RTCW(loc10));
			if ((EIF_BOOLEAN) !tb1) {
				loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tb1 = F777_4100(RTCW(loc10));
				if ((EIF_BOOLEAN) !tb1) {
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						loc13 = F777_4097(RTCW(loc10));
						loc14 = F777_4097(RTCW(loc11));
						if (!RTEQ(loc13, loc14)) {
							if ((EIF_BOOLEAN)(loc9 == NULL)) {
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,776,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									loc9 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
								}
								F1082_7254(RTCW(loc9), loc4);
								F1082_7273(RTCW(loc9), loc11);
							}
							F1082_7273(RTCW(loc9), loc10);
						}
						if ((EIF_BOOLEAN)(loc13 != NULL)) {
							loc17 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_0_0_0_);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
							loc17 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
						}
						if ((EIF_BOOLEAN)(loc14 != NULL)) {
							loc18 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_0_);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc11));
							loc18 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
						}
						if ((EIF_BOOLEAN) (loc17 < loc18)) {
							loc11 = (EIF_REFERENCE) loc10;
						}
					} else {
						loc11 = (EIF_REFERENCE) loc10;
					}
				} else {
					loc11 = (EIF_REFERENCE) NULL;
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
				}
			}
			loc3++;
		}
		if (loc12) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			loc15 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,776,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc16 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			F1082_7254(RTCW(loc16), loc4);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				loc10 = F1082_7260(RTCW(loc8), loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
				tb1 = F1082_7267(RTCW(loc15), tr1);
				if (tb1) {
					F1082_7273(RTCW(loc16), loc10);
				}
				loc3++;
			}
			loc4 = *(EIF_INTEGER_32 *)(RTCW(loc16)+ _LNGOFF_4_0_0_1_);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				loc10 = F1082_7260(RTCW(loc16), loc3);
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					loc13 = F777_4097(RTCW(loc10));
					loc14 = F777_4097(RTCW(loc11));
					if (!RTEQ(loc13, loc14)) {
						if ((EIF_BOOLEAN)(loc9 == NULL)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,776,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								loc9 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
							}
							F1082_7254(RTCW(loc9), loc4);
							F1082_7273(RTCW(loc9), loc11);
						}
						F1082_7273(RTCW(loc9), loc10);
					}
					if ((EIF_BOOLEAN)(loc13 != NULL)) {
						loc17 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_0_0_0_);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
						loc17 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
					}
					if ((EIF_BOOLEAN)(loc14 != NULL)) {
						loc18 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_0_);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc11));
						loc18 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_2_);
					}
					if ((EIF_BOOLEAN) (loc17 < loc18)) {
						loc11 = (EIF_REFERENCE) loc10;
					}
				} else {
					loc11 = (EIF_REFERENCE) loc10;
				}
				loc3++;
			}
		}
		if ((EIF_BOOLEAN)(loc9 != NULL)) {
			tr1 = RTMS_EX_H("State ",6,1799093536);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg2))-907])(arg2, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_6_2_0_0_);
			F904_5915(RTCW(arg2), ti4_1);
			tr1 = RTMS_EX_H(" contains 1 error action conflict:",34,1467567418);
			F907_5932(RTCW(arg2), tr1);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc5 > loc6)) break;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg2))-907])(arg2, (EIF_CHARACTER_8) '\011');
				tr1 = F1082_7260(RTCW(loc9), loc5);
				F777_4103(RTCW(tr1), arg2);
				F907_5933(RTCW(arg2));
				loc5++;
			}
			loc19++;
			loc9 = (EIF_REFERENCE) NULL;
		}
		if ((EIF_BOOLEAN)(loc11 != NULL)) {
			tr1 = F777_4097(RTCW(loc11));
			F926_6156(RTCW(loc7), tr1);
			loc11 = (EIF_REFERENCE) NULL;
		}
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc19 >= ((EIF_INTEGER_32) 1L))) {
		F907_5933(RTCW(arg2));
		loc20 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F893_5664(RTCW(loc20), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("Parser contains ",16,1225786912);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc20))-894])(loc20, tr1);
		if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("1 error action conflict.\012",25,242750474);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc20))-894])(loc20, tr1);
		} else {
			tr1 = RTOSCF(4027,F774_4027, (Current));
			F923_6022(RTCW(tr1), loc19, loc20);
			tr1 = RTMS_EX_H(" error action conflicts.\012",25,1199306762);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc20))-894])(loc20, tr1);
		}
		loc21 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1165_8410(RTCW(loc21), loc20);
		F1114_7662(RTCW(arg1), loc21);
	}
	RTLE;
}

/* {PR_FSM}.print_machine */
void F1113_7646 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1115_7700(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		F926_6162(RTCW(tr1), arg1);
		loc1++;
	}
	RTLE;
}

/* {PR_FSM}.build_nondeterministic */
void F1113_7647 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1113_7652(Current);
	F1113_7648(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1082_7260(RTCW(tr1), loc1);
		F1113_7651(Current, tr1);
		loc1++;
	}
	F1113_7649(Current);
	RTLE;
}

/* {PR_FSM}.put_start_state */
void F1113_7648 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	loc1 = RTLNS(eif_new_type(925, 0x01).id, 925, _OBJSIZ_6_2_0_2_0_0_0_0_);
	F926_6137(RTCW(loc1), ((EIF_INTEGER_32) 0L), loc2);
	F1113_7650(Current, loc1, loc2);
	F926_6160(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current);
	F1082_7272(RTCW(tr1), loc1);
	RTLE;
}

/* {PR_FSM}.put_final_state */
void F1113_7649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc5);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1082_7268(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1082_7261(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = F926_6147(RTCW(loc1), loc5);
	if (tb1) {
		loc2 = F926_6144(RTCW(loc1), loc5);
	} else {
		loc2 = RTLNS(eif_new_type(925, 0x01).id, 925, _OBJSIZ_6_2_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		F926_6137(RTCW(loc2), ti4_1, loc5);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1082_7273(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		F1082_7278(RTCW(tr1), loc2);
	}
	loc6 = RTLNS(eif_new_type(140, 0x01).id, 140, _OBJSIZ_3_2_0_4_0_0_0_0_);
	tr1 = RTMS_EX_H("$",1,36);
	tr2 = RTOSCF(7658,F1113_7658, (Current));
	F139_1538(RTCW(loc6), ((EIF_INTEGER_32) 0L), tr1, tr2);
	loc3 = RTLNS(eif_new_type(925, 0x01).id, 925, _OBJSIZ_6_2_0_2_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F926_6137(RTCW(loc3), ti4_1, loc6);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1082_7273(RTCW(tr1), loc3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
	F1082_7278(RTCW(tr1), loc3);
	loc4 = RTLNS(eif_new_type(925, 0x01).id, 925, _OBJSIZ_6_2_0_2_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F926_6137(RTCW(loc4), ti4_1, loc6);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1082_7273(RTCW(tr1), loc4);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
	F1082_7278(RTCW(tr1), loc4);
	RTLE;
}

/* {PR_FSM}.put_closure_positions */
void F1113_7650 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_4_);
	loc1 = F1077_7140(RTCW(tr1));
	F979_6782(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1029_6870(RTCW(loc1));
		loc3 = RTLNS(eif_new_type(776, 0x01).id, 776, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F777_4092(RTCW(loc3), loc2, ((EIF_INTEGER_32) 1L));
		F926_6152(RTCW(arg1), loc3);
		F979_6783(RTCW(loc1));
	}
	RTLE;
}

/* {PR_FSM}.build_transitions */
void F1113_7651 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc13);
	RTLR(6,loc6);
	RTLR(7,loc8);
	RTLR(8,loc7);
	RTLR(9,loc15);
	RTLR(10,loc14);
	RTLR(11,loc12);
	RTLR(12,tr2);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,925,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc10 = RTLNS(typres0.id, 681, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F682_3619(RTCW(loc10), NULL, (EIF_INTEGER_32) -loc4, loc5);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	loc13 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tb1 = F1082_7268(RTCW(loc13), loc3);
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(loc13), (EIF_INTEGER_32) (ti4_1 + loc3));
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc6 = F1082_7260(RTCW(loc1), loc2);
		tb1 = F777_4100(RTCW(loc6));
		if ((EIF_BOOLEAN) !tb1) {
			loc8 = F777_4095(RTCW(loc6));
			loc9 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O1503[Dtype(loc8)-138]);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1499[Dtype(RTCW(loc8))-139])(loc8);
			if (tb1) {
				loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc9;
			}
			loc7 = F682_3624(RTCW(loc10), loc9);
			if ((EIF_BOOLEAN)(loc7 == NULL)) {
				loc7 = RTLNS(eif_new_type(925, 0x01).id, 925, _OBJSIZ_6_2_0_2_0_0_0_0_);
				F926_6137(RTCW(loc7), ((EIF_INTEGER_32) 0L), loc8);
				F682_3643(RTCW(loc10), loc7, loc9);
				loc11++;
			}
			tr1 = F777_4096(RTCW(loc6));
			loc6 = (EIF_REFERENCE) tr1;
			F926_6152(RTCW(loc7), loc6);
			tb1 = F777_4100(RTCW(loc6));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F777_4095(RTCW(loc6));
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(139, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					F1113_7650(Current, loc7, loc15);
				}
			}
		} else {
			loc14 = RTLNS(eif_new_type(145, 0x01).id, 145, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
			F146_1615(RTCW(loc14), tr1);
			F1082_7273(RTCW(loc13), loc14);
		}
		loc2++;
	}
	loc12 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	tb1 = F1082_7268(RTCW(loc12), loc11);
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_4_0_0_1_);
		F1082_7307(RTCW(loc12), (EIF_INTEGER_32) (ti4_1 + loc11));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1082_7268(RTCW(tr1), loc11);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_0_);
		F1082_7307(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + loc11) + ((EIF_INTEGER_32) 100L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_11_0_0_7_);
		F1086_7359(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + loc11) + ((EIF_INTEGER_32) 100L)));
	}
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc4;
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc5)) break;
		loc7 = F682_3624(RTCW(loc10), loc2);
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			tr1 = F1113_7653(Current, loc7);
			loc7 = (EIF_REFERENCE) tr1;
			F1082_7273(RTCW(loc12), loc7);
		}
		loc2++;
	}
	RTLE;
}

/* {PR_FSM}.build_derives */
void F1113_7652 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc7);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr2);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		loc3 = F1082_7260(RTCW(loc2), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
		tb1 = F1030_6885(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			tr1 = F1082_7261(RTCW(tr1));
			loc7 = tr1;
			loc7 = RTRV(eif_new_type(139, 0x01),loc7);
			if (EIF_TEST(loc7)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
				F1077_7158(RTCW(tr1), loc7);
			}
		}
		loc1--;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		loc5 = F1082_7260(RTCW(loc4), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_2_);
		F1077_7170(RTCW(tr1), tr2);
		loc1--;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,19,0xFF01,146,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc6 = RTLNS(typres0.id, 19, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	F20_268(RTCW(loc6), loc4);
	RTLE;
}

/* {PR_FSM}.new_state */
EIF_REFERENCE F1113_7653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	F926_6160(RTCW(arg1));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_6_2_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1097_7509(RTCW(tr1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1086_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = F1086_7336(RTCW(tr1));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) || (EIF_BOOLEAN) (loc1 > loc2))) break;
			loc5 = F1082_7260(RTCW(loc4), loc1);
			tb1 = F926_6150(RTCW(loc5), arg1);
			if ((EIF_BOOLEAN) !tb1) {
				loc5 = (EIF_REFERENCE) NULL;
				loc1++;
			}
		}
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,925,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc4 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1082_7254(RTCW(loc4), ((EIF_INTEGER_32) 2L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1097_7515(RTCW(tr1), loc4, loc3);
	}
	if ((EIF_BOOLEAN)(loc5 == NULL)) {
		Result = (EIF_REFERENCE) arg1;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		F926_6155(RTCW(Result), ti4_1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1082_7273(RTCW(tr1), arg1);
		F1082_7278(RTCW(loc4), arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) loc5;
	}
	RTLE;
	return Result;
}

/* {PR_FSM}.build_deterministic */
void F1113_7655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(23);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,loc14);
	RTLR(5,loc9);
	RTLR(6,loc15);
	RTLR(7,loc19);
	RTLR(8,loc16);
	RTLR(9,loc13);
	RTLR(10,loc7);
	RTLR(11,loc10);
	RTLR(12,loc17);
	RTLR(13,loc20);
	RTLR(14,loc21);
	RTLR(15,tr2);
	RTLR(16,loc22);
	RTLR(17,loc11);
	RTLR(18,loc18);
	RTLR(19,loc12);
	RTLR(20,loc23);
	RTLR(21,loc8);
	RTLR(22,loc5);
	RTLIU(23);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1076,0xFF01,145,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTLNS(typres0.id, 1076, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1077_7131(RTCW(loc4));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1076,0xFF01,136,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc6 = RTLNS(typres0.id, 1076, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1077_7131(RTCW(loc6));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc14 = F1082_7260(RTCW(tr1), loc1);
		F926_6151(RTCW(loc14));
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc14)+ _CHROFF_6_0_);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc14) + _REFACS_3_);
			F1077_7170(RTCW(loc4), tr1);
		}
		loc9 = *(EIF_REFERENCE *)(RTCW(loc14) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
			loc15 = F1082_7260(RTCW(loc9), loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc15));
			loc19 = tr1;
			loc19 = RTRV(eif_new_type(139, 0x01),loc19);
			if (EIF_TEST(loc19)) {
				loc16 = RTLNS(eif_new_type(136, 0x01).id, 136, _OBJSIZ_4_0_0_1_0_0_0_0_);
				F137_1528(RTCW(loc16), loc14, loc15);
				F140_1559(loc19, loc16);
				F1077_7158(RTCW(loc6), loc16);
			}
			loc2--;
		}
		loc1--;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1080,0xFF01,925,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc13 = RTLNS(typres0.id, 1080, _OBJSIZ_3_0_0_2_0_0_0_0_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = F1115_7688(RTCW(tr1));
	F1081_7222(RTCW(loc13), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	loc7 = F1077_7140(RTCW(loc6));
	F979_6782(RTCW(loc7));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2618[Dtype(RTCW(loc7))-381])(loc7);
		if (tb1) break;
		loc16 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2617[Dtype(RTCW(loc7))-381])(loc7);
		loc10 = *(EIF_REFERENCE *)(RTCW(loc16) + _REFACS_3_);
		loc14 = *(EIF_REFERENCE *)(RTCW(loc16) + _REFACS_1_);
		loc9 = *(EIF_REFERENCE *)(RTCW(loc14) + _REFACS_2_);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
			tr1 = F1082_7260(RTCW(loc9), loc1);
			loc17 = *(EIF_REFERENCE *)(RTCW(tr1));
			loc20 = loc17;
			loc20 = RTRV(eif_new_type(140, 0x01),loc20);
			if (EIF_TEST(loc20)) {
				tb2 = F1077_7143(RTCW(loc10), loc20);
				if ((EIF_BOOLEAN) !tb2) {
					F1077_7158(RTCW(loc10), loc20);
				}
			} else {
				loc21 = loc17;
				loc21 = RTRV(eif_new_type(139, 0x01),loc21);
				if (EIF_TEST(loc21)) {
					tb2 = *(EIF_BOOLEAN *)(loc21+ _CHROFF_6_1_);
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc16) + _REFACS_2_);
						tr2 = F140_1556(loc21, loc14);
						F1077_7158(RTCW(tr1), tr2);
					}
				}
			}
			loc1--;
		}
		RTCT0("transition_variable", EX_CHECK);
		tr1 = F137_1531(RTCW(loc16));
		loc22 = tr1;
		loc22 = RTRV(eif_new_type(139, 0x01),loc22);
		if (EIF_TEST(loc22)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc11 = *(EIF_REFERENCE *)(loc22 + _REFACS_2_);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
			loc14 = *(EIF_REFERENCE *)(RTCW(loc16));
			F1081_7242(RTCW(loc13));
			F1081_7234(RTCW(loc13), loc14);
			loc18 = F1082_7260(RTCW(loc11), loc1);
			loc12 = *(EIF_REFERENCE *)(RTCW(loc18) + _REFACS_1_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_4_0_0_1_);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > loc3)) break;
				tr1 = F1082_7260(RTCW(loc12), loc2);
				tr1 = F926_6144(RTCW(loc14), tr1);
				loc14 = (EIF_REFERENCE) tr1;
				F1081_7234(RTCW(loc13), loc14);
				loc2++;
			}
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc14)+ _CHROFF_6_0_);
			if (tb2) {
				F926_6153(RTCW(loc14), loc16, loc18);
			}
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_4_0_0_1_);
			F1081_7239(RTCW(loc13));
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
				tr1 = F1082_7260(RTCW(loc12), loc2);
				loc23 = tr1;
				loc23 = RTRV(eif_new_type(139, 0x01),loc23);
				if (EIF_TEST(loc23)) {
					loc14 = F1081_7227(RTCW(loc13));
					F1081_7239(RTCW(loc13));
					tr1 = F140_1556(loc23, loc14);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
					F1077_7158(RTCW(tr1), loc16);
					tb2 = *(EIF_BOOLEAN *)(loc23+ _CHROFF_6_1_);
					if ((EIF_BOOLEAN) !tb2) {
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					} else {
						loc2--;
					}
				} else {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
			}
			loc1--;
		}
		F979_6783(RTCW(loc7));
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,19,0xFF01,140,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc8 = RTLNS(typres0.id, 19, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	F20_268(RTCW(loc8), loc6);
	loc5 = F1077_7140(RTCW(loc4));
	F979_6782(RTCW(loc5));
	for (;;) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2618[Dtype(RTCW(loc5))-381])(loc5);
		if (tb2) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2617[Dtype(RTCW(loc5))-381])(loc5);
		F146_1621(RTCW(tr1));
		F979_6783(RTCW(loc5));
	}
	RTLE;
}

/* {PR_FSM}.no_type */
static EIF_REFERENCE F1113_7658_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7658);
#define Result RTOSR(7658)
	RTOC_NEW(Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tb1 = F1030_6885(RTCW(tr1));
	if (tb1) {
		tr1 = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		tr2 = RTMS_EX_H("ANY",3,4279897);
		F902_5889(RTCW(tr1), ((EIF_INTEGER_32) 0L), NULL, tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		Result = F1082_7261(RTCW(tr1));
	}
	RTOSE (7658);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1113_7658 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7658,F1113_7658_body,(Current));
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
