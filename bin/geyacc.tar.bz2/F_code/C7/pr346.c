/*
 * Code for class PR_STRING_TOKEN_DEFINED_TWICE_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr346.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_STRING_TOKEN_DEFINED_TWICE_ERROR}.make */
void F1141_8338 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLR(6,arg5);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8313,F1132_8313, (Current));
	F682_3619(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = eif_out__i4_s1(arg2);
	F682_3643(RTCW(tr1), tr2, ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg3, ((EIF_INTEGER_32) 3L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg4, ((EIF_INTEGER_32) 4L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg5, ((EIF_INTEGER_32) 5L));
	RTLE;
}

/* {PR_STRING_TOKEN_DEFINED_TWICE_ERROR}.default_template */

EIF_REFERENCE F1141_8339 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (8339,RTMS_EX_H("\"$1\", line $2: literal string $3 defined twice with $4 and $5",61,1059422773));
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
