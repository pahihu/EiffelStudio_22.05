
#ifndef _C7_kl306_
#define _C7_kl306_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 6718)


extern EIF_REFERENCE F961_6718(EIF_REFERENCE);
extern void F961_6719(EIF_REFERENCE);
extern void EIF_Minit306(void);
extern void F642_3250(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
