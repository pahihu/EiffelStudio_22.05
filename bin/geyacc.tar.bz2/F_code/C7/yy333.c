/*
 * Code for class YY_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy333.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_PARSER_SKELETON}.make */
void F1128_8047 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2554,F248_2554, (Current));
	tr1 = F22_270(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	F1130_8214(Current);
	F1130_8213(Current);
	RTLE;
}

/* {YY_PARSER_SKELETON}.parse */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1128_8048 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_3;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) == ((EIF_INTEGER_32) 105L))) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_27_);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_28_);
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_29_);
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_30_);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_31_);
		loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_32_);
		loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_33_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 3L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc3 = (EIF_INTEGER_32) ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_)));
			/* END INLINED CODE */
			loc6 = ti4_3;
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 64L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
			/* END INLINED CODE */
			loc2 = ti4_2;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 1123L)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				loc2 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
				/* END INLINED CODE */
				loc2 = ti4_2;
			}
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_37_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_61_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F1130_8215(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) != ((EIF_INTEGER_32) 104L))) break;
		switch (loc7) {
			case 1L:
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_) >= loc1)) {
					loc1 += ((EIF_INTEGER_32) 200L);
					tr1 = RTOSCF(2554,F248_2554, (Current));
					tr1 = F22_278(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(2554,F248_2554, (Current));
				F22_275(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				} else {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_61_4_)) {
						F947_6475(Current);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_61_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_) > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_) <= ((EIF_INTEGER_32) 303L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_)));
							/* END INLINED CODE */
							loc4 = ti4_3;
						} else {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
						}
						loc3 += loc4;
					} else {
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_) == ((EIF_INTEGER_32) 0L))) {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_37_))++;
							F1130_8222(Current, loc2);
							F1128_8053(Current);
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						}
					}
					tb1 = '\01';
					if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1123L)))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != loc4);
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 216L))) {
									F1128_8052(Current);
								} else {
									if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_) > ((EIF_INTEGER_32) 0L))) {
										*(EIF_BOOLEAN *)(Current+ _CHROFF_61_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									F1130_8217(Current, loc4);
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_) != ((EIF_INTEGER_32) 0L))) {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_))--;
									}
									loc2 = (EIF_INTEGER_32) loc3;
								}
							}
						}
					}
				}
				break;
			case 2L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				} else {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				}
				break;
			case 3L:
				F1130_8221(Current, loc3);
				switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_)) {
					case 104L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_)));
						/* END INLINED CODE */
						loc6 = ti4_3;
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 64L));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
						/* END INLINED CODE */
						loc2 = ti4_2;
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
						tb1 = '\0';
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 1123L)))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							loc2 = (EIF_INTEGER_32) ti4_1;
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
							/* END INLINED CODE */
							loc2 = ti4_2;
						}
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						break;
					case 105L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_27_) = (EIF_INTEGER_32) loc1;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_28_) = (EIF_INTEGER_32) loc2;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_29_) = (EIF_INTEGER_32) loc3;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_30_) = (EIF_INTEGER_32) loc4;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_31_) = (EIF_INTEGER_32) loc5;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_32_) = (EIF_INTEGER_32) loc6;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_33_) = (EIF_INTEGER_32) loc7;
						break;
					case 103L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						break;
				}
				break;
			case 4L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_) == ((EIF_INTEGER_32) 3L))) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_2_) <= ((EIF_INTEGER_32) 0L))) {
						F1128_8053(Current);
					} else {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_61_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
					}
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_) == ((EIF_INTEGER_32) 0L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_37_))++;
						F1130_8222(Current, loc2);
					}
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_35_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			case 5L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				} else {
					loc3 += ((EIF_INTEGER_32) 1L);
					tb1 = '\01';
					if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1123L)))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 216L))) {
									F1128_8052(Current);
								} else {
									F1130_8218(Current);
									loc2 = (EIF_INTEGER_32) loc3;
									loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
					}
				}
				break;
			case 6L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_) == ((EIF_INTEGER_32) 0L))) {
					F1128_8053(Current);
				} else {
					F1130_8219(Current, loc2);
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_))--;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
					/* INLINED CODE (SPECIAL.item) */
					ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_34_)));
					/* END INLINED CODE */
					loc2 = ti4_3;
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) != ((EIF_INTEGER_32) 105L))) {
		F1128_8098(Current);
	}
	RTE_E
	RTXSC;
	F1128_8053(Current);
	F1128_8098(Current);
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {YY_PARSER_SKELETON}.error_count */
EIF_INTEGER_32 F1128_8051 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_37_);
}


/* {YY_PARSER_SKELETON}.accept */
void F1128_8052 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
}

/* {YY_PARSER_SKELETON}.abort */
void F1128_8053 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_36_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
}

/* {YY_PARSER_SKELETON}.clear_all */
void F1128_8054 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1128_8055(Current);
}

/* {YY_PARSER_SKELETON}.clear_stacks */
void F1128_8055 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1130_8216(Current);
}

/* {YY_PARSER_SKELETON}.report_eof_expected_error */
void F1128_8060 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTMS_EX_H("parse error",11,283683698);
	F1129_8179(Current, tr1);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yyfixed_array */
EIF_REFERENCE F1128_8091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(2554,F248_2554, (Current));
	Result = F22_273(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {YY_PARSER_SKELETON}.yyarray_subcopy */
void F1128_8092 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(3775,F750_3775, (Current));
	F918_6013(RTCW(tr1), arg1, arg2, arg3, arg4, arg5);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yy_clear_all */
void F1128_8098 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1128_8054(Current);
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
