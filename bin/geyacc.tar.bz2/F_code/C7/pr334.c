/*
 * Code for class PR_YACC_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr334.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_YACC_PARSER_SKELETON}.make */
void F1129_8122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1126_7960(Current, arg1);
	F1128_8047(Current);
	tr1 = RTLNSMART(eif_new_type(12, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1114, 1).id);
	F1115_7681(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1104,0xFF01,140,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1095_7490(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1104,0xFF01,139,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1095_7490(RTCW(tr1), ((EIF_INTEGER_32) 300L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1095_7490(RTCW(tr1), ((EIF_INTEGER_32) 300L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1095_7490(RTCW(tr1), ((EIF_INTEGER_32) 300L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.parse_file */
void F1129_8124 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F945_6374(Current, arg1);
	F946_6426(Current, loc1);
	F1128_8048(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	tb1 = F159_1839(RTCW(loc1));
	F1115_7695(RTCW(tr1), tb1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.new_rule */
EIF_REFERENCE F1129_8129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	Result = RTLNS(eif_new_type(146, 0x01).id, 146, _OBJSIZ_4_1_0_4_0_0_0_0_);
	tr1 = RTOSCF(8210,F1129_8210, (Current));
	F147_1623(RTCW(Result), loc1, arg1, tr1);
	F140_1558(RTCW(arg1), Result);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_terminal */
EIF_REFERENCE F1129_8130 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if (F1129_8178(Current, arg1)) {
		F1129_8196(Current, arg1);
		tr1 = F887_5426(RTMS_EX_H("\'a\'",3,2580775));
		Result = F1129_8140(Current, tr1);
	} else {
		Result = F1129_8139(Current, arg1);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result)+ _CHROFF_3_1_);
	if (tb1) {
		F1129_8193(Current, arg1);
	} else {
		F141_1582(RTCW(Result));
	}
	F139_1545(RTCW(Result), arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_char_terminal */
EIF_REFERENCE F1129_8131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	Result = F1129_8140(Current, arg1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result)+ _CHROFF_3_1_);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(924, 0x01).id, 924, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = F925_6106(RTCW(tr1), arg1);
		F1129_8193(Current, tr2);
	} else {
		F141_1582(RTCW(Result));
	}
	F139_1545(RTCW(Result), arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_left_terminal */
EIF_REFERENCE F1129_8132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F1129_8178(Current, arg1)) {
		F1129_8196(Current, arg1);
		tr1 = F887_5426(RTMS_EX_H("\'a\'",3,2580775));
		Result = F1129_8140(Current, tr1);
	} else {
		Result = F1129_8139(Current, arg1);
	}
	F141_1579(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_left_char_terminal */
EIF_REFERENCE F1129_8133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = F1129_8140(Current, arg1);
	F141_1579(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_right_terminal */
EIF_REFERENCE F1129_8134 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F1129_8178(Current, arg1)) {
		F1129_8196(Current, arg1);
		tr1 = F887_5426(RTMS_EX_H("\'a\'",3,2580775));
		Result = F1129_8140(Current, tr1);
	} else {
		Result = F1129_8139(Current, arg1);
	}
	F141_1580(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_right_char_terminal */
EIF_REFERENCE F1129_8135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = F1129_8140(Current, arg1);
	F141_1580(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_nonassoc_terminal */
EIF_REFERENCE F1129_8136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F1129_8178(Current, arg1)) {
		F1129_8196(Current, arg1);
		tr1 = F887_5426(RTMS_EX_H("\'a\'",3,2580775));
		Result = F1129_8140(Current, tr1);
	} else {
		Result = F1129_8139(Current, arg1);
	}
	F141_1581(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_nonassoc_char_terminal */
EIF_REFERENCE F1129_8137 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = F1129_8140(Current, arg1);
	F141_1581(RTCW(Result));
	F1129_8161(Current, Result, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_nonterminal */
EIF_REFERENCE F1129_8138 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	if (F1129_8177(Current, arg1)) {
		F1129_8195(Current, arg1);
		Result = F1129_8143(Current);
	} else {
		if (F1129_8178(Current, arg1)) {
			F1129_8194(Current, arg1);
			Result = F1129_8143(Current);
		} else {
			Result = F1129_8142(Current, arg1);
		}
	}
	F139_1545(RTCW(Result), arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_token */
EIF_REFERENCE F1129_8139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(140, 0x01).id, 140, _OBJSIZ_3_2_0_4_0_0_0_0_);
		tr1 = F1129_8212(Current);
		F139_1538(RTCW(Result), loc2, arg1, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		F1095_7519(RTCW(tr1), Result, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		F1115_7696(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_char_token */
EIF_REFERENCE F1129_8140 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
		tw1 = F892_5579(RTCW(arg1), ((EIF_INTEGER_32) 2L));
		loc1 = (EIF_INTEGER_32) (tw1);
	} else {
		loc3 = F892_5579(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		switch (loc3) {
			case (EIF_CHARACTER_8) 'b':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
				break;
			case (EIF_CHARACTER_8) 'f':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
				break;
			case (EIF_CHARACTER_8) 'n':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
				break;
			case (EIF_CHARACTER_8) 'r':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
				break;
			case (EIF_CHARACTER_8) 't':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
				break;
			case (EIF_CHARACTER_8) 'a':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
				break;
			case (EIF_CHARACTER_8) 'v':
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
				break;
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
				loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc4 > loc5)) break;
					tw1 = F892_5579(RTCW(arg1), loc4);
					ti4_1 = (EIF_INTEGER_32) (tw1);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 8L)) + ti4_1) - ((EIF_INTEGER_32) 48L));
					loc4++;
				}
				break;
			case (EIF_CHARACTER_8) 'U':
			case (EIF_CHARACTER_8) 'X':
			case (EIF_CHARACTER_8) 'u':
			case (EIF_CHARACTER_8) 'x':
				loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 3L))) {
					loc1 = (EIF_INTEGER_32) (loc3);
				} else {
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
					tw1 = F892_5579(RTCW(arg1), loc4);
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
					if ((EIF_BOOLEAN)(tw1 == tw2)) {
						loc4++;
						loc5--;
					}
					for (;;) {
						if ((EIF_BOOLEAN) (loc4 > loc5)) break;
						loc1 *= ((EIF_INTEGER_32) 16L);
						loc3 = F892_5579(RTCW(arg1), loc4);
						switch (loc3) {
							case (EIF_CHARACTER_8) '0':
							case (EIF_CHARACTER_8) '1':
							case (EIF_CHARACTER_8) '2':
							case (EIF_CHARACTER_8) '3':
							case (EIF_CHARACTER_8) '4':
							case (EIF_CHARACTER_8) '5':
							case (EIF_CHARACTER_8) '6':
							case (EIF_CHARACTER_8) '7':
							case (EIF_CHARACTER_8) '8':
							case (EIF_CHARACTER_8) '9':
								ti4_1 = (EIF_INTEGER_32) (loc3);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) - ((EIF_INTEGER_32) 48L));
								break;
							case (EIF_CHARACTER_8) 'a':
							case (EIF_CHARACTER_8) 'b':
							case (EIF_CHARACTER_8) 'c':
							case (EIF_CHARACTER_8) 'd':
							case (EIF_CHARACTER_8) 'e':
							case (EIF_CHARACTER_8) 'f':
								ti4_1 = (EIF_INTEGER_32) (loc3);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) - ((EIF_INTEGER_32) 97L)) + ((EIF_INTEGER_32) 10L));
								break;
							case (EIF_CHARACTER_8) 'A':
							case (EIF_CHARACTER_8) 'B':
							case (EIF_CHARACTER_8) 'C':
							case (EIF_CHARACTER_8) 'D':
							case (EIF_CHARACTER_8) 'E':
							case (EIF_CHARACTER_8) 'F':
								ti4_1 = (EIF_INTEGER_32) (loc3);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) - ((EIF_INTEGER_32) 65L)) + ((EIF_INTEGER_32) 10L));
								break;
							default:
								RTEC(EN_WHEN);
						}
						loc4++;
					}
				}
				break;
			default:
				loc1 = (EIF_INTEGER_32) (loc3);
				break;
		}
	}
	tr1 = RTLNS(eif_new_type(1122, 0x01).id, 1122, _OBJSIZ_0_0_0_0_0_0_0_0_);
	if ((EIF_BOOLEAN) !F1123_7901(RTCW(tr1), loc1)) {
		tr1 = RTLNS(eif_new_type(924, 0x01).id, 924, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = F925_6106(RTCW(tr1), arg1);
		F1129_8203(Current, tr2);
	}
	loc2 = eif_out__i4_s1(loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	F1095_7509(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(140, 0x01).id, 140, _OBJSIZ_3_2_0_4_0_0_0_0_);
		tr1 = F887_5420(RTCW(arg1));
		tr2 = F1129_8212(Current);
		F139_1538(RTCW(Result), loc6, tr1, tr2);
		F141_1576(RTCW(Result), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		F1095_7519(RTCW(tr1), Result, loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		F1115_7696(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_string_token */
EIF_REFERENCE F1129_8141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	F1095_7509(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		F1129_8199(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(140, 0x01).id, 140, _OBJSIZ_3_2_0_4_0_0_0_0_);
		tr1 = F1129_8212(Current);
		F139_1538(RTCW(Result), loc1, arg1, tr1);
		F141_1578(RTCW(Result), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		F1095_7519(RTCW(tr1), Result, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		F1115_7696(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_variable */
EIF_REFERENCE F1129_8142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		Result = RTLNS(eif_new_type(139, 0x01).id, 139, _OBJSIZ_6_2_0_2_0_0_0_0_);
		tr1 = F1129_8212(Current);
		F140_1548(RTCW(Result), loc2, arg1, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		F1095_7519(RTCW(tr1), Result, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		F1115_7697(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_midrule_variable */
EIF_REFERENCE F1129_8143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F893_5664(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, (EIF_CHARACTER_8) '@');
	tr1 = RTOSCF(4027,F774_4027, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_11_0_0_8_);
	F923_6022(RTCW(tr1), ti4_1, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	Result = RTLNS(eif_new_type(139, 0x01).id, 139, _OBJSIZ_6_2_0_2_0_0_0_0_);
	tr1 = F1129_8212(Current);
	F140_1548(RTCW(Result), loc2, loc1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	F1095_7518(RTCW(tr1), Result, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	F1115_7697(RTCW(tr1), Result);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_symbol */
EIF_REFERENCE F1129_8144 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		tb1 = F1095_7506(RTCW(tr1), loc1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			Result = F1095_7498(RTCW(tr1), loc1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc2 = RTLNS(eif_new_type(139, 0x01).id, 139, _OBJSIZ_6_2_0_2_0_0_0_0_);
			tr1 = F1129_8212(Current);
			F140_1548(RTCW(loc2), loc3, arg1, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
			F1095_7519(RTCW(tr1), loc2, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7697(RTCW(tr1), loc2);
			RTLE;
			return (EIF_REFERENCE) loc2;
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_type */
EIF_REFERENCE F1129_8145 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		F893_5664(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg1))-894])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, (EIF_CHARACTER_8) ' ');
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg2))-894])(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg2))-894])(arg2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5889(RTCW(Result), loc2, arg1, arg2);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			F1095_7519(RTCW(tr1), Result, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7698(RTCW(tr1), Result);
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_basic_type */
EIF_REFERENCE F1129_8146 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		F893_5664(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg1))-894])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, (EIF_CHARACTER_8) ' ');
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg2))-894])(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(arg2))-894])(arg2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(902, 0x01).id, 902, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5889(RTCW(Result), loc2, arg1, arg2);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			F1095_7519(RTCW(tr1), Result, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7698(RTCW(tr1), Result);
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_generic_type */
EIF_REFERENCE F1129_8147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,Result);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5890(RTCW(Result), loc2, arg1, arg2, arg3);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(tr1))-894])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		F1095_7509(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		tb1 = F1084_7344(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			Result = F1084_7336(RTCW(tr1));
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
				F1095_7519(RTCW(tr1), Result, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F1115_7698(RTCW(tr1), Result);
			}
		}
	} else {
		Result = F1129_8145(Current, arg1, arg2);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_labeled_tuple_type */
EIF_REFERENCE F1129_8148 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,Result);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5891(RTCW(Result), loc2, arg1, arg2, arg3);
		tr1 = *(EIF_REFERENCE *)(RTCW(Result));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4229[Dtype(RTCW(tr1))-894])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		F1095_7509(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		tb1 = F1084_7344(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			Result = F1084_7336(RTCW(tr1));
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
				F1095_7519(RTCW(tr1), Result, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F1115_7698(RTCW(tr1), Result);
			}
		}
	} else {
		Result = F1129_8145(Current, arg1, arg2);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_anchored_type */
EIF_REFERENCE F1129_8149 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		F893_5664(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, (EIF_CHARACTER_8) ' ');
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg2))-894])(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg2))-894])(arg2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5892(RTCW(Result), loc2, arg1, arg2);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			F1095_7519(RTCW(tr1), Result, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7698(RTCW(tr1), Result);
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_like_current_type */
EIF_REFERENCE F1129_8150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		F893_5664(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 13L)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4433[Dtype(RTCW(loc1))-894])(loc1, (EIF_CHARACTER_8) ' ');
		tr1 = RTOSCF(8209,F1129_8209, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(loc1))-894])(loc1, tr1);
	} else {
		loc1 = RTOSCF(8209,F1129_8209, (Current));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F902_5893(RTCW(Result), loc2, arg1);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			F1095_7519(RTCW(tr1), Result, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7698(RTCW(tr1), Result);
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_qualified_anchored_type */
EIF_REFERENCE F1129_8151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
	Result = RTLNS(eif_new_type(901, 0x01).id, 901, _OBJSIZ_2_0_0_1_0_0_0_0_);
	F902_5894(RTCW(Result), loc2, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result));
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(tr1))-894])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1095_7509(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	tb1 = F1084_7344(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
		Result = F1084_7336(RTCW(tr1));
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_39_) == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			F1095_7519(RTCW(tr1), Result, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7698(RTCW(tr1), Result);
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_labeled_type */
EIF_REFERENCE F1129_8152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1081,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1081, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1082_7254(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	F1082_7272(RTCW(loc1), arg1);
	tr1 = RTLNS(eif_new_type(26, 0x01).id, 26, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F27_280(RTCW(tr1), loc1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {PR_YACC_PARSER_SKELETON}.new_action */
EIF_REFERENCE F1129_8153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
	Result = F13_122(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.new_error_action */
EIF_REFERENCE F1129_8154 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(942, 0x01).id, 942, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
	tr1 = F13_122(RTCW(tr1), arg1);
	F943_6306(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.initialize_grammar */
void F1129_8155 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTMS_EX_H("detachable",10,1071588197);
	tr2 = RTMS_EX_H("ANY",3,4279897);
	loc2 = F1129_8145(Current, tr1, tr2);
	tr1 = RTMS_EX_H("error",5,1920877938);
	loc1 = F1129_8139(Current, tr1);
	F139_1544(RTCW(loc1), (EIF_BOOLEAN) 1);
	tr1 = RTMS_EX_H("$undefined.",11,931393582);
	loc1 = F1129_8139(Current, tr1);
	F139_1544(RTCW(loc1), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.put_rule */
void F1129_8156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	F1115_7699(RTCW(tr1), arg1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.put_symbol */
void F1129_8157 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
	if ((EIF_BOOLEAN)(tr1 != RTOSCF(8210,F1129_8210, (Current)))) {
		loc2 = F1129_8143(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		F139_1545(RTCW(loc2), tr1);
		loc1 = F1129_8129(Current, loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		F147_1631(RTCW(loc1), tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_1_0_2_);
		F147_1634(RTCW(loc1), ti4_1);
		F1129_8156(Current, loc1);
		F147_1636(RTCW(arg2), loc2);
		tr1 = RTOSCF(8210,F1129_8210, (Current));
		F147_1631(RTCW(arg2), tr1);
	}
	F147_1636(RTCW(arg2), arg1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.put_action */
void F1129_8158 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
	if ((EIF_BOOLEAN)(tr1 != RTOSCF(8210,F1129_8210, (Current)))) {
		loc2 = F1129_8143(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		F139_1545(RTCW(loc2), tr1);
		loc1 = F1129_8129(Current, loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		F147_1631(RTCW(loc1), tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_1_0_2_);
		F147_1634(RTCW(loc1), ti4_1);
		F1129_8156(Current, loc1);
		F147_1636(RTCW(arg2), loc2);
	}
	F147_1631(RTCW(arg2), arg1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.put_error_action */
void F1129_8159 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	F147_1632(RTCW(arg3), arg1, arg2);
}

/* {PR_YACC_PARSER_SKELETON}.set_start_symbol */
void F1129_8160 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = *(EIF_REFERENCE *)(loc3);
		if (F1129_8177(Current, loc2)) {
			F1129_8185(Current);
		} else {
			if ((EIF_BOOLEAN) !F1129_8178(Current, loc2)) {
				F1129_8186(Current);
			} else {
				loc1 = F1129_8142(Current, loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F1115_7692(RTCW(tr1), loc1);
			}
		}
		*(EIF_REFERENCE *)(Current + _REFACS_36_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tb1 = F1030_6885(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			tr1 = F1082_7261(RTCW(tr1));
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
			F1115_7692(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.set_precedence */
void F1129_8161 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = F141_1571(RTCW(arg1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1129_8189(Current, tr1);
	}
	F141_1577(RTCW(arg1), arg2);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.set_alias_name */
void F1129_8162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTOSCF(5830,F897_5830, (Current));
		tb1 = F924_6052(RTCW(tr1), loc1, arg2);
		if ((EIF_BOOLEAN) !tb1) {
			tb1 = F586_3153(RTCW(loc1));
			if (tb1) {
				F1129_8182(Current, arg1, arg2);
			} else {
				F1129_8181(Current, arg1, loc1, arg2);
			}
		}
	} else {
		F902_5900(RTCW(arg1), arg2);
		loc3 = F1129_8211(Current);
		loc2 = F902_5897(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
		F1095_7509(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
		tb1 = F1084_7344(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
			tr1 = F1084_7336(RTCW(tr1));
			F1129_8184(Current, loc2, tr1, arg1);
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 != loc3)) {
				tr1 = F902_5897(RTCW(loc3));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4390[Dtype(RTCW(tr1))-893])(tr1, loc2);
				tb1 = tb2;
			}
			if (tb1) {
				F1129_8184(Current, loc2, loc3, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
				F1095_7521(RTCW(tr1), arg1, loc2);
			}
		}
	}
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.set_no_alias_name */
void F1129_8163 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = F586_3153(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			F1129_8183(Current, arg1, loc1);
		}
	} else {
		tr1 = RTMS_EX_H("",0,0);
		F902_5900(RTCW(arg1), tr1);
		loc3 = F1129_8211(Current);
		loc2 = F902_5897(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
		F1095_7509(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
		tb1 = F1084_7344(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
			tr1 = F1084_7336(RTCW(tr1));
			F1129_8184(Current, loc2, tr1, arg1);
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 != loc3)) {
				tr1 = F902_5897(RTCW(loc3));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4390[Dtype(RTCW(tr1))-893])(tr1, loc2);
				tb1 = tb2;
			}
			if (tb1) {
				F1129_8184(Current, loc2, loc3, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
				F1095_7521(RTCW(tr1), arg1, loc2);
			}
		}
	}
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.set_token_id */
void F1129_8164 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	tb2 = F141_1572(RTCW(arg1));
	if (tb2) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
		tb1 = (EIF_BOOLEAN)(ti4_1 != arg2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
		F1129_8202(Current, tr1, ti4_1, arg2);
	}
	F141_1576(RTCW(arg1), arg2);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.set_literal_string */
void F1129_8165 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(loc1)-5])(loc1, arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1129_8201(Current, tr1, loc1, arg2);
	} else {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		tb2 = F1095_7506(RTCW(tr1), arg2);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			tr1 = F1095_7498(RTCW(tr1), arg2);
			tb1 = (EIF_BOOLEAN)(tr1 != arg1);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			tr1 = F1095_7498(RTCW(tr1), arg2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1129_8200(Current, arg2, tr1, tr2);
		}
	}
	F141_1578(RTCW(arg1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	F1095_7518(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.process_rule */
void F1129_8166 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = (EIF_REFERENCE) loc4;
		F139_1544(loc4, (EIF_BOOLEAN) 1);
	} else {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(loc2 != NULL))) break;
			tr1 = F1082_7260(RTCW(loc1), loc3);
			loc5 = tr1;
			loc5 = RTRV(eif_new_type(140, 0x01),loc5);
			if (EIF_TEST(loc5)) {
				loc2 = (EIF_REFERENCE) loc5;
			}
			loc3--;
		}
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb1 = F141_1567(RTCW(loc2));
		if (tb1) {
			F147_1642(RTCW(arg1));
		} else {
			tb1 = F141_1568(RTCW(loc2));
			if (tb1) {
				F147_1643(RTCW(arg1));
			} else {
				tb1 = F141_1569(RTCW(loc2));
				if (tb1) {
					F147_1644(RTCW(arg1));
				}
			}
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_2_0_2_);
		F147_1633(RTCW(arg1), ti4_1);
	}
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.process_symbols */
void F1129_8167 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc9);
	RTLR(4,loc5);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1093,814,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc9 = RTLNS(typres0.id, 1093, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1087_7335(RTCW(loc9), loc3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc5 = F1082_7260(RTCW(loc4), loc2);
		tb1 = F141_1572(RTCW(loc5));
		if (tb1) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_2_0_1_);
			F1090_7437(RTCW(loc9), ti4_1);
		}
		loc2++;
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc5 = F1082_7260(RTCW(loc4), loc2);
		tb1 = F141_1572(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			loc1++;
			for (;;) {
				tb1 = F1090_7431(RTCW(loc9), loc1);
				if ((EIF_BOOLEAN) !tb1) break;
				loc1++;
			}
			F141_1576(RTCW(loc5), loc1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_2_0_1_);
		if ((EIF_BOOLEAN) (ti4_1 > loc8)) {
			loc8 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_2_0_1_);
		}
		loc2++;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,140,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc10 = RTLNS(typres0.id, 681, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F682_3619(RTCW(loc10), NULL, ((EIF_INTEGER_32) 0L), loc8);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc5 = F1082_7260(RTCW(loc4), loc2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_2_0_1_);
		tr1 = F682_3624(RTCW(loc10), ti4_1);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			F1129_8205(Current, loc11, loc5);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_2_0_1_);
			F682_3643(RTCW(loc10), loc5, ti4_1);
		}
		loc2++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc7 = F1082_7260(RTCW(loc6), loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_2_);
		tb2 = F1030_6885(RTCW(tr1));
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
			F1129_8198(Current, tr1);
		}
		loc2++;
	}
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.is_terminal */
EIF_BOOLEAN F1129_8177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	Result = F1095_7506(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.is_nonterminal */
EIF_BOOLEAN F1129_8178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4228[Dtype(RTCW(arg1))-894])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	Result = F1095_7506(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.report_error */
void F1129_8179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1163, 0x01).id, 1163, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1164_8407(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_invalid_unicode_character_error */
void F1129_8180 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\'\\u{",4,660370811);
	tr2 = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr2 = arg1;
	tr2 = F825_4806(RTCW(tr2));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4395[Dtype(tr1)-894])(tr1, tr2);
	tr2 = RTMS_EX_H("}\'",2,32039);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4395[Dtype(RTCW(tr1))-894])(tr1, tr2);
	F1129_8203(Current, tr1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_alias_name_defined_twice_error */
void F1129_8181 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1161, 0x01).id, 1161, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1162_8401(RTCW(loc1), tr1, ti4_1, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_alias_name_not_defined_error */
void F1129_8182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1160, 0x01).id, 1160, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1161_8398(RTCW(loc1), tr1, ti4_1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_alias_name_undefined_error */
void F1129_8183 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1141, 0x01).id, 1141, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1142_8341(RTCW(loc1), tr1, ti4_1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_last_value_name_used_twice_error */
void F1129_8184 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1157, 0x01).id, 1157, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1158_8389(RTCW(loc1), tr1, ti4_1, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_start_symbol_token_error */
void F1129_8185 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	RTCT0("start_symbol_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(loc4);
	loc3 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_0_0_0_);
	loc1 = RTLNS(eif_new_type(1159, 0x01).id, 1159, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	F1160_8395(RTCW(loc1), tr1, loc3, loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_unknown_start_symbol_error */
void F1129_8186 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	RTCT0("start_symbol_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_REFERENCE *)(loc4);
	loc3 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_0_0_0_);
	loc1 = RTLNS(eif_new_type(1158, 0x01).id, 1158, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	F1159_8392(RTCW(loc1), tr1, loc3, loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_lhs_symbol_token_error */
void F1129_8187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1156, 0x01).id, 1156, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1157_8386(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_multiple_start_declarations_error */
void F1129_8188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1155, 0x01).id, 1155, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1156_8383(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_precedence_defined_twice_error */
void F1129_8189 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1154, 0x01).id, 1154, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1155_8380(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_prec_specified_twice_error */
void F1129_8190 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1153, 0x01).id, 1153, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1154_8377(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_prec_not_token_error */
void F1129_8191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1152, 0x01).id, 1152, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1153_8374(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_invalid_error_n_error */
void F1129_8192 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1151, 0x01).id, 1151, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1152_8371(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_token_declared_twice_error */
void F1129_8193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1150, 0x01).id, 1150, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1151_8368(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_variable_declared_twice_error */
void F1129_8194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1149, 0x01).id, 1149, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1150_8365(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_variable_declared_as_token_error */
void F1129_8195 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1148, 0x01).id, 1148, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1149_8362(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_token_declared_as_variable_error */
void F1129_8196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1145, 0x01).id, 1145, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1146_8353(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_no_rules_error */
void F1129_8197 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1147, 0x01).id, 1147, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	F1148_8359(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_undefined_symbol_error */
void F1129_8198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1144, 0x01).id, 1144, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	F1145_8350(RTCW(loc1), tr1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_undefined_string_token_error */
void F1129_8199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1146, 0x01).id, 1146, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1147_8356(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_string_token_defined_twice_error */
void F1129_8200 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1140, 0x01).id, 1140, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1141_8338(RTCW(loc1), tr1, ti4_1, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_two_strings_token_error */
void F1129_8201 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1143, 0x01).id, 1143, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1144_8347(RTCW(loc1), tr1, ti4_1, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_two_token_ids_token_error */
void F1129_8202 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1162, 0x01).id, 1162, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1163_8404(RTCW(loc1), tr1, ti4_1, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_invalid_character_error */
void F1129_8203 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1139, 0x01).id, 1139, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1140_8335(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_rule_declared_twice_warning */
void F1129_8204 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1143_8344(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7662(RTCW(tr1), loc1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.report_token_id_used_twice_warning */
void F1129_8205 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,arg2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1138, 0x01).id, 1138, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
	F1139_8332(RTCW(loc1), tr1, tr2, tr3, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7662(RTCW(tr1), loc1);
	RTLE;
}

/* {PR_YACC_PARSER_SKELETON}.like_current_lower_name */

EIF_REFERENCE F1129_8209 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (8209,RTMS_EX_H("like current",12,1405247092));
}

/* {PR_YACC_PARSER_SKELETON}.no_action */
static EIF_REFERENCE F1129_8210_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (8210);
#define Result RTOSR(8210)
	RTOC_NEW(Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
	tr2 = RTMS_EX_H("",0,0);
	Result = F13_122(RTCW(tr1), tr2);
	RTOSE (8210);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1129_8210 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8210,F1129_8210_body,(Current));
}

/* {PR_YACC_PARSER_SKELETON}.no_type */
EIF_REFERENCE F1129_8211 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("detachable",10,1071588197);
	tr2 = RTMS_EX_H("ANY",3,4279897);
	Result = F1129_8145(Current, tr1, tr2);
	RTLE;
	return Result;
}

/* {PR_YACC_PARSER_SKELETON}.unknown_type */
EIF_REFERENCE F1129_8212 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("detachable",10,1071588197);
	tr2 = RTMS_EX_H("ANY",3,4279897);
	Result = F1129_8145(Current, tr1, tr2);
	RTLE;
	return Result;
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
