/*
 * Code for class PR_INVALID_DOLLAR_N_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr339.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_INVALID_DOLLAR_N_ERROR}.make */
void F1134_8317 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8313,F1132_8313, (Current));
	F682_3619(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = eif_out__i4_s1(arg2);
	F682_3643(RTCW(tr1), tr2, ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = eif_out__i4_s1(arg3);
	F682_3643(RTCW(tr1), tr2, ((EIF_INTEGER_32) 3L));
	RTLE;
}

/* {PR_INVALID_DOLLAR_N_ERROR}.default_template */

EIF_REFERENCE F1134_8318 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (8318,RTMS_EX_H("\"$1\", line $2: invalid use of $$$3 in semantic action",53,1757632878));
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
