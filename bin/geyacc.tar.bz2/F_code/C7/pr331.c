/*
 * Code for class PR_YACC_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_YACC_SCANNER_SKELETON}.make */
void F1126_7960 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6379,F945_6379, (Current));
	F946_6394(Current, tr1);
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS32_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(894, 1).id);
	F893_5664(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = RTOSCF(7971,F1126_7971, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.filename */
EIF_REFERENCE F1126_7965 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(156, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1316[Dtype(RTCW(tr1))-928])(tr1);
	} else {
		Result = RTMS_EX_H("string",6,2146502247);
	}
	RTLE;
	return Result;
}

/* {PR_YACC_SCANNER_SKELETON}.eiffel_more */
void F1126_7968 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F946_6407(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_24_) = (EIF_INTEGER_32) ti4_1;
	F946_6421(Current);
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.eiffel_no_verbatim_marker */

EIF_REFERENCE F1126_7971 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (7971,RTMS32_EX_H("",0,0));
}

/* {PR_YACC_SCANNER_SKELETON}.is_eiffel_verbatim_string_closer */
EIF_BOOLEAN F1126_7972 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc5 > loc4)) {
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - loc4);
		loc6 = F946_6402(Current, loc3);
		tb1 = '\0';
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
		if (!(EIF_BOOLEAN)(loc6 == tw1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			tb2 = (EIF_BOOLEAN)(loc6 == tw1);
		}
		if (tb2) {
			tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_61_5_0_1_);
			tw1 = (EIF_CHARACTER_32) (((EIF_NATURAL_32) tw1) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
			tb1 = (EIF_BOOLEAN)(loc6 == tw1);
		}
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc4)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				loc6 = F892_5579(RTCW(tr1), loc1);
				if ((EIF_BOOLEAN)(loc6 == F946_6402(Current, loc2))) {
					loc1++;
					loc2++;
				} else {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
				}
			}
			if (Result) {
				loc2 = (EIF_INTEGER_32) arg1;
				for (;;) {
					if ((EIF_BOOLEAN)(loc2 == loc3)) break;
					tw1 = F946_6402(Current, loc2);
					tu4_1 = (EIF_NATURAL_32) tw1;
					switch (tu4_1) {
						case 9U:
						case 10U:
						case 11U:
						case 12U:
						case 13U:
						case 32U:
						case 160U:
						case 5760U:
						case 8192U:
						case 8193U:
						case 8194U:
						case 8195U:
						case 8196U:
						case 8197U:
						case 8198U:
						case 8199U:
						case 8200U:
						case 8201U:
						case 8202U:
						case 8239U:
						case 8287U:
						case 12288U:
							loc2++;
							break;
						default:
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc2 = (EIF_INTEGER_32) loc3;
							break;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {PR_YACC_SCANNER_SKELETON}.process_dollar_n */
void F1126_7977 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (arg1 > arg2))) {
		F1126_7982(Current, arg1);
	} else {
		tr1 = F1082_7260(RTCW(loc1), arg1);
		loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		F902_5901(RTCW(loc2), arg1, arg2, arg3, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	}
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.process_dollar_dollar */
void F1126_7978 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	F902_5902(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_19_));
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.cloned_string */
EIF_REFERENCE F1126_7979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(894, 0x01).id, 894, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F893_5664(RTCW(Result), ti4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4431[Dtype(RTCW(Result))-894])(Result, arg1);
	RTLE;
	return Result;
}

/* {PR_YACC_SCANNER_SKELETON}.report_missing_characters_error */
void F1126_7980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1137, 0x01).id, 1137, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1138_8329(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.report_null_integer_error */
void F1126_7981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1134, 0x01).id, 1134, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1135_8320(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.report_invalid_dollar_n_error */
void F1126_7982 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1134_8317(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.report_invalid_dollar_dollar_error */
void F1126_7983 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1137_8326(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.report_integer_too_large_error */
void F1126_7984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1132, 0x01).id, 1132, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1133_8314(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {PR_YACC_SCANNER_SKELETON}.report_invalid_string_token_error */
void F1126_7985 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1126_7965(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_61_5_0_23_);
	F1136_8323(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1114_7661(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_61_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
