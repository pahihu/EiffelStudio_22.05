
#ifndef _C7_ut336_
#define _C7_ut336_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1131_8305(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit336(void);
extern void F935_6237(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F211_2101(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2101)
extern char *(*R3006[])();
extern char *(*R997[])();
extern char *(*R4528[])();
extern char *(*R4381[])();

#ifdef __cplusplus
}
#endif

#endif
