/*
 * Code for class PR_ALIAS_NAME_UNDEFINED_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr347.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_ALIAS_NAME_UNDEFINED_ERROR}.make */
void F1142_8341 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFF01,894,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8313,F1132_8313, (Current));
	F682_3619(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = eif_out__i4_s1(arg2);
	F682_3643(RTCW(tr1), tr2, ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg3));
	F682_3643(RTCW(tr1), tr2, ((EIF_INTEGER_32) 3L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F682_3643(RTCW(tr1), arg4, ((EIF_INTEGER_32) 4L));
	RTLE;
}

/* {PR_ALIAS_NAME_UNDEFINED_ERROR}.default_template */

EIF_REFERENCE F1142_8342 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (8342,RTMS_EX_H("\"$1\", line $2: alias name \'$4\' for type \'$3\' should be repeated in each %token declaration with that type",105,1081364581));
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
