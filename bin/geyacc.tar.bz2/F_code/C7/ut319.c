/*
 * Code for class UT_ERROR_HANDLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut319.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_ERROR_HANDLER}.make_standard */
void F1114_7659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(266,F19_266, (RTCV(RTOSCF(2372,F241_2372, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(266,F19_266, (RTCV(RTOSCF(2372,F241_2372, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(265,F19_265, (RTCV(RTOSCF(2372,F241_2372, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_error */
void F1114_7661 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1114_7680(Current, arg1);
	F1114_7664(Current, tr1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_warning */
void F1114_7662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1114_7680(Current, arg1);
	F1114_7665(Current, tr1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_info */
void F1114_7663 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1114_7680(Current, arg1);
	F1114_7666(Current, tr1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_error_message */
void F1114_7664 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F907_5932(RTCW(tr1), arg1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_warning_message */
void F1114_7665 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F907_5932(RTCW(tr1), arg1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.report_info_message */
void F1114_7666 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F907_5932(RTCW(tr1), arg1);
	RTLE;
}

/* {UT_ERROR_HANDLER}.message */
EIF_REFERENCE F1114_7680 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = F1132_8310(RTCW(arg1));
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit319 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
