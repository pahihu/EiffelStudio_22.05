
#ifndef _C21_fi1029_
#define _C21_fi1029_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F590_3153(EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern EIF_INTEGER_32 F692_3631(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
