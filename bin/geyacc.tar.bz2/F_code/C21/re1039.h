
#ifndef _C21_re1039_
#define _C21_re1039_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F616_3166(EIF_REFERENCE);
extern void EIF_Minit1039(void);
extern EIF_INTEGER_32 F692_3632(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
