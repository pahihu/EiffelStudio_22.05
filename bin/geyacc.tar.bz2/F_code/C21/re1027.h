
#ifndef _C21_re1027_
#define _C21_re1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F378_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F378_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F378_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F378_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F378_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F378_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F378_2982(EIF_REFERENCE);
extern void F378_2987(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
