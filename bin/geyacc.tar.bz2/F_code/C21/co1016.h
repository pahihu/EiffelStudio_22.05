
#ifndef _C21_co1016_
#define _C21_co1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F447_3055(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
