
#ifndef _C21_to1031_
#define _C21_to1031_

#ifdef __cplusplus
extern "C" {
#endif

extern void F239_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F239_2365(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern void F239_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern void F667_3531(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
