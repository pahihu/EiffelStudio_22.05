
#ifndef _C3_op118_
#define _C3_op118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F176_1919(EIF_REFERENCE);
extern void F176_1922(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
