
#ifndef _C3_ad138_
#define _C3_ad138_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F196_1980(EIF_REFERENCE);
extern void EIF_Minit138(void);

#ifdef __cplusplus
}
#endif

#endif
