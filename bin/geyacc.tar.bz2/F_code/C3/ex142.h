
#ifndef _C3_ex142_
#define _C3_ex142_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F200_1986(EIF_REFERENCE);
extern void EIF_Minit142(void);

#ifdef __cplusplus
}
#endif

#endif
