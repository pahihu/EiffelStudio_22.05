
#ifndef _C3_cr139_
#define _C3_cr139_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F197_1982(EIF_REFERENCE);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
