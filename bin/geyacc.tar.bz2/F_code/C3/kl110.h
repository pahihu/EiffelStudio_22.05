
#ifndef _C3_kl110_
#define _C3_kl110_

#ifdef __cplusplus
extern "C" {
#endif

extern void F168_1881(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit110(void);

#ifdef __cplusplus
}
#endif

#endif
