
#ifndef _C3_va146_
#define _C3_va146_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F204_1992(EIF_REFERENCE);
extern void EIF_Minit146(void);

#ifdef __cplusplus
}
#endif

#endif
