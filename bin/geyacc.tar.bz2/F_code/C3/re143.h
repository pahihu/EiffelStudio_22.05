
#ifndef _C3_re143_
#define _C3_re143_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F201_1988(EIF_REFERENCE);
extern void EIF_Minit143(void);

#ifdef __cplusplus
}
#endif

#endif
