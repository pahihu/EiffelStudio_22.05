
#ifndef _C3_ba133_
#define _C3_ba133_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F191_1968(EIF_REFERENCE);
extern void EIF_Minit133(void);

#ifdef __cplusplus
}
#endif

#endif
