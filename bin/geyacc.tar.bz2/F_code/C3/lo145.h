
#ifndef _C3_lo145_
#define _C3_lo145_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F203_1990(EIF_REFERENCE);
extern void EIF_Minit145(void);

#ifdef __cplusplus
}
#endif

#endif
