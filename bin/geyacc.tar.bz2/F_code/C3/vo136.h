
#ifndef _C3_vo136_
#define _C3_vo136_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F194_1978(EIF_REFERENCE);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
