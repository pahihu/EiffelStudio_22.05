
#ifndef _C3_io131_
#define _C3_io131_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F189_1962(EIF_REFERENCE);
extern void F189_1965(EIF_REFERENCE, EIF_INTEGER_32);
extern void F189_1966(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
