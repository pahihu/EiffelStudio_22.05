
#ifndef _C3_fl116_
#define _C3_fl116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F174_1917(EIF_REFERENCE);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
