
#ifndef _C3_de112_
#define _C3_de112_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F170_1914(EIF_REFERENCE);
extern void EIF_Minit112(void);

#ifdef __cplusplus
}
#endif

#endif
