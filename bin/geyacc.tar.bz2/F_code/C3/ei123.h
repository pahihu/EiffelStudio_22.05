
#ifndef _C3_ei123_
#define _C3_ei123_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F181_1948(EIF_REFERENCE);
extern void F181_1950(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
