
#ifndef _C3_re141_
#define _C3_re141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F199_1984(EIF_REFERENCE);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
