
#ifndef _C3_in148_
#define _C3_in148_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F206_1996(EIF_REFERENCE);
extern void F206_1997(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit148(void);

#ifdef __cplusplus
}
#endif

#endif
