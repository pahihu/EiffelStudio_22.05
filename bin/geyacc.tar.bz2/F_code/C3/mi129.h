
#ifndef _C3_mi129_
#define _C3_mi129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F187_1958(EIF_REFERENCE);
extern void EIF_Minit129(void);

#ifdef __cplusplus
}
#endif

#endif
