
#ifndef _C3_ex127_
#define _C3_ex127_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F185_1956(EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
