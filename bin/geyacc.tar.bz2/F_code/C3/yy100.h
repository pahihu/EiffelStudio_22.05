
#ifndef _C3_yy100_
#define _C3_yy100_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F156_1806(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit100(void);
extern void F250_2557(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1676[];
extern EIF_TYPE_INDEX *Y1676_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
