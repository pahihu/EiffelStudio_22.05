
#ifndef _C3_no126_
#define _C3_no126_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F184_1952(EIF_REFERENCE);
extern void F184_1954(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
