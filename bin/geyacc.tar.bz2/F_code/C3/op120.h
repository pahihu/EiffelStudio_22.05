
#ifndef _C3_op120_
#define _C3_op120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F178_1942(EIF_REFERENCE);
extern void F178_1945(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
