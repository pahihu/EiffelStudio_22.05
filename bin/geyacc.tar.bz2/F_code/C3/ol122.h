
#ifndef _C3_ol122_
#define _C3_ol122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F180_1946(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
