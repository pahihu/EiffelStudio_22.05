
#ifndef _C3_se130_
#define _C3_se130_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F188_1960(EIF_REFERENCE);
extern void EIF_Minit130(void);

#ifdef __cplusplus
}
#endif

#endif
