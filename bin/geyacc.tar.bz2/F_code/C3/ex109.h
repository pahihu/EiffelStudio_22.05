
#ifndef _C3_ex109_
#define _C3_ex109_

#ifdef __cplusplus
extern "C" {
#endif

extern void F167_1874(EIF_REFERENCE, EIF_REFERENCE);
extern void F167_1875(EIF_REFERENCE, EIF_REFERENCE);
extern void F167_1876(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit109(void);
extern void F169_1898(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F166_1855(EIF_REFERENCE);
extern EIF_REFERENCE F98_1111(EIF_REFERENCE, EIF_INTEGER_32);
extern void F169_1883(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1855)

#ifdef __cplusplus
}
#endif

#endif
