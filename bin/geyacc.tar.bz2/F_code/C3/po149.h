
#ifndef _C3_po149_
#define _C3_po149_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F207_2000(EIF_REFERENCE);
extern void EIF_Minit149(void);

#ifdef __cplusplus
}
#endif

#endif
