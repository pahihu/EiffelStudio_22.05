
#ifndef _C3_ro134_
#define _C3_ro134_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F192_1972(EIF_REFERENCE);
extern void F192_1974(EIF_REFERENCE, EIF_REFERENCE);
extern void F192_1975(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
