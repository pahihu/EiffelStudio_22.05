
#ifndef _C3_kl107_
#define _C3_kl107_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1854)
static EIF_REFERENCE F165_1854_body(EIF_REFERENCE);
extern EIF_REFERENCE F165_1854(EIF_REFERENCE);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
