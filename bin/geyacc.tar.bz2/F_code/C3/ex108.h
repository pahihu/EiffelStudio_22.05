
#ifndef _C3_ex108_
#define _C3_ex108_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1855)
static EIF_REFERENCE F166_1855_body(EIF_REFERENCE);
extern EIF_REFERENCE F166_1855(EIF_REFERENCE);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
