
#ifndef _C20_ds951_
#define _C20_ds951_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1094_7486(EIF_REFERENCE);
extern EIF_INTEGER_32 F1094_7489(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit951(void);
extern void F1002_6808(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5255[];
extern EIF_TYPE_INDEX *Y5255_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
