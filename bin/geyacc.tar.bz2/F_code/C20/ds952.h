
#ifndef _C20_ds952_
#define _C20_ds952_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1009_6827(EIF_REFERENCE);
extern void EIF_Minit952(void);

#ifdef __cplusplus
}
#endif

#endif
