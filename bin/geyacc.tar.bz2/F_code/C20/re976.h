
#ifndef _C20_re976_
#define _C20_re976_

#ifdef __cplusplus
extern "C" {
#endif

extern void F377_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F377_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F377_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F377_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F377_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F377_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F377_2982(EIF_REFERENCE);
extern void F377_2987(EIF_REFERENCE);
extern void EIF_Minit976(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
