
#ifndef _C20_re996_
#define _C20_re996_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F615_3166(EIF_REFERENCE);
extern void EIF_Minit996(void);
extern EIF_INTEGER_32 F691_3632(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
