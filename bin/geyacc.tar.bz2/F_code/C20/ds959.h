
#ifndef _C20_ds959_
#define _C20_ds959_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1107_7570(EIF_REFERENCE);
extern EIF_INTEGER_32 F1107_7573(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit959(void);
extern char *(*R5203[])();
extern EIF_TYPE_INDEX Y730[];
extern EIF_TYPE_INDEX *Y730_gen_type [];
extern EIF_TYPE_INDEX Y5255[];
extern EIF_TYPE_INDEX *Y5255_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
