
#ifndef _C20_co983_
#define _C20_co983_

#ifdef __cplusplus
extern "C" {
#endif

extern void F446_3055(EIF_REFERENCE);
extern void EIF_Minit983(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
