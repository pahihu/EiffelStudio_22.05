
#ifndef _C20_ds961_
#define _C20_ds961_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1097_7490(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7493(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7496(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1097_7498(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1097_7504(EIF_REFERENCE);
extern EIF_BOOLEAN F1097_7506(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7509(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1097_7510(EIF_REFERENCE, EIF_REFERENCE);
extern void F1097_7513(EIF_REFERENCE, EIF_REFERENCE);
extern void F1097_7515(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7518(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7519(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7521(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1097_7522(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1097_7534(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit961(void);
extern void F1086_7355(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F912_5958(EIF_REFERENCE);
extern EIF_BOOLEAN F6_74(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1_29(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5958)
extern char *(*R5441[])();
extern char *(*R5485[])();
extern char *(*R5257[])();
extern char *(*R5493[])();
extern char *(*R5499[])();
extern char *(*R5260[])();
extern char *(*R5466[])();
extern char *(*R5540[])();
extern char *(*R5504[])();
extern char *(*R5505[])();
extern char *(*R5470[])();
extern char *(*R5475[])();
extern char *(*R5476[])();
extern char *(*R5477[])();
extern char *(*R5478[])();
extern char *(*R5481[])();
extern char *(*R5440[])();
extern EIF_TYPE_INDEX Y5555[];
extern EIF_TYPE_INDEX *Y5555_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
