
#ifndef _C20_fi990_
#define _C20_fi990_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F589_3153(EIF_REFERENCE);
extern void EIF_Minit990(void);
extern EIF_INTEGER_32 F691_3631(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
