
#ifndef _C20_to992_
#define _C20_to992_

#ifdef __cplusplus
extern "C" {
#endif

extern void F238_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F238_2365(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F238_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit992(void);
extern void F666_3531(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
