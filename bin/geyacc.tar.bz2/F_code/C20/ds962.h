
#ifndef _C20_ds962_
#define _C20_ds962_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1012_6829(EIF_REFERENCE);
extern void EIF_Minit962(void);
extern char *(*R5335[])();

#ifdef __cplusplus
}
#endif

#endif
