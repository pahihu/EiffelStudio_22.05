
#ifndef _C20_ds972_
#define _C20_ds972_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1022_6835(EIF_REFERENCE);
extern void EIF_Minit972(void);

#ifdef __cplusplus
}
#endif

#endif
