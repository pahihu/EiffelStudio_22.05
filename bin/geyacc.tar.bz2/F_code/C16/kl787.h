
#ifndef _C16_kl787_
#define _C16_kl787_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F21_270(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F21_273(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_275(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F21_278(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F21_279(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit787(void);
extern char *(*R3040[])();
extern char *(*R3026[])();
extern char *(*R3022[])();
extern char *(*R2567[])();
extern char *(*R2568[])();
extern char *(*R3039[])();

#ifdef __cplusplus
}
#endif

#endif
