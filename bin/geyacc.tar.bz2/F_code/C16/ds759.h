
#ifndef _C16_ds759_
#define _C16_ds759_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1041_6920(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1041_6925(EIF_REFERENCE, EIF_REFERENCE);
extern void F1041_6928(EIF_REFERENCE, EIF_REFERENCE);
extern void F1041_6929(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit759(void);
extern char *(*R5173[])();
extern char *(*R5174[])();
extern char *(*R5179[])();
extern char *(*R5284[])();

#ifdef __cplusplus
}
#endif

#endif
