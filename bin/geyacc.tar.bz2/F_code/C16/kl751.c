/*
 * Code for class KL_ARRAY_ROUTINES [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl751.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_ARRAY_ROUTINES}.make_empty_with_lower */
EIF_REFERENCE F917_6008 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNS(typres0.id, 681, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3071[Dtype(RTCW(tr1))-681])(tr1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,693,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc1 = RTLNS(typres0.id, 693, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3071[Dtype(RTCW(loc1))-681])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3109[Dtype(RTCW(loc1))-693])(loc1, arg1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNS(typres0.id, 681, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3074[Dtype(RTCW(tr1))-681])(tr1, loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {KL_ARRAY_ROUTINES}.subarray */
EIF_REFERENCE F917_6011 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 < arg2)) {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4602[dtype-916])(Current, arg4);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,681,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(Dftype(Current), typarr0);
			Result = RTLNS(typres0.id, 681, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2769[Dtype(RTCW(arg1))-681])(arg1, (EIF_REFERENCE) &arg2);
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R3072[Dtype(RTCW(Result))-681])(Result, tr2, arg4, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 + arg3) - arg2));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R4607[dtype-916])(Current, Result, arg1, arg2, arg3, arg4);
	}
	RTLE;
	return Result;
}

/* {KL_ARRAY_ROUTINES}.subcopy */
void F917_6013 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R3085[Dtype(RTCW(arg1))-681])(arg1, arg2, arg3, arg4, arg5);
	}
	RTLE;
}

/* {KL_ARRAY_ROUTINES}.resize_with_default */
void F917_6015 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		tr1 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R3099[Dtype(RTCW(arg1))-681])(arg1, tr1, arg3, arg4);
	}
	RTLE;
}

void EIF_Minit751 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
