
#ifndef _C16_kl751_
#define _C16_kl751_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F917_6008(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F917_6011(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F917_6013(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F917_6015(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit751(void);
extern char *(*R3085[])();
extern char *(*R4602[])();
extern char *(*R3099[])();
extern char *(*R4607[])();
extern char *(*R3109[])();
extern char *(*R3071[])();
extern char *(*R3072[])();
extern char *(*R2769[])();
extern char *(*R3074[])();

#ifdef __cplusplus
}
#endif

#endif
