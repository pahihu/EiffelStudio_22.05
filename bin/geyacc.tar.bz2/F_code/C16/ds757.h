
#ifndef _C16_ds757_
#define _C16_ds757_

#ifdef __cplusplus
extern "C" {
#endif

extern void F979_6782(EIF_REFERENCE);
extern void F979_6783(EIF_REFERENCE);
extern void F979_6785(EIF_REFERENCE);
extern void EIF_Minit757(void);
extern char *(*R5173[])();
extern char *(*R5311[])();
extern char *(*R5312[])();
extern char *(*R5314[])();

#ifdef __cplusplus
}
#endif

#endif
