
#ifndef _C16_ce773_
#define _C16_ce773_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F101_1161(EIF_REFERENCE);
extern void F101_1162(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit773(void);

#ifdef __cplusplus
}
#endif

#endif
