
#ifndef _C16_ds764_
#define _C16_ds764_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1039_6915(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit764(void);
extern char *(*R859[])();

#ifdef __cplusplus
}
#endif

#endif
