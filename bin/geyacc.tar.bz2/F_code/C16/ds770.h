
#ifndef _C16_ds770_
#define _C16_ds770_

#ifdef __cplusplus
extern "C" {
#endif

extern void F114_1314(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit770(void);

#ifdef __cplusplus
}
#endif

#endif
