
#ifndef _C16_ds760_
#define _C16_ds760_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1030_6885(EIF_REFERENCE);
extern void EIF_Minit760(void);
extern char *(*R5246[])();

#ifdef __cplusplus
}
#endif

#endif
