/*
 * Code for class DS_SORTABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds764.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1039_6915 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R859[Dtype(RTCW(arg1))-71])(arg1, Current);
}

void EIF_Minit764 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
