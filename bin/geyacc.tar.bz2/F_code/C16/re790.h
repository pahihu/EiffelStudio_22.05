
#ifndef _C16_re790_
#define _C16_re790_

#ifdef __cplusplus
extern "C" {
#endif

extern void F375_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F375_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F375_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F375_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F375_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F375_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F375_2982(EIF_REFERENCE);
extern void F375_2987(EIF_REFERENCE);
extern void EIF_Minit790(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
