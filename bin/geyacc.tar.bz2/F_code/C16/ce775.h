
#ifndef _C16_ce775_
#define _C16_ce775_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F103_1161(EIF_REFERENCE);
extern void F103_1162(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit775(void);

#ifdef __cplusplus
}
#endif

#endif
