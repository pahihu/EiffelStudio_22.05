
#ifndef _C16_ds766_
#define _C16_ds766_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F985_6792(EIF_REFERENCE);
extern void EIF_Minit766(void);
extern char *(*R2618[])();
extern char *(*R5191[])();

#ifdef __cplusplus
}
#endif

#endif
