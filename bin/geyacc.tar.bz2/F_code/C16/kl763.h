
#ifndef _C16_kl763_
#define _C16_kl763_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F119_1330(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F119_1331(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit763(void);
extern char *(*R1324[])();
extern char *(*R1325[])();

#ifdef __cplusplus
}
#endif

#endif
