
#ifndef _C16_ce774_
#define _C16_ce774_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F102_1161(EIF_REFERENCE);
extern void F102_1162(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit774(void);

#ifdef __cplusplus
}
#endif

#endif
