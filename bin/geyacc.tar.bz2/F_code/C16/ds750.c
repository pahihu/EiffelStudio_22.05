/*
 * Code for class DS_LINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds750.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKED_LIST}.make */
void F1077_7131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1077_7140(Current);
	F1077_7196(Current, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.item */
EIF_REFERENCE F1077_7137 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg1)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_REFERENCE *)(RTCW(loc1));
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.first */
EIF_REFERENCE F1077_7138 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_REFERENCE *)(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.new_cursor */
EIF_REFERENCE F1077_7140 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1028,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5255,Y5255_gen_type,Dftype(Current),1029);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1028, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	F1029_6869(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_LINKED_LIST}.count */
EIF_INTEGER_32 F1077_7141 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
}


/* {DS_LINKED_LIST}.has */
EIF_BOOLEAN F1077_7143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			tr2 = RTCCL(tr1);
			tr3 = RTCCL(arg1);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1930[Dtype(loc2)-211])(loc2, tr2, tr3);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			if (RTCEQ(tr1, arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.copy */
void F1077_7153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1077_7200(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb1 = F1041_6920(Current, loc4);
		}
		if (tb1) {
			F1077_7196(Current, loc4);
		} else {
			tr1 = F1077_7140(Current);
			F1077_7196(Current, tr1);
		}
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				loc3 = RTLNSMART(typres0.id);
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			tr2 = RTCCL(tr1);
			F112_1308(RTCW(loc3), tr2);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			loc1 = (EIF_REFERENCE) tr1;
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == NULL)) break;
				{
					static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
						typarr0[1] = l_type.annotations | 0xFF00;
						typarr0[2] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					loc2 = RTLNSMART(typres0.id);
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				tr2 = RTCCL(tr1);
				F112_1308(RTCW(loc2), tr2);
				F114_1314(RTCW(loc3), loc2);
				loc3 = (EIF_REFERENCE) loc2;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
				loc1 = (EIF_REFERENCE) tr1;
			}
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.is_equal */
EIF_BOOLEAN F1077_7154 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5958,F912_5958, (Current));
		tb2 = F6_74(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_));
		}
		if (tb1) {
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
				if (!RTCEQ(tr1, tr2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_REFERENCE) NULL;
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
					loc1 = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
					loc2 = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.put_last */
void F1077_7157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc1 = RTLNSMART(typres0.id);
		}
		tr1 = RTCCL(arg1);
		F112_1308(RTCW(loc1), tr1);
		F114_1314(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNSMART(typres0.id);
		}
		tr2 = RTCCL(arg1);
		F112_1308(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.force_last */
void F1077_7158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc1 = RTLNSMART(typres0.id);
		}
		tr1 = RTCCL(arg1);
		F112_1308(RTCW(loc1), tr1);
		F114_1314(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNSMART(typres0.id);
		}
		tr2 = RTCCL(arg1);
		F112_1308(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.replace */
void F1077_7159 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg2)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTCCL(arg1);
	F112_1307(RTCW(loc1), tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.append_last */
void F1077_7170 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5247[Dtype(RTCW(arg1))-1076])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5278[Dtype(RTCW(arg1))-1076])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5187[Dtype(RTCW(loc1))-1007])(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc2 = RTLNSMART(typres0.id);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2617[Dtype(RTCW(loc1))-381])(loc1);
		tr2 = RTCCL(tr1);
		F112_1308(RTCW(loc2), tr2);
		loc3 = (EIF_REFERENCE) loc2;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2619[Dtype(RTCW(loc1))-381])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2618[Dtype(RTCW(loc1))-381])(loc1);
			if (tb1) break;
			{
				static EIF_TYPE_INDEX typarr0[] = {113,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y5255,Y5255_gen_type,dftype,1029);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				loc4 = RTLNSMART(typres0.id);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2617[Dtype(RTCW(loc1))-381])(loc1);
			tr2 = RTCCL(tr1);
			F112_1308(RTCW(loc4), tr2);
			F114_1314(RTCW(loc3), loc4);
			loc3 = (EIF_REFERENCE) loc4;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2619[Dtype(RTCW(loc1))-381])(loc1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			F114_1314(loc5, loc2);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		} else {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc2;
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		}
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5246[Dtype(RTCW(arg1))-1076])(arg1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_)) += ti4_1;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.set_internal_cursor */
void F1077_7196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.internal_cursor */
EIF_REFERENCE F1077_7197 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_LINKED_LIST}.move_all_cursors_after */
void F1077_7200 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1029_6879(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F970_6771(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_item */
EIF_REFERENCE F1077_7201 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	RTCT0("not_off", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_REFERENCE *)(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_same_position */
EIF_BOOLEAN F1077_7205 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == tr2)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
		tb1 = (EIF_BOOLEAN)(tb2 == tb3);
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
		Result = (EIF_BOOLEAN)(tb1 == tb2);
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_start */
void F1077_7206 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1041_6925(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	F1029_6881(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_BOOLEAN) 0, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && loc1)) {
		F1041_6928(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_forth */
void F1077_7208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + _REFACS_1_);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	F1029_6881(RTCW(arg1), loc3, (EIF_BOOLEAN) 0, loc2);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			F1041_6929(Current, arg1);
		}
	} else {
		if (loc1) {
			F1041_6928(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_after */
void F1077_7212 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1041_6925(Current, arg1);
	F1029_6879(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1041_6929(Current, arg1);
	}
	RTLE;
}

void EIF_Minit750 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
