
#ifndef _C16_ds761_
#define _C16_ds761_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1045_6933(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit761(void);

#ifdef __cplusplus
}
#endif

#endif
