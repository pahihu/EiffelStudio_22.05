
#ifndef _C16_ds771_
#define _C16_ds771_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F112_1305(EIF_REFERENCE);
extern void F112_1307(EIF_REFERENCE, EIF_REFERENCE);
extern void F112_1308(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit771(void);

#ifdef __cplusplus
}
#endif

#endif
