
#ifndef _C16_kl778_
#define _C16_kl778_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F217_2108(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F217_2111(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit778(void);
extern char *(*R1932[])();
extern char *(*R1325[])();

#ifdef __cplusplus
}
#endif

#endif
