
#ifndef _C16_ha781_
#define _C16_ha781_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F384_2996(EIF_REFERENCE);
extern EIF_REFERENCE F384_2997(EIF_REFERENCE);
extern EIF_BOOLEAN F384_2999(EIF_REFERENCE);
extern void F384_3000(EIF_REFERENCE);
extern EIF_REFERENCE F384_3001(EIF_REFERENCE);
extern void EIF_Minit781(void);
extern EIF_BOOLEAN F370_2982(EIF_REFERENCE);
extern char *(*R3006[])();
extern char *(*R3217[])();
extern char *(*R3218[])();
extern char *(*R2567[])();

#ifdef __cplusplus
}
#endif

#endif
