
#ifndef _C16_kl777_
#define _C16_kl777_

#ifdef __cplusplus
extern "C" {
#endif

extern void F219_2112(EIF_REFERENCE);
extern EIF_BOOLEAN F219_2113(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit777(void);
extern char *(*R1541[])();

#ifdef __cplusplus
}
#endif

#endif
