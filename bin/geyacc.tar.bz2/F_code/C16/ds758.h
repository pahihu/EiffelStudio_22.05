
#ifndef _C16_ds758_
#define _C16_ds758_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F970_6762(EIF_REFERENCE);
extern EIF_BOOLEAN F970_6765(EIF_REFERENCE, EIF_REFERENCE);
extern void F970_6768(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F970_6769(EIF_REFERENCE, EIF_REFERENCE);
extern void F970_6771(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit758(void);
extern EIF_REFERENCE F912_5958(EIF_REFERENCE);
extern EIF_BOOLEAN F6_74(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5958)
extern char *(*R5290[])();
extern char *(*R5173[])();
extern char *(*R5174[])();
extern char *(*R5175[])();
extern char *(*R5285[])();
extern char *(*R5287[])();
extern char *(*R5289[])();

#ifdef __cplusplus
}
#endif

#endif
