
#ifndef _C16_kl752_
#define _C16_kl752_

#ifdef __cplusplus
extern "C" {
#endif

extern void F694_3677(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit752(void);

#ifdef __cplusplus
}
#endif

#endif
