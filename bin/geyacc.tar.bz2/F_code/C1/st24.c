/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st24.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F46_482_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (482);
#define Result RTOSR(482)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(941, 0x01).id, 941, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F942_6244(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (482);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_482 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(482,F46_482_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F46_483_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (483);
#define Result RTOSR(483)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(941, 0x01).id, 941, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F942_6245(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (483);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_483 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(483,F46_483_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F46_484_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (484);
#define Result RTOSR(484)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(941, 0x01).id, 941, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F942_6246(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (484);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_484 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(484,F46_484_body,(Current));
}

/* {STD_FILES}.set_output_default */
void F46_510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(483,F46_483, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit24 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
