
#ifndef _C1_pr25_
#define _C1_pr25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F47_562(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F47_567(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit25(void);
extern void F904_5915(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4528[])();

#ifdef __cplusplus
}
#endif

#endif
