/*
 * Code for class KL_SHARED_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl38.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_PLATFORM}.platform */
static EIF_REFERENCE F65_779_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (779);
#define Result RTOSR(779)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(148, 0x01).id, 148, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (779);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F65_779 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(779,F65_779_body,(Current));
}

void EIF_Minit38 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
