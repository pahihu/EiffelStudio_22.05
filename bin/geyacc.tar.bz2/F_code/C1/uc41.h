
#ifndef _C1_uc41_
#define _C1_uc41_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,869)
static EIF_REFERENCE F74_869_body(EIF_REFERENCE);
extern EIF_REFERENCE F74_869(EIF_REFERENCE);
extern void EIF_Minit41(void);

#ifdef __cplusplus
}
#endif

#endif
