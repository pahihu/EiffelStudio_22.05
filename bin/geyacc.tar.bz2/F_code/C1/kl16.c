/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl16.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F19_264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (264);
#define Result RTOSR(264)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(928, 0x01).id, 928, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F929_6177(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (264);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(264,F19_264_body,(Current));
}

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F19_265_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (265);
#define Result RTOSR(265)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(908, 0x01).id, 908, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (265);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_265 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(265,F19_265_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F19_266_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (266);
#define Result RTOSR(266)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(907, 0x01).id, 907, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (266);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F19_266 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(266,F19_266_body,(Current));
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
