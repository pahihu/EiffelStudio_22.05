/*
 * Code for class PR_CONFLICT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr25.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_CONFLICT}.make */
void F47_562 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg4;
	RTLE;
}

/* {PR_CONFLICT}.print_conflict */
void F47_567 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Conflict in state ",18,1672583456);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_6_2_0_0_);
	F904_5915(RTCW(arg1), ti4_1);
	tr1 = RTMS_EX_H(" between rule ",14,1783119136);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_1_0_0_);
	F904_5915(RTCW(arg1), ti4_1);
	tr1 = RTMS_EX_H(" and token ",11,1316592416);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_2_0_1_);
	F904_5915(RTCW(arg1), ti4_1);
	tr1 = RTMS_EX_H(" (",2,8232);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	tr1 = RTMS_EX_H(") resolved as ",14,1904749600);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = RTMS_EX_H(".\012",2,11786);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	RTLE;
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
