
#ifndef _C1_is22_
#define _C1_is22_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F32_366(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F32_371(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F32_373(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F32_381(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit22(void);

#ifdef __cplusplus
}
#endif

#endif
