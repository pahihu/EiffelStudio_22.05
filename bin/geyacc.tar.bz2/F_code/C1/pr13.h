
#ifndef _C1_pr13_
#define _C1_pr13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F13_121(EIF_REFERENCE);
extern EIF_REFERENCE F13_122(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit13(void);
extern void F916_6001(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
