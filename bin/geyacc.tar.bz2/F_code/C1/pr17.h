
#ifndef _C1_pr17_
#define _C1_pr17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_280(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
