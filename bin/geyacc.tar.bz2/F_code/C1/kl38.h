
#ifndef _C1_kl38_
#define _C1_kl38_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,779)
static EIF_REFERENCE F65_779_body(EIF_REFERENCE);
extern EIF_REFERENCE F65_779(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
