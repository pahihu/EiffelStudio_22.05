
#ifndef _C1_kl6_
#define _C1_kl6_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F6_74(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);

#ifdef __cplusplus
}
#endif

#endif
