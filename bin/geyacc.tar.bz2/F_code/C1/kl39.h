
#ifndef _C1_kl39_
#define _C1_kl39_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F66_784(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit39(void);

#ifdef __cplusplus
}
#endif

#endif
