/*
 * Code for class PR_ACTION_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr13.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PR_ACTION_FACTORY}.make */
void F13_121 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {PR_ACTION_FACTORY}.new_action */
EIF_REFERENCE F13_122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(915, 0x01).id, 915, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F916_6001(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
