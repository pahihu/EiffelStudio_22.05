/*
 * Code for class UT_ARRAY_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut8.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_ARRAY_FORMATTER}.put_integer_array */
void F8_83 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(87,F8_87, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_INTEGER_32) arg3;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg4)) break;
		loc4++;
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 10L))) {
			F907_5933(RTCW(arg1));
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc3++;
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 10L))) {
				F907_5933(RTCW(arg1));
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			}
			tr1 = RTOSCF(87,F8_87, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
		}
		loc2 = F684_3624(RTCW(arg2), loc1);
		tr1 = eif_out__i4_s1(loc2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		switch (ti4_1) {
			case 1L:
				tr1 = RTOSCF(86,F8_86, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case 2L:
				tr1 = RTOSCF(85,F8_85, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			case 3L:
				tr1 = RTOSCF(84,F8_84, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4528[Dtype(RTCW(arg1))-907])(arg1, tr1);
				break;
			default:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) ' ');
				break;
		}
		F904_5915(RTCW(arg1), loc2);
		if ((EIF_BOOLEAN) (loc1 < arg4)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R997[Dtype(RTCW(arg1))-907])(arg1, (EIF_CHARACTER_8) ',');
		}
		loc1++;
	}
	RTLE;
}

/* {UT_ARRAY_FORMATTER}.two_spaces */

EIF_REFERENCE F8_84 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (84,RTMS_EX_H("  ",2,8224));
}

/* {UT_ARRAY_FORMATTER}.three_spaces */

EIF_REFERENCE F8_85 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (85,RTMS_EX_H("   ",3,2105376));
}

/* {UT_ARRAY_FORMATTER}.four_spaces */

EIF_REFERENCE F8_86 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (86,RTMS_EX_H("    ",4,538976288));
}

/* {UT_ARRAY_FORMATTER}.indentation */

EIF_REFERENCE F8_87 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (87,RTMS_EX_H("\011\011\011",3,592137));
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
