/*
 * Code for class UC_UNICODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UNICODE_CONSTANTS}.bom_character */
static EIF_CHARACTER_32 F67_786_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (786);
#define Result RTOSR(786)
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65279L);
	RTOSE (786);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F67_786 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(786,F67_786_body,(Current));
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
