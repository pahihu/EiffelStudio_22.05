
#ifndef _C1_uc40_
#define _C1_uc40_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_32,786)
static EIF_CHARACTER_32 F67_786_body(EIF_REFERENCE);
extern EIF_CHARACTER_32 F67_786(EIF_REFERENCE);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
