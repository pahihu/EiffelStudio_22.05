#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F766_3950(EIF_REFERENCE);
extern void F773_4023(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F773_4024(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern EIF_BOOLEAN F586_3153(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif
