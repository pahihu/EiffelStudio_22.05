#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F1170_8425(EIF_REFERENCE);
extern void emain(int, EIF_NATIVE_CHAR **);
void emain (int argc, EIF_NATIVE_CHAR ** argv)
{
	GTCX
	root_obj = RTLNSMART(egc_rcdt[egc_ridx]);
	switch (egc_ridx)
	{
		case 0:

			F1170_8425(root_obj);
			break;
	}
}

extern void EIF_Minit1(void);
extern void EIF_Minit6(void);
extern void EIF_Minit8(void);
extern void EIF_Minit13(void);
extern void EIF_Minit16(void);
extern void EIF_Minit1165(void);
extern void EIF_Minit787(void);
extern void EIF_Minit554(void);
extern void EIF_Minit708(void);
extern void EIF_Minit709(void);
extern void EIF_Minit1158(void);
extern void EIF_Minit1161(void);
extern void EIF_Minit17(void);
extern void EIF_Minit21(void);
extern void EIF_Minit20(void);
extern void EIF_Minit22(void);
extern void EIF_Minit24(void);
extern void EIF_Minit25(void);
extern void EIF_Minit38(void);
extern void EIF_Minit39(void);
extern void EIF_Minit40(void);
extern void EIF_Minit1153(void);
extern void EIF_Minit1163(void);
extern void EIF_Minit1152(void);
extern void EIF_Minit1162(void);
extern void EIF_Minit41(void);
extern void EIF_Minit48(void);
extern void EIF_Minit50(void);
extern void EIF_Minit53(void);
extern void EIF_Minit58(void);
extern void EIF_Minit385(void);
extern void EIF_Minit773(void);
extern void EIF_Minit774(void);
extern void EIF_Minit775(void);
extern void EIF_Minit60(void);
extern void EIF_Minit771(void);
extern void EIF_Minit884(void);
extern void EIF_Minit770(void);
extern void EIF_Minit763(void);
extern void EIF_Minit896(void);
extern void EIF_Minit75(void);
extern void EIF_Minit76(void);
extern void EIF_Minit77(void);
extern void EIF_Minit78(void);
extern void EIF_Minit80(void);
extern void EIF_Minit1138(void);
extern void EIF_Minit81(void);
extern void EIF_Minit82(void);
extern void EIF_Minit83(void);
extern void EIF_Minit84(void);
extern void EIF_Minit85(void);
extern void EIF_Minit87(void);
extern void EIF_Minit89(void);
extern void EIF_Minit90(void);
extern void EIF_Minit91(void);
extern void EIF_Minit92(void);
extern void EIF_Minit93(void);
extern void EIF_Minit94(void);
extern void EIF_Minit95(void);
extern void EIF_Minit96(void);
extern void EIF_Minit97(void);
extern void EIF_Minit98(void);
extern void EIF_Minit100(void);
extern void EIF_Minit101(void);
extern void EIF_Minit103(void);
extern void EIF_Minit107(void);
extern void EIF_Minit108(void);
extern void EIF_Minit109(void);
extern void EIF_Minit110(void);
extern void EIF_Minit111(void);
extern void EIF_Minit112(void);
extern void EIF_Minit116(void);
extern void EIF_Minit118(void);
extern void EIF_Minit119(void);
extern void EIF_Minit120(void);
extern void EIF_Minit122(void);
extern void EIF_Minit123(void);
extern void EIF_Minit126(void);
extern void EIF_Minit127(void);
extern void EIF_Minit129(void);
extern void EIF_Minit130(void);
extern void EIF_Minit131(void);
extern void EIF_Minit133(void);
extern void EIF_Minit134(void);
extern void EIF_Minit135(void);
extern void EIF_Minit136(void);
extern void EIF_Minit138(void);
extern void EIF_Minit139(void);
extern void EIF_Minit141(void);
extern void EIF_Minit142(void);
extern void EIF_Minit143(void);
extern void EIF_Minit145(void);
extern void EIF_Minit146(void);
extern void EIF_Minit147(void);
extern void EIF_Minit148(void);
extern void EIF_Minit149(void);
extern void EIF_Minit150(void);
extern void EIF_Minit152(void);
extern void EIF_Minit153(void);
extern void EIF_Minit383(void);
extern void EIF_Minit493(void);
extern void EIF_Minit600(void);
extern void EIF_Minit650(void);
extern void EIF_Minit778(void);
extern void EIF_Minit1168(void);
extern void EIF_Minit777(void);
extern void EIF_Minit1167(void);
extern void EIF_Minit155(void);
extern void EIF_Minit158(void);
extern void EIF_Minit433(void);
extern void EIF_Minit470(void);
extern void EIF_Minit516(void);
extern void EIF_Minit575(void);
extern void EIF_Minit622(void);
extern void EIF_Minit678(void);
extern void EIF_Minit734(void);
extern void EIF_Minit809(void);
extern void EIF_Minit832(void);
extern void EIF_Minit992(void);
extern void EIF_Minit1031(void);
extern void EIF_Minit1067(void);
extern void EIF_Minit163(void);
extern void EIF_Minit164(void);
extern void EIF_Minit165(void);
extern void EIF_Minit168(void);
extern void EIF_Minit170(void);
extern void EIF_Minit172(void);
extern void EIF_Minit173(void);
extern void EIF_Minit174(void);
extern void EIF_Minit175(void);
extern void EIF_Minit182(void);
extern void EIF_Minit184(void);
extern void EIF_Minit185(void);
extern void EIF_Minit406(void);
extern void EIF_Minit461(void);
extern void EIF_Minit499(void);
extern void EIF_Minit571(void);
extern void EIF_Minit605(void);
extern void EIF_Minit674(void);
extern void EIF_Minit717(void);
extern void EIF_Minit790(void);
extern void EIF_Minit836(void);
extern void EIF_Minit976(void);
extern void EIF_Minit1027(void);
extern void EIF_Minit1063(void);
extern void EIF_Minit443(void);
extern void EIF_Minit490(void);
extern void EIF_Minit781(void);
extern void EIF_Minit1105(void);
extern void EIF_Minit1101(void);
extern void EIF_Minit389(void);
extern void EIF_Minit451(void);
extern void EIF_Minit507(void);
extern void EIF_Minit560(void);
extern void EIF_Minit613(void);
extern void EIF_Minit665(void);
extern void EIF_Minit725(void);
extern void EIF_Minit800(void);
extern void EIF_Minit844(void);
extern void EIF_Minit983(void);
extern void EIF_Minit1016(void);
extern void EIF_Minit1052(void);
extern void EIF_Minit825(void);
extern void EIF_Minit188(void);
extern void EIF_Minit408(void);
extern void EIF_Minit463(void);
extern void EIF_Minit514(void);
extern void EIF_Minit573(void);
extern void EIF_Minit620(void);
extern void EIF_Minit676(void);
extern void EIF_Minit732(void);
extern void EIF_Minit807(void);
extern void EIF_Minit851(void);
extern void EIF_Minit990(void);
extern void EIF_Minit1029(void);
extern void EIF_Minit1065(void);
extern void EIF_Minit440(void);
extern void EIF_Minit474(void);
extern void EIF_Minit520(void);
extern void EIF_Minit583(void);
extern void EIF_Minit626(void);
extern void EIF_Minit686(void);
extern void EIF_Minit738(void);
extern void EIF_Minit813(void);
extern void EIF_Minit856(void);
extern void EIF_Minit996(void);
extern void EIF_Minit1039(void);
extern void EIF_Minit1075(void);
extern void EIF_Minit189(void);
extern void EIF_Minit191(void);
extern void EIF_Minit434(void);
extern void EIF_Minit465(void);
extern void EIF_Minit496(void);
extern void EIF_Minit576(void);
extern void EIF_Minit602(void);
extern void EIF_Minit679(void);
extern void EIF_Minit721(void);
extern void EIF_Minit796(void);
extern void EIF_Minit833(void);
extern void EIF_Minit973(void);
extern void EIF_Minit1032(void);
extern void EIF_Minit1068(void);
extern void EIF_Minit438(void);
extern void EIF_Minit469(void);
extern void EIF_Minit506(void);
extern void EIF_Minit559(void);
extern void EIF_Minit612(void);
extern void EIF_Minit664(void);
extern void EIF_Minit724(void);
extern void EIF_Minit799(void);
extern void EIF_Minit843(void);
extern void EIF_Minit982(void);
extern void EIF_Minit1015(void);
extern void EIF_Minit1051(void);
extern void EIF_Minit752(void);
extern void EIF_Minit540(void);
extern void EIF_Minit595(void);
extern void EIF_Minit648(void);
extern void EIF_Minit698(void);
extern void EIF_Minit1160(void);
extern void EIF_Minit193(void);
extern void EIF_Minit195(void);
extern void EIF_Minit444(void);
extern void EIF_Minit449(void);
extern void EIF_Minit782(void);
extern void EIF_Minit1102(void);
extern void EIF_Minit1098(void);
extern void EIF_Minit196(void);
extern void EIF_Minit197(void);
extern void EIF_Minit200(void);
extern void EIF_Minit384(void);
extern void EIF_Minit386(void);
extern void EIF_Minit396(void);
extern void EIF_Minit415(void);
extern void EIF_Minit416(void);
extern void EIF_Minit417(void);
extern void EIF_Minit418(void);
extern void EIF_Minit419(void);
extern void EIF_Minit420(void);
extern void EIF_Minit421(void);
extern void EIF_Minit422(void);
extern void EIF_Minit423(void);
extern void EIF_Minit424(void);
extern void EIF_Minit425(void);
extern void EIF_Minit426(void);
extern void EIF_Minit427(void);
extern void EIF_Minit776(void);
extern void EIF_Minit901(void);
extern void EIF_Minit905(void);
extern void EIF_Minit909(void);
extern void EIF_Minit913(void);
extern void EIF_Minit917(void);
extern void EIF_Minit921(void);
extern void EIF_Minit925(void);
extern void EIF_Minit929(void);
extern void EIF_Minit933(void);
extern void EIF_Minit937(void);
extern void EIF_Minit941(void);
extern void EIF_Minit945(void);
extern void EIF_Minit949(void);
extern void EIF_Minit1014(void);
extern void EIF_Minit201(void);
extern void EIF_Minit202(void);
extern void EIF_Minit204(void);
extern void EIF_Minit203(void);
extern void EIF_Minit205(void);
extern void EIF_Minit207(void);
extern void EIF_Minit206(void);
extern void EIF_Minit208(void);
extern void EIF_Minit210(void);
extern void EIF_Minit209(void);
extern void EIF_Minit211(void);
extern void EIF_Minit213(void);
extern void EIF_Minit212(void);
extern void EIF_Minit214(void);
extern void EIF_Minit216(void);
extern void EIF_Minit215(void);
extern void EIF_Minit217(void);
extern void EIF_Minit219(void);
extern void EIF_Minit218(void);
extern void EIF_Minit220(void);
extern void EIF_Minit222(void);
extern void EIF_Minit221(void);
extern void EIF_Minit223(void);
extern void EIF_Minit225(void);
extern void EIF_Minit224(void);
extern void EIF_Minit226(void);
extern void EIF_Minit228(void);
extern void EIF_Minit227(void);
extern void EIF_Minit229(void);
extern void EIF_Minit231(void);
extern void EIF_Minit230(void);
extern void EIF_Minit232(void);
extern void EIF_Minit234(void);
extern void EIF_Minit233(void);
extern void EIF_Minit235(void);
extern void EIF_Minit237(void);
extern void EIF_Minit236(void);
extern void EIF_Minit238(void);
extern void EIF_Minit240(void);
extern void EIF_Minit239(void);
extern void EIF_Minit241(void);
extern void EIF_Minit243(void);
extern void EIF_Minit242(void);
extern void EIF_Minit244(void);
extern void EIF_Minit246(void);
extern void EIF_Minit247(void);
extern void EIF_Minit248(void);
extern void EIF_Minit249(void);
extern void EIF_Minit250(void);
extern void EIF_Minit251(void);
extern void EIF_Minit252(void);
extern void EIF_Minit254(void);
extern void EIF_Minit258(void);
extern void EIF_Minit259(void);
extern void EIF_Minit261(void);
extern void EIF_Minit264(void);
extern void EIF_Minit265(void);
extern void EIF_Minit266(void);
extern void EIF_Minit269(void);
extern void EIF_Minit273(void);
extern void EIF_Minit751(void);
extern void EIF_Minit539(void);
extern void EIF_Minit557(void);
extern void EIF_Minit647(void);
extern void EIF_Minit663(void);
extern void EIF_Minit1159(void);
extern void EIF_Minit274(void);
extern void EIF_Minit275(void);
extern void EIF_Minit276(void);
extern void EIF_Minit277(void);
extern void EIF_Minit278(void);
extern void EIF_Minit280(void);
extern void EIF_Minit281(void);
extern void EIF_Minit282(void);
extern void EIF_Minit286(void);
extern void EIF_Minit287(void);
extern void EIF_Minit288(void);
extern void EIF_Minit290(void);
extern void EIF_Minit291(void);
extern void EIF_Minit292(void);
extern void EIF_Minit294(void);
extern void EIF_Minit295(void);
extern void EIF_Minit296(void);
extern void EIF_Minit298(void);
extern void EIF_Minit304(void);
extern void EIF_Minit305(void);
extern void EIF_Minit306(void);
extern void EIF_Minit310(void);
extern void EIF_Minit311(void);
extern void EIF_Minit758(void);
extern void EIF_Minit536(void);
extern void EIF_Minit642(void);
extern void EIF_Minit660(void);
extern void EIF_Minit757(void);
extern void EIF_Minit535(void);
extern void EIF_Minit641(void);
extern void EIF_Minit657(void);
extern void EIF_Minit766(void);
extern void EIF_Minit534(void);
extern void EIF_Minit640(void);
extern void EIF_Minit656(void);
extern void EIF_Minit1120(void);
extern void EIF_Minit876(void);
extern void EIF_Minit967(void);
extern void EIF_Minit548(void);
extern void EIF_Minit702(void);
extern void EIF_Minit1117(void);
extern void EIF_Minit952(void);
extern void EIF_Minit1143(void);
extern void EIF_Minit871(void);
extern void EIF_Minit962(void);
extern void EIF_Minit542(void);
extern void EIF_Minit652(void);
extern void EIF_Minit1151(void);
extern void EIF_Minit882(void);
extern void EIF_Minit972(void);
extern void EIF_Minit556(void);
extern void EIF_Minit596(void);
extern void EIF_Minit886(void);
extern void EIF_Minit889(void);
extern void EIF_Minit772(void);
extern void EIF_Minit760(void);
extern void EIF_Minit494(void);
extern void EIF_Minit601(void);
extern void EIF_Minit644(void);
extern void EIF_Minit764(void);
extern void EIF_Minit897(void);
extern void EIF_Minit759(void);
extern void EIF_Minit537(void);
extern void EIF_Minit643(void);
extern void EIF_Minit661(void);
extern void EIF_Minit761(void);
extern void EIF_Minit492(void);
extern void EIF_Minit599(void);
extern void EIF_Minit649(void);
extern void EIF_Minit750(void);
extern void EIF_Minit887(void);
extern void EIF_Minit550(void);
extern void EIF_Minit704(void);
extern void EIF_Minit1008(void);
extern void EIF_Minit885(void);
extern void EIF_Minit888(void);
extern void EIF_Minit1121(void);
extern void EIF_Minit877(void);
extern void EIF_Minit968(void);
extern void EIF_Minit549(void);
extern void EIF_Minit703(void);
extern void EIF_Minit1122(void);
extern void EIF_Minit955(void);
extern void EIF_Minit1125(void);
extern void EIF_Minit958(void);
extern void EIF_Minit1116(void);
extern void EIF_Minit951(void);
extern void EIF_Minit1142(void);
extern void EIF_Minit870(void);
extern void EIF_Minit961(void);
extern void EIF_Minit541(void);
extern void EIF_Minit651(void);
extern void EIF_Minit1149(void);
extern void EIF_Minit879(void);
extern void EIF_Minit970(void);
extern void EIF_Minit552(void);
extern void EIF_Minit706(void);
extern void EIF_Minit1140(void);
extern void EIF_Minit868(void);
extern void EIF_Minit959(void);
extern void EIF_Minit491(void);
extern void EIF_Minit598(void);
extern void EIF_Minit318(void);
extern void EIF_Minit319(void);
extern void EIF_Minit320(void);
extern void EIF_Minit328(void);
extern void EIF_Minit331(void);
extern void EIF_Minit332(void);
extern void EIF_Minit333(void);
extern void EIF_Minit334(void);
extern void EIF_Minit335(void);
extern void EIF_Minit336(void);
extern void EIF_Minit337(void);
extern void EIF_Minit338(void);
extern void EIF_Minit339(void);
extern void EIF_Minit340(void);
extern void EIF_Minit341(void);
extern void EIF_Minit342(void);
extern void EIF_Minit343(void);
extern void EIF_Minit344(void);
extern void EIF_Minit345(void);
extern void EIF_Minit346(void);
extern void EIF_Minit347(void);
extern void EIF_Minit348(void);
extern void EIF_Minit349(void);
extern void EIF_Minit350(void);
extern void EIF_Minit351(void);
extern void EIF_Minit352(void);
extern void EIF_Minit353(void);
extern void EIF_Minit354(void);
extern void EIF_Minit355(void);
extern void EIF_Minit356(void);
extern void EIF_Minit357(void);
extern void EIF_Minit358(void);
extern void EIF_Minit359(void);
extern void EIF_Minit360(void);
extern void EIF_Minit361(void);
extern void EIF_Minit362(void);
extern void EIF_Minit363(void);
extern void EIF_Minit364(void);
extern void EIF_Minit365(void);
extern void EIF_Minit366(void);
extern void EIF_Minit367(void);
extern void EIF_Minit368(void);
extern void EIF_Minit369(void);
extern void EIF_Minit370(void);
extern void EIF_Minit371(void);
extern void EIF_Minit372(void);
extern void EIF_Minit373(void);
extern void EIF_Minit374(void);
extern void EIF_Minit375(void);
extern void EIF_Minit381(void);
RTOSDF (EIF_REFERENCE,8440)
RTOSDF (EIF_REFERENCE,8444)
RTOSDF (EIF_REFERENCE,24)
RTOSDF (EIF_REFERENCE,4262)
RTOSDF (EIF_REFERENCE,4264)
RTOSDF (EIF_REFERENCE,5736)
RTOSDF (EIF_REFERENCE,5570)
RTOSDF (EIF_REFERENCE,1115)
RTOSDF (EIF_REFERENCE,1116)
RTOSDF (EIF_REFERENCE,1117)
RTOSDF (EIF_REFERENCE,1118)
RTOSDF (EIF_REFERENCE,1119)
RTOSDF (EIF_REFERENCE,1120)
RTOSDF (EIF_REFERENCE,7715)
RTOSDF (EIF_REFERENCE,7716)
RTOSDF (EIF_REFERENCE,8423)
RTOSDF (EIF_REFERENCE,8223)
RTOSDF (EIF_REFERENCE,8226)
RTOSDF (EIF_REFERENCE,8227)
RTOSDF (EIF_REFERENCE,8230)
RTOSDF (EIF_REFERENCE,8231)
RTOSDF (EIF_REFERENCE,8234)
RTOSDF (EIF_REFERENCE,8235)
RTOSDF (EIF_REFERENCE,8238)
RTOSDF (EIF_REFERENCE,8239)
RTOSDF (EIF_REFERENCE,8246)
RTOSDF (EIF_REFERENCE,8420)
RTOSDF (EIF_REFERENCE,8417)
RTOSDF (EIF_REFERENCE,7658)
RTOSDF (EIF_REFERENCE,5886)
RTOSDF (EIF_REFERENCE,5887)
RTOSDF (EIF_REFERENCE,5888)
RTOSDF (EIF_REFERENCE,6718)
RTOSDF (EIF_REFERENCE,6169)
RTOSDF (EIF_REFERENCE,8414)
RTOSDF (EIF_REFERENCE,1167)
RTOSDF (EIF_REFERENCE,1724)
RTOSDF (EIF_REFERENCE,2372)
RTOSDF (EIF_REFERENCE,5830)
RTOSDF (EIF_REFERENCE,482)
RTOSDF (EIF_REFERENCE,483)
RTOSDF (EIF_REFERENCE,484)
RTOSDF (EIF_REFERENCE,3797)
RTOSDF (EIF_REFERENCE,5248)
RTOSDF (EIF_REFERENCE,5249)
RTOSDF (EIF_REFERENCE,5250)
RTOSDF (EIF_REFERENCE,3150)
RTOSDF (EIF_REFERENCE,5454)
RTOSDF (EIF_REFERENCE,5455)
RTOSDF (EIF_REFERENCE,363)
RTOSDF (EIF_REFERENCE,1855)
RTOSDF (EIF_REFERENCE,8411)
RTOSDF (EIF_REFERENCE,4027)
RTOSDF (EIF_REFERENCE,8313)
RTOSDF (EIF_REFERENCE,1536)
RTOSDF (EIF_REFERENCE,8209)
RTOSDF (EIF_REFERENCE,8210)
RTOSDF (EIF_REFERENCE,7991)
RTOSDF (EIF_REFERENCE,7999)
RTOSDF (EIF_REFERENCE,8007)
RTOSDF (EIF_REFERENCE,8011)
RTOSDF (EIF_REFERENCE,8014)
RTOSDF (EIF_REFERENCE,8017)
RTOSDF (EIF_REFERENCE,8018)
RTOSDF (EIF_REFERENCE,8021)
RTOSDF (EIF_REFERENCE,6740)
RTOSDF (EIF_REFERENCE,6741)
RTOSDF (EIF_REFERENCE,1854)
RTOSDF (EIF_REFERENCE,6088)
RTOSDF (EIF_REFERENCE,6135)
RTOSDF (EIF_REFERENCE,6136)
RTOSDF (EIF_REFERENCE,3775)
RTOSDF (EIF_REFERENCE,2101)
RTOSDF (EIF_REFERENCE,2104)
RTOSDF (EIF_REFERENCE,2105)
RTOSDF (EIF_REFERENCE,5958)
RTOSDF (EIF_REFERENCE,1071)
RTOSDF (EIF_REFERENCE,264)
RTOSDF (EIF_REFERENCE,265)
RTOSDF (EIF_REFERENCE,266)
RTOSDF (EIF_REFERENCE,6073)
RTOSDP (4025)
RTOSDF (EIF_REFERENCE,1518)
RTOSDF (EIF_REFERENCE,1471)
RTOSDF (EIF_REFERENCE,2098)
RTOSDF (EIF_REFERENCE,6198)
RTOSDF (EIF_REFERENCE,8408)
RTOSDF (EIF_REFERENCE,8405)
RTOSDF (EIF_REFERENCE,8402)
RTOSDF (EIF_REFERENCE,8399)
RTOSDF (EIF_REFERENCE,8396)
RTOSDF (EIF_REFERENCE,8393)
RTOSDF (EIF_REFERENCE,8390)
RTOSDF (EIF_REFERENCE,8387)
RTOSDF (EIF_REFERENCE,8384)
RTOSDF (EIF_REFERENCE,8381)
RTOSDF (EIF_REFERENCE,8378)
RTOSDF (EIF_REFERENCE,8375)
RTOSDF (EIF_REFERENCE,8372)
RTOSDF (EIF_REFERENCE,8369)
RTOSDF (EIF_REFERENCE,8366)
RTOSDF (EIF_REFERENCE,8363)
RTOSDF (EIF_REFERENCE,8360)
RTOSDF (EIF_REFERENCE,8357)
RTOSDF (EIF_REFERENCE,8354)
RTOSDF (EIF_REFERENCE,8351)
RTOSDF (EIF_REFERENCE,8348)
RTOSDF (EIF_REFERENCE,8345)
RTOSDF (EIF_REFERENCE,8342)
RTOSDF (EIF_REFERENCE,8339)
RTOSDF (EIF_REFERENCE,8336)
RTOSDF (EIF_REFERENCE,8333)
RTOSDF (EIF_REFERENCE,7971)
RTOSDF (EIF_REFERENCE,6686)
RTOSDF (EIF_REFERENCE,3348)
RTOSDF (EIF_REFERENCE,3349)
RTOSDF (EIF_CHARACTER_32,786)
RTOSDF (EIF_REFERENCE,8716)
RTOSDF (EIF_REFERENCE,8739)
RTOSDF (EIF_REFERENCE,8740)
RTOSDF (EIF_REFERENCE,2114)
RTOSDF (EIF_REFERENCE,84)
RTOSDF (EIF_REFERENCE,85)
RTOSDF (EIF_REFERENCE,86)
RTOSDF (EIF_REFERENCE,87)
RTOSDF (EIF_REFERENCE,2941)
RTOSDF (EIF_REFERENCE,5945)
RTOSDF (EIF_REFERENCE,5950)
RTOSDF (EIF_REFERENCE,5937)
RTOSDF (EIF_REFERENCE,5942)
RTOSDF (EIF_REFERENCE,6178)
RTOSDF (EIF_REFERENCE,6192)
RTOSDF (EIF_REFERENCE,6193)
RTOSDF (EIF_REFERENCE,779)
RTOSDF (EIF_REFERENCE,2554)
RTOSDF (EIF_REFERENCE,8330)
RTOSDF (EIF_REFERENCE,8327)
RTOSDF (EIF_REFERENCE,8324)
RTOSDF (EIF_REFERENCE,8321)
RTOSDF (EIF_REFERENCE,8318)
RTOSDF (EIF_REFERENCE,8315)
RTOSDF (EIF_REFERENCE,869)
RTOSDF (EIF_REFERENCE,2904)
RTOSDF (EIF_INTEGER_32,1719)
RTOSDF (EIF_INTEGER_32,1796)
RTOSDF (EIF_REFERENCE,6563)
RTOSDF (EIF_REFERENCE,6564)
RTOSDF (EIF_REFERENCE,6565)
RTOSDF (EIF_REFERENCE,6566)
RTOSDF (EIF_REFERENCE,6567)
RTOSDF (EIF_REFERENCE,6568)
RTOSDF (EIF_REFERENCE,6569)
RTOSDF (EIF_REFERENCE,6570)
RTOSDF (EIF_REFERENCE,6571)
RTOSDF (EIF_REFERENCE,6572)
RTOSDF (EIF_REFERENCE,6573)
RTOSDF (EIF_REFERENCE,6574)
RTOSDF (EIF_REFERENCE,6575)
RTOSDF (EIF_REFERENCE,6576)
RTOSDF (EIF_REFERENCE,6577)
RTOSDF (EIF_REFERENCE,6578)
RTOSDF (EIF_REFERENCE,6579)
RTOSDF (EIF_REFERENCE,6580)
RTOSDF (EIF_REFERENCE,6581)
RTOSDF (EIF_REFERENCE,6582)
RTOSDF (EIF_REFERENCE,6583)
RTOSDF (EIF_REFERENCE,6538)
RTOSDF (EIF_REFERENCE,6539)
RTOSDF (EIF_REFERENCE,6540)
RTOSDF (EIF_REFERENCE,6541)
RTOSDF (EIF_REFERENCE,6542)
RTOSDF (EIF_REFERENCE,6543)
RTOSDF (EIF_REFERENCE,6544)
RTOSDF (EIF_REFERENCE,6545)
RTOSDF (EIF_REFERENCE,6546)
RTOSDF (EIF_REFERENCE,6547)
RTOSDF (EIF_REFERENCE,6548)
RTOSDF (EIF_REFERENCE,6549)
RTOSDF (EIF_REFERENCE,6550)
RTOSDF (EIF_REFERENCE,6551)
RTOSDF (EIF_REFERENCE,6552)
RTOSDF (EIF_REFERENCE,6553)
RTOSDF (EIF_REFERENCE,6554)
RTOSDF (EIF_REFERENCE,6555)
RTOSDF (EIF_REFERENCE,6556)
RTOSDF (EIF_REFERENCE,6557)
RTOSDF (EIF_REFERENCE,6558)
RTOSDF (EIF_REFERENCE,6559)
RTOSDF (EIF_REFERENCE,6379)

extern void egc_system_mod_init_init(void);
void egc_system_mod_init_init (void)
{
	egc_type_of_gc = 123174;
	EIF_Minit1();
	EIF_Minit6();
	EIF_Minit8();
	EIF_Minit13();
	EIF_Minit16();
	EIF_Minit1165();
	EIF_Minit787();
	EIF_Minit554();
	EIF_Minit708();
	EIF_Minit709();
	EIF_Minit1158();
	EIF_Minit1161();
	EIF_Minit17();
	EIF_Minit21();
	EIF_Minit20();
	EIF_Minit22();
	EIF_Minit24();
	EIF_Minit25();
	EIF_Minit38();
	EIF_Minit39();
	EIF_Minit40();
	EIF_Minit1153();
	EIF_Minit1163();
	EIF_Minit1152();
	EIF_Minit1162();
	EIF_Minit41();
	EIF_Minit48();
	EIF_Minit50();
	EIF_Minit53();
	EIF_Minit58();
	EIF_Minit385();
	EIF_Minit773();
	EIF_Minit774();
	EIF_Minit775();
	EIF_Minit60();
	EIF_Minit771();
	EIF_Minit884();
	EIF_Minit770();
	EIF_Minit763();
	EIF_Minit896();
	EIF_Minit75();
	EIF_Minit76();
	EIF_Minit77();
	EIF_Minit78();
	EIF_Minit80();
	EIF_Minit1138();
	EIF_Minit81();
	EIF_Minit82();
	EIF_Minit83();
	EIF_Minit84();
	EIF_Minit85();
	EIF_Minit87();
	EIF_Minit89();
	EIF_Minit90();
	EIF_Minit91();
	EIF_Minit92();
	EIF_Minit93();
	EIF_Minit94();
	EIF_Minit95();
	EIF_Minit96();
	EIF_Minit97();
	EIF_Minit98();
	EIF_Minit100();
	EIF_Minit101();
	EIF_Minit103();
	EIF_Minit107();
	EIF_Minit108();
	EIF_Minit109();
	EIF_Minit110();
	EIF_Minit111();
	EIF_Minit112();
	EIF_Minit116();
	EIF_Minit118();
	EIF_Minit119();
	EIF_Minit120();
	EIF_Minit122();
	EIF_Minit123();
	EIF_Minit126();
	EIF_Minit127();
	EIF_Minit129();
	EIF_Minit130();
	EIF_Minit131();
	EIF_Minit133();
	EIF_Minit134();
	EIF_Minit135();
	EIF_Minit136();
	EIF_Minit138();
	EIF_Minit139();
	EIF_Minit141();
	EIF_Minit142();
	EIF_Minit143();
	EIF_Minit145();
	EIF_Minit146();
	EIF_Minit147();
	EIF_Minit148();
	EIF_Minit149();
	EIF_Minit150();
	EIF_Minit152();
	EIF_Minit153();
	EIF_Minit383();
	EIF_Minit493();
	EIF_Minit600();
	EIF_Minit650();
	EIF_Minit778();
	EIF_Minit1168();
	EIF_Minit777();
	EIF_Minit1167();
	EIF_Minit155();
	EIF_Minit158();
	EIF_Minit433();
	EIF_Minit470();
	EIF_Minit516();
	EIF_Minit575();
	EIF_Minit622();
	EIF_Minit678();
	EIF_Minit734();
	EIF_Minit809();
	EIF_Minit832();
	EIF_Minit992();
	EIF_Minit1031();
	EIF_Minit1067();
	EIF_Minit163();
	EIF_Minit164();
	EIF_Minit165();
	EIF_Minit168();
	EIF_Minit170();
	EIF_Minit172();
	EIF_Minit173();
	EIF_Minit174();
	EIF_Minit175();
	EIF_Minit182();
	EIF_Minit184();
	EIF_Minit185();
	EIF_Minit406();
	EIF_Minit461();
	EIF_Minit499();
	EIF_Minit571();
	EIF_Minit605();
	EIF_Minit674();
	EIF_Minit717();
	EIF_Minit790();
	EIF_Minit836();
	EIF_Minit976();
	EIF_Minit1027();
	EIF_Minit1063();
	EIF_Minit443();
	EIF_Minit490();
	EIF_Minit781();
	EIF_Minit1105();
	EIF_Minit1101();
	EIF_Minit389();
	EIF_Minit451();
	EIF_Minit507();
	EIF_Minit560();
	EIF_Minit613();
	EIF_Minit665();
	EIF_Minit725();
	EIF_Minit800();
	EIF_Minit844();
	EIF_Minit983();
	EIF_Minit1016();
	EIF_Minit1052();
	EIF_Minit825();
	EIF_Minit188();
	EIF_Minit408();
	EIF_Minit463();
	EIF_Minit514();
	EIF_Minit573();
	EIF_Minit620();
	EIF_Minit676();
	EIF_Minit732();
	EIF_Minit807();
	EIF_Minit851();
	EIF_Minit990();
	EIF_Minit1029();
	EIF_Minit1065();
	EIF_Minit440();
	EIF_Minit474();
	EIF_Minit520();
	EIF_Minit583();
	EIF_Minit626();
	EIF_Minit686();
	EIF_Minit738();
	EIF_Minit813();
	EIF_Minit856();
	EIF_Minit996();
	EIF_Minit1039();
	EIF_Minit1075();
	EIF_Minit189();
	EIF_Minit191();
	EIF_Minit434();
	EIF_Minit465();
	EIF_Minit496();
	EIF_Minit576();
	EIF_Minit602();
	EIF_Minit679();
	EIF_Minit721();
	EIF_Minit796();
	EIF_Minit833();
	EIF_Minit973();
	EIF_Minit1032();
	EIF_Minit1068();
	EIF_Minit438();
	EIF_Minit469();
	EIF_Minit506();
	EIF_Minit559();
	EIF_Minit612();
	EIF_Minit664();
	EIF_Minit724();
	EIF_Minit799();
	EIF_Minit843();
	EIF_Minit982();
	EIF_Minit1015();
	EIF_Minit1051();
	EIF_Minit752();
	EIF_Minit540();
	EIF_Minit595();
	EIF_Minit648();
	EIF_Minit698();
	EIF_Minit1160();
	EIF_Minit193();
	EIF_Minit195();
	EIF_Minit444();
	EIF_Minit449();
	EIF_Minit782();
	EIF_Minit1102();
	EIF_Minit1098();
	EIF_Minit196();
	EIF_Minit197();
	EIF_Minit200();
	EIF_Minit384();
	EIF_Minit386();
	EIF_Minit396();
	EIF_Minit415();
	EIF_Minit416();
	EIF_Minit417();
	EIF_Minit418();
	EIF_Minit419();
	EIF_Minit420();
	EIF_Minit421();
	EIF_Minit422();
	EIF_Minit423();
	EIF_Minit424();
	EIF_Minit425();
	EIF_Minit426();
	EIF_Minit427();
	EIF_Minit776();
	EIF_Minit901();
	EIF_Minit905();
	EIF_Minit909();
	EIF_Minit913();
	EIF_Minit917();
	EIF_Minit921();
	EIF_Minit925();
	EIF_Minit929();
	EIF_Minit933();
	EIF_Minit937();
	EIF_Minit941();
	EIF_Minit945();
	EIF_Minit949();
	EIF_Minit1014();
	EIF_Minit201();
	EIF_Minit202();
	EIF_Minit204();
	EIF_Minit203();
	EIF_Minit205();
	EIF_Minit207();
	EIF_Minit206();
	EIF_Minit208();
	EIF_Minit210();
	EIF_Minit209();
	EIF_Minit211();
	EIF_Minit213();
	EIF_Minit212();
	EIF_Minit214();
	EIF_Minit216();
	EIF_Minit215();
	EIF_Minit217();
	EIF_Minit219();
	EIF_Minit218();
	EIF_Minit220();
	EIF_Minit222();
	EIF_Minit221();
	EIF_Minit223();
	EIF_Minit225();
	EIF_Minit224();
	EIF_Minit226();
	EIF_Minit228();
	EIF_Minit227();
	EIF_Minit229();
	EIF_Minit231();
	EIF_Minit230();
	EIF_Minit232();
	EIF_Minit234();
	EIF_Minit233();
	EIF_Minit235();
	EIF_Minit237();
	EIF_Minit236();
	EIF_Minit238();
	EIF_Minit240();
	EIF_Minit239();
	EIF_Minit241();
	EIF_Minit243();
	EIF_Minit242();
	EIF_Minit244();
	EIF_Minit246();
	EIF_Minit247();
	EIF_Minit248();
	EIF_Minit249();
	EIF_Minit250();
	EIF_Minit251();
	EIF_Minit252();
	EIF_Minit254();
	EIF_Minit258();
	EIF_Minit259();
	EIF_Minit261();
	EIF_Minit264();
	EIF_Minit265();
	EIF_Minit266();
	EIF_Minit269();
	EIF_Minit273();
	EIF_Minit751();
	EIF_Minit539();
	EIF_Minit557();
	EIF_Minit647();
	EIF_Minit663();
	EIF_Minit1159();
	EIF_Minit274();
	EIF_Minit275();
	EIF_Minit276();
	EIF_Minit277();
	EIF_Minit278();
	EIF_Minit280();
	EIF_Minit281();
	EIF_Minit282();
	EIF_Minit286();
	EIF_Minit287();
	EIF_Minit288();
	EIF_Minit290();
	EIF_Minit291();
	EIF_Minit292();
	EIF_Minit294();
	EIF_Minit295();
	EIF_Minit296();
	EIF_Minit298();
	EIF_Minit304();
	EIF_Minit305();
	EIF_Minit306();
	EIF_Minit310();
	EIF_Minit311();
	EIF_Minit758();
	EIF_Minit536();
	EIF_Minit642();
	EIF_Minit660();
	EIF_Minit757();
	EIF_Minit535();
	EIF_Minit641();
	EIF_Minit657();
	EIF_Minit766();
	EIF_Minit534();
	EIF_Minit640();
	EIF_Minit656();
	EIF_Minit1120();
	EIF_Minit876();
	EIF_Minit967();
	EIF_Minit548();
	EIF_Minit702();
	EIF_Minit1117();
	EIF_Minit952();
	EIF_Minit1143();
	EIF_Minit871();
	EIF_Minit962();
	EIF_Minit542();
	EIF_Minit652();
	EIF_Minit1151();
	EIF_Minit882();
	EIF_Minit972();
	EIF_Minit556();
	EIF_Minit596();
	EIF_Minit886();
	EIF_Minit889();
	EIF_Minit772();
	EIF_Minit760();
	EIF_Minit494();
	EIF_Minit601();
	EIF_Minit644();
	EIF_Minit764();
	EIF_Minit897();
	EIF_Minit759();
	EIF_Minit537();
	EIF_Minit643();
	EIF_Minit661();
	EIF_Minit761();
	EIF_Minit492();
	EIF_Minit599();
	EIF_Minit649();
	EIF_Minit750();
	EIF_Minit887();
	EIF_Minit550();
	EIF_Minit704();
	EIF_Minit1008();
	EIF_Minit885();
	EIF_Minit888();
	EIF_Minit1121();
	EIF_Minit877();
	EIF_Minit968();
	EIF_Minit549();
	EIF_Minit703();
	EIF_Minit1122();
	EIF_Minit955();
	EIF_Minit1125();
	EIF_Minit958();
	EIF_Minit1116();
	EIF_Minit951();
	EIF_Minit1142();
	EIF_Minit870();
	EIF_Minit961();
	EIF_Minit541();
	EIF_Minit651();
	EIF_Minit1149();
	EIF_Minit879();
	EIF_Minit970();
	EIF_Minit552();
	EIF_Minit706();
	EIF_Minit1140();
	EIF_Minit868();
	EIF_Minit959();
	EIF_Minit491();
	EIF_Minit598();
	EIF_Minit318();
	EIF_Minit319();
	EIF_Minit320();
	EIF_Minit328();
	EIF_Minit331();
	EIF_Minit332();
	EIF_Minit333();
	EIF_Minit334();
	EIF_Minit335();
	EIF_Minit336();
	EIF_Minit337();
	EIF_Minit338();
	EIF_Minit339();
	EIF_Minit340();
	EIF_Minit341();
	EIF_Minit342();
	EIF_Minit343();
	EIF_Minit344();
	EIF_Minit345();
	EIF_Minit346();
	EIF_Minit347();
	EIF_Minit348();
	EIF_Minit349();
	EIF_Minit350();
	EIF_Minit351();
	EIF_Minit352();
	EIF_Minit353();
	EIF_Minit354();
	EIF_Minit355();
	EIF_Minit356();
	EIF_Minit357();
	EIF_Minit358();
	EIF_Minit359();
	EIF_Minit360();
	EIF_Minit361();
	EIF_Minit362();
	EIF_Minit363();
	EIF_Minit364();
	EIF_Minit365();
	EIF_Minit366();
	EIF_Minit367();
	EIF_Minit368();
	EIF_Minit369();
	EIF_Minit370();
	EIF_Minit371();
	EIF_Minit372();
	EIF_Minit373();
	EIF_Minit374();
	EIF_Minit375();
	EIF_Minit381();
}

#ifdef __cplusplus
}
#endif
