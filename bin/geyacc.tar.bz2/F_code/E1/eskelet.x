#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names2[];
static const uint32 types2 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags2 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype2_0 [] = {1108,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_4 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_5 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_6 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_7 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes2 [] = {
g_atype2_0,
g_atype2_1,
g_atype2_2,
g_atype2_3,
g_atype2_4,
g_atype2_5,
g_atype2_6,
g_atype2_7,
};

static const long offsets2 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I64OFF(1,3,0,0,0,0,0),
+ @I64OFF(1,3,0,0,0,0,1),
+ @I64OFF(1,3,0,0,0,0,2),
+ @I64OFF(1,3,0,0,0,0,3),
};

extern const char *names4[];
static const uint32 types4 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags4 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype4_0 [] = {0xFF01,766,880,0xFF01,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype4_1 [] = {0xFF01,765,0xFF01,892,0xFF01,892,0xFFFF};

static const EIF_TYPE_INDEX *gtypes4 [] = {
g_atype4_0,
g_atype4_1,
};

static const long offsets4 [] =
{
0,
 + @REFACS(1),
};

extern const char *names5[];
static const uint32 types5 [] =
{
SK_UINT32,
};

static const uint16 attr_flags5 [] =
{1,};

static const EIF_TYPE_INDEX g_atype5_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes5 [] = {
g_atype5_0,
};

static const long offsets5 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names9[];
static const uint32 types9 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags9 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype9_0 [] = {0xFF01,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_1 [] = {0xFF01,953,0xFFFF};

static const EIF_TYPE_INDEX *gtypes9 [] = {
g_atype9_0,
g_atype9_1,
};

static const long offsets9 [] =
{
0,
 + @REFACS(1),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags27 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {0xFF01,1081,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_1 [] = {0xFF01,901,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
g_atype27_1,
};

static const long offsets27 [] =
{
0,
 + @REFACS(1),
};

extern const char *names29[];
static const uint32 types29 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags29 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype29_0 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes29 [] = {
g_atype29_0,
g_atype29_1,
g_atype29_2,
g_atype29_3,
};

static const long offsets29 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_REF,
};

static const uint16 attr_flags46 [] =
{0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {643,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
};

static const long offsets46 [] =
{
0,
};

extern const char *names47[];
static const uint32 types47 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags47 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype47_0 [] = {0xFF01,925,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_1 [] = {0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_2 [] = {0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_3 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes47 [] = {
g_atype47_0,
g_atype47_1,
g_atype47_2,
g_atype47_3,
};

static const long offsets47 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags62 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {882,0xFF01,0xFFF9,1,808,0xFF01,222,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_2 [] = {882,0xFF01,0xFFF9,2,808,0xFF01,222,0xFF01,222,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_3 [] = {882,0xFF01,0xFFF9,1,808,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_4 [] = {753,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_5 [] = {769,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_11 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
g_atype62_2,
g_atype62_3,
g_atype62_4,
g_atype62_5,
g_atype62_6,
g_atype62_7,
g_atype62_8,
g_atype62_9,
g_atype62_10,
g_atype62_11,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names63[];
static const uint32 types63 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags63 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype63_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_1 [] = {882,0xFF01,0xFFF9,1,808,0xFF01,222,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_2 [] = {882,0xFF01,0xFFF9,2,808,0xFF01,222,0xFF01,222,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_3 [] = {882,0xFF01,0xFFF9,1,808,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_4 [] = {753,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_5 [] = {769,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_11 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes63 [] = {
g_atype63_0,
g_atype63_1,
g_atype63_2,
g_atype63_3,
g_atype63_4,
g_atype63_5,
g_atype63_6,
g_atype63_7,
g_atype63_8,
g_atype63_9,
g_atype63_10,
g_atype63_11,
};

static const long offsets63 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
};

static const uint16 attr_flags70 [] =
{0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {0xFF01,118,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
};

static const long offsets70 [] =
{
0,
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_REF,
};

static const uint16 attr_flags71 [] =
{0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {0xFF01,119,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
};

static const long offsets71 [] =
{
0,
};

extern const char *names72[];
static const uint32 types72 [] =
{
SK_REF,
};

static const uint16 attr_flags72 [] =
{0,};

static const EIF_TYPE_INDEX g_atype72_0 [] = {0xFF01,118,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes72 [] = {
g_atype72_0,
};

static const long offsets72 [] =
{
0,
};

extern const char *names73[];
static const uint32 types73 [] =
{
SK_REF,
};

static const uint16 attr_flags73 [] =
{0,};

static const EIF_TYPE_INDEX g_atype73_0 [] = {0xFF01,119,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes73 [] = {
g_atype73_0,
};

static const long offsets73 [] =
{
0,
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
};

static const uint16 attr_flags77 [] =
{0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
};

static const long offsets77 [] =
{
0,
};

extern const char *names78[];
static const uint32 types78 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags78 [] =
{0,};

static const EIF_TYPE_INDEX g_atype78_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes78 [] = {
g_atype78_0,
};

static const long offsets78 [] =
{
+ @CHROFF(0,0),
};

extern const char *names79[];
static const uint32 types79 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags79 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype79_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_1 [] = {78,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes79 [] = {
g_atype79_0,
g_atype79_1,
};

static const long offsets79 [] =
{
0,
 + @REFACS(1),
};

extern const char *names80[];
static const uint32 types80 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags80 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype80_0 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_1 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes80 [] = {
g_atype80_0,
g_atype80_1,
};

static const long offsets80 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags95 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_1 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_2 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_3 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_4 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_5 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_6 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_7 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_8 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_9 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_15 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
g_atype95_1,
g_atype95_2,
g_atype95_3,
g_atype95_4,
g_atype95_5,
g_atype95_6,
g_atype95_7,
g_atype95_8,
g_atype95_9,
g_atype95_10,
g_atype95_11,
g_atype95_12,
g_atype95_13,
g_atype95_14,
g_atype95_15,
};

static const long offsets95 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
};

static const uint16 attr_flags100 [] =
{0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
};

static const long offsets100 [] =
{
0,
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_UINT64,
};

static const uint16 attr_flags101 [] =
{0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
};

static const long offsets101 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_INT32,
};

static const uint16 attr_flags102 [] =
{0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
};

static const long offsets102 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags103 [] =
{0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
};

static const long offsets103 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags104 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_1 [] = {103,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
g_atype104_1,
};

static const long offsets104 [] =
{
0,
 + @REFACS(1),
};

extern const char *names105[];
static const uint32 types105 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags105 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype105_0 [] = {104,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes105 [] = {
g_atype105_0,
g_atype105_1,
};

static const long offsets105 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
};

static const uint16 attr_flags112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
};

static const long offsets112 [] =
{
0,
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags113 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
};

static const long offsets113 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags114 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_1 [] = {113,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
g_atype114_1,
};

static const long offsets114 [] =
{
0,
 + @REFACS(1),
};

extern const char *names121[];
static const uint32 types121 [] =
{
SK_REF,
};

static const uint16 attr_flags121 [] =
{0,};

static const EIF_TYPE_INDEX g_atype121_0 [] = {0xFF01,118,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes121 [] = {
g_atype121_0,
};

static const long offsets121 [] =
{
0,
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
};

static const uint16 attr_flags122 [] =
{0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {0xFF01,119,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
};

static const long offsets122 [] =
{
0,
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags127 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {656,0xFF01,658,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags128 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {656,0xFF01,658,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags129 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {656,0xFF01,658,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
};

extern const char *names131[];
static const uint32 types131 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags131 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype131_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_1 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_2 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_3 [] = {0xFF01,661,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes131 [] = {
g_atype131_0,
g_atype131_1,
g_atype131_2,
g_atype131_3,
};

static const long offsets131 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags132 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
g_atype132_1,
g_atype132_2,
g_atype132_3,
g_atype132_4,
g_atype132_5,
g_atype132_6,
};

static const long offsets132 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags133 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_9 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_10 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
g_atype133_1,
g_atype133_2,
g_atype133_3,
g_atype133_4,
g_atype133_5,
g_atype133_6,
g_atype133_7,
g_atype133_8,
g_atype133_9,
g_atype133_10,
};

static const long offsets133 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags134 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_12 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_13 [] = {838,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_14 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
g_atype134_1,
g_atype134_2,
g_atype134_3,
g_atype134_4,
g_atype134_5,
g_atype134_6,
g_atype134_7,
g_atype134_8,
g_atype134_9,
g_atype134_10,
g_atype134_11,
g_atype134_12,
g_atype134_13,
g_atype134_14,
};

static const long offsets134 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags135 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_8 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_9 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
g_atype135_2,
g_atype135_3,
g_atype135_4,
g_atype135_5,
g_atype135_6,
g_atype135_7,
g_atype135_8,
g_atype135_9,
};

static const long offsets135 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_INT32,
};

static const uint16 attr_flags136 [] =
{0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
};

static const long offsets136 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags137 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {0xFF01,925,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {0xFF01,925,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_2 [] = {0xFF01,1076,0xFF01,136,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_3 [] = {0xFF01,1076,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
g_atype137_2,
g_atype137_3,
g_atype137_4,
};

static const long offsets137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {0xFF01,1081,0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {0xFF01,1076,0xFF01,136,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_4 [] = {0xFF01,1076,0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_5 [] = {0xFF01,1076,0xFF01,139,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
g_atype140_4,
g_atype140_5,
g_atype140_6,
g_atype140_7,
g_atype140_8,
g_atype140_9,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @LNGOFF(6,2,0,1),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_8 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
g_atype141_6,
g_atype141_7,
g_atype141_8,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @LNGOFF(3,2,0,2),
+ @LNGOFF(3,2,0,3),
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags145 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {0xFF01,1082,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_1 [] = {0xFF01,1082,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
g_atype145_1,
g_atype145_2,
g_atype145_3,
g_atype145_4,
g_atype145_5,
g_atype145_6,
};

static const long offsets145 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags146 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {0xFF01,1081,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {0xFF01,1076,0xFF01,136,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
};

static const long offsets146 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags147 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {0xFF01,139,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {0xFF01,1081,0xFF01,138,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {0xFF01,1081,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_3 [] = {0xFF01,95,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_8 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
g_atype147_3,
g_atype147_4,
g_atype147_5,
g_atype147_6,
g_atype147_7,
g_atype147_8,
};

static const long offsets147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags151 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
};

static const long offsets151 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags152 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
};

static const long offsets152 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags153 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
};

static const long offsets153 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
g_atype154_5,
g_atype154_6,
g_atype154_7,
g_atype154_8,
g_atype154_9,
};

static const long offsets154 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
g_atype155_5,
g_atype155_6,
g_atype155_7,
g_atype155_8,
g_atype155_9,
};

static const long offsets155 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {0xFF01,249,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
g_atype156_3,
g_atype156_4,
g_atype156_5,
g_atype156_6,
g_atype156_7,
g_atype156_8,
g_atype156_9,
};

static const long offsets156 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_11 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
g_atype157_5,
g_atype157_6,
g_atype157_7,
g_atype157_8,
g_atype157_9,
g_atype157_10,
g_atype157_11,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags158 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_13 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
g_atype158_2,
g_atype158_3,
g_atype158_4,
g_atype158_5,
g_atype158_6,
g_atype158_7,
g_atype158_8,
g_atype158_9,
g_atype158_10,
g_atype158_11,
g_atype158_12,
g_atype158_13,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names159[];
static const uint32 types159 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags159 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype159_0 [] = {0xFF01,249,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_1 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_14 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes159 [] = {
g_atype159_0,
g_atype159_1,
g_atype159_2,
g_atype159_3,
g_atype159_4,
g_atype159_5,
g_atype159_6,
g_atype159_7,
g_atype159_8,
g_atype159_9,
g_atype159_10,
g_atype159_11,
g_atype159_12,
g_atype159_13,
g_atype159_14,
};

static const long offsets159 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names161[];
static const uint32 types161 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags161 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype161_0 [] = {103,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes161 [] = {
g_atype161_0,
g_atype161_1,
g_atype161_2,
};

static const long offsets161 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags162 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {104,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
g_atype162_1,
g_atype162_2,
};

static const long offsets162 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
};

static const long offsets163 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_INT32,
};

static const uint16 attr_flags164 [] =
{0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
};

static const long offsets164 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags169 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
g_atype169_3,
g_atype169_4,
g_atype169_5,
g_atype169_6,
};

static const long offsets169 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags170 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
g_atype170_3,
g_atype170_4,
g_atype170_5,
g_atype170_6,
};

static const long offsets170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags171 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
g_atype171_3,
g_atype171_4,
g_atype171_5,
g_atype171_6,
};

static const long offsets171 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags172 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
g_atype172_1,
g_atype172_2,
g_atype172_3,
g_atype172_4,
g_atype172_5,
g_atype172_6,
};

static const long offsets172 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
g_atype173_3,
g_atype173_4,
g_atype173_5,
g_atype173_6,
};

static const long offsets173 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags174 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
g_atype174_1,
g_atype174_2,
g_atype174_3,
g_atype174_4,
g_atype174_5,
g_atype174_6,
};

static const long offsets174 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
g_atype175_1,
g_atype175_2,
g_atype175_3,
g_atype175_4,
g_atype175_5,
g_atype175_6,
};

static const long offsets175 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags176 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
g_atype176_1,
g_atype176_2,
g_atype176_3,
g_atype176_4,
g_atype176_5,
g_atype176_6,
g_atype176_7,
};

static const long offsets176 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags177 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
g_atype177_2,
g_atype177_3,
g_atype177_4,
g_atype177_5,
g_atype177_6,
g_atype177_7,
g_atype177_8,
g_atype177_9,
};

static const long offsets177 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags178 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
g_atype178_2,
g_atype178_3,
g_atype178_4,
g_atype178_5,
g_atype178_6,
g_atype178_7,
};

static const long offsets178 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags179 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
g_atype179_2,
g_atype179_3,
g_atype179_4,
g_atype179_5,
g_atype179_6,
};

static const long offsets179 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
g_atype180_4,
g_atype180_5,
g_atype180_6,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
g_atype181_6,
g_atype181_7,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
g_atype182_6,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
g_atype183_6,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags184 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
g_atype184_2,
g_atype184_3,
g_atype184_4,
g_atype184_5,
g_atype184_6,
g_atype184_7,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
g_atype185_6,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
g_atype186_6,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
g_atype187_6,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
g_atype188_6,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags189 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_8 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
g_atype189_1,
g_atype189_2,
g_atype189_3,
g_atype189_4,
g_atype189_5,
g_atype189_6,
g_atype189_7,
g_atype189_8,
};

static const long offsets189 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
g_atype190_4,
g_atype190_5,
g_atype190_6,
};

static const long offsets190 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags191 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
g_atype191_3,
g_atype191_4,
g_atype191_5,
g_atype191_6,
};

static const long offsets191 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags192 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_8 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
g_atype192_1,
g_atype192_2,
g_atype192_3,
g_atype192_4,
g_atype192_5,
g_atype192_6,
g_atype192_7,
g_atype192_8,
};

static const long offsets192 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags193 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
g_atype193_1,
g_atype193_2,
g_atype193_3,
g_atype193_4,
g_atype193_5,
g_atype193_6,
};

static const long offsets193 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags194 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
g_atype194_2,
g_atype194_3,
g_atype194_4,
g_atype194_5,
g_atype194_6,
};

static const long offsets194 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags195 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
g_atype195_1,
g_atype195_2,
g_atype195_3,
g_atype195_4,
g_atype195_5,
g_atype195_6,
};

static const long offsets195 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags196 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
g_atype196_1,
g_atype196_2,
g_atype196_3,
g_atype196_4,
g_atype196_5,
g_atype196_6,
};

static const long offsets196 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags197 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
g_atype197_1,
g_atype197_2,
g_atype197_3,
g_atype197_4,
g_atype197_5,
g_atype197_6,
};

static const long offsets197 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags198 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
g_atype198_1,
g_atype198_2,
g_atype198_3,
g_atype198_4,
g_atype198_5,
g_atype198_6,
};

static const long offsets198 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags199 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
g_atype199_2,
g_atype199_3,
g_atype199_4,
g_atype199_5,
g_atype199_6,
};

static const long offsets199 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
g_atype200_3,
g_atype200_4,
g_atype200_5,
g_atype200_6,
};

static const long offsets200 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
g_atype201_4,
g_atype201_5,
g_atype201_6,
};

static const long offsets201 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags202 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
g_atype202_1,
g_atype202_2,
g_atype202_3,
g_atype202_4,
g_atype202_5,
g_atype202_6,
};

static const long offsets202 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
g_atype203_5,
g_atype203_6,
};

static const long offsets203 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags204 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
g_atype204_3,
g_atype204_4,
g_atype204_5,
g_atype204_6,
};

static const long offsets204 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
g_atype205_4,
g_atype205_5,
g_atype205_6,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
g_atype206_5,
g_atype206_6,
g_atype206_7,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
g_atype207_5,
g_atype207_6,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {168,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {251,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
g_atype208_5,
g_atype208_6,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names210[];
static const uint32 types210 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags210 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype210_0 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_2 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_3 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes210 [] = {
g_atype210_0,
g_atype210_1,
g_atype210_2,
g_atype210_3,
};

static const long offsets210 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names223[];
static const uint32 types223 [] =
{
SK_INT32,
};

static const uint16 attr_flags223 [] =
{0,};

static const EIF_TYPE_INDEX g_atype223_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes223 [] = {
g_atype223_0,
};

static const long offsets223 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags227 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {0xFF01,222,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
g_atype227_2,
g_atype227_3,
};

static const long offsets227 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags228 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
g_atype228_1,
g_atype228_2,
};

static const long offsets228 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names229[];
static const uint32 types229 [] =
{
SK_REF,
};

static const uint16 attr_flags229 [] =
{0,};

static const EIF_TYPE_INDEX g_atype229_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes229 [] = {
g_atype229_0,
};

static const long offsets229 [] =
{
0,
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
};

static const uint16 attr_flags230 [] =
{0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {0xFF01,657,880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
};

static const long offsets230 [] =
{
0,
};

extern const char *names231[];
static const uint32 types231 [] =
{
SK_REF,
};

static const uint16 attr_flags231 [] =
{0,};

static const EIF_TYPE_INDEX g_atype231_0 [] = {0xFF01,658,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes231 [] = {
g_atype231_0,
};

static const long offsets231 [] =
{
0,
};

extern const char *names232[];
static const uint32 types232 [] =
{
SK_REF,
};

static const uint16 attr_flags232 [] =
{0,};

static const EIF_TYPE_INDEX g_atype232_0 [] = {0xFF01,659,847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes232 [] = {
g_atype232_0,
};

static const long offsets232 [] =
{
0,
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
};

static const uint16 attr_flags233 [] =
{0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {0xFF01,660,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
};

static const long offsets233 [] =
{
0,
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
};

static const uint16 attr_flags234 [] =
{0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {0xFF01,661,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
};

static const long offsets234 [] =
{
0,
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
};

static const uint16 attr_flags235 [] =
{0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {0xFF01,662,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
};

static const long offsets235 [] =
{
0,
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
};

static const uint16 attr_flags236 [] =
{0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {0xFF01,663,841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
};

static const long offsets236 [] =
{
0,
};

extern const char *names237[];
static const uint32 types237 [] =
{
SK_REF,
};

static const uint16 attr_flags237 [] =
{0,};

static const EIF_TYPE_INDEX g_atype237_0 [] = {0xFF01,664,832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes237 [] = {
g_atype237_0,
};

static const long offsets237 [] =
{
0,
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
};

static const uint16 attr_flags238 [] =
{0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {0xFF01,665,829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
};

static const long offsets238 [] =
{
0,
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
};

static const uint16 attr_flags239 [] =
{0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {0xFF01,666,835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
};

static const long offsets239 [] =
{
0,
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
};

static const uint16 attr_flags240 [] =
{0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {0xFF01,667,838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
};

static const long offsets240 [] =
{
0,
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags243 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {0xFF01,209,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
};

static const long offsets243 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_INT32,
};

static const uint16 attr_flags244 [] =
{0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
};

static const long offsets244 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags245 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_4 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_5 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
g_atype245_3,
g_atype245_4,
g_atype245_5,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_4 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
g_atype246_4,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags247 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_4 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
g_atype247_3,
g_atype247_4,
};

static const long offsets247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags251 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_1 [] = {0xFF01,662,844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
g_atype251_1,
};

static const long offsets251 [] =
{
0,
 + @REFACS(1),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags252 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {0xFF01,209,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
g_atype252_1,
};

static const long offsets252 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names253[];
static const uint32 types253 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags253 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype253_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_3 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_4 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_5 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_6 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_9 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_10 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_11 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_12 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes253 [] = {
g_atype253_0,
g_atype253_1,
g_atype253_2,
g_atype253_3,
g_atype253_4,
g_atype253_5,
g_atype253_6,
g_atype253_7,
g_atype253_8,
g_atype253_9,
g_atype253_10,
g_atype253_11,
g_atype253_12,
};

static const long offsets253 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names255[];
static const uint32 types255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags255 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype255_0 [] = {0xFF01,1111,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_2 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_3 [] = {254,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_4 [] = {0xFF01,756,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_5 [] = {753,254,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_6 [] = {753,0xFF01,256,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_7 [] = {0xFF01,0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_14 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes255 [] = {
g_atype255_0,
g_atype255_1,
g_atype255_2,
g_atype255_3,
g_atype255_4,
g_atype255_5,
g_atype255_6,
g_atype255_7,
g_atype255_8,
g_atype255_9,
g_atype255_10,
g_atype255_11,
g_atype255_12,
g_atype255_13,
g_atype255_14,
};

static const long offsets255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags257 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
g_atype257_1,
g_atype257_2,
};

static const long offsets257 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags258 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
g_atype258_2,
g_atype258_3,
g_atype258_4,
};

static const long offsets258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags259 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_2 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
g_atype259_1,
g_atype259_2,
g_atype259_3,
g_atype259_4,
};

static const long offsets259 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names260[];
static const uint32 types260 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags260 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype260_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_2 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes260 [] = {
g_atype260_0,
g_atype260_1,
g_atype260_2,
g_atype260_3,
g_atype260_4,
};

static const long offsets260 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
g_atype261_1,
g_atype261_2,
g_atype261_3,
g_atype261_4,
};

static const long offsets261 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags262 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_4 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
g_atype262_2,
g_atype262_3,
g_atype262_4,
};

static const long offsets262 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags263 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
};

static const long offsets263 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags264 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
g_atype264_3,
g_atype264_4,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags265 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
g_atype265_2,
g_atype265_3,
g_atype265_4,
};

static const long offsets265 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags266 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_4 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
g_atype266_1,
g_atype266_2,
g_atype266_3,
g_atype266_4,
};

static const long offsets266 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags267 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_4 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
g_atype267_1,
g_atype267_2,
g_atype267_3,
g_atype267_4,
};

static const long offsets267 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names268[];
static const uint32 types268 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags268 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype268_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_4 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes268 [] = {
g_atype268_0,
g_atype268_1,
g_atype268_2,
g_atype268_3,
g_atype268_4,
};

static const long offsets268 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names269[];
static const uint32 types269 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags269 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype269_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes269 [] = {
g_atype269_0,
g_atype269_1,
g_atype269_2,
g_atype269_3,
g_atype269_4,
};

static const long offsets269 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags270 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags271 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_4 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
g_atype271_2,
g_atype271_3,
g_atype271_4,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags272 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_2 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
g_atype272_2,
g_atype272_3,
g_atype272_4,
};

static const long offsets272 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags273 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
g_atype273_2,
g_atype273_3,
g_atype273_4,
g_atype273_5,
};

static const long offsets273 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags274 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
g_atype274_3,
g_atype274_4,
g_atype274_5,
};

static const long offsets274 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags275 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_5 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
g_atype275_3,
g_atype275_4,
g_atype275_5,
};

static const long offsets275 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
g_atype276_3,
g_atype276_4,
g_atype276_5,
};

static const long offsets276 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags277 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_1 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
g_atype277_1,
g_atype277_2,
g_atype277_3,
g_atype277_4,
g_atype277_5,
};

static const long offsets277 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags278 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
g_atype278_3,
g_atype278_4,
g_atype278_5,
};

static const long offsets278 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags279 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_5 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
g_atype279_3,
g_atype279_4,
g_atype279_5,
};

static const long offsets279 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags280 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
g_atype280_2,
g_atype280_3,
g_atype280_4,
g_atype280_5,
};

static const long offsets280 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags281 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
g_atype281_2,
g_atype281_3,
g_atype281_4,
g_atype281_5,
};

static const long offsets281 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
g_atype282_4,
g_atype282_5,
};

static const long offsets282 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags283 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_5 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
g_atype283_3,
g_atype283_4,
g_atype283_5,
};

static const long offsets283 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
g_atype284_1,
g_atype284_2,
g_atype284_3,
g_atype284_4,
g_atype284_5,
};

static const long offsets284 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags285 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_5 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
g_atype285_1,
g_atype285_2,
g_atype285_3,
g_atype285_4,
g_atype285_5,
};

static const long offsets285 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags286 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_5 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
g_atype286_3,
g_atype286_4,
g_atype286_5,
};

static const long offsets286 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
g_atype287_4,
g_atype287_5,
};

static const long offsets287 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
g_atype288_5,
};

static const long offsets288 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags289 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
};

static const long offsets289 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
};

static const long offsets290 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
};

static const long offsets291 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
};

static const long offsets292 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
};

static const long offsets293 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
g_atype294_4,
g_atype294_5,
};

static const long offsets294 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_5 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
g_atype296_5,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags297 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_5 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
g_atype297_4,
g_atype297_5,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
g_atype298_4,
g_atype298_5,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
g_atype299_4,
g_atype299_5,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags300 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_5 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
g_atype300_5,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags301 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
g_atype301_3,
g_atype301_4,
g_atype301_5,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags302 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFFF9,2,808,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
g_atype302_3,
g_atype302_4,
g_atype302_5,
};

static const long offsets302 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags316 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {0xFFF5,1,0xFF01,656,0xFFF8,1,3007,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {0xFFF5,1,0xFF01,752,0xFFF8,1,3170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags317 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
};

static const long offsets317 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
};

static const long offsets336 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
};

static const uint16 attr_flags338 [] =
{0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
};

static const long offsets338 [] =
{
0,
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags368 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {0xFF01,644,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
g_atype368_1,
g_atype368_2,
g_atype368_3,
g_atype368_4,
g_atype368_5,
g_atype368_6,
};

static const long offsets368 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags369 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {0xFF01,645,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
g_atype369_5,
g_atype369_6,
};

static const long offsets369 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags370 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {0xFF01,646,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
g_atype370_5,
g_atype370_6,
};

static const long offsets370 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags371 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {0xFF01,647,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
g_atype371_1,
g_atype371_2,
g_atype371_3,
g_atype371_4,
g_atype371_5,
g_atype371_6,
};

static const long offsets371 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags372 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {0xFF01,648,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
g_atype372_1,
g_atype372_2,
g_atype372_3,
g_atype372_4,
g_atype372_5,
g_atype372_6,
};

static const long offsets372 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags373 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {0xFF01,649,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
g_atype373_1,
g_atype373_2,
g_atype373_3,
g_atype373_4,
g_atype373_5,
g_atype373_6,
};

static const long offsets373 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags374 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {0xFF01,650,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
g_atype374_1,
g_atype374_2,
g_atype374_3,
g_atype374_4,
g_atype374_5,
g_atype374_6,
};

static const long offsets374 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags375 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {0xFF01,651,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
g_atype375_1,
g_atype375_2,
g_atype375_3,
g_atype375_4,
g_atype375_5,
g_atype375_6,
};

static const long offsets375 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags376 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {0xFF01,652,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
g_atype376_1,
g_atype376_2,
g_atype376_3,
g_atype376_4,
g_atype376_5,
g_atype376_6,
};

static const long offsets376 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags377 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {0xFF01,653,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
g_atype377_1,
g_atype377_2,
g_atype377_3,
g_atype377_4,
g_atype377_5,
g_atype377_6,
};

static const long offsets377 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags378 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {0xFF01,654,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
g_atype378_1,
g_atype378_2,
g_atype378_3,
g_atype378_4,
g_atype378_5,
g_atype378_6,
};

static const long offsets378 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags379 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {0xFF01,655,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
g_atype379_1,
g_atype379_2,
g_atype379_3,
g_atype379_4,
g_atype379_5,
g_atype379_6,
};

static const long offsets379 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags380 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {0xFF01,747,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_1 [] = {103,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
g_atype380_1,
g_atype380_2,
g_atype380_3,
g_atype380_4,
g_atype380_5,
g_atype380_6,
g_atype380_7,
};

static const long offsets380 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags381 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {0xFF01,748,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_1 [] = {104,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_3 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
g_atype381_1,
g_atype381_2,
g_atype381_3,
g_atype381_4,
g_atype381_5,
g_atype381_6,
g_atype381_7,
};

static const long offsets381 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags382 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {0xFF01,765,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
g_atype382_1,
g_atype382_2,
g_atype382_3,
g_atype382_4,
g_atype382_5,
g_atype382_6,
};

static const long offsets382 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags383 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {0xFF01,766,880,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
g_atype383_1,
g_atype383_2,
g_atype383_3,
g_atype383_4,
g_atype383_5,
g_atype383_6,
};

static const long offsets383 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags384 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {0xFF01,767,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
g_atype384_1,
g_atype384_2,
g_atype384_3,
g_atype384_4,
g_atype384_5,
g_atype384_6,
};

static const long offsets384 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags385 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {0xFF01,768,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
g_atype385_1,
g_atype385_2,
g_atype385_3,
g_atype385_4,
g_atype385_5,
g_atype385_6,
};

static const long offsets385 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags386 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {0xFF01,769,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_2 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_6 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
g_atype386_1,
g_atype386_2,
g_atype386_3,
g_atype386_4,
g_atype386_5,
g_atype386_6,
};

static const long offsets386 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags387 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
g_atype387_1,
g_atype387_2,
};

static const long offsets387 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags388 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
g_atype388_1,
g_atype388_2,
};

static const long offsets388 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags389 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
g_atype389_1,
g_atype389_2,
};

static const long offsets389 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags390 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
g_atype390_1,
g_atype390_2,
};

static const long offsets390 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags391 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
g_atype391_1,
g_atype391_2,
};

static const long offsets391 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags392 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
g_atype392_1,
g_atype392_2,
};

static const long offsets392 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags393 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
g_atype393_1,
g_atype393_2,
};

static const long offsets393 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags394 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
g_atype394_1,
g_atype394_2,
};

static const long offsets394 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags395 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
g_atype395_1,
g_atype395_2,
};

static const long offsets395 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags396 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
g_atype396_1,
g_atype396_2,
};

static const long offsets396 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags397 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
g_atype397_1,
g_atype397_2,
};

static const long offsets397 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags398 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
g_atype398_1,
g_atype398_2,
};

static const long offsets398 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags399 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_1 [] = {0xFF01,753,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
g_atype399_1,
g_atype399_2,
g_atype399_3,
};

static const long offsets399 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags400 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_1 [] = {0xFF01,754,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
g_atype400_1,
g_atype400_2,
g_atype400_3,
};

static const long offsets400 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags401 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_1 [] = {0xFF01,755,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
g_atype401_1,
g_atype401_2,
g_atype401_3,
};

static const long offsets401 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags402 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_1 [] = {0xFF01,756,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
g_atype402_1,
g_atype402_2,
g_atype402_3,
};

static const long offsets402 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags403 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {0xFF01,757,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
g_atype403_2,
g_atype403_3,
};

static const long offsets403 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags404 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_1 [] = {0xFF01,758,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
g_atype404_1,
g_atype404_2,
g_atype404_3,
};

static const long offsets404 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags405 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_1 [] = {0xFF01,759,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
g_atype405_1,
g_atype405_2,
g_atype405_3,
};

static const long offsets405 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags406 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_1 [] = {0xFF01,760,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
g_atype406_1,
g_atype406_2,
g_atype406_3,
};

static const long offsets406 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags407 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_1 [] = {0xFF01,761,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
g_atype407_1,
g_atype407_2,
g_atype407_3,
};

static const long offsets407 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags408 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_1 [] = {0xFF01,762,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
g_atype408_1,
g_atype408_2,
g_atype408_3,
};

static const long offsets408 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags409 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {0xFF01,763,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
g_atype409_2,
g_atype409_3,
};

static const long offsets409 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags410 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {0xFF01,764,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
g_atype410_2,
g_atype410_3,
};

static const long offsets410 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags411 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {0xFF01,889,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
g_atype411_3,
g_atype411_4,
};

static const long offsets411 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags412 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_1 [] = {0xFF01,892,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
g_atype412_1,
g_atype412_2,
g_atype412_3,
g_atype412_4,
};

static const long offsets412 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags413 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_1 [] = {0xFF01,681,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
g_atype413_1,
g_atype413_2,
g_atype413_3,
g_atype413_4,
};

static const long offsets413 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags414 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_1 [] = {0xFF01,682,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
g_atype414_1,
g_atype414_2,
g_atype414_3,
g_atype414_4,
};

static const long offsets414 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags415 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_1 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
g_atype415_1,
g_atype415_2,
g_atype415_3,
g_atype415_4,
};

static const long offsets415 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags416 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_1 [] = {0xFF01,684,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
g_atype416_1,
g_atype416_2,
g_atype416_3,
g_atype416_4,
};

static const long offsets416 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags417 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_1 [] = {0xFF01,685,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
g_atype417_1,
g_atype417_2,
g_atype417_3,
g_atype417_4,
};

static const long offsets417 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags418 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_1 [] = {0xFF01,686,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
g_atype418_1,
g_atype418_2,
g_atype418_3,
g_atype418_4,
};

static const long offsets418 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags419 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_1 [] = {0xFF01,687,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
g_atype419_1,
g_atype419_2,
g_atype419_3,
g_atype419_4,
};

static const long offsets419 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags420 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_1 [] = {0xFF01,688,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
g_atype420_1,
g_atype420_2,
g_atype420_3,
g_atype420_4,
};

static const long offsets420 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags421 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_1 [] = {0xFF01,689,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
g_atype421_1,
g_atype421_2,
g_atype421_3,
g_atype421_4,
};

static const long offsets421 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags422 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_1 [] = {0xFF01,690,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
g_atype422_1,
g_atype422_2,
g_atype422_3,
g_atype422_4,
};

static const long offsets422 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags423 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_1 [] = {0xFF01,691,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
g_atype423_1,
g_atype423_2,
g_atype423_3,
g_atype423_4,
};

static const long offsets423 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags424 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {0xFF01,692,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
g_atype424_3,
g_atype424_4,
};

static const long offsets424 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags425 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
g_atype425_2,
};

static const long offsets425 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
g_atype426_2,
};

static const long offsets426 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
g_atype427_2,
};

static const long offsets427 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags428 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
g_atype428_2,
};

static const long offsets428 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags429 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
g_atype429_1,
g_atype429_2,
};

static const long offsets429 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags430 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
g_atype430_1,
g_atype430_2,
};

static const long offsets430 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags431 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
g_atype431_1,
g_atype431_2,
};

static const long offsets431 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags432 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
g_atype432_2,
};

static const long offsets432 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags433 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
};

static const long offsets433 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags434 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
};

static const long offsets434 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags435 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
g_atype435_1,
g_atype435_2,
};

static const long offsets435 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags436 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
};

static const long offsets436 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_BOOL,
};

static const uint16 attr_flags437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
};

static const long offsets437 [] =
{
+ @CHROFF(0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_BOOL,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @CHROFF(0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_BOOL,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @CHROFF(0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_BOOL,
};

static const uint16 attr_flags440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
};

static const long offsets440 [] =
{
+ @CHROFF(0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_BOOL,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @CHROFF(0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_BOOL,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @CHROFF(0,0),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_BOOL,
};

static const uint16 attr_flags443 [] =
{0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
};

static const long offsets443 [] =
{
+ @CHROFF(0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_BOOL,
};

static const uint16 attr_flags444 [] =
{0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
};

static const long offsets444 [] =
{
+ @CHROFF(0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
};

static const uint16 attr_flags445 [] =
{0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_BOOL,
};

static const uint16 attr_flags446 [] =
{0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
};

static const long offsets446 [] =
{
+ @CHROFF(0,0),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_BOOL,
};

static const uint16 attr_flags447 [] =
{0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
};

static const long offsets447 [] =
{
+ @CHROFF(0,0),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_BOOL,
};

static const uint16 attr_flags448 [] =
{0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
};

static const long offsets448 [] =
{
+ @CHROFF(0,0),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_BOOL,
};

static const uint16 attr_flags449 [] =
{0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
};

static const long offsets449 [] =
{
+ @CHROFF(0,0),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_BOOL,
};

static const uint16 attr_flags450 [] =
{0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
};

static const long offsets450 [] =
{
+ @CHROFF(0,0),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_BOOL,
};

static const uint16 attr_flags451 [] =
{0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
};

static const long offsets451 [] =
{
+ @CHROFF(0,0),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_BOOL,
};

static const uint16 attr_flags452 [] =
{0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
};

static const long offsets452 [] =
{
+ @CHROFF(0,0),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_BOOL,
};

static const uint16 attr_flags453 [] =
{0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
};

static const long offsets453 [] =
{
+ @CHROFF(0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_BOOL,
};

static const uint16 attr_flags454 [] =
{0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
};

static const long offsets454 [] =
{
+ @CHROFF(0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_BOOL,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @CHROFF(0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_BOOL,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
+ @CHROFF(0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags578 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
g_atype578_1,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags579 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
g_atype579_1,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags642 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_7 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_8 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_9 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_10 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_11 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_15 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_16 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_17 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_18 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_19 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
g_atype642_1,
g_atype642_2,
g_atype642_3,
g_atype642_4,
g_atype642_5,
g_atype642_6,
g_atype642_7,
g_atype642_8,
g_atype642_9,
g_atype642_10,
g_atype642_11,
g_atype642_12,
g_atype642_13,
g_atype642_14,
g_atype642_15,
g_atype642_16,
g_atype642_17,
g_atype642_18,
g_atype642_19,
};

static const long offsets642 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags643 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_3 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_4 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_8 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_9 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_10 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_11 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_12 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_16 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_17 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_18 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_19 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_20 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
g_atype643_1,
g_atype643_2,
g_atype643_3,
g_atype643_4,
g_atype643_5,
g_atype643_6,
g_atype643_7,
g_atype643_8,
g_atype643_9,
g_atype643_10,
g_atype643_11,
g_atype643_12,
g_atype643_13,
g_atype643_14,
g_atype643_15,
g_atype643_16,
g_atype643_17,
g_atype643_18,
g_atype643_19,
g_atype643_20,
};

static const long offsets643 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags644 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_3 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_4 [] = {8,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_10 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_11 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_12 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_13 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_14 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_18 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_19 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_20 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_21 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_22 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
g_atype644_1,
g_atype644_2,
g_atype644_3,
g_atype644_4,
g_atype644_5,
g_atype644_6,
g_atype644_7,
g_atype644_8,
g_atype644_9,
g_atype644_10,
g_atype644_11,
g_atype644_12,
g_atype644_13,
g_atype644_14,
g_atype644_15,
g_atype644_16,
g_atype644_17,
g_atype644_18,
g_atype644_19,
g_atype644_20,
g_atype644_21,
g_atype644_22,
};

static const long offsets644 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags681 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
g_atype681_1,
g_atype681_2,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags682 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
g_atype682_1,
g_atype682_2,
g_atype682_3,
};

static const long offsets682 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags683 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
g_atype683_1,
g_atype683_2,
g_atype683_3,
};

static const long offsets683 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags684 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
g_atype684_1,
g_atype684_2,
g_atype684_3,
};

static const long offsets684 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags685 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
g_atype685_1,
g_atype685_2,
g_atype685_3,
};

static const long offsets685 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags686 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
g_atype686_1,
g_atype686_2,
g_atype686_3,
};

static const long offsets686 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags687 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
g_atype687_1,
g_atype687_2,
g_atype687_3,
};

static const long offsets687 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags688 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
g_atype688_1,
g_atype688_2,
g_atype688_3,
};

static const long offsets688 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags689 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
g_atype689_1,
g_atype689_2,
g_atype689_3,
};

static const long offsets689 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags690 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
g_atype690_1,
g_atype690_2,
g_atype690_3,
};

static const long offsets690 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags691 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
g_atype691_1,
g_atype691_2,
g_atype691_3,
};

static const long offsets691 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags692 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
g_atype692_1,
g_atype692_2,
g_atype692_3,
};

static const long offsets692 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags693 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
g_atype693_1,
g_atype693_2,
g_atype693_3,
};

static const long offsets693 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags694 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
g_atype694_1,
g_atype694_2,
g_atype694_3,
};

static const long offsets694 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags695 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
g_atype695_1,
g_atype695_2,
g_atype695_3,
};

static const long offsets695 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags696 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
g_atype696_1,
g_atype696_2,
g_atype696_3,
};

static const long offsets696 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags697 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
g_atype697_1,
g_atype697_2,
g_atype697_3,
};

static const long offsets697 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags698 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
g_atype698_2,
g_atype698_3,
};

static const long offsets698 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags699 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
g_atype699_1,
g_atype699_2,
g_atype699_3,
};

static const long offsets699 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_BOOL,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @CHROFF(0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_BOOL,
};

static const uint16 attr_flags703 [] =
{0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
};

static const long offsets703 [] =
{
+ @CHROFF(0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_BOOL,
};

static const uint16 attr_flags704 [] =
{0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
};

static const long offsets704 [] =
{
+ @CHROFF(0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_BOOL,
};

static const uint16 attr_flags705 [] =
{0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
};

static const long offsets705 [] =
{
+ @CHROFF(0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_BOOL,
};

static const uint16 attr_flags706 [] =
{0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
};

static const long offsets706 [] =
{
+ @CHROFF(0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_BOOL,
};

static const uint16 attr_flags707 [] =
{0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
};

static const long offsets707 [] =
{
+ @CHROFF(0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_BOOL,
};

static const uint16 attr_flags708 [] =
{0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
};

static const long offsets708 [] =
{
+ @CHROFF(0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_BOOL,
};

static const uint16 attr_flags709 [] =
{0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
};

static const long offsets709 [] =
{
+ @CHROFF(0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_BOOL,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
+ @CHROFF(0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_BOOL,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
+ @CHROFF(0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_BOOL,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
+ @CHROFF(0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_BOOL,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
+ @CHROFF(0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_BOOL,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @CHROFF(0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_BOOL,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @CHROFF(0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_BOOL,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @CHROFF(0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_BOOL,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @CHROFF(0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_BOOL,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @CHROFF(0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_BOOL,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags748 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {103,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_1 [] = {103,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
g_atype748_1,
g_atype748_2,
g_atype748_3,
g_atype748_4,
g_atype748_5,
};

static const long offsets748 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags749 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {104,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_1 [] = {104,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_2 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
g_atype749_1,
g_atype749_2,
g_atype749_3,
g_atype749_4,
g_atype749_5,
};

static const long offsets749 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags753 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
g_atype753_1,
g_atype753_2,
g_atype753_3,
};

static const long offsets753 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags754 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
g_atype754_1,
g_atype754_2,
};

static const long offsets754 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags755 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
g_atype755_1,
g_atype755_2,
};

static const long offsets755 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags756 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
g_atype756_1,
g_atype756_2,
};

static const long offsets756 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags757 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
g_atype757_1,
g_atype757_2,
};

static const long offsets757 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags758 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
g_atype758_1,
g_atype758_2,
};

static const long offsets758 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags759 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
g_atype759_1,
g_atype759_2,
};

static const long offsets759 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags760 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
g_atype760_1,
g_atype760_2,
};

static const long offsets760 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags761 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
g_atype761_1,
g_atype761_2,
};

static const long offsets761 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags762 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {0xFF01,664,832,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
g_atype762_1,
g_atype762_2,
};

static const long offsets762 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags763 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {0xFF01,665,829,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
g_atype763_1,
g_atype763_2,
};

static const long offsets763 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags764 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {0xFF01,666,835,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
g_atype764_1,
g_atype764_2,
};

static const long offsets764 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags765 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {0xFF01,667,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
g_atype765_1,
g_atype765_2,
};

static const long offsets765 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags766 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_1 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_2 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_4 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_16 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
g_atype766_1,
g_atype766_2,
g_atype766_3,
g_atype766_4,
g_atype766_5,
g_atype766_6,
g_atype766_7,
g_atype766_8,
g_atype766_9,
g_atype766_10,
g_atype766_11,
g_atype766_12,
g_atype766_13,
g_atype766_14,
g_atype766_15,
g_atype766_16,
};

static const long offsets766 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags767 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {0xFF01,657,880,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_1 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_3 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_15 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_16 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
g_atype767_1,
g_atype767_2,
g_atype767_3,
g_atype767_4,
g_atype767_5,
g_atype767_6,
g_atype767_7,
g_atype767_8,
g_atype767_9,
g_atype767_10,
g_atype767_11,
g_atype767_12,
g_atype767_13,
g_atype767_14,
g_atype767_15,
g_atype767_16,
};

static const long offsets767 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags768 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_1 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_3 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_16 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
g_atype768_1,
g_atype768_2,
g_atype768_3,
g_atype768_4,
g_atype768_5,
g_atype768_6,
g_atype768_7,
g_atype768_8,
g_atype768_9,
g_atype768_10,
g_atype768_11,
g_atype768_12,
g_atype768_13,
g_atype768_14,
g_atype768_15,
g_atype768_16,
};

static const long offsets768 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags769 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_1 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_4 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_16 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
g_atype769_1,
g_atype769_2,
g_atype769_3,
g_atype769_4,
g_atype769_5,
g_atype769_6,
g_atype769_7,
g_atype769_8,
g_atype769_9,
g_atype769_10,
g_atype769_11,
g_atype769_12,
g_atype769_13,
g_atype769_14,
g_atype769_15,
g_atype769_16,
};

static const long offsets769 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags770 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_1 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_3 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_16 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
g_atype770_1,
g_atype770_2,
g_atype770_3,
g_atype770_4,
g_atype770_5,
g_atype770_6,
g_atype770_7,
g_atype770_8,
g_atype770_9,
g_atype770_10,
g_atype770_11,
g_atype770_12,
g_atype770_13,
g_atype770_14,
g_atype770_15,
g_atype770_16,
};

static const long offsets770 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags771 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_1 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_2 [] = {0xFF01,656,0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_4 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_6 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_17 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
g_atype771_1,
g_atype771_2,
g_atype771_3,
g_atype771_4,
g_atype771_5,
g_atype771_6,
g_atype771_7,
g_atype771_8,
g_atype771_9,
g_atype771_10,
g_atype771_11,
g_atype771_12,
g_atype771_13,
g_atype771_14,
g_atype771_15,
g_atype771_16,
g_atype771_17,
};

static const long offsets771 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags772 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {0xFF01,656,0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_3 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_4 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_17 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
g_atype772_2,
g_atype772_3,
g_atype772_4,
g_atype772_5,
g_atype772_6,
g_atype772_7,
g_atype772_8,
g_atype772_9,
g_atype772_10,
g_atype772_11,
g_atype772_12,
g_atype772_13,
g_atype772_14,
g_atype772_15,
g_atype772_16,
g_atype772_17,
};

static const long offsets772 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags773 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {0xFF01,656,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {0xFF01,656,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_4 [] = {0xFF01,659,847,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_6 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_7 [] = {893,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_8 [] = {893,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
g_atype773_4,
g_atype773_5,
g_atype773_6,
g_atype773_7,
g_atype773_8,
g_atype773_9,
g_atype773_10,
g_atype773_11,
g_atype773_12,
g_atype773_13,
g_atype773_14,
g_atype773_15,
g_atype773_16,
g_atype773_17,
g_atype773_18,
};

static const long offsets773 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags776 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
};

static const long offsets776 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags777 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
};

static const long offsets777 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags778 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
};

static const long offsets778 [] =
{
0,
 + @REFACS(1),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags779 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
};

static const long offsets779 [] =
{
0,
 + @REFACS(1),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags780 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
};

static const long offsets780 [] =
{
0,
 + @REFACS(1),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags781 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
};

static const long offsets781 [] =
{
0,
 + @REFACS(1),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags782 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
};

static const long offsets782 [] =
{
0,
 + @REFACS(1),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags783 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
};

static const long offsets783 [] =
{
0,
 + @REFACS(1),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags784 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
};

static const long offsets784 [] =
{
0,
 + @REFACS(1),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags785 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
};

static const long offsets785 [] =
{
0,
 + @REFACS(1),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags786 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
};

static const long offsets786 [] =
{
0,
 + @REFACS(1),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags787 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
g_atype787_1,
};

static const long offsets787 [] =
{
0,
 + @REFACS(1),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags788 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
g_atype788_1,
};

static const long offsets788 [] =
{
0,
 + @REFACS(1),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags789 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
g_atype789_1,
};

static const long offsets789 [] =
{
0,
 + @REFACS(1),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags790 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
g_atype790_1,
};

static const long offsets790 [] =
{
0,
 + @REFACS(1),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags791 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
g_atype791_1,
};

static const long offsets791 [] =
{
0,
 + @REFACS(1),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags792 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
g_atype792_1,
};

static const long offsets792 [] =
{
0,
 + @REFACS(1),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags793 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
g_atype793_1,
};

static const long offsets793 [] =
{
0,
 + @REFACS(1),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags794 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
g_atype794_1,
};

static const long offsets794 [] =
{
0,
 + @REFACS(1),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags795 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
g_atype795_1,
};

static const long offsets795 [] =
{
0,
 + @REFACS(1),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags796 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
};

static const long offsets796 [] =
{
0,
 + @REFACS(1),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags797 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
};

static const long offsets797 [] =
{
0,
 + @REFACS(1),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags798 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
};

static const long offsets798 [] =
{
0,
 + @REFACS(1),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags799 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
};

static const long offsets799 [] =
{
0,
 + @REFACS(1),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags800 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
};

static const long offsets800 [] =
{
0,
 + @REFACS(1),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags801 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
};

static const long offsets801 [] =
{
0,
 + @REFACS(1),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags802 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
};

static const long offsets802 [] =
{
0,
 + @REFACS(1),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags803 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
};

static const long offsets803 [] =
{
0,
 + @REFACS(1),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags804 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
};

static const long offsets804 [] =
{
0,
 + @REFACS(1),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags805 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
};

static const long offsets805 [] =
{
0,
 + @REFACS(1),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags806 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
};

static const long offsets806 [] =
{
0,
 + @REFACS(1),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags807 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
};

static const long offsets807 [] =
{
0,
 + @REFACS(1),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags808 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {890,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {893,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
};

static const long offsets808 [] =
{
0,
 + @REFACS(1),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_INT64,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_INT64,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_INT64,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_INT32,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_INT32,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_INT32,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_INT16,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_INT16,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_INT16,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {817,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_INT8,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_INT8,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_INT8,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {820,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_UINT64,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_UINT64,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_UINT64,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_UINT32,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_UINT32,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_UINT32,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_UINT16,
};

static const uint16 attr_flags828 [] =
{0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
};

static const long offsets828 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_UINT16,
};

static const uint16 attr_flags829 [] =
{0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
};

static const long offsets829 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_UINT16,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_UINT8,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @CHROFF(0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_UINT8,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @CHROFF(0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_UINT8,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {832,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @CHROFF(0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_REAL32,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_REAL32,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_REAL32,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {835,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_REAL64,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_REAL64,
};

static const uint16 attr_flags838 [] =
{0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
};

static const long offsets838 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_REAL64,
};

static const uint16 attr_flags839 [] =
{0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
};

static const long offsets839 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {841,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @CHROFF(0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @CHROFF(0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {844,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @CHROFF(0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_BOOL,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @CHROFF(0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_BOOL,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @CHROFF(0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_BOOL,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @CHROFF(0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_POINTER,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_POINTER,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_POINTER,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_POINTER,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_POINTER,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_POINTER,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_POINTER,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_POINTER,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_POINTER,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_POINTER,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_POINTER,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_POINTER,
};

static const uint16 attr_flags860 [] =
{0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
};

static const long offsets860 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_POINTER,
};

static const uint16 attr_flags861 [] =
{0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
};

static const long offsets861 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_POINTER,
};

static const uint16 attr_flags862 [] =
{0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
};

static const long offsets862 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_POINTER,
};

static const uint16 attr_flags863 [] =
{0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
};

static const long offsets863 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_POINTER,
};

static const uint16 attr_flags864 [] =
{0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
};

static const long offsets864 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_POINTER,
};

static const uint16 attr_flags865 [] =
{0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
};

static const long offsets865 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_POINTER,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_POINTER,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_POINTER,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_POINTER,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_POINTER,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_POINTER,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_POINTER,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_POINTER,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_POINTER,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_POINTER,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_POINTER,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_POINTER,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_POINTER,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_POINTER,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_POINTER,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_POINTER,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags882 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_1 [] = {0xFFF9,0,808,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_2 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_3 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_9 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_10 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_11 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
g_atype882_1,
g_atype882_2,
g_atype882_3,
g_atype882_4,
g_atype882_5,
g_atype882_6,
g_atype882_7,
g_atype882_8,
g_atype882_9,
g_atype882_10,
g_atype882_11,
};

static const long offsets882 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags883 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_1 [] = {0xFFF9,0,808,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_2 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_3 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_9 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_10 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_11 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
g_atype883_1,
g_atype883_2,
g_atype883_3,
g_atype883_4,
g_atype883_5,
g_atype883_6,
g_atype883_7,
g_atype883_8,
g_atype883_9,
g_atype883_10,
g_atype883_11,
};

static const long offsets883 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags884 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_1 [] = {0xFFF9,0,808,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_2 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_3 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_10 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_11 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_12 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
g_atype884_1,
g_atype884_2,
g_atype884_3,
g_atype884_4,
g_atype884_5,
g_atype884_6,
g_atype884_7,
g_atype884_8,
g_atype884_9,
g_atype884_10,
g_atype884_11,
g_atype884_12,
};

static const long offsets884 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags885 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_1 [] = {0xFFF9,0,808,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_2 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_3 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_10 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_11 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_12 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
g_atype885_1,
g_atype885_2,
g_atype885_3,
g_atype885_4,
g_atype885_5,
g_atype885_6,
g_atype885_7,
g_atype885_8,
g_atype885_9,
g_atype885_10,
g_atype885_11,
g_atype885_12,
};

static const long offsets885 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags886 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {0xFFF9,0,808,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_2 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_3 [] = {683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_10 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_11 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_12 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
g_atype886_2,
g_atype886_3,
g_atype886_4,
g_atype886_5,
g_atype886_6,
g_atype886_7,
g_atype886_8,
g_atype886_9,
g_atype886_10,
g_atype886_11,
g_atype886_12,
};

static const long offsets886 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags887 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
};

static const long offsets887 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags888 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
};

static const long offsets888 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags889 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
};

static const long offsets889 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags890 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
g_atype890_2,
g_atype890_3,
};

static const long offsets890 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags891 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
g_atype891_2,
g_atype891_3,
g_atype891_4,
};

static const long offsets891 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags892 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {0xFF01,663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
g_atype892_2,
g_atype892_3,
g_atype892_4,
};

static const long offsets892 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags893 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
g_atype893_2,
g_atype893_3,
};

static const long offsets893 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags894 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
g_atype894_2,
g_atype894_3,
g_atype894_4,
};

static const long offsets894 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags895 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
g_atype895_2,
g_atype895_3,
g_atype895_4,
};

static const long offsets895 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags896 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
g_atype896_2,
g_atype896_3,
g_atype896_4,
};

static const long offsets896 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_INT32,
};

static const uint16 attr_flags900 [] =
{0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
};

static const long offsets900 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags901 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_1 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_2 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_3 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_4 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_5 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_6 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_7 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_8 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_9 [] = {0xFF01,683,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_10 [] = {0xFF01,1112,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_11 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_12 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
g_atype901_1,
g_atype901_2,
g_atype901_3,
g_atype901_4,
g_atype901_5,
g_atype901_6,
g_atype901_7,
g_atype901_8,
g_atype901_9,
g_atype901_10,
g_atype901_11,
g_atype901_12,
g_atype901_13,
g_atype901_14,
g_atype901_15,
g_atype901_16,
g_atype901_17,
g_atype901_18,
g_atype901_19,
};

static const long offsets901 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @LNGOFF(12,1,0,0),
+ @LNGOFF(12,1,0,1),
+ @LNGOFF(12,1,0,2),
+ @LNGOFF(12,1,0,3),
+ @LNGOFF(12,1,0,4),
+ @LNGOFF(12,1,0,5),
+ @LNGOFF(12,1,0,6),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags902 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
g_atype902_1,
g_atype902_2,
};

static const long offsets902 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags903 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
g_atype903_1,
g_atype903_2,
};

static const long offsets903 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_REF,
};

static const uint16 attr_flags910 [] =
{0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
};

static const long offsets910 [] =
{
0,
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_REF,
};

static const uint16 attr_flags916 [] =
{0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
};

static const long offsets916 [] =
{
0,
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags926 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {0xFF01,138,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_1 [] = {0xFF01,1081,0xFF01,776,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_2 [] = {0xFF01,1081,0xFF01,925,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_3 [] = {0xFF01,1081,0xFF01,145,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_4 [] = {0xFF01,1081,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_5 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_9 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
g_atype926_1,
g_atype926_2,
g_atype926_3,
g_atype926_4,
g_atype926_5,
g_atype926_6,
g_atype926_7,
g_atype926_8,
g_atype926_9,
};

static const long offsets926 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @LNGOFF(6,2,0,1),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags929 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_3 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
g_atype929_1,
g_atype929_2,
g_atype929_3,
};

static const long offsets929 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags930 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_1 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_2 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
g_atype930_1,
g_atype930_2,
g_atype930_3,
g_atype930_4,
};

static const long offsets930 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags934 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_1 [] = {0xFF01,1081,0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
g_atype934_1,
g_atype934_2,
g_atype934_3,
};

static const long offsets934 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags942 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_3 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_4 [] = {8,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_10 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_11 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_12 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_13 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_14 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_18 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_19 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_20 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_21 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_22 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
g_atype942_1,
g_atype942_2,
g_atype942_3,
g_atype942_4,
g_atype942_5,
g_atype942_6,
g_atype942_7,
g_atype942_8,
g_atype942_9,
g_atype942_10,
g_atype942_11,
g_atype942_12,
g_atype942_13,
g_atype942_14,
g_atype942_15,
g_atype942_16,
g_atype942_17,
g_atype942_18,
g_atype942_19,
g_atype942_20,
g_atype942_21,
g_atype942_22,
};

static const long offsets942 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags943 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {0xFF01,95,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_1 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
g_atype943_1,
};

static const long offsets943 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags945 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_1 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_2 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
g_atype945_1,
g_atype945_2,
g_atype945_3,
};

static const long offsets945 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names946[];
static const uint32 types946 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags946 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype946_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_7 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_19 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_20 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_21 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes946 [] = {
g_atype946_0,
g_atype946_1,
g_atype946_2,
g_atype946_3,
g_atype946_4,
g_atype946_5,
g_atype946_6,
g_atype946_7,
g_atype946_8,
g_atype946_9,
g_atype946_10,
g_atype946_11,
g_atype946_12,
g_atype946_13,
g_atype946_14,
g_atype946_15,
g_atype946_16,
g_atype946_17,
g_atype946_18,
g_atype946_19,
g_atype946_20,
g_atype946_21,
};

static const long offsets946 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags947 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_9 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_10 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_12 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_13 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_14 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_15 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_16 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_17 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_19 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_20 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_21 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_22 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_23 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_24 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_25 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_26 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_27 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_28 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_30 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_31 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_32 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_33 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_34 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_35 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_36 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_37 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
g_atype947_1,
g_atype947_2,
g_atype947_3,
g_atype947_4,
g_atype947_5,
g_atype947_6,
g_atype947_7,
g_atype947_8,
g_atype947_9,
g_atype947_10,
g_atype947_11,
g_atype947_12,
g_atype947_13,
g_atype947_14,
g_atype947_15,
g_atype947_16,
g_atype947_17,
g_atype947_18,
g_atype947_19,
g_atype947_20,
g_atype947_21,
g_atype947_22,
g_atype947_23,
g_atype947_24,
g_atype947_25,
g_atype947_26,
g_atype947_27,
g_atype947_28,
g_atype947_29,
g_atype947_30,
g_atype947_31,
g_atype947_32,
g_atype947_33,
g_atype947_34,
g_atype947_35,
g_atype947_36,
g_atype947_37,
};

static const long offsets947 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names954[];
static const uint32 types954 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags954 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype954_0 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes954 [] = {
g_atype954_0,
g_atype954_1,
g_atype954_2,
};

static const long offsets954 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names955[];
static const uint32 types955 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags955 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype955_0 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes955 [] = {
g_atype955_0,
g_atype955_1,
g_atype955_2,
};

static const long offsets955 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names956[];
static const uint32 types956 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags956 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype956_0 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_2 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes956 [] = {
g_atype956_0,
g_atype956_1,
g_atype956_2,
};

static const long offsets956 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names958[];
static const uint32 types958 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags958 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype958_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_3 [] = {78,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_9 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_10 [] = {880,0xFFFF};

static const EIF_TYPE_INDEX *gtypes958 [] = {
g_atype958_0,
g_atype958_1,
g_atype958_2,
g_atype958_3,
g_atype958_4,
g_atype958_5,
g_atype958_6,
g_atype958_7,
g_atype958_8,
g_atype958_9,
g_atype958_10,
};

static const long offsets958 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names959[];
static const uint32 types959 [] =
{
SK_REF,
};

static const uint16 attr_flags959 [] =
{0,};

static const EIF_TYPE_INDEX g_atype959_0 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes959 [] = {
g_atype959_0,
};

static const long offsets959 [] =
{
0,
};

extern const char *names960[];
static const uint32 types960 [] =
{
SK_REF,
};

static const uint16 attr_flags960 [] =
{0,};

static const EIF_TYPE_INDEX g_atype960_0 [] = {0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes960 [] = {
g_atype960_0,
};

static const long offsets960 [] =
{
0,
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags961 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_3 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_4 [] = {8,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_11 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_12 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_13 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_14 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_15 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_20 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_21 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_22 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_23 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
g_atype961_1,
g_atype961_2,
g_atype961_3,
g_atype961_4,
g_atype961_5,
g_atype961_6,
g_atype961_7,
g_atype961_8,
g_atype961_9,
g_atype961_10,
g_atype961_11,
g_atype961_12,
g_atype961_13,
g_atype961_14,
g_atype961_15,
g_atype961_16,
g_atype961_17,
g_atype961_18,
g_atype961_19,
g_atype961_20,
g_atype961_21,
g_atype961_22,
g_atype961_23,
};

static const long offsets961 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags962 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_3 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_9 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_10 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_11 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_12 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_13 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_17 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_18 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_19 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_20 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_21 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
g_atype962_1,
g_atype962_2,
g_atype962_3,
g_atype962_4,
g_atype962_5,
g_atype962_6,
g_atype962_7,
g_atype962_8,
g_atype962_9,
g_atype962_10,
g_atype962_11,
g_atype962_12,
g_atype962_13,
g_atype962_14,
g_atype962_15,
g_atype962_16,
g_atype962_17,
g_atype962_18,
g_atype962_19,
g_atype962_20,
g_atype962_21,
};

static const long offsets962 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags963 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_3 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_9 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_10 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_11 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_12 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_13 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_17 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_18 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_19 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_20 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_21 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
g_atype963_1,
g_atype963_2,
g_atype963_3,
g_atype963_4,
g_atype963_5,
g_atype963_6,
g_atype963_7,
g_atype963_8,
g_atype963_9,
g_atype963_10,
g_atype963_11,
g_atype963_12,
g_atype963_13,
g_atype963_14,
g_atype963_15,
g_atype963_16,
g_atype963_17,
g_atype963_18,
g_atype963_19,
g_atype963_20,
g_atype963_21,
};

static const long offsets963 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags964 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_1 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_3 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_5 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_9 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_10 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_11 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_12 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_13 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_17 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_18 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_19 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_20 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_21 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
g_atype964_1,
g_atype964_2,
g_atype964_3,
g_atype964_4,
g_atype964_5,
g_atype964_6,
g_atype964_7,
g_atype964_8,
g_atype964_9,
g_atype964_10,
g_atype964_11,
g_atype964_12,
g_atype964_13,
g_atype964_14,
g_atype964_15,
g_atype964_16,
g_atype964_17,
g_atype964_18,
g_atype964_19,
g_atype964_20,
g_atype964_21,
};

static const long offsets964 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags965 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_1 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_2 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_3 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_4 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
g_atype965_1,
g_atype965_2,
g_atype965_3,
g_atype965_4,
};

static const long offsets965 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags966 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_1 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_2 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_3 [] = {8,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_5 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_6 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_8 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_12 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_13 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_14 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_15 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_16 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_17 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_19 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_20 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_21 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_22 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_23 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_24 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_25 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
g_atype966_1,
g_atype966_2,
g_atype966_3,
g_atype966_4,
g_atype966_5,
g_atype966_6,
g_atype966_7,
g_atype966_8,
g_atype966_9,
g_atype966_10,
g_atype966_11,
g_atype966_12,
g_atype966_13,
g_atype966_14,
g_atype966_15,
g_atype966_16,
g_atype966_17,
g_atype966_18,
g_atype966_19,
g_atype966_20,
g_atype966_21,
g_atype966_22,
g_atype966_23,
g_atype966_24,
g_atype966_25,
};

static const long offsets966 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags967 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_1 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_3 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_4 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_11 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_12 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_13 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_14 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_15 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_20 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_21 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_22 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_23 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
g_atype967_1,
g_atype967_2,
g_atype967_3,
g_atype967_4,
g_atype967_5,
g_atype967_6,
g_atype967_7,
g_atype967_8,
g_atype967_9,
g_atype967_10,
g_atype967_11,
g_atype967_12,
g_atype967_13,
g_atype967_14,
g_atype967_15,
g_atype967_16,
g_atype967_17,
g_atype967_18,
g_atype967_19,
g_atype967_20,
g_atype967_21,
g_atype967_22,
g_atype967_23,
};

static const long offsets967 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags968 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_1 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_3 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_4 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_11 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_12 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_13 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_14 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_15 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_20 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_21 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_22 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_23 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
g_atype968_1,
g_atype968_2,
g_atype968_3,
g_atype968_4,
g_atype968_5,
g_atype968_6,
g_atype968_7,
g_atype968_8,
g_atype968_9,
g_atype968_10,
g_atype968_11,
g_atype968_12,
g_atype968_13,
g_atype968_14,
g_atype968_15,
g_atype968_16,
g_atype968_17,
g_atype968_18,
g_atype968_19,
g_atype968_20,
g_atype968_21,
g_atype968_22,
g_atype968_23,
};

static const long offsets968 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags969 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_1 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_2 [] = {209,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_3 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_4 [] = {79,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_6 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_7 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_11 [] = {832,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_12 [] = {820,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_13 [] = {829,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_14 [] = {817,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_15 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_19 [] = {835,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_20 [] = {880,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_21 [] = {823,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_22 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_23 [] = {838,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
g_atype969_1,
g_atype969_2,
g_atype969_3,
g_atype969_4,
g_atype969_5,
g_atype969_6,
g_atype969_7,
g_atype969_8,
g_atype969_9,
g_atype969_10,
g_atype969_11,
g_atype969_12,
g_atype969_13,
g_atype969_14,
g_atype969_15,
g_atype969_16,
g_atype969_17,
g_atype969_18,
g_atype969_19,
g_atype969_20,
g_atype969_21,
g_atype969_22,
g_atype969_23,
};

static const long offsets969 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_REF,
};

static const uint16 attr_flags970 [] =
{0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {969,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
};

static const long offsets970 [] =
{
0,
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_REF,
};

static const uint16 attr_flags971 [] =
{0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {970,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
};

static const long offsets971 [] =
{
0,
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_REF,
};

static const uint16 attr_flags972 [] =
{0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {971,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
};

static const long offsets972 [] =
{
0,
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_REF,
};

static const uint16 attr_flags973 [] =
{0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {972,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
};

static const long offsets973 [] =
{
0,
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_REF,
};

static const uint16 attr_flags974 [] =
{0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {969,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
};

static const long offsets974 [] =
{
0,
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_REF,
};

static const uint16 attr_flags975 [] =
{0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {970,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
};

static const long offsets975 [] =
{
0,
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_REF,
};

static const uint16 attr_flags976 [] =
{0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {969,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
};

static const long offsets976 [] =
{
0,
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_REF,
};

static const uint16 attr_flags977 [] =
{0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {970,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
};

static const long offsets977 [] =
{
0,
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_REF,
};

static const uint16 attr_flags978 [] =
{0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {972,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
};

static const long offsets978 [] =
{
0,
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_REF,
};

static const uint16 attr_flags979 [] =
{0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {978,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
};

static const long offsets979 [] =
{
0,
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_REF,
};

static const uint16 attr_flags980 [] =
{0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {979,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
};

static const long offsets980 [] =
{
0,
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_REF,
};

static const uint16 attr_flags981 [] =
{0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {980,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
};

static const long offsets981 [] =
{
0,
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {981,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
0,
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_REF,
};

static const uint16 attr_flags983 [] =
{0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {982,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
};

static const long offsets983 [] =
{
0,
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REF,
};

static const uint16 attr_flags984 [] =
{0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {983,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
};

static const long offsets984 [] =
{
0,
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_REF,
};

static const uint16 attr_flags985 [] =
{0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {984,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
};

static const long offsets985 [] =
{
0,
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_REF,
};

static const uint16 attr_flags986 [] =
{0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {985,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
};

static const long offsets986 [] =
{
0,
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_REF,
};

static const uint16 attr_flags987 [] =
{0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {986,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
};

static const long offsets987 [] =
{
0,
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_REF,
};

static const uint16 attr_flags988 [] =
{0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {987,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
};

static const long offsets988 [] =
{
0,
};

extern const char *names989[];
static const uint32 types989 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags989 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype989_0 [] = {988,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_1 [] = {0xFFF5,2,0xFF01,1056,0xFFF8,1,0xFFF8,2,5330,5278,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_2 [] = {0xFF01,1056,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes989 [] = {
g_atype989_0,
g_atype989_1,
g_atype989_2,
};

static const long offsets989 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names990[];
static const uint32 types990 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags990 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype990_0 [] = {989,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype990_1 [] = {0xFFF5,2,0xFF01,1057,814,0xFFF8,2,5330,5278,0xFFFF};
static const EIF_TYPE_INDEX g_atype990_2 [] = {0xFF01,1057,814,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes990 [] = {
g_atype990_0,
g_atype990_1,
g_atype990_2,
};

static const long offsets990 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names991[];
static const uint32 types991 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags991 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype991_0 [] = {990,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_1 [] = {0xFFF5,2,0xFF01,1058,0xFFF8,1,814,5330,5278,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_2 [] = {0xFF01,1058,0xFFF8,1,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes991 [] = {
g_atype991_0,
g_atype991_1,
g_atype991_2,
};

static const long offsets991 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names992[];
static const uint32 types992 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags992 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype992_0 [] = {991,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_1 [] = {0xFF01,1012,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_2 [] = {0xFF01,1059,814,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes992 [] = {
g_atype992_0,
g_atype992_1,
g_atype992_2,
};

static const long offsets992 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names993[];
static const uint32 types993 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags993 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype993_0 [] = {992,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype993_1 [] = {0xFF01,1013,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype993_2 [] = {0xFF01,1060,823,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes993 [] = {
g_atype993_0,
g_atype993_1,
g_atype993_2,
};

static const long offsets993 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names994[];
static const uint32 types994 [] =
{
SK_REF,
};

static const uint16 attr_flags994 [] =
{0,};

static const EIF_TYPE_INDEX g_atype994_0 [] = {993,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes994 [] = {
g_atype994_0,
};

static const long offsets994 [] =
{
0,
};

extern const char *names995[];
static const uint32 types995 [] =
{
SK_REF,
};

static const uint16 attr_flags995 [] =
{0,};

static const EIF_TYPE_INDEX g_atype995_0 [] = {994,814,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes995 [] = {
g_atype995_0,
};

static const long offsets995 [] =
{
0,
};

extern const char *names996[];
static const uint32 types996 [] =
{
SK_REF,
};

static const uint16 attr_flags996 [] =
{0,};

static const EIF_TYPE_INDEX g_atype996_0 [] = {995,0xFFF8,1,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes996 [] = {
g_atype996_0,
};

static const long offsets996 [] =
{
0,
};

extern const char *names997[];
static const uint32 types997 [] =
{
SK_REF,
};

static const uint16 attr_flags997 [] =
{0,};

static const EIF_TYPE_INDEX g_atype997_0 [] = {996,814,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes997 [] = {
g_atype997_0,
};

static const long offsets997 [] =
{
0,
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_REF,
};

static const uint16 attr_flags998 [] =
{0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {997,823,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
};

static const long offsets998 [] =
{
0,
};

extern const char *names999[];
static const uint32 types999 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags999 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype999_0 [] = {998,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_1 [] = {0xFF01,1083,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes999 [] = {
g_atype999_0,
g_atype999_1,
g_atype999_2,
};

static const long offsets999 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1000[];
static const uint32 types1000 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1000 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1000_0 [] = {999,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1000_1 [] = {0xFF01,1084,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1000_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1000 [] = {
g_atype1000_0,
g_atype1000_1,
g_atype1000_2,
};

static const long offsets1000 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1001 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {1000,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1001_1 [] = {0xFF01,1085,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1001_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
g_atype1001_1,
g_atype1001_2,
};

static const long offsets1001 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1002[];
static const uint32 types1002 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1002 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1002_0 [] = {1001,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1002_1 [] = {0xFF01,1086,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1002_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1002 [] = {
g_atype1002_0,
g_atype1002_1,
g_atype1002_2,
};

static const long offsets1002 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1003 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {1002,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1003_1 [] = {0xFF01,1087,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1003_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
g_atype1003_1,
g_atype1003_2,
};

static const long offsets1003 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1004 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {1003,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_1 [] = {0xFF01,1088,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
g_atype1004_1,
g_atype1004_2,
};

static const long offsets1004 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1005 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {1004,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_1 [] = {0xFF01,1089,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
g_atype1005_1,
g_atype1005_2,
};

static const long offsets1005 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1006 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {1005,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1006_1 [] = {0xFF01,1090,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1006_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
g_atype1006_1,
g_atype1006_2,
};

static const long offsets1006 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1007 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {1006,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1007_1 [] = {0xFF01,1091,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1007_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
g_atype1007_1,
g_atype1007_2,
};

static const long offsets1007 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1008 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {1007,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1008_1 [] = {0xFF01,1092,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1008_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
g_atype1008_1,
g_atype1008_2,
};

static const long offsets1008 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1009 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1008,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1009_1 [] = {0xFF01,1093,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1009_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
g_atype1009_1,
g_atype1009_2,
};

static const long offsets1009 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1010 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {1009,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_1 [] = {0xFF01,1094,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
g_atype1010_1,
g_atype1010_2,
};

static const long offsets1010 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1011 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {1010,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1011_1 [] = {0xFF01,1095,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1011_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
g_atype1011_1,
g_atype1011_2,
};

static const long offsets1011 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1012 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {1011,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_1 [] = {0xFF01,1096,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
g_atype1012_1,
g_atype1012_2,
};

static const long offsets1012 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1013 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {1012,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_1 [] = {0xFF01,1097,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
g_atype1013_1,
g_atype1013_2,
};

static const long offsets1013 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1014 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1013,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_1 [] = {0xFF01,1098,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
g_atype1014_1,
g_atype1014_2,
};

static const long offsets1014 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1015 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {1014,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_1 [] = {0xFF01,1099,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
g_atype1015_1,
g_atype1015_2,
};

static const long offsets1015 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1016 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1015,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_1 [] = {0xFF01,1100,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
g_atype1016_1,
g_atype1016_2,
};

static const long offsets1016 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1017 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1016,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_1 [] = {0xFF01,1101,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
g_atype1017_1,
g_atype1017_2,
};

static const long offsets1017 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1018 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1017,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_1 [] = {0xFF01,1102,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
g_atype1018_1,
g_atype1018_2,
};

static const long offsets1018 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1019 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1018,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_1 [] = {0xFF01,1103,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
g_atype1019_1,
g_atype1019_2,
};

static const long offsets1019 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1020 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1019,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_1 [] = {0xFF01,1104,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
g_atype1020_1,
g_atype1020_2,
};

static const long offsets1020 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1021 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1020,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_1 [] = {0xFF01,1105,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
g_atype1021_1,
g_atype1021_2,
};

static const long offsets1021 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1022 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1021,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_1 [] = {0xFF01,1106,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
g_atype1022_1,
g_atype1022_2,
};

static const long offsets1022 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1023 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1022,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_1 [] = {0xFF01,1107,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
g_atype1023_1,
g_atype1023_2,
};

static const long offsets1023 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1024 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {1023,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1024_1 [] = {0xFF01,1108,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1024_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
g_atype1024_1,
g_atype1024_2,
};

static const long offsets1024 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_REF,
};

static const uint16 attr_flags1025 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1024,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
};

static const long offsets1025 [] =
{
0,
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_REF,
};

static const uint16 attr_flags1026 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {1025,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
};

static const long offsets1026 [] =
{
0,
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1027 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {1026,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {0xFF01,1081,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1028 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {1027,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {0xFF01,1082,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1029 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {1028,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_1 [] = {113,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_2 [] = {0xFF01,1076,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_3 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_4 [] = {847,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
g_atype1029_1,
g_atype1029_2,
g_atype1029_3,
g_atype1029_4,
};

static const long offsets1029 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_REF,
};

static const uint16 attr_flags1045 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
};

static const long offsets1045 [] =
{
0,
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
};

static const uint16 attr_flags1046 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
};

static const long offsets1046 [] =
{
0,
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
};

static const uint16 attr_flags1047 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {213,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
};

static const long offsets1047 [] =
{
0,
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_REF,
};

static const uint16 attr_flags1048 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {214,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
};

static const long offsets1048 [] =
{
0,
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_REF,
};

static const uint16 attr_flags1049 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
};

static const long offsets1049 [] =
{
0,
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_REF,
};

static const uint16 attr_flags1050 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
};

static const long offsets1050 [] =
{
0,
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_REF,
};

static const uint16 attr_flags1051 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {214,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
};

static const long offsets1051 [] =
{
0,
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_REF,
};

static const uint16 attr_flags1052 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {213,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
};

static const long offsets1052 [] =
{
0,
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_REF,
};

static const uint16 attr_flags1053 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
};

static const long offsets1053 [] =
{
0,
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
};

static const uint16 attr_flags1054 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
};

static const long offsets1054 [] =
{
0,
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
};

static const uint16 attr_flags1055 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {214,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
};

static const long offsets1055 [] =
{
0,
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
};

static const uint16 attr_flags1056 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {213,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
};

static const long offsets1056 [] =
{
0,
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1057 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_1 [] = {0xFF01,1094,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_2 [] = {0xFF01,988,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
g_atype1057_1,
g_atype1057_2,
};

static const long offsets1057 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1058 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_1 [] = {0xFF01,1095,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_2 [] = {0xFF01,989,814,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
g_atype1058_1,
g_atype1058_2,
};

static const long offsets1058 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1059 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_1 [] = {0xFF01,1096,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_2 [] = {0xFF01,990,0xFFF8,1,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
g_atype1059_1,
g_atype1059_2,
};

static const long offsets1059 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1060 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_1 [] = {0xFF01,1097,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_2 [] = {0xFF01,991,814,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
g_atype1060_1,
g_atype1060_2,
};

static const long offsets1060 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1061 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {214,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_1 [] = {0xFF01,1098,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_2 [] = {0xFF01,992,823,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
g_atype1061_1,
g_atype1061_2,
};

static const long offsets1061 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_REF,
};

static const uint16 attr_flags1062 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
};

static const long offsets1062 [] =
{
0,
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
};

static const uint16 attr_flags1063 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
};

static const long offsets1063 [] =
{
0,
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
};

static const uint16 attr_flags1064 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
};

static const long offsets1064 [] =
{
0,
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
};

static const uint16 attr_flags1065 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
};

static const long offsets1065 [] =
{
0,
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
};

static const uint16 attr_flags1066 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {213,823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
};

static const long offsets1066 [] =
{
0,
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
};

static const uint16 attr_flags1067 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
};

static const long offsets1067 [] =
{
0,
};

extern const char *names1068[];
static const uint32 types1068 [] =
{
SK_REF,
};

static const uint16 attr_flags1068 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1068_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1068 [] = {
g_atype1068_0,
};

static const long offsets1068 [] =
{
0,
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
};

static const uint16 attr_flags1069 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
};

static const long offsets1069 [] =
{
0,
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
};

static const uint16 attr_flags1070 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
};

static const long offsets1070 [] =
{
0,
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_REF,
};

static const uint16 attr_flags1071 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
};

static const long offsets1071 [] =
{
0,
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
};

static const uint16 attr_flags1072 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
};

static const long offsets1072 [] =
{
0,
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
};

static const uint16 attr_flags1073 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
};

static const long offsets1073 [] =
{
0,
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
};

static const uint16 attr_flags1074 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
};

static const long offsets1074 [] =
{
0,
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
};

static const uint16 attr_flags1075 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
};

static const long offsets1075 [] =
{
0,
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
};

static const uint16 attr_flags1076 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {212,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
};

static const long offsets1076 [] =
{
0,
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1077 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_1 [] = {113,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_2 [] = {113,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_3 [] = {0xFF01,1028,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
g_atype1077_1,
g_atype1077_2,
g_atype1077_3,
g_atype1077_4,
};

static const long offsets1077 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1081 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_1 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_2 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_4 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
g_atype1081_1,
g_atype1081_2,
g_atype1081_3,
g_atype1081_4,
};

static const long offsets1081 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1082 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_2 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_3 [] = {0xFF01,1026,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
g_atype1082_2,
g_atype1082_3,
g_atype1082_4,
g_atype1082_5,
};

static const long offsets1082 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1083 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_2 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_3 [] = {0xFF01,1027,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
g_atype1083_2,
g_atype1083_3,
g_atype1083_4,
g_atype1083_5,
};

static const long offsets1083 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1084 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {0xFF01,998,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
g_atype1084_2,
g_atype1084_3,
g_atype1084_4,
g_atype1084_5,
g_atype1084_6,
g_atype1084_7,
g_atype1084_8,
g_atype1084_9,
g_atype1084_10,
};

static const long offsets1084 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1085[];
static const uint32 types1085 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1085 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1085_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_1 [] = {0xFF01,999,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1085 [] = {
g_atype1085_0,
g_atype1085_1,
g_atype1085_2,
g_atype1085_3,
g_atype1085_4,
g_atype1085_5,
g_atype1085_6,
g_atype1085_7,
g_atype1085_8,
g_atype1085_9,
g_atype1085_10,
};

static const long offsets1085 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1086[];
static const uint32 types1086 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1086 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1086_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_1 [] = {0xFF01,1000,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1086 [] = {
g_atype1086_0,
g_atype1086_1,
g_atype1086_2,
g_atype1086_3,
g_atype1086_4,
g_atype1086_5,
g_atype1086_6,
g_atype1086_7,
g_atype1086_8,
g_atype1086_9,
g_atype1086_10,
};

static const long offsets1086 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1087[];
static const uint32 types1087 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1087 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1087_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_1 [] = {0xFF01,1001,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1087 [] = {
g_atype1087_0,
g_atype1087_1,
g_atype1087_2,
g_atype1087_3,
g_atype1087_4,
g_atype1087_5,
g_atype1087_6,
g_atype1087_7,
g_atype1087_8,
g_atype1087_9,
g_atype1087_10,
};

static const long offsets1087 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1088[];
static const uint32 types1088 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1088 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1088_0 [] = {213,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_1 [] = {0xFF01,1002,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1088 [] = {
g_atype1088_0,
g_atype1088_1,
g_atype1088_2,
g_atype1088_3,
g_atype1088_4,
g_atype1088_5,
g_atype1088_6,
g_atype1088_7,
g_atype1088_8,
g_atype1088_9,
g_atype1088_10,
};

static const long offsets1088 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1089[];
static const uint32 types1089 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1089 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1089_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_1 [] = {0xFF01,1003,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1089 [] = {
g_atype1089_0,
g_atype1089_1,
g_atype1089_2,
g_atype1089_3,
g_atype1089_4,
g_atype1089_5,
g_atype1089_6,
g_atype1089_7,
g_atype1089_8,
g_atype1089_9,
g_atype1089_10,
};

static const long offsets1089 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1090 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_1 [] = {0xFF01,1004,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
g_atype1090_1,
g_atype1090_2,
g_atype1090_3,
g_atype1090_4,
g_atype1090_5,
g_atype1090_6,
g_atype1090_7,
g_atype1090_8,
g_atype1090_9,
g_atype1090_10,
};

static const long offsets1090 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1091 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {0xFF01,1005,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_2 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_5 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_14 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
g_atype1091_2,
g_atype1091_3,
g_atype1091_4,
g_atype1091_5,
g_atype1091_6,
g_atype1091_7,
g_atype1091_8,
g_atype1091_9,
g_atype1091_10,
g_atype1091_11,
g_atype1091_12,
g_atype1091_13,
g_atype1091_14,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1092[];
static const uint32 types1092 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1092 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1092_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_1 [] = {0xFF01,1006,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_5 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_14 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1092 [] = {
g_atype1092_0,
g_atype1092_1,
g_atype1092_2,
g_atype1092_3,
g_atype1092_4,
g_atype1092_5,
g_atype1092_6,
g_atype1092_7,
g_atype1092_8,
g_atype1092_9,
g_atype1092_10,
g_atype1092_11,
g_atype1092_12,
g_atype1092_13,
g_atype1092_14,
};

static const long offsets1092 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1093[];
static const uint32 types1093 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1093 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1093_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_1 [] = {0xFF01,1007,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_2 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_5 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_6 [] = {13,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_15 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1093 [] = {
g_atype1093_0,
g_atype1093_1,
g_atype1093_2,
g_atype1093_3,
g_atype1093_4,
g_atype1093_5,
g_atype1093_6,
g_atype1093_7,
g_atype1093_8,
g_atype1093_9,
g_atype1093_10,
g_atype1093_11,
g_atype1093_12,
g_atype1093_13,
g_atype1093_14,
g_atype1093_15,
};

static const long offsets1093 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1094[];
static const uint32 types1094 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1094 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1094_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_1 [] = {0xFF01,1008,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_5 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_6 [] = {14,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_15 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1094 [] = {
g_atype1094_0,
g_atype1094_1,
g_atype1094_2,
g_atype1094_3,
g_atype1094_4,
g_atype1094_5,
g_atype1094_6,
g_atype1094_7,
g_atype1094_8,
g_atype1094_9,
g_atype1094_10,
g_atype1094_11,
g_atype1094_12,
g_atype1094_13,
g_atype1094_14,
g_atype1094_15,
};

static const long offsets1094 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1095[];
static const uint32 types1095 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1095 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1095_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_1 [] = {0xFF01,1009,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_2 [] = {1056,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_12 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1095 [] = {
g_atype1095_0,
g_atype1095_1,
g_atype1095_2,
g_atype1095_3,
g_atype1095_4,
g_atype1095_5,
g_atype1095_6,
g_atype1095_7,
g_atype1095_8,
g_atype1095_9,
g_atype1095_10,
g_atype1095_11,
g_atype1095_12,
};

static const long offsets1095 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1096 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {0xFF01,1010,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_2 [] = {1057,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_12 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
g_atype1096_2,
g_atype1096_3,
g_atype1096_4,
g_atype1096_5,
g_atype1096_6,
g_atype1096_7,
g_atype1096_8,
g_atype1096_9,
g_atype1096_10,
g_atype1096_11,
g_atype1096_12,
};

static const long offsets1096 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1097 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_1 [] = {0xFF01,1011,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_2 [] = {1058,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_12 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
g_atype1097_1,
g_atype1097_2,
g_atype1097_3,
g_atype1097_4,
g_atype1097_5,
g_atype1097_6,
g_atype1097_7,
g_atype1097_8,
g_atype1097_9,
g_atype1097_10,
g_atype1097_11,
g_atype1097_12,
};

static const long offsets1097 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1098 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_1 [] = {0xFF01,1012,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_2 [] = {1059,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_12 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
g_atype1098_1,
g_atype1098_2,
g_atype1098_3,
g_atype1098_4,
g_atype1098_5,
g_atype1098_6,
g_atype1098_7,
g_atype1098_8,
g_atype1098_9,
g_atype1098_10,
g_atype1098_11,
g_atype1098_12,
};

static const long offsets1098 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1099 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {213,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {0xFF01,1013,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_2 [] = {1060,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_3 [] = {214,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_7 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_8 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_12 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
g_atype1099_2,
g_atype1099_3,
g_atype1099_4,
g_atype1099_5,
g_atype1099_6,
g_atype1099_7,
g_atype1099_8,
g_atype1099_9,
g_atype1099_10,
g_atype1099_11,
g_atype1099_12,
};

static const long offsets1099 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1100 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_1 [] = {0xFF01,1014,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_2 [] = {1056,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_4 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_5 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_8 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_9 [] = {0xFF01,20,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
g_atype1100_1,
g_atype1100_2,
g_atype1100_3,
g_atype1100_4,
g_atype1100_5,
g_atype1100_6,
g_atype1100_7,
g_atype1100_8,
g_atype1100_9,
g_atype1100_10,
g_atype1100_11,
g_atype1100_12,
g_atype1100_13,
g_atype1100_14,
g_atype1100_15,
g_atype1100_16,
g_atype1100_17,
g_atype1100_18,
};

static const long offsets1100 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1101 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {0xFF01,1015,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_2 [] = {1057,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_5 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_8 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_9 [] = {0xFF01,20,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
g_atype1101_2,
g_atype1101_3,
g_atype1101_4,
g_atype1101_5,
g_atype1101_6,
g_atype1101_7,
g_atype1101_8,
g_atype1101_9,
g_atype1101_10,
g_atype1101_11,
g_atype1101_12,
g_atype1101_13,
g_atype1101_14,
g_atype1101_15,
g_atype1101_16,
g_atype1101_17,
g_atype1101_18,
};

static const long offsets1101 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1102 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {0xFF01,1016,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_2 [] = {1058,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_4 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_8 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_9 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
g_atype1102_2,
g_atype1102_3,
g_atype1102_4,
g_atype1102_5,
g_atype1102_6,
g_atype1102_7,
g_atype1102_8,
g_atype1102_9,
g_atype1102_10,
g_atype1102_11,
g_atype1102_12,
g_atype1102_13,
g_atype1102_14,
g_atype1102_15,
g_atype1102_16,
g_atype1102_17,
g_atype1102_18,
};

static const long offsets1102 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1103 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {0xFF01,1017,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_2 [] = {1059,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_8 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_9 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
g_atype1103_2,
g_atype1103_3,
g_atype1103_4,
g_atype1103_5,
g_atype1103_6,
g_atype1103_7,
g_atype1103_8,
g_atype1103_9,
g_atype1103_10,
g_atype1103_11,
g_atype1103_12,
g_atype1103_13,
g_atype1103_14,
g_atype1103_15,
g_atype1103_16,
g_atype1103_17,
g_atype1103_18,
};

static const long offsets1103 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1104 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {213,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_1 [] = {0xFF01,1018,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_2 [] = {1060,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_3 [] = {214,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_4 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_5 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_8 [] = {0xFF01,22,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_9 [] = {0xFF01,23,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_10 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_18 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
g_atype1104_1,
g_atype1104_2,
g_atype1104_3,
g_atype1104_4,
g_atype1104_5,
g_atype1104_6,
g_atype1104_7,
g_atype1104_8,
g_atype1104_9,
g_atype1104_10,
g_atype1104_11,
g_atype1104_12,
g_atype1104_13,
g_atype1104_14,
g_atype1104_15,
g_atype1104_16,
g_atype1104_17,
g_atype1104_18,
};

static const long offsets1104 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1105 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_1 [] = {0xFF01,1019,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_2 [] = {1056,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_4 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_5 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_8 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_9 [] = {0xFF01,20,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_10 [] = {13,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
g_atype1105_1,
g_atype1105_2,
g_atype1105_3,
g_atype1105_4,
g_atype1105_5,
g_atype1105_6,
g_atype1105_7,
g_atype1105_8,
g_atype1105_9,
g_atype1105_10,
g_atype1105_11,
g_atype1105_12,
g_atype1105_13,
g_atype1105_14,
g_atype1105_15,
g_atype1105_16,
g_atype1105_17,
g_atype1105_18,
g_atype1105_19,
};

static const long offsets1105 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1106 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {0xFF01,1020,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_2 [] = {1057,814,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_3 [] = {211,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_5 [] = {0xFF01,656,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_8 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_9 [] = {0xFF01,20,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_10 [] = {13,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
g_atype1106_2,
g_atype1106_3,
g_atype1106_4,
g_atype1106_5,
g_atype1106_6,
g_atype1106_7,
g_atype1106_8,
g_atype1106_9,
g_atype1106_10,
g_atype1106_11,
g_atype1106_12,
g_atype1106_13,
g_atype1106_14,
g_atype1106_15,
g_atype1106_16,
g_atype1106_17,
g_atype1106_18,
g_atype1106_19,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1107 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {0xFF01,1021,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_2 [] = {1058,0xFFF8,1,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_4 [] = {0xFF01,656,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_8 [] = {0xFF01,20,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_9 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_10 [] = {14,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
g_atype1107_2,
g_atype1107_3,
g_atype1107_4,
g_atype1107_5,
g_atype1107_6,
g_atype1107_7,
g_atype1107_8,
g_atype1107_9,
g_atype1107_10,
g_atype1107_11,
g_atype1107_12,
g_atype1107_13,
g_atype1107_14,
g_atype1107_15,
g_atype1107_16,
g_atype1107_17,
g_atype1107_18,
g_atype1107_19,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1108 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_1 [] = {0xFF01,1022,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_2 [] = {1059,814,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_3 [] = {212,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_8 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_9 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_10 [] = {14,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
g_atype1108_1,
g_atype1108_2,
g_atype1108_3,
g_atype1108_4,
g_atype1108_5,
g_atype1108_6,
g_atype1108_7,
g_atype1108_8,
g_atype1108_9,
g_atype1108_10,
g_atype1108_11,
g_atype1108_12,
g_atype1108_13,
g_atype1108_14,
g_atype1108_15,
g_atype1108_16,
g_atype1108_17,
g_atype1108_18,
g_atype1108_19,
};

static const long offsets1108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1109 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {213,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_1 [] = {0xFF01,1023,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_2 [] = {1060,823,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_3 [] = {214,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_4 [] = {0xFF01,661,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_5 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_8 [] = {0xFF01,22,823,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_9 [] = {0xFF01,23,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_10 [] = {15,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_11 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_19 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
g_atype1109_1,
g_atype1109_2,
g_atype1109_3,
g_atype1109_4,
g_atype1109_5,
g_atype1109_6,
g_atype1109_7,
g_atype1109_8,
g_atype1109_9,
g_atype1109_10,
g_atype1109_11,
g_atype1109_12,
g_atype1109_13,
g_atype1109_14,
g_atype1109_15,
g_atype1109_16,
g_atype1109_17,
g_atype1109_18,
g_atype1109_19,
};

static const long offsets1109 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1110 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {0xFF01,660,826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_1 [] = {0xFF01,660,826,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
g_atype1110_1,
};

static const long offsets1110 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1112 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_1 [] = {254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_2 [] = {254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_3 [] = {747,0xFF01,0xFFF9,2,808,0xFF01,254,753,0xFF01,0xFFF9,2,808,0xFF01,256,0xFF01,256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_5 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_6 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_9 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_10 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
g_atype1112_1,
g_atype1112_2,
g_atype1112_3,
g_atype1112_4,
g_atype1112_5,
g_atype1112_6,
g_atype1112_7,
g_atype1112_8,
g_atype1112_9,
g_atype1112_10,
};

static const long offsets1112 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1113 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {0xFF01,1081,0xFF01,925,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_1 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_2 [] = {0xFF01,1106,0xFF01,1081,0xFF01,925,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
g_atype1113_1,
g_atype1113_2,
};

static const long offsets1113 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1114 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_2 [] = {0xFF01,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
g_atype1114_1,
g_atype1114_2,
};

static const long offsets1114 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1115 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {0xFF01,1081,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_1 [] = {0xFF01,1081,0xFF01,139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_2 [] = {0xFF01,1081,0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_3 [] = {0xFF01,1081,0xFF01,146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_4 [] = {0xFF01,139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_6 [] = {0xFF01,1081,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_7 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_8 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
g_atype1115_1,
g_atype1115_2,
g_atype1115_3,
g_atype1115_4,
g_atype1115_5,
g_atype1115_6,
g_atype1115_7,
g_atype1115_8,
};

static const long offsets1115 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1121 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
g_atype1121_1,
g_atype1121_2,
g_atype1121_3,
};

static const long offsets1121 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1122 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_1 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
g_atype1122_1,
g_atype1122_2,
g_atype1122_3,
};

static const long offsets1122 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1125 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_1 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_2 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_3 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
g_atype1125_1,
g_atype1125_2,
g_atype1125_3,
};

static const long offsets1125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1126 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_9 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_10 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_12 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_13 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_15 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_16 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_17 [] = {0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_18 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_19 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_20 [] = {146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_21 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_22 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_23 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_24 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_25 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_26 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_27 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_28 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_30 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_31 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_32 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_33 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_34 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_35 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_36 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_37 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_38 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_39 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_40 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_41 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_42 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_43 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_44 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_45 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_46 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_47 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_48 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_49 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_50 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_51 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
g_atype1126_1,
g_atype1126_2,
g_atype1126_3,
g_atype1126_4,
g_atype1126_5,
g_atype1126_6,
g_atype1126_7,
g_atype1126_8,
g_atype1126_9,
g_atype1126_10,
g_atype1126_11,
g_atype1126_12,
g_atype1126_13,
g_atype1126_14,
g_atype1126_15,
g_atype1126_16,
g_atype1126_17,
g_atype1126_18,
g_atype1126_19,
g_atype1126_20,
g_atype1126_21,
g_atype1126_22,
g_atype1126_23,
g_atype1126_24,
g_atype1126_25,
g_atype1126_26,
g_atype1126_27,
g_atype1126_28,
g_atype1126_29,
g_atype1126_30,
g_atype1126_31,
g_atype1126_32,
g_atype1126_33,
g_atype1126_34,
g_atype1126_35,
g_atype1126_36,
g_atype1126_37,
g_atype1126_38,
g_atype1126_39,
g_atype1126_40,
g_atype1126_41,
g_atype1126_42,
g_atype1126_43,
g_atype1126_44,
g_atype1126_45,
g_atype1126_46,
g_atype1126_47,
g_atype1126_48,
g_atype1126_49,
g_atype1126_50,
g_atype1126_51,
};

static const long offsets1126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @LNGOFF(21,4,0,0),
+ @LNGOFF(21,4,0,1),
+ @LNGOFF(21,4,0,2),
+ @LNGOFF(21,4,0,3),
+ @LNGOFF(21,4,0,4),
+ @LNGOFF(21,4,0,5),
+ @LNGOFF(21,4,0,6),
+ @LNGOFF(21,4,0,7),
+ @LNGOFF(21,4,0,8),
+ @LNGOFF(21,4,0,9),
+ @LNGOFF(21,4,0,10),
+ @LNGOFF(21,4,0,11),
+ @LNGOFF(21,4,0,12),
+ @LNGOFF(21,4,0,13),
+ @LNGOFF(21,4,0,14),
+ @LNGOFF(21,4,0,15),
+ @LNGOFF(21,4,0,16),
+ @LNGOFF(21,4,0,17),
+ @LNGOFF(21,4,0,18),
+ @LNGOFF(21,4,0,19),
+ @LNGOFF(21,4,0,20),
+ @LNGOFF(21,4,0,21),
+ @LNGOFF(21,4,0,22),
+ @LNGOFF(21,4,0,23),
+ @LNGOFF(21,4,0,24),
+ @LNGOFF(21,4,0,25),
+ @LNGOFF(21,4,0,26),
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1127 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_9 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_10 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_12 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_13 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_15 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_16 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_17 [] = {0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_18 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_19 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_20 [] = {146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_21 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_22 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_23 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_24 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_25 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_26 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_27 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_28 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_30 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_31 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_32 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_33 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_34 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_35 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_36 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_37 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_38 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_39 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_40 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_41 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_42 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_43 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_44 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_45 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_46 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_47 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_48 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_49 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_50 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_51 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
g_atype1127_1,
g_atype1127_2,
g_atype1127_3,
g_atype1127_4,
g_atype1127_5,
g_atype1127_6,
g_atype1127_7,
g_atype1127_8,
g_atype1127_9,
g_atype1127_10,
g_atype1127_11,
g_atype1127_12,
g_atype1127_13,
g_atype1127_14,
g_atype1127_15,
g_atype1127_16,
g_atype1127_17,
g_atype1127_18,
g_atype1127_19,
g_atype1127_20,
g_atype1127_21,
g_atype1127_22,
g_atype1127_23,
g_atype1127_24,
g_atype1127_25,
g_atype1127_26,
g_atype1127_27,
g_atype1127_28,
g_atype1127_29,
g_atype1127_30,
g_atype1127_31,
g_atype1127_32,
g_atype1127_33,
g_atype1127_34,
g_atype1127_35,
g_atype1127_36,
g_atype1127_37,
g_atype1127_38,
g_atype1127_39,
g_atype1127_40,
g_atype1127_41,
g_atype1127_42,
g_atype1127_43,
g_atype1127_44,
g_atype1127_45,
g_atype1127_46,
g_atype1127_47,
g_atype1127_48,
g_atype1127_49,
g_atype1127_50,
g_atype1127_51,
};

static const long offsets1127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @LNGOFF(21,4,0,0),
+ @LNGOFF(21,4,0,1),
+ @LNGOFF(21,4,0,2),
+ @LNGOFF(21,4,0,3),
+ @LNGOFF(21,4,0,4),
+ @LNGOFF(21,4,0,5),
+ @LNGOFF(21,4,0,6),
+ @LNGOFF(21,4,0,7),
+ @LNGOFF(21,4,0,8),
+ @LNGOFF(21,4,0,9),
+ @LNGOFF(21,4,0,10),
+ @LNGOFF(21,4,0,11),
+ @LNGOFF(21,4,0,12),
+ @LNGOFF(21,4,0,13),
+ @LNGOFF(21,4,0,14),
+ @LNGOFF(21,4,0,15),
+ @LNGOFF(21,4,0,16),
+ @LNGOFF(21,4,0,17),
+ @LNGOFF(21,4,0,18),
+ @LNGOFF(21,4,0,19),
+ @LNGOFF(21,4,0,20),
+ @LNGOFF(21,4,0,21),
+ @LNGOFF(21,4,0,22),
+ @LNGOFF(21,4,0,23),
+ @LNGOFF(21,4,0,24),
+ @LNGOFF(21,4,0,25),
+ @LNGOFF(21,4,0,26),
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1128 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_1 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_2 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_3 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_9 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_10 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_12 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_13 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_14 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_15 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_16 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_17 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_18 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_19 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_20 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_21 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_22 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
g_atype1128_1,
g_atype1128_2,
g_atype1128_3,
g_atype1128_4,
g_atype1128_5,
g_atype1128_6,
g_atype1128_7,
g_atype1128_8,
g_atype1128_9,
g_atype1128_10,
g_atype1128_11,
g_atype1128_12,
g_atype1128_13,
g_atype1128_14,
g_atype1128_15,
g_atype1128_16,
g_atype1128_17,
g_atype1128_18,
g_atype1128_19,
g_atype1128_20,
g_atype1128_21,
g_atype1128_22,
};

static const long offsets1128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1129 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_9 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_10 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_12 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_13 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_15 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_16 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_17 [] = {0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_18 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_19 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_20 [] = {146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_21 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_22 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_23 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_24 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_25 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_26 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_27 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_28 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_29 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_30 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_31 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_32 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_33 [] = {0xFF01,12,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_34 [] = {140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_35 [] = {901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_36 [] = {112,0xFF01,894,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_37 [] = {0xFF01,1104,0xFF01,140,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_38 [] = {0xFF01,1104,0xFF01,139,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_39 [] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_40 [] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_41 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_42 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_43 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_44 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_45 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_46 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_47 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_48 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_49 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_50 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_51 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_52 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_53 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_54 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_55 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_56 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_57 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_58 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_59 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_60 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_61 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_62 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_63 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_64 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_65 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_66 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_67 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_68 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_69 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_70 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_71 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_72 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_73 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_74 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_75 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_76 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_77 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_78 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_79 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_80 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_81 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_82 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_83 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_84 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_85 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
g_atype1129_1,
g_atype1129_2,
g_atype1129_3,
g_atype1129_4,
g_atype1129_5,
g_atype1129_6,
g_atype1129_7,
g_atype1129_8,
g_atype1129_9,
g_atype1129_10,
g_atype1129_11,
g_atype1129_12,
g_atype1129_13,
g_atype1129_14,
g_atype1129_15,
g_atype1129_16,
g_atype1129_17,
g_atype1129_18,
g_atype1129_19,
g_atype1129_20,
g_atype1129_21,
g_atype1129_22,
g_atype1129_23,
g_atype1129_24,
g_atype1129_25,
g_atype1129_26,
g_atype1129_27,
g_atype1129_28,
g_atype1129_29,
g_atype1129_30,
g_atype1129_31,
g_atype1129_32,
g_atype1129_33,
g_atype1129_34,
g_atype1129_35,
g_atype1129_36,
g_atype1129_37,
g_atype1129_38,
g_atype1129_39,
g_atype1129_40,
g_atype1129_41,
g_atype1129_42,
g_atype1129_43,
g_atype1129_44,
g_atype1129_45,
g_atype1129_46,
g_atype1129_47,
g_atype1129_48,
g_atype1129_49,
g_atype1129_50,
g_atype1129_51,
g_atype1129_52,
g_atype1129_53,
g_atype1129_54,
g_atype1129_55,
g_atype1129_56,
g_atype1129_57,
g_atype1129_58,
g_atype1129_59,
g_atype1129_60,
g_atype1129_61,
g_atype1129_62,
g_atype1129_63,
g_atype1129_64,
g_atype1129_65,
g_atype1129_66,
g_atype1129_67,
g_atype1129_68,
g_atype1129_69,
g_atype1129_70,
g_atype1129_71,
g_atype1129_72,
g_atype1129_73,
g_atype1129_74,
g_atype1129_75,
g_atype1129_76,
g_atype1129_77,
g_atype1129_78,
g_atype1129_79,
g_atype1129_80,
g_atype1129_81,
g_atype1129_82,
g_atype1129_83,
g_atype1129_84,
g_atype1129_85,
};

static const long offsets1129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
+ @CHROFF(41,0),
+ @CHROFF(41,1),
+ @CHROFF(41,2),
+ @CHROFF(41,3),
+ @CHROFF(41,4),
+ @LNGOFF(41,5,0,0),
+ @LNGOFF(41,5,0,1),
+ @LNGOFF(41,5,0,2),
+ @LNGOFF(41,5,0,3),
+ @LNGOFF(41,5,0,4),
+ @LNGOFF(41,5,0,5),
+ @LNGOFF(41,5,0,6),
+ @LNGOFF(41,5,0,7),
+ @LNGOFF(41,5,0,8),
+ @LNGOFF(41,5,0,9),
+ @LNGOFF(41,5,0,10),
+ @LNGOFF(41,5,0,11),
+ @LNGOFF(41,5,0,12),
+ @LNGOFF(41,5,0,13),
+ @LNGOFF(41,5,0,14),
+ @LNGOFF(41,5,0,15),
+ @LNGOFF(41,5,0,16),
+ @LNGOFF(41,5,0,17),
+ @LNGOFF(41,5,0,18),
+ @LNGOFF(41,5,0,19),
+ @LNGOFF(41,5,0,20),
+ @LNGOFF(41,5,0,21),
+ @LNGOFF(41,5,0,22),
+ @LNGOFF(41,5,0,23),
+ @LNGOFF(41,5,0,24),
+ @LNGOFF(41,5,0,25),
+ @LNGOFF(41,5,0,26),
+ @LNGOFF(41,5,0,27),
+ @LNGOFF(41,5,0,28),
+ @LNGOFF(41,5,0,29),
+ @LNGOFF(41,5,0,30),
+ @LNGOFF(41,5,0,31),
+ @LNGOFF(41,5,0,32),
+ @LNGOFF(41,5,0,33),
+ @LNGOFF(41,5,0,34),
+ @LNGOFF(41,5,0,35),
+ @LNGOFF(41,5,0,36),
+ @LNGOFF(41,5,0,37),
+ @LNGOFF(41,5,0,38),
+ @LNGOFF(41,5,0,39),
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1130 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_1 [] = {0xFF01,89,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_2 [] = {662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_3 [] = {663,841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_4 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_5 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_6 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_7 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_8 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_9 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_10 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_12 [] = {658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_13 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_15 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_16 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_17 [] = {0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_18 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_19 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_20 [] = {146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_21 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_22 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_23 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_24 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_25 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_26 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_27 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_28 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_29 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_30 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_31 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_32 [] = {0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_33 [] = {0xFF01,12,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_34 [] = {140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_35 [] = {901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_36 [] = {112,0xFF01,894,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_37 [] = {0xFF01,1104,0xFF01,140,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_38 [] = {0xFF01,1104,0xFF01,139,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_39 [] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_40 [] = {0xFF01,1104,0xFF01,901,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_41 [] = {0xFF01,656,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_42 [] = {0xFF01,20,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_43 [] = {0xFF01,656,0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_44 [] = {0xFF01,20,0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_45 [] = {0xFF01,656,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_46 [] = {0xFF01,20,0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_47 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_48 [] = {0xFF01,21,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_49 [] = {0xFF01,656,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_50 [] = {0xFF01,20,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_51 [] = {0xFF01,656,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_52 [] = {0xFF01,20,0xFF01,140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_53 [] = {0xFF01,656,0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_54 [] = {0xFF01,20,0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_55 [] = {0xFF01,656,0xFF01,1081,0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_56 [] = {0xFF01,20,0xFF01,1081,0xFF01,901,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_57 [] = {0xFF01,656,0xFF01,1081,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_58 [] = {0xFF01,20,0xFF01,1081,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_59 [] = {0xFF01,656,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_60 [] = {0xFF01,20,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_61 [] = {844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_62 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_63 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_64 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_65 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_66 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_67 [] = {841,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_68 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_69 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_70 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_71 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_72 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_73 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_74 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_75 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_76 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_77 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_78 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_79 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_80 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_81 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_82 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_83 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_84 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_85 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_86 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_87 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_88 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_89 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_90 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_91 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_92 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_93 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_94 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_95 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_96 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_97 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_98 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_99 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_100 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_101 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_102 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_103 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_104 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_105 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_106 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_107 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_108 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_109 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_110 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_111 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_112 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_113 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_114 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_115 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_116 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_117 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_118 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_119 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_120 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_121 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_122 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_123 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_124 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_125 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
g_atype1130_1,
g_atype1130_2,
g_atype1130_3,
g_atype1130_4,
g_atype1130_5,
g_atype1130_6,
g_atype1130_7,
g_atype1130_8,
g_atype1130_9,
g_atype1130_10,
g_atype1130_11,
g_atype1130_12,
g_atype1130_13,
g_atype1130_14,
g_atype1130_15,
g_atype1130_16,
g_atype1130_17,
g_atype1130_18,
g_atype1130_19,
g_atype1130_20,
g_atype1130_21,
g_atype1130_22,
g_atype1130_23,
g_atype1130_24,
g_atype1130_25,
g_atype1130_26,
g_atype1130_27,
g_atype1130_28,
g_atype1130_29,
g_atype1130_30,
g_atype1130_31,
g_atype1130_32,
g_atype1130_33,
g_atype1130_34,
g_atype1130_35,
g_atype1130_36,
g_atype1130_37,
g_atype1130_38,
g_atype1130_39,
g_atype1130_40,
g_atype1130_41,
g_atype1130_42,
g_atype1130_43,
g_atype1130_44,
g_atype1130_45,
g_atype1130_46,
g_atype1130_47,
g_atype1130_48,
g_atype1130_49,
g_atype1130_50,
g_atype1130_51,
g_atype1130_52,
g_atype1130_53,
g_atype1130_54,
g_atype1130_55,
g_atype1130_56,
g_atype1130_57,
g_atype1130_58,
g_atype1130_59,
g_atype1130_60,
g_atype1130_61,
g_atype1130_62,
g_atype1130_63,
g_atype1130_64,
g_atype1130_65,
g_atype1130_66,
g_atype1130_67,
g_atype1130_68,
g_atype1130_69,
g_atype1130_70,
g_atype1130_71,
g_atype1130_72,
g_atype1130_73,
g_atype1130_74,
g_atype1130_75,
g_atype1130_76,
g_atype1130_77,
g_atype1130_78,
g_atype1130_79,
g_atype1130_80,
g_atype1130_81,
g_atype1130_82,
g_atype1130_83,
g_atype1130_84,
g_atype1130_85,
g_atype1130_86,
g_atype1130_87,
g_atype1130_88,
g_atype1130_89,
g_atype1130_90,
g_atype1130_91,
g_atype1130_92,
g_atype1130_93,
g_atype1130_94,
g_atype1130_95,
g_atype1130_96,
g_atype1130_97,
g_atype1130_98,
g_atype1130_99,
g_atype1130_100,
g_atype1130_101,
g_atype1130_102,
g_atype1130_103,
g_atype1130_104,
g_atype1130_105,
g_atype1130_106,
g_atype1130_107,
g_atype1130_108,
g_atype1130_109,
g_atype1130_110,
g_atype1130_111,
g_atype1130_112,
g_atype1130_113,
g_atype1130_114,
g_atype1130_115,
g_atype1130_116,
g_atype1130_117,
g_atype1130_118,
g_atype1130_119,
g_atype1130_120,
g_atype1130_121,
g_atype1130_122,
g_atype1130_123,
g_atype1130_124,
g_atype1130_125,
};

static const long offsets1130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
+ @CHROFF(61,0),
+ @CHROFF(61,1),
+ @CHROFF(61,2),
+ @CHROFF(61,3),
+ @CHROFF(61,4),
+ @LNGOFF(61,5,0,0),
+ @LNGOFF(61,5,0,1),
+ @LNGOFF(61,5,0,2),
+ @LNGOFF(61,5,0,3),
+ @LNGOFF(61,5,0,4),
+ @LNGOFF(61,5,0,5),
+ @LNGOFF(61,5,0,6),
+ @LNGOFF(61,5,0,7),
+ @LNGOFF(61,5,0,8),
+ @LNGOFF(61,5,0,9),
+ @LNGOFF(61,5,0,10),
+ @LNGOFF(61,5,0,11),
+ @LNGOFF(61,5,0,12),
+ @LNGOFF(61,5,0,13),
+ @LNGOFF(61,5,0,14),
+ @LNGOFF(61,5,0,15),
+ @LNGOFF(61,5,0,16),
+ @LNGOFF(61,5,0,17),
+ @LNGOFF(61,5,0,18),
+ @LNGOFF(61,5,0,19),
+ @LNGOFF(61,5,0,20),
+ @LNGOFF(61,5,0,21),
+ @LNGOFF(61,5,0,22),
+ @LNGOFF(61,5,0,23),
+ @LNGOFF(61,5,0,24),
+ @LNGOFF(61,5,0,25),
+ @LNGOFF(61,5,0,26),
+ @LNGOFF(61,5,0,27),
+ @LNGOFF(61,5,0,28),
+ @LNGOFF(61,5,0,29),
+ @LNGOFF(61,5,0,30),
+ @LNGOFF(61,5,0,31),
+ @LNGOFF(61,5,0,32),
+ @LNGOFF(61,5,0,33),
+ @LNGOFF(61,5,0,34),
+ @LNGOFF(61,5,0,35),
+ @LNGOFF(61,5,0,36),
+ @LNGOFF(61,5,0,37),
+ @LNGOFF(61,5,0,38),
+ @LNGOFF(61,5,0,39),
+ @LNGOFF(61,5,0,40),
+ @LNGOFF(61,5,0,41),
+ @LNGOFF(61,5,0,42),
+ @LNGOFF(61,5,0,43),
+ @LNGOFF(61,5,0,44),
+ @LNGOFF(61,5,0,45),
+ @LNGOFF(61,5,0,46),
+ @LNGOFF(61,5,0,47),
+ @LNGOFF(61,5,0,48),
+ @LNGOFF(61,5,0,49),
+ @LNGOFF(61,5,0,50),
+ @LNGOFF(61,5,0,51),
+ @LNGOFF(61,5,0,52),
+ @LNGOFF(61,5,0,53),
+ @LNGOFF(61,5,0,54),
+ @LNGOFF(61,5,0,55),
+ @LNGOFF(61,5,0,56),
+ @LNGOFF(61,5,0,57),
+ @LNGOFF(61,5,0,58),
+ @LNGOFF(61,5,0,59),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
};

static const uint16 attr_flags1132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
};

static const long offsets1132 [] =
{
0,
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
};

static const uint16 attr_flags1133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
};

static const long offsets1133 [] =
{
0,
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
};

static const uint16 attr_flags1134 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
};

static const long offsets1134 [] =
{
0,
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
};

static const uint16 attr_flags1135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
};

static const long offsets1135 [] =
{
0,
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
};

static const uint16 attr_flags1136 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
};

static const long offsets1136 [] =
{
0,
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
};

static const uint16 attr_flags1137 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
};

static const long offsets1137 [] =
{
0,
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
};

static const uint16 attr_flags1138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
};

static const long offsets1138 [] =
{
0,
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
};

static const uint16 attr_flags1139 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
};

static const long offsets1139 [] =
{
0,
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_REF,
};

static const uint16 attr_flags1140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
};

static const long offsets1140 [] =
{
0,
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_REF,
};

static const uint16 attr_flags1141 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
};

static const long offsets1141 [] =
{
0,
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_REF,
};

static const uint16 attr_flags1142 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
};

static const long offsets1142 [] =
{
0,
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_REF,
};

static const uint16 attr_flags1143 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
};

static const long offsets1143 [] =
{
0,
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_REF,
};

static const uint16 attr_flags1144 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
};

static const long offsets1144 [] =
{
0,
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
};

static const uint16 attr_flags1145 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
};

static const long offsets1145 [] =
{
0,
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
};

static const uint16 attr_flags1146 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
};

static const long offsets1146 [] =
{
0,
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
};

static const uint16 attr_flags1147 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
};

static const long offsets1147 [] =
{
0,
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
};

static const uint16 attr_flags1148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
};

static const long offsets1148 [] =
{
0,
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
};

static const uint16 attr_flags1149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
};

static const long offsets1149 [] =
{
0,
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
};

static const uint16 attr_flags1150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
};

static const long offsets1150 [] =
{
0,
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
};

static const uint16 attr_flags1151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
};

static const long offsets1151 [] =
{
0,
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
};

static const uint16 attr_flags1152 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
};

static const long offsets1152 [] =
{
0,
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
};

static const uint16 attr_flags1153 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
};

static const long offsets1153 [] =
{
0,
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
};

static const uint16 attr_flags1154 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
};

static const long offsets1154 [] =
{
0,
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_REF,
};

static const uint16 attr_flags1155 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
};

static const long offsets1155 [] =
{
0,
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
};

static const uint16 attr_flags1156 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
};

static const long offsets1156 [] =
{
0,
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
};

static const uint16 attr_flags1157 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
};

static const long offsets1157 [] =
{
0,
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
};

static const uint16 attr_flags1158 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
};

static const long offsets1158 [] =
{
0,
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
};

static const uint16 attr_flags1159 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
};

static const long offsets1159 [] =
{
0,
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
};

static const uint16 attr_flags1160 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
};

static const long offsets1160 [] =
{
0,
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
};

static const uint16 attr_flags1161 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
};

static const long offsets1161 [] =
{
0,
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
};

static const uint16 attr_flags1162 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
};

static const long offsets1162 [] =
{
0,
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
};

static const uint16 attr_flags1163 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
};

static const long offsets1163 [] =
{
0,
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
};

static const uint16 attr_flags1164 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
};

static const long offsets1164 [] =
{
0,
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
};

static const uint16 attr_flags1165 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
};

static const long offsets1165 [] =
{
0,
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
};

static const uint16 attr_flags1166 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
};

static const long offsets1166 [] =
{
0,
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
};

static const uint16 attr_flags1167 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
};

static const long offsets1167 [] =
{
0,
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
};

static const uint16 attr_flags1168 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
};

static const long offsets1168 [] =
{
0,
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
};

static const uint16 attr_flags1169 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {0xFF01,681,0xFF01,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
};

static const long offsets1169 [] =
{
0,
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_2 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_3 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_4 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_5 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_6 [] = {1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_7 [] = {0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_11 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
g_atype1170_2,
g_atype1170_3,
g_atype1170_4,
g_atype1170_5,
g_atype1170_6,
g_atype1170_7,
g_atype1170_8,
g_atype1170_9,
g_atype1170_10,
g_atype1170_11,
};

static const long offsets1170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @LNGOFF(8,3,0,0),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {0xFF01,681,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_5 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
g_atype1172_5,
};

static const long offsets1172 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {0xFF01,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {0xFF01,1109,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_5 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_6 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_7 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_8 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_9 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_10 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_11 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_12 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_13 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_14 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_15 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_16 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_17 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_18 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_19 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_20 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_21 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_22 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_23 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_24 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_25 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_26 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_27 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_28 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_30 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_31 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
g_atype1173_5,
g_atype1173_6,
g_atype1173_7,
g_atype1173_8,
g_atype1173_9,
g_atype1173_10,
g_atype1173_11,
g_atype1173_12,
g_atype1173_13,
g_atype1173_14,
g_atype1173_15,
g_atype1173_16,
g_atype1173_17,
g_atype1173_18,
g_atype1173_19,
g_atype1173_20,
g_atype1173_21,
g_atype1173_22,
g_atype1173_23,
g_atype1173_24,
g_atype1173_25,
g_atype1173_26,
g_atype1173_27,
g_atype1173_28,
g_atype1173_29,
g_atype1173_30,
g_atype1173_31,
};

static const long offsets1173 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @CHROFF(8,4),
+ @CHROFF(8,5),
+ @CHROFF(8,6),
+ @CHROFF(8,7),
+ @CHROFF(8,8),
+ @CHROFF(8,9),
+ @CHROFF(8,10),
+ @CHROFF(8,11),
+ @CHROFF(8,12),
+ @LNGOFF(8,13,0,0),
+ @LNGOFF(8,13,0,1),
+ @LNGOFF(8,13,0,2),
+ @LNGOFF(8,13,0,3),
+ @LNGOFF(8,13,0,4),
+ @LNGOFF(8,13,0,5),
+ @LNGOFF(8,13,0,6),
+ @LNGOFF(8,13,0,7),
+ @LNGOFF(8,13,0,8),
+ @I64OFF(8,13,0,9,0,0,0),
+ @I64OFF(8,13,0,9,0,0,1),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {0xFF01,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {0xFF01,1109,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_6 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_7 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_8 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_9 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_10 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_12 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_13 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_14 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_15 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_16 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_17 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_18 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_19 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_20 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_21 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_22 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_23 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_24 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_25 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_26 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_27 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_28 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_30 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_31 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_32 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_33 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_34 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_35 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_36 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_37 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_38 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_39 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_40 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_41 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_42 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_43 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_44 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_45 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_46 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_47 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_48 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_49 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_50 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_51 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_52 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
g_atype1174_6,
g_atype1174_7,
g_atype1174_8,
g_atype1174_9,
g_atype1174_10,
g_atype1174_11,
g_atype1174_12,
g_atype1174_13,
g_atype1174_14,
g_atype1174_15,
g_atype1174_16,
g_atype1174_17,
g_atype1174_18,
g_atype1174_19,
g_atype1174_20,
g_atype1174_21,
g_atype1174_22,
g_atype1174_23,
g_atype1174_24,
g_atype1174_25,
g_atype1174_26,
g_atype1174_27,
g_atype1174_28,
g_atype1174_29,
g_atype1174_30,
g_atype1174_31,
g_atype1174_32,
g_atype1174_33,
g_atype1174_34,
g_atype1174_35,
g_atype1174_36,
g_atype1174_37,
g_atype1174_38,
g_atype1174_39,
g_atype1174_40,
g_atype1174_41,
g_atype1174_42,
g_atype1174_43,
g_atype1174_44,
g_atype1174_45,
g_atype1174_46,
g_atype1174_47,
g_atype1174_48,
g_atype1174_49,
g_atype1174_50,
g_atype1174_51,
g_atype1174_52,
};

static const long offsets1174 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {0xFF01,886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {886,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {0xFF01,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {0xFF01,1109,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_4 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_5 [] = {0xFF01,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_6 [] = {0xFF01,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_7 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_8 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_9 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_10 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_11 [] = {0xFF01,658,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_12 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_13 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_14 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_15 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_16 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_17 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_18 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_19 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_20 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_21 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_22 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_23 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_24 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_25 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_26 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_27 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_28 [] = {826,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_29 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_30 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_31 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_32 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_33 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_34 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_35 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_36 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_37 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_38 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_39 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_40 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_41 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_42 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_43 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_44 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_45 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_46 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_47 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_48 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_49 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_50 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_51 [] = {811,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_52 [] = {811,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
g_atype1175_4,
g_atype1175_5,
g_atype1175_6,
g_atype1175_7,
g_atype1175_8,
g_atype1175_9,
g_atype1175_10,
g_atype1175_11,
g_atype1175_12,
g_atype1175_13,
g_atype1175_14,
g_atype1175_15,
g_atype1175_16,
g_atype1175_17,
g_atype1175_18,
g_atype1175_19,
g_atype1175_20,
g_atype1175_21,
g_atype1175_22,
g_atype1175_23,
g_atype1175_24,
g_atype1175_25,
g_atype1175_26,
g_atype1175_27,
g_atype1175_28,
g_atype1175_29,
g_atype1175_30,
g_atype1175_31,
g_atype1175_32,
g_atype1175_33,
g_atype1175_34,
g_atype1175_35,
g_atype1175_36,
g_atype1175_37,
g_atype1175_38,
g_atype1175_39,
g_atype1175_40,
g_atype1175_41,
g_atype1175_42,
g_atype1175_43,
g_atype1175_44,
g_atype1175_45,
g_atype1175_46,
g_atype1175_47,
g_atype1175_48,
g_atype1175_49,
g_atype1175_50,
g_atype1175_51,
g_atype1175_52,
};

static const long offsets1175 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
g_atype1176_5,
g_atype1176_6,
g_atype1176_7,
};

static const long offsets1176 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {0xFF01,662,844,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {847,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_3 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_4 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_5 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_6 [] = {814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_7 [] = {814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
g_atype1177_3,
g_atype1177_4,
g_atype1177_5,
g_atype1177_6,
g_atype1177_7,
};

static const long offsets1177 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"RX_CHARACTER_SET",
	names2,
	types2,
	attr_flags2,
	gtypes2,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets2,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names4,
	types4,
	attr_flags4,
	gtypes4,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets4,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names5,
	types5,
	attr_flags5,
	gtypes5,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets5,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_BOOLEAN_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_ARRAY_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names9,
	types9,
	attr_flags9,
	gtypes9,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets9,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PR_ACTION_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_NESTED_LIST_FLATTENER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_LABELED_TYPE",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names29,
	types29,
	attr_flags29,
	gtypes29,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets29,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PR_CONFLICT",
	names47,
	types47,
	attr_flags47,
	gtypes47,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets47,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names63,
	types63,
	attr_flags63,
	gtypes63,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets63,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names72,
	types72,
	attr_flags72,
	gtypes72,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets72,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names73,
	types73,
	attr_flags73,
	gtypes73,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets73,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names78,
	types78,
	attr_flags78,
	gtypes78,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets78,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names79,
	types79,
	attr_flags79,
	gtypes79,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets79,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names80,
	types80,
	attr_flags80,
	gtypes80,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets80,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_GOBO_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEYACC_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 16,
	(long) 16,
	"PR_PARSER_ENGINE",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DP_COMMAND",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names105,
	types105,
	attr_flags105,
	gtypes105,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets105,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_32_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_PAIR",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names121,
	types121,
	attr_flags121,
	gtypes121,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets121,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names131,
	types131,
	attr_flags131,
	gtypes131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets131,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_NESTED_LIST",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 5,
	(long) 5,
	"PR_TRANSITION",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PR_SYMBOL",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 10,
	(long) 10,
	"PR_VARIABLE",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PR_TOKEN",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PR_PORTION",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PR_REDUCTION",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PR_RULE",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_DOC_GENERATOR",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_HTML_DOC_GENERATOR",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_XML_DOC_GENERATOR",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names159,
	types159,
	attr_flags159,
	gtypes159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets159,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names161,
	types161,
	attr_flags161,
	gtypes161,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets161,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names210,
	types210,
	attr_flags210,
	gtypes210,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets210,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_IMPORTED_FORMATTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names223,
	types223,
	attr_flags223,
	gtypes223,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets223,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names229,
	types229,
	attr_flags229,
	gtypes229,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets229,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names231,
	types231,
	attr_flags231,
	gtypes231,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets231,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names232,
	types232,
	attr_flags232,
	gtypes232,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets232,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names237,
	types237,
	attr_flags237,
	gtypes237,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets237,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names253,
	types253,
	attr_flags253,
	gtypes253,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets253,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names255,
	types255,
	attr_flags255,
	gtypes255,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets255,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names260,
	types260,
	attr_flags260,
	gtypes260,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets260,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names268,
	types268,
	attr_flags268,
	gtypes268,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets268,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names269,
	types269,
	attr_flags269,
	gtypes269,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets269,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_ARGUMENTS",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_POSITION",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 20,
	(long) 20,
	"PR_PARSER_GENERATOR",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PR_TYPE",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PR_BASIC_TYPE",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_NATURAL_32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_ACTION",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"PR_STATE",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_BYTE_CODE",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_INTEGER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets942,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PR_ERROR_ACTION",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets943,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names946,
	types946,
	attr_flags946,
	gtypes946,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets946,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names954,
	types954,
	attr_flags954,
	gtypes954,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets954,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names955,
	types955,
	attr_flags955,
	gtypes955,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets955,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names956,
	types956,
	attr_flags956,
	gtypes956,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets956,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names958,
	types958,
	attr_flags958,
	gtypes958,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets958,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names959,
	types959,
	attr_flags959,
	gtypes959,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets959,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names960,
	types960,
	attr_flags960,
	gtypes960,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets960,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_TEXT_OUTPUT_FILE",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names989,
	types989,
	attr_flags989,
	gtypes989,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets989,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names990,
	types990,
	attr_flags990,
	gtypes990,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets990,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names991,
	types991,
	attr_flags991,
	gtypes991,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets991,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names992,
	types992,
	attr_flags992,
	gtypes992,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets992,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names993,
	types993,
	attr_flags993,
	gtypes993,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets993,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names994,
	types994,
	attr_flags994,
	gtypes994,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets994,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names995,
	types995,
	attr_flags995,
	gtypes995,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets995,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names996,
	types996,
	attr_flags996,
	gtypes996,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets996,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names997,
	types997,
	attr_flags997,
	gtypes997,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets997,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names999,
	types999,
	attr_flags999,
	gtypes999,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets999,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1000,
	types1000,
	attr_flags1000,
	gtypes1000,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1000,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1001,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1002,
	types1002,
	attr_flags1002,
	gtypes1002,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1002,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1003,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1004,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1005,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1006,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1007,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1008,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1009,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1010,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1011,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1012,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1013,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1014,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1015,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1016,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1017,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1018,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1019,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1020,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1021,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1022,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1023,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1024,
	"20130823"
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1027,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1028,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1068,
	types1068,
	attr_flags1068,
	gtypes1068,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1068,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1081,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1082,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1083,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1084,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1085,
	types1085,
	attr_flags1085,
	gtypes1085,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1085,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1086,
	types1086,
	attr_flags1086,
	gtypes1086,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1086,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1087,
	types1087,
	attr_flags1087,
	gtypes1087,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1087,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1088,
	types1088,
	attr_flags1088,
	gtypes1088,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1088,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1089,
	types1089,
	attr_flags1089,
	gtypes1089,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1089,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1090,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1091,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1092,
	types1092,
	attr_flags1092,
	gtypes1092,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1092,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1093,
	types1093,
	attr_flags1093,
	gtypes1093,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1093,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1094,
	types1094,
	attr_flags1094,
	gtypes1094,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1094,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1095,
	types1095,
	attr_flags1095,
	gtypes1095,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1095,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1096,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1097,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1098,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1099,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1100,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1101,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1102,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1103,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1104,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1105,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1106,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1107,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1108,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1109,
	"20130823"
},
{
	(long) 2,
	(long) 2,
	"RX_CASE_MAPPING",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PR_FSM",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UT_ERROR_HANDLER",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PR_GRAMMAR",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_PATTERN_MATCHER",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_REGULAR_EXPRESSION",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PR_YACC_TOKENS",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 52,
	(long) 52,
	"PR_YACC_SCANNER_SKELETON",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 52,
	(long) 52,
	"PR_YACC_SCANNER",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 86,
	(long) 86,
	"PR_YACC_PARSER_SKELETON",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 126,
	(long) 126,
	"PR_YACC_PARSER",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_ERROR",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INTEGER_TOO_LARGE_ERROR",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INVALID_DOLLAR_N_ERROR",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_NULL_INTEGER_ERROR",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INVALID_STRING_TOKEN_ERROR",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INVALID_DOLLAR_DOLLAR_ERROR",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_MISSING_CHARACTERS_ERROR",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_TOKEN_ID_USED_TWICE_ERROR",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INVALID_UNICODE_CHARACTER_ERROR",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_STRING_TOKEN_DEFINED_TWICE_ERROR",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1141,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_ALIAS_NAME_UNDEFINED_ERROR",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1142,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_RULE_DECLARED_TWICE_ERROR",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1143,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_TWO_STRINGS_TOKEN_ERROR",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1144,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_UNDEFINED_SYMBOL_ERROR",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_SYMBOL_DECLARED_VARIABLE_ERROR",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_UNDEFINED_STRING_TOKEN_ERROR",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_NO_RULES_ERROR",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_SYMBOL_DECLARED_TOKEN_ERROR",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_VARIABLE_DECLARED_TWICE_ERROR",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_TOKEN_DECLARED_TWICE_ERROR",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_INVALID_ERROR_N_ERROR",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_PREC_NOT_TOKEN_ERROR",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_PREC_SPECIFIED_TWICE_ERROR",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_PRECEDENCE_DEFINED_TWICE_ERROR",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1155,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_MULTIPLE_START_DECLARATIONS_ERROR",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_LHS_SYMBOL_TOKEN_ERROR",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_LAST_VALUE_NAME_USED_TWICE_ERROR",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_UNKNOWN_START_SYMBOL_ERROR",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_START_SYMBOL_TOKEN_ERROR",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_ALIAS_NAME_NOT_DEFINED_ERROR",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_ALIAS_NAME_DEFINED_TWICE_ERROR",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1162,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PR_TWO_TOKEN_IDS_TOKEN_ERROR",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_SYNTAX_ERROR",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_MESSAGE",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_WRITE_TO_FILE_ERROR",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_USAGE_MESSAGE",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_READ_FILE_ERROR",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_VERSION_NUMBER",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 12,
	(long) 12,
	"GEYACC",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 32,
	(long) 32,
	"RX_PCRE_COMPILER",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_MATCHER",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_REGULAR_EXPRESSION",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1177,
	NULL
},};


#ifdef __cplusplus
}
#endif
