
#ifndef _C11_re520_
#define _C11_re520_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F608_3166(EIF_REFERENCE);
extern void EIF_Minit520(void);
extern EIF_INTEGER_32 F684_3632(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
