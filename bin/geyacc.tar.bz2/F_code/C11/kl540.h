
#ifndef _C11_kl540_
#define _C11_kl540_

#ifdef __cplusplus
extern "C" {
#endif

extern void F695_3677(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit540(void);

#ifdef __cplusplus
}
#endif

#endif
