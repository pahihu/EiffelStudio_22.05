
#ifndef _C11_to516_
#define _C11_to516_

#ifdef __cplusplus
extern "C" {
#endif

extern void F231_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F231_2365(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F231_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit516(void);
extern void F659_3531(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
