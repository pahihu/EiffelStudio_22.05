
#ifndef _C11_co507_
#define _C11_co507_

#ifdef __cplusplus
extern "C" {
#endif

extern void F439_3055(EIF_REFERENCE);
extern void EIF_Minit507(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
