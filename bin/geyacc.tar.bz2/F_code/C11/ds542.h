
#ifndef _C11_ds542_
#define _C11_ds542_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1013_6829(EIF_REFERENCE);
extern void EIF_Minit542(void);
extern EIF_INTEGER_32 F1098_7534(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
