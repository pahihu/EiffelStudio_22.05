
#ifndef _C11_ds534_
#define _C11_ds534_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F986_6792(EIF_REFERENCE);
extern void EIF_Minit534(void);
extern char *(*R2618[])();
extern char *(*R5191[])();

#ifdef __cplusplus
}
#endif

#endif
