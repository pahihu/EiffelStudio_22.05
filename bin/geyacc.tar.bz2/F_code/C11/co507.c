/*
 * Code for class CONTAINER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co507.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F439_3055 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O2734[Dtype(Current)-436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
