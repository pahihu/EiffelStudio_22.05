/*
 * Code for class DS_CURSOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds536.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.item */
EIF_INTEGER_32 F971_6762 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[Dtype(Current)-1007])(Current);
	Result = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5285[Dtype(RTCW(tr1))-1076])(tr1, Current));
	RTLE;
	return Result;
}

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F971_6765 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[Dtype(Current)-1007])(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5287[Dtype(RTCW(tr1))-1076])(tr1, Current, arg1);
	RTLE;
	return Result;
}

/* {DS_CURSOR}.copy */
void F971_6768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[dtype-1007])(Current) != NULL)) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5174[dtype-1007])(Current);
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[dtype-1007])(Current);
		F1042_6929(RTCW(tr1), Current);
	}
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5174[dtype-1007])(Current)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[dtype-1007])(Current);
		F1042_6928(RTCW(tr1), Current);
	}
	RTLE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F971_6769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(5958,F912_5958, (Current));
	tb1 = F6_74(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F971_6765(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F971_6771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
