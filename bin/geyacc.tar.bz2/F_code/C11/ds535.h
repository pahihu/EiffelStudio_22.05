
#ifndef _C11_ds535_
#define _C11_ds535_

#ifdef __cplusplus
extern "C" {
#endif

extern void F980_6782(EIF_REFERENCE);
extern void F980_6783(EIF_REFERENCE);
extern void F980_6785(EIF_REFERENCE);
extern void EIF_Minit535(void);
extern char *(*R5173[])();
extern char *(*R5311[])();
extern char *(*R5312[])();
extern char *(*R5314[])();

#ifdef __cplusplus
}
#endif

#endif
