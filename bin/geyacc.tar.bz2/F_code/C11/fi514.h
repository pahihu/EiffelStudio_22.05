
#ifndef _C11_fi514_
#define _C11_fi514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F582_3153(EIF_REFERENCE);
extern void EIF_Minit514(void);
extern char *(*R2796[])();

#ifdef __cplusplus
}
#endif

#endif
