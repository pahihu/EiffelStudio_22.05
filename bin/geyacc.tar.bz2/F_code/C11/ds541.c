/*
 * Code for class DS_SPARSE_TABLE [INTEGER_32, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds541.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_TABLE}.make */
void F1098_7490 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y5555,Y5555_gen_type,Dftype(Current),1094).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1098_7496(Current, arg1, NULL, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_map */
void F1098_7493 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1098_7496(Current, arg1, NULL, NULL);
}

/* {DS_SPARSE_TABLE}.make_with_equality_testers */
void F1098_7496 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	F1087_7335(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.item */
EIF_INTEGER_32 F1098_7498 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7368(Current, arg1);
	RTLE;
	return (EIF_INTEGER_32) F1103_7536(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
}

/* {DS_SPARSE_TABLE}.key_equality_tester */
EIF_REFERENCE F1098_7504 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_SPARSE_TABLE}.has */
EIF_BOOLEAN F1098_7506 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7368(Current, arg1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_TABLE}.search */
void F1098_7509 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7368(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_TABLE}.is_equal */
EIF_BOOLEAN F1098_7510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5958,F912_5958, (Current));
		tb2 = F6_74(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == ti4_1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F1103_7539(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F1103_7538(Current, loc2);
					Result = '\0';
					tb1 = F1098_7506(RTCW(arg1), loc1);
					if (tb1) {
						ti4_1 = F1098_7498(RTCW(arg1), loc1);
						Result = (EIF_BOOLEAN)(ti4_1 == F1103_7536(Current, loc2));
					}
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_TABLE}.replace_found_item */
void F1098_7513 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1103_7537(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_));
}

/* {DS_SPARSE_TABLE}.put_new */
void F1098_7515 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7354(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	} else {
		ti4_1 = F1103_7539(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1108_7573(Current, arg2);
	ti4_1 = F1103_7561(Current, loc2);
	F1103_7555(Current, ti4_1, loc1);
	F1103_7562(Current, loc1, loc2);
	F1103_7537(Current, arg1, loc1);
	F1103_7548(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.force */
void F1098_7518 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7354(Current);
	F1087_7368(Current, arg2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1103_7537(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = F1087_7424(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F1087_7359(Current, ti4_1);
			loc2 = F1108_7573(Current, arg2);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		} else {
			ti4_1 = F1103_7539(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F1103_7561(Current, loc2);
		F1103_7555(Current, ti4_1, loc1);
		F1103_7562(Current, loc1, loc2);
		F1103_7537(Current, arg1, loc1);
		F1103_7548(Current, arg2, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_new */
void F1098_7519 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7354(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = F1087_7424(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F1087_7359(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	} else {
		ti4_1 = F1103_7539(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1108_7573(Current, arg2);
	ti4_1 = F1103_7561(Current, loc2);
	F1103_7555(Current, ti4_1, loc1);
	F1103_7562(Current, loc1, loc2);
	F1103_7537(Current, arg1, loc1);
	F1103_7548(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_last_new */
void F1098_7521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_7354(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = F1087_7424(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
		F1087_7359(Current, ti4_1);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
	loc2 = F1108_7573(Current, arg2);
	ti4_1 = F1103_7561(Current, loc2);
	F1103_7555(Current, ti4_1, loc1);
	F1103_7562(Current, loc1, loc2);
	F1103_7537(Current, arg1, loc1);
	F1103_7548(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.copy */
void F1098_7522 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F1087_7355(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.cursor_key */
EIF_INTEGER_32 F1098_7534 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = F1103_7538(Current, ti4_1);
	RTLE;
	return Result;
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
