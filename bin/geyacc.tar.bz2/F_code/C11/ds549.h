
#ifndef _C11_ds549_
#define _C11_ds549_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1087_7335(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1087_7336(EIF_REFERENCE);
extern EIF_INTEGER_32 F1087_7337(EIF_REFERENCE);
extern EIF_INTEGER_32 F1087_7340(EIF_REFERENCE);
extern EIF_INTEGER_32 F1087_7341(EIF_REFERENCE);
extern EIF_BOOLEAN F1087_7343(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1087_7344(EIF_REFERENCE);
extern void F1087_7354(EIF_REFERENCE);
extern void F1087_7355(EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_7359(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1087_7368(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1087_7405(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1087_7406(EIF_REFERENCE);
extern void F1087_7407(EIF_REFERENCE);
extern EIF_INTEGER_32 F1087_7411(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1087_7414(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_7415(EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_7417(EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_7421(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1087_7424(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1087_7425(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit549(void);
extern void F1002_6815(EIF_REFERENCE);
extern void F1042_6928(EIF_REFERENCE, EIF_REFERENCE);
extern void F971_6771(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1031_6885(EIF_REFERENCE);
extern EIF_BOOLEAN F1042_6925(EIF_REFERENCE, EIF_REFERENCE);
extern void F1042_6929(EIF_REFERENCE, EIF_REFERENCE);
extern void F1002_6814(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1042_6920(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R5487[])();
extern char *(*R5488[])();
extern char *(*R5489[])();
extern char *(*R5492[])();
extern char *(*R5494[])();
extern char *(*R5495[])();
extern char *(*R5498[])();
extern char *(*R1930[])();
extern char *(*R5499[])();
extern char *(*R5500[])();
extern char *(*R5501[])();
extern char *(*R5503[])();
extern char *(*R5504[])();
extern char *(*R5505[])();
extern char *(*R5278[])();
extern char *(*R5507[])();
extern char *(*R5475[])();
extern char *(*R5477[])();
extern char *(*R5478[])();
extern char *(*R5506[])();
extern char *(*R5483[])();
extern long O5509[];
extern long O5474[];
extern long O5510[];
extern long O5511[];
extern long O5512[];
extern long O5513[];
extern long O5514[];
extern long O5524[];
extern long O5525[];

#ifdef __cplusplus
}
#endif

#endif
