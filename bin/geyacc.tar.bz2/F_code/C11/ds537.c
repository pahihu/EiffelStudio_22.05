/*
 * Code for class DS_TRAVERSABLE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds537.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_TRAVERSABLE}.valid_cursor */
EIF_BOOLEAN F1042_6920 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5173[Dtype(RTCW(arg1))-1007])(arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == Current);
	RTLE;
	return Result;
}

/* {DS_TRAVERSABLE}.cursor_off */
EIF_BOOLEAN F1042_6925 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5174[Dtype(RTCW(arg1))-1007])(arg1);
	return (EIF_BOOLEAN) tb1;
}

/* {DS_TRAVERSABLE}.add_traversing_cursor */
void F1042_6928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5284[dtype-1076])(Current))) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5284[dtype-1076])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F971_6771(RTCW(arg1), tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5284[dtype-1076])(Current);
		F971_6771(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {DS_TRAVERSABLE}.remove_traversing_cursor */
void F1042_6929 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5284[dtype-1076])(Current))) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5284[dtype-1076])(Current);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg1) || (EIF_BOOLEAN)(loc1 == NULL))) break;
			loc2 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
		if ((EIF_BOOLEAN)(loc1 == arg1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F971_6771(RTCW(loc2), tr1);
			F971_6771(RTCW(arg1), NULL);
		}
	}
	RTLE;
}

void EIF_Minit537 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
