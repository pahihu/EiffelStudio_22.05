
#ifndef _C11_ds537_
#define _C11_ds537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1042_6920(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1042_6925(EIF_REFERENCE, EIF_REFERENCE);
extern void F1042_6928(EIF_REFERENCE, EIF_REFERENCE);
extern void F1042_6929(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit537(void);
extern void F971_6771(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5173[])();
extern char *(*R5174[])();
extern char *(*R5284[])();

#ifdef __cplusplus
}
#endif

#endif
