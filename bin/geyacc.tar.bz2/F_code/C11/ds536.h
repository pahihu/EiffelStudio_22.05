
#ifndef _C11_ds536_
#define _C11_ds536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F971_6762(EIF_REFERENCE);
extern EIF_BOOLEAN F971_6765(EIF_REFERENCE, EIF_REFERENCE);
extern void F971_6768(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F971_6769(EIF_REFERENCE, EIF_REFERENCE);
extern void F971_6771(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit536(void);
extern void F1042_6928(EIF_REFERENCE, EIF_REFERENCE);
extern void F1042_6929(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F912_5958(EIF_REFERENCE);
extern EIF_BOOLEAN F6_74(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5958)
extern char *(*R5173[])();
extern char *(*R5174[])();
extern char *(*R5285[])();
extern char *(*R5287[])();

#ifdef __cplusplus
}
#endif

#endif
