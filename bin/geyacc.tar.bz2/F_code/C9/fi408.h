
#ifndef _C9_fi408_
#define _C9_fi408_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F580_3153(EIF_REFERENCE);
extern void EIF_Minit408(void);
extern char *(*R2796[])();

#ifdef __cplusplus
}
#endif

#endif
