
#ifndef _C9_ha444_
#define _C9_ha444_

#ifdef __cplusplus
extern "C" {
#endif

extern void F766_3896(EIF_REFERENCE, EIF_INTEGER_32);
extern void F766_3899(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F766_3900(EIF_REFERENCE);
extern EIF_REFERENCE F766_3902(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F766_3904(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F766_3911(EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3913(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3914(EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3917(EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3918(EIF_REFERENCE);
extern EIF_BOOLEAN F766_3919(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F766_3920(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F766_3928(EIF_REFERENCE);
extern EIF_BOOLEAN F766_3929(EIF_REFERENCE);
extern void F766_3938(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3940(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F766_3941(EIF_REFERENCE, EIF_INTEGER_32);
extern void F766_3942(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3943(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3950(EIF_REFERENCE);
extern void F766_3953(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F766_3954(EIF_REFERENCE, EIF_INTEGER_32);
extern void F766_3955(EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3964(EIF_REFERENCE);
extern EIF_BOOLEAN F766_3965(EIF_REFERENCE);
extern EIF_REFERENCE F766_3972(EIF_REFERENCE);
extern EIF_REFERENCE F766_3973(EIF_REFERENCE);
extern EIF_INTEGER_32 F766_3974(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F766_3975(EIF_REFERENCE, EIF_INTEGER_32);
extern void F766_3978(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3980(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3981(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3982(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3986(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_3992(EIF_REFERENCE);
extern void F766_4005(EIF_REFERENCE);
extern void EIF_Minit444(void);
extern EIF_REFERENCE F752_3797(EIF_REFERENCE);
extern void F752_3796(EIF_REFERENCE);
extern void F659_3552(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F659_3531(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F579_3143(EIF_REFERENCE, EIF_INTEGER_32);
extern void F660_3549(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F660_3552(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F660_3531(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F660_3542(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3797)
extern char *(*R3233[])();
extern char *(*R3234[])();
extern char *(*R2617[])();
extern char *(*R2632[])();
extern char *(*R2619[])();
extern char *(*R2736[])();
extern char *(*R3042[])();
extern char *(*R2618[])();
extern char *(*R3006[])();
extern char *(*R3200[])();
extern char *(*R3244[])();
extern char *(*R2704[])();
extern char *(*R2701[])();
extern char *(*R3247[])();
extern char *(*R2568[])();
extern char *(*R3249[])();
extern char *(*R3207[])();
extern char *(*R3291[])();
extern char *(*R3250[])();
extern char *(*R3251[])();
extern char *(*R3255[])();
extern char *(*R3215[])();
extern char *(*R3217[])();
extern char *(*R3218[])();
extern char *(*R3023[])();
extern char *(*R2567[])();
extern char *(*R3186[])();
extern char *(*R3261[])();
extern char *(*R3189[])();
extern char *(*R3224[])();
extern char *(*R3206[])();
extern char *(*R3243[])();
extern char *(*R3190[])();
extern char *(*R3274[])();
extern char *(*R3198[])();
extern char *(*R2772[])();
extern char *(*R2630[])();
extern long O3226[];
extern long O3227[];
extern long O3228[];
extern long O3229[];
extern long O3199[];
extern long O3230[];
extern long O3231[];
extern long O3232[];
extern long O3276[];
extern long O3235[];
extern long O3236[];
extern long O3190[];
extern long O3241[];
extern long O3242[];
extern long O3240[];
extern long O2734[];
extern EIF_TYPE_INDEX Y3226[];
extern EIF_TYPE_INDEX *Y3226_gen_type [];
extern EIF_TYPE_INDEX Y3227[];
extern EIF_TYPE_INDEX *Y3227_gen_type [];
extern EIF_TYPE_INDEX Y2774[];
extern EIF_TYPE_INDEX *Y2774_gen_type [];
extern EIF_TYPE_INDEX Y2633[];
extern EIF_TYPE_INDEX *Y2633_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
