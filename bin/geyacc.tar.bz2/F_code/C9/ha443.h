
#ifndef _C9_ha443_
#define _C9_ha443_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F382_2996(EIF_REFERENCE);
extern EIF_REFERENCE F382_2997(EIF_REFERENCE);
extern EIF_BOOLEAN F382_2999(EIF_REFERENCE);
extern void F382_3000(EIF_REFERENCE);
extern EIF_REFERENCE F382_3001(EIF_REFERENCE);
extern void EIF_Minit443(void);
extern char *(*R3006[])();
extern char *(*R3217[])();
extern char *(*R3218[])();
extern char *(*R2567[])();
extern char *(*R2698[])();
extern long O3226[];
extern long O3227[];

#ifdef __cplusplus
}
#endif

#endif
