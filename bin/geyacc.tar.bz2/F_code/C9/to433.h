
#ifndef _C9_to433_
#define _C9_to433_

#ifdef __cplusplus
extern "C" {
#endif

extern void F229_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F229_2365(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F229_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit433(void);
extern char *(*R3012[])();
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
