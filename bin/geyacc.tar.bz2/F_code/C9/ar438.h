
#ifndef _C9_ar438_
#define _C9_ar438_

#ifdef __cplusplus
extern "C" {
#endif

extern void F682_3618(EIF_REFERENCE);
extern void F682_3619(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F682_3620(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F682_3621(EIF_REFERENCE, EIF_REFERENCE);
extern void F682_3622(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F682_3624(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F682_3629(EIF_REFERENCE);
extern EIF_INTEGER_32 F682_3630(EIF_REFERENCE);
extern EIF_INTEGER_32 F682_3631(EIF_REFERENCE);
extern EIF_INTEGER_32 F682_3632(EIF_REFERENCE);
extern EIF_BOOLEAN F682_3634(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F682_3639(EIF_REFERENCE, EIF_INTEGER_32);
extern void F682_3643(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F682_3648(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F682_3664(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F682_3672(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F682_3676(EIF_REFERENCE);
extern void EIF_Minit438(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R3040[])();
extern char *(*R3006[])();
extern char *(*R3026[])();
extern char *(*R2796[])();
extern char *(*R3372[])();
extern char *(*R3021[])();
extern char *(*R3022[])();
extern char *(*R2178[])();
extern char *(*R2179[])();
extern char *(*R2567[])();
extern char *(*R3030[])();
extern char *(*R3029[])();
extern char *(*R3106[])();
extern char *(*R2769[])();
extern char *(*R2185[])();
extern char *(*R2568[])();
extern EIF_TYPE_INDEX Y2633[];
extern EIF_TYPE_INDEX *Y2633_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
