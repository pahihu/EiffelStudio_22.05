
#ifndef _C9_re440_
#define _C9_re440_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F606_3166(EIF_REFERENCE);
extern void EIF_Minit440(void);
extern char *(*R2799[])();

#ifdef __cplusplus
}
#endif

#endif
