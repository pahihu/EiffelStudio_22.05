
#ifndef _C9_re406_
#define _C9_re406_

#ifdef __cplusplus
extern "C" {
#endif

extern void F368_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F368_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F368_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F368_2982(EIF_REFERENCE);
extern void F368_2987(EIF_REFERENCE);
extern void EIF_Minit406(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
