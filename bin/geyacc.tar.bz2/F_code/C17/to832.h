
#ifndef _C17_to832_
#define _C17_to832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F237_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F237_2365(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F237_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit832(void);
extern void F665_3531(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
