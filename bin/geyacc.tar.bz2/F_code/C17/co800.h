
#ifndef _C17_co800_
#define _C17_co800_

#ifdef __cplusplus
extern "C" {
#endif

extern void F444_3055(EIF_REFERENCE);
extern void EIF_Minit800(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
