
#ifndef _C17_re813_
#define _C17_re813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F613_3166(EIF_REFERENCE);
extern void EIF_Minit813(void);
extern char *(*R2799[])();

#ifdef __cplusplus
}
#endif

#endif
