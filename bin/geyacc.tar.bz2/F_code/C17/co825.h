
#ifndef _C17_co825_
#define _C17_co825_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F578_3123(EIF_REFERENCE);
extern EIF_BOOLEAN F578_3125(EIF_REFERENCE);
extern void F578_3131(EIF_REFERENCE);
extern void EIF_Minit825(void);

#ifdef __cplusplus
}
#endif

#endif
