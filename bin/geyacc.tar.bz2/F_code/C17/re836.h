
#ifndef _C17_re836_
#define _C17_re836_

#ifdef __cplusplus
extern "C" {
#endif

extern void F376_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F376_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F376_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F376_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F376_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F376_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F376_2982(EIF_REFERENCE);
extern void F376_2987(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
