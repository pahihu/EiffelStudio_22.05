
#ifndef _C17_fi807_
#define _C17_fi807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F587_3153(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern char *(*R2796[])();

#ifdef __cplusplus
}
#endif

#endif
