
#ifndef _C17_to809_
#define _C17_to809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F236_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F236_2365(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F236_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit809(void);
extern void F664_3531(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
