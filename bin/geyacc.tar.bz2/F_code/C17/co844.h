
#ifndef _C17_co844_
#define _C17_co844_

#ifdef __cplusplus
extern "C" {
#endif

extern void F445_3055(EIF_REFERENCE);
extern void EIF_Minit844(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
