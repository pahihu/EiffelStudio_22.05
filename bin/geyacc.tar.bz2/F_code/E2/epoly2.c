#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2736[598])();
void R2736_init () {
	R2736[0] = (char *(*)()) F439_3055;
	R2736[103] = (char *(*)()) F437_3055;
	R2736[104] = (char *(*)()) F438_3055;
	R2736[105] = (char *(*)()) F439_3055;
	R2736[106] = (char *(*)()) F440_3055;
	R2736[107] = (char *(*)()) F441_3055;
	R2736[108] = (char *(*)()) F442_3055;
	R2736[109] = (char *(*)()) F443_3055;
	R2736[110] = (char *(*)()) F444_3055;
	R2736[111] = (char *(*)()) F445_3055;
	R2736[112] = (char *(*)()) F446_3055;
	R2736[113] = (char *(*)()) F447_3055;
	R2736[114] = (char *(*)()) F448_3055;
	R2736[115] = (char *(*)()) F437_3055;
	R2736[116] = (char *(*)()) F439_3055;
	R2736[117] = (char *(*)()) F440_3055;
	R2736[118] = (char *(*)()) F441_3055;
	R2736[119] = (char *(*)()) F442_3055;
	R2736[120] = (char *(*)()) F443_3055;
	R2736[187] = (char *(*)()) F437_3055;
	R2736[188] = (char *(*)()) F438_3055;
	R2736[189] = (char *(*)()) F439_3055;
	R2736[190] = (char *(*)()) F437_3055;
	R2736[191] = (char *(*)()) F439_3055;
	R2736[194] = (char *(*)()) F437_3055;
	R2736[313] = (char *(*)()) F444_3055;
	R2736[316] = (char *(*)()) F443_3055;
	R2736[363] = (char *(*)()) F443_3055;
	R2736[382] = (char *(*)()) F443_3055;
	R2736[387] = (char *(*)()) F443_3055;
	R2736[597] = (char *(*)()) F443_3055;
}

char *(*R2769[495])();
void R2769_init () {
	R2769[0] = (char *(*)()) F682_3624_2769_5;
	R2769[1] = (char *(*)()) F683_3624_2769_5;
	R2769[2] = (char *(*)()) F684_3624_2769_5;
	R2769[3] = (char *(*)()) F685_3624_2769_5;
	R2769[4] = (char *(*)()) F686_3624_2769_5;
	R2769[5] = (char *(*)()) F687_3624_2769_5;
	R2769[6] = (char *(*)()) F688_3624_2769_5;
	R2769[7] = (char *(*)()) F689_3624_2769_5;
	R2769[8] = (char *(*)()) F690_3624_2769_5;
	R2769[9] = (char *(*)()) F691_3624_2769_5;
	R2769[10] = (char *(*)()) F692_3624_2769_5;
	R2769[11] = (char *(*)()) F693_3624_2769_5;
	R2769[12] = (char *(*)()) F682_3624_2769_5;
	R2769[13] = (char *(*)()) F684_3624_2769_5;
	R2769[14] = (char *(*)()) F685_3624_2769_5;
	R2769[15] = (char *(*)()) F686_3624_2769_5;
	R2769[16] = (char *(*)()) F687_3624_2769_5;
	R2769[17] = (char *(*)()) F688_3624_2769_5;
	R2769[210] = (char *(*)()) F892_5579_2769_5;
	R2769[213] = (char *(*)()) F895_5743_2769_5;
	R2769[494] = (char *(*)()) F1176_8632_2769_5;
}
static EIF_REFERENCE F682_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F682_3624(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F683_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F683_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F685_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F686_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F686_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F687_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F688_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F689_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F690_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F691_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F692_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_3624_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F693_3624(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_5579_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F892_5579(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_5743_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F895_5743(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1176_8632_2769_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1176_8632(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2772[495])();
void R2772_init () {
	R2772[0] = (char *(*)()) F682_3643_2772_14;
	R2772[1] = (char *(*)()) F683_3643_2772_14;
	R2772[2] = (char *(*)()) F684_3643_2772_14;
	R2772[3] = (char *(*)()) F685_3643_2772_14;
	R2772[4] = (char *(*)()) F686_3643_2772_14;
	R2772[5] = (char *(*)()) F687_3643_2772_14;
	R2772[6] = (char *(*)()) F688_3643_2772_14;
	R2772[7] = (char *(*)()) F689_3643_2772_14;
	R2772[8] = (char *(*)()) F690_3643_2772_14;
	R2772[9] = (char *(*)()) F691_3643_2772_14;
	R2772[10] = (char *(*)()) F692_3643_2772_14;
	R2772[11] = (char *(*)()) F693_3643_2772_14;
	R2772[12] = (char *(*)()) F682_3643_2772_14;
	R2772[13] = (char *(*)()) F684_3643_2772_14;
	R2772[14] = (char *(*)()) F685_3643_2772_14;
	R2772[15] = (char *(*)()) F686_3643_2772_14;
	R2772[16] = (char *(*)()) F687_3643_2772_14;
	R2772[17] = (char *(*)()) F688_3643_2772_14;
	R2772[84] = (char *(*)()) F766_3942;
	R2772[85] = (char *(*)()) F767_3942_2772_14;
	R2772[86] = (char *(*)()) F768_3942_2772_14;
	R2772[87] = (char *(*)()) F769_3942_2772_14;
	R2772[88] = (char *(*)()) F770_3942_2772_14;
	R2772[91] = (char *(*)()) F766_3942;
	R2772[210] = (char *(*)()) F892_5599_2772_14;
	R2772[213] = (char *(*)()) F895_5764_2772_14;
	R2772[494] = (char *(*)()) F1176_8667_2772_14;
}
static void F682_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F682_3643(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F683_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F683_3643(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F684_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F684_3643(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F685_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F685_3643(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F686_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F686_3643(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F687_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F687_3643(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F688_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F688_3643(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F689_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F689_3643(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F690_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F690_3643(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F691_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F691_3643(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F692_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F692_3643(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F693_3643_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F693_3643(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F767_3942_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F767_3942(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F768_3942_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F768_3942(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F769_3942_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F769_3942(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F770_3942_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F770_3942(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F892_5599_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F892_5599(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F895_5764_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_5764(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1176_8667_2772_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1176_8667(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2774_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype30[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype31[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype32[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype33[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype34[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype35[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype36[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype37[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype38[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype39[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype40[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype41[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype42[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype43[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype44[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype45[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype46[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype47[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype48[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype49[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype50[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype51[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype52[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype53[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype54[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype55[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype56[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype57[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype58[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype59[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype60[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype61[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype62[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype63[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype64[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype65[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype66[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype67[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype68[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype69[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype70[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype71[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype72[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype73[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype74[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype75[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype76[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype77[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype78[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype79[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype80[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype81[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype82[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype83[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype84[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype85[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype86[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype87[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype88[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype89[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype90[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype91[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype92[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype93[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype94[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype95[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype96[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype97[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype98[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype99[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype100[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype101[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype102[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype103[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype104[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype105[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype106[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype107[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype108[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype109[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype110[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype111[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype112[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype113[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype114[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype115[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype116[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype117[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype118[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype119[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype120[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype121[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype122[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype128[] = {0xFF01,886,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype129[] = {0xFF01,886,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype130[] = {0xFF01,894,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype131[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype132[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype133[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype134[] = {814,0xFFFF};
static EIF_TYPE_INDEX Y2774_pgtype135[] = {814,0xFFFF};
EIF_TYPE_INDEX *Y2774_gen_type [668];
EIF_TYPE_INDEX Y2774 [668];
void Y2774_init (void)
{
	egc_routines_types [2774] = Y2774;
	egc_routines_gen_types [2774] = Y2774_gen_type;
	egc_routines_offset [2774] = 509;
	Y2774_gen_type [0] = Y2774_pgtype0;
	Y2774_gen_type [1] = Y2774_pgtype1;
	Y2774_gen_type [2] = Y2774_pgtype2;
	Y2774_gen_type [3] = Y2774_pgtype3;
	Y2774_gen_type [4] = Y2774_pgtype4;
	Y2774_gen_type [5] = Y2774_pgtype5;
	Y2774_gen_type [6] = Y2774_pgtype6;
	Y2774_gen_type [7] = Y2774_pgtype7;
	Y2774_gen_type [8] = Y2774_pgtype8;
	Y2774_gen_type [9] = Y2774_pgtype9;
	Y2774_gen_type [10] = Y2774_pgtype10;
	Y2774_gen_type [11] = Y2774_pgtype11;
	Y2774_gen_type [12] = Y2774_pgtype12;
	Y2774_gen_type [13] = Y2774_pgtype13;
	Y2774_gen_type [14] = Y2774_pgtype14;
	Y2774_gen_type [15] = Y2774_pgtype15;
	Y2774_gen_type [16] = Y2774_pgtype16;
	Y2774_gen_type [17] = Y2774_pgtype17;
	Y2774_gen_type [18] = Y2774_pgtype18;
	Y2774_gen_type [19] = Y2774_pgtype19;
	Y2774_gen_type [20] = Y2774_pgtype20;
	Y2774_gen_type [21] = Y2774_pgtype21;
	Y2774_gen_type [22] = Y2774_pgtype22;
	Y2774_gen_type [23] = Y2774_pgtype23;
	Y2774_gen_type [24] = Y2774_pgtype24;
	Y2774_gen_type [25] = Y2774_pgtype25;
	Y2774_gen_type [26] = Y2774_pgtype26;
	Y2774_gen_type [27] = Y2774_pgtype27;
	Y2774_gen_type [28] = Y2774_pgtype28;
	Y2774_gen_type [29] = Y2774_pgtype29;
	Y2774_gen_type [159] = Y2774_pgtype30;
	Y2774_gen_type [160] = Y2774_pgtype31;
	Y2774_gen_type [161] = Y2774_pgtype32;
	Y2774_gen_type [162] = Y2774_pgtype33;
	Y2774_gen_type [163] = Y2774_pgtype34;
	Y2774_gen_type [164] = Y2774_pgtype35;
	Y2774_gen_type [165] = Y2774_pgtype36;
	Y2774_gen_type [166] = Y2774_pgtype37;
	Y2774_gen_type [167] = Y2774_pgtype38;
	Y2774_gen_type [168] = Y2774_pgtype39;
	Y2774_gen_type [169] = Y2774_pgtype40;
	Y2774_gen_type [170] = Y2774_pgtype41;
	Y2774_gen_type [171] = Y2774_pgtype42;
	Y2774_gen_type [172] = Y2774_pgtype43;
	Y2774_gen_type [173] = Y2774_pgtype44;
	Y2774_gen_type [174] = Y2774_pgtype45;
	Y2774_gen_type [175] = Y2774_pgtype46;
	Y2774_gen_type [176] = Y2774_pgtype47;
	Y2774_gen_type [177] = Y2774_pgtype48;
	Y2774_gen_type [178] = Y2774_pgtype49;
	Y2774_gen_type [179] = Y2774_pgtype50;
	Y2774_gen_type [180] = Y2774_pgtype51;
	Y2774_gen_type [181] = Y2774_pgtype52;
	Y2774_gen_type [182] = Y2774_pgtype53;
	Y2774_gen_type [183] = Y2774_pgtype54;
	Y2774_gen_type [184] = Y2774_pgtype55;
	Y2774_gen_type [185] = Y2774_pgtype56;
	Y2774_gen_type [186] = Y2774_pgtype57;
	Y2774_gen_type [187] = Y2774_pgtype58;
	Y2774_gen_type [188] = Y2774_pgtype59;
	Y2774_gen_type [189] = Y2774_pgtype60;
	Y2774_gen_type [190] = Y2774_pgtype61;
	Y2774_gen_type [191] = Y2774_pgtype62;
	Y2774_gen_type [192] = Y2774_pgtype63;
	Y2774_gen_type [193] = Y2774_pgtype64;
	Y2774_gen_type [194] = Y2774_pgtype65;
	Y2774_gen_type [195] = Y2774_pgtype66;
	Y2774_gen_type [196] = Y2774_pgtype67;
	Y2774_gen_type [197] = Y2774_pgtype68;
	Y2774_gen_type [198] = Y2774_pgtype69;
	Y2774_gen_type [199] = Y2774_pgtype70;
	Y2774_gen_type [200] = Y2774_pgtype71;
	Y2774_gen_type [201] = Y2774_pgtype72;
	Y2774_gen_type [202] = Y2774_pgtype73;
	Y2774_gen_type [203] = Y2774_pgtype74;
	Y2774_gen_type [204] = Y2774_pgtype75;
	Y2774_gen_type [205] = Y2774_pgtype76;
	Y2774_gen_type [206] = Y2774_pgtype77;
	Y2774_gen_type [207] = Y2774_pgtype78;
	Y2774_gen_type [208] = Y2774_pgtype79;
	Y2774_gen_type [209] = Y2774_pgtype80;
	Y2774_gen_type [210] = Y2774_pgtype81;
	Y2774_gen_type [211] = Y2774_pgtype82;
	Y2774_gen_type [212] = Y2774_pgtype83;
	Y2774_gen_type [213] = Y2774_pgtype84;
	Y2774_gen_type [214] = Y2774_pgtype85;
	Y2774_gen_type [215] = Y2774_pgtype86;
	Y2774_gen_type [216] = Y2774_pgtype87;
	Y2774_gen_type [217] = Y2774_pgtype88;
	Y2774_gen_type [218] = Y2774_pgtype89;
	Y2774_gen_type [219] = Y2774_pgtype90;
	Y2774_gen_type [220] = Y2774_pgtype91;
	Y2774_gen_type [221] = Y2774_pgtype92;
	Y2774_gen_type [222] = Y2774_pgtype93;
	Y2774_gen_type [223] = Y2774_pgtype94;
	Y2774_gen_type [224] = Y2774_pgtype95;
	Y2774_gen_type [225] = Y2774_pgtype96;
	Y2774_gen_type [226] = Y2774_pgtype97;
	Y2774_gen_type [227] = Y2774_pgtype98;
	Y2774_gen_type [228] = Y2774_pgtype99;
	Y2774_gen_type [229] = Y2774_pgtype100;
	Y2774_gen_type [230] = Y2774_pgtype101;
	Y2774_gen_type [231] = Y2774_pgtype102;
	Y2774_gen_type [232] = Y2774_pgtype103;
	Y2774_gen_type [233] = Y2774_pgtype104;
	Y2774_gen_type [234] = Y2774_pgtype105;
	Y2774_gen_type [235] = Y2774_pgtype106;
	Y2774_gen_type [236] = Y2774_pgtype107;
	Y2774_gen_type [237] = Y2774_pgtype108;
	Y2774_gen_type [238] = Y2774_pgtype109;
	Y2774_gen_type [239] = Y2774_pgtype110;
	Y2774_gen_type [244] = Y2774_pgtype111;
	Y2774_gen_type [245] = Y2774_pgtype112;
	Y2774_gen_type [246] = Y2774_pgtype113;
	Y2774_gen_type [247] = Y2774_pgtype114;
	Y2774_gen_type [248] = Y2774_pgtype115;
	Y2774_gen_type [249] = Y2774_pgtype116;
	Y2774_gen_type [250] = Y2774_pgtype117;
	Y2774_gen_type [251] = Y2774_pgtype118;
	Y2774_gen_type [252] = Y2774_pgtype119;
	Y2774_gen_type [253] = Y2774_pgtype120;
	Y2774_gen_type [254] = Y2774_pgtype121;
	Y2774_gen_type [255] = Y2774_pgtype122;
	Y2774_gen_type [256] = Y2774_pgtype123;
	Y2774_gen_type [257] = Y2774_pgtype124;
	Y2774_gen_type [258] = Y2774_pgtype125;
	Y2774_gen_type [259] = Y2774_pgtype126;
	Y2774_gen_type [260] = Y2774_pgtype127;
	Y2774_gen_type [261] = Y2774_pgtype128;
	Y2774_gen_type [262] = Y2774_pgtype129;
	Y2774_gen_type [263] = Y2774_pgtype130;
	Y2774_gen_type [382] = Y2774_pgtype131;
	Y2774_gen_type [385] = Y2774_pgtype132;
	Y2774_gen_type [386] = Y2774_pgtype133;
	Y2774_gen_type [666] = Y2774_pgtype134;
	Y2774_gen_type [667] = Y2774_pgtype135;
	{long i; for (i = 159; i < 240; i++) Y2774[i] = 814;};
	{long i; for (i = 244; i < 256; i++) Y2774[i] = 814;};
	{long i; for (i = 261; i < 263; i++) Y2774[i] = 886;};
	Y2774[263] = 894;
	Y2774[382] = 814;
	{long i; for (i = 385; i < 387; i++) Y2774[i] = 814;};
	{long i; for (i = 666; i < 668; i++) Y2774[i] = 814;};
}

char *(*R2796[495])();
void R2796_init () {
	R2796[0] = (char *(*)()) F682_3631;
	R2796[1] = (char *(*)()) F683_3631;
	R2796[2] = (char *(*)()) F684_3631;
	R2796[3] = (char *(*)()) F685_3631;
	R2796[4] = (char *(*)()) F686_3631;
	R2796[5] = (char *(*)()) F687_3631;
	R2796[6] = (char *(*)()) F688_3631;
	R2796[7] = (char *(*)()) F689_3631;
	R2796[8] = (char *(*)()) F690_3631;
	R2796[9] = (char *(*)()) F691_3631;
	R2796[10] = (char *(*)()) F692_3631;
	R2796[11] = (char *(*)()) F693_3631;
	R2796[12] = (char *(*)()) F682_3631;
	R2796[13] = (char *(*)()) F684_3631;
	R2796[14] = (char *(*)()) F685_3631;
	R2796[15] = (char *(*)()) F686_3631;
	R2796[16] = (char *(*)()) F687_3631;
	R2796[17] = (char *(*)()) F688_3631;
	R2796[84] = (char *(*)()) F766_3914;
	R2796[85] = (char *(*)()) F767_3914;
	R2796[86] = (char *(*)()) F768_3914;
	R2796[87] = (char *(*)()) F769_3914;
	R2796[88] = (char *(*)()) F770_3914;
	R2796[91] = (char *(*)()) F766_3914;
	R2796[210] = (char *(*)()) F890_5518;
	R2796[213] = (char *(*)()) F893_5686;
	R2796[260] = (char *(*)()) F942_6251;
	R2796[279] = (char *(*)()) F642_3209;
	R2796[284] = (char *(*)()) F642_3209;
	R2796[494] = (char *(*)()) F1176_8648;
}

char *(*R2799[495])();
void R2799_init () {
	R2799[0] = (char *(*)()) F682_3632;
	R2799[1] = (char *(*)()) F683_3632;
	R2799[2] = (char *(*)()) F684_3632;
	R2799[3] = (char *(*)()) F685_3632;
	R2799[4] = (char *(*)()) F686_3632;
	R2799[5] = (char *(*)()) F687_3632;
	R2799[6] = (char *(*)()) F688_3632;
	R2799[7] = (char *(*)()) F689_3632;
	R2799[8] = (char *(*)()) F690_3632;
	R2799[9] = (char *(*)()) F691_3632;
	R2799[10] = (char *(*)()) F692_3632;
	R2799[11] = (char *(*)()) F693_3632;
	R2799[12] = (char *(*)()) F682_3632;
	R2799[13] = (char *(*)()) F684_3632;
	R2799[14] = (char *(*)()) F685_3632;
	R2799[15] = (char *(*)()) F686_3632;
	R2799[16] = (char *(*)()) F687_3632;
	R2799[17] = (char *(*)()) F688_3632;
	R2799[210] = (char *(*)()) F890_5517;
	R2799[213] = (char *(*)()) F893_5685;
	R2799[494] = (char *(*)()) F1176_8650;
}

char *(*R2835[25])();
void R2835_init () {
	R2835[0] = (char *(*)()) F942_6249;
	R2835[19] = (char *(*)()) F642_3213;
	R2835[24] = (char *(*)()) F642_3213;
}

char *(*R2905[25])();
void R2905_init () {
	R2905[0] = (char *(*)()) F942_6305;
	R2905[19] = (char *(*)()) F642_3338;
	R2905[24] = (char *(*)()) F642_3338;
}

char *(*R3006[520])();
void R3006_init () {
	R3006[0] = (char *(*)()) F657_3533;
	R3006[1] = (char *(*)()) F658_3533_3006_28;
	R3006[2] = (char *(*)()) F659_3533_3006_28;
	R3006[3] = (char *(*)()) F660_3533_3006_28;
	R3006[4] = (char *(*)()) F661_3533_3006_28;
	R3006[5] = (char *(*)()) F662_3533_3006_28;
	R3006[6] = (char *(*)()) F663_3533_3006_28;
	R3006[7] = (char *(*)()) F664_3533_3006_28;
	R3006[8] = (char *(*)()) F665_3533_3006_28;
	R3006[9] = (char *(*)()) F666_3533_3006_28;
	R3006[10] = (char *(*)()) F667_3533_3006_28;
	R3006[11] = (char *(*)()) F668_3533_3006_28;
	R3006[25] = (char *(*)()) F682_3624;
	R3006[26] = (char *(*)()) F683_3624_3006_28;
	R3006[27] = (char *(*)()) F684_3624_3006_28;
	R3006[28] = (char *(*)()) F685_3624_3006_28;
	R3006[29] = (char *(*)()) F686_3624_3006_28;
	R3006[30] = (char *(*)()) F687_3624_3006_28;
	R3006[31] = (char *(*)()) F688_3624_3006_28;
	R3006[32] = (char *(*)()) F689_3624_3006_28;
	R3006[33] = (char *(*)()) F690_3624_3006_28;
	R3006[34] = (char *(*)()) F691_3624_3006_28;
	R3006[35] = (char *(*)()) F692_3624_3006_28;
	R3006[36] = (char *(*)()) F693_3624_3006_28;
	R3006[37] = (char *(*)()) F682_3624;
	R3006[38] = (char *(*)()) F684_3624_3006_28;
	R3006[39] = (char *(*)()) F685_3624_3006_28;
	R3006[40] = (char *(*)()) F686_3624_3006_28;
	R3006[41] = (char *(*)()) F687_3624_3006_28;
	R3006[42] = (char *(*)()) F688_3624_3006_28;
	R3006[152] = (char *(*)()) F809_4134;
	R3006[234] = (char *(*)()) F891_5556_3006_28;
	R3006[235] = (char *(*)()) F892_5579_3006_28;
	R3006[237] = (char *(*)()) F894_5721_3006_28;
	R3006[238] = (char *(*)()) F895_5743_3006_28;
	R3006[519] = (char *(*)()) F1176_8632_3006_28;
}
static EIF_REFERENCE F658_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F658_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F659_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F660_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F661_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F662_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F664_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3533_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_3533(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F683_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F684_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F685_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F686_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F686_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F687_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F688_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F689_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F690_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F691_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F692_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_3624_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F693_3624(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_5556_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F891_5556(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_5579_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F892_5579(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_5721_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F894_5721(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_5743_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F895_5743(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1176_8632_3006_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1176_8632(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3007[520])();
void R3007_init () {
	R3007[0] = (char *(*)()) F657_3541;
	R3007[1] = (char *(*)()) F658_3541;
	R3007[2] = (char *(*)()) F659_3541;
	R3007[3] = (char *(*)()) F660_3541;
	R3007[4] = (char *(*)()) F661_3541;
	R3007[5] = (char *(*)()) F662_3541;
	R3007[6] = (char *(*)()) F663_3541;
	R3007[7] = (char *(*)()) F664_3541;
	R3007[8] = (char *(*)()) F665_3541;
	R3007[9] = (char *(*)()) F666_3541;
	R3007[10] = (char *(*)()) F667_3541;
	R3007[11] = (char *(*)()) F668_3541;
	R3007[25] = (char *(*)()) F682_3629;
	R3007[26] = (char *(*)()) F683_3629;
	R3007[27] = (char *(*)()) F684_3629;
	R3007[28] = (char *(*)()) F685_3629;
	R3007[29] = (char *(*)()) F686_3629;
	R3007[30] = (char *(*)()) F687_3629;
	R3007[31] = (char *(*)()) F688_3629;
	R3007[32] = (char *(*)()) F689_3629;
	R3007[33] = (char *(*)()) F690_3629;
	R3007[34] = (char *(*)()) F691_3629;
	R3007[35] = (char *(*)()) F692_3629;
	R3007[36] = (char *(*)()) F693_3629;
	R3007[37] = (char *(*)()) F682_3629;
	R3007[38] = (char *(*)()) F684_3629;
	R3007[39] = (char *(*)()) F685_3629;
	R3007[40] = (char *(*)()) F686_3629;
	R3007[41] = (char *(*)()) F687_3629;
	R3007[42] = (char *(*)()) F688_3629;
	R3007[109] = (char *(*)()) F766_3917;
	R3007[110] = (char *(*)()) F767_3917;
	R3007[111] = (char *(*)()) F768_3917;
	R3007[112] = (char *(*)()) F769_3917;
	R3007[113] = (char *(*)()) F770_3917;
	R3007[116] = (char *(*)()) F766_3917;
	R3007[152] = (char *(*)()) F809_4164;
	{long i; for (i = 234; i < 236; i++) R3007[i] = (char *(*)()) F890_5520;}
	{long i; for (i = 237; i < 239; i++) R3007[i] = (char *(*)()) F893_5688;}
	R3007[519] = (char *(*)()) F893_5688;
}

EIF_TYPE_INDEX *Y3007_gen_type [533];
EIF_TYPE_INDEX Y3007 [533];
void Y3007_init (void)
{
	egc_routines_types [3007] = Y3007;
	egc_routines_gen_types [3007] = Y3007_gen_type;
	egc_routines_offset [3007] = 644;
	{long i; for (i = 0; i < 105; i++) Y3007[i] = 814;};
	{long i; for (i = 109; i < 129; i++) Y3007[i] = 814;};
	Y3007[164] = 814;
	{long i; for (i = 245; i < 252; i++) Y3007[i] = 814;};
	{long i; for (i = 531; i < 533; i++) Y3007[i] = 814;};
}

char *(*R3008[520])();
void R3008_init () {
	R3008[0] = (char *(*)()) F657_3542;
	R3008[1] = (char *(*)()) F658_3542;
	R3008[2] = (char *(*)()) F659_3542;
	R3008[3] = (char *(*)()) F660_3542;
	R3008[4] = (char *(*)()) F661_3542;
	R3008[5] = (char *(*)()) F662_3542;
	R3008[6] = (char *(*)()) F663_3542;
	R3008[7] = (char *(*)()) F664_3542;
	R3008[8] = (char *(*)()) F665_3542;
	R3008[9] = (char *(*)()) F666_3542;
	R3008[10] = (char *(*)()) F667_3542;
	R3008[11] = (char *(*)()) F668_3542;
	R3008[25] = (char *(*)()) F682_3630;
	R3008[26] = (char *(*)()) F683_3630;
	R3008[27] = (char *(*)()) F684_3630;
	R3008[28] = (char *(*)()) F685_3630;
	R3008[29] = (char *(*)()) F686_3630;
	R3008[30] = (char *(*)()) F687_3630;
	R3008[31] = (char *(*)()) F688_3630;
	R3008[32] = (char *(*)()) F689_3630;
	R3008[33] = (char *(*)()) F690_3630;
	R3008[34] = (char *(*)()) F691_3630;
	R3008[35] = (char *(*)()) F692_3630;
	R3008[36] = (char *(*)()) F693_3630;
	R3008[37] = (char *(*)()) F682_3630;
	R3008[38] = (char *(*)()) F684_3630;
	R3008[39] = (char *(*)()) F685_3630;
	R3008[40] = (char *(*)()) F686_3630;
	R3008[41] = (char *(*)()) F687_3630;
	R3008[42] = (char *(*)()) F688_3630;
	R3008[109] = (char *(*)()) F766_3918;
	R3008[110] = (char *(*)()) F767_3918;
	R3008[111] = (char *(*)()) F768_3918;
	R3008[112] = (char *(*)()) F769_3918;
	R3008[113] = (char *(*)()) F770_3918;
	R3008[116] = (char *(*)()) F766_3918;
	R3008[152] = (char *(*)()) F809_4163;
	{long i; for (i = 234; i < 236; i++) R3008[i] = (char *(*)()) F890_5518;}
	{long i; for (i = 237; i < 239; i++) R3008[i] = (char *(*)()) F893_5686;}
	R3008[519] = (char *(*)()) F1176_8648;
}

char *(*R3011[12])();
void R3011_init () {
	R3011[0] = (char *(*)()) F657_3530;
	R3011[1] = (char *(*)()) F658_3530;
	R3011[2] = (char *(*)()) F659_3530;
	R3011[3] = (char *(*)()) F660_3530;
	R3011[4] = (char *(*)()) F661_3530;
	R3011[5] = (char *(*)()) F662_3530;
	R3011[6] = (char *(*)()) F663_3530;
	R3011[7] = (char *(*)()) F664_3530;
	R3011[8] = (char *(*)()) F665_3530;
	R3011[9] = (char *(*)()) F666_3530;
	R3011[10] = (char *(*)()) F667_3530;
	R3011[11] = (char *(*)()) F668_3530;
}

char *(*R3012[12])();
void R3012_init () {
	R3012[0] = (char *(*)()) F657_3531;
	R3012[1] = (char *(*)()) F658_3531_3012_132;
	R3012[2] = (char *(*)()) F659_3531_3012_132;
	R3012[3] = (char *(*)()) F660_3531_3012_132;
	R3012[4] = (char *(*)()) F661_3531_3012_132;
	R3012[5] = (char *(*)()) F662_3531_3012_132;
	R3012[6] = (char *(*)()) F663_3531_3012_132;
	R3012[7] = (char *(*)()) F664_3531_3012_132;
	R3012[8] = (char *(*)()) F665_3531_3012_132;
	R3012[9] = (char *(*)()) F666_3531_3012_132;
	R3012[10] = (char *(*)()) F667_3531_3012_132;
	R3012[11] = (char *(*)()) F668_3531_3012_132;
}
static void F658_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F658_3531(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F659_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F659_3531(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F660_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_3531(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F661_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F661_3531(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F662_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F662_3531(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F663_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F663_3531(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F664_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F664_3531(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F665_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_3531(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F666_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_3531(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F667_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_3531(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F668_3531_3012_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_3531(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3021[12])();
void R3021_init () {
	R3021[0] = (char *(*)()) F657_3546;
	R3021[1] = (char *(*)()) F658_3546;
	R3021[2] = (char *(*)()) F659_3546;
	R3021[3] = (char *(*)()) F660_3546;
	R3021[4] = (char *(*)()) F661_3546;
	R3021[5] = (char *(*)()) F662_3546;
	R3021[6] = (char *(*)()) F663_3546;
	R3021[7] = (char *(*)()) F664_3546;
	R3021[8] = (char *(*)()) F665_3546;
	R3021[9] = (char *(*)()) F666_3546;
	R3021[10] = (char *(*)()) F667_3546;
	R3021[11] = (char *(*)()) F668_3546;
}

char *(*R3022[12])();
void R3022_init () {
	R3022[0] = (char *(*)()) F657_3548;
	R3022[1] = (char *(*)()) F658_3548_3022_132;
	R3022[2] = (char *(*)()) F659_3548_3022_132;
	R3022[3] = (char *(*)()) F660_3548_3022_132;
	R3022[4] = (char *(*)()) F661_3548_3022_132;
	R3022[5] = (char *(*)()) F662_3548_3022_132;
	R3022[6] = (char *(*)()) F663_3548_3022_132;
	R3022[7] = (char *(*)()) F664_3548_3022_132;
	R3022[8] = (char *(*)()) F665_3548_3022_132;
	R3022[9] = (char *(*)()) F666_3548_3022_132;
	R3022[10] = (char *(*)()) F667_3548_3022_132;
	R3022[11] = (char *(*)()) F668_3548_3022_132;
}
static void F658_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F658_3548(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F659_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F659_3548(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F660_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_3548(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F661_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F661_3548(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F662_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F662_3548(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F663_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F663_3548(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F664_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F664_3548(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F665_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_3548(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F666_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_3548(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F667_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_3548(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F668_3548_3022_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_3548(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3023[12])();
void R3023_init () {
	R3023[0] = (char *(*)()) F657_3549;
	R3023[1] = (char *(*)()) F658_3549_3023_132;
	R3023[2] = (char *(*)()) F659_3549_3023_132;
	R3023[3] = (char *(*)()) F660_3549_3023_132;
	R3023[4] = (char *(*)()) F661_3549_3023_132;
	R3023[5] = (char *(*)()) F662_3549_3023_132;
	R3023[6] = (char *(*)()) F663_3549_3023_132;
	R3023[7] = (char *(*)()) F664_3549_3023_132;
	R3023[8] = (char *(*)()) F665_3549_3023_132;
	R3023[9] = (char *(*)()) F666_3549_3023_132;
	R3023[10] = (char *(*)()) F667_3549_3023_132;
	R3023[11] = (char *(*)()) F668_3549_3023_132;
}
static void F658_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F658_3549(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F659_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F659_3549(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F660_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_3549(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F661_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F661_3549(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F662_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F662_3549(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F663_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F663_3549(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F664_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F664_3549(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F665_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_3549(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F666_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_3549(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F667_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_3549(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F668_3549_3023_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_3549(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3026[12])();
void R3026_init () {
	R3026[0] = (char *(*)()) F657_3552;
	R3026[1] = (char *(*)()) F658_3552_3026_40;
	R3026[2] = (char *(*)()) F659_3552_3026_40;
	R3026[3] = (char *(*)()) F660_3552_3026_40;
	R3026[4] = (char *(*)()) F661_3552_3026_40;
	R3026[5] = (char *(*)()) F662_3552_3026_40;
	R3026[6] = (char *(*)()) F663_3552_3026_40;
	R3026[7] = (char *(*)()) F664_3552_3026_40;
	R3026[8] = (char *(*)()) F665_3552_3026_40;
	R3026[9] = (char *(*)()) F666_3552_3026_40;
	R3026[10] = (char *(*)()) F667_3552_3026_40;
	R3026[11] = (char *(*)()) F668_3552_3026_40;
}
static void F658_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F658_3552(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F659_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F659_3552(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F660_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F660_3552(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F661_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F661_3552(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F662_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F662_3552(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F663_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F663_3552(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F664_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F664_3552(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F665_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F665_3552(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F666_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F666_3552(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F667_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F667_3552(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F668_3552_3026_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F668_3552(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3029[12])();
void R3029_init () {
	R3029[0] = (char *(*)()) F657_3555;
	R3029[1] = (char *(*)()) F658_3555;
	R3029[2] = (char *(*)()) F659_3555;
	R3029[3] = (char *(*)()) F660_3555;
	R3029[4] = (char *(*)()) F661_3555;
	R3029[5] = (char *(*)()) F662_3555;
	R3029[6] = (char *(*)()) F663_3555;
	R3029[7] = (char *(*)()) F664_3555;
	R3029[8] = (char *(*)()) F665_3555;
	R3029[9] = (char *(*)()) F666_3555;
	R3029[10] = (char *(*)()) F667_3555;
	R3029[11] = (char *(*)()) F668_3555;
}

char *(*R3030[12])();
void R3030_init () {
	R3030[0] = (char *(*)()) F657_3556;
	R3030[1] = (char *(*)()) F658_3556;
	R3030[2] = (char *(*)()) F659_3556;
	R3030[3] = (char *(*)()) F660_3556;
	R3030[4] = (char *(*)()) F661_3556;
	R3030[5] = (char *(*)()) F662_3556;
	R3030[6] = (char *(*)()) F663_3556;
	R3030[7] = (char *(*)()) F664_3556;
	R3030[8] = (char *(*)()) F665_3556;
	R3030[9] = (char *(*)()) F666_3556;
	R3030[10] = (char *(*)()) F667_3556;
	R3030[11] = (char *(*)()) F668_3556;
}

char *(*R3031[12])();
void R3031_init () {
	R3031[0] = (char *(*)()) F657_3557;
	R3031[1] = (char *(*)()) F658_3557;
	R3031[2] = (char *(*)()) F659_3557;
	R3031[3] = (char *(*)()) F660_3557;
	R3031[4] = (char *(*)()) F661_3557;
	R3031[5] = (char *(*)()) F662_3557;
	R3031[6] = (char *(*)()) F663_3557;
	R3031[7] = (char *(*)()) F664_3557;
	R3031[8] = (char *(*)()) F665_3557;
	R3031[9] = (char *(*)()) F666_3557;
	R3031[10] = (char *(*)()) F667_3557;
	R3031[11] = (char *(*)()) F668_3557;
}

char *(*R3032[12])();
void R3032_init () {
	R3032[0] = (char *(*)()) F657_3558;
	R3032[1] = (char *(*)()) F658_3558;
	R3032[2] = (char *(*)()) F659_3558;
	R3032[3] = (char *(*)()) F660_3558;
	R3032[4] = (char *(*)()) F661_3558;
	R3032[5] = (char *(*)()) F662_3558;
	R3032[6] = (char *(*)()) F663_3558;
	R3032[7] = (char *(*)()) F664_3558;
	R3032[8] = (char *(*)()) F665_3558;
	R3032[9] = (char *(*)()) F666_3558;
	R3032[10] = (char *(*)()) F667_3558;
	R3032[11] = (char *(*)()) F668_3558;
}

char *(*R3033[12])();
void R3033_init () {
	R3033[0] = (char *(*)()) F657_3559;
	R3033[1] = (char *(*)()) F658_3559;
	R3033[2] = (char *(*)()) F659_3559;
	R3033[3] = (char *(*)()) F660_3559;
	R3033[4] = (char *(*)()) F661_3559;
	R3033[5] = (char *(*)()) F662_3559;
	R3033[6] = (char *(*)()) F663_3559;
	R3033[7] = (char *(*)()) F664_3559;
	R3033[8] = (char *(*)()) F665_3559;
	R3033[9] = (char *(*)()) F666_3559;
	R3033[10] = (char *(*)()) F667_3559;
	R3033[11] = (char *(*)()) F668_3559;
}

char *(*R3037[12])();
void R3037_init () {
	R3037[0] = (char *(*)()) F657_3563;
	R3037[1] = (char *(*)()) F658_3563;
	R3037[2] = (char *(*)()) F659_3563;
	R3037[3] = (char *(*)()) F660_3563;
	R3037[4] = (char *(*)()) F661_3563;
	R3037[5] = (char *(*)()) F662_3563;
	R3037[6] = (char *(*)()) F663_3563;
	R3037[7] = (char *(*)()) F664_3563;
	R3037[8] = (char *(*)()) F665_3563;
	R3037[9] = (char *(*)()) F666_3563;
	R3037[10] = (char *(*)()) F667_3563;
	R3037[11] = (char *(*)()) F668_3563;
}

char *(*R3039[12])();
void R3039_init () {
	R3039[0] = (char *(*)()) F657_3565;
	R3039[1] = (char *(*)()) F658_3565;
	R3039[2] = (char *(*)()) F659_3565;
	R3039[3] = (char *(*)()) F660_3565;
	R3039[4] = (char *(*)()) F661_3565;
	R3039[5] = (char *(*)()) F662_3565;
	R3039[6] = (char *(*)()) F663_3565;
	R3039[7] = (char *(*)()) F664_3565;
	R3039[8] = (char *(*)()) F665_3565;
	R3039[9] = (char *(*)()) F666_3565;
	R3039[10] = (char *(*)()) F667_3565;
	R3039[11] = (char *(*)()) F668_3565;
}

char *(*R3040[12])();
void R3040_init () {
	R3040[0] = (char *(*)()) F657_3566;
	R3040[1] = (char *(*)()) F658_3566_3040_32;
	R3040[2] = (char *(*)()) F659_3566_3040_32;
	R3040[3] = (char *(*)()) F660_3566_3040_32;
	R3040[4] = (char *(*)()) F661_3566_3040_32;
	R3040[5] = (char *(*)()) F662_3566_3040_32;
	R3040[6] = (char *(*)()) F663_3566_3040_32;
	R3040[7] = (char *(*)()) F664_3566_3040_32;
	R3040[8] = (char *(*)()) F665_3566_3040_32;
	R3040[9] = (char *(*)()) F666_3566_3040_32;
	R3040[10] = (char *(*)()) F667_3566_3040_32;
	R3040[11] = (char *(*)()) F668_3566_3040_32;
}
static EIF_REFERENCE F658_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F658_3566(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F659_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F659_3566(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F660_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F660_3566(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F661_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F661_3566(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F662_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F662_3566(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F663_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F663_3566(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F664_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F664_3566(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F665_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F665_3566(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F666_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F666_3566(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F667_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F667_3566(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F668_3566_3040_32 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F668_3566(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3042[12])();
void R3042_init () {
	R3042[0] = (char *(*)()) F657_3568;
	R3042[1] = (char *(*)()) F658_3568;
	R3042[2] = (char *(*)()) F659_3568;
	R3042[3] = (char *(*)()) F660_3568;
	R3042[4] = (char *(*)()) F661_3568;
	R3042[5] = (char *(*)()) F662_3568;
	R3042[6] = (char *(*)()) F663_3568;
	R3042[7] = (char *(*)()) F664_3568;
	R3042[8] = (char *(*)()) F665_3568;
	R3042[9] = (char *(*)()) F666_3568;
	R3042[10] = (char *(*)()) F667_3568;
	R3042[11] = (char *(*)()) F668_3568;
}

char *(*R3051[12])();
void R3051_init () {
	R3051[0] = (char *(*)()) F657_3578;
	R3051[1] = (char *(*)()) F658_3578;
	R3051[2] = (char *(*)()) F659_3578;
	R3051[3] = (char *(*)()) F660_3578;
	R3051[4] = (char *(*)()) F661_3578;
	R3051[5] = (char *(*)()) F662_3578;
	R3051[6] = (char *(*)()) F663_3578;
	R3051[7] = (char *(*)()) F664_3578;
	R3051[8] = (char *(*)()) F665_3578;
	R3051[9] = (char *(*)()) F666_3578;
	R3051[10] = (char *(*)()) F667_3578;
	R3051[11] = (char *(*)()) F668_3578;
}

char *(*R3071[18])();
void R3071_init () {
	R3071[0] = (char *(*)()) F682_3618;
	R3071[1] = (char *(*)()) F683_3618;
	R3071[2] = (char *(*)()) F684_3618;
	R3071[3] = (char *(*)()) F685_3618;
	R3071[4] = (char *(*)()) F686_3618;
	R3071[5] = (char *(*)()) F687_3618;
	R3071[6] = (char *(*)()) F688_3618;
	R3071[7] = (char *(*)()) F689_3618;
	R3071[8] = (char *(*)()) F690_3618;
	R3071[9] = (char *(*)()) F691_3618;
	R3071[10] = (char *(*)()) F692_3618;
	R3071[11] = (char *(*)()) F693_3618;
	R3071[12] = (char *(*)()) F682_3618;
	R3071[13] = (char *(*)()) F684_3618;
	R3071[14] = (char *(*)()) F685_3618;
	R3071[15] = (char *(*)()) F686_3618;
	R3071[16] = (char *(*)()) F687_3618;
	R3071[17] = (char *(*)()) F688_3618;
}

char *(*R3072[18])();
void R3072_init () {
	R3072[0] = (char *(*)()) F682_3619;
	R3072[1] = (char *(*)()) F683_3619_3072_40;
	R3072[2] = (char *(*)()) F684_3619_3072_40;
	R3072[3] = (char *(*)()) F685_3619_3072_40;
	R3072[4] = (char *(*)()) F686_3619_3072_40;
	R3072[5] = (char *(*)()) F687_3619_3072_40;
	R3072[6] = (char *(*)()) F688_3619_3072_40;
	R3072[7] = (char *(*)()) F689_3619_3072_40;
	R3072[8] = (char *(*)()) F690_3619_3072_40;
	R3072[9] = (char *(*)()) F691_3619_3072_40;
	R3072[10] = (char *(*)()) F692_3619_3072_40;
	R3072[11] = (char *(*)()) F693_3619_3072_40;
	R3072[12] = (char *(*)()) F682_3619;
	R3072[13] = (char *(*)()) F684_3619_3072_40;
	R3072[14] = (char *(*)()) F685_3619_3072_40;
	R3072[15] = (char *(*)()) F686_3619_3072_40;
	R3072[16] = (char *(*)()) F687_3619_3072_40;
	R3072[17] = (char *(*)()) F688_3619_3072_40;
}
static void F683_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F683_3619(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F684_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F684_3619(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F685_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F685_3619(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F686_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F686_3619(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F687_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F687_3619(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F688_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F688_3619(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F689_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F689_3619(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F690_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F690_3619(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F691_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F691_3619(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F692_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F692_3619(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F693_3619_3072_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F693_3619(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3074[18])();
void R3074_init () {
	R3074[0] = (char *(*)()) F682_3621;
	R3074[1] = (char *(*)()) F683_3621;
	R3074[2] = (char *(*)()) F684_3621;
	R3074[3] = (char *(*)()) F685_3621;
	R3074[4] = (char *(*)()) F686_3621;
	R3074[5] = (char *(*)()) F687_3621;
	R3074[6] = (char *(*)()) F688_3621;
	R3074[7] = (char *(*)()) F689_3621;
	R3074[8] = (char *(*)()) F690_3621;
	R3074[9] = (char *(*)()) F691_3621;
	R3074[10] = (char *(*)()) F692_3621;
	R3074[11] = (char *(*)()) F693_3621;
	R3074[12] = (char *(*)()) F682_3621;
	R3074[13] = (char *(*)()) F684_3621;
	R3074[14] = (char *(*)()) F685_3621;
	R3074[15] = (char *(*)()) F686_3621;
	R3074[16] = (char *(*)()) F687_3621;
	R3074[17] = (char *(*)()) F688_3621;
}

char *(*R3075[18])();
void R3075_init () {
	R3075[0] = (char *(*)()) F682_3622;
	R3075[1] = (char *(*)()) F683_3622;
	R3075[2] = (char *(*)()) F684_3622;
	R3075[3] = (char *(*)()) F685_3622;
	R3075[4] = (char *(*)()) F686_3622;
	R3075[5] = (char *(*)()) F687_3622;
	R3075[6] = (char *(*)()) F688_3622;
	R3075[7] = (char *(*)()) F689_3622;
	R3075[8] = (char *(*)()) F690_3622;
	R3075[9] = (char *(*)()) F691_3622;
	R3075[10] = (char *(*)()) F692_3622;
	R3075[11] = (char *(*)()) F693_3622;
	R3075[12] = (char *(*)()) F682_3622;
	R3075[13] = (char *(*)()) F684_3622;
	R3075[14] = (char *(*)()) F685_3622;
	R3075[15] = (char *(*)()) F686_3622;
	R3075[16] = (char *(*)()) F687_3622;
	R3075[17] = (char *(*)()) F688_3622;
}

char *(*R3085[18])();
void R3085_init () {
	R3085[0] = (char *(*)()) F682_3648;
	R3085[1] = (char *(*)()) F683_3648;
	R3085[2] = (char *(*)()) F684_3648;
	R3085[3] = (char *(*)()) F685_3648;
	R3085[4] = (char *(*)()) F686_3648;
	R3085[5] = (char *(*)()) F687_3648;
	R3085[6] = (char *(*)()) F688_3648;
	R3085[7] = (char *(*)()) F689_3648;
	R3085[8] = (char *(*)()) F690_3648;
	R3085[9] = (char *(*)()) F691_3648;
	R3085[10] = (char *(*)()) F692_3648;
	R3085[11] = (char *(*)()) F693_3648;
	R3085[12] = (char *(*)()) F682_3648;
	R3085[13] = (char *(*)()) F684_3648;
	R3085[14] = (char *(*)()) F685_3648;
	R3085[15] = (char *(*)()) F686_3648;
	R3085[16] = (char *(*)()) F687_3648;
	R3085[17] = (char *(*)()) F688_3648;
}

char *(*R3099[18])();
void R3099_init () {
	R3099[0] = (char *(*)()) F682_3664;
	R3099[1] = (char *(*)()) F683_3664_3099_40;
	R3099[2] = (char *(*)()) F684_3664_3099_40;
	R3099[3] = (char *(*)()) F685_3664_3099_40;
	R3099[4] = (char *(*)()) F686_3664_3099_40;
	R3099[5] = (char *(*)()) F687_3664_3099_40;
	R3099[6] = (char *(*)()) F688_3664_3099_40;
	R3099[7] = (char *(*)()) F689_3664_3099_40;
	R3099[8] = (char *(*)()) F690_3664_3099_40;
	R3099[9] = (char *(*)()) F691_3664_3099_40;
	R3099[10] = (char *(*)()) F692_3664_3099_40;
	R3099[11] = (char *(*)()) F693_3664_3099_40;
	R3099[12] = (char *(*)()) F682_3664;
	R3099[13] = (char *(*)()) F684_3664_3099_40;
	R3099[14] = (char *(*)()) F685_3664_3099_40;
	R3099[15] = (char *(*)()) F686_3664_3099_40;
	R3099[16] = (char *(*)()) F687_3664_3099_40;
	R3099[17] = (char *(*)()) F688_3664_3099_40;
}
static void F683_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F683_3664(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F684_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F684_3664(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F685_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F685_3664(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F686_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F686_3664(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F687_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F687_3664(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F688_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F688_3664(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F689_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F689_3664(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F690_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F690_3664(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F691_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F691_3664(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F692_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F692_3664(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F693_3664_3099_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F693_3664(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3106[18])();
void R3106_init () {
	R3106[0] = (char *(*)()) F682_3676;
	R3106[1] = (char *(*)()) F683_3676;
	R3106[2] = (char *(*)()) F684_3676;
	R3106[3] = (char *(*)()) F685_3676;
	R3106[4] = (char *(*)()) F686_3676;
	R3106[5] = (char *(*)()) F687_3676;
	R3106[6] = (char *(*)()) F688_3676;
	R3106[7] = (char *(*)()) F689_3676;
	R3106[8] = (char *(*)()) F690_3676;
	R3106[9] = (char *(*)()) F691_3676;
	R3106[10] = (char *(*)()) F692_3676;
	R3106[11] = (char *(*)()) F693_3676;
	R3106[12] = (char *(*)()) F682_3676;
	R3106[13] = (char *(*)()) F684_3676;
	R3106[14] = (char *(*)()) F685_3676;
	R3106[15] = (char *(*)()) F686_3676;
	R3106[16] = (char *(*)()) F687_3676;
	R3106[17] = (char *(*)()) F688_3676;
}

char *(*R3109[6])();
void R3109_init () {
	R3109[0] = (char *(*)()) F694_3677;
	R3109[1] = (char *(*)()) F695_3677;
	R3109[2] = (char *(*)()) F696_3677;
	R3109[3] = (char *(*)()) F697_3677;
	R3109[4] = (char *(*)()) F698_3677;
	R3109[5] = (char *(*)()) F699_3677;
}

char *(*R3159[411])();
void R3159_init () {
	R3159[0] = (char *(*)()) F766_3955;
	R3159[1] = (char *(*)()) F767_3955;
	R3159[2] = (char *(*)()) F768_3955;
	R3159[3] = (char *(*)()) F769_3955;
	R3159[4] = (char *(*)()) F770_3955;
	R3159[7] = (char *(*)()) F766_3955;
	R3159[43] = (char *(*)()) F809_4242;
	R3159[125] = (char *(*)()) F891_5572;
	R3159[126] = (char *(*)()) F892_5663;
	R3159[129] = (char *(*)()) F895_5827;
	R3159[242] = (char *(*)()) F999_6821;
	R3159[243] = (char *(*)()) F1002_6821;
	R3159[254] = (char *(*)()) F999_6821;
	R3159[255] = (char *(*)()) F1000_6821;
	R3159[256] = (char *(*)()) F1001_6821;
	R3159[257] = (char *(*)()) F1002_6821;
	R3159[258] = (char *(*)()) F1003_6821;
	R3159[261] = (char *(*)()) F1027_6867;
	R3159[262] = (char *(*)()) F1028_6867;
	R3159[315] = (char *(*)()) F1081_7252;
	R3159[316] = (char *(*)()) F1082_7333;
	R3159[317] = (char *(*)()) F1083_7333;
	R3159[327] = (char *(*)()) F1091_7484;
	R3159[328] = (char *(*)()) F1092_7484;
	R3159[339] = (char *(*)()) F1100_7568;
	R3159[340] = (char *(*)()) F1101_7568;
	R3159[341] = (char *(*)()) F1102_7568;
	R3159[342] = (char *(*)()) F1103_7568;
	R3159[343] = (char *(*)()) F1104_7568;
	R3159[410] = (char *(*)()) F895_5827;
}

char *(*R3186[8])();
void R3186_init () {
	R3186[0] = (char *(*)()) F766_3896;
	R3186[1] = (char *(*)()) F767_3896;
	R3186[2] = (char *(*)()) F768_3896;
	R3186[3] = (char *(*)()) F769_3896;
	R3186[4] = (char *(*)()) F770_3896;
	R3186[7] = (char *(*)()) F766_3896;
}

char *(*R3189[8])();
void R3189_init () {
	R3189[0] = (char *(*)()) F766_3899;
	R3189[1] = (char *(*)()) F767_3899;
	R3189[2] = (char *(*)()) F768_3899;
	R3189[3] = (char *(*)()) F769_3899;
	R3189[4] = (char *(*)()) F770_3899;
	R3189[7] = (char *(*)()) F766_3899;
}

char *(*R3190[8])();
void R3190_init () {
	R3190[0] = (char *(*)()) F766_3900;
	R3190[1] = (char *(*)()) F767_3900_3190_1;
	R3190[2] = (char *(*)()) F768_3900_3190_1;
	R3190[3] = (char *(*)()) F769_3900;
	R3190[4] = (char *(*)()) F770_3900_3190_1;
	R3190[7] = (char *(*)()) F766_3900;
}
static EIF_REFERENCE F767_3900_3190_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F767_3900(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F768_3900_3190_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F768_3900(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_3900_3190_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F770_3900(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3198[8])();
void R3198_init () {
	R3198[0] = (char *(*)()) F766_3913;
	R3198[1] = (char *(*)()) F767_3913;
	R3198[2] = (char *(*)()) F768_3913;
	R3198[3] = (char *(*)()) F769_3913_3198_23;
	R3198[4] = (char *(*)()) F770_3913_3198_23;
	R3198[7] = (char *(*)()) F766_3913;
}
static EIF_INTEGER_32 F769_3913_3198_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F769_3913(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F770_3913_3198_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F770_3913(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3200[8])();
void R3200_init () {
	R3200[0] = (char *(*)()) F766_3920;
	R3200[1] = (char *(*)()) F767_3920;
	R3200[2] = (char *(*)()) F768_3920;
	R3200[3] = (char *(*)()) F769_3920_3200_3;
	R3200[4] = (char *(*)()) F770_3920_3200_3;
	R3200[7] = (char *(*)()) F766_3920;
}
static EIF_BOOLEAN F769_3920_3200_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F769_3920(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F770_3920_3200_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F770_3920(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3206[8])();
void R3206_init () {
	R3206[0] = (char *(*)()) F766_3928;
	R3206[1] = (char *(*)()) F767_3928;
	R3206[2] = (char *(*)()) F768_3928;
	R3206[3] = (char *(*)()) F769_3928;
	R3206[4] = (char *(*)()) F770_3928;
	R3206[7] = (char *(*)()) F766_3928;
}

char *(*R3207[8])();
void R3207_init () {
	R3207[0] = (char *(*)()) F766_3929;
	R3207[1] = (char *(*)()) F767_3929;
	R3207[2] = (char *(*)()) F768_3929;
	R3207[3] = (char *(*)()) F769_3929;
	R3207[4] = (char *(*)()) F770_3929;
	R3207[7] = (char *(*)()) F766_3929;
}

char *(*R3215[8])();
void R3215_init () {
	R3215[0] = (char *(*)()) F766_3938;
	R3215[1] = (char *(*)()) F767_3938;
	R3215[2] = (char *(*)()) F768_3938;
	R3215[3] = (char *(*)()) F769_3938_3215_4;
	R3215[4] = (char *(*)()) F770_3938_3215_4;
	R3215[7] = (char *(*)()) F766_3938;
}
static void F769_3938_3215_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F769_3938(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F770_3938_3215_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F770_3938(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3217[8])();
void R3217_init () {
	R3217[0] = (char *(*)()) F766_3940;
	R3217[1] = (char *(*)()) F767_3940;
	R3217[2] = (char *(*)()) F768_3940;
	R3217[3] = (char *(*)()) F769_3940;
	R3217[4] = (char *(*)()) F770_3940;
	R3217[7] = (char *(*)()) F766_3940;
}

char *(*R3218[8])();
void R3218_init () {
	R3218[0] = (char *(*)()) F766_3941;
	R3218[1] = (char *(*)()) F767_3941;
	R3218[2] = (char *(*)()) F768_3941;
	R3218[3] = (char *(*)()) F769_3941;
	R3218[4] = (char *(*)()) F770_3941;
	R3218[7] = (char *(*)()) F766_3941;
}

char *(*R3224[8])();
void R3224_init () {
	R3224[0] = (char *(*)()) F766_3954;
	R3224[1] = (char *(*)()) F767_3954;
	R3224[2] = (char *(*)()) F768_3954;
	R3224[3] = (char *(*)()) F769_3954;
	R3224[4] = (char *(*)()) F770_3954;
	R3224[7] = (char *(*)()) F766_3954;
}

char *(*R3233[8])();
void R3233_init () {
	R3233[0] = (char *(*)()) F766_3964;
	R3233[1] = (char *(*)()) F767_3964;
	R3233[2] = (char *(*)()) F768_3964;
	R3233[3] = (char *(*)()) F769_3964;
	R3233[4] = (char *(*)()) F770_3964;
	R3233[7] = (char *(*)()) F766_3964;
}

char *(*R3234[8])();
void R3234_init () {
	R3234[0] = (char *(*)()) F766_3965;
	R3234[1] = (char *(*)()) F767_3965;
	R3234[2] = (char *(*)()) F768_3965;
	R3234[3] = (char *(*)()) F769_3965;
	R3234[4] = (char *(*)()) F770_3965;
	R3234[7] = (char *(*)()) F766_3965;
}

char *(*R3241[8])();
void R3241_init () {
	R3241[0] = (char *(*)()) F766_3972;
	R3241[1] = (char *(*)()) F767_3972_3241_1;
	R3241[2] = (char *(*)()) F768_3972_3241_1;
	R3241[3] = (char *(*)()) F769_3972;
	R3241[4] = (char *(*)()) F770_3972_3241_1;
	R3241[7] = (char *(*)()) F766_3972;
}
static EIF_REFERENCE F767_3972_3241_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F767_3972(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F768_3972_3241_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F768_3972(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_3972_3241_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F770_3972(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3242[8])();
void R3242_init () {
	R3242[0] = (char *(*)()) F766_3973;
	R3242[1] = (char *(*)()) F767_3973;
	R3242[2] = (char *(*)()) F768_3973;
	R3242[3] = (char *(*)()) F769_3973_3242_1;
	R3242[4] = (char *(*)()) F770_3973_3242_1;
	R3242[7] = (char *(*)()) F766_3973;
}
static EIF_REFERENCE F769_3973_3242_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F769_3973(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_3973_3242_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F770_3973(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3243[8])();
void R3243_init () {
	R3243[0] = (char *(*)()) F766_3974;
	R3243[1] = (char *(*)()) F767_3974;
	R3243[2] = (char *(*)()) F768_3974;
	R3243[3] = (char *(*)()) F769_3974;
	R3243[4] = (char *(*)()) F770_3974;
	R3243[7] = (char *(*)()) F766_3974;
}

char *(*R3244[8])();
void R3244_init () {
	R3244[0] = (char *(*)()) F766_3975;
	R3244[1] = (char *(*)()) F767_3975;
	R3244[2] = (char *(*)()) F768_3975;
	R3244[3] = (char *(*)()) F769_3975;
	R3244[4] = (char *(*)()) F770_3975;
	R3244[7] = (char *(*)()) F766_3975;
}

char *(*R3247[8])();
void R3247_init () {
	R3247[0] = (char *(*)()) F766_3978;
	R3247[1] = (char *(*)()) F767_3978;
	R3247[2] = (char *(*)()) F768_3978;
	R3247[3] = (char *(*)()) F769_3978;
	R3247[4] = (char *(*)()) F770_3978;
	R3247[7] = (char *(*)()) F766_3978;
}

char *(*R3249[8])();
void R3249_init () {
	R3249[0] = (char *(*)()) F766_3980;
	R3249[1] = (char *(*)()) F767_3980;
	R3249[2] = (char *(*)()) F768_3980;
	R3249[3] = (char *(*)()) F769_3980;
	R3249[4] = (char *(*)()) F770_3980;
	R3249[7] = (char *(*)()) F766_3980;
}

char *(*R3250[8])();
void R3250_init () {
	R3250[0] = (char *(*)()) F766_3981;
	R3250[1] = (char *(*)()) F767_3981;
	R3250[2] = (char *(*)()) F768_3981;
	R3250[3] = (char *(*)()) F769_3981;
	R3250[4] = (char *(*)()) F770_3981;
	R3250[7] = (char *(*)()) F766_3981;
}

char *(*R3251[8])();
void R3251_init () {
	R3251[0] = (char *(*)()) F766_3982;
	R3251[1] = (char *(*)()) F767_3982;
	R3251[2] = (char *(*)()) F768_3982;
	R3251[3] = (char *(*)()) F769_3982;
	R3251[4] = (char *(*)()) F770_3982;
	R3251[7] = (char *(*)()) F766_3982;
}

char *(*R3255[8])();
void R3255_init () {
	R3255[0] = (char *(*)()) F766_3986;
	R3255[1] = (char *(*)()) F767_3986;
	R3255[2] = (char *(*)()) F768_3986;
	R3255[3] = (char *(*)()) F769_3986_3255_4;
	R3255[4] = (char *(*)()) F770_3986_3255_4;
	R3255[7] = (char *(*)()) F766_3986;
}
static void F769_3986_3255_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F769_3986(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F770_3986_3255_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F770_3986(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3261[8])();
void R3261_init () {
	R3261[0] = (char *(*)()) F766_3992;
	R3261[1] = (char *(*)()) F767_3992;
	R3261[2] = (char *(*)()) F768_3992;
	R3261[3] = (char *(*)()) F769_3992;
	R3261[4] = (char *(*)()) F770_3992;
	R3261[7] = (char *(*)()) F766_3992;
}

char *(*R3274[8])();
void R3274_init () {
	R3274[0] = (char *(*)()) F766_4005;
	R3274[1] = (char *(*)()) F767_4005;
	R3274[2] = (char *(*)()) F768_4005;
	R3274[3] = (char *(*)()) F769_4005;
	R3274[4] = (char *(*)()) F770_4005;
	R3274[7] = (char *(*)()) F766_4005;
}

char *(*R3291[400])();
void R3291_init () {
	R3291[0] = (char *(*)()) F777_4098;
	R3291[1] = (char *(*)()) F778_4108;
	R3291[2] = (char *(*)()) F779_4108;
	R3291[3] = (char *(*)()) F780_4108;
	R3291[4] = (char *(*)()) F781_4108;
	R3291[5] = (char *(*)()) F782_4108;
	R3291[6] = (char *(*)()) F783_4108;
	R3291[7] = (char *(*)()) F784_4108;
	R3291[8] = (char *(*)()) F785_4108;
	R3291[9] = (char *(*)()) F786_4108;
	R3291[10] = (char *(*)()) F787_4108;
	R3291[11] = (char *(*)()) F788_4108;
	R3291[12] = (char *(*)()) F789_4108;
	R3291[13] = (char *(*)()) F790_4108;
	R3291[14] = (char *(*)()) F791_4108;
	R3291[15] = (char *(*)()) F792_4108;
	R3291[16] = (char *(*)()) F793_4108;
	R3291[17] = (char *(*)()) F794_4108;
	R3291[18] = (char *(*)()) F795_4108;
	R3291[19] = (char *(*)()) F796_4108;
	R3291[20] = (char *(*)()) F797_4108;
	R3291[21] = (char *(*)()) F798_4108;
	R3291[22] = (char *(*)()) F799_4108;
	R3291[23] = (char *(*)()) F800_4108;
	R3291[24] = (char *(*)()) F801_4108;
	R3291[25] = (char *(*)()) F802_4108;
	R3291[26] = (char *(*)()) F803_4108;
	R3291[27] = (char *(*)()) F804_4108;
	R3291[28] = (char *(*)()) F805_4108;
	R3291[29] = (char *(*)()) F806_4108;
	R3291[30] = (char *(*)()) F807_4108;
	R3291[31] = (char *(*)()) F808_4108;
	R3291[32] = (char *(*)()) F809_4160;
	{long i; for (i = 34; i < 36; i++) R3291[i] = (char *(*)()) F810_4267;}
	{long i; for (i = 37; i < 39; i++) R3291[i] = (char *(*)()) F813_4365;}
	{long i; for (i = 40; i < 42; i++) R3291[i] = (char *(*)()) F816_4464;}
	{long i; for (i = 43; i < 45; i++) R3291[i] = (char *(*)()) F819_4563;}
	{long i; for (i = 46; i < 48; i++) R3291[i] = (char *(*)()) F822_4662;}
	{long i; for (i = 49; i < 51; i++) R3291[i] = (char *(*)()) F825_4756;}
	{long i; for (i = 52; i < 54; i++) R3291[i] = (char *(*)()) F828_4850;}
	{long i; for (i = 55; i < 57; i++) R3291[i] = (char *(*)()) F831_4945;}
	{long i; for (i = 58; i < 60; i++) R3291[i] = (char *(*)()) F834_5040;}
	{long i; for (i = 61; i < 63; i++) R3291[i] = (char *(*)()) F837_5106;}
	{long i; for (i = 64; i < 66; i++) R3291[i] = (char *(*)()) F840_5173;}
	{long i; for (i = 67; i < 69; i++) R3291[i] = (char *(*)()) F843_5214;}
	{long i; for (i = 70; i < 72; i++) R3291[i] = (char *(*)()) F846_5262;}
	{long i; for (i = 73; i < 103; i++) R3291[i] = (char *(*)()) F849_5283;}
	R3291[103] = (char *(*)()) F880_5309;
	R3291[104] = (char *(*)()) F881_5309;
	{long i; for (i = 114; i < 116; i++) R3291[i] = (char *(*)()) F887_5376;}
	{long i; for (i = 117; i < 119; i++) R3291[i] = (char *(*)()) F887_5376;}
	{long i; for (i = 125; i < 127; i++) R3291[i] = (char *(*)()) F902_5899;}
	R3291[149] = (char *(*)()) F926_6146;
	R3291[399] = (char *(*)()) F1176_8643;
}

char *(*R3359[31])();
void R3359_init () {
	R3359[0] = (char *(*)()) F778_4104;
	R3359[1] = (char *(*)()) F779_4104;
	R3359[2] = (char *(*)()) F780_4104;
	R3359[3] = (char *(*)()) F781_4104;
	R3359[4] = (char *(*)()) F782_4104;
	R3359[5] = (char *(*)()) F783_4104;
	R3359[6] = (char *(*)()) F784_4104;
	R3359[7] = (char *(*)()) F785_4104;
	R3359[8] = (char *(*)()) F786_4104;
	R3359[9] = (char *(*)()) F787_4104;
	R3359[10] = (char *(*)()) F788_4104;
	R3359[11] = (char *(*)()) F789_4104;
	R3359[12] = (char *(*)()) F790_4104;
	R3359[13] = (char *(*)()) F791_4104;
	R3359[14] = (char *(*)()) F792_4104;
	R3359[15] = (char *(*)()) F793_4104;
	R3359[16] = (char *(*)()) F794_4104;
	R3359[17] = (char *(*)()) F795_4104;
	R3359[18] = (char *(*)()) F796_4104;
	R3359[19] = (char *(*)()) F797_4104;
	R3359[20] = (char *(*)()) F798_4104;
	R3359[21] = (char *(*)()) F799_4104;
	R3359[22] = (char *(*)()) F800_4104;
	R3359[23] = (char *(*)()) F801_4104;
	R3359[24] = (char *(*)()) F802_4104;
	R3359[25] = (char *(*)()) F803_4104;
	R3359[26] = (char *(*)()) F804_4104;
	R3359[27] = (char *(*)()) F805_4104;
	R3359[28] = (char *(*)()) F806_4104;
	R3359[29] = (char *(*)()) F807_4104;
	R3359[30] = (char *(*)()) F808_4104;
}

char *(*R3362[31])();
void R3362_init () {
	R3362[0] = (char *(*)()) F778_4107;
	R3362[1] = (char *(*)()) F779_4107;
	R3362[2] = (char *(*)()) F780_4107;
	R3362[3] = (char *(*)()) F781_4107;
	R3362[4] = (char *(*)()) F782_4107;
	R3362[5] = (char *(*)()) F783_4107;
	R3362[6] = (char *(*)()) F784_4107;
	R3362[7] = (char *(*)()) F785_4107;
	R3362[8] = (char *(*)()) F786_4107;
	R3362[9] = (char *(*)()) F787_4107;
	R3362[10] = (char *(*)()) F788_4107;
	R3362[11] = (char *(*)()) F789_4107;
	R3362[12] = (char *(*)()) F790_4107;
	R3362[13] = (char *(*)()) F791_4107;
	R3362[14] = (char *(*)()) F792_4107;
	R3362[15] = (char *(*)()) F793_4107;
	R3362[16] = (char *(*)()) F794_4107;
	R3362[17] = (char *(*)()) F795_4107;
	R3362[18] = (char *(*)()) F796_4107;
	R3362[19] = (char *(*)()) F797_4107;
	R3362[20] = (char *(*)()) F798_4107;
	R3362[21] = (char *(*)()) F799_4107;
	R3362[22] = (char *(*)()) F800_4107;
	R3362[23] = (char *(*)()) F801_4107;
	R3362[24] = (char *(*)()) F802_4107;
	R3362[25] = (char *(*)()) F803_4107;
	R3362[26] = (char *(*)()) F804_4107;
	R3362[27] = (char *(*)()) F805_4107;
	R3362[28] = (char *(*)()) F806_4107;
	R3362[29] = (char *(*)()) F807_4107;
	R3362[30] = (char *(*)()) F808_4107;
}

char *(*R3367[31])();
void R3367_init () {
	R3367[0] = (char *(*)()) F778_4113;
	R3367[1] = (char *(*)()) F779_4113;
	R3367[2] = (char *(*)()) F780_4113;
	R3367[3] = (char *(*)()) F781_4113;
	R3367[4] = (char *(*)()) F782_4113;
	R3367[5] = (char *(*)()) F783_4113;
	R3367[6] = (char *(*)()) F784_4113;
	R3367[7] = (char *(*)()) F785_4113;
	R3367[8] = (char *(*)()) F786_4113;
	R3367[9] = (char *(*)()) F787_4113;
	R3367[10] = (char *(*)()) F788_4113;
	R3367[11] = (char *(*)()) F789_4113;
	R3367[12] = (char *(*)()) F790_4113;
	R3367[13] = (char *(*)()) F791_4113;
	R3367[14] = (char *(*)()) F792_4113;
	R3367[15] = (char *(*)()) F793_4113;
	R3367[16] = (char *(*)()) F794_4113;
	R3367[17] = (char *(*)()) F795_4113;
	R3367[18] = (char *(*)()) F796_4113;
	R3367[19] = (char *(*)()) F797_4113;
	R3367[20] = (char *(*)()) F798_4113;
	R3367[21] = (char *(*)()) F799_4113;
	R3367[22] = (char *(*)()) F800_4113;
	R3367[23] = (char *(*)()) F801_4113;
	R3367[24] = (char *(*)()) F802_4113;
	R3367[25] = (char *(*)()) F803_4113;
	R3367[26] = (char *(*)()) F804_4113;
	R3367[27] = (char *(*)()) F805_4113;
	R3367[28] = (char *(*)()) F806_4113;
	R3367[29] = (char *(*)()) F807_4113;
	R3367[30] = (char *(*)()) F808_4113;
}

char *(*R3372[31])();
void R3372_init () {
	R3372[0] = (char *(*)()) F778_4121;
	R3372[1] = (char *(*)()) F779_4121_3372_1;
	R3372[2] = (char *(*)()) F780_4121_3372_1;
	R3372[3] = (char *(*)()) F781_4121_3372_1;
	R3372[4] = (char *(*)()) F782_4121_3372_1;
	R3372[5] = (char *(*)()) F783_4121_3372_1;
	R3372[6] = (char *(*)()) F784_4121_3372_1;
	R3372[7] = (char *(*)()) F785_4121_3372_1;
	R3372[8] = (char *(*)()) F786_4121_3372_1;
	R3372[9] = (char *(*)()) F787_4121_3372_1;
	R3372[10] = (char *(*)()) F788_4121_3372_1;
	R3372[11] = (char *(*)()) F789_4121_3372_1;
	R3372[12] = (char *(*)()) F790_4121_3372_1;
	R3372[13] = (char *(*)()) F791_4121_3372_1;
	R3372[14] = (char *(*)()) F792_4121_3372_1;
	R3372[15] = (char *(*)()) F793_4121_3372_1;
	R3372[16] = (char *(*)()) F794_4121;
	R3372[17] = (char *(*)()) F795_4121_3372_1;
	R3372[18] = (char *(*)()) F796_4121_3372_1;
	R3372[19] = (char *(*)()) F797_4121_3372_1;
	R3372[20] = (char *(*)()) F798_4121_3372_1;
	R3372[21] = (char *(*)()) F799_4121_3372_1;
	R3372[22] = (char *(*)()) F800_4121_3372_1;
	R3372[23] = (char *(*)()) F801_4121_3372_1;
	R3372[24] = (char *(*)()) F802_4121_3372_1;
	R3372[25] = (char *(*)()) F803_4121_3372_1;
	R3372[26] = (char *(*)()) F804_4121_3372_1;
	R3372[27] = (char *(*)()) F805_4121_3372_1;
	R3372[28] = (char *(*)()) F806_4121_3372_1;
	R3372[29] = (char *(*)()) F807_4121_3372_1;
	R3372[30] = (char *(*)()) F808_4121_3372_1;
}
static EIF_REFERENCE F779_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F779_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F780_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {850,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 850, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F781_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(838, 0x00).id, 838, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F782_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F783_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(832, 0x00).id, 832, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F784_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(829, 0x00).id, 829, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F785_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F786_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F787_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F788_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F789_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F790_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(811, 0x00).id, 811, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F791_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F791_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(844, 0x00).id, 844, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F792_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F792_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(847, 0x00).id, 847, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F793_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F793_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(841, 0x00).id, 841, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F795_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {852,820,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 852, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F796_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {854,817,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 854, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F797_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {856,814,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 856, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F798_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {858,811,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F799_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {860,832,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 860, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F800_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {862,829,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 862, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F801_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {864,826,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 864, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F802_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {866,823,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 866, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F803_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {868,838,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 868, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F804_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {870,835,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 870, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F805_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {872,844,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 872, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F806_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F806_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {874,847,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 874, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F807_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F807_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {876,880,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 876, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F808_4121_3372_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F808_4121(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {878,841,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 878, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}

char *(*R3382[31])();
void R3382_init () {
	R3382[0] = (char *(*)()) F778_4133;
	R3382[1] = (char *(*)()) F779_4133;
	R3382[2] = (char *(*)()) F780_4133;
	R3382[3] = (char *(*)()) F781_4133;
	R3382[4] = (char *(*)()) F782_4133;
	R3382[5] = (char *(*)()) F783_4133;
	R3382[6] = (char *(*)()) F784_4133;
	R3382[7] = (char *(*)()) F785_4133;
	R3382[8] = (char *(*)()) F786_4133;
	R3382[9] = (char *(*)()) F787_4133;
	R3382[10] = (char *(*)()) F788_4133;
	R3382[11] = (char *(*)()) F789_4133;
	R3382[12] = (char *(*)()) F790_4133;
	R3382[13] = (char *(*)()) F791_4133;
	R3382[14] = (char *(*)()) F792_4133;
	R3382[15] = (char *(*)()) F793_4133;
	R3382[16] = (char *(*)()) F794_4133;
	R3382[17] = (char *(*)()) F795_4133;
	R3382[18] = (char *(*)()) F796_4133;
	R3382[19] = (char *(*)()) F797_4133;
	R3382[20] = (char *(*)()) F798_4133;
	R3382[21] = (char *(*)()) F799_4133;
	R3382[22] = (char *(*)()) F800_4133;
	R3382[23] = (char *(*)()) F801_4133;
	R3382[24] = (char *(*)()) F802_4133;
	R3382[25] = (char *(*)()) F803_4133;
	R3382[26] = (char *(*)()) F804_4133;
	R3382[27] = (char *(*)()) F805_4133;
	R3382[28] = (char *(*)()) F806_4133;
	R3382[29] = (char *(*)()) F807_4133;
	R3382[30] = (char *(*)()) F808_4133;
}

char *(*R3528[2])();
void R3528_init () {
	R3528[0] = (char *(*)()) F811_4349;
	R3528[1] = (char *(*)()) F812_4349;
}

char *(*R3531[2])();
void R3531_init () {
	R3531[0] = (char *(*)()) F811_4352;
	R3531[1] = (char *(*)()) F812_4352;
}

char *(*R3583[2])();
void R3583_init () {
	R3583[0] = (char *(*)()) F814_4447;
	R3583[1] = (char *(*)()) F815_4447;
}

char *(*R3584[2])();
void R3584_init () {
	R3584[0] = (char *(*)()) F814_4448;
	R3584[1] = (char *(*)()) F815_4448;
}

char *(*R3588[2])();
void R3588_init () {
	R3588[0] = (char *(*)()) F814_4452;
	R3588[1] = (char *(*)()) F815_4452;
}

char *(*R3640[2])();
void R3640_init () {
	R3640[0] = (char *(*)()) F817_4547;
	R3640[1] = (char *(*)()) F818_4547;
}

char *(*R3643[2])();
void R3643_init () {
	R3643[0] = (char *(*)()) F817_4550;
	R3643[1] = (char *(*)()) F818_4550;
}

char *(*R3693[2])();
void R3693_init () {
	R3693[0] = (char *(*)()) F820_4643;
	R3693[1] = (char *(*)()) F821_4643;
}

char *(*R3696[2])();
void R3696_init () {
	R3696[0] = (char *(*)()) F820_4646;
	R3696[1] = (char *(*)()) F821_4646;
}

char *(*R3699[2])();
void R3699_init () {
	R3699[0] = (char *(*)()) F820_4649;
	R3699[1] = (char *(*)()) F821_4649;
}

char *(*R3753[2])();
void R3753_init () {
	R3753[0] = (char *(*)()) F823_4743;
	R3753[1] = (char *(*)()) F824_4743;
}

char *(*R3799[2])();
void R3799_init () {
	R3799[0] = (char *(*)()) F826_4831;
	R3799[1] = (char *(*)()) F827_4831;
}

char *(*R3800[2])();
void R3800_init () {
	R3800[0] = (char *(*)()) F826_4832;
	R3800[1] = (char *(*)()) F827_4832;
}

char *(*R3802[2])();
void R3802_init () {
	R3802[0] = (char *(*)()) F826_4834;
	R3802[1] = (char *(*)()) F827_4834;
}

char *(*R3805[2])();
void R3805_init () {
	R3805[0] = (char *(*)()) F826_4837;
	R3805[1] = (char *(*)()) F827_4837;
}

char *(*R3806[2])();
void R3806_init () {
	R3806[0] = (char *(*)()) F826_4838;
	R3806[1] = (char *(*)()) F827_4838;
}

char *(*R3854[2])();
void R3854_init () {
	R3854[0] = (char *(*)()) F829_4928;
	R3854[1] = (char *(*)()) F830_4928;
}

char *(*R3855[2])();
void R3855_init () {
	R3855[0] = (char *(*)()) F829_4929;
	R3855[1] = (char *(*)()) F830_4929;
}

char *(*R3858[2])();
void R3858_init () {
	R3858[0] = (char *(*)()) F829_4932;
	R3858[1] = (char *(*)()) F830_4932;
}

char *(*R3906[2])();
void R3906_init () {
	R3906[0] = (char *(*)()) F832_5022;
	R3906[1] = (char *(*)()) F833_5022;
}

char *(*R3907[2])();
void R3907_init () {
	R3907[0] = (char *(*)()) F832_5023;
	R3907[1] = (char *(*)()) F833_5023;
}

char *(*R3908[2])();
void R3908_init () {
	R3908[0] = (char *(*)()) F832_5024;
	R3908[1] = (char *(*)()) F833_5024;
}

char *(*R3909[2])();
void R3909_init () {
	R3909[0] = (char *(*)()) F832_5025;
	R3909[1] = (char *(*)()) F833_5025;
}

char *(*R3911[2])();
void R3911_init () {
	R3911[0] = (char *(*)()) F832_5027;
	R3911[1] = (char *(*)()) F833_5027;
}

char *(*R3957[2])();
void R3957_init () {
	R3957[0] = (char *(*)()) F835_5085;
	R3957[1] = (char *(*)()) F836_5085;
}

char *(*R3991[2])();
void R3991_init () {
	R3991[0] = (char *(*)()) F838_5151;
	R3991[1] = (char *(*)()) F839_5151;
}

char *(*R4012[2])();
void R4012_init () {
	R4012[0] = (char *(*)()) F841_5209;
	R4012[1] = (char *(*)()) F842_5209;
}

char *(*R4167[286])();
void R4167_init () {
	{long i; for (i = 0; i < 2; i++) R4167[i] = (char *(*)()) F890_5497;}
	{long i; for (i = 3; i < 5; i++) R4167[i] = (char *(*)()) F893_5664;}
	R4167[285] = (char *(*)()) F1176_8617;
}

char *(*R4169[286])();
void R4169_init () {
	R4169[0] = (char *(*)()) F891_5558;
	R4169[1] = (char *(*)()) F892_5581;
	R4169[3] = (char *(*)()) F894_5724;
	R4169[4] = (char *(*)()) F895_5746;
	R4169[285] = (char *(*)()) F1176_8745;
}

char *(*R4170[286])();
void R4170_init () {
	R4170[0] = (char *(*)()) F891_5556;
	R4170[1] = (char *(*)()) F892_5579;
	R4170[3] = (char *(*)()) F894_5723;
	R4170[4] = (char *(*)()) F895_5745;
	R4170[285] = (char *(*)()) F895_5745;
}

char *(*R4206[286])();
void R4206_init () {
	{long i; for (i = 0; i < 2; i++) R4206[i] = (char *(*)()) F890_5518;}
	{long i; for (i = 3; i < 5; i++) R4206[i] = (char *(*)()) F893_5686;}
	R4206[285] = (char *(*)()) F1176_8648;
}

char *(*R4207[286])();
void R4207_init () {
	{long i; for (i = 0; i < 2; i++) R4207[i] = (char *(*)()) F890_5517;}
	{long i; for (i = 3; i < 5; i++) R4207[i] = (char *(*)()) F893_5685;}
	R4207[285] = (char *(*)()) F1176_8650;
}

char *(*R4212[286])();
void R4212_init () {
	{long i; for (i = 0; i < 2; i++) R4212[i] = (char *(*)()) F887_5412;}
	{long i; for (i = 3; i < 5; i++) R4212[i] = (char *(*)()) F887_5412;}
	R4212[285] = (char *(*)()) F1176_8661;
}

char *(*R4228[282])();
void R4228_init () {
	R4228[0] = (char *(*)()) F895_5812;
	R4228[281] = (char *(*)()) F1176_8705;
}

char *(*R4229[282])();
void R4229_init () {
	R4229[0] = (char *(*)()) F895_5813;
	R4229[281] = (char *(*)()) F1176_8706;
}

char *(*R4247[286])();
void R4247_init () {
	R4247[0] = (char *(*)()) F891_5565;
	R4247[1] = (char *(*)()) F892_5659;
	R4247[3] = (char *(*)()) F894_5731;
	R4247[4] = (char *(*)()) F895_5824;
	R4247[285] = (char *(*)()) F1176_8634;
}

char *(*R4262[285])();
void R4262_init () {
	R4262[0] = (char *(*)()) F892_5661;
	R4262[3] = (char *(*)()) F895_5826;
	R4262[284] = (char *(*)()) F895_5826;
}

char *(*R4265[285])();
void R4265_init () {
	R4265[0] = (char *(*)()) F892_5600;
	R4265[3] = (char *(*)()) F895_5765;
	R4265[284] = (char *(*)()) F1176_8747;
}


#ifdef __cplusplus
}
#endif
