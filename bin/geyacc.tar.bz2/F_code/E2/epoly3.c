#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1154[6];
void O1154_init () {
	O1154[0] = 0;
	O1154[1] = + _I64OFF_0_0_0_0_0_0_0_;
	{long i; for (i = 2; i < 4; i++) O1154[i] = + _LNGOFF_0_0_0_0_;}
	O1154[4] = 0;
	O1154[5] = + _LNGOFF_1_0_0_0_;
}

long O1414[4];
void O1414_init () {
	O1414[0] = + _CHROFF_2_0_;
	O1414[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1414[i] = + _CHROFF_2_0_;}
}

long O1415[4];
void O1415_init () {
	O1415[0] = + _CHROFF_2_1_;
	O1415[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1415[i] = + _CHROFF_2_1_;}
}

long O1485[5];
void O1485_init () {
	O1485[0] = + _LNGOFF_0_0_0_0_;
	O1485[1] = + _LNGOFF_4_0_0_0_;
	O1485[4] = + _LNGOFF_6_2_0_0_;
}

long O1500[3];
void O1500_init () {
	O1500[0] = + _CHROFF_2_0_;
	O1500[1] = + _CHROFF_6_0_;
	O1500[2] = + _CHROFF_3_0_;
}

long O1503[3];
void O1503_init () {
	O1503[0] = + _LNGOFF_2_1_0_0_;
	O1503[1] = + _LNGOFF_6_2_0_1_;
	O1503[2] = + _LNGOFF_3_2_0_0_;
}

static EIF_TYPE_INDEX Y1676_pgtype0[] = {0xFF01,89,0xFFFF};
static EIF_TYPE_INDEX Y1676_pgtype1[] = {0xFF01,89,0xFFFF};
static EIF_TYPE_INDEX Y1676_pgtype2[] = {0xFF01,249,0xFFFF};
static EIF_TYPE_INDEX Y1676_pgtype3[] = {0xFF01,89,0xFFFF};
static EIF_TYPE_INDEX Y1676_pgtype4[] = {0xFF01,89,0xFFFF};
static EIF_TYPE_INDEX Y1676_pgtype5[] = {0xFF01,249,0xFFFF};
EIF_TYPE_INDEX *Y1676_gen_type [6];
EIF_TYPE_INDEX Y1676 [6];
void Y1676_init (void)
{
	egc_routines_types [1676] = Y1676;
	egc_routines_gen_types [1676] = Y1676_gen_type;
	egc_routines_offset [1676] = 153;
	Y1676_gen_type [0] = Y1676_pgtype0;
	Y1676_gen_type [1] = Y1676_pgtype1;
	Y1676_gen_type [2] = Y1676_pgtype2;
	Y1676_gen_type [3] = Y1676_pgtype3;
	Y1676_gen_type [4] = Y1676_pgtype4;
	Y1676_gen_type [5] = Y1676_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y1676[i] = 89;};
	Y1676[2] = 249;
	{long i; for (i = 3; i < 5; i++) Y1676[i] = 89;};
	Y1676[5] = 249;
}

long O1677[6];
void O1677_init () {
	{long i; for (i = 0; i < 3; i++) O1677[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O1677[i] = + _LNGOFF_2_4_0_0_;}
	O1677[5] = + _LNGOFF_2_5_0_0_;
}

long O1678[6];
void O1678_init () {
	{long i; for (i = 0; i < 3; i++) O1678[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O1678[i] = + _LNGOFF_2_4_0_1_;}
	O1678[5] = + _LNGOFF_2_5_0_1_;
}

long O1679[6];
void O1679_init () {
	{long i; for (i = 0; i < 3; i++) O1679[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O1679[i] = + _LNGOFF_2_4_0_2_;}
	O1679[5] = + _LNGOFF_2_5_0_2_;
}

long O1680[6];
void O1680_init () {
	{long i; for (i = 0; i < 3; i++) O1680[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O1680[i] = + _LNGOFF_2_4_0_3_;}
	O1680[5] = + _LNGOFF_2_5_0_3_;
}

long O1681[6];
void O1681_init () {
	{long i; for (i = 0; i < 3; i++) O1681[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O1681[i] = + _LNGOFF_2_4_0_4_;}
	O1681[5] = + _LNGOFF_2_5_0_4_;
}

long O1682[6];
void O1682_init () {
	{long i; for (i = 0; i < 3; i++) O1682[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O1682[i] = + _LNGOFF_2_4_0_5_;}
	O1682[5] = + _LNGOFF_2_5_0_5_;
}

long O1683[6];
void O1683_init () {
	{long i; for (i = 0; i < 3; i++) O1683[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O1683[i] = + _CHROFF_2_0_;}
}

long O1688[6];
void O1688_init () {
	{long i; for (i = 0; i < 3; i++) O1688[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O1688[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y2180_pgtype0[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype1[] = {0xFF01,657,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype2[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype3[] = {0xFF01,659,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype4[] = {0xFF01,660,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype5[] = {0xFF01,661,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype6[] = {0xFF01,662,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype7[] = {0xFF01,663,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype8[] = {0xFF01,664,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype9[] = {0xFF01,665,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype10[] = {0xFF01,666,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype11[] = {0xFF01,667,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype12[] = {0xFF01,664,832,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype13[] = {0xFF01,664,832,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype14[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype15[] = {0xFF01,657,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype16[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype17[] = {0xFF01,659,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype18[] = {0xFF01,660,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype19[] = {0xFF01,661,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype20[] = {0xFF01,662,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype21[] = {0xFF01,663,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype22[] = {0xFF01,664,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype23[] = {0xFF01,665,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype24[] = {0xFF01,666,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype25[] = {0xFF01,667,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype26[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype27[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype28[] = {0xFF01,659,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype29[] = {0xFF01,660,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype30[] = {0xFF01,661,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype31[] = {0xFF01,662,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype32[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype33[] = {0xFF01,657,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype34[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype35[] = {0xFF01,659,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype36[] = {0xFF01,660,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype37[] = {0xFF01,661,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype38[] = {0xFF01,662,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype39[] = {0xFF01,663,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype40[] = {0xFF01,664,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype41[] = {0xFF01,665,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype42[] = {0xFF01,666,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype43[] = {0xFF01,667,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype44[] = {0xFF01,663,841,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype45[] = {0xFF01,662,844,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype46[] = {0xFF01,662,844,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype47[] = {0xFF01,662,844,0xFFFF};
static EIF_TYPE_INDEX Y2180_pgtype48[] = {0xFF01,662,844,0xFFFF};
EIF_TYPE_INDEX *Y2180_gen_type [949];
EIF_TYPE_INDEX Y2180 [949];
void Y2180_init (void)
{
	egc_routines_types [2180] = Y2180;
	egc_routines_gen_types [2180] = Y2180_gen_type;
	egc_routines_offset [2180] = 228;
	Y2180_gen_type [0] = Y2180_pgtype0;
	Y2180_gen_type [1] = Y2180_pgtype1;
	Y2180_gen_type [2] = Y2180_pgtype2;
	Y2180_gen_type [3] = Y2180_pgtype3;
	Y2180_gen_type [4] = Y2180_pgtype4;
	Y2180_gen_type [5] = Y2180_pgtype5;
	Y2180_gen_type [6] = Y2180_pgtype6;
	Y2180_gen_type [7] = Y2180_pgtype7;
	Y2180_gen_type [8] = Y2180_pgtype8;
	Y2180_gen_type [9] = Y2180_pgtype9;
	Y2180_gen_type [10] = Y2180_pgtype10;
	Y2180_gen_type [11] = Y2180_pgtype11;
	Y2180_gen_type [17] = Y2180_pgtype12;
	Y2180_gen_type [18] = Y2180_pgtype13;
	Y2180_gen_type [453] = Y2180_pgtype14;
	Y2180_gen_type [454] = Y2180_pgtype15;
	Y2180_gen_type [455] = Y2180_pgtype16;
	Y2180_gen_type [456] = Y2180_pgtype17;
	Y2180_gen_type [457] = Y2180_pgtype18;
	Y2180_gen_type [458] = Y2180_pgtype19;
	Y2180_gen_type [459] = Y2180_pgtype20;
	Y2180_gen_type [460] = Y2180_pgtype21;
	Y2180_gen_type [461] = Y2180_pgtype22;
	Y2180_gen_type [462] = Y2180_pgtype23;
	Y2180_gen_type [463] = Y2180_pgtype24;
	Y2180_gen_type [464] = Y2180_pgtype25;
	Y2180_gen_type [465] = Y2180_pgtype26;
	Y2180_gen_type [466] = Y2180_pgtype27;
	Y2180_gen_type [467] = Y2180_pgtype28;
	Y2180_gen_type [468] = Y2180_pgtype29;
	Y2180_gen_type [469] = Y2180_pgtype30;
	Y2180_gen_type [470] = Y2180_pgtype31;
	Y2180_gen_type [525] = Y2180_pgtype32;
	Y2180_gen_type [526] = Y2180_pgtype33;
	Y2180_gen_type [527] = Y2180_pgtype34;
	Y2180_gen_type [528] = Y2180_pgtype35;
	Y2180_gen_type [529] = Y2180_pgtype36;
	Y2180_gen_type [530] = Y2180_pgtype37;
	Y2180_gen_type [531] = Y2180_pgtype38;
	Y2180_gen_type [532] = Y2180_pgtype39;
	Y2180_gen_type [533] = Y2180_pgtype40;
	Y2180_gen_type [534] = Y2180_pgtype41;
	Y2180_gen_type [535] = Y2180_pgtype42;
	Y2180_gen_type [536] = Y2180_pgtype43;
	Y2180_gen_type [663] = Y2180_pgtype44;
	Y2180_gen_type [666] = Y2180_pgtype45;
	Y2180_gen_type [667] = Y2180_pgtype46;
	Y2180_gen_type [947] = Y2180_pgtype47;
	Y2180_gen_type [948] = Y2180_pgtype48;
	Y2180[0] = 656;
	Y2180[1] = 657;
	Y2180[2] = 658;
	Y2180[3] = 659;
	Y2180[4] = 660;
	Y2180[5] = 661;
	Y2180[6] = 662;
	Y2180[7] = 663;
	Y2180[8] = 664;
	Y2180[9] = 665;
	Y2180[10] = 666;
	Y2180[11] = 667;
	{long i; for (i = 17; i < 19; i++) Y2180[i] = 664;};
	Y2180[453] = 656;
	Y2180[454] = 657;
	Y2180[455] = 658;
	Y2180[456] = 659;
	Y2180[457] = 660;
	Y2180[458] = 661;
	Y2180[459] = 662;
	Y2180[460] = 663;
	Y2180[461] = 664;
	Y2180[462] = 665;
	Y2180[463] = 666;
	Y2180[464] = 667;
	Y2180[465] = 656;
	Y2180[466] = 658;
	Y2180[467] = 659;
	Y2180[468] = 660;
	Y2180[469] = 661;
	Y2180[470] = 662;
	Y2180[525] = 656;
	Y2180[526] = 657;
	Y2180[527] = 658;
	Y2180[528] = 659;
	Y2180[529] = 660;
	Y2180[530] = 661;
	Y2180[531] = 662;
	Y2180[532] = 663;
	Y2180[533] = 664;
	Y2180[534] = 665;
	Y2180[535] = 666;
	Y2180[536] = 667;
	Y2180[663] = 663;
	{long i; for (i = 666; i < 668; i++) Y2180[i] = 662;};
	{long i; for (i = 947; i < 949; i++) Y2180[i] = 662;};
}

long O2426[717];
void O2426_init () {
	O2426[0] = + _CHROFF_1_0_;
	O2426[389] = + _CHROFF_3_0_;
	O2426[390] = + _CHROFF_4_0_;
	O2426[391] = + _CHROFF_5_0_;
	O2426[689] = + _CHROFF_5_0_;
	O2426[708] = + _CHROFF_6_0_;
	{long i; for (i = 709; i < 712; i++) O2426[i] = + _CHROFF_5_0_;}
	O2426[713] = + _CHROFF_7_1_;
	{long i; for (i = 714; i < 717; i++) O2426[i] = + _CHROFF_6_1_;}
}

long O2427[717];
void O2427_init () {
	O2427[0] = 0;
	{long i; for (i = 389; i < 392; i++) O2427[i] = 0;}
	O2427[689] = 0;
	{long i; for (i = 708; i < 712; i++) O2427[i] = 0;}
	O2427[713] =  + _REFACS_6_;
	{long i; for (i = 714; i < 717; i++) O2427[i] =  + _REFACS_5_;}
}

long O2734[741];
void O2734_init () {
	{long i; for (i = 0; i < 205; i++) O2734[i] = + _CHROFF_0_0_;}
	O2734[205] = + _CHROFF_3_2_;
	O2734[206] = + _CHROFF_4_2_;
	O2734[207] = + _CHROFF_5_2_;
	{long i; for (i = 232; i < 245; i++) O2734[i] = + _CHROFF_0_0_;}
	{long i; for (i = 245; i < 263; i++) O2734[i] = + _CHROFF_1_0_;}
	{long i; for (i = 263; i < 311; i++) O2734[i] = + _CHROFF_0_0_;}
	{long i; for (i = 311; i < 313; i++) O2734[i] = + _CHROFF_2_0_;}
	{long i; for (i = 316; i < 329; i++) O2734[i] = + _CHROFF_1_0_;}
	O2734[329] = + _CHROFF_7_0_;
	{long i; for (i = 330; i < 332; i++) O2734[i] = + _CHROFF_5_0_;}
	O2734[332] = + _CHROFF_6_0_;
	O2734[333] = + _CHROFF_4_0_;
	O2734[334] = + _CHROFF_7_0_;
	O2734[335] = + _CHROFF_5_0_;
	O2734[336] = + _CHROFF_9_0_;
	O2734[455] = + _CHROFF_1_0_;
	{long i; for (i = 458; i < 460; i++) O2734[i] = + _CHROFF_1_0_;}
	O2734[505] = + _CHROFF_5_2_;
	O2734[524] = + _CHROFF_6_2_;
	{long i; for (i = 525; i < 528; i++) O2734[i] = + _CHROFF_5_2_;}
	O2734[529] = + _CHROFF_7_2_;
	{long i; for (i = 530; i < 533; i++) O2734[i] = + _CHROFF_6_2_;}
	{long i; for (i = 739; i < 741; i++) O2734[i] = + _CHROFF_1_0_;}
}

long O2823[328];
void O2823_init () {
	O2823[0] = + _PTROFF_3_6_2_4_1_0_;
	O2823[1] = + _PTROFF_4_6_2_4_1_0_;
	O2823[2] = + _PTROFF_5_7_2_4_1_0_;
	O2823[300] = + _PTROFF_5_7_2_4_1_0_;
	O2823[319] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 320; i < 323; i++) O2823[i] = + _PTROFF_5_6_2_4_1_0_;}
	O2823[324] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 325; i < 328; i++) O2823[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O2906[328];
void O2906_init () {
	{long i; for (i = 0; i < 3; i++) O2906[i] =  + _REFACS_1_;}
	O2906[300] =  + _REFACS_1_;
	{long i; for (i = 319; i < 323; i++) O2906[i] =  + _REFACS_1_;}
	{long i; for (i = 324; i < 328; i++) O2906[i] = 0;}
}

long O2908[328];
void O2908_init () {
	{long i; for (i = 0; i < 3; i++) O2908[i] =  + _REFACS_2_;}
	O2908[300] =  + _REFACS_2_;
	{long i; for (i = 319; i < 323; i++) O2908[i] =  + _REFACS_2_;}
	{long i; for (i = 324; i < 328; i++) O2908[i] =  + _REFACS_1_;}
}

long O2962[328];
void O2962_init () {
	O2962[0] = + _LNGOFF_3_6_2_3_;
	O2962[1] = + _LNGOFF_4_6_2_3_;
	O2962[2] = + _LNGOFF_5_7_2_3_;
	O2962[300] = + _LNGOFF_5_7_2_3_;
	O2962[319] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 320; i < 323; i++) O2962[i] = + _LNGOFF_5_6_2_3_;}
	O2962[324] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 325; i < 328; i++) O2962[i] = + _LNGOFF_6_7_2_3_;}
}

long O2971[328];
void O2971_init () {
	O2971[0] = + _CHROFF_3_3_;
	O2971[1] = + _CHROFF_4_3_;
	O2971[2] = + _CHROFF_5_3_;
	O2971[300] = + _CHROFF_5_3_;
	O2971[319] = + _CHROFF_6_3_;
	{long i; for (i = 320; i < 323; i++) O2971[i] = + _CHROFF_5_3_;}
	O2971[324] = + _CHROFF_7_3_;
	{long i; for (i = 325; i < 328; i++) O2971[i] = + _CHROFF_6_3_;}
}

long O2985[323];
void O2985_init () {
	O2985[0] =  + _REFACS_3_;
	O2985[298] =  + _REFACS_3_;
	O2985[317] =  + _REFACS_3_;
	O2985[322] =  + _REFACS_2_;
}

EIF_TYPE_INDEX *Y3170_gen_type [1];
EIF_TYPE_INDEX Y3170 [1];
void Y3170_init (void)
{
	egc_routines_types [3170] = Y3170;
	egc_routines_gen_types [3170] = Y3170_gen_type;
	egc_routines_offset [3170] = 752;
	Y3170[0] = 814;
}

long O3190[8];
void O3190_init () {
	O3190[0] = 0;
	O3190[1] = + _PTROFF_5_3_0_7_0_0_;
	O3190[2] = + _LNGOFF_5_3_0_0_;
	O3190[3] = 0;
	O3190[4] = + _LNGOFF_4_3_0_0_;
	O3190[5] = 0;
	O3190[6] = + _LNGOFF_5_4_0_0_;
	O3190[7] = 0;
}

long O3199[8];
void O3199_init () {
	O3199[0] = + _LNGOFF_7_3_0_0_;
	O3199[1] = + _LNGOFF_5_3_0_0_;
	O3199[2] = + _LNGOFF_5_3_0_1_;
	O3199[3] = + _LNGOFF_6_3_0_0_;
	O3199[4] = + _LNGOFF_4_3_0_1_;
	O3199[5] = + _LNGOFF_7_4_0_0_;
	O3199[6] = + _LNGOFF_5_4_0_1_;
	O3199[7] = + _LNGOFF_9_3_0_0_;
}

long O3226[8];
void O3226_init () {
	O3226[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3226[i] = 0;}
	O3226[3] =  + _REFACS_1_;
	O3226[4] = 0;
	O3226[5] =  + _REFACS_1_;
	O3226[6] = 0;
	O3226[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3226_pgtype0[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype1[] = {0xFF01,657,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype2[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype3[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype4[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype5[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype6[] = {0xFF01,658,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3226_pgtype7[] = {0xFF01,656,0,0xFFFF};
EIF_TYPE_INDEX *Y3226_gen_type [8];
EIF_TYPE_INDEX Y3226 [8];
void Y3226_init (void)
{
	egc_routines_types [3226] = Y3226;
	egc_routines_gen_types [3226] = Y3226_gen_type;
	egc_routines_offset [3226] = 765;
	Y3226_gen_type [0] = Y3226_pgtype0;
	Y3226_gen_type [1] = Y3226_pgtype1;
	Y3226_gen_type [2] = Y3226_pgtype2;
	Y3226_gen_type [3] = Y3226_pgtype3;
	Y3226_gen_type [4] = Y3226_pgtype4;
	Y3226_gen_type [5] = Y3226_pgtype5;
	Y3226_gen_type [6] = Y3226_pgtype6;
	Y3226_gen_type [7] = Y3226_pgtype7;
	Y3226[0] = 656;
	Y3226[1] = 657;
	Y3226[2] = 658;
	Y3226[3] = 656;
	Y3226[4] = 658;
	Y3226[5] = 656;
	Y3226[6] = 658;
	Y3226[7] = 656;
}

long O3227[8];
void O3227_init () {
	O3227[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O3227[i] =  + _REFACS_1_;}
	O3227[3] =  + _REFACS_2_;
	O3227[4] =  + _REFACS_1_;
	O3227[5] =  + _REFACS_2_;
	O3227[6] =  + _REFACS_1_;
	O3227[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3227_pgtype0[] = {0xFF01,656,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype1[] = {0xFF01,656,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype2[] = {0xFF01,656,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype3[] = {0xFF01,658,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype4[] = {0xFF01,658,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype5[] = {0xFF01,656,0xFF01,886,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype6[] = {0xFF01,656,0xFF01,886,0xFFFF};
static EIF_TYPE_INDEX Y3227_pgtype7[] = {0xFF01,656,0xFF01,894,0xFFFF};
EIF_TYPE_INDEX *Y3227_gen_type [8];
EIF_TYPE_INDEX Y3227 [8];
void Y3227_init (void)
{
	egc_routines_types [3227] = Y3227;
	egc_routines_gen_types [3227] = Y3227_gen_type;
	egc_routines_offset [3227] = 765;
	Y3227_gen_type [0] = Y3227_pgtype0;
	Y3227_gen_type [1] = Y3227_pgtype1;
	Y3227_gen_type [2] = Y3227_pgtype2;
	Y3227_gen_type [3] = Y3227_pgtype3;
	Y3227_gen_type [4] = Y3227_pgtype4;
	Y3227_gen_type [5] = Y3227_pgtype5;
	Y3227_gen_type [6] = Y3227_pgtype6;
	Y3227_gen_type [7] = Y3227_pgtype7;
	{long i; for (i = 0; i < 3; i++) Y3227[i] = 656;};
	{long i; for (i = 3; i < 5; i++) Y3227[i] = 658;};
	{long i; for (i = 5; i < 8; i++) Y3227[i] = 656;};
}

long O3228[8];
void O3228_init () {
	O3228[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O3228[i] =  + _REFACS_2_;}
	O3228[3] =  + _REFACS_3_;
	O3228[4] =  + _REFACS_2_;
	O3228[5] =  + _REFACS_3_;
	O3228[6] =  + _REFACS_2_;
	O3228[7] =  + _REFACS_3_;
}

long O3229[8];
void O3229_init () {
	O3229[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O3229[i] =  + _REFACS_3_;}
	O3229[3] =  + _REFACS_4_;
	O3229[4] =  + _REFACS_3_;
	O3229[5] =  + _REFACS_4_;
	O3229[6] =  + _REFACS_3_;
	O3229[7] =  + _REFACS_4_;
}

long O3230[8];
void O3230_init () {
	O3230[0] = + _LNGOFF_7_3_0_1_;
	O3230[1] = + _LNGOFF_5_3_0_1_;
	O3230[2] = + _LNGOFF_5_3_0_2_;
	O3230[3] = + _LNGOFF_6_3_0_1_;
	O3230[4] = + _LNGOFF_4_3_0_2_;
	O3230[5] = + _LNGOFF_7_4_0_1_;
	O3230[6] = + _LNGOFF_5_4_0_2_;
	O3230[7] = + _LNGOFF_9_3_0_1_;
}

long O3231[8];
void O3231_init () {
	O3231[0] = + _CHROFF_7_2_;
	{long i; for (i = 1; i < 3; i++) O3231[i] = + _CHROFF_5_2_;}
	O3231[3] = + _CHROFF_6_2_;
	O3231[4] = + _CHROFF_4_2_;
	O3231[5] = + _CHROFF_7_2_;
	O3231[6] = + _CHROFF_5_2_;
	O3231[7] = + _CHROFF_9_2_;
}

long O3232[8];
void O3232_init () {
	O3232[0] = + _LNGOFF_7_3_0_2_;
	O3232[1] = + _LNGOFF_5_3_0_2_;
	O3232[2] = + _LNGOFF_5_3_0_3_;
	O3232[3] = + _LNGOFF_6_3_0_2_;
	O3232[4] = + _LNGOFF_4_3_0_3_;
	O3232[5] = + _LNGOFF_7_4_0_2_;
	O3232[6] = + _LNGOFF_5_4_0_3_;
	O3232[7] = + _LNGOFF_9_3_0_2_;
}

long O3235[8];
void O3235_init () {
	O3235[0] = + _LNGOFF_7_3_0_3_;
	O3235[1] = + _LNGOFF_5_3_0_3_;
	O3235[2] = + _LNGOFF_5_3_0_4_;
	O3235[3] = + _LNGOFF_6_3_0_3_;
	O3235[4] = + _LNGOFF_4_3_0_4_;
	O3235[5] = + _LNGOFF_7_4_0_3_;
	O3235[6] = + _LNGOFF_5_4_0_4_;
	O3235[7] = + _LNGOFF_9_3_0_3_;
}

long O3236[8];
void O3236_init () {
	O3236[0] = + _LNGOFF_7_3_0_4_;
	O3236[1] = + _LNGOFF_5_3_0_4_;
	O3236[2] = + _LNGOFF_5_3_0_5_;
	O3236[3] = + _LNGOFF_6_3_0_4_;
	O3236[4] = + _LNGOFF_4_3_0_5_;
	O3236[5] = + _LNGOFF_7_4_0_4_;
	O3236[6] = + _LNGOFF_5_4_0_5_;
	O3236[7] = + _LNGOFF_9_3_0_4_;
}

long O3240[8];
void O3240_init () {
	O3240[0] = + _LNGOFF_7_3_0_5_;
	O3240[1] = + _LNGOFF_5_3_0_5_;
	O3240[2] = + _LNGOFF_5_3_0_6_;
	O3240[3] = + _LNGOFF_6_3_0_5_;
	O3240[4] = + _LNGOFF_4_3_0_6_;
	O3240[5] = + _LNGOFF_7_4_0_5_;
	O3240[6] = + _LNGOFF_5_4_0_6_;
	O3240[7] = + _LNGOFF_9_3_0_5_;
}

long O3241[8];
void O3241_init () {
	O3241[0] =  + _REFACS_5_;
	O3241[1] = + _PTROFF_5_3_0_7_0_1_;
	O3241[2] = + _LNGOFF_5_3_0_7_;
	O3241[3] =  + _REFACS_5_;
	O3241[4] = + _LNGOFF_4_3_0_7_;
	O3241[5] =  + _REFACS_5_;
	O3241[6] = + _LNGOFF_5_4_0_7_;
	O3241[7] =  + _REFACS_5_;
}

long O3242[8];
void O3242_init () {
	O3242[0] =  + _REFACS_6_;
	{long i; for (i = 1; i < 3; i++) O3242[i] =  + _REFACS_4_;}
	O3242[3] = + _LNGOFF_6_3_0_6_;
	O3242[4] = + _LNGOFF_4_3_0_8_;
	O3242[5] =  + _REFACS_6_;
	O3242[6] =  + _REFACS_4_;
	O3242[7] =  + _REFACS_6_;
}

long O3276[8];
void O3276_init () {
	O3276[0] = + _LNGOFF_7_3_0_6_;
	O3276[1] = + _LNGOFF_5_3_0_6_;
	O3276[2] = + _LNGOFF_5_3_0_8_;
	O3276[3] = + _LNGOFF_6_3_0_7_;
	O3276[4] = + _LNGOFF_4_3_0_9_;
	O3276[5] = + _LNGOFF_7_4_0_6_;
	O3276[6] = + _LNGOFF_5_4_0_8_;
	O3276[7] = + _LNGOFF_9_3_0_6_;
}

long O4259[291];
void O4259_init () {
	{long i; for (i = 0; i < 3; i++) O4259[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O4259[i] = + _LNGOFF_1_0_0_0_;}
	O4259[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O4259[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O4259[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 289; i < 291; i++) O4259[i] = + _LNGOFF_1_1_0_0_;}
}

long O4260[291];
void O4260_init () {
	{long i; for (i = 0; i < 3; i++) O4260[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O4260[i] = + _LNGOFF_1_0_0_1_;}
	O4260[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O4260[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O4260[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 289; i < 291; i++) O4260[i] = + _LNGOFF_1_1_0_1_;}
}

long O4325[3];
void O4325_init () {
	{long i; for (i = 0; i < 2; i++) O4325[i] = + _LNGOFF_1_0_0_2_;}
	O4325[2] = + _LNGOFF_1_1_0_2_;
}

long O4405[285];
void O4405_init () {
	{long i; for (i = 0; i < 2; i++) O4405[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4405[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 283; i < 285; i++) O4405[i] = + _LNGOFF_1_1_0_2_;}
}

long O5150[11];
void O5150_init () {
	{long i; for (i = 0; i < 2; i++) O5150[i] = 0;}
	O5150[2] =  + _REFACS_5_;
	{long i; for (i = 3; i < 6; i++) O5150[i] =  + _REFACS_4_;}
	O5150[6] = 0;
	O5150[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 11; i++) O5150[i] =  + _REFACS_3_;}
}

static EIF_TYPE_INDEX Y5297_pgtype0[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype1[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype2[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype3[] = {214,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype4[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype5[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype6[] = {214,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype7[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype8[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype9[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype10[] = {214,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype11[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype12[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype13[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype14[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype15[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype16[] = {214,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype17[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype18[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype19[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype20[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype21[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype22[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype23[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype24[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype25[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype26[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype27[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype28[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype29[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype30[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype31[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype32[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype33[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype34[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype35[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype36[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype37[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype38[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype39[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype40[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype41[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype42[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype43[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype44[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype45[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype46[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype47[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype48[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype49[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype50[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype51[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype52[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype53[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype54[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype55[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype56[] = {213,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype57[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype58[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype59[] = {211,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype60[] = {212,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5297_pgtype61[] = {213,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5297_gen_type [65];
EIF_TYPE_INDEX Y5297 [65];
void Y5297_init (void)
{
	egc_routines_types [5297] = Y5297;
	egc_routines_gen_types [5297] = Y5297_gen_type;
	egc_routines_offset [5297] = 1044;
	Y5297_gen_type [0] = Y5297_pgtype0;
	Y5297_gen_type [1] = Y5297_pgtype1;
	Y5297_gen_type [2] = Y5297_pgtype2;
	Y5297_gen_type [3] = Y5297_pgtype3;
	Y5297_gen_type [4] = Y5297_pgtype4;
	Y5297_gen_type [5] = Y5297_pgtype5;
	Y5297_gen_type [6] = Y5297_pgtype6;
	Y5297_gen_type [7] = Y5297_pgtype7;
	Y5297_gen_type [8] = Y5297_pgtype8;
	Y5297_gen_type [9] = Y5297_pgtype9;
	Y5297_gen_type [10] = Y5297_pgtype10;
	Y5297_gen_type [11] = Y5297_pgtype11;
	Y5297_gen_type [12] = Y5297_pgtype12;
	Y5297_gen_type [13] = Y5297_pgtype13;
	Y5297_gen_type [14] = Y5297_pgtype14;
	Y5297_gen_type [15] = Y5297_pgtype15;
	Y5297_gen_type [16] = Y5297_pgtype16;
	Y5297_gen_type [17] = Y5297_pgtype17;
	Y5297_gen_type [18] = Y5297_pgtype18;
	Y5297_gen_type [19] = Y5297_pgtype19;
	Y5297_gen_type [20] = Y5297_pgtype20;
	Y5297_gen_type [21] = Y5297_pgtype21;
	Y5297_gen_type [22] = Y5297_pgtype22;
	Y5297_gen_type [23] = Y5297_pgtype23;
	Y5297_gen_type [24] = Y5297_pgtype24;
	Y5297_gen_type [25] = Y5297_pgtype25;
	Y5297_gen_type [26] = Y5297_pgtype26;
	Y5297_gen_type [27] = Y5297_pgtype27;
	Y5297_gen_type [28] = Y5297_pgtype28;
	Y5297_gen_type [29] = Y5297_pgtype29;
	Y5297_gen_type [30] = Y5297_pgtype30;
	Y5297_gen_type [31] = Y5297_pgtype31;
	Y5297_gen_type [32] = Y5297_pgtype32;
	Y5297_gen_type [36] = Y5297_pgtype33;
	Y5297_gen_type [37] = Y5297_pgtype34;
	Y5297_gen_type [38] = Y5297_pgtype35;
	Y5297_gen_type [39] = Y5297_pgtype36;
	Y5297_gen_type [40] = Y5297_pgtype37;
	Y5297_gen_type [41] = Y5297_pgtype38;
	Y5297_gen_type [42] = Y5297_pgtype39;
	Y5297_gen_type [43] = Y5297_pgtype40;
	Y5297_gen_type [44] = Y5297_pgtype41;
	Y5297_gen_type [45] = Y5297_pgtype42;
	Y5297_gen_type [46] = Y5297_pgtype43;
	Y5297_gen_type [47] = Y5297_pgtype44;
	Y5297_gen_type [48] = Y5297_pgtype45;
	Y5297_gen_type [49] = Y5297_pgtype46;
	Y5297_gen_type [50] = Y5297_pgtype47;
	Y5297_gen_type [51] = Y5297_pgtype48;
	Y5297_gen_type [52] = Y5297_pgtype49;
	Y5297_gen_type [53] = Y5297_pgtype50;
	Y5297_gen_type [54] = Y5297_pgtype51;
	Y5297_gen_type [55] = Y5297_pgtype52;
	Y5297_gen_type [56] = Y5297_pgtype53;
	Y5297_gen_type [57] = Y5297_pgtype54;
	Y5297_gen_type [58] = Y5297_pgtype55;
	Y5297_gen_type [59] = Y5297_pgtype56;
	Y5297_gen_type [60] = Y5297_pgtype57;
	Y5297_gen_type [61] = Y5297_pgtype58;
	Y5297_gen_type [62] = Y5297_pgtype59;
	Y5297_gen_type [63] = Y5297_pgtype60;
	Y5297_gen_type [64] = Y5297_pgtype61;
	Y5297[0] = 211;
	Y5297[1] = 212;
	Y5297[2] = 213;
	Y5297[3] = 214;
	Y5297[4] = 211;
	Y5297[5] = 212;
	Y5297[6] = 214;
	Y5297[7] = 213;
	Y5297[8] = 211;
	Y5297[9] = 212;
	Y5297[10] = 214;
	Y5297[11] = 213;
	{long i; for (i = 12; i < 14; i++) Y5297[i] = 211;};
	{long i; for (i = 14; i < 16; i++) Y5297[i] = 212;};
	Y5297[16] = 214;
	Y5297[17] = 211;
	Y5297[18] = 212;
	Y5297[19] = 211;
	Y5297[20] = 212;
	Y5297[21] = 213;
	Y5297[22] = 211;
	Y5297[23] = 212;
	Y5297[24] = 211;
	Y5297[25] = 212;
	{long i; for (i = 26; i < 29; i++) Y5297[i] = 211;};
	Y5297[29] = 212;
	Y5297[30] = 211;
	Y5297[31] = 212;
	Y5297[32] = 211;
	{long i; for (i = 36; i < 38; i++) Y5297[i] = 211;};
	Y5297[38] = 212;
	Y5297[39] = 211;
	Y5297[40] = 212;
	Y5297[41] = 211;
	Y5297[42] = 212;
	Y5297[43] = 213;
	Y5297[44] = 211;
	Y5297[45] = 212;
	Y5297[46] = 211;
	Y5297[47] = 212;
	Y5297[48] = 211;
	Y5297[49] = 212;
	Y5297[50] = 211;
	Y5297[51] = 212;
	Y5297[52] = 211;
	Y5297[53] = 212;
	Y5297[54] = 213;
	Y5297[55] = 211;
	Y5297[56] = 212;
	Y5297[57] = 211;
	Y5297[58] = 212;
	Y5297[59] = 213;
	Y5297[60] = 211;
	Y5297[61] = 212;
	Y5297[62] = 211;
	Y5297[63] = 212;
	Y5297[64] = 213;
}

static EIF_TYPE_INDEX Y5330_pgtype0[] = {0xFF01,1094,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5330_pgtype1[] = {0xFF01,1095,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5330_pgtype2[] = {0xFF01,1096,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5330_pgtype3[] = {0xFF01,1097,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5330_pgtype4[] = {0xFF01,1098,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5330_gen_type [5];
EIF_TYPE_INDEX Y5330 [5];
void Y5330_init (void)
{
	egc_routines_types [5330] = Y5330;
	egc_routines_gen_types [5330] = Y5330_gen_type;
	egc_routines_offset [5330] = 1056;
	Y5330_gen_type [0] = Y5330_pgtype0;
	Y5330_gen_type [1] = Y5330_pgtype1;
	Y5330_gen_type [2] = Y5330_pgtype2;
	Y5330_gen_type [3] = Y5330_pgtype3;
	Y5330_gen_type [4] = Y5330_pgtype4;
	Y5330[0] = 1094;
	Y5330[1] = 1095;
	Y5330[2] = 1096;
	Y5330[3] = 1097;
	Y5330[4] = 1098;
}

long O5474[26];
void O5474_init () {
	{long i; for (i = 0; i < 7; i++) O5474[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 7; i < 9; i++) O5474[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 9; i < 11; i++) O5474[i] = + _LNGOFF_7_0_0_0_;}
	{long i; for (i = 11; i < 16; i++) O5474[i] = + _LNGOFF_4_0_0_0_;}
	{long i; for (i = 16; i < 21; i++) O5474[i] = + _LNGOFF_10_0_0_0_;}
	{long i; for (i = 21; i < 26; i++) O5474[i] = + _LNGOFF_11_0_0_0_;}
}

long O5509[26];
void O5509_init () {
	{long i; for (i = 0; i < 7; i++) O5509[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 7; i < 9; i++) O5509[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 9; i < 11; i++) O5509[i] = + _LNGOFF_7_0_0_1_;}
	{long i; for (i = 11; i < 16; i++) O5509[i] = + _LNGOFF_4_0_0_1_;}
	{long i; for (i = 16; i < 21; i++) O5509[i] = + _LNGOFF_10_0_0_1_;}
	{long i; for (i = 21; i < 26; i++) O5509[i] = + _LNGOFF_11_0_0_1_;}
}

long O5510[26];
void O5510_init () {
	{long i; for (i = 0; i < 7; i++) O5510[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 7; i < 9; i++) O5510[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 9; i < 11; i++) O5510[i] = + _LNGOFF_7_0_0_2_;}
	{long i; for (i = 11; i < 16; i++) O5510[i] = + _LNGOFF_4_0_0_2_;}
	{long i; for (i = 16; i < 21; i++) O5510[i] = + _LNGOFF_10_0_0_2_;}
	{long i; for (i = 21; i < 26; i++) O5510[i] = + _LNGOFF_11_0_0_2_;}
}

long O5511[26];
void O5511_init () {
	{long i; for (i = 0; i < 7; i++) O5511[i] = + _LNGOFF_2_0_0_3_;}
	{long i; for (i = 7; i < 9; i++) O5511[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 9; i < 11; i++) O5511[i] = + _LNGOFF_7_0_0_3_;}
	{long i; for (i = 11; i < 16; i++) O5511[i] = + _LNGOFF_4_0_0_3_;}
	{long i; for (i = 16; i < 21; i++) O5511[i] = + _LNGOFF_10_0_0_3_;}
	{long i; for (i = 21; i < 26; i++) O5511[i] = + _LNGOFF_11_0_0_3_;}
}

long O5512[26];
void O5512_init () {
	{long i; for (i = 0; i < 7; i++) O5512[i] = + _LNGOFF_2_0_0_4_;}
	{long i; for (i = 7; i < 9; i++) O5512[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 9; i < 11; i++) O5512[i] = + _LNGOFF_7_0_0_4_;}
	{long i; for (i = 11; i < 16; i++) O5512[i] = + _LNGOFF_4_0_0_4_;}
	{long i; for (i = 16; i < 21; i++) O5512[i] = + _LNGOFF_10_0_0_4_;}
	{long i; for (i = 21; i < 26; i++) O5512[i] = + _LNGOFF_11_0_0_4_;}
}

long O5513[26];
void O5513_init () {
	{long i; for (i = 0; i < 7; i++) O5513[i] = + _LNGOFF_2_0_0_5_;}
	{long i; for (i = 7; i < 9; i++) O5513[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 9; i < 11; i++) O5513[i] = + _LNGOFF_7_0_0_5_;}
	{long i; for (i = 11; i < 16; i++) O5513[i] = + _LNGOFF_4_0_0_5_;}
	{long i; for (i = 16; i < 21; i++) O5513[i] = + _LNGOFF_10_0_0_5_;}
	{long i; for (i = 21; i < 26; i++) O5513[i] = + _LNGOFF_11_0_0_5_;}
}

long O5514[26];
void O5514_init () {
	{long i; for (i = 0; i < 7; i++) O5514[i] = + _LNGOFF_2_0_0_6_;}
	{long i; for (i = 7; i < 9; i++) O5514[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 9; i < 11; i++) O5514[i] = + _LNGOFF_7_0_0_6_;}
	{long i; for (i = 11; i < 16; i++) O5514[i] = + _LNGOFF_4_0_0_6_;}
	{long i; for (i = 16; i < 21; i++) O5514[i] = + _LNGOFF_10_0_0_6_;}
	{long i; for (i = 21; i < 26; i++) O5514[i] = + _LNGOFF_11_0_0_6_;}
}

long O5524[26];
void O5524_init () {
	{long i; for (i = 0; i < 7; i++) O5524[i] = + _LNGOFF_2_0_0_7_;}
	{long i; for (i = 7; i < 9; i++) O5524[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 9; i < 11; i++) O5524[i] = + _LNGOFF_7_0_0_7_;}
	{long i; for (i = 11; i < 16; i++) O5524[i] = + _LNGOFF_4_0_0_7_;}
	{long i; for (i = 16; i < 21; i++) O5524[i] = + _LNGOFF_10_0_0_7_;}
	{long i; for (i = 21; i < 26; i++) O5524[i] = + _LNGOFF_11_0_0_7_;}
}

long O5525[26];
void O5525_init () {
	{long i; for (i = 0; i < 7; i++) O5525[i] = + _LNGOFF_2_0_0_8_;}
	{long i; for (i = 7; i < 9; i++) O5525[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 9; i < 11; i++) O5525[i] = + _LNGOFF_7_0_0_8_;}
	{long i; for (i = 11; i < 16; i++) O5525[i] = + _LNGOFF_4_0_0_8_;}
	{long i; for (i = 16; i < 21; i++) O5525[i] = + _LNGOFF_10_0_0_8_;}
	{long i; for (i = 21; i < 26; i++) O5525[i] = + _LNGOFF_11_0_0_8_;}
}

static EIF_TYPE_INDEX Y5531_pgtype0[] = {0xFF01,20,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5531_pgtype1[] = {0xFF01,21,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5531_pgtype2[] = {0xFF01,20,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5531_pgtype3[] = {0xFF01,21,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5531_gen_type [4];
EIF_TYPE_INDEX Y5531 [4];
void Y5531_init (void)
{
	egc_routines_types [5531] = Y5531;
	egc_routines_gen_types [5531] = Y5531_gen_type;
	egc_routines_offset [5531] = 1090;
	Y5531_gen_type [0] = Y5531_pgtype0;
	Y5531_gen_type [1] = Y5531_pgtype1;
	Y5531_gen_type [2] = Y5531_pgtype2;
	Y5531_gen_type [3] = Y5531_pgtype3;
	Y5531[0] = 20;
	Y5531[1] = 21;
	Y5531[2] = 20;
	Y5531[3] = 21;
}

static EIF_TYPE_INDEX Y5555_pgtype0[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype1[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype2[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype3[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype4[] = {214,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype5[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype6[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype7[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype8[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype9[] = {214,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype10[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype11[] = {211,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype12[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype13[] = {212,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5555_pgtype14[] = {214,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5555_gen_type [15];
EIF_TYPE_INDEX Y5555 [15];
void Y5555_init (void)
{
	egc_routines_types [5555] = Y5555;
	egc_routines_gen_types [5555] = Y5555_gen_type;
	egc_routines_offset [5555] = 1094;
	Y5555_gen_type [0] = Y5555_pgtype0;
	Y5555_gen_type [1] = Y5555_pgtype1;
	Y5555_gen_type [2] = Y5555_pgtype2;
	Y5555_gen_type [3] = Y5555_pgtype3;
	Y5555_gen_type [4] = Y5555_pgtype4;
	Y5555_gen_type [5] = Y5555_pgtype5;
	Y5555_gen_type [6] = Y5555_pgtype6;
	Y5555_gen_type [7] = Y5555_pgtype7;
	Y5555_gen_type [8] = Y5555_pgtype8;
	Y5555_gen_type [9] = Y5555_pgtype9;
	Y5555_gen_type [10] = Y5555_pgtype10;
	Y5555_gen_type [11] = Y5555_pgtype11;
	Y5555_gen_type [12] = Y5555_pgtype12;
	Y5555_gen_type [13] = Y5555_pgtype13;
	Y5555_gen_type [14] = Y5555_pgtype14;
	{long i; for (i = 0; i < 2; i++) Y5555[i] = 211;};
	{long i; for (i = 2; i < 4; i++) Y5555[i] = 212;};
	Y5555[4] = 214;
	{long i; for (i = 5; i < 7; i++) Y5555[i] = 211;};
	{long i; for (i = 7; i < 9; i++) Y5555[i] = 212;};
	Y5555[9] = 214;
	{long i; for (i = 10; i < 12; i++) Y5555[i] = 211;};
	{long i; for (i = 12; i < 14; i++) Y5555[i] = 212;};
	Y5555[14] = 214;
}

static EIF_TYPE_INDEX Y5561_pgtype0[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype1[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype2[] = {0xFF01,21,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype3[] = {0xFF01,21,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype4[] = {0xFF01,23,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype5[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype6[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype7[] = {0xFF01,21,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype8[] = {0xFF01,21,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5561_pgtype9[] = {0xFF01,23,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5561_gen_type [10];
EIF_TYPE_INDEX Y5561 [10];
void Y5561_init (void)
{
	egc_routines_types [5561] = Y5561;
	egc_routines_gen_types [5561] = Y5561_gen_type;
	egc_routines_offset [5561] = 1099;
	Y5561_gen_type [0] = Y5561_pgtype0;
	Y5561_gen_type [1] = Y5561_pgtype1;
	Y5561_gen_type [2] = Y5561_pgtype2;
	Y5561_gen_type [3] = Y5561_pgtype3;
	Y5561_gen_type [4] = Y5561_pgtype4;
	Y5561_gen_type [5] = Y5561_pgtype5;
	Y5561_gen_type [6] = Y5561_pgtype6;
	Y5561_gen_type [7] = Y5561_pgtype7;
	Y5561_gen_type [8] = Y5561_pgtype8;
	Y5561_gen_type [9] = Y5561_pgtype9;
	{long i; for (i = 0; i < 2; i++) Y5561[i] = 20;};
	{long i; for (i = 2; i < 4; i++) Y5561[i] = 21;};
	Y5561[4] = 23;
	{long i; for (i = 5; i < 7; i++) Y5561[i] = 20;};
	{long i; for (i = 7; i < 9; i++) Y5561[i] = 21;};
	Y5561[9] = 23;
}


#ifdef __cplusplus
}
#endif
