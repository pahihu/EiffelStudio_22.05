#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4266[285])();
void R4266_init () {
	R4266[0] = (char *(*)()) F889_5467;
	R4266[3] = (char *(*)()) F889_5467;
	R4266[284] = (char *(*)()) F1176_8748;
}

char *(*R4294[282])();
void R4294_init () {
	R4294[0] = (char *(*)()) F895_5806;
	R4294[281] = (char *(*)()) F1176_8741;
}

char *(*R4295[285])();
void R4295_init () {
	R4295[0] = (char *(*)()) F892_5644;
	R4295[3] = (char *(*)()) F895_5809;
	R4295[284] = (char *(*)()) F895_5809;
}

char *(*R4323[2])();
void R4323_init () {
	R4323[0] = (char *(*)()) F891_5571;
	R4323[1] = (char *(*)()) F890_5548;
}

char *(*R4381[282])();
void R4381_init () {
	R4381[0] = (char *(*)()) F895_5747;
	R4381[281] = (char *(*)()) F1176_8631;
}

char *(*R4385[283])();
void R4385_init () {
	{long i; for (i = 0; i < 2; i++) R4385[i] = (char *(*)()) F893_5680;}
	R4385[282] = (char *(*)()) F1176_8637;
}

char *(*R4390[283])();
void R4390_init () {
	{long i; for (i = 0; i < 2; i++) R4390[i] = (char *(*)()) F893_5692;}
	R4390[282] = (char *(*)()) F1176_8660;
}

char *(*R4395[282])();
void R4395_init () {
	R4395[0] = (char *(*)()) F895_5796;
	R4395[281] = (char *(*)()) F1176_8638;
}

char *(*R4403[283])();
void R4403_init () {
	R4403[0] = (char *(*)()) F894_5737;
	R4403[1] = (char *(*)()) F893_5716;
	R4403[282] = (char *(*)()) F893_5716;
}

char *(*R4429[282])();
void R4429_init () {
	R4429[0] = (char *(*)()) F895_5777;
	R4429[281] = (char *(*)()) F1176_8676;
}

char *(*R4431[282])();
void R4431_init () {
	R4431[0] = (char *(*)()) F895_5779;
	R4431[281] = (char *(*)()) F1176_8674;
}

char *(*R4433[282])();
void R4433_init () {
	R4433[0] = (char *(*)()) F895_5790;
	R4433[281] = (char *(*)()) F1176_8673;
}

char *(*R4445[282])();
void R4445_init () {
	R4445[0] = (char *(*)()) F895_5818;
	R4445[281] = (char *(*)()) F1176_8707;
}

char *(*R4446[282])();
void R4446_init () {
	R4446[0] = (char *(*)()) F895_5819;
	R4446[281] = (char *(*)()) F1176_8708;
}

char *(*R4528[269])();
void R4528_init () {
	R4528[0] = (char *(*)()) F908_5940;
	R4528[1] = (char *(*)()) F909_5948;
	R4528[53] = (char *(*)()) F960_6704;
	R4528[268] = (char *(*)()) F1176_8675;
}

char *(*R4548[269])();
void R4548_init () {
	R4548[0] = (char *(*)()) F908_5937;
	R4548[1] = (char *(*)()) F909_5945;
	R4548[53] = (char *(*)()) F961_6718;
	R4548[268] = (char *(*)()) F1176_8716;
}

char *(*R4602[6])();
void R4602_init () {
	R4602[0] = (char *(*)()) F917_6008;
	R4602[1] = (char *(*)()) F918_6008;
	R4602[2] = (char *(*)()) F919_6008;
	R4602[3] = (char *(*)()) F920_6008;
	R4602[4] = (char *(*)()) F921_6008;
	R4602[5] = (char *(*)()) F922_6008;
}

char *(*R4607[6])();
void R4607_init () {
	R4607[0] = (char *(*)()) F917_6013;
	R4607[1] = (char *(*)()) F918_6013;
	R4607[2] = (char *(*)()) F919_6013;
	R4607[3] = (char *(*)()) F920_6013;
	R4607[4] = (char *(*)()) F921_6013;
	R4607[5] = (char *(*)()) F922_6013;
}

char *(*R4766[38])();
void R4766_init () {
	R4766[0] = (char *(*)()) F929_6189;
	R4766[1] = (char *(*)()) F927_6171;
	R4766[37] = (char *(*)()) F965_6733;
}

char *(*R5173[22])();
void R5173_init () {
	R5173[0] = (char *(*)()) F1008_6827;
	R5173[1] = (char *(*)()) F1009_6827;
	R5173[12] = (char *(*)()) F1020_6835;
	R5173[13] = (char *(*)()) F1021_6835;
	R5173[14] = (char *(*)()) F1022_6835;
	R5173[15] = (char *(*)()) F1023_6835;
	R5173[16] = (char *(*)()) F1024_6835;
	R5173[19] = (char *(*)()) F1027_6856;
	R5173[20] = (char *(*)()) F1028_6856;
	R5173[21] = (char *(*)()) F1029_6871;
}

char *(*R5174[22])();
void R5174_init () {
	R5174[0] = (char *(*)()) F999_6812;
	R5174[1] = (char *(*)()) F1002_6812;
	R5174[12] = (char *(*)()) F999_6812;
	R5174[13] = (char *(*)()) F1000_6812;
	R5174[14] = (char *(*)()) F1001_6812;
	R5174[15] = (char *(*)()) F1002_6812;
	R5174[16] = (char *(*)()) F1003_6812;
	R5174[19] = (char *(*)()) F985_6792;
	R5174[20] = (char *(*)()) F986_6792;
	R5174[21] = (char *(*)()) F1029_6874;
}

char *(*R5175[22])();
void R5175_init () {
	R5175[0] = (char *(*)()) F970_6765;
	R5175[1] = (char *(*)()) F971_6765;
	R5175[12] = (char *(*)()) F970_6765;
	R5175[13] = (char *(*)()) F971_6765;
	R5175[14] = (char *(*)()) F970_6765;
	R5175[15] = (char *(*)()) F971_6765;
	R5175[16] = (char *(*)()) F973_6765;
	R5175[19] = (char *(*)()) F970_6765;
	R5175[20] = (char *(*)()) F971_6765;
	R5175[21] = (char *(*)()) F1029_6875;
}

char *(*R5179[22])();
void R5179_init () {
	R5179[0] = (char *(*)()) F970_6771;
	R5179[1] = (char *(*)()) F971_6771;
	R5179[12] = (char *(*)()) F970_6771;
	R5179[13] = (char *(*)()) F971_6771;
	R5179[14] = (char *(*)()) F970_6771;
	R5179[15] = (char *(*)()) F971_6771;
	R5179[16] = (char *(*)()) F973_6771;
	R5179[19] = (char *(*)()) F970_6771;
	R5179[20] = (char *(*)()) F971_6771;
	R5179[21] = (char *(*)()) F970_6771;
}

char *(*R5187[22])();
void R5187_init () {
	R5187[0] = (char *(*)()) F979_6782;
	R5187[1] = (char *(*)()) F980_6782;
	R5187[12] = (char *(*)()) F979_6782;
	R5187[13] = (char *(*)()) F980_6782;
	R5187[14] = (char *(*)()) F979_6782;
	R5187[15] = (char *(*)()) F980_6782;
	R5187[16] = (char *(*)()) F982_6782;
	R5187[19] = (char *(*)()) F979_6782;
	R5187[20] = (char *(*)()) F980_6782;
	R5187[21] = (char *(*)()) F979_6782;
}

char *(*R5191[22])();
void R5191_init () {
	R5191[0] = (char *(*)()) F999_6811;
	R5191[1] = (char *(*)()) F1002_6811;
	R5191[12] = (char *(*)()) F999_6811;
	R5191[13] = (char *(*)()) F1000_6811;
	R5191[14] = (char *(*)()) F1001_6811;
	R5191[15] = (char *(*)()) F1002_6811;
	R5191[16] = (char *(*)()) F1003_6811;
	R5191[19] = (char *(*)()) F1027_6858;
	R5191[20] = (char *(*)()) F1028_6858;
	R5191[21] = (char *(*)()) F1029_6873;
}

char *(*R5203[17])();
void R5203_init () {
	R5203[0] = (char *(*)()) F999_6808;
	R5203[1] = (char *(*)()) F1002_6808;
	R5203[12] = (char *(*)()) F999_6808;
	R5203[13] = (char *(*)()) F1000_6808;
	R5203[14] = (char *(*)()) F1001_6808;
	R5203[15] = (char *(*)()) F1002_6808;
	R5203[16] = (char *(*)()) F1003_6808;
}

char *(*R5205[17])();
void R5205_init () {
	R5205[0] = (char *(*)()) F999_6814;
	R5205[1] = (char *(*)()) F1002_6814;
	R5205[12] = (char *(*)()) F999_6814;
	R5205[13] = (char *(*)()) F1000_6814;
	R5205[14] = (char *(*)()) F1001_6814;
	R5205[15] = (char *(*)()) F1002_6814;
	R5205[16] = (char *(*)()) F1003_6814;
}

char *(*R5206[17])();
void R5206_init () {
	R5206[0] = (char *(*)()) F999_6815;
	R5206[1] = (char *(*)()) F1002_6815;
	R5206[12] = (char *(*)()) F999_6815;
	R5206[13] = (char *(*)()) F1000_6815;
	R5206[14] = (char *(*)()) F1001_6815;
	R5206[15] = (char *(*)()) F1002_6815;
	R5206[16] = (char *(*)()) F1003_6815;
}

char *(*R5211[17])();
void R5211_init () {
	R5211[0] = (char *(*)()) F999_6822;
	R5211[1] = (char *(*)()) F1002_6822;
	R5211[12] = (char *(*)()) F999_6822;
	R5211[13] = (char *(*)()) F1000_6822;
	R5211[14] = (char *(*)()) F1001_6822;
	R5211[15] = (char *(*)()) F1002_6822;
	R5211[16] = (char *(*)()) F1003_6822;
}

char *(*R5227[2])();
void R5227_init () {
	R5227[0] = (char *(*)()) F1027_6855;
	R5227[1] = (char *(*)()) F1028_6855;
}

char *(*R5229[2])();
void R5229_init () {
	R5229[0] = (char *(*)()) F1027_6861;
	R5229[1] = (char *(*)()) F1028_6861;
}

char *(*R5230[2])();
void R5230_init () {
	R5230[0] = (char *(*)()) F1027_6862;
	R5230[1] = (char *(*)()) F1028_6862;
}

char *(*R5234[2])();
void R5234_init () {
	R5234[0] = (char *(*)()) F1027_6868;
	R5234[1] = (char *(*)()) F1028_6868;
}

char *(*R5246[33])();
void R5246_init () {
	R5246[0] = (char *(*)()) F1077_7141;
	R5246[4] = (char *(*)()) F1081_7229;
	R5246[5] = (char *(*)()) F1082_7264;
	R5246[6] = (char *(*)()) F1083_7264;
	R5246[16] = (char *(*)()) F1084_7340;
	R5246[17] = (char *(*)()) F1087_7340;
	R5246[28] = (char *(*)()) F1084_7340;
	R5246[29] = (char *(*)()) F1085_7340;
	R5246[30] = (char *(*)()) F1086_7340;
	R5246[31] = (char *(*)()) F1087_7340;
	R5246[32] = (char *(*)()) F1088_7340;
}

char *(*R5247[33])();
void R5247_init () {
	R5247[0] = (char *(*)()) F1030_6885;
	{long i; for (i = 4; i < 6; i++) R5247[i] = (char *(*)()) F1030_6885;}
	R5247[6] = (char *(*)()) F1031_6885;
	R5247[16] = (char *(*)()) F1030_6885;
	R5247[17] = (char *(*)()) F1031_6885;
	R5247[28] = (char *(*)()) F1030_6885;
	R5247[29] = (char *(*)()) F1031_6885;
	R5247[30] = (char *(*)()) F1030_6885;
	R5247[31] = (char *(*)()) F1031_6885;
	R5247[32] = (char *(*)()) F1032_6885;
}

static EIF_TYPE_INDEX Y5255_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5255_pgtype79[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5255_gen_type [80];
EIF_TYPE_INDEX Y5255 [80];
void Y5255_init (void)
{
	egc_routines_types [5255] = Y5255;
	egc_routines_gen_types [5255] = Y5255_gen_type;
	egc_routines_offset [5255] = 1029;
	Y5255_gen_type [0] = Y5255_pgtype0;
	Y5255_gen_type [1] = Y5255_pgtype1;
	Y5255_gen_type [2] = Y5255_pgtype2;
	Y5255_gen_type [3] = Y5255_pgtype3;
	Y5255_gen_type [4] = Y5255_pgtype4;
	Y5255_gen_type [5] = Y5255_pgtype5;
	Y5255_gen_type [6] = Y5255_pgtype6;
	Y5255_gen_type [7] = Y5255_pgtype7;
	Y5255_gen_type [8] = Y5255_pgtype8;
	Y5255_gen_type [9] = Y5255_pgtype9;
	Y5255_gen_type [10] = Y5255_pgtype10;
	Y5255_gen_type [11] = Y5255_pgtype11;
	Y5255_gen_type [12] = Y5255_pgtype12;
	Y5255_gen_type [13] = Y5255_pgtype13;
	Y5255_gen_type [14] = Y5255_pgtype14;
	Y5255_gen_type [15] = Y5255_pgtype15;
	Y5255_gen_type [16] = Y5255_pgtype16;
	Y5255_gen_type [17] = Y5255_pgtype17;
	Y5255_gen_type [18] = Y5255_pgtype18;
	Y5255_gen_type [19] = Y5255_pgtype19;
	Y5255_gen_type [20] = Y5255_pgtype20;
	Y5255_gen_type [21] = Y5255_pgtype21;
	Y5255_gen_type [22] = Y5255_pgtype22;
	Y5255_gen_type [23] = Y5255_pgtype23;
	Y5255_gen_type [24] = Y5255_pgtype24;
	Y5255_gen_type [25] = Y5255_pgtype25;
	Y5255_gen_type [26] = Y5255_pgtype26;
	Y5255_gen_type [27] = Y5255_pgtype27;
	Y5255_gen_type [28] = Y5255_pgtype28;
	Y5255_gen_type [29] = Y5255_pgtype29;
	Y5255_gen_type [30] = Y5255_pgtype30;
	Y5255_gen_type [31] = Y5255_pgtype31;
	Y5255_gen_type [32] = Y5255_pgtype32;
	Y5255_gen_type [33] = Y5255_pgtype33;
	Y5255_gen_type [34] = Y5255_pgtype34;
	Y5255_gen_type [35] = Y5255_pgtype35;
	Y5255_gen_type [36] = Y5255_pgtype36;
	Y5255_gen_type [37] = Y5255_pgtype37;
	Y5255_gen_type [38] = Y5255_pgtype38;
	Y5255_gen_type [39] = Y5255_pgtype39;
	Y5255_gen_type [40] = Y5255_pgtype40;
	Y5255_gen_type [41] = Y5255_pgtype41;
	Y5255_gen_type [42] = Y5255_pgtype42;
	Y5255_gen_type [43] = Y5255_pgtype43;
	Y5255_gen_type [44] = Y5255_pgtype44;
	Y5255_gen_type [45] = Y5255_pgtype45;
	Y5255_gen_type [46] = Y5255_pgtype46;
	Y5255_gen_type [47] = Y5255_pgtype47;
	Y5255_gen_type [48] = Y5255_pgtype48;
	Y5255_gen_type [49] = Y5255_pgtype49;
	Y5255_gen_type [50] = Y5255_pgtype50;
	Y5255_gen_type [51] = Y5255_pgtype51;
	Y5255_gen_type [52] = Y5255_pgtype52;
	Y5255_gen_type [53] = Y5255_pgtype53;
	Y5255_gen_type [54] = Y5255_pgtype54;
	Y5255_gen_type [55] = Y5255_pgtype55;
	Y5255_gen_type [56] = Y5255_pgtype56;
	Y5255_gen_type [57] = Y5255_pgtype57;
	Y5255_gen_type [58] = Y5255_pgtype58;
	Y5255_gen_type [59] = Y5255_pgtype59;
	Y5255_gen_type [60] = Y5255_pgtype60;
	Y5255_gen_type [61] = Y5255_pgtype61;
	Y5255_gen_type [62] = Y5255_pgtype62;
	Y5255_gen_type [63] = Y5255_pgtype63;
	Y5255_gen_type [64] = Y5255_pgtype64;
	Y5255_gen_type [65] = Y5255_pgtype65;
	Y5255_gen_type [66] = Y5255_pgtype66;
	Y5255_gen_type [67] = Y5255_pgtype67;
	Y5255_gen_type [68] = Y5255_pgtype68;
	Y5255_gen_type [69] = Y5255_pgtype69;
	Y5255_gen_type [70] = Y5255_pgtype70;
	Y5255_gen_type [71] = Y5255_pgtype71;
	Y5255_gen_type [72] = Y5255_pgtype72;
	Y5255_gen_type [73] = Y5255_pgtype73;
	Y5255_gen_type [74] = Y5255_pgtype74;
	Y5255_gen_type [75] = Y5255_pgtype75;
	Y5255_gen_type [76] = Y5255_pgtype76;
	Y5255_gen_type [77] = Y5255_pgtype77;
	Y5255_gen_type [78] = Y5255_pgtype78;
	Y5255_gen_type [79] = Y5255_pgtype79;
}

char *(*R5257[5])();
void R5257_init () {
	R5257[0] = (char *(*)()) F1095_7498;
	R5257[1] = (char *(*)()) F1096_7498_5257_5;
	R5257[2] = (char *(*)()) F1097_7498_5257_5;
	R5257[3] = (char *(*)()) F1098_7498_5257_5;
	R5257[4] = (char *(*)()) F1099_7498_5257_5;
}
static EIF_REFERENCE F1096_7498_5257_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1096_7498(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1097_7498_5257_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1097_7498(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1098_7498_5257_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1098_7498(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_7498_5257_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1099_7498(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5260[5])();
void R5260_init () {
	R5260[0] = (char *(*)()) F1095_7506;
	R5260[1] = (char *(*)()) F1096_7506;
	R5260[2] = (char *(*)()) F1097_7506_5260_2;
	R5260[3] = (char *(*)()) F1098_7506_5260_2;
	R5260[4] = (char *(*)()) F1099_7506_5260_2;
}
static EIF_BOOLEAN F1097_7506_5260_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1097_7506(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1098_7506_5260_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1098_7506(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1099_7506_5260_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1099_7506(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5278[33])();
void R5278_init () {
	R5278[0] = (char *(*)()) F1077_7140;
	R5278[5] = (char *(*)()) F1082_7263;
	R5278[6] = (char *(*)()) F1083_7263;
	R5278[16] = (char *(*)()) F1093_7486;
	R5278[17] = (char *(*)()) F1094_7486;
	R5278[28] = (char *(*)()) F1105_7570;
	R5278[29] = (char *(*)()) F1106_7570;
	R5278[30] = (char *(*)()) F1107_7570;
	R5278[31] = (char *(*)()) F1108_7570;
	R5278[32] = (char *(*)()) F1109_7570;
}

static EIF_TYPE_INDEX Y5278_pgtype0[] = {0xFF01,969,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype1[] = {0xFF01,970,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype2[] = {0xFF01,971,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype3[] = {0xFF01,972,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype4[] = {0xFF01,978,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype5[] = {0xFF01,979,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype6[] = {0xFF01,980,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype7[] = {0xFF01,981,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype8[] = {0xFF01,984,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype9[] = {0xFF01,985,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype10[] = {0xFF01,986,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype11[] = {0xFF01,987,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype12[] = {0xFF01,988,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype13[] = {0xFF01,989,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype14[] = {0xFF01,990,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype15[] = {0xFF01,991,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype16[] = {0xFF01,992,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype17[] = {0xFF01,993,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype18[] = {0xFF01,994,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype19[] = {0xFF01,995,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype20[] = {0xFF01,996,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype21[] = {0xFF01,997,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype22[] = {0xFF01,982,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype23[] = {0xFF01,983,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype24[] = {0xFF01,1024,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype25[] = {0xFF01,1025,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype26[] = {0xFF01,1028,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype27[] = {0xFF01,1026,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype28[] = {0xFF01,1027,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype29[] = {0xFF01,998,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype30[] = {0xFF01,999,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype31[] = {0xFF01,1000,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype32[] = {0xFF01,1001,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype33[] = {0xFF01,1002,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype34[] = {0xFF01,1003,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype35[] = {0xFF01,1004,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype36[] = {0xFF01,1005,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype37[] = {0xFF01,1006,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype38[] = {0xFF01,1007,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype39[] = {0xFF01,1008,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype40[] = {0xFF01,1009,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype41[] = {0xFF01,1010,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype42[] = {0xFF01,1011,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype43[] = {0xFF01,1012,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype44[] = {0xFF01,1013,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype45[] = {0xFF01,1014,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype46[] = {0xFF01,1015,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype47[] = {0xFF01,1016,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype48[] = {0xFF01,1017,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype49[] = {0xFF01,1018,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype50[] = {0xFF01,1019,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype51[] = {0xFF01,1020,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype52[] = {0xFF01,1021,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype53[] = {0xFF01,1022,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5278_pgtype54[] = {0xFF01,1023,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5278_gen_type [69];
EIF_TYPE_INDEX Y5278 [69];
void Y5278_init (void)
{
	egc_routines_types [5278] = Y5278;
	egc_routines_gen_types [5278] = Y5278_gen_type;
	egc_routines_offset [5278] = 1040;
	Y5278_gen_type [0] = Y5278_pgtype0;
	Y5278_gen_type [1] = Y5278_pgtype1;
	Y5278_gen_type [2] = Y5278_pgtype2;
	Y5278_gen_type [3] = Y5278_pgtype3;
	Y5278_gen_type [8] = Y5278_pgtype4;
	Y5278_gen_type [9] = Y5278_pgtype5;
	Y5278_gen_type [10] = Y5278_pgtype6;
	Y5278_gen_type [11] = Y5278_pgtype7;
	Y5278_gen_type [12] = Y5278_pgtype8;
	Y5278_gen_type [13] = Y5278_pgtype9;
	Y5278_gen_type [14] = Y5278_pgtype10;
	Y5278_gen_type [15] = Y5278_pgtype11;
	Y5278_gen_type [16] = Y5278_pgtype12;
	Y5278_gen_type [17] = Y5278_pgtype13;
	Y5278_gen_type [18] = Y5278_pgtype14;
	Y5278_gen_type [19] = Y5278_pgtype15;
	Y5278_gen_type [20] = Y5278_pgtype16;
	Y5278_gen_type [21] = Y5278_pgtype17;
	Y5278_gen_type [22] = Y5278_pgtype18;
	Y5278_gen_type [23] = Y5278_pgtype19;
	Y5278_gen_type [24] = Y5278_pgtype20;
	Y5278_gen_type [25] = Y5278_pgtype21;
	Y5278_gen_type [28] = Y5278_pgtype22;
	Y5278_gen_type [29] = Y5278_pgtype23;
	Y5278_gen_type [34] = Y5278_pgtype24;
	Y5278_gen_type [35] = Y5278_pgtype25;
	Y5278_gen_type [36] = Y5278_pgtype26;
	Y5278_gen_type [41] = Y5278_pgtype27;
	Y5278_gen_type [42] = Y5278_pgtype28;
	Y5278_gen_type [43] = Y5278_pgtype29;
	Y5278_gen_type [44] = Y5278_pgtype30;
	Y5278_gen_type [45] = Y5278_pgtype31;
	Y5278_gen_type [46] = Y5278_pgtype32;
	Y5278_gen_type [47] = Y5278_pgtype33;
	Y5278_gen_type [48] = Y5278_pgtype34;
	Y5278_gen_type [49] = Y5278_pgtype35;
	Y5278_gen_type [50] = Y5278_pgtype36;
	Y5278_gen_type [51] = Y5278_pgtype37;
	Y5278_gen_type [52] = Y5278_pgtype38;
	Y5278_gen_type [53] = Y5278_pgtype39;
	Y5278_gen_type [54] = Y5278_pgtype40;
	Y5278_gen_type [55] = Y5278_pgtype41;
	Y5278_gen_type [56] = Y5278_pgtype42;
	Y5278_gen_type [57] = Y5278_pgtype43;
	Y5278_gen_type [58] = Y5278_pgtype44;
	Y5278_gen_type [59] = Y5278_pgtype45;
	Y5278_gen_type [60] = Y5278_pgtype46;
	Y5278_gen_type [61] = Y5278_pgtype47;
	Y5278_gen_type [62] = Y5278_pgtype48;
	Y5278_gen_type [63] = Y5278_pgtype49;
	Y5278_gen_type [64] = Y5278_pgtype50;
	Y5278_gen_type [65] = Y5278_pgtype51;
	Y5278_gen_type [66] = Y5278_pgtype52;
	Y5278_gen_type [67] = Y5278_pgtype53;
	Y5278_gen_type [68] = Y5278_pgtype54;
	Y5278[0] = 969;
	Y5278[1] = 970;
	Y5278[2] = 971;
	Y5278[3] = 972;
	Y5278[8] = 978;
	Y5278[9] = 979;
	Y5278[10] = 980;
	Y5278[11] = 981;
	Y5278[12] = 984;
	Y5278[13] = 985;
	Y5278[14] = 986;
	Y5278[15] = 987;
	Y5278[16] = 988;
	Y5278[17] = 989;
	Y5278[18] = 990;
	Y5278[19] = 991;
	Y5278[20] = 992;
	Y5278[21] = 993;
	Y5278[22] = 994;
	Y5278[23] = 995;
	Y5278[24] = 996;
	Y5278[25] = 997;
	Y5278[28] = 982;
	Y5278[29] = 983;
	Y5278[34] = 1024;
	Y5278[35] = 1025;
	Y5278[36] = 1028;
	Y5278[41] = 1026;
	Y5278[42] = 1027;
	Y5278[43] = 998;
	Y5278[44] = 999;
	Y5278[45] = 1000;
	Y5278[46] = 1001;
	Y5278[47] = 1002;
	Y5278[48] = 1003;
	Y5278[49] = 1004;
	Y5278[50] = 1005;
	Y5278[51] = 1006;
	Y5278[52] = 1007;
	Y5278[53] = 1008;
	Y5278[54] = 1009;
	Y5278[55] = 1010;
	Y5278[56] = 1011;
	Y5278[57] = 1012;
	Y5278[58] = 1013;
	Y5278[59] = 1014;
	Y5278[60] = 1015;
	Y5278[61] = 1016;
	Y5278[62] = 1017;
	Y5278[63] = 1018;
	Y5278[64] = 1019;
	Y5278[65] = 1020;
	Y5278[66] = 1021;
	Y5278[67] = 1022;
	Y5278[68] = 1023;
}

char *(*R5281[33])();
void R5281_init () {
	R5281[0] = (char *(*)()) F1041_6920;
	R5281[5] = (char *(*)()) F1041_6920;
	R5281[6] = (char *(*)()) F1042_6920;
	R5281[16] = (char *(*)()) F1041_6920;
	R5281[17] = (char *(*)()) F1042_6920;
	R5281[28] = (char *(*)()) F1041_6920;
	R5281[29] = (char *(*)()) F1042_6920;
	R5281[30] = (char *(*)()) F1041_6920;
	R5281[31] = (char *(*)()) F1042_6920;
	R5281[32] = (char *(*)()) F1044_6920;
}

char *(*R5283[33])();
void R5283_init () {
	R5283[0] = (char *(*)()) F1077_7196;
	R5283[5] = (char *(*)()) F1082_7312;
	R5283[6] = (char *(*)()) F1083_7312;
	R5283[16] = (char *(*)()) F1084_7405;
	R5283[17] = (char *(*)()) F1087_7405;
	R5283[28] = (char *(*)()) F1084_7405;
	R5283[29] = (char *(*)()) F1085_7405;
	R5283[30] = (char *(*)()) F1086_7405;
	R5283[31] = (char *(*)()) F1087_7405;
	R5283[32] = (char *(*)()) F1088_7405;
}

char *(*R5284[33])();
void R5284_init () {
	R5284[0] = (char *(*)()) F1077_7197;
	R5284[5] = (char *(*)()) F1082_7313;
	R5284[6] = (char *(*)()) F1083_7313;
	R5284[16] = (char *(*)()) F1084_7406;
	R5284[17] = (char *(*)()) F1087_7406;
	R5284[28] = (char *(*)()) F1084_7406;
	R5284[29] = (char *(*)()) F1085_7406;
	R5284[30] = (char *(*)()) F1086_7406;
	R5284[31] = (char *(*)()) F1087_7406;
	R5284[32] = (char *(*)()) F1088_7406;
}

char *(*R5285[33])();
void R5285_init () {
	R5285[0] = (char *(*)()) F1077_7201;
	R5285[5] = (char *(*)()) F1082_7318;
	R5285[6] = (char *(*)()) F1083_7318_5285_5;
	R5285[16] = (char *(*)()) F1084_7411;
	R5285[17] = (char *(*)()) F1087_7411_5285_5;
	R5285[28] = (char *(*)()) F1084_7411;
	R5285[29] = (char *(*)()) F1085_7411_5285_5;
	R5285[30] = (char *(*)()) F1086_7411;
	R5285[31] = (char *(*)()) F1087_7411_5285_5;
	R5285[32] = (char *(*)()) F1088_7411_5285_5;
}
static EIF_REFERENCE F1083_7318_5285_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1083_7318(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1087_7411_5285_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1087_7411(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1085_7411_5285_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1085_7411(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1088_7411_5285_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1088_7411(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5286[33])();
void R5286_init () {
	R5286[0] = (char *(*)()) F1041_6925;
	R5286[5] = (char *(*)()) F1041_6925;
	R5286[6] = (char *(*)()) F1042_6925;
	R5286[16] = (char *(*)()) F1041_6925;
	R5286[17] = (char *(*)()) F1042_6925;
	R5286[28] = (char *(*)()) F1041_6925;
	R5286[29] = (char *(*)()) F1042_6925;
	R5286[30] = (char *(*)()) F1041_6925;
	R5286[31] = (char *(*)()) F1042_6925;
	R5286[32] = (char *(*)()) F1044_6925;
}

char *(*R5287[33])();
void R5287_init () {
	R5287[0] = (char *(*)()) F1077_7205;
	R5287[5] = (char *(*)()) F1082_7322;
	R5287[6] = (char *(*)()) F1083_7322;
	R5287[16] = (char *(*)()) F1084_7414;
	R5287[17] = (char *(*)()) F1087_7414;
	R5287[28] = (char *(*)()) F1084_7414;
	R5287[29] = (char *(*)()) F1085_7414;
	R5287[30] = (char *(*)()) F1086_7414;
	R5287[31] = (char *(*)()) F1087_7414;
	R5287[32] = (char *(*)()) F1088_7414;
}

char *(*R5289[33])();
void R5289_init () {
	R5289[0] = (char *(*)()) F1041_6928;
	R5289[5] = (char *(*)()) F1041_6928;
	R5289[6] = (char *(*)()) F1042_6928;
	R5289[16] = (char *(*)()) F1041_6928;
	R5289[17] = (char *(*)()) F1042_6928;
	R5289[28] = (char *(*)()) F1041_6928;
	R5289[29] = (char *(*)()) F1042_6928;
	R5289[30] = (char *(*)()) F1041_6928;
	R5289[31] = (char *(*)()) F1042_6928;
	R5289[32] = (char *(*)()) F1044_6928;
}

char *(*R5290[33])();
void R5290_init () {
	R5290[0] = (char *(*)()) F1041_6929;
	R5290[5] = (char *(*)()) F1041_6929;
	R5290[6] = (char *(*)()) F1042_6929;
	R5290[16] = (char *(*)()) F1041_6929;
	R5290[17] = (char *(*)()) F1042_6929;
	R5290[28] = (char *(*)()) F1041_6929;
	R5290[29] = (char *(*)()) F1042_6929;
	R5290[30] = (char *(*)()) F1041_6929;
	R5290[31] = (char *(*)()) F1042_6929;
	R5290[32] = (char *(*)()) F1044_6929;
}

char *(*R5291[33])();
void R5291_init () {
	R5291[0] = (char *(*)()) F1077_7143;
	R5291[5] = (char *(*)()) F1082_7267;
	R5291[6] = (char *(*)()) F1083_7267_5291_2;
	R5291[16] = (char *(*)()) F1089_7431;
	R5291[17] = (char *(*)()) F1090_7431_5291_2;
	R5291[28] = (char *(*)()) F1084_7343;
	R5291[29] = (char *(*)()) F1085_7343_5291_2;
	R5291[30] = (char *(*)()) F1086_7343;
	R5291[31] = (char *(*)()) F1087_7343_5291_2;
	R5291[32] = (char *(*)()) F1088_7343_5291_2;
}
static EIF_BOOLEAN F1083_7267_5291_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1083_7267(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1090_7431_5291_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1090_7431(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1085_7343_5291_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1085_7343(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1087_7343_5291_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1087_7343(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1088_7343_5291_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1088_7343(Current, *(EIF_NATURAL_64 *)arg1);
}

char *(*R5294[33])();
void R5294_init () {
	R5294[0] = (char *(*)()) F1045_6933;
	{long i; for (i = 4; i < 6; i++) R5294[i] = (char *(*)()) F1045_6933;}
	R5294[6] = (char *(*)()) F1046_6933;
	R5294[16] = (char *(*)()) F1045_6933;
	R5294[17] = (char *(*)()) F1046_6933;
	R5294[28] = (char *(*)()) F1045_6933;
	R5294[29] = (char *(*)()) F1046_6933;
	R5294[30] = (char *(*)()) F1045_6933;
	R5294[31] = (char *(*)()) F1046_6933;
	R5294[32] = (char *(*)()) F1047_6933;
}

char *(*R5311[33])();
void R5311_init () {
	R5311[0] = (char *(*)()) F1077_7206;
	R5311[5] = (char *(*)()) F1082_7323;
	R5311[6] = (char *(*)()) F1083_7323;
	R5311[16] = (char *(*)()) F1084_7415;
	R5311[17] = (char *(*)()) F1087_7415;
	R5311[28] = (char *(*)()) F1084_7415;
	R5311[29] = (char *(*)()) F1085_7415;
	R5311[30] = (char *(*)()) F1086_7415;
	R5311[31] = (char *(*)()) F1087_7415;
	R5311[32] = (char *(*)()) F1088_7415;
}

char *(*R5312[33])();
void R5312_init () {
	R5312[0] = (char *(*)()) F1077_7208;
	R5312[5] = (char *(*)()) F1082_7325;
	R5312[6] = (char *(*)()) F1083_7325;
	R5312[16] = (char *(*)()) F1084_7417;
	R5312[17] = (char *(*)()) F1087_7417;
	R5312[28] = (char *(*)()) F1084_7417;
	R5312[29] = (char *(*)()) F1085_7417;
	R5312[30] = (char *(*)()) F1086_7417;
	R5312[31] = (char *(*)()) F1087_7417;
	R5312[32] = (char *(*)()) F1088_7417;
}

char *(*R5314[33])();
void R5314_init () {
	R5314[0] = (char *(*)()) F1077_7212;
	R5314[5] = (char *(*)()) F1082_7329;
	R5314[6] = (char *(*)()) F1083_7329;
	R5314[16] = (char *(*)()) F1084_7421;
	R5314[17] = (char *(*)()) F1087_7421;
	R5314[28] = (char *(*)()) F1084_7421;
	R5314[29] = (char *(*)()) F1085_7421;
	R5314[30] = (char *(*)()) F1086_7421;
	R5314[31] = (char *(*)()) F1087_7421;
	R5314[32] = (char *(*)()) F1088_7421;
}

char *(*R5335[5])();
void R5335_init () {
	R5335[0] = (char *(*)()) F1095_7534;
	R5335[1] = (char *(*)()) F1096_7534;
	R5335[2] = (char *(*)()) F1097_7534_5335_5;
	R5335[3] = (char *(*)()) F1098_7534_5335_5;
	R5335[4] = (char *(*)()) F1099_7534_5335_5;
}
static EIF_REFERENCE F1097_7534_5335_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1097_7534(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1098_7534_5335_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1098_7534(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_7534_5335_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1099_7534(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5336[3])();
void R5336_init () {
	R5336[0] = (char *(*)()) F1081_7226;
	R5336[1] = (char *(*)()) F1082_7268;
	R5336[2] = (char *(*)()) F1083_7268;
}

char *(*R5337[7])();
void R5337_init () {
	R5337[0] = (char *(*)()) F1077_7157;
	R5337[4] = (char *(*)()) F1081_7234;
	R5337[5] = (char *(*)()) F1082_7273;
	R5337[6] = (char *(*)()) F1083_7273_5337_4;
}
static void F1083_7273_5337_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_7273(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5367[7])();
void R5367_init () {
	R5367[0] = (char *(*)()) F1077_7137;
	R5367[5] = (char *(*)()) F1082_7260;
	R5367[6] = (char *(*)()) F1083_7260_5367_28;
}
static EIF_REFERENCE F1083_7260_5367_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1083_7260(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5371[2])();
void R5371_init () {
	R5371[0] = (char *(*)()) F1082_7274;
	R5371[1] = (char *(*)()) F1083_7274_5371_132;
}
static void F1083_7274_5371_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1083_7274(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5374[7])();
void R5374_init () {
	R5374[0] = (char *(*)()) F1077_7159;
	R5374[5] = (char *(*)()) F1082_7271;
	R5374[6] = (char *(*)()) F1083_7271_5374_132;
}
static void F1083_7271_5374_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1083_7271(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5381[2])();
void R5381_init () {
	R5381[0] = (char *(*)()) F1082_7293;
	R5381[1] = (char *(*)()) F1083_7293;
}

char *(*R5437[29])();
void R5437_init () {
	R5437[0] = (char *(*)()) F1081_7230;
	R5437[1] = (char *(*)()) F1082_7265;
	R5437[2] = (char *(*)()) F1083_7265;
	R5437[12] = (char *(*)()) F1084_7341;
	R5437[13] = (char *(*)()) F1087_7341;
	R5437[24] = (char *(*)()) F1084_7341;
	R5437[25] = (char *(*)()) F1085_7341;
	R5437[26] = (char *(*)()) F1086_7341;
	R5437[27] = (char *(*)()) F1087_7341;
	R5437[28] = (char *(*)()) F1088_7341;
}

char *(*R5440[29])();
void R5440_init () {
	R5440[0] = (char *(*)()) F1081_7243;
	R5440[1] = (char *(*)()) F1082_7307;
	R5440[2] = (char *(*)()) F1083_7307;
	R5440[12] = (char *(*)()) F1084_7359;
	R5440[13] = (char *(*)()) F1087_7359;
	R5440[24] = (char *(*)()) F1084_7359;
	R5440[25] = (char *(*)()) F1085_7359;
	R5440[26] = (char *(*)()) F1086_7359;
	R5440[27] = (char *(*)()) F1087_7359;
	R5440[28] = (char *(*)()) F1088_7359;
}

char *(*R5441[29])();
void R5441_init () {
	{long i; for (i = 0; i < 2; i++) R5441[i] = (char *(*)()) F1078_7221;}
	R5441[2] = (char *(*)()) F1079_7221;
	R5441[12] = (char *(*)()) F1084_7424;
	R5441[13] = (char *(*)()) F1087_7424;
	R5441[24] = (char *(*)()) F1084_7424;
	R5441[25] = (char *(*)()) F1085_7424;
	R5441[26] = (char *(*)()) F1086_7424;
	R5441[27] = (char *(*)()) F1087_7424;
	R5441[28] = (char *(*)()) F1088_7424;
}

char *(*R5455[2])();
void R5455_init () {
	R5455[0] = (char *(*)()) F1082_7309;
	R5455[1] = (char *(*)()) F1083_7309;
}

char *(*R5456[2])();
void R5456_init () {
	R5456[0] = (char *(*)()) F1082_7310;
	R5456[1] = (char *(*)()) F1083_7310;
}

char *(*R5458[2])();
void R5458_init () {
	R5458[0] = (char *(*)()) F1082_7314;
	R5458[1] = (char *(*)()) F1083_7314;
}

char *(*R5459[2])();
void R5459_init () {
	R5459[0] = (char *(*)()) F1082_7315;
	R5459[1] = (char *(*)()) F1083_7315;
}

char *(*R5460[2])();
void R5460_init () {
	R5460[0] = (char *(*)()) F1082_7316;
	R5460[1] = (char *(*)()) F1083_7316;
}

char *(*R5461[2])();
void R5461_init () {
	R5461[0] = (char *(*)()) F1082_7317;
	R5461[1] = (char *(*)()) F1083_7317;
}

char *(*R5462[2])();
void R5462_init () {
	R5462[0] = (char *(*)()) F1082_7334;
	R5462[1] = (char *(*)()) F1083_7334;
}

char *(*R5466[17])();
void R5466_init () {
	R5466[0] = (char *(*)()) F1084_7335;
	R5466[1] = (char *(*)()) F1087_7335;
	R5466[12] = (char *(*)()) F1084_7335;
	R5466[13] = (char *(*)()) F1085_7335;
	R5466[14] = (char *(*)()) F1086_7335;
	R5466[15] = (char *(*)()) F1087_7335;
	R5466[16] = (char *(*)()) F1088_7335;
}

char *(*R5470[17])();
void R5470_init () {
	R5470[0] = (char *(*)()) F1084_7354;
	R5470[1] = (char *(*)()) F1087_7354;
	R5470[12] = (char *(*)()) F1084_7354;
	R5470[13] = (char *(*)()) F1085_7354;
	R5470[14] = (char *(*)()) F1086_7354;
	R5470[15] = (char *(*)()) F1087_7354;
	R5470[16] = (char *(*)()) F1088_7354;
}

char *(*R5475[17])();
void R5475_init () {
	R5475[0] = (char *(*)()) F1091_7461;
	R5475[1] = (char *(*)()) F1092_7461_5475_28;
	R5475[12] = (char *(*)()) F1100_7536;
	R5475[13] = (char *(*)()) F1101_7536_5475_28;
	R5475[14] = (char *(*)()) F1102_7536;
	R5475[15] = (char *(*)()) F1103_7536_5475_28;
	R5475[16] = (char *(*)()) F1104_7536_5475_28;
}
static EIF_REFERENCE F1092_7461_5475_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1092_7461(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1101_7536_5475_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1101_7536(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1103_7536_5475_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1103_7536(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1104_7536_5475_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1104_7536(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5476[17])();
void R5476_init () {
	R5476[0] = (char *(*)()) F1091_7465;
	R5476[1] = (char *(*)()) F1092_7465_5476_132;
	R5476[12] = (char *(*)()) F1100_7537;
	R5476[13] = (char *(*)()) F1101_7537_5476_132;
	R5476[14] = (char *(*)()) F1102_7537;
	R5476[15] = (char *(*)()) F1103_7537_5476_132;
	R5476[16] = (char *(*)()) F1104_7537_5476_132;
}
static void F1092_7465_5476_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1092_7465(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1101_7537_5476_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1101_7537(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1103_7537_5476_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1103_7537(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1104_7537_5476_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1104_7537(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}

char *(*R5477[17])();
void R5477_init () {
	R5477[0] = (char *(*)()) F1089_7451;
	R5477[1] = (char *(*)()) F1090_7451_5477_28;
	R5477[12] = (char *(*)()) F1100_7538;
	R5477[13] = (char *(*)()) F1101_7538;
	R5477[14] = (char *(*)()) F1102_7538_5477_28;
	R5477[15] = (char *(*)()) F1103_7538_5477_28;
	R5477[16] = (char *(*)()) F1104_7538_5477_28;
}
static EIF_REFERENCE F1090_7451_5477_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1090_7451(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1102_7538_5477_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1102_7538(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1103_7538_5477_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1103_7538(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1104_7538_5477_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1104_7538(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5478[17])();
void R5478_init () {
	R5478[0] = (char *(*)()) F1091_7462;
	R5478[1] = (char *(*)()) F1092_7462;
	R5478[12] = (char *(*)()) F1100_7539;
	R5478[13] = (char *(*)()) F1101_7539;
	R5478[14] = (char *(*)()) F1102_7539;
	R5478[15] = (char *(*)()) F1103_7539;
	R5478[16] = (char *(*)()) F1104_7539;
}

char *(*R5481[17])();
void R5481_init () {
	R5481[0] = (char *(*)()) F1084_7368;
	R5481[1] = (char *(*)()) F1087_7368_5481_4;
	R5481[12] = (char *(*)()) F1084_7368;
	R5481[13] = (char *(*)()) F1085_7368;
	R5481[14] = (char *(*)()) F1086_7368_5481_4;
	R5481[15] = (char *(*)()) F1087_7368_5481_4;
	R5481[16] = (char *(*)()) F1088_7368_5481_4;
}
static void F1087_7368_5481_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1087_7368(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1086_7368_5481_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1086_7368(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1088_7368_5481_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1088_7368(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5483[17])();
void R5483_init () {
	R5483[0] = (char *(*)()) F1089_7452;
	R5483[1] = (char *(*)()) F1090_7452;
	R5483[12] = (char *(*)()) F1095_7504;
	R5483[13] = (char *(*)()) F1096_7504;
	R5483[14] = (char *(*)()) F1097_7504;
	R5483[15] = (char *(*)()) F1098_7504;
	R5483[16] = (char *(*)()) F1099_7504;
}

char *(*R5485[17])();
void R5485_init () {
	R5485[0] = (char *(*)()) F1093_7489;
	R5485[1] = (char *(*)()) F1094_7489_5485_23;
	R5485[12] = (char *(*)()) F1105_7573;
	R5485[13] = (char *(*)()) F1106_7573;
	R5485[14] = (char *(*)()) F1107_7573_5485_23;
	R5485[15] = (char *(*)()) F1108_7573_5485_23;
	R5485[16] = (char *(*)()) F1109_7573_5485_23;
}
static EIF_INTEGER_32 F1094_7489_5485_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1094_7489(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1107_7573_5485_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1107_7573(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1108_7573_5485_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1108_7573(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1109_7573_5485_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1109_7573(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5487[17])();
void R5487_init () {
	R5487[0] = (char *(*)()) F1091_7464;
	R5487[1] = (char *(*)()) F1092_7464;
	R5487[12] = (char *(*)()) F1100_7541;
	R5487[13] = (char *(*)()) F1101_7541;
	R5487[14] = (char *(*)()) F1102_7541;
	R5487[15] = (char *(*)()) F1103_7541;
	R5487[16] = (char *(*)()) F1104_7541;
}

char *(*R5488[17])();
void R5488_init () {
	R5488[0] = (char *(*)()) F1091_7466;
	R5488[1] = (char *(*)()) F1092_7466;
	R5488[12] = (char *(*)()) F1100_7542;
	R5488[13] = (char *(*)()) F1101_7542;
	R5488[14] = (char *(*)()) F1102_7542;
	R5488[15] = (char *(*)()) F1103_7542;
	R5488[16] = (char *(*)()) F1104_7542;
}

char *(*R5489[17])();
void R5489_init () {
	R5489[0] = (char *(*)()) F1091_7467;
	R5489[1] = (char *(*)()) F1092_7467;
	R5489[12] = (char *(*)()) F1100_7543;
	R5489[13] = (char *(*)()) F1101_7543;
	R5489[14] = (char *(*)()) F1102_7543;
	R5489[15] = (char *(*)()) F1103_7543;
	R5489[16] = (char *(*)()) F1104_7543;
}

char *(*R5492[17])();
void R5492_init () {
	R5492[0] = (char *(*)()) F1089_7454;
	R5492[1] = (char *(*)()) F1090_7454;
	R5492[12] = (char *(*)()) F1100_7547;
	R5492[13] = (char *(*)()) F1101_7547;
	R5492[14] = (char *(*)()) F1102_7547;
	R5492[15] = (char *(*)()) F1103_7547;
	R5492[16] = (char *(*)()) F1104_7547;
}

char *(*R5493[5])();
void R5493_init () {
	R5493[0] = (char *(*)()) F1100_7548;
	R5493[1] = (char *(*)()) F1101_7548;
	R5493[2] = (char *(*)()) F1102_7548_5493_132;
	R5493[3] = (char *(*)()) F1103_7548_5493_132;
	R5493[4] = (char *(*)()) F1104_7548_5493_132;
}
static void F1102_7548_5493_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1102_7548(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1103_7548_5493_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1103_7548(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1104_7548_5493_132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1104_7548(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R5494[17])();
void R5494_init () {
	R5494[0] = (char *(*)()) F1089_7456;
	R5494[1] = (char *(*)()) F1090_7456;
	R5494[12] = (char *(*)()) F1100_7549;
	R5494[13] = (char *(*)()) F1101_7549;
	R5494[14] = (char *(*)()) F1102_7549;
	R5494[15] = (char *(*)()) F1103_7549;
	R5494[16] = (char *(*)()) F1104_7549;
}

char *(*R5495[17])();
void R5495_init () {
	R5495[0] = (char *(*)()) F1089_7457;
	R5495[1] = (char *(*)()) F1090_7457;
	R5495[12] = (char *(*)()) F1100_7550;
	R5495[13] = (char *(*)()) F1101_7550;
	R5495[14] = (char *(*)()) F1102_7550;
	R5495[15] = (char *(*)()) F1103_7550;
	R5495[16] = (char *(*)()) F1104_7550;
}

char *(*R5498[17])();
void R5498_init () {
	R5498[0] = (char *(*)()) F1091_7471;
	R5498[1] = (char *(*)()) F1092_7471;
	R5498[12] = (char *(*)()) F1100_7554;
	R5498[13] = (char *(*)()) F1101_7554;
	R5498[14] = (char *(*)()) F1102_7554;
	R5498[15] = (char *(*)()) F1103_7554;
	R5498[16] = (char *(*)()) F1104_7554;
}

char *(*R5499[17])();
void R5499_init () {
	R5499[0] = (char *(*)()) F1091_7472;
	R5499[1] = (char *(*)()) F1092_7472;
	R5499[12] = (char *(*)()) F1100_7555;
	R5499[13] = (char *(*)()) F1101_7555;
	R5499[14] = (char *(*)()) F1102_7555;
	R5499[15] = (char *(*)()) F1103_7555;
	R5499[16] = (char *(*)()) F1104_7555;
}

char *(*R5500[17])();
void R5500_init () {
	R5500[0] = (char *(*)()) F1091_7473;
	R5500[1] = (char *(*)()) F1092_7473;
	R5500[12] = (char *(*)()) F1100_7556;
	R5500[13] = (char *(*)()) F1101_7556;
	R5500[14] = (char *(*)()) F1102_7556;
	R5500[15] = (char *(*)()) F1103_7556;
	R5500[16] = (char *(*)()) F1104_7556;
}

char *(*R5501[17])();
void R5501_init () {
	R5501[0] = (char *(*)()) F1091_7474;
	R5501[1] = (char *(*)()) F1092_7474;
	R5501[12] = (char *(*)()) F1100_7557;
	R5501[13] = (char *(*)()) F1101_7557;
	R5501[14] = (char *(*)()) F1102_7557;
	R5501[15] = (char *(*)()) F1103_7557;
	R5501[16] = (char *(*)()) F1104_7557;
}

char *(*R5503[17])();
void R5503_init () {
	R5503[0] = (char *(*)()) F1091_7477;
	R5503[1] = (char *(*)()) F1092_7477;
	R5503[12] = (char *(*)()) F1100_7560;
	R5503[13] = (char *(*)()) F1101_7560;
	R5503[14] = (char *(*)()) F1102_7560;
	R5503[15] = (char *(*)()) F1103_7560;
	R5503[16] = (char *(*)()) F1104_7560;
}

char *(*R5504[17])();
void R5504_init () {
	R5504[0] = (char *(*)()) F1091_7478;
	R5504[1] = (char *(*)()) F1092_7478;
	R5504[12] = (char *(*)()) F1100_7561;
	R5504[13] = (char *(*)()) F1101_7561;
	R5504[14] = (char *(*)()) F1102_7561;
	R5504[15] = (char *(*)()) F1103_7561;
	R5504[16] = (char *(*)()) F1104_7561;
}

char *(*R5505[17])();
void R5505_init () {
	R5505[0] = (char *(*)()) F1091_7479;
	R5505[1] = (char *(*)()) F1092_7479;
	R5505[12] = (char *(*)()) F1100_7562;
	R5505[13] = (char *(*)()) F1101_7562;
	R5505[14] = (char *(*)()) F1102_7562;
	R5505[15] = (char *(*)()) F1103_7562;
	R5505[16] = (char *(*)()) F1104_7562;
}

char *(*R5506[17])();
void R5506_init () {
	R5506[0] = (char *(*)()) F1091_7480;
	R5506[1] = (char *(*)()) F1092_7480;
	R5506[12] = (char *(*)()) F1100_7563;
	R5506[13] = (char *(*)()) F1101_7563;
	R5506[14] = (char *(*)()) F1102_7563;
	R5506[15] = (char *(*)()) F1103_7563;
	R5506[16] = (char *(*)()) F1104_7563;
}

char *(*R5507[17])();
void R5507_init () {
	R5507[0] = (char *(*)()) F1091_7481;
	R5507[1] = (char *(*)()) F1092_7481;
	R5507[12] = (char *(*)()) F1100_7564;
	R5507[13] = (char *(*)()) F1101_7564;
	R5507[14] = (char *(*)()) F1102_7564;
	R5507[15] = (char *(*)()) F1103_7564;
	R5507[16] = (char *(*)()) F1104_7564;
}

char *(*R5518[17])();
void R5518_init () {
	R5518[0] = (char *(*)()) F1084_7407;
	R5518[1] = (char *(*)()) F1087_7407;
	R5518[12] = (char *(*)()) F1084_7407;
	R5518[13] = (char *(*)()) F1085_7407;
	R5518[14] = (char *(*)()) F1086_7407;
	R5518[15] = (char *(*)()) F1087_7407;
	R5518[16] = (char *(*)()) F1088_7407;
}

char *(*R5522[17])();
void R5522_init () {
	R5522[0] = (char *(*)()) F1084_7425;
	R5522[1] = (char *(*)()) F1087_7425;
	R5522[12] = (char *(*)()) F1084_7425;
	R5522[13] = (char *(*)()) F1085_7425;
	R5522[14] = (char *(*)()) F1086_7425;
	R5522[15] = (char *(*)()) F1087_7425;
	R5522[16] = (char *(*)()) F1088_7425;
}

char *(*R5532[2])();
void R5532_init () {
	R5532[0] = (char *(*)()) F1091_7485;
	R5532[1] = (char *(*)()) F1092_7485;
}

char *(*R5540[5])();
void R5540_init () {
	R5540[0] = (char *(*)()) F1095_7496;
	R5540[1] = (char *(*)()) F1096_7496;
	R5540[2] = (char *(*)()) F1097_7496;
	R5540[3] = (char *(*)()) F1098_7496;
	R5540[4] = (char *(*)()) F1099_7496;
}

char *(*R5562[5])();
void R5562_init () {
	R5562[0] = (char *(*)()) F1100_7569;
	R5562[1] = (char *(*)()) F1101_7569;
	R5562[2] = (char *(*)()) F1102_7569;
	R5562[3] = (char *(*)()) F1103_7569;
	R5562[4] = (char *(*)()) F1104_7569;
}

char *(*R6176[37])();
void R6176_init () {
	R6176[0] = (char *(*)()) F1133_8315;
	R6176[1] = (char *(*)()) F1134_8318;
	R6176[2] = (char *(*)()) F1135_8321;
	R6176[3] = (char *(*)()) F1136_8324;
	R6176[4] = (char *(*)()) F1137_8327;
	R6176[5] = (char *(*)()) F1138_8330;
	R6176[6] = (char *(*)()) F1139_8333;
	R6176[7] = (char *(*)()) F1140_8336;
	R6176[8] = (char *(*)()) F1141_8339;
	R6176[9] = (char *(*)()) F1142_8342;
	R6176[10] = (char *(*)()) F1143_8345;
	R6176[11] = (char *(*)()) F1144_8348;
	R6176[12] = (char *(*)()) F1145_8351;
	R6176[13] = (char *(*)()) F1146_8354;
	R6176[14] = (char *(*)()) F1147_8357;
	R6176[15] = (char *(*)()) F1148_8360;
	R6176[16] = (char *(*)()) F1149_8363;
	R6176[17] = (char *(*)()) F1150_8366;
	R6176[18] = (char *(*)()) F1151_8369;
	R6176[19] = (char *(*)()) F1152_8372;
	R6176[20] = (char *(*)()) F1153_8375;
	R6176[21] = (char *(*)()) F1154_8378;
	R6176[22] = (char *(*)()) F1155_8381;
	R6176[23] = (char *(*)()) F1156_8384;
	R6176[24] = (char *(*)()) F1157_8387;
	R6176[25] = (char *(*)()) F1158_8390;
	R6176[26] = (char *(*)()) F1159_8393;
	R6176[27] = (char *(*)()) F1160_8396;
	R6176[28] = (char *(*)()) F1161_8399;
	R6176[29] = (char *(*)()) F1162_8402;
	R6176[30] = (char *(*)()) F1163_8405;
	R6176[31] = (char *(*)()) F1164_8408;
	R6176[32] = (char *(*)()) F1165_8411;
	R6176[33] = (char *(*)()) F1166_8414;
	R6176[34] = (char *(*)()) F1167_8417;
	R6176[35] = (char *(*)()) F1168_8420;
	R6176[36] = (char *(*)()) F1169_8423;
}
char *(*R2[1177])();
void R2_init () {}
char *(*R6[1177])();
void R6_init () {}

char *(*R3[1177])();
void R3_init () {
	R3[209] = (char *(*)()) F210_2097;
	R3[941] = (char *(*)()) F942_6252;
	R3[960] = (char *(*)()) F253_2675;
	R3[965] = (char *(*)()) F253_2675;
}

char *(*R4[1177])();
void R4_init () {
	R4[5] = (char *(*)()) F1_15;
	R4[7] = (char *(*)()) F1_15;
	{long i; for (i = 11; i < 13; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 18; i < 27; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 29; i < 32; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 45; i < 47; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 65; i < 67; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 71; i < 73; i++) R4[i] = (char *(*)()) F1_15;}
	R4[85] = (char *(*)()) F1_15;
	{long i; for (i = 97; i < 103; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 112; i < 114; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 129; i < 131; i++) R4[i] = (char *(*)()) F1_15;}
	R4[132] = (char *(*)()) F1_15;
	R4[134] = (char *(*)()) F1_15;
	R4[136] = (char *(*)()) F1_15;
	{long i; for (i = 139; i < 141; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 144; i < 149; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 151; i < 154; i++) R4[i] = (char *(*)()) F1_15;}
	R4[158] = (char *(*)()) F1_15;
	{long i; for (i = 166; i < 170; i++) R4[i] = (char *(*)()) F1_15;}
	R4[173] = (char *(*)()) F1_15;
	{long i; for (i = 175; i < 178; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 179; i < 181; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 183; i < 185; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 186; i < 189; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 190; i < 194; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 195; i < 197; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 198; i < 201; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 202; i < 208; i++) R4[i] = (char *(*)()) F1_15;}
	R4[209] = (char *(*)()) F210_2016;
	{long i; for (i = 211; i < 215; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 218; i < 220; i++) R4[i] = (char *(*)()) F1_15;}
	R4[223] = (char *(*)()) F1_15;
	R4[242] = (char *(*)()) F1_15;
	R4[245] = (char *(*)()) F246_2535;
	{long i; for (i = 249; i < 252; i++) R4[i] = (char *(*)()) F1_15;}
	R4[334] = (char *(*)()) F1_15;
	R4[337] = (char *(*)()) F1_15;
	{long i; for (i = 381; i < 386; i++) R4[i] = (char *(*)()) F1_15;}
	R4[578] = (char *(*)()) F1_15;
	{long i; for (i = 656; i < 668; i++) R4[i] = (char *(*)()) F1_15;}
	R4[681] = (char *(*)()) F682_3672;
	R4[682] = (char *(*)()) F683_3672;
	R4[683] = (char *(*)()) F684_3672;
	R4[684] = (char *(*)()) F685_3672;
	R4[685] = (char *(*)()) F686_3672;
	R4[686] = (char *(*)()) F687_3672;
	R4[687] = (char *(*)()) F688_3672;
	R4[688] = (char *(*)()) F689_3672;
	R4[689] = (char *(*)()) F690_3672;
	R4[690] = (char *(*)()) F691_3672;
	R4[691] = (char *(*)()) F692_3672;
	R4[692] = (char *(*)()) F693_3672;
	R4[693] = (char *(*)()) F682_3672;
	R4[694] = (char *(*)()) F684_3672;
	R4[695] = (char *(*)()) F685_3672;
	R4[696] = (char *(*)()) F686_3672;
	R4[697] = (char *(*)()) F687_3672;
	R4[698] = (char *(*)()) F688_3672;
	R4[765] = (char *(*)()) F766_3953;
	R4[766] = (char *(*)()) F767_3953;
	R4[767] = (char *(*)()) F768_3953;
	R4[768] = (char *(*)()) F769_3953;
	R4[769] = (char *(*)()) F770_3953;
	R4[772] = (char *(*)()) F766_3953;
	{long i; for (i = 776; i < 809; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 810; i < 812; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 813; i < 815; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 816; i < 818; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 819; i < 821; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 822; i < 824; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 825; i < 827; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 828; i < 830; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 831; i < 833; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 834; i < 836; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 837; i < 839; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 840; i < 842; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 843; i < 845; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 846; i < 848; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 849; i < 881; i++) R4[i] = (char *(*)()) F1_15;}
	R4[890] = (char *(*)()) F891_5555;
	R4[891] = (char *(*)()) F890_5536;
	R4[893] = (char *(*)()) F894_5720;
	R4[894] = (char *(*)()) F893_5704;
	{long i; for (i = 900; i < 903; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 907; i < 909; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 915; i < 926; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 928; i < 930; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 934; i < 943; i++) R4[i] = (char *(*)()) F1_15;}
	R4[960] = (char *(*)()) F1_15;
	R4[965] = (char *(*)()) F1_15;
	R4[1007] = (char *(*)()) F970_6768;
	R4[1008] = (char *(*)()) F971_6768;
	R4[1019] = (char *(*)()) F970_6768;
	R4[1020] = (char *(*)()) F971_6768;
	R4[1021] = (char *(*)()) F970_6768;
	R4[1022] = (char *(*)()) F971_6768;
	R4[1023] = (char *(*)()) F973_6768;
	R4[1026] = (char *(*)()) F970_6768;
	R4[1027] = (char *(*)()) F971_6768;
	R4[1028] = (char *(*)()) F970_6768;
	R4[1076] = (char *(*)()) F1077_7153;
	R4[1080] = (char *(*)()) F1081_7232;
	R4[1081] = (char *(*)()) F1082_7269;
	R4[1082] = (char *(*)()) F1083_7269;
	R4[1092] = (char *(*)()) F1084_7355;
	R4[1093] = (char *(*)()) F1087_7355;
	R4[1104] = (char *(*)()) F1095_7522;
	R4[1105] = (char *(*)()) F1096_7522;
	R4[1106] = (char *(*)()) F1097_7522;
	R4[1107] = (char *(*)()) F1098_7522;
	R4[1108] = (char *(*)()) F1099_7522;
	{long i; for (i = 1112; i < 1115; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1122] = (char *(*)()) F1_15;
	{long i; for (i = 1129; i < 1131; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1132; i < 1170; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1175] = (char *(*)()) F1176_8701;
}

char *(*R5[1177])();
void R5_init () {
	R5[5] = (char *(*)()) F1_8;
	R5[7] = (char *(*)()) F1_8;
	{long i; for (i = 11; i < 13; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 18; i < 27; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 29; i < 32; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 45; i < 47; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 65; i < 67; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 71; i < 73; i++) R5[i] = (char *(*)()) F1_8;}
	R5[85] = (char *(*)()) F1_8;
	{long i; for (i = 97; i < 103; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 112; i < 114; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 129; i < 131; i++) R5[i] = (char *(*)()) F1_8;}
	R5[132] = (char *(*)()) F1_8;
	R5[134] = (char *(*)()) F1_8;
	R5[136] = (char *(*)()) F1_8;
	{long i; for (i = 139; i < 141; i++) R5[i] = (char *(*)()) F1_8;}
	R5[144] = (char *(*)()) F145_1613;
	{long i; for (i = 145; i < 147; i++) R5[i] = (char *(*)()) F143_1596;}
	{long i; for (i = 147; i < 149; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 151; i < 154; i++) R5[i] = (char *(*)()) F1_8;}
	R5[158] = (char *(*)()) F1_8;
	{long i; for (i = 166; i < 170; i++) R5[i] = (char *(*)()) F1_8;}
	R5[173] = (char *(*)()) F1_8;
	{long i; for (i = 175; i < 178; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 179; i < 181; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 183; i < 185; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 186; i < 189; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 190; i < 194; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 195; i < 197; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 198; i < 201; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 202; i < 208; i++) R5[i] = (char *(*)()) F1_8;}
	R5[209] = (char *(*)()) F210_2015;
	{long i; for (i = 211; i < 215; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 218; i < 220; i++) R5[i] = (char *(*)()) F1_8;}
	R5[223] = (char *(*)()) F1_8;
	R5[242] = (char *(*)()) F243_2389;
	R5[245] = (char *(*)()) F246_2534;
	{long i; for (i = 249; i < 252; i++) R5[i] = (char *(*)()) F1_8;}
	R5[334] = (char *(*)()) F1_8;
	R5[337] = (char *(*)()) F1_8;
	{long i; for (i = 381; i < 386; i++) R5[i] = (char *(*)()) F1_8;}
	R5[578] = (char *(*)()) F1_8;
	{long i; for (i = 656; i < 668; i++) R5[i] = (char *(*)()) F1_8;}
	R5[681] = (char *(*)()) F682_3634;
	R5[682] = (char *(*)()) F683_3634;
	R5[683] = (char *(*)()) F684_3634;
	R5[684] = (char *(*)()) F685_3634;
	R5[685] = (char *(*)()) F686_3634;
	R5[686] = (char *(*)()) F687_3634;
	R5[687] = (char *(*)()) F688_3634;
	R5[688] = (char *(*)()) F689_3634;
	R5[689] = (char *(*)()) F690_3634;
	R5[690] = (char *(*)()) F691_3634;
	R5[691] = (char *(*)()) F692_3634;
	R5[692] = (char *(*)()) F693_3634;
	R5[693] = (char *(*)()) F682_3634;
	R5[694] = (char *(*)()) F684_3634;
	R5[695] = (char *(*)()) F685_3634;
	R5[696] = (char *(*)()) F686_3634;
	R5[697] = (char *(*)()) F687_3634;
	R5[698] = (char *(*)()) F688_3634;
	R5[765] = (char *(*)()) F766_3919;
	R5[766] = (char *(*)()) F767_3919;
	R5[767] = (char *(*)()) F768_3919;
	R5[768] = (char *(*)()) F769_3919;
	R5[769] = (char *(*)()) F770_3919;
	R5[772] = (char *(*)()) F766_3919;
	R5[776] = (char *(*)()) F143_1596;
	R5[777] = (char *(*)()) F778_4114;
	R5[778] = (char *(*)()) F779_4114;
	R5[779] = (char *(*)()) F780_4114;
	R5[780] = (char *(*)()) F781_4114;
	R5[781] = (char *(*)()) F782_4114;
	R5[782] = (char *(*)()) F783_4114;
	R5[783] = (char *(*)()) F784_4114;
	R5[784] = (char *(*)()) F785_4114;
	R5[785] = (char *(*)()) F786_4114;
	R5[786] = (char *(*)()) F787_4114;
	R5[787] = (char *(*)()) F788_4114;
	R5[788] = (char *(*)()) F789_4114;
	R5[789] = (char *(*)()) F790_4114;
	R5[790] = (char *(*)()) F791_4114;
	R5[791] = (char *(*)()) F792_4114;
	R5[792] = (char *(*)()) F793_4114;
	R5[793] = (char *(*)()) F794_4114;
	R5[794] = (char *(*)()) F795_4114;
	R5[795] = (char *(*)()) F796_4114;
	R5[796] = (char *(*)()) F797_4114;
	R5[797] = (char *(*)()) F798_4114;
	R5[798] = (char *(*)()) F799_4114;
	R5[799] = (char *(*)()) F800_4114;
	R5[800] = (char *(*)()) F801_4114;
	R5[801] = (char *(*)()) F802_4114;
	R5[802] = (char *(*)()) F803_4114;
	R5[803] = (char *(*)()) F804_4114;
	R5[804] = (char *(*)()) F805_4114;
	R5[805] = (char *(*)()) F806_4114;
	R5[806] = (char *(*)()) F807_4114;
	R5[807] = (char *(*)()) F808_4114;
	R5[808] = (char *(*)()) F809_4157;
	{long i; for (i = 810; i < 812; i++) R5[i] = (char *(*)()) F810_4275;}
	{long i; for (i = 813; i < 815; i++) R5[i] = (char *(*)()) F813_4373;}
	{long i; for (i = 816; i < 818; i++) R5[i] = (char *(*)()) F816_4472;}
	{long i; for (i = 819; i < 821; i++) R5[i] = (char *(*)()) F819_4571;}
	{long i; for (i = 822; i < 824; i++) R5[i] = (char *(*)()) F822_4670;}
	{long i; for (i = 825; i < 827; i++) R5[i] = (char *(*)()) F825_4764;}
	{long i; for (i = 828; i < 830; i++) R5[i] = (char *(*)()) F828_4858;}
	{long i; for (i = 831; i < 833; i++) R5[i] = (char *(*)()) F831_4953;}
	{long i; for (i = 834; i < 836; i++) R5[i] = (char *(*)()) F834_5052;}
	{long i; for (i = 837; i < 839; i++) R5[i] = (char *(*)()) F837_5118;}
	{long i; for (i = 840; i < 842; i++) R5[i] = (char *(*)()) F840_5179;}
	{long i; for (i = 843; i < 845; i++) R5[i] = (char *(*)()) F843_5219;}
	{long i; for (i = 846; i < 848; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 849; i < 881; i++) R5[i] = (char *(*)()) F849_5285;}
	{long i; for (i = 890; i < 892; i++) R5[i] = (char *(*)()) F890_5521;}
	{long i; for (i = 893; i < 895; i++) R5[i] = (char *(*)()) F893_5689;}
	{long i; for (i = 900; i < 903; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 907; i < 909; i++) R5[i] = (char *(*)()) F1_8;}
	R5[915] = (char *(*)()) F916_6005;
	{long i; for (i = 916; i < 926; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 928; i < 930; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 934; i < 942; i++) R5[i] = (char *(*)()) F1_8;}
	R5[942] = (char *(*)()) F943_6309;
	R5[960] = (char *(*)()) F1_8;
	R5[965] = (char *(*)()) F1_8;
	R5[1007] = (char *(*)()) F970_6769;
	R5[1008] = (char *(*)()) F971_6769;
	R5[1019] = (char *(*)()) F970_6769;
	R5[1020] = (char *(*)()) F971_6769;
	R5[1021] = (char *(*)()) F970_6769;
	R5[1022] = (char *(*)()) F971_6769;
	R5[1023] = (char *(*)()) F973_6769;
	R5[1026] = (char *(*)()) F970_6769;
	R5[1027] = (char *(*)()) F971_6769;
	R5[1028] = (char *(*)()) F970_6769;
	R5[1076] = (char *(*)()) F1077_7154;
	R5[1080] = (char *(*)()) F1081_7233;
	R5[1081] = (char *(*)()) F1082_7270;
	R5[1082] = (char *(*)()) F1083_7270;
	R5[1092] = (char *(*)()) F1089_7436;
	R5[1093] = (char *(*)()) F1090_7436;
	R5[1104] = (char *(*)()) F1095_7510;
	R5[1105] = (char *(*)()) F1096_7510;
	R5[1106] = (char *(*)()) F1097_7510;
	R5[1107] = (char *(*)()) F1098_7510;
	R5[1108] = (char *(*)()) F1099_7510;
	{long i; for (i = 1112; i < 1115; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1122] = (char *(*)()) F1_8;
	{long i; for (i = 1129; i < 1131; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1132; i < 1170; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1175] = (char *(*)()) F1176_8658;
}


#ifdef __cplusplus
}
#endif
