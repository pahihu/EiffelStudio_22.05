/*
 * Code for class KL_EQUALITY_TESTER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl493.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_EQUALITY_TESTER}.test */
EIF_BOOLEAN F213_2106 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		return (EIF_BOOLEAN) (arg1 == arg2);
	}/* NOTREACHED */
	
}

void EIF_Minit493 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
