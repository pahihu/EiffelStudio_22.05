
#ifndef _C10_re499_
#define _C10_re499_

#ifdef __cplusplus
extern "C" {
#endif

extern void F370_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F370_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F370_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F370_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F370_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F370_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F370_2982(EIF_REFERENCE);
extern void F370_2987(EIF_REFERENCE);
extern void EIF_Minit499(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
