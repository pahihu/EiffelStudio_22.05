
#ifndef _C10_ha490_
#define _C10_ha490_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F383_2996(EIF_REFERENCE);
extern EIF_REFERENCE F383_2997(EIF_REFERENCE);
extern EIF_BOOLEAN F383_2999(EIF_REFERENCE);
extern void F383_3000(EIF_REFERENCE);
extern EIF_REFERENCE F383_3001(EIF_REFERENCE);
extern void EIF_Minit490(void);
extern EIF_BOOLEAN F369_2982(EIF_REFERENCE);
extern EIF_INTEGER_32 F767_3941(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F767_3940(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R3006[])();
extern char *(*R2567[])();

#ifdef __cplusplus
}
#endif

#endif
