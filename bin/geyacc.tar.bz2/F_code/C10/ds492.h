
#ifndef _C10_ds492_
#define _C10_ds492_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1046_6933(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit492(void);

#ifdef __cplusplus
}
#endif

#endif
