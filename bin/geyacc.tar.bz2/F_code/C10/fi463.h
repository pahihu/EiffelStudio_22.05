
#ifndef _C10_fi463_
#define _C10_fi463_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F581_3153(EIF_REFERENCE);
extern void EIF_Minit463(void);
extern char *(*R2796[])();

#ifdef __cplusplus
}
#endif

#endif
