
#ifndef _C10_re474_
#define _C10_re474_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F607_3166(EIF_REFERENCE);
extern void EIF_Minit474(void);
extern EIF_INTEGER_32 F683_3632(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
