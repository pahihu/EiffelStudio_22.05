
#ifndef _C10_to470_
#define _C10_to470_

#ifdef __cplusplus
extern "C" {
#endif

extern void F230_2364(EIF_REFERENCE, EIF_INTEGER_32);
extern void F230_2365(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F230_2371(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit470(void);
extern void F658_3531(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2180[];
extern EIF_TYPE_INDEX *Y2180_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
