
#ifndef _C10_ds491_
#define _C10_ds491_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1108_7570(EIF_REFERENCE);
extern EIF_INTEGER_32 F1108_7573(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit491(void);
extern void F1002_6808(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y730[];
extern EIF_TYPE_INDEX *Y730_gen_type [];
extern EIF_TYPE_INDEX Y5255[];
extern EIF_TYPE_INDEX *Y5255_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
