
#ifndef _C10_co451_
#define _C10_co451_

#ifdef __cplusplus
extern "C" {
#endif

extern void F438_3055(EIF_REFERENCE);
extern void EIF_Minit451(void);
extern long O2734[];

#ifdef __cplusplus
}
#endif

#endif
