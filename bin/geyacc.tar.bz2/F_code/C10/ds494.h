
#ifndef _C10_ds494_
#define _C10_ds494_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1031_6885(EIF_REFERENCE);
extern void EIF_Minit494(void);
extern char *(*R5246[])();

#ifdef __cplusplus
}
#endif

#endif
