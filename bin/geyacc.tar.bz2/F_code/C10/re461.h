
#ifndef _C10_re461_
#define _C10_re461_

#ifdef __cplusplus
extern "C" {
#endif

extern void F369_2968(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F369_2970(EIF_REFERENCE);
extern EIF_INTEGER_32 F369_2971(EIF_REFERENCE);
extern EIF_INTEGER_32 F369_2972(EIF_REFERENCE);
extern EIF_INTEGER_32 F369_2973(EIF_REFERENCE);
extern EIF_BOOLEAN F369_2981(EIF_REFERENCE);
extern EIF_BOOLEAN F369_2982(EIF_REFERENCE);
extern void F369_2987(EIF_REFERENCE);
extern void EIF_Minit461(void);
extern char *(*R3007[])();
extern char *(*R3008[])();

#ifdef __cplusplus
}
#endif

#endif
