
#ifndef _C10_kl493_
#define _C10_kl493_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F213_2106(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit493(void);

#ifdef __cplusplus
}
#endif

#endif
