#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1224[1205];
void O1224_init () {
	O1224[0] = 0;
	{long i; for (i = 1077; i < 1079; i++) O1224[i] = 0;}
	{long i; for (i = 1107; i < 1112; i++) O1224[i] = 0;}
	O1224[1112] =  + _REFACS_1_;
	{long i; for (i = 1113; i < 1115; i++) O1224[i] = 0;}
	O1224[1115] =  + _REFACS_1_;
	{long i; for (i = 1116; i < 1140; i++) O1224[i] = 0;}
	O1224[1140] =  + _REFACS_4_;
	O1224[1141] =  + _REFACS_2_;
	O1224[1142] =  + _REFACS_1_;
	{long i; for (i = 1143; i < 1147; i++) O1224[i] = 0;}
	{long i; for (i = 1147; i < 1149; i++) O1224[i] =  + _REFACS_2_;}
	O1224[1149] =  + _REFACS_1_;
	O1224[1150] =  + _REFACS_2_;
	O1224[1151] =  + _REFACS_6_;
	O1224[1152] =  + _REFACS_1_;
	O1224[1153] =  + _REFACS_4_;
	{long i; for (i = 1154; i < 1156; i++) O1224[i] = 0;}
	O1224[1156] =  + _REFACS_4_;
	O1224[1157] =  + _REFACS_2_;
	O1224[1158] =  + _REFACS_1_;
	{long i; for (i = 1159; i < 1162; i++) O1224[i] = 0;}
	{long i; for (i = 1162; i < 1164; i++) O1224[i] =  + _REFACS_2_;}
	{long i; for (i = 1164; i < 1166; i++) O1224[i] =  + _REFACS_1_;}
	O1224[1166] =  + _REFACS_4_;
	O1224[1167] =  + _REFACS_2_;
	O1224[1168] =  + _REFACS_6_;
	{long i; for (i = 1191; i < 1195; i++) O1224[i] =  + _REFACS_5_;}
	O1224[1196] = 0;
	O1224[1199] = 0;
	O1224[1201] = 0;
	O1224[1204] = 0;
}

long O1225[1205];
void O1225_init () {
	O1225[0] =  + _REFACS_1_;
	{long i; for (i = 1077; i < 1079; i++) O1225[i] =  + _REFACS_1_;}
	{long i; for (i = 1107; i < 1112; i++) O1225[i] =  + _REFACS_1_;}
	O1225[1112] =  + _REFACS_2_;
	{long i; for (i = 1113; i < 1115; i++) O1225[i] =  + _REFACS_1_;}
	O1225[1115] =  + _REFACS_2_;
	{long i; for (i = 1116; i < 1140; i++) O1225[i] =  + _REFACS_1_;}
	O1225[1140] =  + _REFACS_5_;
	O1225[1141] =  + _REFACS_3_;
	O1225[1142] =  + _REFACS_2_;
	{long i; for (i = 1143; i < 1147; i++) O1225[i] =  + _REFACS_1_;}
	{long i; for (i = 1147; i < 1149; i++) O1225[i] =  + _REFACS_3_;}
	O1225[1149] =  + _REFACS_2_;
	O1225[1150] =  + _REFACS_3_;
	O1225[1151] =  + _REFACS_7_;
	O1225[1152] =  + _REFACS_2_;
	O1225[1153] =  + _REFACS_5_;
	{long i; for (i = 1154; i < 1156; i++) O1225[i] =  + _REFACS_1_;}
	O1225[1156] =  + _REFACS_5_;
	O1225[1157] =  + _REFACS_3_;
	O1225[1158] =  + _REFACS_2_;
	{long i; for (i = 1159; i < 1162; i++) O1225[i] =  + _REFACS_1_;}
	{long i; for (i = 1162; i < 1164; i++) O1225[i] =  + _REFACS_3_;}
	{long i; for (i = 1164; i < 1166; i++) O1225[i] =  + _REFACS_2_;}
	O1225[1166] =  + _REFACS_5_;
	O1225[1167] =  + _REFACS_3_;
	O1225[1168] =  + _REFACS_7_;
	{long i; for (i = 1191; i < 1195; i++) O1225[i] =  + _REFACS_6_;}
	O1225[1196] =  + _REFACS_1_;
	O1225[1199] =  + _REFACS_1_;
	O1225[1201] =  + _REFACS_1_;
	O1225[1204] =  + _REFACS_1_;
}

long O1227[1188];
void O1227_init () {
	O1227[0] = 0;
	{long i; for (i = 1178; i < 1182; i++) O1227[i] =  + _REFACS_3_;}
	O1227[1182] =  + _REFACS_4_;
	{long i; for (i = 1183; i < 1187; i++) O1227[i] =  + _REFACS_3_;}
	O1227[1187] =  + _REFACS_4_;
}

long O1267[1196];
void O1267_init () {
	O1267[0] = 0;
	{long i; for (i = 1096; i < 1098; i++) O1267[i] = 0;}
	{long i; for (i = 1098; i < 1100; i++) O1267[i] =  + _REFACS_2_;}
	{long i; for (i = 1100; i < 1103; i++) O1267[i] =  + _REFACS_3_;}
	O1267[1103] =  + _REFACS_4_;
	{long i; for (i = 1104; i < 1106; i++) O1267[i] =  + _REFACS_3_;}
	O1267[1106] =  + _REFACS_4_;
	O1267[1107] =  + _REFACS_3_;
	{long i; for (i = 1108; i < 1130; i++) O1267[i] =  + _REFACS_4_;}
	O1267[1130] =  + _REFACS_2_;
	O1267[1131] =  + _REFACS_6_;
	O1267[1132] =  + _REFACS_4_;
	{long i; for (i = 1133; i < 1135; i++) O1267[i] =  + _REFACS_3_;}
	{long i; for (i = 1135; i < 1138; i++) O1267[i] =  + _REFACS_2_;}
	{long i; for (i = 1138; i < 1140; i++) O1267[i] =  + _REFACS_4_;}
	O1267[1140] =  + _REFACS_3_;
	O1267[1141] =  + _REFACS_4_;
	O1267[1142] =  + _REFACS_8_;
	O1267[1143] =  + _REFACS_3_;
	O1267[1144] =  + _REFACS_6_;
	O1267[1145] =  + _REFACS_2_;
	O1267[1146] =  + _REFACS_3_;
	O1267[1147] =  + _REFACS_6_;
	O1267[1148] =  + _REFACS_4_;
	O1267[1149] =  + _REFACS_3_;
	{long i; for (i = 1150; i < 1153; i++) O1267[i] =  + _REFACS_2_;}
	{long i; for (i = 1153; i < 1155; i++) O1267[i] =  + _REFACS_4_;}
	{long i; for (i = 1155; i < 1157; i++) O1267[i] =  + _REFACS_3_;}
	O1267[1157] =  + _REFACS_6_;
	O1267[1158] =  + _REFACS_4_;
	O1267[1159] =  + _REFACS_8_;
	O1267[1160] =  + _REFACS_3_;
	{long i; for (i = 1161; i < 1163; i++) O1267[i] =  + _REFACS_5_;}
	O1267[1163] =  + _REFACS_3_;
	{long i; for (i = 1164; i < 1168; i++) O1267[i] =  + _REFACS_7_;}
	{long i; for (i = 1168; i < 1170; i++) O1267[i] =  + _REFACS_3_;}
	{long i; for (i = 1170; i < 1174; i++) O1267[i] =  + _REFACS_4_;}
	O1267[1174] =  + _REFACS_5_;
	{long i; for (i = 1175; i < 1179; i++) O1267[i] =  + _REFACS_4_;}
	{long i; for (i = 1179; i < 1182; i++) O1267[i] =  + _REFACS_5_;}
	{long i; for (i = 1182; i < 1186; i++) O1267[i] =  + _REFACS_7_;}
	O1267[1187] =  + _REFACS_2_;
	O1267[1190] =  + _REFACS_2_;
	O1267[1192] =  + _REFACS_2_;
	O1267[1195] =  + _REFACS_2_;
}

long O1269[1196];
void O1269_init () {
	O1269[0] =  + _REFACS_1_;
	{long i; for (i = 1096; i < 1098; i++) O1269[i] =  + _REFACS_1_;}
	{long i; for (i = 1098; i < 1100; i++) O1269[i] =  + _REFACS_3_;}
	{long i; for (i = 1100; i < 1103; i++) O1269[i] =  + _REFACS_4_;}
	O1269[1103] =  + _REFACS_5_;
	{long i; for (i = 1104; i < 1106; i++) O1269[i] =  + _REFACS_4_;}
	O1269[1106] =  + _REFACS_5_;
	O1269[1107] =  + _REFACS_4_;
	{long i; for (i = 1108; i < 1130; i++) O1269[i] =  + _REFACS_5_;}
	O1269[1130] =  + _REFACS_3_;
	O1269[1131] =  + _REFACS_7_;
	O1269[1132] =  + _REFACS_5_;
	{long i; for (i = 1133; i < 1135; i++) O1269[i] =  + _REFACS_4_;}
	{long i; for (i = 1135; i < 1138; i++) O1269[i] =  + _REFACS_3_;}
	{long i; for (i = 1138; i < 1140; i++) O1269[i] =  + _REFACS_5_;}
	O1269[1140] =  + _REFACS_4_;
	O1269[1141] =  + _REFACS_5_;
	O1269[1142] =  + _REFACS_9_;
	O1269[1143] =  + _REFACS_4_;
	O1269[1144] =  + _REFACS_7_;
	O1269[1145] =  + _REFACS_3_;
	O1269[1146] =  + _REFACS_4_;
	O1269[1147] =  + _REFACS_7_;
	O1269[1148] =  + _REFACS_5_;
	O1269[1149] =  + _REFACS_4_;
	{long i; for (i = 1150; i < 1153; i++) O1269[i] =  + _REFACS_3_;}
	{long i; for (i = 1153; i < 1155; i++) O1269[i] =  + _REFACS_5_;}
	{long i; for (i = 1155; i < 1157; i++) O1269[i] =  + _REFACS_4_;}
	O1269[1157] =  + _REFACS_7_;
	O1269[1158] =  + _REFACS_5_;
	O1269[1159] =  + _REFACS_9_;
	O1269[1160] =  + _REFACS_4_;
	{long i; for (i = 1161; i < 1163; i++) O1269[i] =  + _REFACS_6_;}
	O1269[1163] =  + _REFACS_4_;
	{long i; for (i = 1164; i < 1168; i++) O1269[i] =  + _REFACS_8_;}
	{long i; for (i = 1168; i < 1170; i++) O1269[i] =  + _REFACS_4_;}
	{long i; for (i = 1170; i < 1174; i++) O1269[i] =  + _REFACS_5_;}
	O1269[1174] =  + _REFACS_6_;
	{long i; for (i = 1175; i < 1179; i++) O1269[i] =  + _REFACS_5_;}
	{long i; for (i = 1179; i < 1182; i++) O1269[i] =  + _REFACS_6_;}
	{long i; for (i = 1182; i < 1186; i++) O1269[i] =  + _REFACS_8_;}
	O1269[1187] =  + _REFACS_3_;
	O1269[1190] =  + _REFACS_3_;
	O1269[1192] =  + _REFACS_3_;
	O1269[1195] =  + _REFACS_3_;
}

long O1273[1196];
void O1273_init () {
	O1273[0] =  + _REFACS_3_;
	{long i; for (i = 1096; i < 1098; i++) O1273[i] =  + _REFACS_3_;}
	{long i; for (i = 1098; i < 1100; i++) O1273[i] =  + _REFACS_5_;}
	{long i; for (i = 1100; i < 1103; i++) O1273[i] =  + _REFACS_6_;}
	O1273[1103] =  + _REFACS_7_;
	{long i; for (i = 1104; i < 1106; i++) O1273[i] =  + _REFACS_6_;}
	O1273[1106] =  + _REFACS_7_;
	O1273[1107] =  + _REFACS_6_;
	{long i; for (i = 1108; i < 1130; i++) O1273[i] =  + _REFACS_7_;}
	O1273[1130] =  + _REFACS_5_;
	O1273[1131] =  + _REFACS_9_;
	O1273[1132] =  + _REFACS_7_;
	{long i; for (i = 1133; i < 1135; i++) O1273[i] =  + _REFACS_6_;}
	{long i; for (i = 1135; i < 1138; i++) O1273[i] =  + _REFACS_5_;}
	{long i; for (i = 1138; i < 1140; i++) O1273[i] =  + _REFACS_7_;}
	O1273[1140] =  + _REFACS_6_;
	O1273[1141] =  + _REFACS_7_;
	O1273[1142] =  + _REFACS_11_;
	O1273[1143] =  + _REFACS_6_;
	O1273[1144] =  + _REFACS_9_;
	O1273[1145] =  + _REFACS_5_;
	O1273[1146] =  + _REFACS_6_;
	O1273[1147] =  + _REFACS_9_;
	O1273[1148] =  + _REFACS_7_;
	O1273[1149] =  + _REFACS_6_;
	{long i; for (i = 1150; i < 1153; i++) O1273[i] =  + _REFACS_5_;}
	{long i; for (i = 1153; i < 1155; i++) O1273[i] =  + _REFACS_7_;}
	{long i; for (i = 1155; i < 1157; i++) O1273[i] =  + _REFACS_6_;}
	O1273[1157] =  + _REFACS_9_;
	O1273[1158] =  + _REFACS_7_;
	O1273[1159] =  + _REFACS_11_;
	O1273[1160] =  + _REFACS_6_;
	{long i; for (i = 1161; i < 1163; i++) O1273[i] =  + _REFACS_8_;}
	O1273[1163] =  + _REFACS_6_;
	{long i; for (i = 1164; i < 1168; i++) O1273[i] =  + _REFACS_10_;}
	{long i; for (i = 1168; i < 1170; i++) O1273[i] =  + _REFACS_6_;}
	{long i; for (i = 1170; i < 1174; i++) O1273[i] =  + _REFACS_7_;}
	O1273[1174] =  + _REFACS_8_;
	{long i; for (i = 1175; i < 1179; i++) O1273[i] =  + _REFACS_7_;}
	{long i; for (i = 1179; i < 1182; i++) O1273[i] =  + _REFACS_8_;}
	{long i; for (i = 1182; i < 1186; i++) O1273[i] =  + _REFACS_10_;}
	O1273[1187] =  + _REFACS_5_;
	O1273[1190] =  + _REFACS_5_;
	O1273[1192] =  + _REFACS_5_;
	O1273[1195] =  + _REFACS_5_;
}

long O1289[1124];
void O1289_init () {
	O1289[0] = 0;
	{long i; for (i = 1112; i < 1114; i++) O1289[i] =  + _REFACS_8_;}
	{long i; for (i = 1114; i < 1116; i++) O1289[i] =  + _REFACS_11_;}
	{long i; for (i = 1120; i < 1122; i++) O1289[i] =  + _REFACS_8_;}
	{long i; for (i = 1122; i < 1124; i++) O1289[i] =  + _REFACS_11_;}
}

long O1291[1124];
void O1291_init () {
	O1291[0] =  + _REFACS_1_;
	{long i; for (i = 1112; i < 1114; i++) O1291[i] =  + _REFACS_9_;}
	{long i; for (i = 1114; i < 1116; i++) O1291[i] =  + _REFACS_12_;}
	{long i; for (i = 1120; i < 1122; i++) O1291[i] =  + _REFACS_9_;}
	{long i; for (i = 1122; i < 1124; i++) O1291[i] =  + _REFACS_12_;}
}

long O1293[1124];
void O1293_init () {
	O1293[0] =  + _REFACS_2_;
	{long i; for (i = 1112; i < 1114; i++) O1293[i] =  + _REFACS_10_;}
	{long i; for (i = 1114; i < 1116; i++) O1293[i] =  + _REFACS_13_;}
	{long i; for (i = 1120; i < 1122; i++) O1293[i] =  + _REFACS_10_;}
	{long i; for (i = 1122; i < 1124; i++) O1293[i] =  + _REFACS_13_;}
}


#ifdef __cplusplus
}
#endif
