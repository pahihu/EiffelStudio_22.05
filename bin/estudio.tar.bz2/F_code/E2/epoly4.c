#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[1297])();
void R28_init () {
	{long i; for (i = 0; i < 4; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 5; i < 10; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 11; i < 17; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 18; i < 21; i++) R28[i] = (char *(*)()) F1_25;}
	R28[23] = (char *(*)()) F1_25;
	{long i; for (i = 25; i < 33; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 35; i < 38; i++) R28[i] = (char *(*)()) F1_25;}
	R28[50] = (char *(*)()) F1_25;
	{long i; for (i = 83; i < 85; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 91; i < 96; i++) R28[i] = (char *(*)()) F1_25;}
	R28[98] = (char *(*)()) F1_25;
	R28[103] = (char *(*)()) F1_25;
	R28[105] = (char *(*)()) F1_25;
	R28[109] = (char *(*)()) F1_25;
	R28[111] = (char *(*)()) F1_25;
	R28[113] = (char *(*)()) F1_25;
	{long i; for (i = 115; i < 117; i++) R28[i] = (char *(*)()) F1_25;}
	R28[119] = (char *(*)()) F1_25;
	R28[123] = (char *(*)()) F1_25;
	R28[127] = (char *(*)()) F1_25;
	R28[135] = (char *(*)()) F1_25;
	R28[143] = (char *(*)()) F1_25;
	{long i; for (i = 149; i < 151; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 152; i < 154; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 156; i < 158; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 162; i < 171; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 173; i < 175; i++) R28[i] = (char *(*)()) F1_25;}
	R28[177] = (char *(*)()) F1_25;
	R28[179] = (char *(*)()) F1_25;
	{long i; for (i = 180; i < 183; i++) R28[i] = (char *(*)()) F184_3405;}
	R28[185] = (char *(*)()) F184_3405;
	{long i; for (i = 187; i < 190; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 191; i < 194; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 195; i < 197; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 199; i < 201; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 202; i < 205; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 206; i < 210; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 211; i < 213; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 214; i < 220; i++) R28[i] = (char *(*)()) F184_3405;}
	{long i; for (i = 221; i < 223; i++) R28[i] = (char *(*)()) F1_25;}
	R28[224] = (char *(*)()) F1_25;
	{long i; for (i = 226; i < 232; i++) R28[i] = (char *(*)()) F1_25;}
	R28[233] = (char *(*)()) F1_25;
	R28[237] = (char *(*)()) F1_25;
	R28[256] = (char *(*)()) F1_25;
	{long i; for (i = 258; i < 260; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 261; i < 263; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 264; i < 270; i++) R28[i] = (char *(*)()) F1_25;}
	R28[273] = (char *(*)()) F1_25;
	R28[287] = (char *(*)()) F1_25;
	R28[308] = (char *(*)()) F1_25;
	{long i; for (i = 536; i < 548; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 597; i < 604; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 606; i < 614; i++) R28[i] = (char *(*)()) F1_25;}
	R28[614] = (char *(*)()) F618_5183;
	{long i; for (i = 615; i < 630; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 632; i < 635; i++) R28[i] = (char *(*)()) F1_25;}
	R28[639] = (char *(*)()) F1_25;
	R28[642] = (char *(*)()) F1_25;
	R28[644] = (char *(*)()) F1_25;
	R28[647] = (char *(*)()) F1_25;
	{long i; for (i = 649; i < 653; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 655; i < 658; i++) R28[i] = (char *(*)()) F1_25;}
	R28[670] = (char *(*)()) F1_25;
	R28[675] = (char *(*)()) F1_25;
	{long i; for (i = 706; i < 727; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 739; i < 777; i++) R28[i] = (char *(*)()) F1_25;}
	R28[778] = (char *(*)()) F782_5612;
	R28[779] = (char *(*)()) F1_25;
	{long i; for (i = 782; i < 794; i++) R28[i] = (char *(*)()) F1_25;}
	R28[842] = (char *(*)()) F1_25;
	{long i; for (i = 844; i < 850; i++) R28[i] = (char *(*)()) F1_25;}
	R28[852] = (char *(*)()) F1_25;
	R28[854] = (char *(*)()) F1_25;
	{long i; for (i = 857; i < 859; i++) R28[i] = (char *(*)()) F1_25;}
	R28[860] = (char *(*)()) F1_25;
	R28[863] = (char *(*)()) F1_25;
	R28[865] = (char *(*)()) F869_6820;
	R28[866] = (char *(*)()) F870_6861;
	R28[867] = (char *(*)()) F871_6861;
	R28[868] = (char *(*)()) F872_6861;
	R28[869] = (char *(*)()) F873_6861;
	R28[870] = (char *(*)()) F874_6861;
	R28[871] = (char *(*)()) F875_6861;
	R28[872] = (char *(*)()) F876_6861;
	R28[873] = (char *(*)()) F877_6861;
	R28[874] = (char *(*)()) F878_6861;
	R28[875] = (char *(*)()) F879_6861;
	R28[876] = (char *(*)()) F880_6861;
	R28[877] = (char *(*)()) F881_6861;
	R28[878] = (char *(*)()) F882_6861;
	R28[879] = (char *(*)()) F883_6861;
	R28[880] = (char *(*)()) F884_6861;
	R28[881] = (char *(*)()) F885_6861;
	R28[882] = (char *(*)()) F886_6861;
	R28[883] = (char *(*)()) F887_6861;
	R28[884] = (char *(*)()) F888_6861;
	R28[885] = (char *(*)()) F889_6861;
	R28[886] = (char *(*)()) F890_6861;
	R28[887] = (char *(*)()) F891_6861;
	R28[888] = (char *(*)()) F892_6861;
	R28[889] = (char *(*)()) F893_6861;
	R28[890] = (char *(*)()) F894_6861;
	R28[891] = (char *(*)()) F895_6861;
	R28[892] = (char *(*)()) F896_6861;
	R28[893] = (char *(*)()) F897_6861;
	R28[894] = (char *(*)()) F898_6861;
	R28[895] = (char *(*)()) F899_6861;
	R28[896] = (char *(*)()) F900_6861;
	R28[897] = (char *(*)()) F901_6861;
	R28[898] = (char *(*)()) F1_25;
	{long i; for (i = 900; i < 902; i++) R28[i] = (char *(*)()) F903_7073;}
	{long i; for (i = 903; i < 905; i++) R28[i] = (char *(*)()) F906_7172;}
	{long i; for (i = 906; i < 908; i++) R28[i] = (char *(*)()) F909_7271;}
	{long i; for (i = 909; i < 911; i++) R28[i] = (char *(*)()) F912_7370;}
	{long i; for (i = 912; i < 914; i++) R28[i] = (char *(*)()) F915_7466;}
	{long i; for (i = 915; i < 917; i++) R28[i] = (char *(*)()) F918_7560;}
	{long i; for (i = 918; i < 920; i++) R28[i] = (char *(*)()) F921_7655;}
	{long i; for (i = 921; i < 923; i++) R28[i] = (char *(*)()) F924_7750;}
	R28[924] = (char *(*)()) F928_7843;
	R28[925] = (char *(*)()) F929_7843;
	R28[927] = (char *(*)()) F931_7909;
	R28[928] = (char *(*)()) F932_7909;
	{long i; for (i = 930; i < 932; i++) R28[i] = (char *(*)()) F933_7925;}
	{long i; for (i = 933; i < 935; i++) R28[i] = (char *(*)()) F936_7965;}
	{long i; for (i = 936; i < 938; i++) R28[i] = (char *(*)()) F939_8013;}
	{long i; for (i = 938; i < 969; i++) R28[i] = (char *(*)()) F942_8039;}
	R28[969] = (char *(*)()) F973_8052;
	R28[970] = (char *(*)()) F974_8052;
	{long i; for (i = 972; i < 977; i++) R28[i] = (char *(*)()) F1_25;}
	R28[980] = (char *(*)()) F983_8246;
	R28[982] = (char *(*)()) F985_8323;
	R28[984] = (char *(*)()) F983_8246;
	R28[985] = (char *(*)()) F985_8323;
	R28[1017] = (char *(*)()) F1_25;
	{long i; for (i = 1019; i < 1022; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1022] = (char *(*)()) F1026_8834;
	R28[1024] = (char *(*)()) F1028_8876;
	{long i; for (i = 1025; i < 1027; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1031] = (char *(*)()) F1_25;
	R28[1048] = (char *(*)()) F1_25;
	{long i; for (i = 1060; i < 1064; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1065; i < 1067; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1068; i < 1070; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1071] = (char *(*)()) F1_25;
	R28[1073] = (char *(*)()) F1_25;
	R28[1075] = (char *(*)()) F1_25;
	{long i; for (i = 1077; i < 1080; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1083] = (char *(*)()) F1_25;
	R28[1089] = (char *(*)()) F1_25;
	R28[1092] = (char *(*)()) F1_25;
	R28[1098] = (char *(*)()) F1_25;
	R28[1107] = (char *(*)()) F1_25;
	R28[1120] = (char *(*)()) F1_25;
	R28[1122] = (char *(*)()) F1_25;
	R28[1124] = (char *(*)()) F1_25;
	R28[1127] = (char *(*)()) F1_25;
	R28[1129] = (char *(*)()) F1_25;
	R28[1131] = (char *(*)()) F1_25;
	R28[1133] = (char *(*)()) F1_25;
	R28[1135] = (char *(*)()) F1_25;
	R28[1140] = (char *(*)()) F1_25;
	{long i; for (i = 1194; i < 1196; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1204; i < 1206; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1207; i < 1210; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1211] = (char *(*)()) F1_25;
	R28[1228] = (char *(*)()) F1_25;
	{long i; for (i = 1232; i < 1234; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1238] = (char *(*)()) F1_25;
	R28[1251] = (char *(*)()) F1_25;
	R28[1257] = (char *(*)()) F1_25;
	R28[1261] = (char *(*)()) F1_25;
	R28[1274] = (char *(*)()) F1_25;
	{long i; for (i = 1276; i < 1278; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1282; i < 1284; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1284] = (char *(*)()) F1288_13148;
	{long i; for (i = 1287; i < 1289; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1292] = (char *(*)()) F1_25;
	{long i; for (i = 1295; i < 1297; i++) R28[i] = (char *(*)()) F1_25;}
}

char *(*R2841[5])();
void R2841_init () {
	R2841[0] = (char *(*)()) F269_4355;
	R2841[1] = (char *(*)()) F270_4357;
	R2841[2] = (char *(*)()) F271_4359;
	R2841[4] = (char *(*)()) F273_4368;
}

char *(*R3204[2])();
void R3204_init () {
	R3204[0] = (char *(*)()) F160_3267;
	R3204[1] = (char *(*)()) F161_3271;
}

char *(*R3206[2])();
void R3206_init () {
	R3206[0] = (char *(*)()) F160_3268;
	R3206[1] = (char *(*)()) F161_3272;
}

char *(*R3218[912])();
void R3218_init () {
	R3218[0] = (char *(*)()) F166_3291;
	R3218[911] = (char *(*)()) F1077_9561;
}

char *(*R3219[912])();
void R3219_init () {
	R3219[0] = (char *(*)()) F166_3292;
	R3219[911] = (char *(*)()) F1077_9564;
}

char *(*R3222[912])();
void R3222_init () {
	R3222[0] = (char *(*)()) F163_3283;
	R3222[911] = (char *(*)()) F1077_9566;
}

char *(*R3228[146])();
void R3228_init () {
	R3228[0] = (char *(*)()) F167_3294;
	R3228[1] = (char *(*)()) F168_3294_3228_1;
	R3228[2] = (char *(*)()) F169_3294_3228_1;
	R3228[3] = (char *(*)()) F170_3294_3228_1;
	R3228[4] = (char *(*)()) F171_3294_3228_1;
	R3228[5] = (char *(*)()) F167_3294;
	R3228[6] = (char *(*)()) F168_3294_3228_1;
	R3228[7] = (char *(*)()) F170_3294_3228_1;
	R3228[145] = (char *(*)()) F167_3294;
}
static EIF_REFERENCE F168_3294_3228_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F168_3294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F169_3294_3228_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F169_3294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F170_3294_3228_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F170_3294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F171_3294_3228_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F171_3294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R3229[146])();
void R3229_init () {
	R3229[0] = (char *(*)()) F167_3295;
	R3229[1] = (char *(*)()) F168_3295_3229_4;
	R3229[2] = (char *(*)()) F169_3295_3229_4;
	R3229[3] = (char *(*)()) F170_3295_3229_4;
	R3229[4] = (char *(*)()) F171_3295_3229_4;
	R3229[5] = (char *(*)()) F167_3295;
	R3229[6] = (char *(*)()) F168_3295_3229_4;
	R3229[7] = (char *(*)()) F170_3295_3229_4;
	R3229[145] = (char *(*)()) F167_3295;
}
static void F168_3295_3229_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F168_3295(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F169_3295_3229_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F169_3295(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F170_3295_3229_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F170_3295(Current, *(EIF_BOOLEAN *)arg1);
}
static void F171_3295_3229_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F171_3295(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R3233[3])();
void R3233_init () {
	R3233[0] = (char *(*)()) F172_3298;
	R3233[1] = (char *(*)()) F173_3298;
	R3233[2] = (char *(*)()) F174_3298;
}

char *(*R3234[3])();
void R3234_init () {
	R3234[0] = (char *(*)()) F172_3299;
	R3234[1] = (char *(*)()) F173_3299;
	R3234[2] = (char *(*)()) F174_3299;
}

char *(*R3235[813])();
void R3235_init () {
	R3235[0] = (char *(*)()) F177_3315;
	R3235[692] = (char *(*)()) F869_6815;
	R3235[727] = (char *(*)()) F904_7075_3235_2;
	R3235[728] = (char *(*)()) F905_7075_3235_2;
	R3235[730] = (char *(*)()) F907_7174_3235_2;
	R3235[731] = (char *(*)()) F908_7174_3235_2;
	R3235[733] = (char *(*)()) F910_7273_3235_2;
	R3235[734] = (char *(*)()) F911_7273_3235_2;
	R3235[736] = (char *(*)()) F913_7372_3235_2;
	R3235[737] = (char *(*)()) F914_7372_3235_2;
	R3235[739] = (char *(*)()) F916_7467_3235_2;
	R3235[740] = (char *(*)()) F917_7467_3235_2;
	R3235[742] = (char *(*)()) F919_7561_3235_2;
	R3235[743] = (char *(*)()) F920_7561_3235_2;
	R3235[745] = (char *(*)()) F922_7656_3235_2;
	R3235[746] = (char *(*)()) F923_7656_3235_2;
	R3235[748] = (char *(*)()) F925_7751_3235_2;
	R3235[749] = (char *(*)()) F926_7751_3235_2;
	R3235[751] = (char *(*)()) F928_7820_3235_2;
	R3235[752] = (char *(*)()) F929_7820_3235_2;
	R3235[754] = (char *(*)()) F931_7886_3235_2;
	R3235[755] = (char *(*)()) F932_7886_3235_2;
	{long i; for (i = 757; i < 759; i++) R3235[i] = (char *(*)()) F933_7917;}
	{long i; for (i = 760; i < 762; i++) R3235[i] = (char *(*)()) F936_7957;}
	R3235[807] = (char *(*)()) F983_8231;
	R3235[809] = (char *(*)()) F985_8308;
	R3235[811] = (char *(*)()) F983_8231;
	R3235[812] = (char *(*)()) F985_8308;
}
static EIF_BOOLEAN F904_7075_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F904_7075(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F905_7075_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F905_7075(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F907_7174_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F907_7174(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F908_7174_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F908_7174(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F910_7273_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F910_7273(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F911_7273_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F911_7273(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F913_7372_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F913_7372(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F914_7372_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F914_7372(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F916_7467_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F916_7467(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F917_7467_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F917_7467(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F919_7561_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F919_7561(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F920_7561_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F920_7561(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F922_7656_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F922_7656(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F923_7656_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F923_7656(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F925_7751_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F925_7751(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F926_7751_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F926_7751(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F928_7820_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F928_7820(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F929_7820_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F929_7820(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F931_7886_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F931_7886(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F932_7886_3235_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F932_7886(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3321[40])();
void R3321_init () {
	R3321[0] = (char *(*)()) F184_3392;
	{long i; for (i = 1; i < 3; i++) R3321[i] = (char *(*)()) F185_3416;}
	R3321[5] = (char *(*)()) F189_3419;
	R3321[7] = (char *(*)()) F191_3421;
	R3321[8] = (char *(*)()) F192_3427;
	R3321[9] = (char *(*)()) F193_3444;
	R3321[11] = (char *(*)()) F195_3448;
	R3321[12] = (char *(*)()) F196_3450;
	R3321[13] = (char *(*)()) F197_3452;
	R3321[15] = (char *(*)()) F199_3454;
	R3321[16] = (char *(*)()) F200_3456;
	R3321[19] = (char *(*)()) F203_3460;
	R3321[20] = (char *(*)()) F204_3464;
	R3321[22] = (char *(*)()) F206_3466;
	R3321[23] = (char *(*)()) F207_3468;
	R3321[24] = (char *(*)()) F208_3470;
	R3321[26] = (char *(*)()) F210_3476;
	R3321[27] = (char *(*)()) F211_3480;
	R3321[28] = (char *(*)()) F212_3484;
	R3321[29] = (char *(*)()) F213_3486;
	R3321[31] = (char *(*)()) F215_3488;
	R3321[32] = (char *(*)()) F216_3490;
	R3321[34] = (char *(*)()) F218_3492;
	R3321[35] = (char *(*)()) F219_3494;
	R3321[36] = (char *(*)()) F220_3496;
	R3321[37] = (char *(*)()) F221_3498;
	R3321[38] = (char *(*)()) F222_3502;
	R3321[39] = (char *(*)()) F223_3504;
}

char *(*R3691[3])();
void R3691_init () {
	R3691[0] = (char *(*)()) F231_3816;
	R3691[1] = (char *(*)()) F232_3816;
	R3691[2] = (char *(*)()) F233_3816;
}

char *(*R4044[724])();
void R4044_init () {
	R4044[0] = (char *(*)()) F251_4176;
	R4044[274] = (char *(*)()) F246_4176;
	R4044[275] = (char *(*)()) F247_4176;
	R4044[276] = (char *(*)()) F248_4176;
	R4044[277] = (char *(*)()) F249_4176;
	R4044[278] = (char *(*)()) F250_4176;
	R4044[279] = (char *(*)()) F251_4176;
	R4044[280] = (char *(*)()) F252_4176;
	R4044[281] = (char *(*)()) F253_4176;
	R4044[282] = (char *(*)()) F254_4176;
	R4044[283] = (char *(*)()) F255_4176;
	R4044[284] = (char *(*)()) F256_4176;
	R4044[285] = (char *(*)()) F257_4176;
	R4044[353] = (char *(*)()) F246_4176;
	R4044[354] = (char *(*)()) F247_4176;
	R4044[355] = (char *(*)()) F248_4176;
	R4044[356] = (char *(*)()) F249_4176;
	R4044[357] = (char *(*)()) F250_4176;
	R4044[358] = (char *(*)()) F251_4176;
	R4044[359] = (char *(*)()) F252_4176;
	R4044[360] = (char *(*)()) F253_4176;
	R4044[361] = (char *(*)()) F254_4176;
	R4044[362] = (char *(*)()) F255_4176;
	R4044[363] = (char *(*)()) F256_4176;
	R4044[364] = (char *(*)()) F257_4176;
	R4044[365] = (char *(*)()) F246_4176;
	R4044[366] = (char *(*)()) F252_4176;
	R4044[367] = (char *(*)()) F249_4176;
	{long i; for (i = 370; i < 373; i++) R4044[i] = (char *(*)()) F246_4176;}
	R4044[377] = (char *(*)()) F246_4176;
	R4044[380] = (char *(*)()) F246_4176;
	R4044[382] = (char *(*)()) F246_4176;
	R4044[385] = (char *(*)()) F246_4176;
	{long i; for (i = 387; i < 391; i++) R4044[i] = (char *(*)()) F246_4176;}
	R4044[393] = (char *(*)()) F246_4176;
	R4044[394] = (char *(*)()) F252_4176;
	R4044[395] = (char *(*)()) F246_4176;
	R4044[722] = (char *(*)()) F254_4176;
	R4044[723] = (char *(*)()) F248_4176;
}

char *(*R4045[724])();
void R4045_init () {
	R4045[0] = (char *(*)()) F251_4177_4045_262;
	R4045[274] = (char *(*)()) F246_4177;
	R4045[275] = (char *(*)()) F247_4177_4045_262;
	R4045[276] = (char *(*)()) F248_4177_4045_262;
	R4045[277] = (char *(*)()) F249_4177_4045_262;
	R4045[278] = (char *(*)()) F250_4177_4045_262;
	R4045[279] = (char *(*)()) F251_4177_4045_262;
	R4045[280] = (char *(*)()) F252_4177_4045_262;
	R4045[281] = (char *(*)()) F253_4177_4045_262;
	R4045[282] = (char *(*)()) F254_4177_4045_262;
	R4045[283] = (char *(*)()) F255_4177_4045_262;
	R4045[284] = (char *(*)()) F256_4177_4045_262;
	R4045[285] = (char *(*)()) F257_4177_4045_262;
	R4045[353] = (char *(*)()) F246_4177;
	R4045[354] = (char *(*)()) F247_4177_4045_262;
	R4045[355] = (char *(*)()) F248_4177_4045_262;
	R4045[356] = (char *(*)()) F249_4177_4045_262;
	R4045[357] = (char *(*)()) F250_4177_4045_262;
	R4045[358] = (char *(*)()) F251_4177_4045_262;
	R4045[359] = (char *(*)()) F252_4177_4045_262;
	R4045[360] = (char *(*)()) F253_4177_4045_262;
	R4045[361] = (char *(*)()) F254_4177_4045_262;
	R4045[362] = (char *(*)()) F255_4177_4045_262;
	R4045[363] = (char *(*)()) F256_4177_4045_262;
	R4045[364] = (char *(*)()) F257_4177_4045_262;
	R4045[365] = (char *(*)()) F246_4177;
	R4045[366] = (char *(*)()) F252_4177_4045_262;
	R4045[367] = (char *(*)()) F249_4177_4045_262;
	{long i; for (i = 370; i < 373; i++) R4045[i] = (char *(*)()) F246_4177;}
	R4045[377] = (char *(*)()) F246_4177;
	R4045[380] = (char *(*)()) F246_4177;
	R4045[382] = (char *(*)()) F246_4177;
	R4045[385] = (char *(*)()) F246_4177;
	{long i; for (i = 387; i < 391; i++) R4045[i] = (char *(*)()) F246_4177;}
	R4045[393] = (char *(*)()) F246_4177;
	R4045[394] = (char *(*)()) F252_4177_4045_262;
	R4045[395] = (char *(*)()) F246_4177;
	R4045[722] = (char *(*)()) F254_4177_4045_262;
	R4045[723] = (char *(*)()) F248_4177_4045_262;
}
static void F251_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F251_4177(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F247_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F247_4177(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F248_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F248_4177(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F249_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F249_4177(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F250_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F250_4177(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F252_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F252_4177(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F253_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F253_4177(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F254_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F254_4177(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F255_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F255_4177(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F256_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F256_4177(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F257_4177_4045_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F257_4177(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4051[724])();
void R4051_init () {
	R4051[0] = (char *(*)()) F251_4183;
	R4051[274] = (char *(*)()) F246_4183;
	R4051[275] = (char *(*)()) F247_4183;
	R4051[276] = (char *(*)()) F248_4183;
	R4051[277] = (char *(*)()) F249_4183;
	R4051[278] = (char *(*)()) F250_4183;
	R4051[279] = (char *(*)()) F251_4183;
	R4051[280] = (char *(*)()) F252_4183;
	R4051[281] = (char *(*)()) F253_4183;
	R4051[282] = (char *(*)()) F254_4183;
	R4051[283] = (char *(*)()) F255_4183;
	R4051[284] = (char *(*)()) F256_4183;
	R4051[285] = (char *(*)()) F257_4183;
	R4051[353] = (char *(*)()) F246_4183;
	R4051[354] = (char *(*)()) F247_4183;
	R4051[355] = (char *(*)()) F248_4183;
	R4051[356] = (char *(*)()) F249_4183;
	R4051[357] = (char *(*)()) F250_4183;
	R4051[358] = (char *(*)()) F251_4183;
	R4051[359] = (char *(*)()) F252_4183;
	R4051[360] = (char *(*)()) F253_4183;
	R4051[361] = (char *(*)()) F254_4183;
	R4051[362] = (char *(*)()) F255_4183;
	R4051[363] = (char *(*)()) F256_4183;
	R4051[364] = (char *(*)()) F257_4183;
	R4051[365] = (char *(*)()) F246_4183;
	R4051[366] = (char *(*)()) F252_4183;
	R4051[367] = (char *(*)()) F249_4183;
	{long i; for (i = 370; i < 373; i++) R4051[i] = (char *(*)()) F246_4183;}
	R4051[377] = (char *(*)()) F246_4183;
	R4051[380] = (char *(*)()) F246_4183;
	R4051[382] = (char *(*)()) F246_4183;
	R4051[385] = (char *(*)()) F246_4183;
	{long i; for (i = 387; i < 391; i++) R4051[i] = (char *(*)()) F246_4183;}
	R4051[393] = (char *(*)()) F246_4183;
	R4051[394] = (char *(*)()) F252_4183;
	R4051[395] = (char *(*)()) F246_4183;
	R4051[722] = (char *(*)()) F254_4183;
	R4051[723] = (char *(*)()) F248_4183;
}

static EIF_TYPE_INDEX Y4052_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype12[] = {925,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype13[] = {925,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype26[] = {925,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype44[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype45[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype46[] = {975,0xFFF9,1,901,0,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype47[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype48[] = {975,0xFFF9,1,901,1089,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype49[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype50[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype51[] = {975,0xFFF9,1,901,1095,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype52[] = {975,0xFFF9,1,901,1057,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype53[] = {975,0xFFF9,1,901,865,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype54[] = {975,0xFFF9,1,901,1036,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype55[] = {975,0xFFF9,5,901,919,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype56[] = {975,0xFFF9,1,901,1287,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype57[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype58[] = {975,0xFFF9,1,901,987,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype59[] = {975,0xFFF9,7,901,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype60[] = {975,0xFFF9,2,901,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype61[] = {975,0xFFF9,4,901,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype62[] = {975,0xFFF9,3,901,907,907,865,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype63[] = {975,0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype64[] = {975,0xFFF9,0,901,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype69[] = {1025,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype70[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype71[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype72[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype73[] = {987,0xFFFF};
EIF_TYPE_INDEX *Y4052_gen_type [845];
EIF_TYPE_INDEX Y4052 [845];
void Y4052_init (void)
{
	egc_routines_types [4052] = Y4052;
	egc_routines_gen_types [4052] = Y4052_gen_type;
	egc_routines_offset [4052] = 245;
	Y4052_gen_type [0] = Y4052_pgtype0;
	Y4052_gen_type [1] = Y4052_pgtype1;
	Y4052_gen_type [2] = Y4052_pgtype2;
	Y4052_gen_type [3] = Y4052_pgtype3;
	Y4052_gen_type [4] = Y4052_pgtype4;
	Y4052_gen_type [5] = Y4052_pgtype5;
	Y4052_gen_type [6] = Y4052_pgtype6;
	Y4052_gen_type [7] = Y4052_pgtype7;
	Y4052_gen_type [8] = Y4052_pgtype8;
	Y4052_gen_type [9] = Y4052_pgtype9;
	Y4052_gen_type [10] = Y4052_pgtype10;
	Y4052_gen_type [11] = Y4052_pgtype11;
	Y4052_gen_type [20] = Y4052_pgtype12;
	Y4052_gen_type [21] = Y4052_pgtype13;
	Y4052_gen_type [294] = Y4052_pgtype14;
	Y4052_gen_type [295] = Y4052_pgtype15;
	Y4052_gen_type [296] = Y4052_pgtype16;
	Y4052_gen_type [297] = Y4052_pgtype17;
	Y4052_gen_type [298] = Y4052_pgtype18;
	Y4052_gen_type [299] = Y4052_pgtype19;
	Y4052_gen_type [300] = Y4052_pgtype20;
	Y4052_gen_type [301] = Y4052_pgtype21;
	Y4052_gen_type [302] = Y4052_pgtype22;
	Y4052_gen_type [303] = Y4052_pgtype23;
	Y4052_gen_type [304] = Y4052_pgtype24;
	Y4052_gen_type [305] = Y4052_pgtype25;
	Y4052_gen_type [306] = Y4052_pgtype26;
	Y4052_gen_type [373] = Y4052_pgtype27;
	Y4052_gen_type [374] = Y4052_pgtype28;
	Y4052_gen_type [375] = Y4052_pgtype29;
	Y4052_gen_type [376] = Y4052_pgtype30;
	Y4052_gen_type [377] = Y4052_pgtype31;
	Y4052_gen_type [378] = Y4052_pgtype32;
	Y4052_gen_type [379] = Y4052_pgtype33;
	Y4052_gen_type [380] = Y4052_pgtype34;
	Y4052_gen_type [381] = Y4052_pgtype35;
	Y4052_gen_type [382] = Y4052_pgtype36;
	Y4052_gen_type [383] = Y4052_pgtype37;
	Y4052_gen_type [384] = Y4052_pgtype38;
	Y4052_gen_type [385] = Y4052_pgtype39;
	Y4052_gen_type [386] = Y4052_pgtype40;
	Y4052_gen_type [387] = Y4052_pgtype41;
	Y4052_gen_type [388] = Y4052_pgtype42;
	Y4052_gen_type [389] = Y4052_pgtype43;
	Y4052_gen_type [390] = Y4052_pgtype44;
	Y4052_gen_type [391] = Y4052_pgtype45;
	Y4052_gen_type [392] = Y4052_pgtype46;
	Y4052_gen_type [393] = Y4052_pgtype47;
	Y4052_gen_type [394] = Y4052_pgtype48;
	Y4052_gen_type [395] = Y4052_pgtype49;
	Y4052_gen_type [396] = Y4052_pgtype50;
	Y4052_gen_type [397] = Y4052_pgtype51;
	Y4052_gen_type [398] = Y4052_pgtype52;
	Y4052_gen_type [399] = Y4052_pgtype53;
	Y4052_gen_type [400] = Y4052_pgtype54;
	Y4052_gen_type [401] = Y4052_pgtype55;
	Y4052_gen_type [402] = Y4052_pgtype56;
	Y4052_gen_type [403] = Y4052_pgtype57;
	Y4052_gen_type [404] = Y4052_pgtype58;
	Y4052_gen_type [405] = Y4052_pgtype59;
	Y4052_gen_type [406] = Y4052_pgtype60;
	Y4052_gen_type [407] = Y4052_pgtype61;
	Y4052_gen_type [408] = Y4052_pgtype62;
	Y4052_gen_type [409] = Y4052_pgtype63;
	Y4052_gen_type [410] = Y4052_pgtype64;
	Y4052_gen_type [411] = Y4052_pgtype65;
	Y4052_gen_type [412] = Y4052_pgtype66;
	Y4052_gen_type [413] = Y4052_pgtype67;
	Y4052_gen_type [414] = Y4052_pgtype68;
	Y4052_gen_type [415] = Y4052_pgtype69;
	Y4052_gen_type [742] = Y4052_pgtype70;
	Y4052_gen_type [743] = Y4052_pgtype71;
	Y4052_gen_type [744] = Y4052_pgtype72;
	Y4052_gen_type [844] = Y4052_pgtype73;
	{long i; for (i = 20; i < 22; i++) Y4052[i] = 925;};
	Y4052[306] = 925;
	{long i; for (i = 390; i < 411; i++) Y4052[i] = 975;};
	Y4052[415] = 1025;
	Y4052[742] = 934;
	{long i; for (i = 743; i < 745; i++) Y4052[i] = 937;};
	Y4052[844] = 987;
}

char *(*R4058[1027])();
void R4058_init () {
	R4058[0] = (char *(*)()) F260_4193;
	R4058[588] = (char *(*)()) F848_5827;
	R4058[1026] = (char *(*)()) F1286_13066;
}

char *(*R4249[997])();
void R4249_init () {
	R4249[0] = (char *(*)()) F291_4446;
	R4249[21] = (char *(*)()) F310_4505;
	R4249[249] = (char *(*)()) F540_4823;
	R4249[250] = (char *(*)()) F541_4823;
	R4249[251] = (char *(*)()) F542_4823;
	R4249[252] = (char *(*)()) F543_4823;
	R4249[253] = (char *(*)()) F544_4823;
	R4249[254] = (char *(*)()) F545_4823;
	R4249[255] = (char *(*)()) F546_4823;
	R4249[256] = (char *(*)()) F547_4823;
	R4249[257] = (char *(*)()) F548_4823;
	R4249[258] = (char *(*)()) F549_4823;
	R4249[259] = (char *(*)()) F550_4823;
	R4249[260] = (char *(*)()) F551_4823;
	R4249[310] = (char *(*)()) F601_4951;
	R4249[311] = (char *(*)()) F602_4951;
	R4249[312] = (char *(*)()) F603_4951;
	{long i; for (i = 313; i < 315; i++) R4249[i] = (char *(*)()) F601_4951;}
	R4249[315] = (char *(*)()) F603_4951;
	R4249[316] = (char *(*)()) F602_4951;
	R4249[319] = (char *(*)()) F610_5072;
	R4249[320] = (char *(*)()) F611_5072;
	R4249[321] = (char *(*)()) F612_5072;
	R4249[322] = (char *(*)()) F613_5072;
	R4249[323] = (char *(*)()) F614_5072;
	R4249[324] = (char *(*)()) F615_5072;
	R4249[325] = (char *(*)()) F610_5072;
	R4249[326] = (char *(*)()) F612_5072;
	R4249[327] = (char *(*)()) F610_5072;
	R4249[328] = (char *(*)()) F619_5202;
	R4249[329] = (char *(*)()) F620_5202;
	R4249[330] = (char *(*)()) F621_5202;
	R4249[331] = (char *(*)()) F622_5202;
	R4249[332] = (char *(*)()) F623_5202;
	R4249[333] = (char *(*)()) F624_5202;
	R4249[334] = (char *(*)()) F625_5202;
	R4249[335] = (char *(*)()) F626_5202;
	R4249[336] = (char *(*)()) F627_5202;
	R4249[337] = (char *(*)()) F628_5202;
	R4249[338] = (char *(*)()) F629_5202;
	R4249[339] = (char *(*)()) F630_5202;
	R4249[340] = (char *(*)()) F619_5202;
	R4249[341] = (char *(*)()) F625_5202;
	R4249[342] = (char *(*)()) F622_5202;
	{long i; for (i = 345; i < 348; i++) R4249[i] = (char *(*)()) F619_5202;}
	R4249[352] = (char *(*)()) F619_5202;
	R4249[355] = (char *(*)()) F619_5202;
	R4249[357] = (char *(*)()) F619_5202;
	R4249[360] = (char *(*)()) F619_5202;
	{long i; for (i = 362; i < 366; i++) R4249[i] = (char *(*)()) F619_5202;}
	R4249[368] = (char *(*)()) F619_5202;
	R4249[369] = (char *(*)()) F625_5202;
	R4249[370] = (char *(*)()) F619_5202;
	R4249[388] = (char *(*)()) F679_5463;
	R4249[419] = (char *(*)()) F710_5496;
	R4249[420] = (char *(*)()) F711_5496;
	R4249[421] = (char *(*)()) F712_5496;
	R4249[422] = (char *(*)()) F713_5496;
	R4249[423] = (char *(*)()) F714_5496;
	R4249[424] = (char *(*)()) F715_5496;
	R4249[425] = (char *(*)()) F716_5496;
	R4249[426] = (char *(*)()) F717_5496;
	R4249[427] = (char *(*)()) F718_5496;
	R4249[428] = (char *(*)()) F719_5496;
	R4249[429] = (char *(*)()) F720_5496;
	R4249[430] = (char *(*)()) F721_5496;
	R4249[431] = (char *(*)()) F710_5496;
	R4249[432] = (char *(*)()) F714_5496;
	R4249[433] = (char *(*)()) F715_5496;
	{long i; for (i = 434; i < 436; i++) R4249[i] = (char *(*)()) F710_5496;}
	{long i; for (i = 436; i < 438; i++) R4249[i] = (char *(*)()) F714_5496;}
	R4249[438] = (char *(*)()) F719_5496;
	R4249[439] = (char *(*)()) F714_5496;
	R4249[452] = (char *(*)()) F743_5546;
	R4249[453] = (char *(*)()) F744_5546;
	R4249[454] = (char *(*)()) F745_5546;
	R4249[455] = (char *(*)()) F746_5546;
	R4249[456] = (char *(*)()) F747_5546;
	R4249[457] = (char *(*)()) F748_5546;
	R4249[458] = (char *(*)()) F749_5546;
	R4249[459] = (char *(*)()) F750_5546;
	R4249[460] = (char *(*)()) F751_5546;
	R4249[461] = (char *(*)()) F752_5546;
	R4249[462] = (char *(*)()) F753_5546;
	R4249[463] = (char *(*)()) F754_5546;
	R4249[464] = (char *(*)()) F755_5552;
	R4249[465] = (char *(*)()) F756_5558;
	R4249[466] = (char *(*)()) F757_5564;
	R4249[467] = (char *(*)()) F758_5564;
	R4249[468] = (char *(*)()) F759_5564;
	R4249[469] = (char *(*)()) F760_5564;
	R4249[470] = (char *(*)()) F761_5564;
	R4249[471] = (char *(*)()) F762_5564;
	R4249[472] = (char *(*)()) F763_5564;
	R4249[473] = (char *(*)()) F764_5564;
	R4249[474] = (char *(*)()) F765_5564;
	R4249[475] = (char *(*)()) F766_5564;
	R4249[476] = (char *(*)()) F767_5564;
	R4249[477] = (char *(*)()) F768_5564;
	R4249[478] = (char *(*)()) F769_5570;
	R4249[479] = (char *(*)()) F770_5570;
	R4249[480] = (char *(*)()) F771_5570;
	R4249[481] = (char *(*)()) F772_5570;
	R4249[482] = (char *(*)()) F773_5570;
	R4249[483] = (char *(*)()) F774_5570;
	R4249[484] = (char *(*)()) F775_5570;
	R4249[485] = (char *(*)()) F776_5570;
	R4249[486] = (char *(*)()) F777_5570;
	R4249[487] = (char *(*)()) F778_5570;
	R4249[488] = (char *(*)()) F779_5570;
	R4249[489] = (char *(*)()) F780_5570;
	R4249[495] = (char *(*)()) F786_5700;
	R4249[496] = (char *(*)()) F787_5700;
	R4249[497] = (char *(*)()) F788_5700;
	R4249[498] = (char *(*)()) F789_5700;
	R4249[499] = (char *(*)()) F790_5700;
	R4249[500] = (char *(*)()) F791_5700;
	R4249[501] = (char *(*)()) F792_5700;
	R4249[502] = (char *(*)()) F793_5700;
	R4249[503] = (char *(*)()) F794_5700;
	R4249[504] = (char *(*)()) F795_5700;
	R4249[505] = (char *(*)()) F796_5700;
	R4249[506] = (char *(*)()) F797_5700;
	R4249[567] = (char *(*)()) F857_6320;
	R4249[611] = (char *(*)()) F514_4760;
	R4249[693] = (char *(*)()) F983_8221;
	R4249[695] = (char *(*)()) F985_8298;
	R4249[697] = (char *(*)()) F983_8221;
	R4249[698] = (char *(*)()) F985_8298;
	{long i; for (i = 773; i < 775; i++) R4249[i] = (char *(*)()) F514_4760;}
	{long i; for (i = 775; i < 777; i++) R4249[i] = (char *(*)()) F1059_9324;}
	{long i; for (i = 778; i < 780; i++) R4249[i] = (char *(*)()) F1059_9324;}
	{long i; for (i = 781; i < 783; i++) R4249[i] = (char *(*)()) F1059_9324;}
	R4249[784] = (char *(*)()) F1059_9324;
	R4249[786] = (char *(*)()) F1059_9324;
	R4249[811] = (char *(*)()) F514_4760;
	R4249[820] = (char *(*)()) F514_4760;
	R4249[996] = (char *(*)()) F1287_13085;
}


#ifdef __cplusplus
}
#endif
