#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y4250_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype12[] = {988,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype13[] = {983,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype260[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype261[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype274[] = {925,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype339[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype357[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype358[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype359[] = {975,0xFFF9,1,901,0,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype360[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype361[] = {975,0xFFF9,1,901,1089,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype362[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype363[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype364[] = {975,0xFFF9,1,901,1095,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype365[] = {975,0xFFF9,1,901,1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype366[] = {975,0xFFF9,1,901,865,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype367[] = {975,0xFFF9,1,901,1036,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype368[] = {975,0xFFF9,5,901,919,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype369[] = {975,0xFFF9,1,901,1287,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype370[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype371[] = {975,0xFFF9,1,901,987,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype372[] = {975,0xFFF9,7,901,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype373[] = {975,0xFFF9,2,901,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype374[] = {975,0xFFF9,4,901,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype375[] = {975,0xFFF9,3,901,907,907,865,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype376[] = {975,0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype377[] = {975,0xFFF9,0,901,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype382[] = {1025,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype383[] = {25,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype384[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype385[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype455[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype456[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype474[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype493[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype494[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype495[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype496[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype497[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype498[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype499[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype500[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype501[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype502[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype503[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype505[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype506[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype507[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype508[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype509[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype510[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype511[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype512[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype513[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype514[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype515[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype516[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype517[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype518[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype519[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype520[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype521[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype522[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype523[] = {1057,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype524[] = {987,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype525[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype526[] = {1089,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype527[] = {1091,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype528[] = {1090,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype529[] = {1090,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype530[] = {1090,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype531[] = {1107,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype532[] = {1107,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype533[] = {1107,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype534[] = {1107,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype535[] = {1095,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype536[] = {1095,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype537[] = {1095,0xFFFF};
static EIF_TYPE_INDEX Y4250_pgtype538[] = {937,0xFFFF};
EIF_TYPE_INDEX *Y4250_gen_type [1010];
EIF_TYPE_INDEX Y4250 [1010];
void Y4250_init (void)
{
	egc_routines_types [4250] = Y4250;
	egc_routines_gen_types [4250] = Y4250_gen_type;
	egc_routines_offset [4250] = 277;
	Y4250_gen_type [0] = Y4250_pgtype0;
	Y4250_gen_type [1] = Y4250_pgtype1;
	Y4250_gen_type [2] = Y4250_pgtype2;
	Y4250_gen_type [3] = Y4250_pgtype3;
	Y4250_gen_type [4] = Y4250_pgtype4;
	Y4250_gen_type [5] = Y4250_pgtype5;
	Y4250_gen_type [6] = Y4250_pgtype6;
	Y4250_gen_type [7] = Y4250_pgtype7;
	Y4250_gen_type [8] = Y4250_pgtype8;
	Y4250_gen_type [9] = Y4250_pgtype9;
	Y4250_gen_type [10] = Y4250_pgtype10;
	Y4250_gen_type [11] = Y4250_pgtype11;
	Y4250_gen_type [12] = Y4250_pgtype12;
	Y4250_gen_type [13] = Y4250_pgtype13;
	Y4250_gen_type [14] = Y4250_pgtype14;
	Y4250_gen_type [15] = Y4250_pgtype15;
	Y4250_gen_type [16] = Y4250_pgtype16;
	Y4250_gen_type [17] = Y4250_pgtype17;
	Y4250_gen_type [18] = Y4250_pgtype18;
	Y4250_gen_type [19] = Y4250_pgtype19;
	Y4250_gen_type [20] = Y4250_pgtype20;
	Y4250_gen_type [21] = Y4250_pgtype21;
	Y4250_gen_type [22] = Y4250_pgtype22;
	Y4250_gen_type [23] = Y4250_pgtype23;
	Y4250_gen_type [24] = Y4250_pgtype24;
	Y4250_gen_type [25] = Y4250_pgtype25;
	Y4250_gen_type [26] = Y4250_pgtype26;
	Y4250_gen_type [27] = Y4250_pgtype27;
	Y4250_gen_type [28] = Y4250_pgtype28;
	Y4250_gen_type [29] = Y4250_pgtype29;
	Y4250_gen_type [30] = Y4250_pgtype30;
	Y4250_gen_type [31] = Y4250_pgtype31;
	Y4250_gen_type [32] = Y4250_pgtype32;
	Y4250_gen_type [33] = Y4250_pgtype33;
	Y4250_gen_type [34] = Y4250_pgtype34;
	Y4250_gen_type [35] = Y4250_pgtype35;
	Y4250_gen_type [36] = Y4250_pgtype36;
	Y4250_gen_type [37] = Y4250_pgtype37;
	Y4250_gen_type [38] = Y4250_pgtype38;
	Y4250_gen_type [39] = Y4250_pgtype39;
	Y4250_gen_type [40] = Y4250_pgtype40;
	Y4250_gen_type [41] = Y4250_pgtype41;
	Y4250_gen_type [42] = Y4250_pgtype42;
	Y4250_gen_type [43] = Y4250_pgtype43;
	Y4250_gen_type [44] = Y4250_pgtype44;
	Y4250_gen_type [45] = Y4250_pgtype45;
	Y4250_gen_type [46] = Y4250_pgtype46;
	Y4250_gen_type [47] = Y4250_pgtype47;
	Y4250_gen_type [48] = Y4250_pgtype48;
	Y4250_gen_type [49] = Y4250_pgtype49;
	Y4250_gen_type [50] = Y4250_pgtype50;
	Y4250_gen_type [51] = Y4250_pgtype51;
	Y4250_gen_type [52] = Y4250_pgtype52;
	Y4250_gen_type [53] = Y4250_pgtype53;
	Y4250_gen_type [54] = Y4250_pgtype54;
	Y4250_gen_type [55] = Y4250_pgtype55;
	Y4250_gen_type [56] = Y4250_pgtype56;
	Y4250_gen_type [57] = Y4250_pgtype57;
	Y4250_gen_type [58] = Y4250_pgtype58;
	Y4250_gen_type [59] = Y4250_pgtype59;
	Y4250_gen_type [60] = Y4250_pgtype60;
	Y4250_gen_type [61] = Y4250_pgtype61;
	Y4250_gen_type [62] = Y4250_pgtype62;
	Y4250_gen_type [63] = Y4250_pgtype63;
	Y4250_gen_type [64] = Y4250_pgtype64;
	Y4250_gen_type [65] = Y4250_pgtype65;
	Y4250_gen_type [66] = Y4250_pgtype66;
	Y4250_gen_type [67] = Y4250_pgtype67;
	Y4250_gen_type [68] = Y4250_pgtype68;
	Y4250_gen_type [69] = Y4250_pgtype69;
	Y4250_gen_type [70] = Y4250_pgtype70;
	Y4250_gen_type [71] = Y4250_pgtype71;
	Y4250_gen_type [72] = Y4250_pgtype72;
	Y4250_gen_type [73] = Y4250_pgtype73;
	Y4250_gen_type [74] = Y4250_pgtype74;
	Y4250_gen_type [75] = Y4250_pgtype75;
	Y4250_gen_type [76] = Y4250_pgtype76;
	Y4250_gen_type [77] = Y4250_pgtype77;
	Y4250_gen_type [78] = Y4250_pgtype78;
	Y4250_gen_type [79] = Y4250_pgtype79;
	Y4250_gen_type [80] = Y4250_pgtype80;
	Y4250_gen_type [81] = Y4250_pgtype81;
	Y4250_gen_type [82] = Y4250_pgtype82;
	Y4250_gen_type [83] = Y4250_pgtype83;
	Y4250_gen_type [84] = Y4250_pgtype84;
	Y4250_gen_type [85] = Y4250_pgtype85;
	Y4250_gen_type [86] = Y4250_pgtype86;
	Y4250_gen_type [87] = Y4250_pgtype87;
	Y4250_gen_type [88] = Y4250_pgtype88;
	Y4250_gen_type [89] = Y4250_pgtype89;
	Y4250_gen_type [90] = Y4250_pgtype90;
	Y4250_gen_type [91] = Y4250_pgtype91;
	Y4250_gen_type [92] = Y4250_pgtype92;
	Y4250_gen_type [93] = Y4250_pgtype93;
	Y4250_gen_type [94] = Y4250_pgtype94;
	Y4250_gen_type [95] = Y4250_pgtype95;
	Y4250_gen_type [96] = Y4250_pgtype96;
	Y4250_gen_type [97] = Y4250_pgtype97;
	Y4250_gen_type [98] = Y4250_pgtype98;
	Y4250_gen_type [99] = Y4250_pgtype99;
	Y4250_gen_type [100] = Y4250_pgtype100;
	Y4250_gen_type [101] = Y4250_pgtype101;
	Y4250_gen_type [102] = Y4250_pgtype102;
	Y4250_gen_type [103] = Y4250_pgtype103;
	Y4250_gen_type [104] = Y4250_pgtype104;
	Y4250_gen_type [105] = Y4250_pgtype105;
	Y4250_gen_type [106] = Y4250_pgtype106;
	Y4250_gen_type [107] = Y4250_pgtype107;
	Y4250_gen_type [108] = Y4250_pgtype108;
	Y4250_gen_type [109] = Y4250_pgtype109;
	Y4250_gen_type [110] = Y4250_pgtype110;
	Y4250_gen_type [111] = Y4250_pgtype111;
	Y4250_gen_type [112] = Y4250_pgtype112;
	Y4250_gen_type [113] = Y4250_pgtype113;
	Y4250_gen_type [114] = Y4250_pgtype114;
	Y4250_gen_type [115] = Y4250_pgtype115;
	Y4250_gen_type [116] = Y4250_pgtype116;
	Y4250_gen_type [117] = Y4250_pgtype117;
	Y4250_gen_type [118] = Y4250_pgtype118;
	Y4250_gen_type [119] = Y4250_pgtype119;
	Y4250_gen_type [120] = Y4250_pgtype120;
	Y4250_gen_type [121] = Y4250_pgtype121;
	Y4250_gen_type [122] = Y4250_pgtype122;
	Y4250_gen_type [123] = Y4250_pgtype123;
	Y4250_gen_type [124] = Y4250_pgtype124;
	Y4250_gen_type [125] = Y4250_pgtype125;
	Y4250_gen_type [126] = Y4250_pgtype126;
	Y4250_gen_type [127] = Y4250_pgtype127;
	Y4250_gen_type [128] = Y4250_pgtype128;
	Y4250_gen_type [129] = Y4250_pgtype129;
	Y4250_gen_type [130] = Y4250_pgtype130;
	Y4250_gen_type [131] = Y4250_pgtype131;
	Y4250_gen_type [132] = Y4250_pgtype132;
	Y4250_gen_type [133] = Y4250_pgtype133;
	Y4250_gen_type [134] = Y4250_pgtype134;
	Y4250_gen_type [135] = Y4250_pgtype135;
	Y4250_gen_type [136] = Y4250_pgtype136;
	Y4250_gen_type [137] = Y4250_pgtype137;
	Y4250_gen_type [138] = Y4250_pgtype138;
	Y4250_gen_type [139] = Y4250_pgtype139;
	Y4250_gen_type [140] = Y4250_pgtype140;
	Y4250_gen_type [141] = Y4250_pgtype141;
	Y4250_gen_type [142] = Y4250_pgtype142;
	Y4250_gen_type [143] = Y4250_pgtype143;
	Y4250_gen_type [144] = Y4250_pgtype144;
	Y4250_gen_type [145] = Y4250_pgtype145;
	Y4250_gen_type [146] = Y4250_pgtype146;
	Y4250_gen_type [147] = Y4250_pgtype147;
	Y4250_gen_type [148] = Y4250_pgtype148;
	Y4250_gen_type [149] = Y4250_pgtype149;
	Y4250_gen_type [150] = Y4250_pgtype150;
	Y4250_gen_type [151] = Y4250_pgtype151;
	Y4250_gen_type [152] = Y4250_pgtype152;
	Y4250_gen_type [153] = Y4250_pgtype153;
	Y4250_gen_type [154] = Y4250_pgtype154;
	Y4250_gen_type [155] = Y4250_pgtype155;
	Y4250_gen_type [156] = Y4250_pgtype156;
	Y4250_gen_type [157] = Y4250_pgtype157;
	Y4250_gen_type [158] = Y4250_pgtype158;
	Y4250_gen_type [159] = Y4250_pgtype159;
	Y4250_gen_type [160] = Y4250_pgtype160;
	Y4250_gen_type [161] = Y4250_pgtype161;
	Y4250_gen_type [162] = Y4250_pgtype162;
	Y4250_gen_type [163] = Y4250_pgtype163;
	Y4250_gen_type [164] = Y4250_pgtype164;
	Y4250_gen_type [165] = Y4250_pgtype165;
	Y4250_gen_type [166] = Y4250_pgtype166;
	Y4250_gen_type [167] = Y4250_pgtype167;
	Y4250_gen_type [168] = Y4250_pgtype168;
	Y4250_gen_type [169] = Y4250_pgtype169;
	Y4250_gen_type [170] = Y4250_pgtype170;
	Y4250_gen_type [171] = Y4250_pgtype171;
	Y4250_gen_type [172] = Y4250_pgtype172;
	Y4250_gen_type [173] = Y4250_pgtype173;
	Y4250_gen_type [174] = Y4250_pgtype174;
	Y4250_gen_type [175] = Y4250_pgtype175;
	Y4250_gen_type [176] = Y4250_pgtype176;
	Y4250_gen_type [177] = Y4250_pgtype177;
	Y4250_gen_type [178] = Y4250_pgtype178;
	Y4250_gen_type [179] = Y4250_pgtype179;
	Y4250_gen_type [180] = Y4250_pgtype180;
	Y4250_gen_type [181] = Y4250_pgtype181;
	Y4250_gen_type [182] = Y4250_pgtype182;
	Y4250_gen_type [183] = Y4250_pgtype183;
	Y4250_gen_type [184] = Y4250_pgtype184;
	Y4250_gen_type [185] = Y4250_pgtype185;
	Y4250_gen_type [186] = Y4250_pgtype186;
	Y4250_gen_type [187] = Y4250_pgtype187;
	Y4250_gen_type [188] = Y4250_pgtype188;
	Y4250_gen_type [189] = Y4250_pgtype189;
	Y4250_gen_type [190] = Y4250_pgtype190;
	Y4250_gen_type [191] = Y4250_pgtype191;
	Y4250_gen_type [192] = Y4250_pgtype192;
	Y4250_gen_type [193] = Y4250_pgtype193;
	Y4250_gen_type [194] = Y4250_pgtype194;
	Y4250_gen_type [195] = Y4250_pgtype195;
	Y4250_gen_type [196] = Y4250_pgtype196;
	Y4250_gen_type [197] = Y4250_pgtype197;
	Y4250_gen_type [198] = Y4250_pgtype198;
	Y4250_gen_type [199] = Y4250_pgtype199;
	Y4250_gen_type [200] = Y4250_pgtype200;
	Y4250_gen_type [201] = Y4250_pgtype201;
	Y4250_gen_type [202] = Y4250_pgtype202;
	Y4250_gen_type [203] = Y4250_pgtype203;
	Y4250_gen_type [204] = Y4250_pgtype204;
	Y4250_gen_type [205] = Y4250_pgtype205;
	Y4250_gen_type [206] = Y4250_pgtype206;
	Y4250_gen_type [207] = Y4250_pgtype207;
	Y4250_gen_type [208] = Y4250_pgtype208;
	Y4250_gen_type [209] = Y4250_pgtype209;
	Y4250_gen_type [210] = Y4250_pgtype210;
	Y4250_gen_type [211] = Y4250_pgtype211;
	Y4250_gen_type [212] = Y4250_pgtype212;
	Y4250_gen_type [213] = Y4250_pgtype213;
	Y4250_gen_type [214] = Y4250_pgtype214;
	Y4250_gen_type [215] = Y4250_pgtype215;
	Y4250_gen_type [216] = Y4250_pgtype216;
	Y4250_gen_type [217] = Y4250_pgtype217;
	Y4250_gen_type [218] = Y4250_pgtype218;
	Y4250_gen_type [219] = Y4250_pgtype219;
	Y4250_gen_type [220] = Y4250_pgtype220;
	Y4250_gen_type [221] = Y4250_pgtype221;
	Y4250_gen_type [222] = Y4250_pgtype222;
	Y4250_gen_type [223] = Y4250_pgtype223;
	Y4250_gen_type [224] = Y4250_pgtype224;
	Y4250_gen_type [225] = Y4250_pgtype225;
	Y4250_gen_type [226] = Y4250_pgtype226;
	Y4250_gen_type [227] = Y4250_pgtype227;
	Y4250_gen_type [228] = Y4250_pgtype228;
	Y4250_gen_type [229] = Y4250_pgtype229;
	Y4250_gen_type [230] = Y4250_pgtype230;
	Y4250_gen_type [231] = Y4250_pgtype231;
	Y4250_gen_type [232] = Y4250_pgtype232;
	Y4250_gen_type [233] = Y4250_pgtype233;
	Y4250_gen_type [234] = Y4250_pgtype234;
	Y4250_gen_type [235] = Y4250_pgtype235;
	Y4250_gen_type [236] = Y4250_pgtype236;
	Y4250_gen_type [237] = Y4250_pgtype237;
	Y4250_gen_type [238] = Y4250_pgtype238;
	Y4250_gen_type [239] = Y4250_pgtype239;
	Y4250_gen_type [240] = Y4250_pgtype240;
	Y4250_gen_type [241] = Y4250_pgtype241;
	Y4250_gen_type [242] = Y4250_pgtype242;
	Y4250_gen_type [243] = Y4250_pgtype243;
	Y4250_gen_type [244] = Y4250_pgtype244;
	Y4250_gen_type [245] = Y4250_pgtype245;
	Y4250_gen_type [246] = Y4250_pgtype246;
	Y4250_gen_type [247] = Y4250_pgtype247;
	Y4250_gen_type [248] = Y4250_pgtype248;
	Y4250_gen_type [249] = Y4250_pgtype249;
	Y4250_gen_type [250] = Y4250_pgtype250;
	Y4250_gen_type [251] = Y4250_pgtype251;
	Y4250_gen_type [252] = Y4250_pgtype252;
	Y4250_gen_type [253] = Y4250_pgtype253;
	Y4250_gen_type [254] = Y4250_pgtype254;
	Y4250_gen_type [255] = Y4250_pgtype255;
	Y4250_gen_type [256] = Y4250_pgtype256;
	Y4250_gen_type [257] = Y4250_pgtype257;
	Y4250_gen_type [258] = Y4250_pgtype258;
	Y4250_gen_type [259] = Y4250_pgtype259;
	Y4250_gen_type [260] = Y4250_pgtype260;
	Y4250_gen_type [261] = Y4250_pgtype261;
	Y4250_gen_type [262] = Y4250_pgtype262;
	Y4250_gen_type [263] = Y4250_pgtype263;
	Y4250_gen_type [264] = Y4250_pgtype264;
	Y4250_gen_type [265] = Y4250_pgtype265;
	Y4250_gen_type [266] = Y4250_pgtype266;
	Y4250_gen_type [267] = Y4250_pgtype267;
	Y4250_gen_type [268] = Y4250_pgtype268;
	Y4250_gen_type [269] = Y4250_pgtype269;
	Y4250_gen_type [270] = Y4250_pgtype270;
	Y4250_gen_type [271] = Y4250_pgtype271;
	Y4250_gen_type [272] = Y4250_pgtype272;
	Y4250_gen_type [273] = Y4250_pgtype273;
	Y4250_gen_type [274] = Y4250_pgtype274;
	Y4250_gen_type [275] = Y4250_pgtype275;
	Y4250_gen_type [276] = Y4250_pgtype276;
	Y4250_gen_type [277] = Y4250_pgtype277;
	Y4250_gen_type [278] = Y4250_pgtype278;
	Y4250_gen_type [279] = Y4250_pgtype279;
	Y4250_gen_type [280] = Y4250_pgtype280;
	Y4250_gen_type [281] = Y4250_pgtype281;
	Y4250_gen_type [282] = Y4250_pgtype282;
	Y4250_gen_type [283] = Y4250_pgtype283;
	Y4250_gen_type [284] = Y4250_pgtype284;
	Y4250_gen_type [285] = Y4250_pgtype285;
	Y4250_gen_type [286] = Y4250_pgtype286;
	Y4250_gen_type [287] = Y4250_pgtype287;
	Y4250_gen_type [288] = Y4250_pgtype288;
	Y4250_gen_type [289] = Y4250_pgtype289;
	Y4250_gen_type [290] = Y4250_pgtype290;
	Y4250_gen_type [291] = Y4250_pgtype291;
	Y4250_gen_type [292] = Y4250_pgtype292;
	Y4250_gen_type [293] = Y4250_pgtype293;
	Y4250_gen_type [294] = Y4250_pgtype294;
	Y4250_gen_type [295] = Y4250_pgtype295;
	Y4250_gen_type [296] = Y4250_pgtype296;
	Y4250_gen_type [297] = Y4250_pgtype297;
	Y4250_gen_type [298] = Y4250_pgtype298;
	Y4250_gen_type [299] = Y4250_pgtype299;
	Y4250_gen_type [300] = Y4250_pgtype300;
	Y4250_gen_type [301] = Y4250_pgtype301;
	Y4250_gen_type [302] = Y4250_pgtype302;
	Y4250_gen_type [303] = Y4250_pgtype303;
	Y4250_gen_type [304] = Y4250_pgtype304;
	Y4250_gen_type [305] = Y4250_pgtype305;
	Y4250_gen_type [306] = Y4250_pgtype306;
	Y4250_gen_type [307] = Y4250_pgtype307;
	Y4250_gen_type [308] = Y4250_pgtype308;
	Y4250_gen_type [309] = Y4250_pgtype309;
	Y4250_gen_type [310] = Y4250_pgtype310;
	Y4250_gen_type [311] = Y4250_pgtype311;
	Y4250_gen_type [312] = Y4250_pgtype312;
	Y4250_gen_type [313] = Y4250_pgtype313;
	Y4250_gen_type [314] = Y4250_pgtype314;
	Y4250_gen_type [315] = Y4250_pgtype315;
	Y4250_gen_type [316] = Y4250_pgtype316;
	Y4250_gen_type [317] = Y4250_pgtype317;
	Y4250_gen_type [318] = Y4250_pgtype318;
	Y4250_gen_type [319] = Y4250_pgtype319;
	Y4250_gen_type [320] = Y4250_pgtype320;
	Y4250_gen_type [321] = Y4250_pgtype321;
	Y4250_gen_type [322] = Y4250_pgtype322;
	Y4250_gen_type [323] = Y4250_pgtype323;
	Y4250_gen_type [324] = Y4250_pgtype324;
	Y4250_gen_type [325] = Y4250_pgtype325;
	Y4250_gen_type [326] = Y4250_pgtype326;
	Y4250_gen_type [327] = Y4250_pgtype327;
	Y4250_gen_type [328] = Y4250_pgtype328;
	Y4250_gen_type [329] = Y4250_pgtype329;
	Y4250_gen_type [331] = Y4250_pgtype330;
	Y4250_gen_type [332] = Y4250_pgtype331;
	Y4250_gen_type [333] = Y4250_pgtype332;
	Y4250_gen_type [334] = Y4250_pgtype333;
	Y4250_gen_type [335] = Y4250_pgtype334;
	Y4250_gen_type [336] = Y4250_pgtype335;
	Y4250_gen_type [337] = Y4250_pgtype336;
	Y4250_gen_type [338] = Y4250_pgtype337;
	Y4250_gen_type [339] = Y4250_pgtype338;
	Y4250_gen_type [340] = Y4250_pgtype339;
	Y4250_gen_type [341] = Y4250_pgtype340;
	Y4250_gen_type [342] = Y4250_pgtype341;
	Y4250_gen_type [343] = Y4250_pgtype342;
	Y4250_gen_type [344] = Y4250_pgtype343;
	Y4250_gen_type [345] = Y4250_pgtype344;
	Y4250_gen_type [346] = Y4250_pgtype345;
	Y4250_gen_type [347] = Y4250_pgtype346;
	Y4250_gen_type [348] = Y4250_pgtype347;
	Y4250_gen_type [349] = Y4250_pgtype348;
	Y4250_gen_type [350] = Y4250_pgtype349;
	Y4250_gen_type [351] = Y4250_pgtype350;
	Y4250_gen_type [352] = Y4250_pgtype351;
	Y4250_gen_type [353] = Y4250_pgtype352;
	Y4250_gen_type [354] = Y4250_pgtype353;
	Y4250_gen_type [355] = Y4250_pgtype354;
	Y4250_gen_type [356] = Y4250_pgtype355;
	Y4250_gen_type [357] = Y4250_pgtype356;
	Y4250_gen_type [358] = Y4250_pgtype357;
	Y4250_gen_type [359] = Y4250_pgtype358;
	Y4250_gen_type [360] = Y4250_pgtype359;
	Y4250_gen_type [361] = Y4250_pgtype360;
	Y4250_gen_type [362] = Y4250_pgtype361;
	Y4250_gen_type [363] = Y4250_pgtype362;
	Y4250_gen_type [364] = Y4250_pgtype363;
	Y4250_gen_type [365] = Y4250_pgtype364;
	Y4250_gen_type [366] = Y4250_pgtype365;
	Y4250_gen_type [367] = Y4250_pgtype366;
	Y4250_gen_type [368] = Y4250_pgtype367;
	Y4250_gen_type [369] = Y4250_pgtype368;
	Y4250_gen_type [370] = Y4250_pgtype369;
	Y4250_gen_type [371] = Y4250_pgtype370;
	Y4250_gen_type [372] = Y4250_pgtype371;
	Y4250_gen_type [373] = Y4250_pgtype372;
	Y4250_gen_type [374] = Y4250_pgtype373;
	Y4250_gen_type [375] = Y4250_pgtype374;
	Y4250_gen_type [376] = Y4250_pgtype375;
	Y4250_gen_type [377] = Y4250_pgtype376;
	Y4250_gen_type [378] = Y4250_pgtype377;
	Y4250_gen_type [379] = Y4250_pgtype378;
	Y4250_gen_type [380] = Y4250_pgtype379;
	Y4250_gen_type [381] = Y4250_pgtype380;
	Y4250_gen_type [382] = Y4250_pgtype381;
	Y4250_gen_type [383] = Y4250_pgtype382;
	Y4250_gen_type [399] = Y4250_pgtype383;
	Y4250_gen_type [400] = Y4250_pgtype384;
	Y4250_gen_type [401] = Y4250_pgtype385;
	Y4250_gen_type [408] = Y4250_pgtype386;
	Y4250_gen_type [409] = Y4250_pgtype387;
	Y4250_gen_type [410] = Y4250_pgtype388;
	Y4250_gen_type [411] = Y4250_pgtype389;
	Y4250_gen_type [412] = Y4250_pgtype390;
	Y4250_gen_type [413] = Y4250_pgtype391;
	Y4250_gen_type [414] = Y4250_pgtype392;
	Y4250_gen_type [415] = Y4250_pgtype393;
	Y4250_gen_type [416] = Y4250_pgtype394;
	Y4250_gen_type [417] = Y4250_pgtype395;
	Y4250_gen_type [418] = Y4250_pgtype396;
	Y4250_gen_type [419] = Y4250_pgtype397;
	Y4250_gen_type [420] = Y4250_pgtype398;
	Y4250_gen_type [421] = Y4250_pgtype399;
	Y4250_gen_type [422] = Y4250_pgtype400;
	Y4250_gen_type [423] = Y4250_pgtype401;
	Y4250_gen_type [424] = Y4250_pgtype402;
	Y4250_gen_type [425] = Y4250_pgtype403;
	Y4250_gen_type [426] = Y4250_pgtype404;
	Y4250_gen_type [427] = Y4250_pgtype405;
	Y4250_gen_type [428] = Y4250_pgtype406;
	Y4250_gen_type [429] = Y4250_pgtype407;
	Y4250_gen_type [430] = Y4250_pgtype408;
	Y4250_gen_type [431] = Y4250_pgtype409;
	Y4250_gen_type [432] = Y4250_pgtype410;
	Y4250_gen_type [433] = Y4250_pgtype411;
	Y4250_gen_type [434] = Y4250_pgtype412;
	Y4250_gen_type [435] = Y4250_pgtype413;
	Y4250_gen_type [436] = Y4250_pgtype414;
	Y4250_gen_type [437] = Y4250_pgtype415;
	Y4250_gen_type [438] = Y4250_pgtype416;
	Y4250_gen_type [439] = Y4250_pgtype417;
	Y4250_gen_type [440] = Y4250_pgtype418;
	Y4250_gen_type [441] = Y4250_pgtype419;
	Y4250_gen_type [442] = Y4250_pgtype420;
	Y4250_gen_type [443] = Y4250_pgtype421;
	Y4250_gen_type [444] = Y4250_pgtype422;
	Y4250_gen_type [445] = Y4250_pgtype423;
	Y4250_gen_type [446] = Y4250_pgtype424;
	Y4250_gen_type [447] = Y4250_pgtype425;
	Y4250_gen_type [448] = Y4250_pgtype426;
	Y4250_gen_type [449] = Y4250_pgtype427;
	Y4250_gen_type [450] = Y4250_pgtype428;
	Y4250_gen_type [451] = Y4250_pgtype429;
	Y4250_gen_type [452] = Y4250_pgtype430;
	Y4250_gen_type [453] = Y4250_pgtype431;
	Y4250_gen_type [454] = Y4250_pgtype432;
	Y4250_gen_type [455] = Y4250_pgtype433;
	Y4250_gen_type [456] = Y4250_pgtype434;
	Y4250_gen_type [457] = Y4250_pgtype435;
	Y4250_gen_type [458] = Y4250_pgtype436;
	Y4250_gen_type [459] = Y4250_pgtype437;
	Y4250_gen_type [460] = Y4250_pgtype438;
	Y4250_gen_type [461] = Y4250_pgtype439;
	Y4250_gen_type [462] = Y4250_pgtype440;
	Y4250_gen_type [463] = Y4250_pgtype441;
	Y4250_gen_type [464] = Y4250_pgtype442;
	Y4250_gen_type [465] = Y4250_pgtype443;
	Y4250_gen_type [466] = Y4250_pgtype444;
	Y4250_gen_type [467] = Y4250_pgtype445;
	Y4250_gen_type [468] = Y4250_pgtype446;
	Y4250_gen_type [469] = Y4250_pgtype447;
	Y4250_gen_type [470] = Y4250_pgtype448;
	Y4250_gen_type [471] = Y4250_pgtype449;
	Y4250_gen_type [472] = Y4250_pgtype450;
	Y4250_gen_type [473] = Y4250_pgtype451;
	Y4250_gen_type [474] = Y4250_pgtype452;
	Y4250_gen_type [475] = Y4250_pgtype453;
	Y4250_gen_type [476] = Y4250_pgtype454;
	Y4250_gen_type [477] = Y4250_pgtype455;
	Y4250_gen_type [478] = Y4250_pgtype456;
	Y4250_gen_type [479] = Y4250_pgtype457;
	Y4250_gen_type [480] = Y4250_pgtype458;
	Y4250_gen_type [481] = Y4250_pgtype459;
	Y4250_gen_type [482] = Y4250_pgtype460;
	Y4250_gen_type [483] = Y4250_pgtype461;
	Y4250_gen_type [484] = Y4250_pgtype462;
	Y4250_gen_type [485] = Y4250_pgtype463;
	Y4250_gen_type [486] = Y4250_pgtype464;
	Y4250_gen_type [487] = Y4250_pgtype465;
	Y4250_gen_type [488] = Y4250_pgtype466;
	Y4250_gen_type [489] = Y4250_pgtype467;
	Y4250_gen_type [490] = Y4250_pgtype468;
	Y4250_gen_type [491] = Y4250_pgtype469;
	Y4250_gen_type [492] = Y4250_pgtype470;
	Y4250_gen_type [493] = Y4250_pgtype471;
	Y4250_gen_type [494] = Y4250_pgtype472;
	Y4250_gen_type [495] = Y4250_pgtype473;
	Y4250_gen_type [496] = Y4250_pgtype474;
	Y4250_gen_type [497] = Y4250_pgtype475;
	Y4250_gen_type [498] = Y4250_pgtype476;
	Y4250_gen_type [499] = Y4250_pgtype477;
	Y4250_gen_type [500] = Y4250_pgtype478;
	Y4250_gen_type [501] = Y4250_pgtype479;
	Y4250_gen_type [502] = Y4250_pgtype480;
	Y4250_gen_type [508] = Y4250_pgtype481;
	Y4250_gen_type [509] = Y4250_pgtype482;
	Y4250_gen_type [510] = Y4250_pgtype483;
	Y4250_gen_type [511] = Y4250_pgtype484;
	Y4250_gen_type [512] = Y4250_pgtype485;
	Y4250_gen_type [513] = Y4250_pgtype486;
	Y4250_gen_type [514] = Y4250_pgtype487;
	Y4250_gen_type [515] = Y4250_pgtype488;
	Y4250_gen_type [516] = Y4250_pgtype489;
	Y4250_gen_type [517] = Y4250_pgtype490;
	Y4250_gen_type [518] = Y4250_pgtype491;
	Y4250_gen_type [519] = Y4250_pgtype492;
	Y4250_gen_type [579] = Y4250_pgtype493;
	Y4250_gen_type [580] = Y4250_pgtype494;
	Y4250_gen_type [581] = Y4250_pgtype495;
	Y4250_gen_type [624] = Y4250_pgtype496;
	Y4250_gen_type [705] = Y4250_pgtype497;
	Y4250_gen_type [706] = Y4250_pgtype498;
	Y4250_gen_type [707] = Y4250_pgtype499;
	Y4250_gen_type [708] = Y4250_pgtype500;
	Y4250_gen_type [710] = Y4250_pgtype501;
	Y4250_gen_type [711] = Y4250_pgtype502;
	Y4250_gen_type [712] = Y4250_pgtype503;
	Y4250_gen_type [778] = Y4250_pgtype504;
	Y4250_gen_type [781] = Y4250_pgtype505;
	Y4250_gen_type [782] = Y4250_pgtype506;
	Y4250_gen_type [783] = Y4250_pgtype507;
	Y4250_gen_type [784] = Y4250_pgtype508;
	Y4250_gen_type [785] = Y4250_pgtype509;
	Y4250_gen_type [786] = Y4250_pgtype510;
	Y4250_gen_type [787] = Y4250_pgtype511;
	Y4250_gen_type [788] = Y4250_pgtype512;
	Y4250_gen_type [789] = Y4250_pgtype513;
	Y4250_gen_type [790] = Y4250_pgtype514;
	Y4250_gen_type [791] = Y4250_pgtype515;
	Y4250_gen_type [792] = Y4250_pgtype516;
	Y4250_gen_type [793] = Y4250_pgtype517;
	Y4250_gen_type [794] = Y4250_pgtype518;
	Y4250_gen_type [795] = Y4250_pgtype519;
	Y4250_gen_type [796] = Y4250_pgtype520;
	Y4250_gen_type [797] = Y4250_pgtype521;
	Y4250_gen_type [798] = Y4250_pgtype522;
	Y4250_gen_type [799] = Y4250_pgtype523;
	Y4250_gen_type [812] = Y4250_pgtype524;
	Y4250_gen_type [822] = Y4250_pgtype525;
	Y4250_gen_type [823] = Y4250_pgtype526;
	Y4250_gen_type [824] = Y4250_pgtype527;
	Y4250_gen_type [825] = Y4250_pgtype528;
	Y4250_gen_type [826] = Y4250_pgtype529;
	Y4250_gen_type [827] = Y4250_pgtype530;
	Y4250_gen_type [828] = Y4250_pgtype531;
	Y4250_gen_type [829] = Y4250_pgtype532;
	Y4250_gen_type [830] = Y4250_pgtype533;
	Y4250_gen_type [831] = Y4250_pgtype534;
	Y4250_gen_type [832] = Y4250_pgtype535;
	Y4250_gen_type [833] = Y4250_pgtype536;
	Y4250_gen_type [834] = Y4250_pgtype537;
	Y4250_gen_type [1009] = Y4250_pgtype538;
	Y4250[12] = 988;
	Y4250[13] = 983;
	{long i; for (i = 260; i < 262; i++) Y4250[i] = 907;};
	Y4250[274] = 925;
	Y4250[340] = 0;
	{long i; for (i = 358; i < 379; i++) Y4250[i] = 975;};
	Y4250[383] = 1025;
	Y4250[399] = 25;
	Y4250[400] = 934;
	Y4250[401] = 907;
	Y4250[477] = 934;
	Y4250[478] = 937;
	{long i; for (i = 579; i < 582; i++) Y4250[i] = 937;};
	Y4250[624] = 0;
	{long i; for (i = 705; i < 707; i++) Y4250[i] = 934;};
	{long i; for (i = 707; i < 709; i++) Y4250[i] = 937;};
	Y4250[710] = 934;
	{long i; for (i = 711; i < 713; i++) Y4250[i] = 937;};
	{long i; for (i = 781; i < 800; i++) Y4250[i] = 1057;};
	Y4250[812] = 987;
	Y4250[823] = 1089;
	Y4250[824] = 1091;
	{long i; for (i = 825; i < 828; i++) Y4250[i] = 1090;};
	{long i; for (i = 828; i < 832; i++) Y4250[i] = 1107;};
	{long i; for (i = 832; i < 835; i++) Y4250[i] = 1095;};
	Y4250[1009] = 937;
}

char *(*R4295[748])();
void R4295_init () {
	R4295[0] = (char *(*)()) F540_4822;
	R4295[1] = (char *(*)()) F541_4822_4295_2;
	R4295[2] = (char *(*)()) F542_4822_4295_2;
	R4295[3] = (char *(*)()) F543_4822_4295_2;
	R4295[4] = (char *(*)()) F544_4822_4295_2;
	R4295[5] = (char *(*)()) F545_4822_4295_2;
	R4295[6] = (char *(*)()) F546_4822_4295_2;
	R4295[7] = (char *(*)()) F547_4822_4295_2;
	R4295[8] = (char *(*)()) F548_4822_4295_2;
	R4295[9] = (char *(*)()) F549_4822_4295_2;
	R4295[10] = (char *(*)()) F550_4822_4295_2;
	R4295[11] = (char *(*)()) F551_4822_4295_2;
	R4295[61] = (char *(*)()) F553_4896;
	R4295[62] = (char *(*)()) F557_4896_4295_2;
	R4295[63] = (char *(*)()) F556_4896_4295_2;
	{long i; for (i = 64; i < 66; i++) R4295[i] = (char *(*)()) F553_4896;}
	R4295[66] = (char *(*)()) F556_4896_4295_2;
	R4295[67] = (char *(*)()) F557_4896_4295_2;
	R4295[70] = (char *(*)()) F610_5067;
	R4295[71] = (char *(*)()) F611_5067;
	R4295[72] = (char *(*)()) F612_5067_4295_2;
	R4295[73] = (char *(*)()) F613_5067_4295_2;
	R4295[74] = (char *(*)()) F614_5067_4295_2;
	R4295[75] = (char *(*)()) F615_5067_4295_2;
	R4295[76] = (char *(*)()) F610_5067;
	R4295[77] = (char *(*)()) F612_5067_4295_2;
	R4295[78] = (char *(*)()) F610_5067;
	R4295[79] = (char *(*)()) F619_5200;
	R4295[80] = (char *(*)()) F620_5200_4295_2;
	R4295[81] = (char *(*)()) F621_5200_4295_2;
	R4295[82] = (char *(*)()) F622_5200_4295_2;
	R4295[83] = (char *(*)()) F623_5200_4295_2;
	R4295[84] = (char *(*)()) F624_5200_4295_2;
	R4295[85] = (char *(*)()) F625_5200_4295_2;
	R4295[86] = (char *(*)()) F626_5200_4295_2;
	R4295[87] = (char *(*)()) F627_5200_4295_2;
	R4295[88] = (char *(*)()) F628_5200_4295_2;
	R4295[89] = (char *(*)()) F629_5200_4295_2;
	R4295[90] = (char *(*)()) F630_5200_4295_2;
	R4295[91] = (char *(*)()) F619_5200;
	R4295[92] = (char *(*)()) F625_5200_4295_2;
	R4295[93] = (char *(*)()) F622_5200_4295_2;
	{long i; for (i = 96; i < 99; i++) R4295[i] = (char *(*)()) F619_5200;}
	R4295[103] = (char *(*)()) F619_5200;
	R4295[106] = (char *(*)()) F619_5200;
	R4295[108] = (char *(*)()) F619_5200;
	R4295[111] = (char *(*)()) F619_5200;
	{long i; for (i = 113; i < 117; i++) R4295[i] = (char *(*)()) F619_5200;}
	R4295[119] = (char *(*)()) F619_5200;
	R4295[120] = (char *(*)()) F625_5200_4295_2;
	R4295[121] = (char *(*)()) F619_5200;
	R4295[139] = (char *(*)()) F679_5461_4295_2;
	R4295[318] = (char *(*)()) F327_4622_4295_2;
	R4295[448] = (char *(*)()) F983_8236_4295_2;
	R4295[449] = (char *(*)()) F985_8313_4295_2;
	{long i; for (i = 524; i < 526; i++) R4295[i] = (char *(*)()) F553_4896;}
	{long i; for (i = 526; i < 528; i++) R4295[i] = (char *(*)()) F1066_9397;}
	R4295[529] = (char *(*)()) F1066_9397;
	R4295[530] = (char *(*)()) F1070_9452;
	{long i; for (i = 532; i < 534; i++) R4295[i] = (char *(*)()) F1070_9452;}
	R4295[535] = (char *(*)()) F1070_9452;
	R4295[537] = (char *(*)()) F1070_9452;
	R4295[562] = (char *(*)()) F553_4896;
	R4295[571] = (char *(*)()) F553_4896;
	R4295[747] = (char *(*)()) F327_4622_4295_2;
}
static EIF_BOOLEAN F541_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F541_4822(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F542_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F542_4822(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F543_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F543_4822(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F544_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F544_4822(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F545_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F545_4822(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F546_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F546_4822(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F547_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F547_4822(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F548_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F548_4822(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F549_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F549_4822(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F550_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F550_4822(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F551_4822_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F551_4822(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F557_4896_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F557_4896(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F556_4896_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F556_4896(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F612_5067_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F612_5067(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F613_5067_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F613_5067(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F614_5067_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F614_5067(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F615_5067_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F615_5067(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F620_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F620_5200(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F621_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F621_5200(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F622_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F622_5200(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F623_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F623_5200(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F624_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F624_5200(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F625_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F625_5200(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F626_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F626_5200(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F627_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F627_5200(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F628_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F628_5200(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F629_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F629_5200(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F630_5200_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F630_5200(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F679_5461_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F679_5461(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F327_4622_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F327_4622(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F983_8236_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F983_8236(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F985_8313_4295_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F985_8313(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4296[976])();
void R4296_init () {
	R4296[0] = (char *(*)()) F310_4497;
	R4296[228] = (char *(*)()) F445_4698;
	R4296[229] = (char *(*)()) F446_4698;
	R4296[230] = (char *(*)()) F447_4698;
	R4296[231] = (char *(*)()) F449_4698;
	R4296[232] = (char *(*)()) F450_4698;
	R4296[233] = (char *(*)()) F451_4698;
	R4296[234] = (char *(*)()) F448_4698;
	R4296[235] = (char *(*)()) F453_4698;
	R4296[236] = (char *(*)()) F452_4698;
	R4296[237] = (char *(*)()) F454_4698;
	R4296[238] = (char *(*)()) F455_4698;
	R4296[239] = (char *(*)()) F456_4698;
	R4296[289] = (char *(*)()) F445_4698;
	R4296[290] = (char *(*)()) F448_4698;
	R4296[291] = (char *(*)()) F449_4698;
	{long i; for (i = 292; i < 294; i++) R4296[i] = (char *(*)()) F445_4698;}
	R4296[294] = (char *(*)()) F449_4698;
	R4296[295] = (char *(*)()) F448_4698;
	{long i; for (i = 298; i < 300; i++) R4296[i] = (char *(*)()) F445_4698;}
	{long i; for (i = 300; i < 302; i++) R4296[i] = (char *(*)()) F448_4698;}
	R4296[302] = (char *(*)()) F454_4698;
	R4296[303] = (char *(*)()) F448_4698;
	R4296[304] = (char *(*)()) F445_4698;
	R4296[305] = (char *(*)()) F448_4698;
	{long i; for (i = 306; i < 308; i++) R4296[i] = (char *(*)()) F445_4698;}
	R4296[308] = (char *(*)()) F446_4698;
	R4296[309] = (char *(*)()) F447_4698;
	R4296[310] = (char *(*)()) F449_4698;
	R4296[311] = (char *(*)()) F450_4698;
	R4296[312] = (char *(*)()) F451_4698;
	R4296[313] = (char *(*)()) F448_4698;
	R4296[314] = (char *(*)()) F453_4698;
	R4296[315] = (char *(*)()) F452_4698;
	R4296[316] = (char *(*)()) F454_4698;
	R4296[317] = (char *(*)()) F455_4698;
	R4296[318] = (char *(*)()) F456_4698;
	R4296[319] = (char *(*)()) F445_4698;
	R4296[320] = (char *(*)()) F448_4698;
	R4296[321] = (char *(*)()) F449_4698;
	{long i; for (i = 324; i < 327; i++) R4296[i] = (char *(*)()) F445_4698;}
	R4296[331] = (char *(*)()) F445_4698;
	R4296[334] = (char *(*)()) F445_4698;
	R4296[336] = (char *(*)()) F445_4698;
	R4296[339] = (char *(*)()) F445_4698;
	{long i; for (i = 341; i < 345; i++) R4296[i] = (char *(*)()) F445_4698;}
	R4296[347] = (char *(*)()) F445_4698;
	R4296[348] = (char *(*)()) F448_4698;
	R4296[349] = (char *(*)()) F445_4698;
	R4296[367] = (char *(*)()) F442_4676;
	R4296[546] = (char *(*)()) F447_4698;
	R4296[676] = (char *(*)()) F452_4698;
	R4296[677] = (char *(*)()) F447_4698;
	{long i; for (i = 752; i < 754; i++) R4296[i] = (char *(*)()) F445_4698;}
	{long i; for (i = 754; i < 756; i++) R4296[i] = (char *(*)()) F1066_9398;}
	{long i; for (i = 757; i < 759; i++) R4296[i] = (char *(*)()) F1066_9398;}
	{long i; for (i = 760; i < 762; i++) R4296[i] = (char *(*)()) F1066_9398;}
	R4296[763] = (char *(*)()) F1066_9398;
	R4296[765] = (char *(*)()) F1066_9398;
	R4296[790] = (char *(*)()) F445_4698;
	R4296[799] = (char *(*)()) F445_4698;
	R4296[975] = (char *(*)()) F1287_13114;
}

char *(*R4300[976])();
void R4300_init () {
	R4300[0] = (char *(*)()) F298_4469;
	R4300[228] = (char *(*)()) F298_4469;
	R4300[229] = (char *(*)()) F299_4469;
	R4300[230] = (char *(*)()) F300_4469;
	R4300[231] = (char *(*)()) F302_4469;
	R4300[232] = (char *(*)()) F303_4469;
	R4300[233] = (char *(*)()) F304_4469;
	R4300[234] = (char *(*)()) F301_4469;
	R4300[235] = (char *(*)()) F306_4469;
	R4300[236] = (char *(*)()) F305_4469;
	R4300[237] = (char *(*)()) F307_4469;
	R4300[238] = (char *(*)()) F308_4469;
	R4300[239] = (char *(*)()) F309_4469;
	R4300[289] = (char *(*)()) F298_4469;
	R4300[290] = (char *(*)()) F301_4469;
	R4300[291] = (char *(*)()) F302_4469;
	{long i; for (i = 292; i < 294; i++) R4300[i] = (char *(*)()) F298_4469;}
	R4300[294] = (char *(*)()) F302_4469;
	R4300[295] = (char *(*)()) F301_4469;
	{long i; for (i = 298; i < 300; i++) R4300[i] = (char *(*)()) F298_4469;}
	{long i; for (i = 300; i < 302; i++) R4300[i] = (char *(*)()) F301_4469;}
	R4300[302] = (char *(*)()) F307_4469;
	R4300[303] = (char *(*)()) F301_4469;
	R4300[304] = (char *(*)()) F298_4469;
	R4300[305] = (char *(*)()) F301_4469;
	{long i; for (i = 306; i < 308; i++) R4300[i] = (char *(*)()) F298_4469;}
	R4300[308] = (char *(*)()) F299_4469;
	R4300[309] = (char *(*)()) F300_4469;
	R4300[310] = (char *(*)()) F302_4469;
	R4300[311] = (char *(*)()) F303_4469;
	R4300[312] = (char *(*)()) F304_4469;
	R4300[313] = (char *(*)()) F301_4469;
	R4300[314] = (char *(*)()) F306_4469;
	R4300[315] = (char *(*)()) F305_4469;
	R4300[316] = (char *(*)()) F307_4469;
	R4300[317] = (char *(*)()) F308_4469;
	R4300[318] = (char *(*)()) F309_4469;
	R4300[319] = (char *(*)()) F298_4469;
	R4300[320] = (char *(*)()) F301_4469;
	R4300[321] = (char *(*)()) F302_4469;
	{long i; for (i = 324; i < 327; i++) R4300[i] = (char *(*)()) F298_4469;}
	R4300[331] = (char *(*)()) F298_4469;
	R4300[334] = (char *(*)()) F298_4469;
	R4300[336] = (char *(*)()) F298_4469;
	R4300[339] = (char *(*)()) F298_4469;
	{long i; for (i = 341; i < 345; i++) R4300[i] = (char *(*)()) F298_4469;}
	R4300[347] = (char *(*)()) F298_4469;
	R4300[348] = (char *(*)()) F301_4469;
	R4300[349] = (char *(*)()) F298_4469;
	R4300[367] = (char *(*)()) F301_4469;
	R4300[546] = (char *(*)()) F300_4469;
	R4300[676] = (char *(*)()) F305_4469;
	R4300[677] = (char *(*)()) F300_4469;
	{long i; for (i = 752; i < 756; i++) R4300[i] = (char *(*)()) F298_4469;}
	{long i; for (i = 757; i < 759; i++) R4300[i] = (char *(*)()) F298_4469;}
	{long i; for (i = 760; i < 762; i++) R4300[i] = (char *(*)()) F298_4469;}
	R4300[763] = (char *(*)()) F298_4469;
	R4300[765] = (char *(*)()) F298_4469;
	R4300[790] = (char *(*)()) F298_4469;
	R4300[799] = (char *(*)()) F298_4469;
	R4300[975] = (char *(*)()) F300_4469;
}

char *(*R4302[976])();
void R4302_init () {
	R4302[0] = (char *(*)()) F310_4524;
	R4302[228] = (char *(*)()) F540_4866;
	R4302[229] = (char *(*)()) F541_4866;
	R4302[230] = (char *(*)()) F542_4866;
	R4302[231] = (char *(*)()) F543_4866;
	R4302[232] = (char *(*)()) F544_4866;
	R4302[233] = (char *(*)()) F545_4866;
	R4302[234] = (char *(*)()) F546_4866;
	R4302[235] = (char *(*)()) F547_4866;
	R4302[236] = (char *(*)()) F548_4866;
	R4302[237] = (char *(*)()) F549_4866;
	R4302[238] = (char *(*)()) F550_4866;
	R4302[239] = (char *(*)()) F551_4866;
	R4302[289] = (char *(*)()) F325_4637;
	R4302[290] = (char *(*)()) F328_4637;
	R4302[291] = (char *(*)()) F329_4637;
	R4302[292] = (char *(*)()) F604_4996;
	R4302[293] = (char *(*)()) F605_5015;
	R4302[294] = (char *(*)()) F606_5015;
	R4302[295] = (char *(*)()) F607_5015;
	R4302[298] = (char *(*)()) F610_5113;
	R4302[299] = (char *(*)()) F611_5113;
	R4302[300] = (char *(*)()) F612_5113;
	R4302[301] = (char *(*)()) F613_5113;
	R4302[302] = (char *(*)()) F614_5113;
	R4302[303] = (char *(*)()) F615_5113;
	R4302[304] = (char *(*)()) F610_5113;
	R4302[305] = (char *(*)()) F612_5113;
	R4302[306] = (char *(*)()) F610_5113;
	R4302[307] = (char *(*)()) F325_4637;
	R4302[308] = (char *(*)()) F326_4637;
	R4302[309] = (char *(*)()) F327_4637;
	R4302[310] = (char *(*)()) F329_4637;
	R4302[311] = (char *(*)()) F330_4637;
	R4302[312] = (char *(*)()) F331_4637;
	R4302[313] = (char *(*)()) F328_4637;
	R4302[314] = (char *(*)()) F333_4637;
	R4302[315] = (char *(*)()) F332_4637;
	R4302[316] = (char *(*)()) F334_4637;
	R4302[317] = (char *(*)()) F335_4637;
	R4302[318] = (char *(*)()) F336_4637;
	R4302[319] = (char *(*)()) F631_5259;
	R4302[320] = (char *(*)()) F632_5259;
	R4302[321] = (char *(*)()) F633_5259;
	{long i; for (i = 324; i < 327; i++) R4302[i] = (char *(*)()) F325_4637;}
	R4302[331] = (char *(*)()) F325_4637;
	R4302[334] = (char *(*)()) F325_4637;
	R4302[336] = (char *(*)()) F325_4637;
	R4302[339] = (char *(*)()) F325_4637;
	{long i; for (i = 341; i < 345; i++) R4302[i] = (char *(*)()) F325_4637;}
	R4302[347] = (char *(*)()) F325_4637;
	R4302[348] = (char *(*)()) F328_4637;
	R4302[349] = (char *(*)()) F325_4637;
	R4302[367] = (char *(*)()) F444_4691;
	R4302[546] = (char *(*)()) F327_4637;
	R4302[676] = (char *(*)()) F988_8468;
	R4302[677] = (char *(*)()) F989_8559;
	{long i; for (i = 752; i < 754; i++) R4302[i] = (char *(*)()) F325_4637;}
	{long i; for (i = 754; i < 756; i++) R4302[i] = (char *(*)()) F1066_9407;}
	{long i; for (i = 757; i < 759; i++) R4302[i] = (char *(*)()) F1066_9407;}
	{long i; for (i = 760; i < 762; i++) R4302[i] = (char *(*)()) F1066_9407;}
	R4302[763] = (char *(*)()) F1066_9407;
	R4302[765] = (char *(*)()) F1066_9407;
	R4302[790] = (char *(*)()) F325_4637;
	R4302[799] = (char *(*)()) F325_4637;
	R4302[975] = (char *(*)()) F327_4637;
}

EIF_TYPE_INDEX *Y4309_gen_type [3];
EIF_TYPE_INDEX Y4309 [3];
void Y4309_init (void)
{
	egc_routines_types [4309] = Y4309;
	egc_routines_gen_types [4309] = Y4309_gen_type;
	egc_routines_offset [4309] = 309;
	{long i; for (i = 0; i < 3; i++) Y4309[i] = 907;};
}

char *(*R4405[687])();
void R4405_init () {
	R4405[0] = (char *(*)()) F601_4946;
	R4405[1] = (char *(*)()) F602_4946_4405_1;
	R4405[2] = (char *(*)()) F603_4946_4405_1;
	{long i; for (i = 3; i < 5; i++) R4405[i] = (char *(*)()) F601_4946;}
	R4405[5] = (char *(*)()) F603_4946_4405_1;
	R4405[6] = (char *(*)()) F602_4946_4405_1;
	R4405[18] = (char *(*)()) F619_5193;
	R4405[19] = (char *(*)()) F620_5193_4405_1;
	R4405[20] = (char *(*)()) F621_5193_4405_1;
	R4405[21] = (char *(*)()) F622_5193_4405_1;
	R4405[22] = (char *(*)()) F623_5193_4405_1;
	R4405[23] = (char *(*)()) F624_5193_4405_1;
	R4405[24] = (char *(*)()) F625_5193_4405_1;
	R4405[25] = (char *(*)()) F626_5193_4405_1;
	R4405[26] = (char *(*)()) F627_5193_4405_1;
	R4405[27] = (char *(*)()) F628_5193_4405_1;
	R4405[28] = (char *(*)()) F629_5193_4405_1;
	R4405[29] = (char *(*)()) F630_5193_4405_1;
	R4405[30] = (char *(*)()) F619_5193;
	R4405[31] = (char *(*)()) F625_5193_4405_1;
	R4405[32] = (char *(*)()) F622_5193_4405_1;
	{long i; for (i = 35; i < 38; i++) R4405[i] = (char *(*)()) F619_5193;}
	R4405[42] = (char *(*)()) F619_5193;
	R4405[45] = (char *(*)()) F619_5193;
	R4405[47] = (char *(*)()) F619_5193;
	R4405[50] = (char *(*)()) F619_5193;
	{long i; for (i = 52; i < 56; i++) R4405[i] = (char *(*)()) F619_5193;}
	R4405[58] = (char *(*)()) F619_5193;
	R4405[59] = (char *(*)()) F625_5193_4405_1;
	R4405[60] = (char *(*)()) F619_5193;
	R4405[78] = (char *(*)()) F444_4680_4405_1;
	R4405[257] = (char *(*)()) F857_6236_4405_1;
	{long i; for (i = 463; i < 465; i++) R4405[i] = (char *(*)()) F1056_9226;}
	R4405[501] = (char *(*)()) F1056_9226;
	R4405[510] = (char *(*)()) F1056_9226;
	R4405[686] = (char *(*)()) F857_6236_4405_1;
}
static EIF_REFERENCE F602_4946_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F602_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_4946_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F620_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5193_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F444_4680_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F444_4680(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6236_4405_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6236(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4406[687])();
void R4406_init () {
	R4406[0] = (char *(*)()) F601_4957;
	R4406[1] = (char *(*)()) F602_4957;
	R4406[2] = (char *(*)()) F603_4957;
	{long i; for (i = 3; i < 5; i++) R4406[i] = (char *(*)()) F601_4957;}
	R4406[5] = (char *(*)()) F603_4957;
	R4406[6] = (char *(*)()) F602_4957;
	R4406[18] = (char *(*)()) F553_4909;
	R4406[19] = (char *(*)()) F554_4909;
	R4406[20] = (char *(*)()) F555_4909;
	R4406[21] = (char *(*)()) F556_4909;
	R4406[22] = (char *(*)()) F558_4909;
	R4406[23] = (char *(*)()) F559_4909;
	R4406[24] = (char *(*)()) F557_4909;
	R4406[25] = (char *(*)()) F560_4909;
	R4406[26] = (char *(*)()) F561_4909;
	R4406[27] = (char *(*)()) F562_4909;
	R4406[28] = (char *(*)()) F563_4909;
	R4406[29] = (char *(*)()) F564_4909;
	R4406[30] = (char *(*)()) F553_4909;
	R4406[31] = (char *(*)()) F557_4909;
	R4406[32] = (char *(*)()) F556_4909;
	{long i; for (i = 35; i < 38; i++) R4406[i] = (char *(*)()) F553_4909;}
	R4406[42] = (char *(*)()) F553_4909;
	R4406[45] = (char *(*)()) F553_4909;
	R4406[47] = (char *(*)()) F553_4909;
	R4406[50] = (char *(*)()) F553_4909;
	{long i; for (i = 52; i < 56; i++) R4406[i] = (char *(*)()) F553_4909;}
	R4406[58] = (char *(*)()) F553_4909;
	R4406[59] = (char *(*)()) F557_4909;
	R4406[60] = (char *(*)()) F553_4909;
	R4406[78] = (char *(*)()) F328_4630;
	R4406[257] = (char *(*)()) F857_6257;
	{long i; for (i = 463; i < 465; i++) R4406[i] = (char *(*)()) F553_4909;}
	R4406[501] = (char *(*)()) F553_4909;
	R4406[510] = (char *(*)()) F553_4909;
	R4406[686] = (char *(*)()) F857_6257;
}

char *(*R4407[687])();
void R4407_init () {
	R4407[0] = (char *(*)()) F601_4963;
	R4407[1] = (char *(*)()) F602_4963;
	R4407[2] = (char *(*)()) F603_4963;
	{long i; for (i = 3; i < 5; i++) R4407[i] = (char *(*)()) F601_4963;}
	R4407[5] = (char *(*)()) F603_4963;
	R4407[6] = (char *(*)()) F602_4963;
	R4407[18] = (char *(*)()) F619_5219;
	R4407[19] = (char *(*)()) F620_5219;
	R4407[20] = (char *(*)()) F621_5219;
	R4407[21] = (char *(*)()) F622_5219;
	R4407[22] = (char *(*)()) F623_5219;
	R4407[23] = (char *(*)()) F624_5219;
	R4407[24] = (char *(*)()) F625_5219;
	R4407[25] = (char *(*)()) F626_5219;
	R4407[26] = (char *(*)()) F627_5219;
	R4407[27] = (char *(*)()) F628_5219;
	R4407[28] = (char *(*)()) F629_5219;
	R4407[29] = (char *(*)()) F630_5219;
	R4407[30] = (char *(*)()) F619_5219;
	R4407[31] = (char *(*)()) F625_5219;
	R4407[32] = (char *(*)()) F622_5219;
	{long i; for (i = 35; i < 38; i++) R4407[i] = (char *(*)()) F619_5219;}
	R4407[42] = (char *(*)()) F619_5219;
	R4407[45] = (char *(*)()) F619_5219;
	R4407[47] = (char *(*)()) F619_5219;
	R4407[50] = (char *(*)()) F619_5219;
	{long i; for (i = 52; i < 56; i++) R4407[i] = (char *(*)()) F619_5219;}
	R4407[58] = (char *(*)()) F619_5219;
	R4407[59] = (char *(*)()) F625_5219;
	R4407[60] = (char *(*)()) F619_5219;
	R4407[78] = (char *(*)()) F444_4688;
	R4407[257] = (char *(*)()) F857_6312;
	{long i; for (i = 463; i < 465; i++) R4407[i] = (char *(*)()) F1056_9236;}
	R4407[501] = (char *(*)()) F1056_9236;
	R4407[510] = (char *(*)()) F1056_9236;
	R4407[686] = (char *(*)()) F857_6312;
}

char *(*R4413[687])();
void R4413_init () {
	R4413[0] = (char *(*)()) F337_4641;
	R4413[1] = (char *(*)()) F341_4641_4413_4;
	R4413[2] = (char *(*)()) F340_4641_4413_4;
	{long i; for (i = 3; i < 5; i++) R4413[i] = (char *(*)()) F337_4641;}
	R4413[5] = (char *(*)()) F340_4641_4413_4;
	R4413[6] = (char *(*)()) F341_4641_4413_4;
	R4413[18] = (char *(*)()) F619_5225;
	R4413[19] = (char *(*)()) F620_5225_4413_4;
	R4413[20] = (char *(*)()) F621_5225_4413_4;
	R4413[21] = (char *(*)()) F622_5225_4413_4;
	R4413[22] = (char *(*)()) F623_5225_4413_4;
	R4413[23] = (char *(*)()) F624_5225_4413_4;
	R4413[24] = (char *(*)()) F625_5225_4413_4;
	R4413[25] = (char *(*)()) F626_5225_4413_4;
	R4413[26] = (char *(*)()) F627_5225_4413_4;
	R4413[27] = (char *(*)()) F628_5225_4413_4;
	R4413[28] = (char *(*)()) F629_5225_4413_4;
	R4413[29] = (char *(*)()) F630_5225_4413_4;
	R4413[30] = (char *(*)()) F619_5225;
	R4413[31] = (char *(*)()) F625_5225_4413_4;
	R4413[32] = (char *(*)()) F622_5225_4413_4;
	{long i; for (i = 35; i < 38; i++) R4413[i] = (char *(*)()) F619_5225;}
	R4413[42] = (char *(*)()) F619_5225;
	R4413[45] = (char *(*)()) F619_5225;
	R4413[47] = (char *(*)()) F619_5225;
	R4413[50] = (char *(*)()) F619_5225;
	{long i; for (i = 52; i < 56; i++) R4413[i] = (char *(*)()) F619_5225;}
	R4413[58] = (char *(*)()) F619_5225;
	R4413[59] = (char *(*)()) F625_5225_4413_4;
	R4413[60] = (char *(*)()) F619_5225;
	R4413[78] = (char *(*)()) F328_4624_4413_4;
	R4413[257] = (char *(*)()) F339_4641_4413_4;
	{long i; for (i = 463; i < 465; i++) R4413[i] = (char *(*)()) F337_4641;}
	R4413[501] = (char *(*)()) F337_4641;
	R4413[510] = (char *(*)()) F337_4641;
	R4413[686] = (char *(*)()) F339_4641_4413_4;
}
static void F341_4641_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F341_4641(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F340_4641_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F340_4641(Current, *(EIF_BOOLEAN *)arg1);
}
static void F620_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5225(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5225(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5225(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5225(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5225(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5225(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5225(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5225(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5225(Current, *(EIF_POINTER *)arg1);
}
static void F629_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5225(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5225_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5225(Current, *(EIF_REAL_64 *)arg1);
}
static void F328_4624_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F328_4624(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F339_4641_4413_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F339_4641(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4414[687])();
void R4414_init () {
	R4414[0] = (char *(*)()) F601_4949;
	R4414[1] = (char *(*)()) F602_4949;
	R4414[2] = (char *(*)()) F603_4949;
	{long i; for (i = 3; i < 5; i++) R4414[i] = (char *(*)()) F601_4949;}
	R4414[5] = (char *(*)()) F603_4949;
	R4414[6] = (char *(*)()) F602_4949;
	R4414[18] = (char *(*)()) F619_5198;
	R4414[19] = (char *(*)()) F620_5198;
	R4414[20] = (char *(*)()) F621_5198;
	R4414[21] = (char *(*)()) F622_5198;
	R4414[22] = (char *(*)()) F623_5198;
	R4414[23] = (char *(*)()) F624_5198;
	R4414[24] = (char *(*)()) F625_5198;
	R4414[25] = (char *(*)()) F626_5198;
	R4414[26] = (char *(*)()) F627_5198;
	R4414[27] = (char *(*)()) F628_5198;
	R4414[28] = (char *(*)()) F629_5198;
	R4414[29] = (char *(*)()) F630_5198;
	R4414[30] = (char *(*)()) F619_5198;
	R4414[31] = (char *(*)()) F625_5198;
	R4414[32] = (char *(*)()) F622_5198;
	{long i; for (i = 35; i < 38; i++) R4414[i] = (char *(*)()) F619_5198;}
	R4414[42] = (char *(*)()) F619_5198;
	R4414[45] = (char *(*)()) F619_5198;
	R4414[47] = (char *(*)()) F619_5198;
	R4414[50] = (char *(*)()) F619_5198;
	{long i; for (i = 52; i < 56; i++) R4414[i] = (char *(*)()) F619_5198;}
	R4414[58] = (char *(*)()) F619_5198;
	R4414[59] = (char *(*)()) F625_5198;
	R4414[60] = (char *(*)()) F619_5198;
	R4414[78] = (char *(*)()) F444_4679;
	R4414[257] = (char *(*)()) F857_6237;
	{long i; for (i = 463; i < 465; i++) R4414[i] = (char *(*)()) F1056_9227;}
	R4414[501] = (char *(*)()) F1056_9227;
	R4414[510] = (char *(*)()) F1056_9227;
	R4414[686] = (char *(*)()) F857_6237;
}

char *(*R4417[687])();
void R4417_init () {
	R4417[0] = (char *(*)()) F325_4628;
	R4417[1] = (char *(*)()) F328_4628;
	R4417[2] = (char *(*)()) F329_4628;
	{long i; for (i = 3; i < 5; i++) R4417[i] = (char *(*)()) F325_4628;}
	R4417[5] = (char *(*)()) F329_4628;
	R4417[6] = (char *(*)()) F328_4628;
	R4417[18] = (char *(*)()) F325_4628;
	R4417[19] = (char *(*)()) F326_4628;
	R4417[20] = (char *(*)()) F327_4628;
	R4417[21] = (char *(*)()) F329_4628;
	R4417[22] = (char *(*)()) F330_4628;
	R4417[23] = (char *(*)()) F331_4628;
	R4417[24] = (char *(*)()) F328_4628;
	R4417[25] = (char *(*)()) F333_4628;
	R4417[26] = (char *(*)()) F332_4628;
	R4417[27] = (char *(*)()) F334_4628;
	R4417[28] = (char *(*)()) F335_4628;
	R4417[29] = (char *(*)()) F336_4628;
	R4417[30] = (char *(*)()) F325_4628;
	R4417[31] = (char *(*)()) F328_4628;
	R4417[32] = (char *(*)()) F329_4628;
	{long i; for (i = 35; i < 38; i++) R4417[i] = (char *(*)()) F325_4628;}
	R4417[42] = (char *(*)()) F325_4628;
	R4417[45] = (char *(*)()) F325_4628;
	R4417[47] = (char *(*)()) F325_4628;
	R4417[50] = (char *(*)()) F325_4628;
	{long i; for (i = 52; i < 56; i++) R4417[i] = (char *(*)()) F325_4628;}
	R4417[58] = (char *(*)()) F325_4628;
	R4417[59] = (char *(*)()) F328_4628;
	R4417[60] = (char *(*)()) F325_4628;
	R4417[78] = (char *(*)()) F328_4628;
	R4417[257] = (char *(*)()) F327_4628;
	{long i; for (i = 463; i < 465; i++) R4417[i] = (char *(*)()) F325_4628;}
	R4417[501] = (char *(*)()) F325_4628;
	R4417[510] = (char *(*)()) F325_4628;
	R4417[686] = (char *(*)()) F327_4628;
}

char *(*R4418[687])();
void R4418_init () {
	R4418[0] = (char *(*)()) F601_4955;
	R4418[1] = (char *(*)()) F602_4955;
	R4418[2] = (char *(*)()) F603_4955;
	{long i; for (i = 3; i < 5; i++) R4418[i] = (char *(*)()) F601_4955;}
	R4418[5] = (char *(*)()) F603_4955;
	R4418[6] = (char *(*)()) F602_4955;
	R4418[18] = (char *(*)()) F577_4933;
	R4418[19] = (char *(*)()) F578_4933;
	R4418[20] = (char *(*)()) F579_4933;
	R4418[21] = (char *(*)()) F580_4933;
	R4418[22] = (char *(*)()) F582_4933;
	R4418[23] = (char *(*)()) F583_4933;
	R4418[24] = (char *(*)()) F581_4933;
	R4418[25] = (char *(*)()) F584_4933;
	R4418[26] = (char *(*)()) F585_4933;
	R4418[27] = (char *(*)()) F586_4933;
	R4418[28] = (char *(*)()) F587_4933;
	R4418[29] = (char *(*)()) F588_4933;
	R4418[30] = (char *(*)()) F577_4933;
	R4418[31] = (char *(*)()) F581_4933;
	R4418[32] = (char *(*)()) F580_4933;
	{long i; for (i = 35; i < 38; i++) R4418[i] = (char *(*)()) F577_4933;}
	R4418[42] = (char *(*)()) F577_4933;
	R4418[45] = (char *(*)()) F577_4933;
	R4418[47] = (char *(*)()) F577_4933;
	R4418[50] = (char *(*)()) F577_4933;
	{long i; for (i = 52; i < 56; i++) R4418[i] = (char *(*)()) F577_4933;}
	R4418[58] = (char *(*)()) F577_4933;
	R4418[59] = (char *(*)()) F581_4933;
	R4418[60] = (char *(*)()) F577_4933;
	R4418[78] = (char *(*)()) F444_4681;
	R4418[257] = (char *(*)()) F857_6255;
	{long i; for (i = 463; i < 465; i++) R4418[i] = (char *(*)()) F577_4933;}
	R4418[501] = (char *(*)()) F577_4933;
	R4418[510] = (char *(*)()) F577_4933;
	R4418[686] = (char *(*)()) F857_6255;
}

char *(*R4419[511])();
void R4419_init () {
	R4419[0] = (char *(*)()) F601_4964;
	R4419[1] = (char *(*)()) F602_4964;
	R4419[2] = (char *(*)()) F603_4964;
	{long i; for (i = 3; i < 5; i++) R4419[i] = (char *(*)()) F601_4964;}
	R4419[5] = (char *(*)()) F603_4964;
	R4419[6] = (char *(*)()) F602_4964;
	R4419[18] = (char *(*)()) F619_5220;
	R4419[19] = (char *(*)()) F620_5220;
	R4419[20] = (char *(*)()) F621_5220;
	R4419[21] = (char *(*)()) F622_5220;
	R4419[22] = (char *(*)()) F623_5220;
	R4419[23] = (char *(*)()) F624_5220;
	R4419[24] = (char *(*)()) F625_5220;
	R4419[25] = (char *(*)()) F626_5220;
	R4419[26] = (char *(*)()) F627_5220;
	R4419[27] = (char *(*)()) F628_5220;
	R4419[28] = (char *(*)()) F629_5220;
	R4419[29] = (char *(*)()) F630_5220;
	R4419[30] = (char *(*)()) F619_5220;
	R4419[31] = (char *(*)()) F625_5220;
	R4419[32] = (char *(*)()) F622_5220;
	{long i; for (i = 35; i < 38; i++) R4419[i] = (char *(*)()) F619_5220;}
	R4419[42] = (char *(*)()) F619_5220;
	R4419[45] = (char *(*)()) F619_5220;
	R4419[47] = (char *(*)()) F619_5220;
	R4419[50] = (char *(*)()) F619_5220;
	{long i; for (i = 52; i < 56; i++) R4419[i] = (char *(*)()) F619_5220;}
	R4419[58] = (char *(*)()) F619_5220;
	R4419[59] = (char *(*)()) F625_5220;
	R4419[60] = (char *(*)()) F619_5220;
	{long i; for (i = 463; i < 465; i++) R4419[i] = (char *(*)()) F553_4903;}
	R4419[501] = (char *(*)()) F553_4903;
	R4419[510] = (char *(*)()) F553_4903;
}


#ifdef __cplusplus
}
#endif
