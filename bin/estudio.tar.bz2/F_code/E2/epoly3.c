#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2798[1154];
void O2798_init () {
	O2798[0] =  + _REFACS_8_;
	{long i; for (i = 1056; i < 1058; i++) O2798[i] =  + _REFACS_14_;}
	{long i; for (i = 1058; i < 1061; i++) O2798[i] =  + _REFACS_15_;}
	O2798[1061] =  + _REFACS_16_;
	{long i; for (i = 1062; i < 1064; i++) O2798[i] =  + _REFACS_15_;}
	O2798[1064] =  + _REFACS_16_;
	O2798[1065] =  + _REFACS_15_;
	{long i; for (i = 1066; i < 1076; i++) O2798[i] =  + _REFACS_16_;}
	{long i; for (i = 1076; i < 1078; i++) O2798[i] =  + _REFACS_20_;}
	{long i; for (i = 1078; i < 1080; i++) O2798[i] =  + _REFACS_23_;}
	{long i; for (i = 1080; i < 1084; i++) O2798[i] =  + _REFACS_16_;}
	{long i; for (i = 1084; i < 1086; i++) O2798[i] =  + _REFACS_20_;}
	{long i; for (i = 1086; i < 1088; i++) O2798[i] =  + _REFACS_23_;}
	O2798[1088] =  + _REFACS_14_;
	O2798[1089] =  + _REFACS_18_;
	O2798[1090] =  + _REFACS_16_;
	{long i; for (i = 1091; i < 1093; i++) O2798[i] =  + _REFACS_15_;}
	O2798[1093] =  + _REFACS_14_;
	{long i; for (i = 1094; i < 1096; i++) O2798[i] =  + _REFACS_15_;}
	{long i; for (i = 1096; i < 1098; i++) O2798[i] =  + _REFACS_16_;}
	O2798[1098] =  + _REFACS_15_;
	O2798[1099] =  + _REFACS_16_;
	O2798[1100] =  + _REFACS_20_;
	O2798[1101] =  + _REFACS_15_;
	O2798[1102] =  + _REFACS_18_;
	O2798[1103] =  + _REFACS_14_;
	O2798[1104] =  + _REFACS_15_;
	O2798[1105] =  + _REFACS_18_;
	O2798[1106] =  + _REFACS_16_;
	O2798[1107] =  + _REFACS_15_;
	O2798[1108] =  + _REFACS_14_;
	{long i; for (i = 1109; i < 1111; i++) O2798[i] =  + _REFACS_15_;}
	{long i; for (i = 1111; i < 1113; i++) O2798[i] =  + _REFACS_16_;}
	{long i; for (i = 1113; i < 1115; i++) O2798[i] =  + _REFACS_15_;}
	O2798[1115] =  + _REFACS_18_;
	O2798[1116] =  + _REFACS_16_;
	O2798[1117] =  + _REFACS_20_;
	O2798[1145] =  + _REFACS_14_;
	O2798[1148] =  + _REFACS_14_;
	O2798[1150] =  + _REFACS_14_;
	O2798[1153] =  + _REFACS_14_;
}

long O2800[1154];
void O2800_init () {
	O2800[0] =  + _REFACS_9_;
	{long i; for (i = 1056; i < 1058; i++) O2800[i] =  + _REFACS_15_;}
	{long i; for (i = 1058; i < 1061; i++) O2800[i] =  + _REFACS_16_;}
	O2800[1061] =  + _REFACS_17_;
	{long i; for (i = 1062; i < 1064; i++) O2800[i] =  + _REFACS_16_;}
	O2800[1064] =  + _REFACS_17_;
	O2800[1065] =  + _REFACS_16_;
	{long i; for (i = 1066; i < 1076; i++) O2800[i] =  + _REFACS_17_;}
	{long i; for (i = 1076; i < 1078; i++) O2800[i] =  + _REFACS_21_;}
	{long i; for (i = 1078; i < 1080; i++) O2800[i] =  + _REFACS_24_;}
	{long i; for (i = 1080; i < 1084; i++) O2800[i] =  + _REFACS_17_;}
	{long i; for (i = 1084; i < 1086; i++) O2800[i] =  + _REFACS_21_;}
	{long i; for (i = 1086; i < 1088; i++) O2800[i] =  + _REFACS_24_;}
	O2800[1088] =  + _REFACS_15_;
	O2800[1089] =  + _REFACS_19_;
	O2800[1090] =  + _REFACS_17_;
	{long i; for (i = 1091; i < 1093; i++) O2800[i] =  + _REFACS_16_;}
	O2800[1093] =  + _REFACS_15_;
	{long i; for (i = 1094; i < 1096; i++) O2800[i] =  + _REFACS_16_;}
	{long i; for (i = 1096; i < 1098; i++) O2800[i] =  + _REFACS_17_;}
	O2800[1098] =  + _REFACS_16_;
	O2800[1099] =  + _REFACS_17_;
	O2800[1100] =  + _REFACS_21_;
	O2800[1101] =  + _REFACS_16_;
	O2800[1102] =  + _REFACS_19_;
	O2800[1103] =  + _REFACS_15_;
	O2800[1104] =  + _REFACS_16_;
	O2800[1105] =  + _REFACS_19_;
	O2800[1106] =  + _REFACS_17_;
	O2800[1107] =  + _REFACS_16_;
	O2800[1108] =  + _REFACS_15_;
	{long i; for (i = 1109; i < 1111; i++) O2800[i] =  + _REFACS_16_;}
	{long i; for (i = 1111; i < 1113; i++) O2800[i] =  + _REFACS_17_;}
	{long i; for (i = 1113; i < 1115; i++) O2800[i] =  + _REFACS_16_;}
	O2800[1115] =  + _REFACS_19_;
	O2800[1116] =  + _REFACS_17_;
	O2800[1117] =  + _REFACS_21_;
	O2800[1145] =  + _REFACS_15_;
	O2800[1148] =  + _REFACS_15_;
	O2800[1150] =  + _REFACS_15_;
	O2800[1153] =  + _REFACS_15_;
}

long O2802[1154];
void O2802_init () {
	O2802[0] =  + _REFACS_10_;
	{long i; for (i = 1056; i < 1058; i++) O2802[i] =  + _REFACS_16_;}
	{long i; for (i = 1058; i < 1061; i++) O2802[i] =  + _REFACS_17_;}
	O2802[1061] =  + _REFACS_18_;
	{long i; for (i = 1062; i < 1064; i++) O2802[i] =  + _REFACS_17_;}
	O2802[1064] =  + _REFACS_18_;
	O2802[1065] =  + _REFACS_17_;
	{long i; for (i = 1066; i < 1076; i++) O2802[i] =  + _REFACS_18_;}
	{long i; for (i = 1076; i < 1078; i++) O2802[i] =  + _REFACS_22_;}
	{long i; for (i = 1078; i < 1080; i++) O2802[i] =  + _REFACS_25_;}
	{long i; for (i = 1080; i < 1084; i++) O2802[i] =  + _REFACS_18_;}
	{long i; for (i = 1084; i < 1086; i++) O2802[i] =  + _REFACS_22_;}
	{long i; for (i = 1086; i < 1088; i++) O2802[i] =  + _REFACS_25_;}
	O2802[1088] =  + _REFACS_16_;
	O2802[1089] =  + _REFACS_20_;
	O2802[1090] =  + _REFACS_18_;
	{long i; for (i = 1091; i < 1093; i++) O2802[i] =  + _REFACS_17_;}
	O2802[1093] =  + _REFACS_16_;
	{long i; for (i = 1094; i < 1096; i++) O2802[i] =  + _REFACS_17_;}
	{long i; for (i = 1096; i < 1098; i++) O2802[i] =  + _REFACS_18_;}
	O2802[1098] =  + _REFACS_17_;
	O2802[1099] =  + _REFACS_18_;
	O2802[1100] =  + _REFACS_22_;
	O2802[1101] =  + _REFACS_17_;
	O2802[1102] =  + _REFACS_20_;
	O2802[1103] =  + _REFACS_16_;
	O2802[1104] =  + _REFACS_17_;
	O2802[1105] =  + _REFACS_20_;
	O2802[1106] =  + _REFACS_18_;
	O2802[1107] =  + _REFACS_17_;
	O2802[1108] =  + _REFACS_16_;
	{long i; for (i = 1109; i < 1111; i++) O2802[i] =  + _REFACS_17_;}
	{long i; for (i = 1111; i < 1113; i++) O2802[i] =  + _REFACS_18_;}
	{long i; for (i = 1113; i < 1115; i++) O2802[i] =  + _REFACS_17_;}
	O2802[1115] =  + _REFACS_20_;
	O2802[1116] =  + _REFACS_18_;
	O2802[1117] =  + _REFACS_22_;
	O2802[1145] =  + _REFACS_16_;
	O2802[1148] =  + _REFACS_16_;
	O2802[1150] =  + _REFACS_16_;
	O2802[1153] =  + _REFACS_16_;
}

long O2804[1154];
void O2804_init () {
	O2804[0] =  + _REFACS_11_;
	{long i; for (i = 1056; i < 1058; i++) O2804[i] =  + _REFACS_17_;}
	{long i; for (i = 1058; i < 1061; i++) O2804[i] =  + _REFACS_18_;}
	O2804[1061] =  + _REFACS_19_;
	{long i; for (i = 1062; i < 1064; i++) O2804[i] =  + _REFACS_18_;}
	O2804[1064] =  + _REFACS_19_;
	O2804[1065] =  + _REFACS_18_;
	{long i; for (i = 1066; i < 1076; i++) O2804[i] =  + _REFACS_19_;}
	{long i; for (i = 1076; i < 1078; i++) O2804[i] =  + _REFACS_23_;}
	{long i; for (i = 1078; i < 1080; i++) O2804[i] =  + _REFACS_26_;}
	{long i; for (i = 1080; i < 1084; i++) O2804[i] =  + _REFACS_19_;}
	{long i; for (i = 1084; i < 1086; i++) O2804[i] =  + _REFACS_23_;}
	{long i; for (i = 1086; i < 1088; i++) O2804[i] =  + _REFACS_26_;}
	O2804[1088] =  + _REFACS_17_;
	O2804[1089] =  + _REFACS_21_;
	O2804[1090] =  + _REFACS_19_;
	{long i; for (i = 1091; i < 1093; i++) O2804[i] =  + _REFACS_18_;}
	O2804[1093] =  + _REFACS_17_;
	{long i; for (i = 1094; i < 1096; i++) O2804[i] =  + _REFACS_18_;}
	{long i; for (i = 1096; i < 1098; i++) O2804[i] =  + _REFACS_19_;}
	O2804[1098] =  + _REFACS_18_;
	O2804[1099] =  + _REFACS_19_;
	O2804[1100] =  + _REFACS_23_;
	O2804[1101] =  + _REFACS_18_;
	O2804[1102] =  + _REFACS_21_;
	O2804[1103] =  + _REFACS_17_;
	O2804[1104] =  + _REFACS_18_;
	O2804[1105] =  + _REFACS_21_;
	O2804[1106] =  + _REFACS_19_;
	O2804[1107] =  + _REFACS_18_;
	O2804[1108] =  + _REFACS_17_;
	{long i; for (i = 1109; i < 1111; i++) O2804[i] =  + _REFACS_18_;}
	{long i; for (i = 1111; i < 1113; i++) O2804[i] =  + _REFACS_19_;}
	{long i; for (i = 1113; i < 1115; i++) O2804[i] =  + _REFACS_18_;}
	O2804[1115] =  + _REFACS_21_;
	O2804[1116] =  + _REFACS_19_;
	O2804[1117] =  + _REFACS_23_;
	O2804[1145] =  + _REFACS_17_;
	O2804[1148] =  + _REFACS_17_;
	O2804[1150] =  + _REFACS_17_;
	O2804[1153] =  + _REFACS_17_;
}

long O2806[1154];
void O2806_init () {
	O2806[0] =  + _REFACS_12_;
	{long i; for (i = 1056; i < 1058; i++) O2806[i] =  + _REFACS_18_;}
	{long i; for (i = 1058; i < 1061; i++) O2806[i] =  + _REFACS_19_;}
	O2806[1061] =  + _REFACS_20_;
	{long i; for (i = 1062; i < 1064; i++) O2806[i] =  + _REFACS_19_;}
	O2806[1064] =  + _REFACS_20_;
	O2806[1065] =  + _REFACS_19_;
	{long i; for (i = 1066; i < 1076; i++) O2806[i] =  + _REFACS_20_;}
	{long i; for (i = 1076; i < 1078; i++) O2806[i] =  + _REFACS_24_;}
	{long i; for (i = 1078; i < 1080; i++) O2806[i] =  + _REFACS_27_;}
	{long i; for (i = 1080; i < 1084; i++) O2806[i] =  + _REFACS_20_;}
	{long i; for (i = 1084; i < 1086; i++) O2806[i] =  + _REFACS_24_;}
	{long i; for (i = 1086; i < 1088; i++) O2806[i] =  + _REFACS_27_;}
	O2806[1088] =  + _REFACS_18_;
	O2806[1089] =  + _REFACS_22_;
	O2806[1090] =  + _REFACS_20_;
	{long i; for (i = 1091; i < 1093; i++) O2806[i] =  + _REFACS_19_;}
	O2806[1093] =  + _REFACS_18_;
	{long i; for (i = 1094; i < 1096; i++) O2806[i] =  + _REFACS_19_;}
	{long i; for (i = 1096; i < 1098; i++) O2806[i] =  + _REFACS_20_;}
	O2806[1098] =  + _REFACS_19_;
	O2806[1099] =  + _REFACS_20_;
	O2806[1100] =  + _REFACS_24_;
	O2806[1101] =  + _REFACS_19_;
	O2806[1102] =  + _REFACS_22_;
	O2806[1103] =  + _REFACS_18_;
	O2806[1104] =  + _REFACS_19_;
	O2806[1105] =  + _REFACS_22_;
	O2806[1106] =  + _REFACS_20_;
	O2806[1107] =  + _REFACS_19_;
	O2806[1108] =  + _REFACS_18_;
	{long i; for (i = 1109; i < 1111; i++) O2806[i] =  + _REFACS_19_;}
	{long i; for (i = 1111; i < 1113; i++) O2806[i] =  + _REFACS_20_;}
	{long i; for (i = 1113; i < 1115; i++) O2806[i] =  + _REFACS_19_;}
	O2806[1115] =  + _REFACS_22_;
	O2806[1116] =  + _REFACS_20_;
	O2806[1117] =  + _REFACS_24_;
	O2806[1145] =  + _REFACS_18_;
	O2806[1148] =  + _REFACS_18_;
	O2806[1150] =  + _REFACS_18_;
	O2806[1153] =  + _REFACS_18_;
}

long O2809[1154];
void O2809_init () {
	O2809[0] =  + _REFACS_13_;
	{long i; for (i = 1056; i < 1058; i++) O2809[i] =  + _REFACS_19_;}
	{long i; for (i = 1058; i < 1061; i++) O2809[i] =  + _REFACS_20_;}
	O2809[1061] =  + _REFACS_21_;
	{long i; for (i = 1062; i < 1064; i++) O2809[i] =  + _REFACS_20_;}
	O2809[1064] =  + _REFACS_21_;
	O2809[1065] =  + _REFACS_20_;
	{long i; for (i = 1066; i < 1076; i++) O2809[i] =  + _REFACS_21_;}
	{long i; for (i = 1076; i < 1078; i++) O2809[i] =  + _REFACS_25_;}
	{long i; for (i = 1078; i < 1080; i++) O2809[i] =  + _REFACS_28_;}
	{long i; for (i = 1080; i < 1084; i++) O2809[i] =  + _REFACS_21_;}
	{long i; for (i = 1084; i < 1086; i++) O2809[i] =  + _REFACS_25_;}
	{long i; for (i = 1086; i < 1088; i++) O2809[i] =  + _REFACS_28_;}
	O2809[1088] =  + _REFACS_19_;
	O2809[1089] =  + _REFACS_23_;
	O2809[1090] =  + _REFACS_21_;
	{long i; for (i = 1091; i < 1093; i++) O2809[i] =  + _REFACS_20_;}
	O2809[1093] =  + _REFACS_19_;
	{long i; for (i = 1094; i < 1096; i++) O2809[i] =  + _REFACS_20_;}
	{long i; for (i = 1096; i < 1098; i++) O2809[i] =  + _REFACS_21_;}
	O2809[1098] =  + _REFACS_20_;
	O2809[1099] =  + _REFACS_21_;
	O2809[1100] =  + _REFACS_25_;
	O2809[1101] =  + _REFACS_20_;
	O2809[1102] =  + _REFACS_23_;
	O2809[1103] =  + _REFACS_19_;
	O2809[1104] =  + _REFACS_20_;
	O2809[1105] =  + _REFACS_23_;
	O2809[1106] =  + _REFACS_21_;
	O2809[1107] =  + _REFACS_20_;
	O2809[1108] =  + _REFACS_19_;
	{long i; for (i = 1109; i < 1111; i++) O2809[i] =  + _REFACS_20_;}
	{long i; for (i = 1111; i < 1113; i++) O2809[i] =  + _REFACS_21_;}
	{long i; for (i = 1113; i < 1115; i++) O2809[i] =  + _REFACS_20_;}
	O2809[1115] =  + _REFACS_23_;
	O2809[1116] =  + _REFACS_21_;
	O2809[1117] =  + _REFACS_25_;
	O2809[1145] =  + _REFACS_19_;
	O2809[1148] =  + _REFACS_19_;
	O2809[1150] =  + _REFACS_19_;
	O2809[1153] =  + _REFACS_19_;
}

long O2839[140];
void O2839_init () {
	O2839[0] = + _PTROFF_1_1_0_0_0_0_;
	O2839[1] = + _PTROFF_3_2_0_1_0_0_;
	{long i; for (i = 135; i < 138; i++) O2839[i] = + _PTROFF_3_2_0_2_0_0_;}
	O2839[139] = + _PTROFF_3_3_0_2_0_0_;
}

long O2840[140];
void O2840_init () {
	O2840[0] = + _CHROFF_1_0_;
	O2840[1] = + _CHROFF_3_0_;
	{long i; for (i = 135; i < 138; i++) O2840[i] = + _CHROFF_3_0_;}
	O2840[139] = + _CHROFF_3_1_;
}

long O2855[140];
void O2855_init () {
	{long i; for (i = 0; i < 2; i++) O2855[i] = 0;}
	{long i; for (i = 135; i < 138; i++) O2855[i] = 0;}
	O2855[139] =  + _REFACS_1_;
}

long O2875[1146];
void O2875_init () {
	O2875[0] = 0;
	{long i; for (i = 1018; i < 1020; i++) O2875[i] =  + _REFACS_2_;}
	{long i; for (i = 1046; i < 1048; i++) O2875[i] =  + _REFACS_4_;}
	{long i; for (i = 1048; i < 1050; i++) O2875[i] =  + _REFACS_21_;}
	{long i; for (i = 1050; i < 1053; i++) O2875[i] =  + _REFACS_22_;}
	O2875[1053] =  + _REFACS_23_;
	{long i; for (i = 1054; i < 1056; i++) O2875[i] =  + _REFACS_22_;}
	O2875[1056] =  + _REFACS_23_;
	O2875[1057] =  + _REFACS_22_;
	{long i; for (i = 1058; i < 1068; i++) O2875[i] =  + _REFACS_23_;}
	{long i; for (i = 1068; i < 1070; i++) O2875[i] =  + _REFACS_27_;}
	{long i; for (i = 1070; i < 1072; i++) O2875[i] =  + _REFACS_30_;}
	{long i; for (i = 1072; i < 1076; i++) O2875[i] =  + _REFACS_23_;}
	{long i; for (i = 1076; i < 1078; i++) O2875[i] =  + _REFACS_27_;}
	{long i; for (i = 1078; i < 1080; i++) O2875[i] =  + _REFACS_30_;}
	O2875[1080] =  + _REFACS_21_;
	O2875[1081] =  + _REFACS_25_;
	O2875[1082] =  + _REFACS_23_;
	{long i; for (i = 1083; i < 1085; i++) O2875[i] =  + _REFACS_22_;}
	O2875[1085] =  + _REFACS_21_;
	{long i; for (i = 1086; i < 1088; i++) O2875[i] =  + _REFACS_22_;}
	{long i; for (i = 1088; i < 1090; i++) O2875[i] =  + _REFACS_23_;}
	O2875[1090] =  + _REFACS_22_;
	O2875[1091] =  + _REFACS_23_;
	O2875[1092] =  + _REFACS_27_;
	O2875[1093] =  + _REFACS_22_;
	O2875[1094] =  + _REFACS_25_;
	O2875[1095] =  + _REFACS_21_;
	O2875[1096] =  + _REFACS_22_;
	O2875[1097] =  + _REFACS_25_;
	O2875[1098] =  + _REFACS_23_;
	O2875[1099] =  + _REFACS_22_;
	O2875[1100] =  + _REFACS_21_;
	{long i; for (i = 1101; i < 1103; i++) O2875[i] =  + _REFACS_22_;}
	{long i; for (i = 1103; i < 1105; i++) O2875[i] =  + _REFACS_23_;}
	{long i; for (i = 1105; i < 1107; i++) O2875[i] =  + _REFACS_22_;}
	O2875[1107] =  + _REFACS_25_;
	O2875[1108] =  + _REFACS_23_;
	O2875[1109] =  + _REFACS_27_;
	O2875[1110] =  + _REFACS_7_;
	{long i; for (i = 1111; i < 1113; i++) O2875[i] =  + _REFACS_9_;}
	O2875[1113] =  + _REFACS_7_;
	{long i; for (i = 1114; i < 1118; i++) O2875[i] =  + _REFACS_11_;}
	{long i; for (i = 1118; i < 1120; i++) O2875[i] =  + _REFACS_7_;}
	{long i; for (i = 1120; i < 1124; i++) O2875[i] =  + _REFACS_8_;}
	O2875[1124] =  + _REFACS_9_;
	{long i; for (i = 1125; i < 1129; i++) O2875[i] =  + _REFACS_8_;}
	{long i; for (i = 1129; i < 1132; i++) O2875[i] =  + _REFACS_9_;}
	{long i; for (i = 1132; i < 1136; i++) O2875[i] =  + _REFACS_11_;}
	O2875[1137] =  + _REFACS_21_;
	O2875[1140] =  + _REFACS_21_;
	O2875[1142] =  + _REFACS_21_;
	O2875[1145] =  + _REFACS_21_;
}

long O2876[1146];
void O2876_init () {
	O2876[0] =  + _REFACS_1_;
	{long i; for (i = 1018; i < 1020; i++) O2876[i] =  + _REFACS_3_;}
	{long i; for (i = 1046; i < 1048; i++) O2876[i] =  + _REFACS_5_;}
	{long i; for (i = 1048; i < 1050; i++) O2876[i] =  + _REFACS_22_;}
	{long i; for (i = 1050; i < 1053; i++) O2876[i] =  + _REFACS_23_;}
	O2876[1053] =  + _REFACS_24_;
	{long i; for (i = 1054; i < 1056; i++) O2876[i] =  + _REFACS_23_;}
	O2876[1056] =  + _REFACS_24_;
	O2876[1057] =  + _REFACS_23_;
	{long i; for (i = 1058; i < 1068; i++) O2876[i] =  + _REFACS_24_;}
	{long i; for (i = 1068; i < 1070; i++) O2876[i] =  + _REFACS_28_;}
	{long i; for (i = 1070; i < 1072; i++) O2876[i] =  + _REFACS_31_;}
	{long i; for (i = 1072; i < 1076; i++) O2876[i] =  + _REFACS_24_;}
	{long i; for (i = 1076; i < 1078; i++) O2876[i] =  + _REFACS_28_;}
	{long i; for (i = 1078; i < 1080; i++) O2876[i] =  + _REFACS_31_;}
	O2876[1080] =  + _REFACS_22_;
	O2876[1081] =  + _REFACS_26_;
	O2876[1082] =  + _REFACS_24_;
	{long i; for (i = 1083; i < 1085; i++) O2876[i] =  + _REFACS_23_;}
	O2876[1085] =  + _REFACS_22_;
	{long i; for (i = 1086; i < 1088; i++) O2876[i] =  + _REFACS_23_;}
	{long i; for (i = 1088; i < 1090; i++) O2876[i] =  + _REFACS_24_;}
	O2876[1090] =  + _REFACS_23_;
	O2876[1091] =  + _REFACS_24_;
	O2876[1092] =  + _REFACS_28_;
	O2876[1093] =  + _REFACS_23_;
	O2876[1094] =  + _REFACS_26_;
	O2876[1095] =  + _REFACS_22_;
	O2876[1096] =  + _REFACS_23_;
	O2876[1097] =  + _REFACS_26_;
	O2876[1098] =  + _REFACS_24_;
	O2876[1099] =  + _REFACS_23_;
	O2876[1100] =  + _REFACS_22_;
	{long i; for (i = 1101; i < 1103; i++) O2876[i] =  + _REFACS_23_;}
	{long i; for (i = 1103; i < 1105; i++) O2876[i] =  + _REFACS_24_;}
	{long i; for (i = 1105; i < 1107; i++) O2876[i] =  + _REFACS_23_;}
	O2876[1107] =  + _REFACS_26_;
	O2876[1108] =  + _REFACS_24_;
	O2876[1109] =  + _REFACS_28_;
	O2876[1110] =  + _REFACS_8_;
	{long i; for (i = 1111; i < 1113; i++) O2876[i] =  + _REFACS_10_;}
	O2876[1113] =  + _REFACS_8_;
	{long i; for (i = 1114; i < 1118; i++) O2876[i] =  + _REFACS_12_;}
	{long i; for (i = 1118; i < 1120; i++) O2876[i] =  + _REFACS_8_;}
	{long i; for (i = 1120; i < 1124; i++) O2876[i] =  + _REFACS_9_;}
	O2876[1124] =  + _REFACS_10_;
	{long i; for (i = 1125; i < 1129; i++) O2876[i] =  + _REFACS_9_;}
	{long i; for (i = 1129; i < 1132; i++) O2876[i] =  + _REFACS_10_;}
	{long i; for (i = 1132; i < 1136; i++) O2876[i] =  + _REFACS_12_;}
	O2876[1137] =  + _REFACS_22_;
	O2876[1140] =  + _REFACS_22_;
	O2876[1142] =  + _REFACS_22_;
	O2876[1145] =  + _REFACS_22_;
}

long O2877[1146];
void O2877_init () {
	O2877[0] = + _I16OFF_3_1_0_;
	O2877[1018] = + _I16OFF_7_5_0_;
	O2877[1019] = + _I16OFF_8_6_0_;
	O2877[1046] = + _I16OFF_13_5_0_;
	O2877[1047] = + _I16OFF_16_7_0_;
	O2877[1048] = + _I16OFF_35_9_0_;
	O2877[1049] = + _I16OFF_42_12_0_;
	O2877[1050] = + _I16OFF_37_9_0_;
	O2877[1051] = + _I16OFF_46_12_0_;
	O2877[1052] = + _I16OFF_37_9_0_;
	O2877[1053] = + _I16OFF_38_9_0_;
	O2877[1054] = + _I16OFF_37_9_0_;
	O2877[1055] = + _I16OFF_47_12_0_;
	O2877[1056] = + _I16OFF_49_12_0_;
	O2877[1057] = + _I16OFF_47_12_0_;
	{long i; for (i = 1058; i < 1061; i++) O2877[i] = + _I16OFF_39_10_0_;}
	{long i; for (i = 1061; i < 1064; i++) O2877[i] = + _I16OFF_49_13_0_;}
	{long i; for (i = 1064; i < 1068; i++) O2877[i] = + _I16OFF_39_10_0_;}
	O2877[1068] = + _I16OFF_47_12_0_;
	O2877[1069] = + _I16OFF_47_14_0_;
	O2877[1070] = + _I16OFF_50_13_0_;
	O2877[1071] = + _I16OFF_53_13_0_;
	O2877[1072] = + _I16OFF_49_13_0_;
	O2877[1073] = + _I16OFF_51_13_0_;
	{long i; for (i = 1074; i < 1076; i++) O2877[i] = + _I16OFF_49_14_0_;}
	O2877[1076] = + _I16OFF_59_21_0_;
	O2877[1077] = + _I16OFF_59_23_0_;
	O2877[1078] = + _I16OFF_65_25_0_;
	O2877[1079] = + _I16OFF_68_26_0_;
	O2877[1080] = + _I16OFF_35_9_0_;
	O2877[1081] = + _I16OFF_43_9_0_;
	{long i; for (i = 1082; i < 1084; i++) O2877[i] = + _I16OFF_37_9_0_;}
	O2877[1084] = + _I16OFF_37_10_0_;
	O2877[1085] = + _I16OFF_35_9_0_;
	{long i; for (i = 1086; i < 1088; i++) O2877[i] = + _I16OFF_36_9_0_;}
	O2877[1088] = + _I16OFF_37_9_0_;
	O2877[1089] = + _I16OFF_37_10_0_;
	O2877[1090] = + _I16OFF_36_9_0_;
	O2877[1091] = + _I16OFF_37_9_0_;
	O2877[1092] = + _I16OFF_41_9_0_;
	O2877[1093] = + _I16OFF_36_9_0_;
	O2877[1094] = + _I16OFF_40_12_0_;
	O2877[1095] = + _I16OFF_42_13_0_;
	O2877[1096] = + _I16OFF_45_16_0_;
	O2877[1097] = + _I16OFF_58_14_0_;
	O2877[1098] = + _I16OFF_51_13_0_;
	{long i; for (i = 1099; i < 1101; i++) O2877[i] = + _I16OFF_44_13_0_;}
	{long i; for (i = 1101; i < 1103; i++) O2877[i] = + _I16OFF_46_14_0_;}
	O2877[1103] = + _I16OFF_50_13_0_;
	O2877[1104] = + _I16OFF_51_14_0_;
	O2877[1105] = + _I16OFF_43_13_0_;
	O2877[1106] = + _I16OFF_44_15_0_;
	O2877[1107] = + _I16OFF_51_18_0_;
	O2877[1108] = + _I16OFF_46_14_0_;
	O2877[1109] = + _I16OFF_59_16_0_;
	O2877[1110] = + _I16OFF_16_5_0_;
	O2877[1111] = + _I16OFF_18_5_0_;
	O2877[1112] = + _I16OFF_23_5_0_;
	O2877[1113] = + _I16OFF_16_5_0_;
	{long i; for (i = 1114; i < 1116; i++) O2877[i] = + _I16OFF_20_5_0_;}
	{long i; for (i = 1116; i < 1118; i++) O2877[i] = + _I16OFF_25_6_0_;}
	{long i; for (i = 1118; i < 1120; i++) O2877[i] = + _I16OFF_21_7_0_;}
	{long i; for (i = 1120; i < 1124; i++) O2877[i] = + _I16OFF_17_6_0_;}
	O2877[1124] = + _I16OFF_18_6_0_;
	O2877[1125] = + _I16OFF_23_8_0_;
	{long i; for (i = 1126; i < 1128; i++) O2877[i] = + _I16OFF_23_9_0_;}
	O2877[1128] = + _I16OFF_24_9_0_;
	O2877[1129] = + _I16OFF_26_8_0_;
	O2877[1130] = + _I16OFF_19_5_0_;
	O2877[1131] = + _I16OFF_22_5_0_;
	{long i; for (i = 1132; i < 1134; i++) O2877[i] = + _I16OFF_21_10_0_;}
	{long i; for (i = 1134; i < 1136; i++) O2877[i] = + _I16OFF_29_14_0_;}
	O2877[1137] = + _I16OFF_36_10_0_;
	O2877[1140] = + _I16OFF_36_9_0_;
	O2877[1142] = + _I16OFF_48_19_0_;
	O2877[1145] = + _I16OFF_48_18_0_;
}


#ifdef __cplusplus
}
#endif
