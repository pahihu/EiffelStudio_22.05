#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2878[1146];
void O2878_init () {
	O2878[0] = + _I16OFF_3_1_1_;
	O2878[1018] = + _I16OFF_7_5_1_;
	O2878[1019] = + _I16OFF_8_6_1_;
	O2878[1046] = + _I16OFF_13_5_1_;
	O2878[1047] = + _I16OFF_16_7_1_;
	O2878[1048] = + _I16OFF_35_9_1_;
	O2878[1049] = + _I16OFF_42_12_1_;
	O2878[1050] = + _I16OFF_37_9_1_;
	O2878[1051] = + _I16OFF_46_12_1_;
	O2878[1052] = + _I16OFF_37_9_1_;
	O2878[1053] = + _I16OFF_38_9_1_;
	O2878[1054] = + _I16OFF_37_9_1_;
	O2878[1055] = + _I16OFF_47_12_1_;
	O2878[1056] = + _I16OFF_49_12_1_;
	O2878[1057] = + _I16OFF_47_12_1_;
	{long i; for (i = 1058; i < 1061; i++) O2878[i] = + _I16OFF_39_10_1_;}
	{long i; for (i = 1061; i < 1064; i++) O2878[i] = + _I16OFF_49_13_1_;}
	{long i; for (i = 1064; i < 1068; i++) O2878[i] = + _I16OFF_39_10_1_;}
	O2878[1068] = + _I16OFF_47_12_1_;
	O2878[1069] = + _I16OFF_47_14_1_;
	O2878[1070] = + _I16OFF_50_13_1_;
	O2878[1071] = + _I16OFF_53_13_1_;
	O2878[1072] = + _I16OFF_49_13_1_;
	O2878[1073] = + _I16OFF_51_13_1_;
	{long i; for (i = 1074; i < 1076; i++) O2878[i] = + _I16OFF_49_14_1_;}
	O2878[1076] = + _I16OFF_59_21_1_;
	O2878[1077] = + _I16OFF_59_23_1_;
	O2878[1078] = + _I16OFF_65_25_1_;
	O2878[1079] = + _I16OFF_68_26_1_;
	O2878[1080] = + _I16OFF_35_9_1_;
	O2878[1081] = + _I16OFF_43_9_1_;
	{long i; for (i = 1082; i < 1084; i++) O2878[i] = + _I16OFF_37_9_1_;}
	O2878[1084] = + _I16OFF_37_10_1_;
	O2878[1085] = + _I16OFF_35_9_1_;
	{long i; for (i = 1086; i < 1088; i++) O2878[i] = + _I16OFF_36_9_1_;}
	O2878[1088] = + _I16OFF_37_9_1_;
	O2878[1089] = + _I16OFF_37_10_1_;
	O2878[1090] = + _I16OFF_36_9_1_;
	O2878[1091] = + _I16OFF_37_9_1_;
	O2878[1092] = + _I16OFF_41_9_1_;
	O2878[1093] = + _I16OFF_36_9_1_;
	O2878[1094] = + _I16OFF_40_12_1_;
	O2878[1095] = + _I16OFF_42_13_1_;
	O2878[1096] = + _I16OFF_45_16_1_;
	O2878[1097] = + _I16OFF_58_14_1_;
	O2878[1098] = + _I16OFF_51_13_1_;
	{long i; for (i = 1099; i < 1101; i++) O2878[i] = + _I16OFF_44_13_1_;}
	{long i; for (i = 1101; i < 1103; i++) O2878[i] = + _I16OFF_46_14_1_;}
	O2878[1103] = + _I16OFF_50_13_1_;
	O2878[1104] = + _I16OFF_51_14_1_;
	O2878[1105] = + _I16OFF_43_13_1_;
	O2878[1106] = + _I16OFF_44_15_1_;
	O2878[1107] = + _I16OFF_51_18_1_;
	O2878[1108] = + _I16OFF_46_14_1_;
	O2878[1109] = + _I16OFF_59_16_1_;
	O2878[1110] = + _I16OFF_16_5_1_;
	O2878[1111] = + _I16OFF_18_5_1_;
	O2878[1112] = + _I16OFF_23_5_1_;
	O2878[1113] = + _I16OFF_16_5_1_;
	{long i; for (i = 1114; i < 1116; i++) O2878[i] = + _I16OFF_20_5_1_;}
	{long i; for (i = 1116; i < 1118; i++) O2878[i] = + _I16OFF_25_6_1_;}
	{long i; for (i = 1118; i < 1120; i++) O2878[i] = + _I16OFF_21_7_1_;}
	{long i; for (i = 1120; i < 1124; i++) O2878[i] = + _I16OFF_17_6_1_;}
	O2878[1124] = + _I16OFF_18_6_1_;
	O2878[1125] = + _I16OFF_23_8_1_;
	{long i; for (i = 1126; i < 1128; i++) O2878[i] = + _I16OFF_23_9_1_;}
	O2878[1128] = + _I16OFF_24_9_1_;
	O2878[1129] = + _I16OFF_26_8_1_;
	O2878[1130] = + _I16OFF_19_5_1_;
	O2878[1131] = + _I16OFF_22_5_1_;
	{long i; for (i = 1132; i < 1134; i++) O2878[i] = + _I16OFF_21_10_1_;}
	{long i; for (i = 1134; i < 1136; i++) O2878[i] = + _I16OFF_29_14_1_;}
	O2878[1137] = + _I16OFF_36_10_1_;
	O2878[1140] = + _I16OFF_36_9_1_;
	O2878[1142] = + _I16OFF_48_19_1_;
	O2878[1145] = + _I16OFF_48_18_1_;
}

long O2886[1146];
void O2886_init () {
	O2886[0] =  + _REFACS_2_;
	{long i; for (i = 1018; i < 1020; i++) O2886[i] =  + _REFACS_4_;}
	{long i; for (i = 1046; i < 1048; i++) O2886[i] =  + _REFACS_6_;}
	{long i; for (i = 1048; i < 1050; i++) O2886[i] =  + _REFACS_23_;}
	{long i; for (i = 1050; i < 1053; i++) O2886[i] =  + _REFACS_24_;}
	O2886[1053] =  + _REFACS_25_;
	{long i; for (i = 1054; i < 1056; i++) O2886[i] =  + _REFACS_24_;}
	O2886[1056] =  + _REFACS_25_;
	O2886[1057] =  + _REFACS_24_;
	{long i; for (i = 1058; i < 1068; i++) O2886[i] =  + _REFACS_25_;}
	{long i; for (i = 1068; i < 1070; i++) O2886[i] =  + _REFACS_29_;}
	{long i; for (i = 1070; i < 1072; i++) O2886[i] =  + _REFACS_32_;}
	{long i; for (i = 1072; i < 1076; i++) O2886[i] =  + _REFACS_25_;}
	{long i; for (i = 1076; i < 1078; i++) O2886[i] =  + _REFACS_29_;}
	{long i; for (i = 1078; i < 1080; i++) O2886[i] =  + _REFACS_32_;}
	O2886[1080] =  + _REFACS_23_;
	O2886[1081] =  + _REFACS_27_;
	O2886[1082] =  + _REFACS_25_;
	{long i; for (i = 1083; i < 1085; i++) O2886[i] =  + _REFACS_24_;}
	O2886[1085] =  + _REFACS_23_;
	{long i; for (i = 1086; i < 1088; i++) O2886[i] =  + _REFACS_24_;}
	{long i; for (i = 1088; i < 1090; i++) O2886[i] =  + _REFACS_25_;}
	O2886[1090] =  + _REFACS_24_;
	O2886[1091] =  + _REFACS_25_;
	O2886[1092] =  + _REFACS_29_;
	O2886[1093] =  + _REFACS_24_;
	O2886[1094] =  + _REFACS_27_;
	O2886[1095] =  + _REFACS_23_;
	O2886[1096] =  + _REFACS_24_;
	O2886[1097] =  + _REFACS_27_;
	O2886[1098] =  + _REFACS_25_;
	O2886[1099] =  + _REFACS_24_;
	O2886[1100] =  + _REFACS_23_;
	{long i; for (i = 1101; i < 1103; i++) O2886[i] =  + _REFACS_24_;}
	{long i; for (i = 1103; i < 1105; i++) O2886[i] =  + _REFACS_25_;}
	{long i; for (i = 1105; i < 1107; i++) O2886[i] =  + _REFACS_24_;}
	O2886[1107] =  + _REFACS_27_;
	O2886[1108] =  + _REFACS_25_;
	O2886[1109] =  + _REFACS_29_;
	O2886[1110] =  + _REFACS_9_;
	{long i; for (i = 1111; i < 1113; i++) O2886[i] =  + _REFACS_11_;}
	O2886[1113] =  + _REFACS_9_;
	{long i; for (i = 1114; i < 1118; i++) O2886[i] =  + _REFACS_13_;}
	{long i; for (i = 1118; i < 1120; i++) O2886[i] =  + _REFACS_9_;}
	{long i; for (i = 1120; i < 1124; i++) O2886[i] =  + _REFACS_10_;}
	O2886[1124] =  + _REFACS_11_;
	{long i; for (i = 1125; i < 1129; i++) O2886[i] =  + _REFACS_10_;}
	{long i; for (i = 1129; i < 1132; i++) O2886[i] =  + _REFACS_11_;}
	{long i; for (i = 1132; i < 1136; i++) O2886[i] =  + _REFACS_13_;}
	O2886[1137] =  + _REFACS_23_;
	O2886[1140] =  + _REFACS_23_;
	O2886[1142] =  + _REFACS_23_;
	O2886[1145] =  + _REFACS_23_;
}

long O2888[1146];
void O2888_init () {
	O2888[0] = + _I16OFF_3_1_2_;
	O2888[1018] = + _I16OFF_7_5_2_;
	O2888[1019] = + _I16OFF_8_6_2_;
	O2888[1046] = + _I16OFF_13_5_2_;
	O2888[1047] = + _I16OFF_16_7_2_;
	O2888[1048] = + _I16OFF_35_9_2_;
	O2888[1049] = + _I16OFF_42_12_2_;
	O2888[1050] = + _I16OFF_37_9_2_;
	O2888[1051] = + _I16OFF_46_12_2_;
	O2888[1052] = + _I16OFF_37_9_2_;
	O2888[1053] = + _I16OFF_38_9_2_;
	O2888[1054] = + _I16OFF_37_9_2_;
	O2888[1055] = + _I16OFF_47_12_2_;
	O2888[1056] = + _I16OFF_49_12_2_;
	O2888[1057] = + _I16OFF_47_12_2_;
	{long i; for (i = 1058; i < 1061; i++) O2888[i] = + _I16OFF_39_10_2_;}
	{long i; for (i = 1061; i < 1064; i++) O2888[i] = + _I16OFF_49_13_2_;}
	{long i; for (i = 1064; i < 1068; i++) O2888[i] = + _I16OFF_39_10_2_;}
	O2888[1068] = + _I16OFF_47_12_2_;
	O2888[1069] = + _I16OFF_47_14_2_;
	O2888[1070] = + _I16OFF_50_13_2_;
	O2888[1071] = + _I16OFF_53_13_2_;
	O2888[1072] = + _I16OFF_49_13_2_;
	O2888[1073] = + _I16OFF_51_13_2_;
	{long i; for (i = 1074; i < 1076; i++) O2888[i] = + _I16OFF_49_14_2_;}
	O2888[1076] = + _I16OFF_59_21_2_;
	O2888[1077] = + _I16OFF_59_23_2_;
	O2888[1078] = + _I16OFF_65_25_2_;
	O2888[1079] = + _I16OFF_68_26_2_;
	O2888[1080] = + _I16OFF_35_9_2_;
	O2888[1081] = + _I16OFF_43_9_2_;
	{long i; for (i = 1082; i < 1084; i++) O2888[i] = + _I16OFF_37_9_2_;}
	O2888[1084] = + _I16OFF_37_10_2_;
	O2888[1085] = + _I16OFF_35_9_2_;
	{long i; for (i = 1086; i < 1088; i++) O2888[i] = + _I16OFF_36_9_2_;}
	O2888[1088] = + _I16OFF_37_9_2_;
	O2888[1089] = + _I16OFF_37_10_2_;
	O2888[1090] = + _I16OFF_36_9_2_;
	O2888[1091] = + _I16OFF_37_9_2_;
	O2888[1092] = + _I16OFF_41_9_2_;
	O2888[1093] = + _I16OFF_36_9_2_;
	O2888[1094] = + _I16OFF_40_12_2_;
	O2888[1095] = + _I16OFF_42_13_2_;
	O2888[1096] = + _I16OFF_45_16_2_;
	O2888[1097] = + _I16OFF_58_14_2_;
	O2888[1098] = + _I16OFF_51_13_2_;
	{long i; for (i = 1099; i < 1101; i++) O2888[i] = + _I16OFF_44_13_2_;}
	{long i; for (i = 1101; i < 1103; i++) O2888[i] = + _I16OFF_46_14_2_;}
	O2888[1103] = + _I16OFF_50_13_2_;
	O2888[1104] = + _I16OFF_51_14_2_;
	O2888[1105] = + _I16OFF_43_13_2_;
	O2888[1106] = + _I16OFF_44_15_2_;
	O2888[1107] = + _I16OFF_51_18_2_;
	O2888[1108] = + _I16OFF_46_14_2_;
	O2888[1109] = + _I16OFF_59_16_2_;
	O2888[1110] = + _I16OFF_16_5_2_;
	O2888[1111] = + _I16OFF_18_5_2_;
	O2888[1112] = + _I16OFF_23_5_2_;
	O2888[1113] = + _I16OFF_16_5_2_;
	{long i; for (i = 1114; i < 1116; i++) O2888[i] = + _I16OFF_20_5_2_;}
	{long i; for (i = 1116; i < 1118; i++) O2888[i] = + _I16OFF_25_6_2_;}
	{long i; for (i = 1118; i < 1120; i++) O2888[i] = + _I16OFF_21_7_2_;}
	{long i; for (i = 1120; i < 1124; i++) O2888[i] = + _I16OFF_17_6_2_;}
	O2888[1124] = + _I16OFF_18_6_2_;
	O2888[1125] = + _I16OFF_23_8_2_;
	{long i; for (i = 1126; i < 1128; i++) O2888[i] = + _I16OFF_23_9_2_;}
	O2888[1128] = + _I16OFF_24_9_2_;
	O2888[1129] = + _I16OFF_26_8_2_;
	O2888[1130] = + _I16OFF_19_5_2_;
	O2888[1131] = + _I16OFF_22_5_2_;
	{long i; for (i = 1132; i < 1134; i++) O2888[i] = + _I16OFF_21_10_2_;}
	{long i; for (i = 1134; i < 1136; i++) O2888[i] = + _I16OFF_29_14_2_;}
	O2888[1137] = + _I16OFF_36_10_2_;
	O2888[1140] = + _I16OFF_36_9_2_;
	O2888[1142] = + _I16OFF_48_19_2_;
	O2888[1145] = + _I16OFF_48_18_2_;
}

long O2889[1146];
void O2889_init () {
	O2889[0] = + _I16OFF_3_1_3_;
	O2889[1018] = + _I16OFF_7_5_3_;
	O2889[1019] = + _I16OFF_8_6_3_;
	O2889[1046] = + _I16OFF_13_5_3_;
	O2889[1047] = + _I16OFF_16_7_3_;
	O2889[1048] = + _I16OFF_35_9_3_;
	O2889[1049] = + _I16OFF_42_12_3_;
	O2889[1050] = + _I16OFF_37_9_3_;
	O2889[1051] = + _I16OFF_46_12_3_;
	O2889[1052] = + _I16OFF_37_9_3_;
	O2889[1053] = + _I16OFF_38_9_3_;
	O2889[1054] = + _I16OFF_37_9_3_;
	O2889[1055] = + _I16OFF_47_12_3_;
	O2889[1056] = + _I16OFF_49_12_3_;
	O2889[1057] = + _I16OFF_47_12_3_;
	{long i; for (i = 1058; i < 1061; i++) O2889[i] = + _I16OFF_39_10_3_;}
	{long i; for (i = 1061; i < 1064; i++) O2889[i] = + _I16OFF_49_13_3_;}
	{long i; for (i = 1064; i < 1068; i++) O2889[i] = + _I16OFF_39_10_3_;}
	O2889[1068] = + _I16OFF_47_12_3_;
	O2889[1069] = + _I16OFF_47_14_3_;
	O2889[1070] = + _I16OFF_50_13_3_;
	O2889[1071] = + _I16OFF_53_13_3_;
	O2889[1072] = + _I16OFF_49_13_3_;
	O2889[1073] = + _I16OFF_51_13_3_;
	{long i; for (i = 1074; i < 1076; i++) O2889[i] = + _I16OFF_49_14_3_;}
	O2889[1076] = + _I16OFF_59_21_3_;
	O2889[1077] = + _I16OFF_59_23_3_;
	O2889[1078] = + _I16OFF_65_25_3_;
	O2889[1079] = + _I16OFF_68_26_3_;
	O2889[1080] = + _I16OFF_35_9_3_;
	O2889[1081] = + _I16OFF_43_9_3_;
	{long i; for (i = 1082; i < 1084; i++) O2889[i] = + _I16OFF_37_9_3_;}
	O2889[1084] = + _I16OFF_37_10_3_;
	O2889[1085] = + _I16OFF_35_9_3_;
	{long i; for (i = 1086; i < 1088; i++) O2889[i] = + _I16OFF_36_9_3_;}
	O2889[1088] = + _I16OFF_37_9_3_;
	O2889[1089] = + _I16OFF_37_10_3_;
	O2889[1090] = + _I16OFF_36_9_3_;
	O2889[1091] = + _I16OFF_37_9_3_;
	O2889[1092] = + _I16OFF_41_9_3_;
	O2889[1093] = + _I16OFF_36_9_3_;
	O2889[1094] = + _I16OFF_40_12_3_;
	O2889[1095] = + _I16OFF_42_13_3_;
	O2889[1096] = + _I16OFF_45_16_3_;
	O2889[1097] = + _I16OFF_58_14_3_;
	O2889[1098] = + _I16OFF_51_13_3_;
	{long i; for (i = 1099; i < 1101; i++) O2889[i] = + _I16OFF_44_13_3_;}
	{long i; for (i = 1101; i < 1103; i++) O2889[i] = + _I16OFF_46_14_3_;}
	O2889[1103] = + _I16OFF_50_13_3_;
	O2889[1104] = + _I16OFF_51_14_3_;
	O2889[1105] = + _I16OFF_43_13_3_;
	O2889[1106] = + _I16OFF_44_15_3_;
	O2889[1107] = + _I16OFF_51_18_3_;
	O2889[1108] = + _I16OFF_46_14_3_;
	O2889[1109] = + _I16OFF_59_16_3_;
	O2889[1110] = + _I16OFF_16_5_3_;
	O2889[1111] = + _I16OFF_18_5_3_;
	O2889[1112] = + _I16OFF_23_5_3_;
	O2889[1113] = + _I16OFF_16_5_3_;
	{long i; for (i = 1114; i < 1116; i++) O2889[i] = + _I16OFF_20_5_3_;}
	{long i; for (i = 1116; i < 1118; i++) O2889[i] = + _I16OFF_25_6_3_;}
	{long i; for (i = 1118; i < 1120; i++) O2889[i] = + _I16OFF_21_7_3_;}
	{long i; for (i = 1120; i < 1124; i++) O2889[i] = + _I16OFF_17_6_3_;}
	O2889[1124] = + _I16OFF_18_6_3_;
	O2889[1125] = + _I16OFF_23_8_3_;
	{long i; for (i = 1126; i < 1128; i++) O2889[i] = + _I16OFF_23_9_3_;}
	O2889[1128] = + _I16OFF_24_9_3_;
	O2889[1129] = + _I16OFF_26_8_3_;
	O2889[1130] = + _I16OFF_19_5_3_;
	O2889[1131] = + _I16OFF_22_5_3_;
	{long i; for (i = 1132; i < 1134; i++) O2889[i] = + _I16OFF_21_10_3_;}
	{long i; for (i = 1134; i < 1136; i++) O2889[i] = + _I16OFF_29_14_3_;}
	O2889[1137] = + _I16OFF_36_10_3_;
	O2889[1140] = + _I16OFF_36_9_3_;
	O2889[1142] = + _I16OFF_48_19_3_;
	O2889[1145] = + _I16OFF_48_18_3_;
}

long O3132[4];
void O3132_init () {
	O3132[0] = + _CHROFF_2_0_;
	O3132[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3132[i] = + _CHROFF_2_0_;}
}

long O3133[4];
void O3133_init () {
	O3133[0] = + _CHROFF_2_1_;
	O3133[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3133[i] = + _CHROFF_2_1_;}
}

long O3228[146];
void O3228_init () {
	O3228[0] = 0;
	O3228[1] = + _LNGOFF_0_0_0_0_;
	O3228[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O3228[3] = + _CHROFF_0_0_;
	O3228[4] = + _LNGOFF_0_0_0_0_;
	O3228[5] = 0;
	O3228[6] = + _LNGOFF_1_0_0_0_;
	O3228[7] = + _CHROFF_1_0_;
	{long i; for (i = 144; i < 146; i++) O3228[i] = 0;}
}

long O3232[3];
void O3232_init () {
	O3232[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3232[i] = 0;}
}

static EIF_TYPE_INDEX Y4046_pgtype0[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype1[] = {786,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype2[] = {787,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype3[] = {788,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype4[] = {789,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype5[] = {790,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype6[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype7[] = {792,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype8[] = {793,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype9[] = {794,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype10[] = {795,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype11[] = {796,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype12[] = {790,925,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype13[] = {790,925,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype14[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype15[] = {786,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype16[] = {787,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype17[] = {788,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype18[] = {789,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype19[] = {790,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype20[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype21[] = {792,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype22[] = {793,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype23[] = {794,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype24[] = {795,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype25[] = {796,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype26[] = {790,925,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype27[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype28[] = {786,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype29[] = {787,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype30[] = {788,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype31[] = {789,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype32[] = {790,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype33[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype34[] = {792,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype35[] = {793,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype36[] = {794,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype37[] = {795,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype38[] = {796,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype39[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype40[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype41[] = {788,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype42[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype43[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype44[] = {785,975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype45[] = {785,975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype46[] = {785,975,0xFFF9,1,901,0,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype47[] = {785,975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype48[] = {785,975,0xFFF9,1,901,1089,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype49[] = {785,975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype50[] = {785,975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype51[] = {785,975,0xFFF9,1,901,1095,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype52[] = {785,975,0xFFF9,1,901,1057,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype53[] = {785,975,0xFFF9,1,901,865,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype54[] = {785,975,0xFFF9,1,901,1036,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype55[] = {785,975,0xFFF9,5,901,919,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype56[] = {785,975,0xFFF9,1,901,1287,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype57[] = {785,975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype58[] = {785,975,0xFFF9,1,901,987,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype59[] = {785,975,0xFFF9,7,901,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype60[] = {785,975,0xFFF9,2,901,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype61[] = {785,975,0xFFF9,4,901,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype62[] = {785,975,0xFFF9,3,901,907,907,865,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype63[] = {785,975,0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype64[] = {785,975,0xFFF9,0,901,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype65[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype66[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype67[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype68[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype69[] = {785,1025,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype70[] = {793,934,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype71[] = {787,937,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype72[] = {787,937,0xFFFF};
static EIF_TYPE_INDEX Y4046_pgtype73[] = {785,987,0xFFFF};
EIF_TYPE_INDEX *Y4046_gen_type [845];
EIF_TYPE_INDEX Y4046 [845];
void Y4046_init (void)
{
	egc_routines_types [4046] = Y4046;
	egc_routines_gen_types [4046] = Y4046_gen_type;
	egc_routines_offset [4046] = 245;
	Y4046_gen_type [0] = Y4046_pgtype0;
	Y4046_gen_type [1] = Y4046_pgtype1;
	Y4046_gen_type [2] = Y4046_pgtype2;
	Y4046_gen_type [3] = Y4046_pgtype3;
	Y4046_gen_type [4] = Y4046_pgtype4;
	Y4046_gen_type [5] = Y4046_pgtype5;
	Y4046_gen_type [6] = Y4046_pgtype6;
	Y4046_gen_type [7] = Y4046_pgtype7;
	Y4046_gen_type [8] = Y4046_pgtype8;
	Y4046_gen_type [9] = Y4046_pgtype9;
	Y4046_gen_type [10] = Y4046_pgtype10;
	Y4046_gen_type [11] = Y4046_pgtype11;
	Y4046_gen_type [20] = Y4046_pgtype12;
	Y4046_gen_type [21] = Y4046_pgtype13;
	Y4046_gen_type [294] = Y4046_pgtype14;
	Y4046_gen_type [295] = Y4046_pgtype15;
	Y4046_gen_type [296] = Y4046_pgtype16;
	Y4046_gen_type [297] = Y4046_pgtype17;
	Y4046_gen_type [298] = Y4046_pgtype18;
	Y4046_gen_type [299] = Y4046_pgtype19;
	Y4046_gen_type [300] = Y4046_pgtype20;
	Y4046_gen_type [301] = Y4046_pgtype21;
	Y4046_gen_type [302] = Y4046_pgtype22;
	Y4046_gen_type [303] = Y4046_pgtype23;
	Y4046_gen_type [304] = Y4046_pgtype24;
	Y4046_gen_type [305] = Y4046_pgtype25;
	Y4046_gen_type [306] = Y4046_pgtype26;
	Y4046_gen_type [373] = Y4046_pgtype27;
	Y4046_gen_type [374] = Y4046_pgtype28;
	Y4046_gen_type [375] = Y4046_pgtype29;
	Y4046_gen_type [376] = Y4046_pgtype30;
	Y4046_gen_type [377] = Y4046_pgtype31;
	Y4046_gen_type [378] = Y4046_pgtype32;
	Y4046_gen_type [379] = Y4046_pgtype33;
	Y4046_gen_type [380] = Y4046_pgtype34;
	Y4046_gen_type [381] = Y4046_pgtype35;
	Y4046_gen_type [382] = Y4046_pgtype36;
	Y4046_gen_type [383] = Y4046_pgtype37;
	Y4046_gen_type [384] = Y4046_pgtype38;
	Y4046_gen_type [385] = Y4046_pgtype39;
	Y4046_gen_type [386] = Y4046_pgtype40;
	Y4046_gen_type [387] = Y4046_pgtype41;
	Y4046_gen_type [388] = Y4046_pgtype42;
	Y4046_gen_type [389] = Y4046_pgtype43;
	Y4046_gen_type [390] = Y4046_pgtype44;
	Y4046_gen_type [391] = Y4046_pgtype45;
	Y4046_gen_type [392] = Y4046_pgtype46;
	Y4046_gen_type [393] = Y4046_pgtype47;
	Y4046_gen_type [394] = Y4046_pgtype48;
	Y4046_gen_type [395] = Y4046_pgtype49;
	Y4046_gen_type [396] = Y4046_pgtype50;
	Y4046_gen_type [397] = Y4046_pgtype51;
	Y4046_gen_type [398] = Y4046_pgtype52;
	Y4046_gen_type [399] = Y4046_pgtype53;
	Y4046_gen_type [400] = Y4046_pgtype54;
	Y4046_gen_type [401] = Y4046_pgtype55;
	Y4046_gen_type [402] = Y4046_pgtype56;
	Y4046_gen_type [403] = Y4046_pgtype57;
	Y4046_gen_type [404] = Y4046_pgtype58;
	Y4046_gen_type [405] = Y4046_pgtype59;
	Y4046_gen_type [406] = Y4046_pgtype60;
	Y4046_gen_type [407] = Y4046_pgtype61;
	Y4046_gen_type [408] = Y4046_pgtype62;
	Y4046_gen_type [409] = Y4046_pgtype63;
	Y4046_gen_type [410] = Y4046_pgtype64;
	Y4046_gen_type [411] = Y4046_pgtype65;
	Y4046_gen_type [412] = Y4046_pgtype66;
	Y4046_gen_type [413] = Y4046_pgtype67;
	Y4046_gen_type [414] = Y4046_pgtype68;
	Y4046_gen_type [415] = Y4046_pgtype69;
	Y4046_gen_type [742] = Y4046_pgtype70;
	Y4046_gen_type [743] = Y4046_pgtype71;
	Y4046_gen_type [744] = Y4046_pgtype72;
	Y4046_gen_type [844] = Y4046_pgtype73;
	Y4046[0] = 785;
	Y4046[1] = 786;
	Y4046[2] = 787;
	Y4046[3] = 788;
	Y4046[4] = 789;
	Y4046[5] = 790;
	Y4046[6] = 791;
	Y4046[7] = 792;
	Y4046[8] = 793;
	Y4046[9] = 794;
	Y4046[10] = 795;
	Y4046[11] = 796;
	{long i; for (i = 20; i < 22; i++) Y4046[i] = 790;};
	Y4046[294] = 785;
	Y4046[295] = 786;
	Y4046[296] = 787;
	Y4046[297] = 788;
	Y4046[298] = 789;
	Y4046[299] = 790;
	Y4046[300] = 791;
	Y4046[301] = 792;
	Y4046[302] = 793;
	Y4046[303] = 794;
	Y4046[304] = 795;
	Y4046[305] = 796;
	Y4046[306] = 790;
	Y4046[373] = 785;
	Y4046[374] = 786;
	Y4046[375] = 787;
	Y4046[376] = 788;
	Y4046[377] = 789;
	Y4046[378] = 790;
	Y4046[379] = 791;
	Y4046[380] = 792;
	Y4046[381] = 793;
	Y4046[382] = 794;
	Y4046[383] = 795;
	Y4046[384] = 796;
	Y4046[385] = 785;
	Y4046[386] = 791;
	Y4046[387] = 788;
	Y4046[388] = 785;
	Y4046[389] = 791;
	{long i; for (i = 390; i < 412; i++) Y4046[i] = 785;};
	Y4046[412] = 791;
	Y4046[413] = 785;
	Y4046[414] = 791;
	Y4046[415] = 785;
	Y4046[742] = 793;
	{long i; for (i = 743; i < 745; i++) Y4046[i] = 787;};
	Y4046[844] = 785;
}

long O4197[870];
void O4197_init () {
	O4197[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1; i < 4; i++) O4197[i] = + _LNGOFF_3_2_0_1_;}
	O4197[4] = + _LNGOFF_0_0_0_0_;
	O4197[5] = + _LNGOFF_3_3_0_1_;
	{long i; for (i = 6; i < 8; i++) O4197[i] = + _LNGOFF_0_0_0_0_;}
	O4197[8] = + _LNGOFF_13_16_0_4_;
	O4197[9] = + _LNGOFF_21_18_0_5_;
	O4197[593] = + _LNGOFF_15_11_0_0_;
	O4197[595] = + _LNGOFF_1_0_0_0_;
	O4197[863] = + _LNGOFF_1_1_0_0_;
	O4197[869] = + _LNGOFF_49_16_0_2_;
}

long O4298[990];
void O4298_init () {
	{long i; for (i = 0; i < 12; i++) O4298[i] = + _CHROFF_0_0_;}
	O4298[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O4298[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O4298[i] = + _CHROFF_0_0_;}
	O4298[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O4298[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O4298[i] = + _CHROFF_0_0_;}
	{long i; for (i = 241; i < 254; i++) O4298[i] = + _CHROFF_1_0_;}
	O4298[254] = + _CHROFF_2_0_;
	{long i; for (i = 255; i < 303; i++) O4298[i] = + _CHROFF_0_0_;}
	{long i; for (i = 303; i < 310; i++) O4298[i] = + _CHROFF_2_0_;}
	O4298[311] = + _CHROFF_1_0_;
	O4298[312] = + _CHROFF_7_0_;
	O4298[313] = + _CHROFF_6_0_;
	O4298[314] = + _CHROFF_5_0_;
	O4298[315] = + _CHROFF_4_0_;
	O4298[316] = + _CHROFF_5_0_;
	O4298[317] = + _CHROFF_4_0_;
	O4298[318] = + _CHROFF_7_0_;
	O4298[319] = + _CHROFF_5_0_;
	O4298[320] = + _CHROFF_9_0_;
	{long i; for (i = 321; i < 338; i++) O4298[i] = + _CHROFF_1_0_;}
	{long i; for (i = 338; i < 340; i++) O4298[i] = + _CHROFF_9_0_;}
	O4298[340] = + _CHROFF_10_0_;
	{long i; for (i = 341; i < 359; i++) O4298[i] = + _CHROFF_9_0_;}
	{long i; for (i = 359; i < 361; i++) O4298[i] = + _CHROFF_3_0_;}
	{long i; for (i = 361; i < 364; i++) O4298[i] = + _CHROFF_5_0_;}
	O4298[379] = + _CHROFF_2_0_;
	O4298[381] = + _CHROFF_0_0_;
	O4298[559] = + _CHROFF_3_2_;
	O4298[560] = + _CHROFF_4_2_;
	O4298[561] = + _CHROFF_5_2_;
	{long i; for (i = 690; i < 693; i++) O4298[i] = + _CHROFF_1_0_;}
	O4298[758] = + _CHROFF_3_0_;
	{long i; for (i = 761; i < 775; i++) O4298[i] = + _CHROFF_6_0_;}
	O4298[775] = + _CHROFF_7_0_;
	{long i; for (i = 776; i < 778; i++) O4298[i] = + _CHROFF_14_0_;}
	O4298[778] = + _CHROFF_6_0_;
	O4298[779] = + _CHROFF_12_0_;
	O4298[792] = + _CHROFF_7_0_;
	O4298[802] = + _CHROFF_3_0_;
	{long i; for (i = 803; i < 808; i++) O4298[i] = + _CHROFF_5_0_;}
	O4298[808] = + _CHROFF_3_0_;
	O4298[809] = + _CHROFF_5_0_;
	{long i; for (i = 810; i < 812; i++) O4298[i] = + _CHROFF_6_0_;}
	O4298[812] = + _CHROFF_3_0_;
	O4298[813] = + _CHROFF_6_0_;
	O4298[814] = + _CHROFF_3_0_;
	O4298[989] = + _CHROFF_5_2_;
}

static EIF_TYPE_INDEX Y4366_pgtype0[] = {310,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4366_pgtype1[] = {311,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4366_gen_type [2];
EIF_TYPE_INDEX Y4366 [2];
void Y4366_init (void)
{
	egc_routines_types [4366] = Y4366;
	egc_routines_gen_types [4366] = Y4366_gen_type;
	egc_routines_offset [4366] = 310;
	Y4366_gen_type [0] = Y4366_pgtype0;
	Y4366_gen_type [1] = Y4366_pgtype1;
	Y4366[0] = 310;
	Y4366[1] = 311;
}

EIF_TYPE_INDEX *Y4613_gen_type [1];
EIF_TYPE_INDEX Y4613 [1];
void Y4613_init (void)
{
	egc_routines_types [4613] = Y4613;
	egc_routines_gen_types [4613] = Y4613_gen_type;
	egc_routines_offset [4613] = 608;
	Y4613[0] = 907;
}

long O4618[9];
void O4618_init () {
	{long i; for (i = 0; i < 2; i++) O4618[i] = 0;}
	O4618[2] = + _LNGOFF_5_3_0_0_;
	O4618[3] = + _LNGOFF_4_3_0_0_;
	O4618[4] = + _PTROFF_5_3_0_7_0_0_;
	O4618[5] = + _LNGOFF_4_3_0_1_;
	O4618[6] = 0;
	O4618[7] = + _LNGOFF_5_4_0_0_;
	O4618[8] = 0;
}

long O4627[9];
void O4627_init () {
	O4627[0] = + _LNGOFF_7_3_0_0_;
	O4627[1] = + _LNGOFF_6_3_0_0_;
	O4627[2] = + _LNGOFF_5_3_0_1_;
	O4627[3] = + _LNGOFF_4_3_0_1_;
	O4627[4] = + _LNGOFF_5_3_0_0_;
	O4627[5] = + _LNGOFF_4_3_0_2_;
	O4627[6] = + _LNGOFF_7_4_0_0_;
	O4627[7] = + _LNGOFF_5_4_0_1_;
	O4627[8] = + _LNGOFF_9_3_0_0_;
}

long O4654[9];
void O4654_init () {
	{long i; for (i = 0; i < 2; i++) O4654[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 6; i++) O4654[i] = 0;}
	O4654[6] =  + _REFACS_1_;
	O4654[7] = 0;
	O4654[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y4654_pgtype0[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype1[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype2[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype3[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype4[] = {794,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype5[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype6[] = {785,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype7[] = {791,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4654_pgtype8[] = {785,0,0xFFFF};
EIF_TYPE_INDEX *Y4654_gen_type [9];
EIF_TYPE_INDEX Y4654 [9];
void Y4654_init (void)
{
	egc_routines_types [4654] = Y4654;
	egc_routines_gen_types [4654] = Y4654_gen_type;
	egc_routines_offset [4654] = 609;
	Y4654_gen_type [0] = Y4654_pgtype0;
	Y4654_gen_type [1] = Y4654_pgtype1;
	Y4654_gen_type [2] = Y4654_pgtype2;
	Y4654_gen_type [3] = Y4654_pgtype3;
	Y4654_gen_type [4] = Y4654_pgtype4;
	Y4654_gen_type [5] = Y4654_pgtype5;
	Y4654_gen_type [6] = Y4654_pgtype6;
	Y4654_gen_type [7] = Y4654_pgtype7;
	Y4654_gen_type [8] = Y4654_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y4654[i] = 785;};
	{long i; for (i = 2; i < 4; i++) Y4654[i] = 791;};
	Y4654[4] = 794;
	Y4654[5] = 791;
	Y4654[6] = 785;
	Y4654[7] = 791;
	Y4654[8] = 785;
}

long O4655[9];
void O4655_init () {
	{long i; for (i = 0; i < 2; i++) O4655[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 6; i++) O4655[i] =  + _REFACS_1_;}
	O4655[6] =  + _REFACS_2_;
	O4655[7] =  + _REFACS_1_;
	O4655[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y4655_pgtype0[] = {785,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype1[] = {791,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype2[] = {785,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype3[] = {791,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype4[] = {785,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype5[] = {792,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype6[] = {785,980,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype7[] = {785,980,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype8[] = {785,988,0xFFFF};
EIF_TYPE_INDEX *Y4655_gen_type [9];
EIF_TYPE_INDEX Y4655 [9];
void Y4655_init (void)
{
	egc_routines_types [4655] = Y4655;
	egc_routines_gen_types [4655] = Y4655_gen_type;
	egc_routines_offset [4655] = 609;
	Y4655_gen_type [0] = Y4655_pgtype0;
	Y4655_gen_type [1] = Y4655_pgtype1;
	Y4655_gen_type [2] = Y4655_pgtype2;
	Y4655_gen_type [3] = Y4655_pgtype3;
	Y4655_gen_type [4] = Y4655_pgtype4;
	Y4655_gen_type [5] = Y4655_pgtype5;
	Y4655_gen_type [6] = Y4655_pgtype6;
	Y4655_gen_type [7] = Y4655_pgtype7;
	Y4655_gen_type [8] = Y4655_pgtype8;
	Y4655[0] = 785;
	Y4655[1] = 791;
	Y4655[2] = 785;
	Y4655[3] = 791;
	Y4655[4] = 785;
	Y4655[5] = 792;
	{long i; for (i = 6; i < 9; i++) Y4655[i] = 785;};
}

long O4656[9];
void O4656_init () {
	{long i; for (i = 0; i < 2; i++) O4656[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 6; i++) O4656[i] =  + _REFACS_2_;}
	O4656[6] =  + _REFACS_3_;
	O4656[7] =  + _REFACS_2_;
	O4656[8] =  + _REFACS_3_;
}

long O4657[9];
void O4657_init () {
	{long i; for (i = 0; i < 2; i++) O4657[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 6; i++) O4657[i] =  + _REFACS_3_;}
	O4657[6] =  + _REFACS_4_;
	O4657[7] =  + _REFACS_3_;
	O4657[8] =  + _REFACS_4_;
}

long O4658[9];
void O4658_init () {
	O4658[0] = + _LNGOFF_7_3_0_1_;
	O4658[1] = + _LNGOFF_6_3_0_1_;
	O4658[2] = + _LNGOFF_5_3_0_2_;
	O4658[3] = + _LNGOFF_4_3_0_2_;
	O4658[4] = + _LNGOFF_5_3_0_1_;
	O4658[5] = + _LNGOFF_4_3_0_3_;
	O4658[6] = + _LNGOFF_7_4_0_1_;
	O4658[7] = + _LNGOFF_5_4_0_2_;
	O4658[8] = + _LNGOFF_9_3_0_1_;
}

long O4659[9];
void O4659_init () {
	O4659[0] = + _CHROFF_7_2_;
	O4659[1] = + _CHROFF_6_2_;
	O4659[2] = + _CHROFF_5_2_;
	O4659[3] = + _CHROFF_4_2_;
	O4659[4] = + _CHROFF_5_2_;
	O4659[5] = + _CHROFF_4_2_;
	O4659[6] = + _CHROFF_7_2_;
	O4659[7] = + _CHROFF_5_2_;
	O4659[8] = + _CHROFF_9_2_;
}

long O4660[9];
void O4660_init () {
	O4660[0] = + _LNGOFF_7_3_0_2_;
	O4660[1] = + _LNGOFF_6_3_0_2_;
	O4660[2] = + _LNGOFF_5_3_0_3_;
	O4660[3] = + _LNGOFF_4_3_0_3_;
	O4660[4] = + _LNGOFF_5_3_0_2_;
	O4660[5] = + _LNGOFF_4_3_0_4_;
	O4660[6] = + _LNGOFF_7_4_0_2_;
	O4660[7] = + _LNGOFF_5_4_0_3_;
	O4660[8] = + _LNGOFF_9_3_0_2_;
}

long O4663[9];
void O4663_init () {
	O4663[0] = + _LNGOFF_7_3_0_3_;
	O4663[1] = + _LNGOFF_6_3_0_3_;
	O4663[2] = + _LNGOFF_5_3_0_4_;
	O4663[3] = + _LNGOFF_4_3_0_4_;
	O4663[4] = + _LNGOFF_5_3_0_3_;
	O4663[5] = + _LNGOFF_4_3_0_5_;
	O4663[6] = + _LNGOFF_7_4_0_3_;
	O4663[7] = + _LNGOFF_5_4_0_4_;
	O4663[8] = + _LNGOFF_9_3_0_3_;
}

long O4664[9];
void O4664_init () {
	O4664[0] = + _LNGOFF_7_3_0_4_;
	O4664[1] = + _LNGOFF_6_3_0_4_;
	O4664[2] = + _LNGOFF_5_3_0_5_;
	O4664[3] = + _LNGOFF_4_3_0_5_;
	O4664[4] = + _LNGOFF_5_3_0_4_;
	O4664[5] = + _LNGOFF_4_3_0_6_;
	O4664[6] = + _LNGOFF_7_4_0_4_;
	O4664[7] = + _LNGOFF_5_4_0_5_;
	O4664[8] = + _LNGOFF_9_3_0_4_;
}

long O4668[9];
void O4668_init () {
	O4668[0] = + _LNGOFF_7_3_0_5_;
	O4668[1] = + _LNGOFF_6_3_0_5_;
	O4668[2] = + _LNGOFF_5_3_0_6_;
	O4668[3] = + _LNGOFF_4_3_0_6_;
	O4668[4] = + _LNGOFF_5_3_0_5_;
	O4668[5] = + _LNGOFF_4_3_0_7_;
	O4668[6] = + _LNGOFF_7_4_0_5_;
	O4668[7] = + _LNGOFF_5_4_0_6_;
	O4668[8] = + _LNGOFF_9_3_0_5_;
}

long O4669[9];
void O4669_init () {
	{long i; for (i = 0; i < 2; i++) O4669[i] =  + _REFACS_5_;}
	O4669[2] = + _LNGOFF_5_3_0_7_;
	O4669[3] = + _LNGOFF_4_3_0_7_;
	O4669[4] = + _PTROFF_5_3_0_7_0_1_;
	O4669[5] = + _LNGOFF_4_3_0_8_;
	O4669[6] =  + _REFACS_5_;
	O4669[7] = + _LNGOFF_5_4_0_7_;
	O4669[8] =  + _REFACS_5_;
}

long O4670[9];
void O4670_init () {
	O4670[0] =  + _REFACS_6_;
	O4670[1] = + _LNGOFF_6_3_0_6_;
	O4670[2] =  + _REFACS_4_;
	O4670[3] = + _LNGOFF_4_3_0_8_;
	O4670[4] =  + _REFACS_4_;
	O4670[5] = + _LNGOFF_4_3_0_0_;
	O4670[6] =  + _REFACS_6_;
	O4670[7] =  + _REFACS_4_;
	O4670[8] =  + _REFACS_6_;
}

long O4704[9];
void O4704_init () {
	O4704[0] = + _LNGOFF_7_3_0_6_;
	O4704[1] = + _LNGOFF_6_3_0_7_;
	O4704[2] = + _LNGOFF_5_3_0_8_;
	O4704[3] = + _LNGOFF_4_3_0_9_;
	O4704[4] = + _LNGOFF_5_3_0_6_;
	O4704[5] = + _LNGOFF_4_3_0_9_;
	O4704[6] = + _LNGOFF_7_4_0_6_;
	O4704[7] = + _LNGOFF_5_4_0_8_;
	O4704[8] = + _LNGOFF_9_3_0_6_;
}

long O4707[2];
void O4707_init () {
	O4707[0] = + _CHROFF_7_3_;
	O4707[1] = + _CHROFF_5_3_;
}

long O4732[472];
void O4732_init () {
	{long i; for (i = 0; i < 15; i++) O4732[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O4732[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O4732[i] = + _LNGOFF_9_2_0_0_;}
	O4732[19] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 20; i < 38; i++) O4732[i] = + _LNGOFF_9_2_0_0_;}
	{long i; for (i = 38; i < 40; i++) O4732[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 40; i < 43; i++) O4732[i] = + _LNGOFF_5_2_0_0_;}
	O4732[471] = + _LNGOFF_7_2_0_0_;
}

long O4740[457];
void O4740_init () {
	{long i; for (i = 0; i < 2; i++) O4740[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O4740[i] = + _CHROFF_9_1_;}
	O4740[4] = + _CHROFF_10_1_;
	{long i; for (i = 5; i < 23; i++) O4740[i] = + _CHROFF_9_1_;}
	{long i; for (i = 23; i < 25; i++) O4740[i] = + _CHROFF_3_1_;}
	{long i; for (i = 25; i < 28; i++) O4740[i] = + _CHROFF_5_1_;}
	O4740[456] = + _CHROFF_7_1_;
}

long O4752[21];
void O4752_init () {
	{long i; for (i = 0; i < 2; i++) O4752[i] = + _LNGOFF_9_2_0_1_;}
	O4752[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 21; i++) O4752[i] = + _LNGOFF_9_2_0_1_;}
}

static EIF_TYPE_INDEX Y4799_pgtype0[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4799_pgtype1[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4799_pgtype2[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4799_pgtype3[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4799_pgtype4[] = {635,0xFFF9,1,901,1025,0xFFFF};
EIF_TYPE_INDEX *Y4799_gen_type [5];
EIF_TYPE_INDEX Y4799 [5];
void Y4799_init (void)
{
	egc_routines_types [4799] = Y4799;
	egc_routines_gen_types [4799] = Y4799_gen_type;
	egc_routines_offset [4799] = 656;
	Y4799_gen_type [0] = Y4799_pgtype0;
	Y4799_gen_type [1] = Y4799_pgtype1;
	Y4799_gen_type [2] = Y4799_pgtype2;
	Y4799_gen_type [3] = Y4799_pgtype3;
	Y4799_gen_type [4] = Y4799_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4799[i] = 635;};
}

static EIF_TYPE_INDEX Y4800_pgtype0[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4800_pgtype1[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4800_pgtype2[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4800_pgtype3[] = {635,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4800_pgtype4[] = {635,0xFFF9,1,901,1025,0xFFFF};
EIF_TYPE_INDEX *Y4800_gen_type [5];
EIF_TYPE_INDEX Y4800 [5];
void Y4800_init (void)
{
	egc_routines_types [4800] = Y4800;
	egc_routines_gen_types [4800] = Y4800_gen_type;
	egc_routines_offset [4800] = 656;
	Y4800_gen_type [0] = Y4800_pgtype0;
	Y4800_gen_type [1] = Y4800_pgtype1;
	Y4800_gen_type [2] = Y4800_pgtype2;
	Y4800_gen_type [3] = Y4800_pgtype3;
	Y4800_gen_type [4] = Y4800_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4800[i] = 635;};
}

static EIF_TYPE_INDEX Y4801_pgtype0[] = {636,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4801_pgtype1[] = {636,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4801_pgtype2[] = {636,0xFFF9,1,901,1025,0xFFFF};
EIF_TYPE_INDEX *Y4801_gen_type [3];
EIF_TYPE_INDEX Y4801 [3];
void Y4801_init (void)
{
	egc_routines_types [4801] = Y4801;
	egc_routines_gen_types [4801] = Y4801_gen_type;
	egc_routines_offset [4801] = 658;
	Y4801_gen_type [0] = Y4801_pgtype0;
	Y4801_gen_type [1] = Y4801_pgtype1;
	Y4801_gen_type [2] = Y4801_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4801[i] = 636;};
}

static EIF_TYPE_INDEX Y4802_pgtype0[] = {636,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4802_pgtype1[] = {636,0xFFF9,1,901,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4802_pgtype2[] = {636,0xFFF9,1,901,1025,0xFFFF};
EIF_TYPE_INDEX *Y4802_gen_type [3];
EIF_TYPE_INDEX Y4802 [3];
void Y4802_init (void)
{
	egc_routines_types [4802] = Y4802;
	egc_routines_gen_types [4802] = Y4802_gen_type;
	egc_routines_offset [4802] = 658;
	Y4802_gen_type [0] = Y4802_pgtype0;
	Y4802_gen_type [1] = Y4802_pgtype1;
	Y4802_gen_type [2] = Y4802_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4802[i] = 636;};
}

long O4866[21];
void O4866_init () {
	{long i; for (i = 0; i < 12; i++) O4866[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O4866[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 21; i++) O4866[i] = + _LNGOFF_1_1_0_0_;}
}

long O4870[21];
void O4870_init () {
	{long i; for (i = 0; i < 12; i++) O4870[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O4870[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 21; i++) O4870[i] = + _CHROFF_1_0_;}
}

long O4871[21];
void O4871_init () {
	{long i; for (i = 0; i < 12; i++) O4871[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O4871[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 21; i++) O4871[i] = + _LNGOFF_1_1_0_1_;}
}

long O4872[21];
void O4872_init () {
	{long i; for (i = 0; i < 12; i++) O4872[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O4872[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 21; i++) O4872[i] = + _LNGOFF_1_1_0_2_;}
}

long O4873[21];
void O4873_init () {
	{long i; for (i = 0; i < 12; i++) O4873[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O4873[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 21; i++) O4873[i] = + _LNGOFF_1_1_0_3_;}
}

long O4874[21];
void O4874_init () {
	{long i; for (i = 0; i < 12; i++) O4874[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O4874[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 21; i++) O4874[i] = + _LNGOFF_1_1_0_4_;}
}

long O4877[50];
void O4877_init () {
	{long i; for (i = 0; i < 12; i++) O4877[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O4877[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O4877[i] = + _LNGOFF_1_0_0_0_;}
}

long O4879[50];
void O4879_init () {
	{long i; for (i = 0; i < 12; i++) O4879[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O4879[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O4879[i] = + _LNGOFF_1_0_0_1_;}
}

long O5315[433];
void O5315_init () {
	O5315[0] = + _CHROFF_1_0_;
	O5315[1] = + _CHROFF_2_0_;
	O5315[2] = + _CHROFF_3_0_;
	O5315[3] = + _CHROFF_4_0_;
	O5315[4] = + _CHROFF_5_0_;
	O5315[432] = + _CHROFF_5_0_;
}

long O5432[431];
void O5432_init () {
	O5432[0] = + _PTROFF_3_6_2_4_1_0_;
	O5432[1] = + _PTROFF_4_6_2_4_1_0_;
	O5432[2] = + _PTROFF_5_7_2_4_1_0_;
	O5432[430] = + _PTROFF_5_7_2_4_1_0_;
}

long O5571[431];
void O5571_init () {
	O5571[0] = + _LNGOFF_3_6_2_3_;
	O5571[1] = + _LNGOFF_4_6_2_3_;
	O5571[2] = + _LNGOFF_5_7_2_3_;
	O5571[430] = + _LNGOFF_5_7_2_3_;
}


#ifdef __cplusplus
}
#endif
