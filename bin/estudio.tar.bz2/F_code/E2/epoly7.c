#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4445[511])();
void R4445_init () {
	R4445[0] = (char *(*)()) F601_4974;
	R4445[1] = (char *(*)()) F602_4974_4445_4;
	R4445[2] = (char *(*)()) F603_4974_4445_4;
	{long i; for (i = 3; i < 5; i++) R4445[i] = (char *(*)()) F601_4974;}
	R4445[5] = (char *(*)()) F603_4974_4445_4;
	R4445[6] = (char *(*)()) F602_4974_4445_4;
	R4445[18] = (char *(*)()) F619_5232;
	R4445[19] = (char *(*)()) F620_5232_4445_4;
	R4445[20] = (char *(*)()) F621_5232_4445_4;
	R4445[21] = (char *(*)()) F622_5232_4445_4;
	R4445[22] = (char *(*)()) F623_5232_4445_4;
	R4445[23] = (char *(*)()) F624_5232_4445_4;
	R4445[24] = (char *(*)()) F625_5232_4445_4;
	R4445[25] = (char *(*)()) F626_5232_4445_4;
	R4445[26] = (char *(*)()) F627_5232_4445_4;
	R4445[27] = (char *(*)()) F628_5232_4445_4;
	R4445[28] = (char *(*)()) F629_5232_4445_4;
	R4445[29] = (char *(*)()) F630_5232_4445_4;
	R4445[30] = (char *(*)()) F619_5232;
	R4445[31] = (char *(*)()) F625_5232_4445_4;
	R4445[32] = (char *(*)()) F622_5232_4445_4;
	{long i; for (i = 35; i < 38; i++) R4445[i] = (char *(*)()) F634_5276;}
	R4445[42] = (char *(*)()) F634_5276;
	R4445[45] = (char *(*)()) F634_5276;
	R4445[47] = (char *(*)()) F634_5276;
	R4445[50] = (char *(*)()) F634_5276;
	{long i; for (i = 52; i < 56; i++) R4445[i] = (char *(*)()) F634_5276;}
	R4445[58] = (char *(*)()) F634_5276;
	R4445[59] = (char *(*)()) F635_5276_4445_4;
	R4445[60] = (char *(*)()) F634_5276;
	{long i; for (i = 463; i < 465; i++) R4445[i] = (char *(*)()) F1056_9263;}
	R4445[501] = (char *(*)()) F1056_9263;
	R4445[510] = (char *(*)()) F1056_9263;
}
static void F602_4974_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F602_4974(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F603_4974_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F603_4974(Current, *(EIF_BOOLEAN *)arg1);
}
static void F620_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5232(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5232(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5232(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5232(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5232(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5232(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5232(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5232(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5232(Current, *(EIF_POINTER *)arg1);
}
static void F629_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5232(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5232_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5232(Current, *(EIF_REAL_64 *)arg1);
}
static void F635_5276_4445_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F635_5276(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4446[511])();
void R4446_init () {
	R4446[0] = (char *(*)()) F601_4977;
	R4446[1] = (char *(*)()) F602_4977;
	R4446[2] = (char *(*)()) F603_4977;
	R4446[3] = (char *(*)()) F601_4978;
	R4446[4] = (char *(*)()) F605_5014;
	R4446[5] = (char *(*)()) F606_5014;
	R4446[6] = (char *(*)()) F607_5014;
	R4446[18] = (char *(*)()) F619_5242;
	R4446[19] = (char *(*)()) F620_5242;
	R4446[20] = (char *(*)()) F621_5242;
	R4446[21] = (char *(*)()) F622_5242;
	R4446[22] = (char *(*)()) F623_5242;
	R4446[23] = (char *(*)()) F624_5242;
	R4446[24] = (char *(*)()) F625_5242;
	R4446[25] = (char *(*)()) F626_5242;
	R4446[26] = (char *(*)()) F627_5242;
	R4446[27] = (char *(*)()) F628_5242;
	R4446[28] = (char *(*)()) F629_5242;
	R4446[29] = (char *(*)()) F630_5242;
	R4446[30] = (char *(*)()) F631_5258;
	R4446[31] = (char *(*)()) F632_5258;
	R4446[32] = (char *(*)()) F633_5258;
	{long i; for (i = 35; i < 38; i++) R4446[i] = (char *(*)()) F634_5277;}
	R4446[42] = (char *(*)()) F634_5277;
	R4446[45] = (char *(*)()) F634_5277;
	R4446[47] = (char *(*)()) F634_5277;
	R4446[50] = (char *(*)()) F634_5277;
	{long i; for (i = 52; i < 56; i++) R4446[i] = (char *(*)()) F634_5277;}
	R4446[58] = (char *(*)()) F634_5277;
	R4446[59] = (char *(*)()) F635_5277;
	R4446[60] = (char *(*)()) F634_5277;
	{long i; for (i = 463; i < 465; i++) R4446[i] = (char *(*)()) F1056_9254;}
	R4446[501] = (char *(*)()) F1056_9254;
	R4446[510] = (char *(*)()) F1056_9254;
}

char *(*R4447[511])();
void R4447_init () {
	R4447[0] = (char *(*)()) F601_4950;
	R4447[1] = (char *(*)()) F602_4950;
	R4447[2] = (char *(*)()) F603_4950;
	{long i; for (i = 3; i < 5; i++) R4447[i] = (char *(*)()) F601_4950;}
	R4447[5] = (char *(*)()) F603_4950;
	R4447[6] = (char *(*)()) F602_4950;
	R4447[18] = (char *(*)()) F619_5199;
	R4447[19] = (char *(*)()) F620_5199;
	R4447[20] = (char *(*)()) F621_5199;
	R4447[21] = (char *(*)()) F622_5199;
	R4447[22] = (char *(*)()) F623_5199;
	R4447[23] = (char *(*)()) F624_5199;
	R4447[24] = (char *(*)()) F625_5199;
	R4447[25] = (char *(*)()) F626_5199;
	R4447[26] = (char *(*)()) F627_5199;
	R4447[27] = (char *(*)()) F628_5199;
	R4447[28] = (char *(*)()) F629_5199;
	R4447[29] = (char *(*)()) F630_5199;
	R4447[30] = (char *(*)()) F619_5199;
	R4447[31] = (char *(*)()) F625_5199;
	R4447[32] = (char *(*)()) F622_5199;
	{long i; for (i = 35; i < 38; i++) R4447[i] = (char *(*)()) F619_5199;}
	R4447[42] = (char *(*)()) F619_5199;
	R4447[45] = (char *(*)()) F619_5199;
	R4447[47] = (char *(*)()) F619_5199;
	R4447[50] = (char *(*)()) F619_5199;
	{long i; for (i = 52; i < 56; i++) R4447[i] = (char *(*)()) F619_5199;}
	R4447[58] = (char *(*)()) F619_5199;
	R4447[59] = (char *(*)()) F625_5199;
	R4447[60] = (char *(*)()) F619_5199;
	{long i; for (i = 463; i < 465; i++) R4447[i] = (char *(*)()) F1056_9228;}
	R4447[501] = (char *(*)()) F1056_9228;
	R4447[510] = (char *(*)()) F1056_9228;
}

static EIF_TYPE_INDEX Y4447_pgtype0[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype1[] = {231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype2[] = {232,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype3[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype4[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype5[] = {232,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype6[] = {231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype7[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype8[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype9[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype10[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype11[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype12[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype13[] = {229,1057,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype14[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype15[] = {229,1089,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype16[] = {229,1091,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype17[] = {229,1090,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype18[] = {229,1090,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype19[] = {229,1090,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype20[] = {229,1107,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype21[] = {229,1107,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype22[] = {229,1107,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype23[] = {229,1107,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype24[] = {229,1095,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype25[] = {229,1095,0xFFFF};
static EIF_TYPE_INDEX Y4447_pgtype26[] = {229,1095,0xFFFF};
EIF_TYPE_INDEX *Y4447_gen_type [695];
EIF_TYPE_INDEX Y4447 [695];
void Y4447_init (void)
{
	egc_routines_types [4447] = Y4447;
	egc_routines_gen_types [4447] = Y4447_gen_type;
	egc_routines_offset [4447] = 417;
	Y4447_gen_type [183] = Y4447_pgtype0;
	Y4447_gen_type [184] = Y4447_pgtype1;
	Y4447_gen_type [185] = Y4447_pgtype2;
	Y4447_gen_type [186] = Y4447_pgtype3;
	Y4447_gen_type [187] = Y4447_pgtype4;
	Y4447_gen_type [188] = Y4447_pgtype5;
	Y4447_gen_type [189] = Y4447_pgtype6;
	Y4447_gen_type [638] = Y4447_pgtype7;
	Y4447_gen_type [642] = Y4447_pgtype8;
	Y4447_gen_type [643] = Y4447_pgtype9;
	Y4447_gen_type [644] = Y4447_pgtype10;
	Y4447_gen_type [645] = Y4447_pgtype11;
	Y4447_gen_type [646] = Y4447_pgtype12;
	Y4447_gen_type [647] = Y4447_pgtype13;
	Y4447_gen_type [682] = Y4447_pgtype14;
	Y4447_gen_type [683] = Y4447_pgtype15;
	Y4447_gen_type [684] = Y4447_pgtype16;
	Y4447_gen_type [685] = Y4447_pgtype17;
	Y4447_gen_type [686] = Y4447_pgtype18;
	Y4447_gen_type [687] = Y4447_pgtype19;
	Y4447_gen_type [688] = Y4447_pgtype20;
	Y4447_gen_type [689] = Y4447_pgtype21;
	Y4447_gen_type [690] = Y4447_pgtype22;
	Y4447_gen_type [691] = Y4447_pgtype23;
	Y4447_gen_type [692] = Y4447_pgtype24;
	Y4447_gen_type [693] = Y4447_pgtype25;
	Y4447_gen_type [694] = Y4447_pgtype26;
	{long i; for (i = 0; i < 12; i++) Y4447[i] = 228;};
	{long i; for (i = 135; i < 183; i++) Y4447[i] = 228;};
	Y4447[183] = 230;
	Y4447[184] = 231;
	Y4447[185] = 232;
	{long i; for (i = 186; i < 188; i++) Y4447[i] = 230;};
	Y4447[188] = 232;
	Y4447[189] = 231;
	{long i; for (i = 201; i < 244; i++) Y4447[i] = 234;};
	Y4447[638] = 229;
	{long i; for (i = 642; i < 648; i++) Y4447[i] = 229;};
	Y4447[672] = 234;
	{long i; for (i = 682; i < 695; i++) Y4447[i] = 229;};
}

char *(*R4449[511])();
void R4449_init () {
	R4449[0] = (char *(*)()) F601_4969;
	R4449[1] = (char *(*)()) F602_4969;
	R4449[2] = (char *(*)()) F603_4969;
	{long i; for (i = 3; i < 5; i++) R4449[i] = (char *(*)()) F601_4969;}
	R4449[5] = (char *(*)()) F603_4969;
	R4449[6] = (char *(*)()) F602_4969;
	R4449[18] = (char *(*)()) F619_5224;
	R4449[19] = (char *(*)()) F620_5224;
	R4449[20] = (char *(*)()) F621_5224;
	R4449[21] = (char *(*)()) F622_5224;
	R4449[22] = (char *(*)()) F623_5224;
	R4449[23] = (char *(*)()) F624_5224;
	R4449[24] = (char *(*)()) F625_5224;
	R4449[25] = (char *(*)()) F626_5224;
	R4449[26] = (char *(*)()) F627_5224;
	R4449[27] = (char *(*)()) F628_5224;
	R4449[28] = (char *(*)()) F629_5224;
	R4449[29] = (char *(*)()) F630_5224;
	R4449[30] = (char *(*)()) F619_5224;
	R4449[31] = (char *(*)()) F625_5224;
	R4449[32] = (char *(*)()) F622_5224;
	{long i; for (i = 35; i < 38; i++) R4449[i] = (char *(*)()) F619_5224;}
	R4449[42] = (char *(*)()) F619_5224;
	R4449[45] = (char *(*)()) F619_5224;
	R4449[47] = (char *(*)()) F619_5224;
	R4449[50] = (char *(*)()) F619_5224;
	{long i; for (i = 52; i < 56; i++) R4449[i] = (char *(*)()) F619_5224;}
	R4449[58] = (char *(*)()) F619_5224;
	R4449[59] = (char *(*)()) F625_5224;
	R4449[60] = (char *(*)()) F619_5224;
	{long i; for (i = 463; i < 465; i++) R4449[i] = (char *(*)()) F1056_9240;}
	R4449[501] = (char *(*)()) F1056_9240;
	R4449[510] = (char *(*)()) F1056_9240;
}

char *(*R4453[748])();
void R4453_init () {
	R4453[0] = (char *(*)()) F540_4826;
	R4453[1] = (char *(*)()) F541_4826;
	R4453[2] = (char *(*)()) F542_4826;
	R4453[3] = (char *(*)()) F543_4826;
	R4453[4] = (char *(*)()) F544_4826;
	R4453[5] = (char *(*)()) F545_4826;
	R4453[6] = (char *(*)()) F546_4826;
	R4453[7] = (char *(*)()) F547_4826;
	R4453[8] = (char *(*)()) F548_4826;
	R4453[9] = (char *(*)()) F549_4826;
	R4453[10] = (char *(*)()) F550_4826;
	R4453[11] = (char *(*)()) F551_4826;
	R4453[61] = (char *(*)()) F601_4953;
	R4453[62] = (char *(*)()) F602_4953;
	R4453[63] = (char *(*)()) F603_4953;
	{long i; for (i = 64; i < 66; i++) R4453[i] = (char *(*)()) F601_4953;}
	R4453[66] = (char *(*)()) F603_4953;
	R4453[67] = (char *(*)()) F602_4953;
	R4453[70] = (char *(*)()) F610_5075;
	R4453[71] = (char *(*)()) F611_5075;
	R4453[72] = (char *(*)()) F612_5075;
	R4453[73] = (char *(*)()) F613_5075;
	R4453[74] = (char *(*)()) F614_5075;
	R4453[75] = (char *(*)()) F615_5075;
	R4453[76] = (char *(*)()) F610_5075;
	R4453[77] = (char *(*)()) F612_5075;
	R4453[78] = (char *(*)()) F610_5075;
	R4453[79] = (char *(*)()) F619_5209;
	R4453[80] = (char *(*)()) F620_5209;
	R4453[81] = (char *(*)()) F621_5209;
	R4453[82] = (char *(*)()) F622_5209;
	R4453[83] = (char *(*)()) F623_5209;
	R4453[84] = (char *(*)()) F624_5209;
	R4453[85] = (char *(*)()) F625_5209;
	R4453[86] = (char *(*)()) F626_5209;
	R4453[87] = (char *(*)()) F627_5209;
	R4453[88] = (char *(*)()) F628_5209;
	R4453[89] = (char *(*)()) F629_5209;
	R4453[90] = (char *(*)()) F630_5209;
	R4453[91] = (char *(*)()) F619_5209;
	R4453[92] = (char *(*)()) F625_5209;
	R4453[93] = (char *(*)()) F622_5209;
	{long i; for (i = 96; i < 99; i++) R4453[i] = (char *(*)()) F619_5209;}
	R4453[103] = (char *(*)()) F619_5209;
	R4453[106] = (char *(*)()) F619_5209;
	R4453[108] = (char *(*)()) F619_5209;
	R4453[111] = (char *(*)()) F619_5209;
	{long i; for (i = 113; i < 117; i++) R4453[i] = (char *(*)()) F619_5209;}
	R4453[119] = (char *(*)()) F619_5209;
	R4453[120] = (char *(*)()) F625_5209;
	R4453[121] = (char *(*)()) F619_5209;
	R4453[318] = (char *(*)()) F857_6254;
	R4453[448] = (char *(*)()) F983_8223;
	R4453[449] = (char *(*)()) F985_8300;
	{long i; for (i = 524; i < 526; i++) R4453[i] = (char *(*)()) F1056_9233;}
	R4453[562] = (char *(*)()) F1056_9233;
	R4453[571] = (char *(*)()) F1056_9233;
	R4453[747] = (char *(*)()) F1287_13082;
}

char *(*R4454[450])();
void R4454_init () {
	R4454[0] = (char *(*)()) F540_4827;
	R4454[1] = (char *(*)()) F541_4827;
	R4454[2] = (char *(*)()) F542_4827;
	R4454[3] = (char *(*)()) F543_4827;
	R4454[4] = (char *(*)()) F544_4827;
	R4454[5] = (char *(*)()) F545_4827;
	R4454[6] = (char *(*)()) F546_4827;
	R4454[7] = (char *(*)()) F547_4827;
	R4454[8] = (char *(*)()) F548_4827;
	R4454[9] = (char *(*)()) F549_4827;
	R4454[10] = (char *(*)()) F550_4827;
	R4454[11] = (char *(*)()) F551_4827;
	R4454[79] = (char *(*)()) F619_5210;
	R4454[80] = (char *(*)()) F620_5210;
	R4454[81] = (char *(*)()) F621_5210;
	R4454[82] = (char *(*)()) F622_5210;
	R4454[83] = (char *(*)()) F623_5210;
	R4454[84] = (char *(*)()) F624_5210;
	R4454[85] = (char *(*)()) F625_5210;
	R4454[86] = (char *(*)()) F626_5210;
	R4454[87] = (char *(*)()) F627_5210;
	R4454[88] = (char *(*)()) F628_5210;
	R4454[89] = (char *(*)()) F629_5210;
	R4454[90] = (char *(*)()) F630_5210;
	R4454[91] = (char *(*)()) F619_5210;
	R4454[92] = (char *(*)()) F625_5210;
	R4454[93] = (char *(*)()) F622_5210;
	{long i; for (i = 96; i < 99; i++) R4454[i] = (char *(*)()) F619_5210;}
	R4454[103] = (char *(*)()) F619_5210;
	R4454[106] = (char *(*)()) F619_5210;
	R4454[108] = (char *(*)()) F619_5210;
	R4454[111] = (char *(*)()) F619_5210;
	{long i; for (i = 113; i < 117; i++) R4454[i] = (char *(*)()) F619_5210;}
	R4454[119] = (char *(*)()) F619_5210;
	R4454[120] = (char *(*)()) F625_5210;
	R4454[121] = (char *(*)()) F619_5210;
	R4454[448] = (char *(*)()) F983_8222;
	R4454[449] = (char *(*)()) F985_8299;
}

char *(*R4458[450])();
void R4458_init () {
	R4458[0] = (char *(*)()) F469_4704;
	R4458[1] = (char *(*)()) F470_4704;
	R4458[2] = (char *(*)()) F471_4704;
	R4458[3] = (char *(*)()) F472_4704;
	R4458[4] = (char *(*)()) F473_4704;
	R4458[5] = (char *(*)()) F474_4704;
	R4458[6] = (char *(*)()) F475_4704;
	R4458[7] = (char *(*)()) F476_4704;
	R4458[8] = (char *(*)()) F477_4704;
	R4458[9] = (char *(*)()) F478_4704;
	R4458[10] = (char *(*)()) F479_4704;
	R4458[11] = (char *(*)()) F480_4704;
	R4458[79] = (char *(*)()) F469_4704;
	R4458[80] = (char *(*)()) F470_4704;
	R4458[81] = (char *(*)()) F471_4704;
	R4458[82] = (char *(*)()) F472_4704;
	R4458[83] = (char *(*)()) F473_4704;
	R4458[84] = (char *(*)()) F474_4704;
	R4458[85] = (char *(*)()) F475_4704;
	R4458[86] = (char *(*)()) F476_4704;
	R4458[87] = (char *(*)()) F477_4704;
	R4458[88] = (char *(*)()) F478_4704;
	R4458[89] = (char *(*)()) F479_4704;
	R4458[90] = (char *(*)()) F480_4704;
	R4458[91] = (char *(*)()) F469_4704;
	R4458[92] = (char *(*)()) F475_4704;
	R4458[93] = (char *(*)()) F472_4704;
	{long i; for (i = 96; i < 99; i++) R4458[i] = (char *(*)()) F469_4704;}
	R4458[103] = (char *(*)()) F469_4704;
	R4458[106] = (char *(*)()) F469_4704;
	R4458[108] = (char *(*)()) F469_4704;
	R4458[111] = (char *(*)()) F469_4704;
	{long i; for (i = 113; i < 117; i++) R4458[i] = (char *(*)()) F469_4704;}
	R4458[119] = (char *(*)()) F469_4704;
	R4458[120] = (char *(*)()) F475_4704;
	R4458[121] = (char *(*)()) F469_4704;
	R4458[448] = (char *(*)()) F477_4704;
	R4458[449] = (char *(*)()) F471_4704;
}

char *(*R4460[371])();
void R4460_init () {
	R4460[0] = (char *(*)()) F619_5236;
	R4460[1] = (char *(*)()) F620_5236;
	R4460[2] = (char *(*)()) F621_5236;
	R4460[3] = (char *(*)()) F622_5236;
	R4460[4] = (char *(*)()) F623_5236;
	R4460[5] = (char *(*)()) F624_5236;
	R4460[6] = (char *(*)()) F625_5236;
	R4460[7] = (char *(*)()) F626_5236;
	R4460[8] = (char *(*)()) F627_5236;
	R4460[9] = (char *(*)()) F628_5236;
	R4460[10] = (char *(*)()) F629_5236;
	R4460[11] = (char *(*)()) F630_5236;
	R4460[12] = (char *(*)()) F619_5236;
	R4460[13] = (char *(*)()) F625_5236;
	R4460[14] = (char *(*)()) F622_5236;
	{long i; for (i = 17; i < 20; i++) R4460[i] = (char *(*)()) F619_5236;}
	R4460[24] = (char *(*)()) F619_5236;
	R4460[27] = (char *(*)()) F619_5236;
	R4460[29] = (char *(*)()) F619_5236;
	R4460[32] = (char *(*)()) F619_5236;
	{long i; for (i = 34; i < 38; i++) R4460[i] = (char *(*)()) F619_5236;}
	R4460[40] = (char *(*)()) F619_5236;
	R4460[41] = (char *(*)()) F625_5236;
	R4460[42] = (char *(*)()) F619_5236;
	R4460[369] = (char *(*)()) F988_8458;
	R4460[370] = (char *(*)()) F989_8549;
}

char *(*R4462[687])();
void R4462_init () {
	R4462[0] = (char *(*)()) F481_4711;
	R4462[1] = (char *(*)()) F485_4711_4462_4;
	R4462[2] = (char *(*)()) F484_4711_4462_4;
	R4462[3] = (char *(*)()) F604_4995;
	R4462[4] = (char *(*)()) F605_5011;
	R4462[5] = (char *(*)()) F606_5011_4462_4;
	R4462[6] = (char *(*)()) F607_5011_4462_4;
	R4462[18] = (char *(*)()) F619_5228;
	R4462[19] = (char *(*)()) F620_5228_4462_4;
	R4462[20] = (char *(*)()) F621_5228_4462_4;
	R4462[21] = (char *(*)()) F622_5228_4462_4;
	R4462[22] = (char *(*)()) F623_5228_4462_4;
	R4462[23] = (char *(*)()) F624_5228_4462_4;
	R4462[24] = (char *(*)()) F625_5228_4462_4;
	R4462[25] = (char *(*)()) F626_5228_4462_4;
	R4462[26] = (char *(*)()) F627_5228_4462_4;
	R4462[27] = (char *(*)()) F628_5228_4462_4;
	R4462[28] = (char *(*)()) F629_5228_4462_4;
	R4462[29] = (char *(*)()) F630_5228_4462_4;
	R4462[30] = (char *(*)()) F619_5228;
	R4462[31] = (char *(*)()) F625_5228_4462_4;
	R4462[32] = (char *(*)()) F622_5228_4462_4;
	{long i; for (i = 35; i < 38; i++) R4462[i] = (char *(*)()) F619_5228;}
	R4462[42] = (char *(*)()) F619_5228;
	R4462[45] = (char *(*)()) F619_5228;
	R4462[47] = (char *(*)()) F619_5228;
	R4462[50] = (char *(*)()) F619_5228;
	{long i; for (i = 52; i < 56; i++) R4462[i] = (char *(*)()) F619_5228;}
	R4462[58] = (char *(*)()) F619_5228;
	R4462[59] = (char *(*)()) F625_5228_4462_4;
	R4462[60] = (char *(*)()) F619_5228;
	R4462[257] = (char *(*)()) F483_4711_4462_4;
	{long i; for (i = 463; i < 465; i++) R4462[i] = (char *(*)()) F481_4711;}
	R4462[501] = (char *(*)()) F481_4711;
	R4462[510] = (char *(*)()) F481_4711;
	R4462[686] = (char *(*)()) F483_4711_4462_4;
}
static void F485_4711_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F485_4711(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F484_4711_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F484_4711(Current, *(EIF_BOOLEAN *)arg1);
}
static void F606_5011_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F606_5011(Current, *(EIF_BOOLEAN *)arg1);
}
static void F607_5011_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F607_5011(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F620_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5228(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5228(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5228(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5228(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5228(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5228(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5228(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5228(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5228(Current, *(EIF_POINTER *)arg1);
}
static void F629_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5228(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5228_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5228(Current, *(EIF_REAL_64 *)arg1);
}
static void F483_4711_4462_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F483_4711(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4476[572])();
void R4476_init () {
	R4476[0] = (char *(*)()) F540_4819;
	R4476[1] = (char *(*)()) F541_4819_4476_89;
	R4476[2] = (char *(*)()) F542_4819_4476_89;
	R4476[3] = (char *(*)()) F543_4819_4476_89;
	R4476[4] = (char *(*)()) F544_4819_4476_89;
	R4476[5] = (char *(*)()) F545_4819_4476_89;
	R4476[6] = (char *(*)()) F546_4819_4476_89;
	R4476[7] = (char *(*)()) F547_4819_4476_89;
	R4476[8] = (char *(*)()) F548_4819_4476_89;
	R4476[9] = (char *(*)()) F549_4819_4476_89;
	R4476[10] = (char *(*)()) F550_4819_4476_89;
	R4476[11] = (char *(*)()) F551_4819_4476_89;
	R4476[61] = (char *(*)()) F553_4898;
	R4476[62] = (char *(*)()) F557_4898_4476_89;
	R4476[63] = (char *(*)()) F556_4898_4476_89;
	{long i; for (i = 64; i < 66; i++) R4476[i] = (char *(*)()) F553_4898;}
	R4476[66] = (char *(*)()) F556_4898_4476_89;
	R4476[67] = (char *(*)()) F557_4898_4476_89;
	R4476[70] = (char *(*)()) F610_5073;
	R4476[71] = (char *(*)()) F611_5073;
	R4476[72] = (char *(*)()) F612_5073_4476_89;
	R4476[73] = (char *(*)()) F613_5073_4476_89;
	R4476[74] = (char *(*)()) F614_5073_4476_89;
	R4476[75] = (char *(*)()) F615_5073_4476_89;
	R4476[76] = (char *(*)()) F610_5073;
	R4476[77] = (char *(*)()) F612_5073_4476_89;
	R4476[78] = (char *(*)()) F610_5073;
	R4476[79] = (char *(*)()) F619_5194;
	R4476[80] = (char *(*)()) F620_5194_4476_89;
	R4476[81] = (char *(*)()) F621_5194_4476_89;
	R4476[82] = (char *(*)()) F622_5194_4476_89;
	R4476[83] = (char *(*)()) F623_5194_4476_89;
	R4476[84] = (char *(*)()) F624_5194_4476_89;
	R4476[85] = (char *(*)()) F625_5194_4476_89;
	R4476[86] = (char *(*)()) F626_5194_4476_89;
	R4476[87] = (char *(*)()) F627_5194_4476_89;
	R4476[88] = (char *(*)()) F628_5194_4476_89;
	R4476[89] = (char *(*)()) F629_5194_4476_89;
	R4476[90] = (char *(*)()) F630_5194_4476_89;
	R4476[91] = (char *(*)()) F619_5194;
	R4476[92] = (char *(*)()) F625_5194_4476_89;
	R4476[93] = (char *(*)()) F622_5194_4476_89;
	{long i; for (i = 96; i < 99; i++) R4476[i] = (char *(*)()) F619_5194;}
	R4476[103] = (char *(*)()) F619_5194;
	R4476[106] = (char *(*)()) F619_5194;
	R4476[108] = (char *(*)()) F619_5194;
	R4476[111] = (char *(*)()) F619_5194;
	{long i; for (i = 113; i < 117; i++) R4476[i] = (char *(*)()) F619_5194;}
	R4476[119] = (char *(*)()) F619_5194;
	R4476[120] = (char *(*)()) F625_5194_4476_89;
	R4476[121] = (char *(*)()) F619_5194;
	R4476[246] = (char *(*)()) F786_5693;
	R4476[247] = (char *(*)()) F787_5693_4476_89;
	R4476[248] = (char *(*)()) F788_5693_4476_89;
	R4476[249] = (char *(*)()) F789_5693_4476_89;
	R4476[250] = (char *(*)()) F790_5693_4476_89;
	R4476[251] = (char *(*)()) F791_5693_4476_89;
	R4476[252] = (char *(*)()) F792_5693_4476_89;
	R4476[253] = (char *(*)()) F793_5693_4476_89;
	R4476[254] = (char *(*)()) F794_5693_4476_89;
	R4476[255] = (char *(*)()) F795_5693_4476_89;
	R4476[256] = (char *(*)()) F796_5693_4476_89;
	R4476[257] = (char *(*)()) F797_5693_4476_89;
	R4476[362] = (char *(*)()) F902_6873;
	R4476[444] = (char *(*)()) F984_8261_4476_89;
	R4476[446] = (char *(*)()) F986_8335_4476_89;
	R4476[448] = (char *(*)()) F988_8392_4476_89;
	R4476[449] = (char *(*)()) F989_8482_4476_89;
	{long i; for (i = 524; i < 526; i++) R4476[i] = (char *(*)()) F1056_9229;}
	R4476[562] = (char *(*)()) F1056_9229;
	R4476[571] = (char *(*)()) F1056_9229;
}
static EIF_REFERENCE F541_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F541_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F542_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F542_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F543_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F543_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F544_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F544_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F545_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F545_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F546_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F546_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F547_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F547_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F548_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F548_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F549_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F550_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F551_4819_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F551_4819(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_4898_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F557_4898(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_4898_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F556_4898(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F612_5073_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F612_5073(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5073_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5073(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5073_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F614_5073(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5073_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F615_5073(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F620_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5194_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5194(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F787_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F788_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F789_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F790_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F791_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F791_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F792_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F792_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F793_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F793_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F794_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F794_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F795_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F796_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_5693_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F797_5693(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_8261_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F984_8261(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F986_8335_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F986_8335(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8392_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F988_8392(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F989_8482_4476_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F989_8482(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4477[572])();
void R4477_init () {
	R4477[0] = (char *(*)()) F540_4824;
	R4477[1] = (char *(*)()) F541_4824;
	R4477[2] = (char *(*)()) F542_4824;
	R4477[3] = (char *(*)()) F543_4824;
	R4477[4] = (char *(*)()) F544_4824;
	R4477[5] = (char *(*)()) F545_4824;
	R4477[6] = (char *(*)()) F546_4824;
	R4477[7] = (char *(*)()) F547_4824;
	R4477[8] = (char *(*)()) F548_4824;
	R4477[9] = (char *(*)()) F549_4824;
	R4477[10] = (char *(*)()) F550_4824;
	R4477[11] = (char *(*)()) F551_4824;
	R4477[61] = (char *(*)()) F553_4901;
	R4477[62] = (char *(*)()) F557_4901;
	R4477[63] = (char *(*)()) F556_4901;
	{long i; for (i = 64; i < 66; i++) R4477[i] = (char *(*)()) F553_4901;}
	R4477[66] = (char *(*)()) F556_4901;
	R4477[67] = (char *(*)()) F557_4901;
	R4477[70] = (char *(*)()) F610_5078;
	R4477[71] = (char *(*)()) F611_5078;
	R4477[72] = (char *(*)()) F612_5078;
	R4477[73] = (char *(*)()) F613_5078;
	R4477[74] = (char *(*)()) F614_5078;
	R4477[75] = (char *(*)()) F615_5078;
	R4477[76] = (char *(*)()) F610_5078;
	R4477[77] = (char *(*)()) F612_5078;
	R4477[78] = (char *(*)()) F610_5078;
	R4477[79] = (char *(*)()) F553_4901;
	R4477[80] = (char *(*)()) F554_4901;
	R4477[81] = (char *(*)()) F555_4901;
	R4477[82] = (char *(*)()) F556_4901;
	R4477[83] = (char *(*)()) F558_4901;
	R4477[84] = (char *(*)()) F559_4901;
	R4477[85] = (char *(*)()) F557_4901;
	R4477[86] = (char *(*)()) F560_4901;
	R4477[87] = (char *(*)()) F561_4901;
	R4477[88] = (char *(*)()) F562_4901;
	R4477[89] = (char *(*)()) F563_4901;
	R4477[90] = (char *(*)()) F564_4901;
	R4477[91] = (char *(*)()) F553_4901;
	R4477[92] = (char *(*)()) F557_4901;
	R4477[93] = (char *(*)()) F556_4901;
	{long i; for (i = 96; i < 99; i++) R4477[i] = (char *(*)()) F553_4901;}
	R4477[103] = (char *(*)()) F553_4901;
	R4477[106] = (char *(*)()) F553_4901;
	R4477[108] = (char *(*)()) F553_4901;
	R4477[111] = (char *(*)()) F553_4901;
	{long i; for (i = 113; i < 117; i++) R4477[i] = (char *(*)()) F553_4901;}
	R4477[119] = (char *(*)()) F553_4901;
	R4477[120] = (char *(*)()) F557_4901;
	R4477[121] = (char *(*)()) F553_4901;
	R4477[246] = (char *(*)()) F786_5701;
	R4477[247] = (char *(*)()) F787_5701;
	R4477[248] = (char *(*)()) F788_5701;
	R4477[249] = (char *(*)()) F789_5701;
	R4477[250] = (char *(*)()) F790_5701;
	R4477[251] = (char *(*)()) F791_5701;
	R4477[252] = (char *(*)()) F792_5701;
	R4477[253] = (char *(*)()) F793_5701;
	R4477[254] = (char *(*)()) F794_5701;
	R4477[255] = (char *(*)()) F795_5701;
	R4477[256] = (char *(*)()) F796_5701;
	R4477[257] = (char *(*)()) F797_5701;
	R4477[362] = (char *(*)()) F902_6903;
	R4477[444] = (char *(*)()) F983_8225;
	R4477[446] = (char *(*)()) F985_8302;
	R4477[448] = (char *(*)()) F983_8225;
	R4477[449] = (char *(*)()) F985_8302;
	{long i; for (i = 524; i < 526; i++) R4477[i] = (char *(*)()) F553_4901;}
	R4477[562] = (char *(*)()) F553_4901;
	R4477[571] = (char *(*)()) F553_4901;
}

EIF_TYPE_INDEX *Y4477_gen_type [599];
EIF_TYPE_INDEX Y4477 [599];
void Y4477_init (void)
{
	egc_routines_types [4477] = Y4477;
	egc_routines_gen_types [4477] = Y4477_gen_type;
	egc_routines_offset [4477] = 513;
	{long i; for (i = 0; i < 94; i++) Y4477[i] = 907;};
	{long i; for (i = 96; i < 148; i++) Y4477[i] = 907;};
	{long i; for (i = 272; i < 284; i++) Y4477[i] = 907;};
	Y4477[388] = 907;
	{long i; for (i = 469; i < 473; i++) Y4477[i] = 907;};
	{long i; for (i = 474; i < 477; i++) Y4477[i] = 907;};
	Y4477[542] = 907;
	{long i; for (i = 546; i < 552; i++) Y4477[i] = 907;};
	Y4477[576] = 907;
	{long i; for (i = 586; i < 599; i++) Y4477[i] = 907;};
}

char *(*R4478[572])();
void R4478_init () {
	R4478[0] = (char *(*)()) F540_4825;
	R4478[1] = (char *(*)()) F541_4825;
	R4478[2] = (char *(*)()) F542_4825;
	R4478[3] = (char *(*)()) F543_4825;
	R4478[4] = (char *(*)()) F544_4825;
	R4478[5] = (char *(*)()) F545_4825;
	R4478[6] = (char *(*)()) F546_4825;
	R4478[7] = (char *(*)()) F547_4825;
	R4478[8] = (char *(*)()) F548_4825;
	R4478[9] = (char *(*)()) F549_4825;
	R4478[10] = (char *(*)()) F550_4825;
	R4478[11] = (char *(*)()) F551_4825;
	R4478[61] = (char *(*)()) F601_4953;
	R4478[62] = (char *(*)()) F602_4953;
	R4478[63] = (char *(*)()) F603_4953;
	{long i; for (i = 64; i < 66; i++) R4478[i] = (char *(*)()) F601_4953;}
	R4478[66] = (char *(*)()) F603_4953;
	R4478[67] = (char *(*)()) F602_4953;
	R4478[70] = (char *(*)()) F610_5079;
	R4478[71] = (char *(*)()) F611_5079;
	R4478[72] = (char *(*)()) F612_5079;
	R4478[73] = (char *(*)()) F613_5079;
	R4478[74] = (char *(*)()) F614_5079;
	R4478[75] = (char *(*)()) F615_5079;
	R4478[76] = (char *(*)()) F610_5079;
	R4478[77] = (char *(*)()) F612_5079;
	R4478[78] = (char *(*)()) F610_5079;
	R4478[79] = (char *(*)()) F619_5209;
	R4478[80] = (char *(*)()) F620_5209;
	R4478[81] = (char *(*)()) F621_5209;
	R4478[82] = (char *(*)()) F622_5209;
	R4478[83] = (char *(*)()) F623_5209;
	R4478[84] = (char *(*)()) F624_5209;
	R4478[85] = (char *(*)()) F625_5209;
	R4478[86] = (char *(*)()) F626_5209;
	R4478[87] = (char *(*)()) F627_5209;
	R4478[88] = (char *(*)()) F628_5209;
	R4478[89] = (char *(*)()) F629_5209;
	R4478[90] = (char *(*)()) F630_5209;
	R4478[91] = (char *(*)()) F619_5209;
	R4478[92] = (char *(*)()) F625_5209;
	R4478[93] = (char *(*)()) F622_5209;
	{long i; for (i = 96; i < 99; i++) R4478[i] = (char *(*)()) F619_5209;}
	R4478[103] = (char *(*)()) F619_5209;
	R4478[106] = (char *(*)()) F619_5209;
	R4478[108] = (char *(*)()) F619_5209;
	R4478[111] = (char *(*)()) F619_5209;
	{long i; for (i = 113; i < 117; i++) R4478[i] = (char *(*)()) F619_5209;}
	R4478[119] = (char *(*)()) F619_5209;
	R4478[120] = (char *(*)()) F625_5209;
	R4478[121] = (char *(*)()) F619_5209;
	R4478[246] = (char *(*)()) F786_5702;
	R4478[247] = (char *(*)()) F787_5702;
	R4478[248] = (char *(*)()) F788_5702;
	R4478[249] = (char *(*)()) F789_5702;
	R4478[250] = (char *(*)()) F790_5702;
	R4478[251] = (char *(*)()) F791_5702;
	R4478[252] = (char *(*)()) F792_5702;
	R4478[253] = (char *(*)()) F793_5702;
	R4478[254] = (char *(*)()) F794_5702;
	R4478[255] = (char *(*)()) F795_5702;
	R4478[256] = (char *(*)()) F796_5702;
	R4478[257] = (char *(*)()) F797_5702;
	R4478[362] = (char *(*)()) F902_6902;
	R4478[444] = (char *(*)()) F983_8223;
	R4478[446] = (char *(*)()) F985_8300;
	R4478[448] = (char *(*)()) F983_8223;
	R4478[449] = (char *(*)()) F985_8300;
	{long i; for (i = 524; i < 526; i++) R4478[i] = (char *(*)()) F1056_9233;}
	R4478[562] = (char *(*)()) F1056_9233;
	R4478[571] = (char *(*)()) F1056_9233;
}

char *(*R4480[572])();
void R4480_init () {
	R4480[0] = (char *(*)()) F540_4834;
	R4480[1] = (char *(*)()) F541_4834;
	R4480[2] = (char *(*)()) F542_4834;
	R4480[3] = (char *(*)()) F543_4834;
	R4480[4] = (char *(*)()) F544_4834;
	R4480[5] = (char *(*)()) F545_4834;
	R4480[6] = (char *(*)()) F546_4834;
	R4480[7] = (char *(*)()) F547_4834;
	R4480[8] = (char *(*)()) F548_4834;
	R4480[9] = (char *(*)()) F549_4834;
	R4480[10] = (char *(*)()) F550_4834;
	R4480[11] = (char *(*)()) F551_4834;
	R4480[61] = (char *(*)()) F553_4906;
	R4480[62] = (char *(*)()) F557_4906;
	R4480[63] = (char *(*)()) F556_4906;
	{long i; for (i = 64; i < 66; i++) R4480[i] = (char *(*)()) F553_4906;}
	R4480[66] = (char *(*)()) F556_4906;
	R4480[67] = (char *(*)()) F557_4906;
	R4480[70] = (char *(*)()) F610_5095;
	R4480[71] = (char *(*)()) F611_5095;
	R4480[72] = (char *(*)()) F612_5095;
	R4480[73] = (char *(*)()) F613_5095;
	R4480[74] = (char *(*)()) F614_5095;
	R4480[75] = (char *(*)()) F615_5095;
	R4480[76] = (char *(*)()) F610_5095;
	R4480[77] = (char *(*)()) F612_5095;
	R4480[78] = (char *(*)()) F610_5095;
	R4480[79] = (char *(*)()) F619_5215;
	R4480[80] = (char *(*)()) F620_5215;
	R4480[81] = (char *(*)()) F621_5215;
	R4480[82] = (char *(*)()) F622_5215;
	R4480[83] = (char *(*)()) F623_5215;
	R4480[84] = (char *(*)()) F624_5215;
	R4480[85] = (char *(*)()) F625_5215;
	R4480[86] = (char *(*)()) F626_5215;
	R4480[87] = (char *(*)()) F627_5215;
	R4480[88] = (char *(*)()) F628_5215;
	R4480[89] = (char *(*)()) F629_5215;
	R4480[90] = (char *(*)()) F630_5215;
	R4480[91] = (char *(*)()) F619_5215;
	R4480[92] = (char *(*)()) F625_5215;
	R4480[93] = (char *(*)()) F622_5215;
	{long i; for (i = 96; i < 99; i++) R4480[i] = (char *(*)()) F619_5215;}
	R4480[103] = (char *(*)()) F619_5215;
	R4480[106] = (char *(*)()) F619_5215;
	R4480[108] = (char *(*)()) F619_5215;
	R4480[111] = (char *(*)()) F619_5215;
	{long i; for (i = 113; i < 117; i++) R4480[i] = (char *(*)()) F619_5215;}
	R4480[119] = (char *(*)()) F619_5215;
	R4480[120] = (char *(*)()) F625_5215;
	R4480[121] = (char *(*)()) F619_5215;
	R4480[246] = (char *(*)()) F786_5707;
	R4480[247] = (char *(*)()) F787_5707;
	R4480[248] = (char *(*)()) F788_5707;
	R4480[249] = (char *(*)()) F789_5707;
	R4480[250] = (char *(*)()) F790_5707;
	R4480[251] = (char *(*)()) F791_5707;
	R4480[252] = (char *(*)()) F792_5707;
	R4480[253] = (char *(*)()) F793_5707;
	R4480[254] = (char *(*)()) F794_5707;
	R4480[255] = (char *(*)()) F795_5707;
	R4480[256] = (char *(*)()) F796_5707;
	R4480[257] = (char *(*)()) F797_5707;
	R4480[362] = (char *(*)()) F902_6900;
	R4480[444] = (char *(*)()) F981_8118;
	R4480[446] = (char *(*)()) F981_8118;
	{long i; for (i = 448; i < 450; i++) R4480[i] = (char *(*)()) F981_8118;}
	{long i; for (i = 524; i < 526; i++) R4480[i] = (char *(*)()) F553_4906;}
	R4480[562] = (char *(*)()) F553_4906;
	R4480[571] = (char *(*)()) F553_4906;
}

char *(*R4507[12])();
void R4507_init () {
	R4507[0] = (char *(*)()) F540_4817;
	R4507[1] = (char *(*)()) F541_4817;
	R4507[2] = (char *(*)()) F542_4817;
	R4507[3] = (char *(*)()) F543_4817;
	R4507[4] = (char *(*)()) F544_4817;
	R4507[5] = (char *(*)()) F545_4817;
	R4507[6] = (char *(*)()) F546_4817;
	R4507[7] = (char *(*)()) F547_4817;
	R4507[8] = (char *(*)()) F548_4817;
	R4507[9] = (char *(*)()) F549_4817;
	R4507[10] = (char *(*)()) F550_4817;
	R4507[11] = (char *(*)()) F551_4817;
}

char *(*R4564[511])();
void R4564_init () {
	R4564[0] = (char *(*)()) F601_4948;
	R4564[1] = (char *(*)()) F602_4948_4564_1;
	R4564[2] = (char *(*)()) F603_4948_4564_1;
	{long i; for (i = 3; i < 5; i++) R4564[i] = (char *(*)()) F601_4948;}
	R4564[5] = (char *(*)()) F603_4948_4564_1;
	R4564[6] = (char *(*)()) F602_4948_4564_1;
	R4564[18] = (char *(*)()) F619_5197;
	R4564[19] = (char *(*)()) F620_5197_4564_1;
	R4564[20] = (char *(*)()) F621_5197_4564_1;
	R4564[21] = (char *(*)()) F622_5197_4564_1;
	R4564[22] = (char *(*)()) F623_5197_4564_1;
	R4564[23] = (char *(*)()) F624_5197_4564_1;
	R4564[24] = (char *(*)()) F625_5197_4564_1;
	R4564[25] = (char *(*)()) F626_5197_4564_1;
	R4564[26] = (char *(*)()) F627_5197_4564_1;
	R4564[27] = (char *(*)()) F628_5197_4564_1;
	R4564[28] = (char *(*)()) F629_5197_4564_1;
	R4564[29] = (char *(*)()) F630_5197_4564_1;
	R4564[30] = (char *(*)()) F619_5197;
	R4564[31] = (char *(*)()) F625_5197_4564_1;
	R4564[32] = (char *(*)()) F622_5197_4564_1;
	{long i; for (i = 35; i < 38; i++) R4564[i] = (char *(*)()) F619_5197;}
	R4564[42] = (char *(*)()) F619_5197;
	R4564[45] = (char *(*)()) F619_5197;
	R4564[47] = (char *(*)()) F619_5197;
	R4564[50] = (char *(*)()) F619_5197;
	{long i; for (i = 52; i < 56; i++) R4564[i] = (char *(*)()) F619_5197;}
	R4564[58] = (char *(*)()) F619_5197;
	R4564[59] = (char *(*)()) F625_5197_4564_1;
	R4564[60] = (char *(*)()) F619_5197;
	{long i; for (i = 463; i < 465; i++) R4564[i] = (char *(*)()) F553_4895;}
	R4564[501] = (char *(*)()) F553_4895;
	R4564[510] = (char *(*)()) F553_4895;
}
static EIF_REFERENCE F602_4948_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F602_4948(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_4948_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_4948(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F620_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5197_4564_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5197(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4565[7])();
void R4565_init () {
	R4565[0] = (char *(*)()) F601_4967;
	R4565[1] = (char *(*)()) F602_4967;
	R4565[2] = (char *(*)()) F603_4967;
	{long i; for (i = 3; i < 5; i++) R4565[i] = (char *(*)()) F601_4967;}
	R4565[5] = (char *(*)()) F603_4967;
	R4565[6] = (char *(*)()) F602_4967;
}

char *(*R4566[511])();
void R4566_init () {
	R4566[0] = (char *(*)()) F601_4968;
	R4566[1] = (char *(*)()) F602_4968;
	R4566[2] = (char *(*)()) F603_4968;
	{long i; for (i = 3; i < 5; i++) R4566[i] = (char *(*)()) F601_4968;}
	R4566[5] = (char *(*)()) F603_4968;
	R4566[6] = (char *(*)()) F602_4968;
	R4566[18] = (char *(*)()) F619_5223;
	R4566[19] = (char *(*)()) F620_5223;
	R4566[20] = (char *(*)()) F621_5223;
	R4566[21] = (char *(*)()) F622_5223;
	R4566[22] = (char *(*)()) F623_5223;
	R4566[23] = (char *(*)()) F624_5223;
	R4566[24] = (char *(*)()) F625_5223;
	R4566[25] = (char *(*)()) F626_5223;
	R4566[26] = (char *(*)()) F627_5223;
	R4566[27] = (char *(*)()) F628_5223;
	R4566[28] = (char *(*)()) F629_5223;
	R4566[29] = (char *(*)()) F630_5223;
	R4566[30] = (char *(*)()) F619_5223;
	R4566[31] = (char *(*)()) F625_5223;
	R4566[32] = (char *(*)()) F622_5223;
	{long i; for (i = 35; i < 38; i++) R4566[i] = (char *(*)()) F619_5223;}
	R4566[42] = (char *(*)()) F619_5223;
	R4566[45] = (char *(*)()) F619_5223;
	R4566[47] = (char *(*)()) F619_5223;
	R4566[50] = (char *(*)()) F619_5223;
	{long i; for (i = 52; i < 56; i++) R4566[i] = (char *(*)()) F619_5223;}
	R4566[58] = (char *(*)()) F619_5223;
	R4566[59] = (char *(*)()) F625_5223;
	R4566[60] = (char *(*)()) F619_5223;
	{long i; for (i = 463; i < 465; i++) R4566[i] = (char *(*)()) F1056_9239;}
	R4566[501] = (char *(*)()) F1056_9239;
	R4566[510] = (char *(*)()) F1056_9239;
}

char *(*R4567[511])();
void R4567_init () {
	R4567[0] = (char *(*)()) F601_4958;
	R4567[1] = (char *(*)()) F602_4958;
	R4567[2] = (char *(*)()) F603_4958;
	{long i; for (i = 3; i < 5; i++) R4567[i] = (char *(*)()) F601_4958;}
	R4567[5] = (char *(*)()) F603_4958;
	R4567[6] = (char *(*)()) F602_4958;
	R4567[18] = (char *(*)()) F553_4907;
	R4567[19] = (char *(*)()) F554_4907;
	R4567[20] = (char *(*)()) F555_4907;
	R4567[21] = (char *(*)()) F556_4907;
	R4567[22] = (char *(*)()) F558_4907;
	R4567[23] = (char *(*)()) F559_4907;
	R4567[24] = (char *(*)()) F557_4907;
	R4567[25] = (char *(*)()) F560_4907;
	R4567[26] = (char *(*)()) F561_4907;
	R4567[27] = (char *(*)()) F562_4907;
	R4567[28] = (char *(*)()) F563_4907;
	R4567[29] = (char *(*)()) F564_4907;
	R4567[30] = (char *(*)()) F553_4907;
	R4567[31] = (char *(*)()) F557_4907;
	R4567[32] = (char *(*)()) F556_4907;
	{long i; for (i = 35; i < 38; i++) R4567[i] = (char *(*)()) F553_4907;}
	R4567[42] = (char *(*)()) F553_4907;
	R4567[45] = (char *(*)()) F553_4907;
	R4567[47] = (char *(*)()) F553_4907;
	R4567[50] = (char *(*)()) F553_4907;
	{long i; for (i = 52; i < 56; i++) R4567[i] = (char *(*)()) F553_4907;}
	R4567[58] = (char *(*)()) F553_4907;
	R4567[59] = (char *(*)()) F557_4907;
	R4567[60] = (char *(*)()) F553_4907;
	{long i; for (i = 463; i < 465; i++) R4567[i] = (char *(*)()) F553_4907;}
	R4567[501] = (char *(*)()) F553_4907;
	R4567[510] = (char *(*)()) F553_4907;
}

char *(*R4568[7])();
void R4568_init () {
	R4568[0] = (char *(*)()) F601_4959;
	R4568[1] = (char *(*)()) F602_4959;
	R4568[2] = (char *(*)()) F603_4959;
	{long i; for (i = 3; i < 5; i++) R4568[i] = (char *(*)()) F601_4959;}
	R4568[5] = (char *(*)()) F603_4959;
	R4568[6] = (char *(*)()) F602_4959;
}

char *(*R4573[7])();
void R4573_init () {
	R4573[0] = (char *(*)()) F601_4970;
	R4573[1] = (char *(*)()) F602_4970_4573_4;
	R4573[2] = (char *(*)()) F603_4970_4573_4;
	{long i; for (i = 3; i < 5; i++) R4573[i] = (char *(*)()) F601_4970;}
	R4573[5] = (char *(*)()) F603_4970_4573_4;
	R4573[6] = (char *(*)()) F602_4970_4573_4;
}
static void F602_4970_4573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F602_4970(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F603_4970_4573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F603_4970(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4574[43])();
void R4574_init () {
	R4574[0] = (char *(*)()) F619_5230;
	R4574[1] = (char *(*)()) F620_5230_4574_4;
	R4574[2] = (char *(*)()) F621_5230_4574_4;
	R4574[3] = (char *(*)()) F622_5230_4574_4;
	R4574[4] = (char *(*)()) F623_5230_4574_4;
	R4574[5] = (char *(*)()) F624_5230_4574_4;
	R4574[6] = (char *(*)()) F625_5230_4574_4;
	R4574[7] = (char *(*)()) F626_5230_4574_4;
	R4574[8] = (char *(*)()) F627_5230_4574_4;
	R4574[9] = (char *(*)()) F628_5230_4574_4;
	R4574[10] = (char *(*)()) F629_5230_4574_4;
	R4574[11] = (char *(*)()) F630_5230_4574_4;
	R4574[12] = (char *(*)()) F619_5230;
	R4574[13] = (char *(*)()) F625_5230_4574_4;
	R4574[14] = (char *(*)()) F622_5230_4574_4;
	{long i; for (i = 17; i < 20; i++) R4574[i] = (char *(*)()) F634_5273;}
	R4574[24] = (char *(*)()) F634_5273;
	R4574[27] = (char *(*)()) F634_5273;
	R4574[29] = (char *(*)()) F634_5273;
	R4574[32] = (char *(*)()) F634_5273;
	{long i; for (i = 34; i < 38; i++) R4574[i] = (char *(*)()) F634_5273;}
	R4574[40] = (char *(*)()) F634_5273;
	R4574[41] = (char *(*)()) F635_5273_4574_4;
	R4574[42] = (char *(*)()) F634_5273;
}
static void F620_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5230(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5230(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5230(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5230(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5230(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5230(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5230(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5230(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5230(Current, *(EIF_POINTER *)arg1);
}
static void F629_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5230(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5230_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5230(Current, *(EIF_REAL_64 *)arg1);
}
static void F635_5273_4574_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F635_5273(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4579[7])();
void R4579_init () {
	R4579[0] = (char *(*)()) F601_4979;
	R4579[1] = (char *(*)()) F602_4979;
	R4579[2] = (char *(*)()) F603_4979;
	{long i; for (i = 3; i < 5; i++) R4579[i] = (char *(*)()) F601_4979;}
	R4579[5] = (char *(*)()) F603_4979;
	R4579[6] = (char *(*)()) F602_4979;
}

char *(*R4584[7])();
void R4584_init () {
	R4584[0] = (char *(*)()) F601_4983;
	R4584[1] = (char *(*)()) F602_4983_4584_5;
	R4584[2] = (char *(*)()) F603_4983_4584_5;
	{long i; for (i = 3; i < 5; i++) R4584[i] = (char *(*)()) F601_4983;}
	R4584[5] = (char *(*)()) F603_4983_4584_5;
	R4584[6] = (char *(*)()) F602_4983_4584_5;
}
static EIF_REFERENCE F602_4983_4584_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F602_4983(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F603_4983_4584_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F603_4983(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4585[7])();
void R4585_init () {
	R4585[0] = (char *(*)()) F601_4984;
	R4585[1] = (char *(*)()) F602_4984;
	R4585[2] = (char *(*)()) F603_4984;
	{long i; for (i = 3; i < 5; i++) R4585[i] = (char *(*)()) F601_4984;}
	R4585[5] = (char *(*)()) F603_4984;
	R4585[6] = (char *(*)()) F602_4984;
}

char *(*R4588[7])();
void R4588_init () {
	R4588[0] = (char *(*)()) F601_4987;
	R4588[1] = (char *(*)()) F602_4987;
	R4588[2] = (char *(*)()) F603_4987;
	{long i; for (i = 3; i < 5; i++) R4588[i] = (char *(*)()) F601_4987;}
	R4588[5] = (char *(*)()) F603_4987;
	R4588[6] = (char *(*)()) F602_4987;
}

char *(*R4589[7])();
void R4589_init () {
	R4589[0] = (char *(*)()) F601_4988;
	R4589[1] = (char *(*)()) F602_4988;
	R4589[2] = (char *(*)()) F603_4988;
	{long i; for (i = 3; i < 5; i++) R4589[i] = (char *(*)()) F601_4988;}
	R4589[5] = (char *(*)()) F603_4988;
	R4589[6] = (char *(*)()) F602_4988;
}

char *(*R4590[7])();
void R4590_init () {
	R4590[0] = (char *(*)()) F601_4989;
	R4590[1] = (char *(*)()) F602_4989;
	R4590[2] = (char *(*)()) F603_4989;
	{long i; for (i = 3; i < 5; i++) R4590[i] = (char *(*)()) F601_4989;}
	R4590[5] = (char *(*)()) F603_4989;
	R4590[6] = (char *(*)()) F602_4989;
}

char *(*R4600[3])();
void R4600_init () {
	R4600[0] = (char *(*)()) F601_4946;
	R4600[1] = (char *(*)()) F603_4946_4600_1;
	R4600[2] = (char *(*)()) F602_4946_4600_1;
}
static EIF_REFERENCE F603_4946_4600_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F602_4946_4600_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F602_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4601[3])();
void R4601_init () {
	R4601[0] = (char *(*)()) F601_4977;
	R4601[1] = (char *(*)()) F603_4977;
	R4601[2] = (char *(*)()) F602_4977;
}

char *(*R4602[380])();
void R4602_init () {
	R4602[0] = (char *(*)()) F610_5116;
	R4602[1] = (char *(*)()) F611_5116;
	R4602[2] = (char *(*)()) F612_5116;
	R4602[3] = (char *(*)()) F613_5116;
	R4602[4] = (char *(*)()) F614_5116;
	R4602[5] = (char *(*)()) F615_5116;
	R4602[6] = (char *(*)()) F610_5116;
	R4602[7] = (char *(*)()) F612_5116;
	R4602[8] = (char *(*)()) F610_5116;
	R4602[9] = (char *(*)()) F619_5249;
	R4602[10] = (char *(*)()) F620_5249;
	R4602[11] = (char *(*)()) F621_5249;
	R4602[12] = (char *(*)()) F622_5249;
	R4602[13] = (char *(*)()) F623_5249;
	R4602[14] = (char *(*)()) F624_5249;
	R4602[15] = (char *(*)()) F625_5249;
	R4602[16] = (char *(*)()) F626_5249;
	R4602[17] = (char *(*)()) F627_5249;
	R4602[18] = (char *(*)()) F628_5249;
	R4602[19] = (char *(*)()) F629_5249;
	R4602[20] = (char *(*)()) F630_5249;
	R4602[21] = (char *(*)()) F619_5249;
	R4602[22] = (char *(*)()) F625_5249;
	R4602[23] = (char *(*)()) F622_5249;
	{long i; for (i = 26; i < 29; i++) R4602[i] = (char *(*)()) F619_5249;}
	R4602[33] = (char *(*)()) F619_5249;
	R4602[36] = (char *(*)()) F619_5249;
	R4602[38] = (char *(*)()) F619_5249;
	R4602[41] = (char *(*)()) F619_5249;
	{long i; for (i = 43; i < 47; i++) R4602[i] = (char *(*)()) F619_5249;}
	R4602[49] = (char *(*)()) F619_5249;
	R4602[50] = (char *(*)()) F625_5249;
	R4602[51] = (char *(*)()) F619_5249;
	R4602[292] = (char *(*)()) F902_6981;
	{long i; for (i = 366; i < 371; i++) R4602[i] = (char *(*)()) F975_8072;}
	R4602[374] = (char *(*)()) F984_8277;
	R4602[378] = (char *(*)()) F988_8476;
	R4602[379] = (char *(*)()) F989_8566;
}


#ifdef __cplusplus
}
#endif
