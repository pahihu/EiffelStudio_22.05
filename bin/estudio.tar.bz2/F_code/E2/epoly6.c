#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4420[687])();
void R4420_init () {
	R4420[0] = (char *(*)()) F601_4965;
	R4420[1] = (char *(*)()) F602_4965;
	R4420[2] = (char *(*)()) F603_4965;
	{long i; for (i = 3; i < 5; i++) R4420[i] = (char *(*)()) F601_4965;}
	R4420[5] = (char *(*)()) F603_4965;
	R4420[6] = (char *(*)()) F602_4965;
	R4420[18] = (char *(*)()) F619_5221;
	R4420[19] = (char *(*)()) F620_5221;
	R4420[20] = (char *(*)()) F621_5221;
	R4420[21] = (char *(*)()) F622_5221;
	R4420[22] = (char *(*)()) F623_5221;
	R4420[23] = (char *(*)()) F624_5221;
	R4420[24] = (char *(*)()) F625_5221;
	R4420[25] = (char *(*)()) F626_5221;
	R4420[26] = (char *(*)()) F627_5221;
	R4420[27] = (char *(*)()) F628_5221;
	R4420[28] = (char *(*)()) F629_5221;
	R4420[29] = (char *(*)()) F630_5221;
	R4420[30] = (char *(*)()) F619_5221;
	R4420[31] = (char *(*)()) F625_5221;
	R4420[32] = (char *(*)()) F622_5221;
	{long i; for (i = 35; i < 38; i++) R4420[i] = (char *(*)()) F619_5221;}
	R4420[42] = (char *(*)()) F619_5221;
	R4420[45] = (char *(*)()) F619_5221;
	R4420[47] = (char *(*)()) F619_5221;
	R4420[50] = (char *(*)()) F619_5221;
	{long i; for (i = 52; i < 56; i++) R4420[i] = (char *(*)()) F619_5221;}
	R4420[58] = (char *(*)()) F619_5221;
	R4420[59] = (char *(*)()) F625_5221;
	R4420[60] = (char *(*)()) F619_5221;
	R4420[78] = (char *(*)()) F444_4687;
	R4420[257] = (char *(*)()) F857_6314;
	{long i; for (i = 463; i < 465; i++) R4420[i] = (char *(*)()) F1056_9238;}
	R4420[501] = (char *(*)()) F1056_9238;
	R4420[510] = (char *(*)()) F1056_9238;
	R4420[686] = (char *(*)()) F857_6314;
}

char *(*R4421[687])();
void R4421_init () {
	R4421[0] = (char *(*)()) F601_4956;
	R4421[1] = (char *(*)()) F602_4956;
	R4421[2] = (char *(*)()) F603_4956;
	{long i; for (i = 3; i < 5; i++) R4421[i] = (char *(*)()) F601_4956;}
	R4421[5] = (char *(*)()) F603_4956;
	R4421[6] = (char *(*)()) F602_4956;
	R4421[18] = (char *(*)()) F577_4934;
	R4421[19] = (char *(*)()) F578_4934;
	R4421[20] = (char *(*)()) F579_4934;
	R4421[21] = (char *(*)()) F580_4934;
	R4421[22] = (char *(*)()) F582_4934;
	R4421[23] = (char *(*)()) F583_4934;
	R4421[24] = (char *(*)()) F581_4934;
	R4421[25] = (char *(*)()) F584_4934;
	R4421[26] = (char *(*)()) F585_4934;
	R4421[27] = (char *(*)()) F586_4934;
	R4421[28] = (char *(*)()) F587_4934;
	R4421[29] = (char *(*)()) F588_4934;
	R4421[30] = (char *(*)()) F577_4934;
	R4421[31] = (char *(*)()) F581_4934;
	R4421[32] = (char *(*)()) F580_4934;
	{long i; for (i = 35; i < 38; i++) R4421[i] = (char *(*)()) F577_4934;}
	R4421[42] = (char *(*)()) F577_4934;
	R4421[45] = (char *(*)()) F577_4934;
	R4421[47] = (char *(*)()) F577_4934;
	R4421[50] = (char *(*)()) F577_4934;
	{long i; for (i = 52; i < 56; i++) R4421[i] = (char *(*)()) F577_4934;}
	R4421[58] = (char *(*)()) F577_4934;
	R4421[59] = (char *(*)()) F581_4934;
	R4421[60] = (char *(*)()) F577_4934;
	R4421[257] = (char *(*)()) F857_6256;
	{long i; for (i = 463; i < 465; i++) R4421[i] = (char *(*)()) F577_4934;}
	R4421[501] = (char *(*)()) F577_4934;
	R4421[510] = (char *(*)()) F577_4934;
	R4421[686] = (char *(*)()) F857_6256;
}

char *(*R4422[669])();
void R4422_init () {
	R4422[0] = (char *(*)()) F619_5222;
	R4422[1] = (char *(*)()) F620_5222;
	R4422[2] = (char *(*)()) F621_5222;
	R4422[3] = (char *(*)()) F622_5222;
	R4422[4] = (char *(*)()) F623_5222;
	R4422[5] = (char *(*)()) F624_5222;
	R4422[6] = (char *(*)()) F625_5222;
	R4422[7] = (char *(*)()) F626_5222;
	R4422[8] = (char *(*)()) F627_5222;
	R4422[9] = (char *(*)()) F628_5222;
	R4422[10] = (char *(*)()) F629_5222;
	R4422[11] = (char *(*)()) F630_5222;
	R4422[12] = (char *(*)()) F619_5222;
	R4422[13] = (char *(*)()) F625_5222;
	R4422[14] = (char *(*)()) F622_5222;
	{long i; for (i = 17; i < 20; i++) R4422[i] = (char *(*)()) F619_5222;}
	R4422[24] = (char *(*)()) F619_5222;
	R4422[27] = (char *(*)()) F619_5222;
	R4422[29] = (char *(*)()) F619_5222;
	R4422[32] = (char *(*)()) F619_5222;
	{long i; for (i = 34; i < 38; i++) R4422[i] = (char *(*)()) F619_5222;}
	R4422[40] = (char *(*)()) F619_5222;
	R4422[41] = (char *(*)()) F625_5222;
	R4422[42] = (char *(*)()) F619_5222;
	R4422[239] = (char *(*)()) F857_6315;
	{long i; for (i = 445; i < 447; i++) R4422[i] = (char *(*)()) F1056_9237;}
	R4422[483] = (char *(*)()) F1056_9237;
	R4422[492] = (char *(*)()) F1056_9237;
	R4422[668] = (char *(*)()) F1287_13084;
}

char *(*R4423[511])();
void R4423_init () {
	R4423[0] = (char *(*)()) F565_4918;
	R4423[1] = (char *(*)()) F569_4918;
	R4423[2] = (char *(*)()) F568_4918;
	{long i; for (i = 3; i < 5; i++) R4423[i] = (char *(*)()) F565_4918;}
	R4423[5] = (char *(*)()) F568_4918;
	R4423[6] = (char *(*)()) F569_4918;
	R4423[18] = (char *(*)()) F565_4918;
	R4423[19] = (char *(*)()) F566_4918;
	R4423[20] = (char *(*)()) F567_4918;
	R4423[21] = (char *(*)()) F568_4918;
	R4423[22] = (char *(*)()) F570_4918;
	R4423[23] = (char *(*)()) F571_4918;
	R4423[24] = (char *(*)()) F569_4918;
	R4423[25] = (char *(*)()) F572_4918;
	R4423[26] = (char *(*)()) F573_4918;
	R4423[27] = (char *(*)()) F574_4918;
	R4423[28] = (char *(*)()) F575_4918;
	R4423[29] = (char *(*)()) F576_4918;
	R4423[30] = (char *(*)()) F565_4918;
	R4423[31] = (char *(*)()) F569_4918;
	R4423[32] = (char *(*)()) F568_4918;
	{long i; for (i = 35; i < 38; i++) R4423[i] = (char *(*)()) F565_4918;}
	R4423[42] = (char *(*)()) F565_4918;
	R4423[45] = (char *(*)()) F565_4918;
	R4423[47] = (char *(*)()) F565_4918;
	R4423[50] = (char *(*)()) F565_4918;
	{long i; for (i = 52; i < 56; i++) R4423[i] = (char *(*)()) F565_4918;}
	R4423[58] = (char *(*)()) F565_4918;
	R4423[59] = (char *(*)()) F569_4918;
	R4423[60] = (char *(*)()) F565_4918;
	{long i; for (i = 463; i < 465; i++) R4423[i] = (char *(*)()) F565_4918;}
	R4423[501] = (char *(*)()) F565_4918;
	R4423[510] = (char *(*)()) F565_4918;
}

char *(*R4424[511])();
void R4424_init () {
	R4424[0] = (char *(*)()) F391_4664;
	R4424[1] = (char *(*)()) F396_4664;
	R4424[2] = (char *(*)()) F394_4664;
	{long i; for (i = 3; i < 5; i++) R4424[i] = (char *(*)()) F391_4664;}
	R4424[5] = (char *(*)()) F394_4664;
	R4424[6] = (char *(*)()) F396_4664;
	R4424[9] = (char *(*)()) F390_4664;
	R4424[10] = (char *(*)()) F391_4664;
	R4424[11] = (char *(*)()) F395_4664;
	R4424[12] = (char *(*)()) F396_4664;
	R4424[13] = (char *(*)()) F401_4664;
	R4424[14] = (char *(*)()) F405_4664;
	R4424[15] = (char *(*)()) F390_4664;
	R4424[16] = (char *(*)()) F395_4664;
	R4424[17] = (char *(*)()) F390_4664;
	R4424[387] = (char *(*)()) F400_4664;
	R4424[388] = (char *(*)()) F393_4664;
	{long i; for (i = 463; i < 465; i++) R4424[i] = (char *(*)()) F391_4664;}
	{long i; for (i = 465; i < 467; i++) R4424[i] = (char *(*)()) F1066_9401;}
	{long i; for (i = 468; i < 470; i++) R4424[i] = (char *(*)()) F1066_9401;}
	{long i; for (i = 471; i < 473; i++) R4424[i] = (char *(*)()) F1066_9401;}
	R4424[474] = (char *(*)()) F1066_9401;
	R4424[476] = (char *(*)()) F1066_9401;
	R4424[501] = (char *(*)()) F391_4664;
	R4424[510] = (char *(*)()) F391_4664;
}

char *(*R4426[29])();
void R4426_init () {
	R4426[0] = (char *(*)()) F605_5013;
	R4426[1] = (char *(*)()) F606_5013_4426_4;
	R4426[2] = (char *(*)()) F607_5013_4426_4;
	R4426[26] = (char *(*)()) F631_5256;
	R4426[27] = (char *(*)()) F632_5256_4426_4;
	R4426[28] = (char *(*)()) F633_5256_4426_4;
}
static void F606_5013_4426_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F606_5013(Current, *(EIF_BOOLEAN *)arg1);
}
static void F607_5013_4426_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F607_5013(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F632_5256_4426_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F632_5256(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F633_5256_4426_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F633_5256(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4427[687])();
void R4427_init () {
	R4427[0] = (char *(*)()) F601_4971;
	R4427[1] = (char *(*)()) F602_4971_4427_4;
	R4427[2] = (char *(*)()) F603_4971_4427_4;
	R4427[3] = (char *(*)()) F604_4994;
	R4427[4] = (char *(*)()) F605_5012;
	R4427[5] = (char *(*)()) F606_5012_4427_4;
	R4427[6] = (char *(*)()) F607_5012_4427_4;
	R4427[18] = (char *(*)()) F619_5229;
	R4427[19] = (char *(*)()) F620_5229_4427_4;
	R4427[20] = (char *(*)()) F621_5229_4427_4;
	R4427[21] = (char *(*)()) F622_5229_4427_4;
	R4427[22] = (char *(*)()) F623_5229_4427_4;
	R4427[23] = (char *(*)()) F624_5229_4427_4;
	R4427[24] = (char *(*)()) F625_5229_4427_4;
	R4427[25] = (char *(*)()) F626_5229_4427_4;
	R4427[26] = (char *(*)()) F627_5229_4427_4;
	R4427[27] = (char *(*)()) F628_5229_4427_4;
	R4427[28] = (char *(*)()) F629_5229_4427_4;
	R4427[29] = (char *(*)()) F630_5229_4427_4;
	R4427[30] = (char *(*)()) F631_5255;
	R4427[31] = (char *(*)()) F632_5255_4427_4;
	R4427[32] = (char *(*)()) F633_5255_4427_4;
	{long i; for (i = 35; i < 38; i++) R4427[i] = (char *(*)()) F634_5271;}
	R4427[42] = (char *(*)()) F634_5271;
	R4427[45] = (char *(*)()) F634_5271;
	R4427[47] = (char *(*)()) F634_5271;
	R4427[50] = (char *(*)()) F634_5271;
	{long i; for (i = 52; i < 56; i++) R4427[i] = (char *(*)()) F634_5271;}
	R4427[58] = (char *(*)()) F634_5271;
	R4427[59] = (char *(*)()) F635_5271_4427_4;
	R4427[60] = (char *(*)()) F634_5271;
	R4427[257] = (char *(*)()) F857_6321_4427_4;
	R4427[387] = (char *(*)()) F988_8439_4427_4;
	R4427[388] = (char *(*)()) F989_8530_4427_4;
	{long i; for (i = 463; i < 467; i++) R4427[i] = (char *(*)()) F1059_9343;}
	{long i; for (i = 468; i < 470; i++) R4427[i] = (char *(*)()) F1059_9343;}
	{long i; for (i = 471; i < 473; i++) R4427[i] = (char *(*)()) F1059_9343;}
	R4427[474] = (char *(*)()) F1059_9343;
	R4427[476] = (char *(*)()) F1059_9343;
	R4427[501] = (char *(*)()) F1056_9262;
	R4427[510] = (char *(*)()) F1056_9262;
	R4427[686] = (char *(*)()) F857_6321_4427_4;
}
static void F602_4971_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F602_4971(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F603_4971_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F603_4971(Current, *(EIF_BOOLEAN *)arg1);
}
static void F606_5012_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F606_5012(Current, *(EIF_BOOLEAN *)arg1);
}
static void F607_5012_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F607_5012(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F620_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5229(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5229(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5229(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5229(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5229(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5229(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5229(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5229(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5229(Current, *(EIF_POINTER *)arg1);
}
static void F629_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5229(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5229_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5229(Current, *(EIF_REAL_64 *)arg1);
}
static void F632_5255_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F632_5255(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F633_5255_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F633_5255(Current, *(EIF_BOOLEAN *)arg1);
}
static void F635_5271_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F635_5271(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F857_6321_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6321(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F988_8439_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F988_8439(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F989_8530_4427_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F989_8530(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4428[511])();
void R4428_init () {
	R4428[0] = (char *(*)()) F553_4914;
	R4428[1] = (char *(*)()) F557_4914;
	R4428[2] = (char *(*)()) F556_4914;
	R4428[4] = (char *(*)()) F498_4757;
	R4428[5] = (char *(*)()) F500_4757;
	R4428[6] = (char *(*)()) F499_4757;
	R4428[18] = (char *(*)()) F553_4914;
	R4428[19] = (char *(*)()) F554_4914;
	R4428[20] = (char *(*)()) F555_4914;
	R4428[21] = (char *(*)()) F556_4914;
	R4428[22] = (char *(*)()) F558_4914;
	R4428[23] = (char *(*)()) F559_4914;
	R4428[24] = (char *(*)()) F557_4914;
	R4428[25] = (char *(*)()) F560_4914;
	R4428[26] = (char *(*)()) F561_4914;
	R4428[27] = (char *(*)()) F562_4914;
	R4428[28] = (char *(*)()) F563_4914;
	R4428[29] = (char *(*)()) F564_4914;
	R4428[30] = (char *(*)()) F498_4757;
	R4428[31] = (char *(*)()) F499_4757;
	R4428[32] = (char *(*)()) F500_4757;
	{long i; for (i = 35; i < 38; i++) R4428[i] = (char *(*)()) F553_4914;}
	R4428[42] = (char *(*)()) F553_4914;
	R4428[45] = (char *(*)()) F553_4914;
	R4428[47] = (char *(*)()) F553_4914;
	R4428[50] = (char *(*)()) F553_4914;
	{long i; for (i = 52; i < 56; i++) R4428[i] = (char *(*)()) F553_4914;}
	R4428[58] = (char *(*)()) F553_4914;
	R4428[59] = (char *(*)()) F557_4914;
	R4428[60] = (char *(*)()) F553_4914;
	{long i; for (i = 463; i < 465; i++) R4428[i] = (char *(*)()) F553_4914;}
	R4428[501] = (char *(*)()) F553_4914;
	R4428[510] = (char *(*)()) F553_4914;
}

char *(*R4429[748])();
void R4429_init () {
	R4429[0] = (char *(*)()) F540_4869;
	R4429[1] = (char *(*)()) F541_4869_4429_4;
	R4429[2] = (char *(*)()) F542_4869_4429_4;
	R4429[3] = (char *(*)()) F543_4869_4429_4;
	R4429[4] = (char *(*)()) F544_4869_4429_4;
	R4429[5] = (char *(*)()) F545_4869_4429_4;
	R4429[6] = (char *(*)()) F546_4869_4429_4;
	R4429[7] = (char *(*)()) F547_4869_4429_4;
	R4429[8] = (char *(*)()) F548_4869_4429_4;
	R4429[9] = (char *(*)()) F549_4869_4429_4;
	R4429[10] = (char *(*)()) F550_4869_4429_4;
	R4429[11] = (char *(*)()) F551_4869_4429_4;
	R4429[61] = (char *(*)()) F565_4924;
	R4429[62] = (char *(*)()) F569_4924_4429_4;
	R4429[63] = (char *(*)()) F568_4924_4429_4;
	R4429[64] = (char *(*)()) F604_4999;
	R4429[65] = (char *(*)()) F565_4924;
	R4429[66] = (char *(*)()) F568_4924_4429_4;
	R4429[67] = (char *(*)()) F569_4924_4429_4;
	R4429[70] = (char *(*)()) F610_5110;
	R4429[71] = (char *(*)()) F611_5110;
	R4429[72] = (char *(*)()) F612_5110_4429_4;
	R4429[73] = (char *(*)()) F613_5110_4429_4;
	R4429[74] = (char *(*)()) F614_5110_4429_4;
	R4429[75] = (char *(*)()) F615_5110_4429_4;
	R4429[76] = (char *(*)()) F610_5110;
	R4429[77] = (char *(*)()) F612_5110_4429_4;
	R4429[78] = (char *(*)()) F610_5110;
	R4429[79] = (char *(*)()) F619_5241;
	R4429[80] = (char *(*)()) F620_5241_4429_4;
	R4429[81] = (char *(*)()) F621_5241_4429_4;
	R4429[82] = (char *(*)()) F622_5241_4429_4;
	R4429[83] = (char *(*)()) F623_5241_4429_4;
	R4429[84] = (char *(*)()) F624_5241_4429_4;
	R4429[85] = (char *(*)()) F625_5241_4429_4;
	R4429[86] = (char *(*)()) F626_5241_4429_4;
	R4429[87] = (char *(*)()) F627_5241_4429_4;
	R4429[88] = (char *(*)()) F628_5241_4429_4;
	R4429[89] = (char *(*)()) F629_5241_4429_4;
	R4429[90] = (char *(*)()) F630_5241_4429_4;
	R4429[91] = (char *(*)()) F619_5241;
	R4429[92] = (char *(*)()) F625_5241_4429_4;
	R4429[93] = (char *(*)()) F622_5241_4429_4;
	{long i; for (i = 96; i < 99; i++) R4429[i] = (char *(*)()) F636_5305;}
	R4429[103] = (char *(*)()) F636_5305;
	R4429[106] = (char *(*)()) F636_5305;
	R4429[108] = (char *(*)()) F636_5305;
	R4429[111] = (char *(*)()) F636_5305;
	{long i; for (i = 113; i < 117; i++) R4429[i] = (char *(*)()) F636_5305;}
	R4429[119] = (char *(*)()) F619_5241;
	R4429[120] = (char *(*)()) F625_5241_4429_4;
	R4429[121] = (char *(*)()) F619_5241;
	R4429[139] = (char *(*)()) F444_4692_4429_4;
	R4429[318] = (char *(*)()) F857_6442_4429_4;
	R4429[448] = (char *(*)()) F988_8450_4429_4;
	R4429[449] = (char *(*)()) F989_8541_4429_4;
	{long i; for (i = 524; i < 528; i++) R4429[i] = (char *(*)()) F1059_9344;}
	{long i; for (i = 529; i < 531; i++) R4429[i] = (char *(*)()) F1059_9344;}
	{long i; for (i = 532; i < 534; i++) R4429[i] = (char *(*)()) F1059_9344;}
	R4429[535] = (char *(*)()) F1059_9344;
	R4429[537] = (char *(*)()) F1059_9344;
	R4429[562] = (char *(*)()) F565_4924;
	R4429[571] = (char *(*)()) F565_4924;
	R4429[747] = (char *(*)()) F857_6442_4429_4;
}
static void F541_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F541_4869(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F542_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F542_4869(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F543_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F543_4869(Current, *(EIF_BOOLEAN *)arg1);
}
static void F544_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F544_4869(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F545_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F545_4869(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F546_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F546_4869(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F547_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F547_4869(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F548_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F548_4869(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F549_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F549_4869(Current, *(EIF_POINTER *)arg1);
}
static void F550_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F550_4869(Current, *(EIF_REAL_32 *)arg1);
}
static void F551_4869_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F551_4869(Current, *(EIF_REAL_64 *)arg1);
}
static void F569_4924_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F569_4924(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F568_4924_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F568_4924(Current, *(EIF_BOOLEAN *)arg1);
}
static void F612_5110_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F612_5110(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F613_5110_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_5110(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F614_5110_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F614_5110(Current, *(EIF_POINTER *)arg1);
}
static void F615_5110_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F615_5110(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F620_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_5241(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F621_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_5241(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F622_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5241(Current, *(EIF_BOOLEAN *)arg1);
}
static void F623_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_5241(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F624_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_5241(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5241(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_5241(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F627_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_5241(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F628_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_5241(Current, *(EIF_POINTER *)arg1);
}
static void F629_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_5241(Current, *(EIF_REAL_32 *)arg1);
}
static void F630_5241_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F630_5241(Current, *(EIF_REAL_64 *)arg1);
}
static void F444_4692_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F444_4692(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F857_6442_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6442(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F988_8450_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F988_8450(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F989_8541_4429_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F989_8541(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4430[572])();
void R4430_init () {
	R4430[0] = (char *(*)()) F349_4649;
	R4430[1] = (char *(*)()) F350_4649_4430_4;
	R4430[2] = (char *(*)()) F351_4649_4430_4;
	R4430[3] = (char *(*)()) F353_4649_4430_4;
	R4430[4] = (char *(*)()) F354_4649_4430_4;
	R4430[5] = (char *(*)()) F355_4649_4430_4;
	R4430[6] = (char *(*)()) F352_4649_4430_4;
	R4430[7] = (char *(*)()) F357_4649_4430_4;
	R4430[8] = (char *(*)()) F356_4649_4430_4;
	R4430[9] = (char *(*)()) F358_4649_4430_4;
	R4430[10] = (char *(*)()) F359_4649_4430_4;
	R4430[11] = (char *(*)()) F360_4649_4430_4;
	R4430[61] = (char *(*)()) F565_4925;
	R4430[62] = (char *(*)()) F569_4925_4430_4;
	R4430[63] = (char *(*)()) F568_4925_4430_4;
	R4430[64] = (char *(*)()) F604_5000;
	R4430[65] = (char *(*)()) F349_4649;
	R4430[66] = (char *(*)()) F353_4649_4430_4;
	R4430[67] = (char *(*)()) F352_4649_4430_4;
	{long i; for (i = 70; i < 72; i++) R4430[i] = (char *(*)()) F349_4649;}
	{long i; for (i = 72; i < 74; i++) R4430[i] = (char *(*)()) F352_4649_4430_4;}
	R4430[74] = (char *(*)()) F358_4649_4430_4;
	R4430[75] = (char *(*)()) F352_4649_4430_4;
	R4430[76] = (char *(*)()) F349_4649;
	R4430[77] = (char *(*)()) F352_4649_4430_4;
	R4430[78] = (char *(*)()) F349_4649;
	{long i; for (i = 96; i < 99; i++) R4430[i] = (char *(*)()) F634_5281;}
	R4430[103] = (char *(*)()) F634_5281;
	R4430[106] = (char *(*)()) F634_5281;
	R4430[108] = (char *(*)()) F634_5281;
	R4430[111] = (char *(*)()) F634_5281;
	{long i; for (i = 113; i < 117; i++) R4430[i] = (char *(*)()) F634_5281;}
	R4430[119] = (char *(*)()) F634_5281;
	R4430[120] = (char *(*)()) F635_5281_4430_4;
	R4430[121] = (char *(*)()) F634_5281;
	R4430[139] = (char *(*)()) F352_4649_4430_4;
	R4430[448] = (char *(*)()) F988_8451_4430_4;
	{long i; for (i = 524; i < 526; i++) R4430[i] = (char *(*)()) F565_4925;}
	{long i; for (i = 526; i < 528; i++) R4430[i] = (char *(*)()) F349_4649;}
	{long i; for (i = 529; i < 531; i++) R4430[i] = (char *(*)()) F349_4649;}
	{long i; for (i = 532; i < 534; i++) R4430[i] = (char *(*)()) F349_4649;}
	R4430[535] = (char *(*)()) F349_4649;
	R4430[537] = (char *(*)()) F349_4649;
	R4430[562] = (char *(*)()) F565_4925;
	R4430[571] = (char *(*)()) F565_4925;
}
static void F350_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F350_4649(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F351_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F351_4649(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F353_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F353_4649(Current, *(EIF_BOOLEAN *)arg1);
}
static void F354_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F354_4649(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F355_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F355_4649(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F352_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F352_4649(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F357_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F357_4649(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F356_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F356_4649(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F358_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F358_4649(Current, *(EIF_POINTER *)arg1);
}
static void F359_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F359_4649(Current, *(EIF_REAL_32 *)arg1);
}
static void F360_4649_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F360_4649(Current, *(EIF_REAL_64 *)arg1);
}
static void F569_4925_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F569_4925(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F568_4925_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F568_4925(Current, *(EIF_BOOLEAN *)arg1);
}
static void F635_5281_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F635_5281(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F988_8451_4430_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F988_8451(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4431[502])();
void R4431_init () {
	R4431[0] = (char *(*)()) F610_5111;
	R4431[1] = (char *(*)()) F611_5111;
	R4431[2] = (char *(*)()) F612_5111;
	R4431[3] = (char *(*)()) F613_5111;
	R4431[4] = (char *(*)()) F614_5111;
	R4431[5] = (char *(*)()) F615_5111;
	R4431[6] = (char *(*)()) F610_5111;
	R4431[7] = (char *(*)()) F612_5111;
	R4431[8] = (char *(*)()) F610_5111;
	R4431[9] = (char *(*)()) F619_5247;
	R4431[10] = (char *(*)()) F620_5247;
	R4431[11] = (char *(*)()) F621_5247;
	R4431[12] = (char *(*)()) F622_5247;
	R4431[13] = (char *(*)()) F623_5247;
	R4431[14] = (char *(*)()) F624_5247;
	R4431[15] = (char *(*)()) F625_5247;
	R4431[16] = (char *(*)()) F626_5247;
	R4431[17] = (char *(*)()) F627_5247;
	R4431[18] = (char *(*)()) F628_5247;
	R4431[19] = (char *(*)()) F629_5247;
	R4431[20] = (char *(*)()) F630_5247;
	R4431[21] = (char *(*)()) F619_5247;
	R4431[22] = (char *(*)()) F625_5247;
	R4431[23] = (char *(*)()) F622_5247;
	{long i; for (i = 26; i < 29; i++) R4431[i] = (char *(*)()) F634_5283;}
	R4431[33] = (char *(*)()) F634_5283;
	R4431[36] = (char *(*)()) F634_5283;
	R4431[38] = (char *(*)()) F634_5283;
	R4431[41] = (char *(*)()) F634_5283;
	{long i; for (i = 43; i < 47; i++) R4431[i] = (char *(*)()) F634_5283;}
	R4431[49] = (char *(*)()) F634_5283;
	R4431[50] = (char *(*)()) F635_5283;
	R4431[51] = (char *(*)()) F634_5283;
	R4431[378] = (char *(*)()) F988_8454;
	R4431[379] = (char *(*)()) F989_8545;
	{long i; for (i = 454; i < 456; i++) R4431[i] = (char *(*)()) F1056_9257;}
	{long i; for (i = 456; i < 458; i++) R4431[i] = (char *(*)()) F1066_9406;}
	{long i; for (i = 459; i < 461; i++) R4431[i] = (char *(*)()) F1066_9406;}
	{long i; for (i = 462; i < 464; i++) R4431[i] = (char *(*)()) F1066_9406;}
	R4431[465] = (char *(*)()) F1066_9406;
	R4431[467] = (char *(*)()) F1066_9406;
	R4431[492] = (char *(*)()) F1056_9257;
	R4431[501] = (char *(*)()) F1056_9257;
}

char *(*R4434[572])();
void R4434_init () {
	R4434[0] = (char *(*)()) F540_4819_4434_5;
	R4434[1] = (char *(*)()) F541_4819_4434_5;
	R4434[2] = (char *(*)()) F542_4819_4434_5;
	R4434[3] = (char *(*)()) F543_4819_4434_5;
	R4434[4] = (char *(*)()) F544_4819_4434_5;
	R4434[5] = (char *(*)()) F545_4819_4434_5;
	R4434[6] = (char *(*)()) F546_4819_4434_5;
	R4434[7] = (char *(*)()) F547_4819_4434_5;
	R4434[8] = (char *(*)()) F548_4819_4434_5;
	R4434[9] = (char *(*)()) F549_4819_4434_5;
	R4434[10] = (char *(*)()) F550_4819_4434_5;
	R4434[11] = (char *(*)()) F551_4819_4434_5;
	R4434[61] = (char *(*)()) F553_4898_4434_5;
	R4434[62] = (char *(*)()) F557_4898_4434_5;
	R4434[63] = (char *(*)()) F556_4898_4434_5;
	{long i; for (i = 64; i < 66; i++) R4434[i] = (char *(*)()) F553_4898_4434_5;}
	R4434[66] = (char *(*)()) F556_4898_4434_5;
	R4434[67] = (char *(*)()) F557_4898_4434_5;
	R4434[79] = (char *(*)()) F619_5194_4434_5;
	R4434[80] = (char *(*)()) F620_5194_4434_5;
	R4434[81] = (char *(*)()) F621_5194_4434_5;
	R4434[82] = (char *(*)()) F622_5194_4434_5;
	R4434[83] = (char *(*)()) F623_5194_4434_5;
	R4434[84] = (char *(*)()) F624_5194_4434_5;
	R4434[85] = (char *(*)()) F625_5194_4434_5;
	R4434[86] = (char *(*)()) F626_5194_4434_5;
	R4434[87] = (char *(*)()) F627_5194_4434_5;
	R4434[88] = (char *(*)()) F628_5194_4434_5;
	R4434[89] = (char *(*)()) F629_5194_4434_5;
	R4434[90] = (char *(*)()) F630_5194_4434_5;
	R4434[91] = (char *(*)()) F619_5194_4434_5;
	R4434[92] = (char *(*)()) F625_5194_4434_5;
	R4434[93] = (char *(*)()) F622_5194_4434_5;
	{long i; for (i = 96; i < 99; i++) R4434[i] = (char *(*)()) F619_5194_4434_5;}
	R4434[103] = (char *(*)()) F619_5194_4434_5;
	R4434[106] = (char *(*)()) F619_5194_4434_5;
	R4434[108] = (char *(*)()) F619_5194_4434_5;
	R4434[111] = (char *(*)()) F619_5194_4434_5;
	{long i; for (i = 113; i < 117; i++) R4434[i] = (char *(*)()) F619_5194_4434_5;}
	R4434[119] = (char *(*)()) F619_5194_4434_5;
	R4434[120] = (char *(*)()) F625_5194_4434_5;
	R4434[121] = (char *(*)()) F619_5194_4434_5;
	R4434[448] = (char *(*)()) F988_8392_4434_5;
	R4434[449] = (char *(*)()) F989_8482_4434_5;
	{long i; for (i = 524; i < 526; i++) R4434[i] = (char *(*)()) F1056_9229_4434_5;}
	R4434[562] = (char *(*)()) F1056_9229_4434_5;
	R4434[571] = (char *(*)()) F1056_9229_4434_5;
}
static EIF_REFERENCE F540_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F540_4819(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F541_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F541_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F542_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F542_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F543_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F543_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F544_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F544_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F545_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F545_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F546_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F546_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F547_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F547_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F548_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F548_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F549_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F550_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F551_4819_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F551_4819(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F553_4898_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F553_4898(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F557_4898_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F557_4898(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_4898_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F556_4898(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F619_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F619_5194(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F620_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5194_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5194(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8392_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F988_8392(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F989_8482_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F989_8482(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1056_9229_4434_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1056_9229(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4435[572])();
void R4435_init () {
	R4435[0] = (char *(*)()) F540_4820_4435_5;
	R4435[1] = (char *(*)()) F541_4820_4435_5;
	R4435[2] = (char *(*)()) F542_4820_4435_5;
	R4435[3] = (char *(*)()) F543_4820_4435_5;
	R4435[4] = (char *(*)()) F544_4820_4435_5;
	R4435[5] = (char *(*)()) F545_4820_4435_5;
	R4435[6] = (char *(*)()) F546_4820_4435_5;
	R4435[7] = (char *(*)()) F547_4820_4435_5;
	R4435[8] = (char *(*)()) F548_4820_4435_5;
	R4435[9] = (char *(*)()) F549_4820_4435_5;
	R4435[10] = (char *(*)()) F550_4820_4435_5;
	R4435[11] = (char *(*)()) F551_4820_4435_5;
	R4435[61] = (char *(*)()) F553_4899_4435_5;
	R4435[62] = (char *(*)()) F557_4899_4435_5;
	R4435[63] = (char *(*)()) F556_4899_4435_5;
	{long i; for (i = 64; i < 66; i++) R4435[i] = (char *(*)()) F553_4899_4435_5;}
	R4435[66] = (char *(*)()) F556_4899_4435_5;
	R4435[67] = (char *(*)()) F557_4899_4435_5;
	R4435[79] = (char *(*)()) F619_5195_4435_5;
	R4435[80] = (char *(*)()) F620_5195_4435_5;
	R4435[81] = (char *(*)()) F621_5195_4435_5;
	R4435[82] = (char *(*)()) F622_5195_4435_5;
	R4435[83] = (char *(*)()) F623_5195_4435_5;
	R4435[84] = (char *(*)()) F624_5195_4435_5;
	R4435[85] = (char *(*)()) F625_5195_4435_5;
	R4435[86] = (char *(*)()) F626_5195_4435_5;
	R4435[87] = (char *(*)()) F627_5195_4435_5;
	R4435[88] = (char *(*)()) F628_5195_4435_5;
	R4435[89] = (char *(*)()) F629_5195_4435_5;
	R4435[90] = (char *(*)()) F630_5195_4435_5;
	R4435[91] = (char *(*)()) F619_5195_4435_5;
	R4435[92] = (char *(*)()) F625_5195_4435_5;
	R4435[93] = (char *(*)()) F622_5195_4435_5;
	{long i; for (i = 96; i < 99; i++) R4435[i] = (char *(*)()) F619_5195_4435_5;}
	R4435[103] = (char *(*)()) F619_5195_4435_5;
	R4435[106] = (char *(*)()) F619_5195_4435_5;
	R4435[108] = (char *(*)()) F619_5195_4435_5;
	R4435[111] = (char *(*)()) F619_5195_4435_5;
	{long i; for (i = 113; i < 117; i++) R4435[i] = (char *(*)()) F619_5195_4435_5;}
	R4435[119] = (char *(*)()) F619_5195_4435_5;
	R4435[120] = (char *(*)()) F625_5195_4435_5;
	R4435[121] = (char *(*)()) F619_5195_4435_5;
	R4435[448] = (char *(*)()) F988_8393_4435_5;
	{long i; for (i = 524; i < 526; i++) R4435[i] = (char *(*)()) F553_4899_4435_5;}
	R4435[562] = (char *(*)()) F553_4899_4435_5;
	R4435[571] = (char *(*)()) F553_4899_4435_5;
}
static EIF_REFERENCE F540_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F540_4820(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F541_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F541_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F542_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F542_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F543_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F543_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F544_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F544_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F545_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F545_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F546_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F546_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F547_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F547_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F548_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F548_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F549_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F550_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F551_4820_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F551_4820(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F553_4899_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F553_4899(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F557_4899_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F557_4899(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_4899_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F556_4899(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F619_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F619_5195(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F620_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5195_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5195(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8393_4435_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F988_8393(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4437[450])();
void R4437_init () {
	R4437[0] = (char *(*)()) F540_4838_4437_12;
	R4437[1] = (char *(*)()) F541_4838_4437_12;
	R4437[2] = (char *(*)()) F542_4838_4437_12;
	R4437[3] = (char *(*)()) F543_4838_4437_12;
	R4437[4] = (char *(*)()) F544_4838_4437_12;
	R4437[5] = (char *(*)()) F545_4838_4437_12;
	R4437[6] = (char *(*)()) F546_4838_4437_12;
	R4437[7] = (char *(*)()) F547_4838_4437_12;
	R4437[8] = (char *(*)()) F548_4838_4437_12;
	R4437[9] = (char *(*)()) F549_4838_4437_12;
	R4437[10] = (char *(*)()) F550_4838_4437_12;
	R4437[11] = (char *(*)()) F551_4838_4437_12;
	R4437[70] = (char *(*)()) F610_5103;
	R4437[71] = (char *(*)()) F611_5103_4437_12;
	R4437[72] = (char *(*)()) F612_5103_4437_12;
	R4437[73] = (char *(*)()) F613_5103_4437_12;
	R4437[74] = (char *(*)()) F614_5103_4437_12;
	R4437[75] = (char *(*)()) F615_5103_4437_12;
	R4437[76] = (char *(*)()) F610_5103;
	R4437[77] = (char *(*)()) F612_5103_4437_12;
	R4437[78] = (char *(*)()) F610_5103;
	R4437[79] = (char *(*)()) F619_5227_4437_12;
	R4437[80] = (char *(*)()) F620_5227_4437_12;
	R4437[81] = (char *(*)()) F621_5227_4437_12;
	R4437[82] = (char *(*)()) F622_5227_4437_12;
	R4437[83] = (char *(*)()) F623_5227_4437_12;
	R4437[84] = (char *(*)()) F624_5227_4437_12;
	R4437[85] = (char *(*)()) F625_5227_4437_12;
	R4437[86] = (char *(*)()) F626_5227_4437_12;
	R4437[87] = (char *(*)()) F627_5227_4437_12;
	R4437[88] = (char *(*)()) F628_5227_4437_12;
	R4437[89] = (char *(*)()) F629_5227_4437_12;
	R4437[90] = (char *(*)()) F630_5227_4437_12;
	R4437[91] = (char *(*)()) F619_5227_4437_12;
	R4437[92] = (char *(*)()) F625_5227_4437_12;
	R4437[93] = (char *(*)()) F622_5227_4437_12;
	{long i; for (i = 96; i < 99; i++) R4437[i] = (char *(*)()) F634_5275_4437_12;}
	R4437[103] = (char *(*)()) F634_5275_4437_12;
	R4437[106] = (char *(*)()) F634_5275_4437_12;
	R4437[108] = (char *(*)()) F634_5275_4437_12;
	R4437[111] = (char *(*)()) F634_5275_4437_12;
	{long i; for (i = 113; i < 117; i++) R4437[i] = (char *(*)()) F634_5275_4437_12;}
	R4437[119] = (char *(*)()) F634_5275_4437_12;
	R4437[120] = (char *(*)()) F635_5275_4437_12;
	R4437[121] = (char *(*)()) F634_5275_4437_12;
	R4437[448] = (char *(*)()) F988_8412_4437_12;
	R4437[449] = (char *(*)()) F989_8503_4437_12;
}
static void F540_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F540_4838(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F541_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F541_4838(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F542_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F542_4838(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F543_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F543_4838(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F544_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F544_4838(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F545_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F545_4838(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F546_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F546_4838(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F547_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F547_4838(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F548_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F548_4838(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F549_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F549_4838(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F550_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F550_4838(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F551_4838_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F551_4838(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F611_5103_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F611_5103(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F612_5103_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F612_5103(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F613_5103_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F613_5103(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F614_5103_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F614_5103(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F615_5103_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F615_5103(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F619_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F619_5227(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F620_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F620_5227(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F621_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F621_5227(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F622_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F622_5227(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F623_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F623_5227(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F624_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F624_5227(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F625_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F625_5227(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F626_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F626_5227(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F627_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F627_5227(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F628_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F628_5227(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F629_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F629_5227(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F630_5227_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F630_5227(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F634_5275_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F634_5275(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F635_5275_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F635_5275(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F988_8412_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F988_8412(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F989_8503_4437_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F989_8503(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4439_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype32[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype33[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype34[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype35[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype36[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype37[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype38[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype39[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype40[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype41[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype42[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype43[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype44[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype45[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype46[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype47[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype48[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype49[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype50[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype51[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype52[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype53[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype54[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype55[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype56[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype57[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype58[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype59[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype60[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype61[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype62[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype63[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype64[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype65[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype66[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype67[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype68[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype69[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype70[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype71[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype72[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype73[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype74[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype75[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype76[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype77[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype78[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype79[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype80[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype81[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype82[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype83[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype84[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype85[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype86[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype87[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype88[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype89[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype90[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype91[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype92[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype93[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype94[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype95[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype96[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype97[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype98[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype99[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype100[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype101[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype102[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype103[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype104[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype105[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype106[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype107[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype108[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype109[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype110[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype111[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype112[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype113[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype114[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype115[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype120[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype121[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype122[] = {988,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype123[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype124[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype125[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype126[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype127[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype128[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype129[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype130[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype131[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype132[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype133[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype134[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype135[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype136[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype137[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype138[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype139[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype140[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype141[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype142[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype143[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype144[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype145[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype146[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype147[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype148[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype149[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype150[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype151[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype152[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype153[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype154[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype155[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype156[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype157[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype158[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype159[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype160[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype161[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype162[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype163[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype164[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype165[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype166[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype167[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype168[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype169[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype170[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype171[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype172[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype173[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype174[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype175[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype176[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype177[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype178[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype179[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype180[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype181[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype182[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype183[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype184[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype185[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype186[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype187[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype188[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4439_pgtype189[] = {907,0xFFFF};
EIF_TYPE_INDEX *Y4439_gen_type [739];
EIF_TYPE_INDEX Y4439 [739];
void Y4439_init (void)
{
	egc_routines_types [4439] = Y4439;
	egc_routines_gen_types [4439] = Y4439_gen_type;
	egc_routines_offset [4439] = 373;
	Y4439_gen_type [0] = Y4439_pgtype0;
	Y4439_gen_type [1] = Y4439_pgtype1;
	Y4439_gen_type [2] = Y4439_pgtype2;
	Y4439_gen_type [3] = Y4439_pgtype3;
	Y4439_gen_type [4] = Y4439_pgtype4;
	Y4439_gen_type [5] = Y4439_pgtype5;
	Y4439_gen_type [6] = Y4439_pgtype6;
	Y4439_gen_type [7] = Y4439_pgtype7;
	Y4439_gen_type [8] = Y4439_pgtype8;
	Y4439_gen_type [9] = Y4439_pgtype9;
	Y4439_gen_type [10] = Y4439_pgtype10;
	Y4439_gen_type [11] = Y4439_pgtype11;
	Y4439_gen_type [12] = Y4439_pgtype12;
	Y4439_gen_type [13] = Y4439_pgtype13;
	Y4439_gen_type [14] = Y4439_pgtype14;
	Y4439_gen_type [15] = Y4439_pgtype15;
	Y4439_gen_type [16] = Y4439_pgtype16;
	Y4439_gen_type [17] = Y4439_pgtype17;
	Y4439_gen_type [18] = Y4439_pgtype18;
	Y4439_gen_type [19] = Y4439_pgtype19;
	Y4439_gen_type [20] = Y4439_pgtype20;
	Y4439_gen_type [21] = Y4439_pgtype21;
	Y4439_gen_type [22] = Y4439_pgtype22;
	Y4439_gen_type [23] = Y4439_pgtype23;
	Y4439_gen_type [24] = Y4439_pgtype24;
	Y4439_gen_type [25] = Y4439_pgtype25;
	Y4439_gen_type [26] = Y4439_pgtype26;
	Y4439_gen_type [27] = Y4439_pgtype27;
	Y4439_gen_type [28] = Y4439_pgtype28;
	Y4439_gen_type [29] = Y4439_pgtype29;
	Y4439_gen_type [30] = Y4439_pgtype30;
	Y4439_gen_type [31] = Y4439_pgtype31;
	Y4439_gen_type [152] = Y4439_pgtype32;
	Y4439_gen_type [153] = Y4439_pgtype33;
	Y4439_gen_type [154] = Y4439_pgtype34;
	Y4439_gen_type [155] = Y4439_pgtype35;
	Y4439_gen_type [156] = Y4439_pgtype36;
	Y4439_gen_type [157] = Y4439_pgtype37;
	Y4439_gen_type [158] = Y4439_pgtype38;
	Y4439_gen_type [159] = Y4439_pgtype39;
	Y4439_gen_type [160] = Y4439_pgtype40;
	Y4439_gen_type [161] = Y4439_pgtype41;
	Y4439_gen_type [162] = Y4439_pgtype42;
	Y4439_gen_type [163] = Y4439_pgtype43;
	Y4439_gen_type [164] = Y4439_pgtype44;
	Y4439_gen_type [165] = Y4439_pgtype45;
	Y4439_gen_type [166] = Y4439_pgtype46;
	Y4439_gen_type [167] = Y4439_pgtype47;
	Y4439_gen_type [168] = Y4439_pgtype48;
	Y4439_gen_type [169] = Y4439_pgtype49;
	Y4439_gen_type [170] = Y4439_pgtype50;
	Y4439_gen_type [171] = Y4439_pgtype51;
	Y4439_gen_type [172] = Y4439_pgtype52;
	Y4439_gen_type [173] = Y4439_pgtype53;
	Y4439_gen_type [174] = Y4439_pgtype54;
	Y4439_gen_type [175] = Y4439_pgtype55;
	Y4439_gen_type [176] = Y4439_pgtype56;
	Y4439_gen_type [177] = Y4439_pgtype57;
	Y4439_gen_type [178] = Y4439_pgtype58;
	Y4439_gen_type [179] = Y4439_pgtype59;
	Y4439_gen_type [180] = Y4439_pgtype60;
	Y4439_gen_type [181] = Y4439_pgtype61;
	Y4439_gen_type [182] = Y4439_pgtype62;
	Y4439_gen_type [183] = Y4439_pgtype63;
	Y4439_gen_type [184] = Y4439_pgtype64;
	Y4439_gen_type [185] = Y4439_pgtype65;
	Y4439_gen_type [186] = Y4439_pgtype66;
	Y4439_gen_type [187] = Y4439_pgtype67;
	Y4439_gen_type [188] = Y4439_pgtype68;
	Y4439_gen_type [189] = Y4439_pgtype69;
	Y4439_gen_type [190] = Y4439_pgtype70;
	Y4439_gen_type [191] = Y4439_pgtype71;
	Y4439_gen_type [192] = Y4439_pgtype72;
	Y4439_gen_type [193] = Y4439_pgtype73;
	Y4439_gen_type [194] = Y4439_pgtype74;
	Y4439_gen_type [195] = Y4439_pgtype75;
	Y4439_gen_type [196] = Y4439_pgtype76;
	Y4439_gen_type [197] = Y4439_pgtype77;
	Y4439_gen_type [198] = Y4439_pgtype78;
	Y4439_gen_type [199] = Y4439_pgtype79;
	Y4439_gen_type [200] = Y4439_pgtype80;
	Y4439_gen_type [201] = Y4439_pgtype81;
	Y4439_gen_type [202] = Y4439_pgtype82;
	Y4439_gen_type [203] = Y4439_pgtype83;
	Y4439_gen_type [204] = Y4439_pgtype84;
	Y4439_gen_type [205] = Y4439_pgtype85;
	Y4439_gen_type [206] = Y4439_pgtype86;
	Y4439_gen_type [207] = Y4439_pgtype87;
	Y4439_gen_type [208] = Y4439_pgtype88;
	Y4439_gen_type [209] = Y4439_pgtype89;
	Y4439_gen_type [210] = Y4439_pgtype90;
	Y4439_gen_type [211] = Y4439_pgtype91;
	Y4439_gen_type [212] = Y4439_pgtype92;
	Y4439_gen_type [213] = Y4439_pgtype93;
	Y4439_gen_type [214] = Y4439_pgtype94;
	Y4439_gen_type [215] = Y4439_pgtype95;
	Y4439_gen_type [216] = Y4439_pgtype96;
	Y4439_gen_type [217] = Y4439_pgtype97;
	Y4439_gen_type [218] = Y4439_pgtype98;
	Y4439_gen_type [219] = Y4439_pgtype99;
	Y4439_gen_type [220] = Y4439_pgtype100;
	Y4439_gen_type [221] = Y4439_pgtype101;
	Y4439_gen_type [222] = Y4439_pgtype102;
	Y4439_gen_type [223] = Y4439_pgtype103;
	Y4439_gen_type [224] = Y4439_pgtype104;
	Y4439_gen_type [225] = Y4439_pgtype105;
	Y4439_gen_type [226] = Y4439_pgtype106;
	Y4439_gen_type [227] = Y4439_pgtype107;
	Y4439_gen_type [228] = Y4439_pgtype108;
	Y4439_gen_type [229] = Y4439_pgtype109;
	Y4439_gen_type [230] = Y4439_pgtype110;
	Y4439_gen_type [231] = Y4439_pgtype111;
	Y4439_gen_type [232] = Y4439_pgtype112;
	Y4439_gen_type [233] = Y4439_pgtype113;
	Y4439_gen_type [236] = Y4439_pgtype114;
	Y4439_gen_type [237] = Y4439_pgtype115;
	Y4439_gen_type [238] = Y4439_pgtype116;
	Y4439_gen_type [239] = Y4439_pgtype117;
	Y4439_gen_type [240] = Y4439_pgtype118;
	Y4439_gen_type [241] = Y4439_pgtype119;
	Y4439_gen_type [242] = Y4439_pgtype120;
	Y4439_gen_type [243] = Y4439_pgtype121;
	Y4439_gen_type [244] = Y4439_pgtype122;
	Y4439_gen_type [245] = Y4439_pgtype123;
	Y4439_gen_type [246] = Y4439_pgtype124;
	Y4439_gen_type [247] = Y4439_pgtype125;
	Y4439_gen_type [248] = Y4439_pgtype126;
	Y4439_gen_type [249] = Y4439_pgtype127;
	Y4439_gen_type [250] = Y4439_pgtype128;
	Y4439_gen_type [251] = Y4439_pgtype129;
	Y4439_gen_type [252] = Y4439_pgtype130;
	Y4439_gen_type [253] = Y4439_pgtype131;
	Y4439_gen_type [254] = Y4439_pgtype132;
	Y4439_gen_type [255] = Y4439_pgtype133;
	Y4439_gen_type [256] = Y4439_pgtype134;
	Y4439_gen_type [257] = Y4439_pgtype135;
	Y4439_gen_type [258] = Y4439_pgtype136;
	Y4439_gen_type [259] = Y4439_pgtype137;
	Y4439_gen_type [260] = Y4439_pgtype138;
	Y4439_gen_type [261] = Y4439_pgtype139;
	Y4439_gen_type [262] = Y4439_pgtype140;
	Y4439_gen_type [263] = Y4439_pgtype141;
	Y4439_gen_type [264] = Y4439_pgtype142;
	Y4439_gen_type [265] = Y4439_pgtype143;
	Y4439_gen_type [266] = Y4439_pgtype144;
	Y4439_gen_type [267] = Y4439_pgtype145;
	Y4439_gen_type [268] = Y4439_pgtype146;
	Y4439_gen_type [269] = Y4439_pgtype147;
	Y4439_gen_type [270] = Y4439_pgtype148;
	Y4439_gen_type [271] = Y4439_pgtype149;
	Y4439_gen_type [272] = Y4439_pgtype150;
	Y4439_gen_type [273] = Y4439_pgtype151;
	Y4439_gen_type [274] = Y4439_pgtype152;
	Y4439_gen_type [275] = Y4439_pgtype153;
	Y4439_gen_type [276] = Y4439_pgtype154;
	Y4439_gen_type [277] = Y4439_pgtype155;
	Y4439_gen_type [278] = Y4439_pgtype156;
	Y4439_gen_type [279] = Y4439_pgtype157;
	Y4439_gen_type [280] = Y4439_pgtype158;
	Y4439_gen_type [281] = Y4439_pgtype159;
	Y4439_gen_type [282] = Y4439_pgtype160;
	Y4439_gen_type [283] = Y4439_pgtype161;
	Y4439_gen_type [284] = Y4439_pgtype162;
	Y4439_gen_type [285] = Y4439_pgtype163;
	Y4439_gen_type [286] = Y4439_pgtype164;
	Y4439_gen_type [287] = Y4439_pgtype165;
	Y4439_gen_type [614] = Y4439_pgtype166;
	Y4439_gen_type [615] = Y4439_pgtype167;
	Y4439_gen_type [616] = Y4439_pgtype168;
	Y4439_gen_type [682] = Y4439_pgtype169;
	Y4439_gen_type [686] = Y4439_pgtype170;
	Y4439_gen_type [687] = Y4439_pgtype171;
	Y4439_gen_type [688] = Y4439_pgtype172;
	Y4439_gen_type [689] = Y4439_pgtype173;
	Y4439_gen_type [690] = Y4439_pgtype174;
	Y4439_gen_type [691] = Y4439_pgtype175;
	Y4439_gen_type [716] = Y4439_pgtype176;
	Y4439_gen_type [726] = Y4439_pgtype177;
	Y4439_gen_type [727] = Y4439_pgtype178;
	Y4439_gen_type [728] = Y4439_pgtype179;
	Y4439_gen_type [729] = Y4439_pgtype180;
	Y4439_gen_type [730] = Y4439_pgtype181;
	Y4439_gen_type [731] = Y4439_pgtype182;
	Y4439_gen_type [732] = Y4439_pgtype183;
	Y4439_gen_type [733] = Y4439_pgtype184;
	Y4439_gen_type [734] = Y4439_pgtype185;
	Y4439_gen_type [735] = Y4439_pgtype186;
	Y4439_gen_type [736] = Y4439_pgtype187;
	Y4439_gen_type [737] = Y4439_pgtype188;
	Y4439_gen_type [738] = Y4439_pgtype189;
	{long i; for (i = 152; i < 234; i++) Y4439[i] = 907;};
	{long i; for (i = 242; i < 244; i++) Y4439[i] = 980;};
	Y4439[244] = 988;
	{long i; for (i = 245; i < 288; i++) Y4439[i] = 907;};
	{long i; for (i = 614; i < 617; i++) Y4439[i] = 907;};
	Y4439[682] = 907;
	{long i; for (i = 686; i < 692; i++) Y4439[i] = 907;};
	Y4439[716] = 907;
	{long i; for (i = 726; i < 739; i++) Y4439[i] = 907;};
}

char *(*R4440[380])();
void R4440_init () {
	R4440[0] = (char *(*)()) F610_5109;
	R4440[1] = (char *(*)()) F611_5109_4440_4;
	R4440[2] = (char *(*)()) F612_5109;
	R4440[3] = (char *(*)()) F613_5109_4440_4;
	R4440[4] = (char *(*)()) F614_5109;
	R4440[5] = (char *(*)()) F615_5109_4440_4;
	R4440[6] = (char *(*)()) F610_5109;
	R4440[7] = (char *(*)()) F612_5109;
	R4440[8] = (char *(*)()) F610_5109;
	R4440[378] = (char *(*)()) F988_8446_4440_4;
	R4440[379] = (char *(*)()) F989_8537_4440_4;
}
static void F611_5109_4440_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_5109(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F613_5109_4440_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_5109(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F615_5109_4440_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F615_5109(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F988_8446_4440_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F988_8446(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F989_8537_4440_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F989_8537(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4441[687])();
void R4441_init () {
	R4441[0] = (char *(*)()) F601_4946;
	R4441[1] = (char *(*)()) F602_4946_4441_1;
	R4441[2] = (char *(*)()) F603_4946_4441_1;
	R4441[3] = (char *(*)()) F604_4992;
	R4441[4] = (char *(*)()) F605_5010;
	R4441[5] = (char *(*)()) F606_5010_4441_1;
	R4441[6] = (char *(*)()) F607_5010_4441_1;
	R4441[18] = (char *(*)()) F619_5193;
	R4441[19] = (char *(*)()) F620_5193_4441_1;
	R4441[20] = (char *(*)()) F621_5193_4441_1;
	R4441[21] = (char *(*)()) F622_5193_4441_1;
	R4441[22] = (char *(*)()) F623_5193_4441_1;
	R4441[23] = (char *(*)()) F624_5193_4441_1;
	R4441[24] = (char *(*)()) F625_5193_4441_1;
	R4441[25] = (char *(*)()) F626_5193_4441_1;
	R4441[26] = (char *(*)()) F627_5193_4441_1;
	R4441[27] = (char *(*)()) F628_5193_4441_1;
	R4441[28] = (char *(*)()) F629_5193_4441_1;
	R4441[29] = (char *(*)()) F630_5193_4441_1;
	R4441[30] = (char *(*)()) F619_5193;
	R4441[31] = (char *(*)()) F625_5193_4441_1;
	R4441[32] = (char *(*)()) F622_5193_4441_1;
	{long i; for (i = 35; i < 38; i++) R4441[i] = (char *(*)()) F619_5193;}
	R4441[42] = (char *(*)()) F619_5193;
	R4441[45] = (char *(*)()) F619_5193;
	R4441[47] = (char *(*)()) F619_5193;
	R4441[50] = (char *(*)()) F619_5193;
	{long i; for (i = 52; i < 56; i++) R4441[i] = (char *(*)()) F619_5193;}
	R4441[58] = (char *(*)()) F619_5193;
	R4441[59] = (char *(*)()) F625_5193_4441_1;
	R4441[60] = (char *(*)()) F619_5193;
	R4441[78] = (char *(*)()) F444_4680_4441_1;
	R4441[257] = (char *(*)()) F857_6236_4441_1;
	{long i; for (i = 463; i < 465; i++) R4441[i] = (char *(*)()) F1056_9226;}
	R4441[501] = (char *(*)()) F1056_9226;
	R4441[510] = (char *(*)()) F1056_9226;
	R4441[686] = (char *(*)()) F857_6236_4441_1;
}
static EIF_REFERENCE F602_4946_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F602_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_4946_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_4946(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_5010_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F606_5010(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F607_5010_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F607_5010(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F620_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F620_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F621_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F621_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F622_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F622_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F623_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F623_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F624_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F624_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F625_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F626_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F627_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F628_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F629_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_5193_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F630_5193(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F444_4680_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F444_4680(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6236_4441_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F857_6236(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4441_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype119[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype120[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype121[] = {975,0xFFF9,1,901,0,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype122[] = {975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype123[] = {975,0xFFF9,1,901,1089,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype124[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype125[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype126[] = {975,0xFFF9,1,901,1095,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype127[] = {975,0xFFF9,1,901,1057,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype128[] = {975,0xFFF9,1,901,865,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype129[] = {975,0xFFF9,1,901,1036,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype130[] = {975,0xFFF9,5,901,919,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype131[] = {975,0xFFF9,1,901,1287,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype132[] = {975,0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype133[] = {975,0xFFF9,1,901,987,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype134[] = {975,0xFFF9,7,901,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype135[] = {975,0xFFF9,2,901,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype136[] = {975,0xFFF9,4,901,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype137[] = {975,0xFFF9,3,901,907,907,865,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype138[] = {975,0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype139[] = {975,0xFFF9,0,901,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4441_pgtype145[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4441_gen_type [882];
EIF_TYPE_INDEX Y4441 [882];
void Y4441_init (void)
{
	egc_routines_types [4441] = Y4441;
	egc_routines_gen_types [4441] = Y4441_gen_type;
	egc_routines_offset [4441] = 405;
	Y4441_gen_type [0] = Y4441_pgtype0;
	Y4441_gen_type [1] = Y4441_pgtype1;
	Y4441_gen_type [2] = Y4441_pgtype2;
	Y4441_gen_type [3] = Y4441_pgtype3;
	Y4441_gen_type [4] = Y4441_pgtype4;
	Y4441_gen_type [5] = Y4441_pgtype5;
	Y4441_gen_type [6] = Y4441_pgtype6;
	Y4441_gen_type [7] = Y4441_pgtype7;
	Y4441_gen_type [8] = Y4441_pgtype8;
	Y4441_gen_type [9] = Y4441_pgtype9;
	Y4441_gen_type [10] = Y4441_pgtype10;
	Y4441_gen_type [11] = Y4441_pgtype11;
	Y4441_gen_type [12] = Y4441_pgtype12;
	Y4441_gen_type [13] = Y4441_pgtype13;
	Y4441_gen_type [14] = Y4441_pgtype14;
	Y4441_gen_type [15] = Y4441_pgtype15;
	Y4441_gen_type [16] = Y4441_pgtype16;
	Y4441_gen_type [17] = Y4441_pgtype17;
	Y4441_gen_type [18] = Y4441_pgtype18;
	Y4441_gen_type [19] = Y4441_pgtype19;
	Y4441_gen_type [20] = Y4441_pgtype20;
	Y4441_gen_type [21] = Y4441_pgtype21;
	Y4441_gen_type [22] = Y4441_pgtype22;
	Y4441_gen_type [23] = Y4441_pgtype23;
	Y4441_gen_type [38] = Y4441_pgtype24;
	Y4441_gen_type [75] = Y4441_pgtype25;
	Y4441_gen_type [76] = Y4441_pgtype26;
	Y4441_gen_type [77] = Y4441_pgtype27;
	Y4441_gen_type [78] = Y4441_pgtype28;
	Y4441_gen_type [79] = Y4441_pgtype29;
	Y4441_gen_type [80] = Y4441_pgtype30;
	Y4441_gen_type [81] = Y4441_pgtype31;
	Y4441_gen_type [82] = Y4441_pgtype32;
	Y4441_gen_type [83] = Y4441_pgtype33;
	Y4441_gen_type [84] = Y4441_pgtype34;
	Y4441_gen_type [85] = Y4441_pgtype35;
	Y4441_gen_type [86] = Y4441_pgtype36;
	Y4441_gen_type [87] = Y4441_pgtype37;
	Y4441_gen_type [88] = Y4441_pgtype38;
	Y4441_gen_type [89] = Y4441_pgtype39;
	Y4441_gen_type [90] = Y4441_pgtype40;
	Y4441_gen_type [91] = Y4441_pgtype41;
	Y4441_gen_type [92] = Y4441_pgtype42;
	Y4441_gen_type [93] = Y4441_pgtype43;
	Y4441_gen_type [94] = Y4441_pgtype44;
	Y4441_gen_type [95] = Y4441_pgtype45;
	Y4441_gen_type [147] = Y4441_pgtype46;
	Y4441_gen_type [148] = Y4441_pgtype47;
	Y4441_gen_type [149] = Y4441_pgtype48;
	Y4441_gen_type [150] = Y4441_pgtype49;
	Y4441_gen_type [151] = Y4441_pgtype50;
	Y4441_gen_type [152] = Y4441_pgtype51;
	Y4441_gen_type [153] = Y4441_pgtype52;
	Y4441_gen_type [154] = Y4441_pgtype53;
	Y4441_gen_type [155] = Y4441_pgtype54;
	Y4441_gen_type [156] = Y4441_pgtype55;
	Y4441_gen_type [157] = Y4441_pgtype56;
	Y4441_gen_type [158] = Y4441_pgtype57;
	Y4441_gen_type [159] = Y4441_pgtype58;
	Y4441_gen_type [160] = Y4441_pgtype59;
	Y4441_gen_type [161] = Y4441_pgtype60;
	Y4441_gen_type [162] = Y4441_pgtype61;
	Y4441_gen_type [163] = Y4441_pgtype62;
	Y4441_gen_type [164] = Y4441_pgtype63;
	Y4441_gen_type [165] = Y4441_pgtype64;
	Y4441_gen_type [166] = Y4441_pgtype65;
	Y4441_gen_type [167] = Y4441_pgtype66;
	Y4441_gen_type [168] = Y4441_pgtype67;
	Y4441_gen_type [169] = Y4441_pgtype68;
	Y4441_gen_type [170] = Y4441_pgtype69;
	Y4441_gen_type [171] = Y4441_pgtype70;
	Y4441_gen_type [172] = Y4441_pgtype71;
	Y4441_gen_type [173] = Y4441_pgtype72;
	Y4441_gen_type [174] = Y4441_pgtype73;
	Y4441_gen_type [175] = Y4441_pgtype74;
	Y4441_gen_type [176] = Y4441_pgtype75;
	Y4441_gen_type [177] = Y4441_pgtype76;
	Y4441_gen_type [178] = Y4441_pgtype77;
	Y4441_gen_type [179] = Y4441_pgtype78;
	Y4441_gen_type [180] = Y4441_pgtype79;
	Y4441_gen_type [181] = Y4441_pgtype80;
	Y4441_gen_type [182] = Y4441_pgtype81;
	Y4441_gen_type [183] = Y4441_pgtype82;
	Y4441_gen_type [184] = Y4441_pgtype83;
	Y4441_gen_type [185] = Y4441_pgtype84;
	Y4441_gen_type [186] = Y4441_pgtype85;
	Y4441_gen_type [187] = Y4441_pgtype86;
	Y4441_gen_type [188] = Y4441_pgtype87;
	Y4441_gen_type [189] = Y4441_pgtype88;
	Y4441_gen_type [190] = Y4441_pgtype89;
	Y4441_gen_type [191] = Y4441_pgtype90;
	Y4441_gen_type [192] = Y4441_pgtype91;
	Y4441_gen_type [193] = Y4441_pgtype92;
	Y4441_gen_type [194] = Y4441_pgtype93;
	Y4441_gen_type [195] = Y4441_pgtype94;
	Y4441_gen_type [196] = Y4441_pgtype95;
	Y4441_gen_type [197] = Y4441_pgtype96;
	Y4441_gen_type [198] = Y4441_pgtype97;
	Y4441_gen_type [199] = Y4441_pgtype98;
	Y4441_gen_type [200] = Y4441_pgtype99;
	Y4441_gen_type [201] = Y4441_pgtype100;
	Y4441_gen_type [203] = Y4441_pgtype101;
	Y4441_gen_type [213] = Y4441_pgtype102;
	Y4441_gen_type [214] = Y4441_pgtype103;
	Y4441_gen_type [215] = Y4441_pgtype104;
	Y4441_gen_type [216] = Y4441_pgtype105;
	Y4441_gen_type [217] = Y4441_pgtype106;
	Y4441_gen_type [218] = Y4441_pgtype107;
	Y4441_gen_type [219] = Y4441_pgtype108;
	Y4441_gen_type [220] = Y4441_pgtype109;
	Y4441_gen_type [221] = Y4441_pgtype110;
	Y4441_gen_type [222] = Y4441_pgtype111;
	Y4441_gen_type [223] = Y4441_pgtype112;
	Y4441_gen_type [224] = Y4441_pgtype113;
	Y4441_gen_type [225] = Y4441_pgtype114;
	Y4441_gen_type [226] = Y4441_pgtype115;
	Y4441_gen_type [227] = Y4441_pgtype116;
	Y4441_gen_type [228] = Y4441_pgtype117;
	Y4441_gen_type [229] = Y4441_pgtype118;
	Y4441_gen_type [230] = Y4441_pgtype119;
	Y4441_gen_type [231] = Y4441_pgtype120;
	Y4441_gen_type [232] = Y4441_pgtype121;
	Y4441_gen_type [233] = Y4441_pgtype122;
	Y4441_gen_type [234] = Y4441_pgtype123;
	Y4441_gen_type [235] = Y4441_pgtype124;
	Y4441_gen_type [236] = Y4441_pgtype125;
	Y4441_gen_type [237] = Y4441_pgtype126;
	Y4441_gen_type [238] = Y4441_pgtype127;
	Y4441_gen_type [239] = Y4441_pgtype128;
	Y4441_gen_type [240] = Y4441_pgtype129;
	Y4441_gen_type [241] = Y4441_pgtype130;
	Y4441_gen_type [242] = Y4441_pgtype131;
	Y4441_gen_type [243] = Y4441_pgtype132;
	Y4441_gen_type [244] = Y4441_pgtype133;
	Y4441_gen_type [245] = Y4441_pgtype134;
	Y4441_gen_type [246] = Y4441_pgtype135;
	Y4441_gen_type [247] = Y4441_pgtype136;
	Y4441_gen_type [248] = Y4441_pgtype137;
	Y4441_gen_type [249] = Y4441_pgtype138;
	Y4441_gen_type [250] = Y4441_pgtype139;
	Y4441_gen_type [251] = Y4441_pgtype140;
	Y4441_gen_type [252] = Y4441_pgtype141;
	Y4441_gen_type [253] = Y4441_pgtype142;
	Y4441_gen_type [254] = Y4441_pgtype143;
	Y4441_gen_type [650] = Y4441_pgtype144;
	Y4441_gen_type [694] = Y4441_pgtype145;
	{long i; for (i = 230; i < 251; i++) Y4441[i] = 975;};
	Y4441[255] = 1025;
	Y4441[273] = 907;
	{long i; for (i = 451; i < 454; i++) Y4441[i] = 937;};
	{long i; for (i = 654; i < 660; i++) Y4441[i] = 1057;};
	Y4441[684] = 987;
	Y4441[695] = 1089;
	Y4441[696] = 1091;
	{long i; for (i = 697; i < 700; i++) Y4441[i] = 1090;};
	{long i; for (i = 700; i < 704; i++) Y4441[i] = 1107;};
	{long i; for (i = 704; i < 707; i++) Y4441[i] = 1095;};
	Y4441[881] = 937;
}


#ifdef __cplusplus
}
#endif
