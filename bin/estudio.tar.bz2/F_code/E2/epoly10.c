#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5580[431];
void O5580_init () {
	O5580[0] = + _CHROFF_3_3_;
	O5580[1] = + _CHROFF_4_3_;
	O5580[2] = + _CHROFF_5_3_;
	O5580[430] = + _CHROFF_5_3_;
}

long O5720[420];
void O5720_init () {
	O5720[0] = + _LNGOFF_0_0_0_0_;
	O5720[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O5720[i] = + _LNGOFF_0_0_0_0_;}
	O5720[4] = + _LNGOFF_2_0_0_0_;
	O5720[5] = + _LNGOFF_0_1_0_0_;
	O5720[179] = + _LNGOFF_2_0_0_0_;
	O5720[192] = + _LNGOFF_4_0_0_0_;
	O5720[196] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 197; i < 211; i++) O5720[i] = + _LNGOFF_6_3_0_0_;}
	O5720[211] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 212; i < 214; i++) O5720[i] = + _LNGOFF_14_3_0_0_;}
	O5720[214] = + _LNGOFF_6_4_0_0_;
	O5720[215] = + _LNGOFF_12_4_0_0_;
	{long i; for (i = 216; i < 220; i++) O5720[i] = + _LNGOFF_5_2_0_0_;}
	O5720[220] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 221; i < 223; i++) O5720[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 223; i < 227; i++) O5720[i] = + _LNGOFF_5_2_0_0_;}
	O5720[227] = + _LNGOFF_6_0_0_0_;
	O5720[228] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 229; i < 238; i++) O5720[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 239; i < 244; i++) O5720[i] = + _LNGOFF_5_3_0_0_;}
	O5720[245] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 246; i < 248; i++) O5720[i] = + _LNGOFF_6_1_0_0_;}
	O5720[249] = + _LNGOFF_6_1_0_0_;
	O5720[256] = + _LNGOFF_2_4_0_0_;
	O5720[275] = + _LNGOFF_49_16_0_3_;
	O5720[277] = + _LNGOFF_2_2_0_1_;
	O5720[279] = + _LNGOFF_2_3_0_0_;
	O5720[280] = + _LNGOFF_4_3_0_0_;
	O5720[281] = + _LNGOFF_5_5_0_0_;
	O5720[282] = + _LNGOFF_10_10_0_0_;
	O5720[296] = + _LNGOFF_6_3_0_0_;
	O5720[319] = + _LNGOFF_8_5_0_0_;
	O5720[321] = + _LNGOFF_16_7_6_0_;
	O5720[323] = + _LNGOFF_42_12_10_0_;
	O5720[325] = + _LNGOFF_46_12_10_0_;
	O5720[329] = + _LNGOFF_47_12_10_0_;
	O5720[330] = + _LNGOFF_49_12_10_0_;
	O5720[331] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 335; i < 338; i++) O5720[i] = + _LNGOFF_49_13_10_0_;}
	O5720[346] = + _LNGOFF_49_13_10_0_;
	O5720[347] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 348; i < 350; i++) O5720[i] = + _LNGOFF_49_14_10_0_;}
	O5720[350] = + _LNGOFF_59_21_10_0_;
	O5720[351] = + _LNGOFF_59_23_10_0_;
	O5720[352] = + _LNGOFF_65_25_10_0_;
	O5720[353] = + _LNGOFF_68_26_10_0_;
	O5720[369] = + _LNGOFF_42_13_10_0_;
	O5720[370] = + _LNGOFF_45_16_10_0_;
	O5720[371] = + _LNGOFF_58_14_10_0_;
	O5720[372] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 373; i < 375; i++) O5720[i] = + _LNGOFF_44_13_10_0_;}
	{long i; for (i = 375; i < 377; i++) O5720[i] = + _LNGOFF_46_14_10_0_;}
	O5720[377] = + _LNGOFF_50_13_10_0_;
	O5720[378] = + _LNGOFF_51_14_10_0_;
	O5720[379] = + _LNGOFF_43_13_10_0_;
	O5720[380] = + _LNGOFF_44_15_10_0_;
	O5720[381] = + _LNGOFF_51_18_10_0_;
	O5720[382] = + _LNGOFF_46_14_10_0_;
	O5720[383] = + _LNGOFF_59_16_10_0_;
	{long i; for (i = 392; i < 394; i++) O5720[i] = + _LNGOFF_21_7_6_0_;}
	O5720[399] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 400; i < 402; i++) O5720[i] = + _LNGOFF_23_9_6_0_;}
	O5720[402] = + _LNGOFF_24_9_6_0_;
	O5720[403] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 408; i < 410; i++) O5720[i] = + _LNGOFF_29_14_8_0_;}
	O5720[416] = + _LNGOFF_48_19_10_0_;
	O5720[419] = + _LNGOFF_48_18_10_0_;
}

long O5780[246];
void O5780_init () {
	O5780[0] =  + _REFACS_1_;
	O5780[188] =  + _REFACS_1_;
	{long i; for (i = 192; i < 211; i++) O5780[i] =  + _REFACS_1_;}
	O5780[211] =  + _REFACS_4_;
	{long i; for (i = 212; i < 224; i++) O5780[i] =  + _REFACS_1_;}
	O5780[224] =  + _REFACS_2_;
	{long i; for (i = 225; i < 234; i++) O5780[i] =  + _REFACS_1_;}
	{long i; for (i = 235; i < 240; i++) O5780[i] =  + _REFACS_1_;}
	{long i; for (i = 241; i < 244; i++) O5780[i] =  + _REFACS_1_;}
	O5780[245] =  + _REFACS_1_;
}

long O6651[6];
void O6651_init () {
	{long i; for (i = 0; i < 2; i++) O6651[i] = + _CHROFF_4_0_;}
	O6651[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O6651[i] = + _CHROFF_4_0_;}
}

long O6652[6];
void O6652_init () {
	{long i; for (i = 0; i < 2; i++) O6652[i] = + _LNGOFF_4_2_0_0_;}
	O6652[2] = + _LNGOFF_5_2_0_0_;
	O6652[3] = + _LNGOFF_4_3_0_0_;
	O6652[4] = + _LNGOFF_4_2_0_0_;
	O6652[5] = + _LNGOFF_4_3_0_0_;
}

long O6660[6];
void O6660_init () {
	{long i; for (i = 0; i < 2; i++) O6660[i] = + _PTROFF_4_2_0_3_0_0_;}
	O6660[2] = + _PTROFF_5_2_0_3_0_0_;
	O6660[3] = + _PTROFF_4_3_0_3_0_0_;
	O6660[4] = + _PTROFF_4_2_0_3_0_0_;
	O6660[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O6661[6];
void O6661_init () {
	{long i; for (i = 0; i < 2; i++) O6661[i] = + _PTROFF_4_2_0_3_0_1_;}
	O6661[2] = + _PTROFF_5_2_0_3_0_1_;
	O6661[3] = + _PTROFF_4_3_0_3_0_1_;
	O6661[4] = + _PTROFF_4_2_0_3_0_1_;
	O6661[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O6663[6];
void O6663_init () {
	{long i; for (i = 0; i < 2; i++) O6663[i] = + _PTROFF_4_2_0_3_0_2_;}
	O6663[2] = + _PTROFF_5_2_0_3_0_2_;
	O6663[3] = + _PTROFF_4_3_0_3_0_2_;
	O6663[4] = + _PTROFF_4_2_0_3_0_2_;
	O6663[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O6664[6];
void O6664_init () {
	{long i; for (i = 0; i < 2; i++) O6664[i] = + _LNGOFF_4_2_0_1_;}
	O6664[2] = + _LNGOFF_5_2_0_1_;
	O6664[3] = + _LNGOFF_4_3_0_1_;
	O6664[4] = + _LNGOFF_4_2_0_1_;
	O6664[5] = + _LNGOFF_4_3_0_1_;
}

long O6665[6];
void O6665_init () {
	{long i; for (i = 0; i < 2; i++) O6665[i] = + _CHROFF_4_1_;}
	O6665[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O6665[i] = + _CHROFF_4_1_;}
}

long O6666[6];
void O6666_init () {
	{long i; for (i = 0; i < 2; i++) O6666[i] = + _LNGOFF_4_2_0_2_;}
	O6666[2] = + _LNGOFF_5_2_0_2_;
	O6666[3] = + _LNGOFF_4_3_0_2_;
	O6666[4] = + _LNGOFF_4_2_0_2_;
	O6666[5] = + _LNGOFF_4_3_0_2_;
}

long O6679[4];
void O6679_init () {
	O6679[0] =  + _REFACS_4_;
	O6679[1] = + _CHROFF_4_2_;
	O6679[2] = + _PTROFF_4_2_0_3_0_3_;
	O6679[3] = + _CHROFF_4_2_;
}

long O6778[10];
void O6778_init () {
	{long i; for (i = 0; i < 2; i++) O6778[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 2; i < 6; i++) O6778[i] = + _LNGOFF_1_0_0_0_;}
	O6778[6] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 7; i < 10; i++) O6778[i] = + _LNGOFF_1_1_0_0_;}
}

long O6779[10];
void O6779_init () {
	{long i; for (i = 0; i < 2; i++) O6779[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 2; i < 6; i++) O6779[i] = + _LNGOFF_1_0_0_1_;}
	O6779[6] = + _LNGOFF_0_0_0_1_;
	{long i; for (i = 7; i < 10; i++) O6779[i] = + _LNGOFF_1_1_0_1_;}
}

long O6810[6];
void O6810_init () {
	{long i; for (i = 0; i < 2; i++) O6810[i] = + _LNGOFF_1_0_0_2_;}
	O6810[5] = + _LNGOFF_1_1_0_2_;
}

long O6851[6];
void O6851_init () {
	{long i; for (i = 0; i < 2; i++) O6851[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 4; i < 6; i++) O6851[i] = + _LNGOFF_1_1_0_2_;}
}

long O7088[96];
void O7088_init () {
	{long i; for (i = 0; i < 17; i++) O7088[i] =  + _REFACS_1_;}
	O7088[17] =  + _REFACS_9_;
	{long i; for (i = 18; i < 36; i++) O7088[i] =  + _REFACS_1_;}
	O7088[36] =  + _REFACS_3_;
	{long i; for (i = 37; i < 40; i++) O7088[i] =  + _REFACS_1_;}
	{long i; for (i = 40; i < 59; i++) O7088[i] =  + _REFACS_3_;}
	O7088[59] =  + _REFACS_6_;
	{long i; for (i = 60; i < 72; i++) O7088[i] =  + _REFACS_3_;}
	O7088[72] =  + _REFACS_4_;
	{long i; for (i = 73; i < 82; i++) O7088[i] =  + _REFACS_3_;}
	O7088[82] =  + _REFACS_1_;
	{long i; for (i = 83; i < 88; i++) O7088[i] =  + _REFACS_3_;}
	O7088[88] =  + _REFACS_1_;
	{long i; for (i = 89; i < 92; i++) O7088[i] =  + _REFACS_3_;}
	O7088[92] =  + _REFACS_1_;
	O7088[93] =  + _REFACS_3_;
	{long i; for (i = 94; i < 96; i++) O7088[i] =  + _REFACS_1_;}
}

long O7279[82];
void O7279_init () {
	O7279[0] =  + _REFACS_2_;
	{long i; for (i = 24; i < 27; i++) O7279[i] =  + _REFACS_2_;}
	{long i; for (i = 27; i < 46; i++) O7279[i] =  + _REFACS_4_;}
	O7279[46] =  + _REFACS_7_;
	{long i; for (i = 47; i < 59; i++) O7279[i] =  + _REFACS_4_;}
	O7279[59] =  + _REFACS_5_;
	{long i; for (i = 60; i < 69; i++) O7279[i] =  + _REFACS_4_;}
	O7279[69] =  + _REFACS_2_;
	{long i; for (i = 70; i < 75; i++) O7279[i] =  + _REFACS_4_;}
	O7279[75] =  + _REFACS_2_;
	{long i; for (i = 76; i < 79; i++) O7279[i] =  + _REFACS_4_;}
	O7279[79] =  + _REFACS_2_;
	O7279[80] =  + _REFACS_4_;
	O7279[81] =  + _REFACS_2_;
}

long O7534[50];
void O7534_init () {
	O7534[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 15; i++) O7534[i] = + _CHROFF_6_1_;}
	O7534[15] = + _CHROFF_7_1_;
	{long i; for (i = 16; i < 18; i++) O7534[i] = + _CHROFF_14_1_;}
	O7534[18] = + _CHROFF_6_1_;
	O7534[19] = + _CHROFF_12_1_;
	{long i; for (i = 20; i < 24; i++) O7534[i] = + _CHROFF_5_0_;}
	{long i; for (i = 24; i < 27; i++) O7534[i] = + _CHROFF_6_0_;}
	{long i; for (i = 27; i < 31; i++) O7534[i] = + _CHROFF_5_0_;}
	{long i; for (i = 43; i < 48; i++) O7534[i] = + _CHROFF_5_1_;}
	O7534[49] = + _CHROFF_5_1_;
}

long O7535[50];
void O7535_init () {
	O7535[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 15; i++) O7535[i] = + _CHROFF_6_2_;}
	O7535[15] = + _CHROFF_7_2_;
	{long i; for (i = 16; i < 18; i++) O7535[i] = + _CHROFF_14_2_;}
	O7535[18] = + _CHROFF_6_2_;
	O7535[19] = + _CHROFF_12_2_;
	{long i; for (i = 20; i < 24; i++) O7535[i] = + _CHROFF_5_1_;}
	{long i; for (i = 24; i < 27; i++) O7535[i] = + _CHROFF_6_1_;}
	{long i; for (i = 27; i < 31; i++) O7535[i] = + _CHROFF_5_1_;}
	{long i; for (i = 43; i < 48; i++) O7535[i] = + _CHROFF_5_2_;}
	O7535[49] = + _CHROFF_5_2_;
}

long O7965[170];
void O7965_init () {
	{long i; for (i = 0; i < 22; i++) O7965[i] = 0;}
	O7965[22] =  + _REFACS_22_;
	O7965[23] =  + _REFACS_23_;
	{long i; for (i = 24; i < 35; i++) O7965[i] = 0;}
	O7965[35] =  + _REFACS_1_;
	O7965[36] = 0;
	O7965[37] =  + _REFACS_1_;
	{long i; for (i = 38; i < 40; i++) O7965[i] = 0;}
	{long i; for (i = 40; i < 42; i++) O7965[i] =  + _REFACS_5_;}
	O7965[42] = 0;
	{long i; for (i = 43; i < 45; i++) O7965[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 51; i++) O7965[i] = 0;}
	{long i; for (i = 51; i < 53; i++) O7965[i] =  + _REFACS_1_;}
	{long i; for (i = 53; i < 66; i++) O7965[i] = 0;}
	{long i; for (i = 66; i < 68; i++) O7965[i] =  + _REFACS_2_;}
	{long i; for (i = 68; i < 70; i++) O7965[i] =  + _REFACS_7_;}
	{long i; for (i = 70; i < 72; i++) O7965[i] =  + _REFACS_24_;}
	{long i; for (i = 72; i < 75; i++) O7965[i] =  + _REFACS_25_;}
	O7965[75] =  + _REFACS_26_;
	{long i; for (i = 76; i < 78; i++) O7965[i] =  + _REFACS_25_;}
	O7965[78] =  + _REFACS_26_;
	O7965[79] =  + _REFACS_25_;
	{long i; for (i = 80; i < 90; i++) O7965[i] =  + _REFACS_26_;}
	{long i; for (i = 90; i < 92; i++) O7965[i] =  + _REFACS_30_;}
	{long i; for (i = 92; i < 94; i++) O7965[i] =  + _REFACS_33_;}
	{long i; for (i = 94; i < 98; i++) O7965[i] =  + _REFACS_26_;}
	{long i; for (i = 98; i < 100; i++) O7965[i] =  + _REFACS_30_;}
	{long i; for (i = 100; i < 102; i++) O7965[i] =  + _REFACS_33_;}
	O7965[102] =  + _REFACS_24_;
	O7965[103] =  + _REFACS_28_;
	O7965[104] =  + _REFACS_26_;
	{long i; for (i = 105; i < 107; i++) O7965[i] =  + _REFACS_25_;}
	O7965[107] =  + _REFACS_24_;
	{long i; for (i = 108; i < 110; i++) O7965[i] =  + _REFACS_25_;}
	{long i; for (i = 110; i < 112; i++) O7965[i] =  + _REFACS_26_;}
	O7965[112] =  + _REFACS_25_;
	O7965[113] =  + _REFACS_26_;
	O7965[114] =  + _REFACS_30_;
	O7965[115] =  + _REFACS_25_;
	O7965[116] =  + _REFACS_28_;
	O7965[117] =  + _REFACS_24_;
	O7965[118] =  + _REFACS_25_;
	O7965[119] =  + _REFACS_28_;
	O7965[120] =  + _REFACS_26_;
	O7965[121] =  + _REFACS_25_;
	O7965[122] =  + _REFACS_24_;
	{long i; for (i = 123; i < 125; i++) O7965[i] =  + _REFACS_25_;}
	{long i; for (i = 125; i < 127; i++) O7965[i] =  + _REFACS_26_;}
	{long i; for (i = 127; i < 129; i++) O7965[i] =  + _REFACS_25_;}
	O7965[129] =  + _REFACS_28_;
	O7965[130] =  + _REFACS_26_;
	O7965[131] =  + _REFACS_30_;
	O7965[132] =  + _REFACS_10_;
	{long i; for (i = 133; i < 135; i++) O7965[i] =  + _REFACS_12_;}
	O7965[135] =  + _REFACS_10_;
	{long i; for (i = 136; i < 140; i++) O7965[i] =  + _REFACS_14_;}
	{long i; for (i = 140; i < 142; i++) O7965[i] =  + _REFACS_10_;}
	{long i; for (i = 142; i < 146; i++) O7965[i] =  + _REFACS_11_;}
	O7965[146] =  + _REFACS_12_;
	{long i; for (i = 147; i < 151; i++) O7965[i] =  + _REFACS_11_;}
	{long i; for (i = 151; i < 154; i++) O7965[i] =  + _REFACS_12_;}
	{long i; for (i = 154; i < 158; i++) O7965[i] =  + _REFACS_14_;}
	O7965[158] = 0;
	O7965[159] =  + _REFACS_25_;
	{long i; for (i = 160; i < 162; i++) O7965[i] = 0;}
	O7965[162] =  + _REFACS_25_;
	O7965[163] = 0;
	O7965[164] =  + _REFACS_25_;
	{long i; for (i = 165; i < 167; i++) O7965[i] = 0;}
	O7965[167] =  + _REFACS_25_;
	{long i; for (i = 168; i < 170; i++) O7965[i] = 0;}
}

static EIF_TYPE_INDEX Y7965_pgtype0[] = {1055,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7965_pgtype1[] = {1055,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7965_pgtype2[] = {1099,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7965_pgtype3[] = {1099,1107,0xFFFF};
static EIF_TYPE_INDEX Y7965_pgtype4[] = {1099,1095,0xFFFF};
static EIF_TYPE_INDEX Y7965_pgtype5[] = {1099,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7965_gen_type [170];
EIF_TYPE_INDEX Y7965 [170];
void Y7965_init (void)
{
	egc_routines_types [7965] = Y7965;
	egc_routines_gen_types [7965] = Y7965_gen_type;
	egc_routines_offset [7965] = 1113;
	Y7965_gen_type [31] = Y7965_pgtype0;
	Y7965_gen_type [32] = Y7965_pgtype1;
	Y7965_gen_type [33] = Y7965_pgtype2;
	Y7965_gen_type [34] = Y7965_pgtype3;
	Y7965_gen_type [35] = Y7965_pgtype4;
	Y7965_gen_type [36] = Y7965_pgtype5;
	Y7965[0] = 1017;
	{long i; for (i = 1; i < 3; i++) Y7965[i] = 1018;};
	{long i; for (i = 3; i < 5; i++) Y7965[i] = 1019;};
	Y7965[5] = 1020;
	{long i; for (i = 6; i < 8; i++) Y7965[i] = 1021;};
	Y7965[8] = 1032;
	{long i; for (i = 9; i < 11; i++) Y7965[i] = 1022;};
	{long i; for (i = 11; i < 13; i++) Y7965[i] = 1023;};
	{long i; for (i = 13; i < 15; i++) Y7965[i] = 1025;};
	Y7965[15] = 1026;
	{long i; for (i = 16; i < 18; i++) Y7965[i] = 1024;};
	{long i; for (i = 18; i < 20; i++) Y7965[i] = 1027;};
	{long i; for (i = 20; i < 22; i++) Y7965[i] = 1028;};
	{long i; for (i = 22; i < 24; i++) Y7965[i] = 1033;};
	{long i; for (i = 24; i < 26; i++) Y7965[i] = 1029;};
	Y7965[26] = 1031;
	{long i; for (i = 27; i < 30; i++) Y7965[i] = 1017;};
	Y7965[30] = 1020;
	{long i; for (i = 31; i < 33; i++) Y7965[i] = 1055;};
	{long i; for (i = 33; i < 37; i++) Y7965[i] = 1099;};
	Y7965[37] = 1109;
	{long i; for (i = 38; i < 40; i++) Y7965[i] = 1035;};
	{long i; for (i = 40; i < 42; i++) Y7965[i] = 1036;};
	Y7965[42] = 1038;
	{long i; for (i = 43; i < 45; i++) Y7965[i] = 1111;};
	Y7965[45] = 1039;
	Y7965[46] = 1041;
	{long i; for (i = 47; i < 49; i++) Y7965[i] = 1037;};
	{long i; for (i = 49; i < 51; i++) Y7965[i] = 1056;};
	{long i; for (i = 51; i < 53; i++) Y7965[i] = 1040;};
	Y7965[53] = 1044;
	Y7965[54] = 1045;
	Y7965[55] = 1053;
	{long i; for (i = 56; i < 58; i++) Y7965[i] = 1042;};
	{long i; for (i = 58; i < 60; i++) Y7965[i] = 1043;};
	{long i; for (i = 60; i < 62; i++) Y7965[i] = 1048;};
	{long i; for (i = 62; i < 65; i++) Y7965[i] = 1046;};
	Y7965[65] = 1026;
	{long i; for (i = 66; i < 68; i++) Y7965[i] = 1052;};
	{long i; for (i = 68; i < 70; i++) Y7965[i] = 1053;};
	{long i; for (i = 70; i < 72; i++) Y7965[i] = 1057;};
	{long i; for (i = 72; i < 74; i++) Y7965[i] = 1058;};
	Y7965[74] = 1059;
	Y7965[75] = 1060;
	Y7965[76] = 1061;
	Y7965[77] = 1059;
	Y7965[78] = 1060;
	Y7965[79] = 1061;
	Y7965[80] = 1062;
	Y7965[81] = 1063;
	Y7965[82] = 1064;
	Y7965[83] = 1062;
	Y7965[84] = 1063;
	Y7965[85] = 1064;
	Y7965[86] = 1065;
	Y7965[87] = 1066;
	{long i; for (i = 88; i < 90; i++) Y7965[i] = 1065;};
	Y7965[90] = 1069;
	Y7965[91] = 1075;
	Y7965[92] = 1070;
	Y7965[93] = 1071;
	Y7965[94] = 1065;
	Y7965[95] = 1066;
	Y7965[96] = 1067;
	Y7965[97] = 1068;
	Y7965[98] = 1069;
	Y7965[99] = 1075;
	Y7965[100] = 1070;
	Y7965[101] = 1071;
	Y7965[102] = 1077;
	Y7965[103] = 1100;
	Y7965[104] = 1106;
	Y7965[105] = 1079;
	Y7965[106] = 1101;
	Y7965[107] = 1080;
	Y7965[108] = 1082;
	Y7965[109] = 1083;
	Y7965[110] = 1102;
	Y7965[111] = 1103;
	Y7965[112] = 1084;
	Y7965[113] = 1085;
	Y7965[114] = 1104;
	Y7965[115] = 1086;
	Y7965[116] = 1087;
	Y7965[117] = 1077;
	Y7965[118] = 1101;
	Y7965[119] = 1100;
	Y7965[120] = 1106;
	Y7965[121] = 1079;
	Y7965[122] = 1080;
	Y7965[123] = 1082;
	Y7965[124] = 1083;
	Y7965[125] = 1102;
	Y7965[126] = 1103;
	Y7965[127] = 1084;
	Y7965[128] = 1086;
	Y7965[129] = 1087;
	Y7965[130] = 1085;
	Y7965[131] = 1104;
	Y7965[132] = 1088;
	{long i; for (i = 133; i < 135; i++) Y7965[i] = 1090;};
	Y7965[135] = 1088;
	Y7965[136] = 1107;
	Y7965[137] = 1108;
	Y7965[138] = 1107;
	Y7965[139] = 1108;
	Y7965[140] = 1088;
	Y7965[141] = 1092;
	Y7965[142] = 1095;
	Y7965[143] = 1096;
	Y7965[144] = 1097;
	Y7965[145] = 1095;
	Y7965[146] = 1110;
	Y7965[147] = 1095;
	Y7965[148] = 1096;
	Y7965[149] = 1097;
	Y7965[150] = 1098;
	Y7965[151] = 1110;
	{long i; for (i = 152; i < 154; i++) Y7965[i] = 1089;};
	Y7965[154] = 1093;
	Y7965[155] = 1094;
	Y7965[156] = 1093;
	Y7965[157] = 1094;
	Y7965[158] = 1049;
	Y7965[159] = 1078;
	Y7965[160] = 1050;
	Y7965[161] = 1051;
	Y7965[162] = 1081;
	Y7965[163] = 1049;
	Y7965[164] = 1078;
	Y7965[165] = 1050;
	Y7965[166] = 1051;
	Y7965[167] = 1081;
	{long i; for (i = 168; i < 170; i++) Y7965[i] = 1112;};
}

long O7966[170];
void O7966_init () {
	{long i; for (i = 0; i < 4; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[4] = + _CHROFF_2_3_;
	{long i; for (i = 5; i < 8; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[8] = + _CHROFF_2_0_;
	O7966[9] = + _CHROFF_2_1_;
	O7966[10] = + _CHROFF_4_1_;
	{long i; for (i = 11; i < 13; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[13] = + _CHROFF_2_1_;
	O7966[14] = + _CHROFF_3_4_;
	{long i; for (i = 15; i < 19; i++) O7966[i] = + _CHROFF_1_0_;}
	{long i; for (i = 19; i < 21; i++) O7966[i] = + _CHROFF_2_0_;}
	O7966[21] = + _CHROFF_3_1_;
	O7966[22] = + _CHROFF_40_8_;
	O7966[23] = + _CHROFF_49_15_;
	O7966[24] = + _CHROFF_1_1_;
	O7966[25] = + _CHROFF_2_1_;
	O7966[26] = + _CHROFF_1_0_;
	O7966[27] = + _CHROFF_2_2_;
	O7966[28] = + _CHROFF_4_2_;
	O7966[29] = + _CHROFF_5_4_;
	O7966[30] = + _CHROFF_10_9_;
	O7966[31] = + _CHROFF_1_0_;
	O7966[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O7966[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O7966[i] = + _CHROFF_2_0_;}
	O7966[37] = + _CHROFF_4_0_;
	O7966[38] = + _CHROFF_1_0_;
	O7966[39] = + _CHROFF_3_0_;
	O7966[40] = + _CHROFF_7_4_;
	O7966[41] = + _CHROFF_8_5_;
	O7966[42] = + _CHROFF_1_0_;
	O7966[43] = + _CHROFF_2_0_;
	O7966[44] = + _CHROFF_6_2_;
	{long i; for (i = 45; i < 49; i++) O7966[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O7966[i] = + _CHROFF_1_1_;}
	{long i; for (i = 51; i < 53; i++) O7966[i] = + _CHROFF_3_1_;}
	{long i; for (i = 53; i < 59; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[59] = + _CHROFF_2_0_;
	O7966[60] = + _CHROFF_1_0_;
	O7966[61] = + _CHROFF_2_0_;
	O7966[62] = + _CHROFF_1_0_;
	O7966[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[66] = + _CHROFF_3_0_;
	O7966[67] = + _CHROFF_8_4_;
	O7966[68] = + _CHROFF_13_3_;
	O7966[69] = + _CHROFF_16_5_;
	O7966[70] = + _CHROFF_35_7_;
	O7966[71] = + _CHROFF_42_10_;
	O7966[72] = + _CHROFF_37_7_;
	O7966[73] = + _CHROFF_46_10_;
	O7966[74] = + _CHROFF_37_7_;
	O7966[75] = + _CHROFF_38_7_;
	O7966[76] = + _CHROFF_37_7_;
	O7966[77] = + _CHROFF_47_10_;
	O7966[78] = + _CHROFF_49_10_;
	O7966[79] = + _CHROFF_47_10_;
	{long i; for (i = 80; i < 83; i++) O7966[i] = + _CHROFF_39_8_;}
	{long i; for (i = 83; i < 86; i++) O7966[i] = + _CHROFF_49_11_;}
	{long i; for (i = 86; i < 90; i++) O7966[i] = + _CHROFF_39_8_;}
	O7966[90] = + _CHROFF_47_10_;
	O7966[91] = + _CHROFF_47_12_;
	O7966[92] = + _CHROFF_50_11_;
	O7966[93] = + _CHROFF_53_11_;
	O7966[94] = + _CHROFF_49_11_;
	O7966[95] = + _CHROFF_51_11_;
	{long i; for (i = 96; i < 98; i++) O7966[i] = + _CHROFF_49_12_;}
	O7966[98] = + _CHROFF_59_19_;
	O7966[99] = + _CHROFF_59_21_;
	O7966[100] = + _CHROFF_65_23_;
	O7966[101] = + _CHROFF_68_24_;
	O7966[102] = + _CHROFF_35_7_;
	O7966[103] = + _CHROFF_43_7_;
	{long i; for (i = 104; i < 106; i++) O7966[i] = + _CHROFF_37_7_;}
	O7966[106] = + _CHROFF_37_8_;
	O7966[107] = + _CHROFF_35_7_;
	{long i; for (i = 108; i < 110; i++) O7966[i] = + _CHROFF_36_7_;}
	O7966[110] = + _CHROFF_37_7_;
	O7966[111] = + _CHROFF_37_8_;
	O7966[112] = + _CHROFF_36_7_;
	O7966[113] = + _CHROFF_37_7_;
	O7966[114] = + _CHROFF_41_7_;
	O7966[115] = + _CHROFF_36_7_;
	O7966[116] = + _CHROFF_40_10_;
	O7966[117] = + _CHROFF_42_11_;
	O7966[118] = + _CHROFF_45_14_;
	O7966[119] = + _CHROFF_58_12_;
	O7966[120] = + _CHROFF_51_11_;
	{long i; for (i = 121; i < 123; i++) O7966[i] = + _CHROFF_44_11_;}
	{long i; for (i = 123; i < 125; i++) O7966[i] = + _CHROFF_46_12_;}
	O7966[125] = + _CHROFF_50_11_;
	O7966[126] = + _CHROFF_51_12_;
	O7966[127] = + _CHROFF_43_11_;
	O7966[128] = + _CHROFF_44_13_;
	O7966[129] = + _CHROFF_51_16_;
	O7966[130] = + _CHROFF_46_12_;
	O7966[131] = + _CHROFF_59_14_;
	O7966[132] = + _CHROFF_16_3_;
	O7966[133] = + _CHROFF_18_3_;
	O7966[134] = + _CHROFF_23_3_;
	O7966[135] = + _CHROFF_16_3_;
	{long i; for (i = 136; i < 138; i++) O7966[i] = + _CHROFF_20_3_;}
	{long i; for (i = 138; i < 140; i++) O7966[i] = + _CHROFF_25_4_;}
	{long i; for (i = 140; i < 142; i++) O7966[i] = + _CHROFF_21_5_;}
	{long i; for (i = 142; i < 146; i++) O7966[i] = + _CHROFF_17_4_;}
	O7966[146] = + _CHROFF_18_4_;
	O7966[147] = + _CHROFF_23_6_;
	{long i; for (i = 148; i < 150; i++) O7966[i] = + _CHROFF_23_7_;}
	O7966[150] = + _CHROFF_24_7_;
	O7966[151] = + _CHROFF_26_6_;
	O7966[152] = + _CHROFF_19_3_;
	O7966[153] = + _CHROFF_22_3_;
	{long i; for (i = 154; i < 156; i++) O7966[i] = + _CHROFF_21_8_;}
	{long i; for (i = 156; i < 158; i++) O7966[i] = + _CHROFF_29_12_;}
	O7966[158] = + _CHROFF_1_0_;
	O7966[159] = + _CHROFF_36_8_;
	{long i; for (i = 160; i < 162; i++) O7966[i] = + _CHROFF_1_0_;}
	O7966[162] = + _CHROFF_36_7_;
	O7966[163] = + _CHROFF_6_2_;
	O7966[164] = + _CHROFF_48_15_;
	O7966[165] = + _CHROFF_6_2_;
	O7966[166] = + _CHROFF_6_4_;
	O7966[167] = + _CHROFF_48_14_;
	{long i; for (i = 168; i < 170; i++) O7966[i] = + _CHROFF_3_0_;}
}

long O8067[160];
void O8067_init () {
	O8067[0] =  + _REFACS_1_;
	{long i; for (i = 62; i < 64; i++) O8067[i] =  + _REFACS_25_;}
	{long i; for (i = 64; i < 67; i++) O8067[i] =  + _REFACS_26_;}
	O8067[67] =  + _REFACS_27_;
	{long i; for (i = 68; i < 70; i++) O8067[i] =  + _REFACS_26_;}
	O8067[70] =  + _REFACS_27_;
	O8067[71] =  + _REFACS_26_;
	{long i; for (i = 72; i < 82; i++) O8067[i] =  + _REFACS_27_;}
	{long i; for (i = 82; i < 84; i++) O8067[i] =  + _REFACS_31_;}
	{long i; for (i = 84; i < 86; i++) O8067[i] =  + _REFACS_34_;}
	{long i; for (i = 86; i < 90; i++) O8067[i] =  + _REFACS_27_;}
	{long i; for (i = 90; i < 92; i++) O8067[i] =  + _REFACS_31_;}
	{long i; for (i = 92; i < 94; i++) O8067[i] =  + _REFACS_34_;}
	O8067[94] =  + _REFACS_25_;
	O8067[95] =  + _REFACS_29_;
	O8067[96] =  + _REFACS_27_;
	{long i; for (i = 97; i < 99; i++) O8067[i] =  + _REFACS_26_;}
	O8067[99] =  + _REFACS_25_;
	{long i; for (i = 100; i < 102; i++) O8067[i] =  + _REFACS_26_;}
	{long i; for (i = 102; i < 104; i++) O8067[i] =  + _REFACS_27_;}
	O8067[104] =  + _REFACS_26_;
	O8067[105] =  + _REFACS_27_;
	O8067[106] =  + _REFACS_31_;
	O8067[107] =  + _REFACS_26_;
	O8067[108] =  + _REFACS_29_;
	O8067[109] =  + _REFACS_25_;
	O8067[110] =  + _REFACS_26_;
	O8067[111] =  + _REFACS_29_;
	O8067[112] =  + _REFACS_27_;
	O8067[113] =  + _REFACS_26_;
	O8067[114] =  + _REFACS_25_;
	{long i; for (i = 115; i < 117; i++) O8067[i] =  + _REFACS_26_;}
	{long i; for (i = 117; i < 119; i++) O8067[i] =  + _REFACS_27_;}
	{long i; for (i = 119; i < 121; i++) O8067[i] =  + _REFACS_26_;}
	O8067[121] =  + _REFACS_29_;
	O8067[122] =  + _REFACS_27_;
	O8067[123] =  + _REFACS_31_;
	O8067[151] =  + _REFACS_26_;
	O8067[154] =  + _REFACS_26_;
	O8067[156] =  + _REFACS_26_;
	O8067[159] =  + _REFACS_26_;
}

long O8497[141];
void O8497_init () {
	O8497[0] = + _PTROFF_2_3_0_1_0_0_;
	O8497[1] = + _PTROFF_4_3_0_1_0_0_;
	O8497[2] = + _PTROFF_5_5_0_1_0_0_;
	O8497[3] = + _PTROFF_10_10_0_9_0_0_;
	O8497[17] = + _PTROFF_6_3_0_2_0_0_;
	O8497[40] = + _PTROFF_8_5_0_1_0_0_;
	O8497[42] = + _PTROFF_16_7_6_1_0_0_;
	O8497[44] = + _PTROFF_42_12_10_6_0_0_;
	O8497[46] = + _PTROFF_46_12_10_6_0_0_;
	O8497[50] = + _PTROFF_47_12_10_7_0_0_;
	O8497[51] = + _PTROFF_49_12_10_10_0_0_;
	O8497[52] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 56; i < 59; i++) O8497[i] = + _PTROFF_49_13_10_7_0_0_;}
	O8497[67] = + _PTROFF_49_13_10_6_0_0_;
	O8497[68] = + _PTROFF_51_13_10_8_0_0_;
	O8497[69] = + _PTROFF_49_14_10_8_0_0_;
	O8497[70] = + _PTROFF_49_14_10_10_0_0_;
	O8497[71] = + _PTROFF_59_21_10_11_0_0_;
	O8497[72] = + _PTROFF_59_23_10_11_0_0_;
	O8497[73] = + _PTROFF_65_25_10_11_0_0_;
	O8497[74] = + _PTROFF_68_26_10_11_0_0_;
	O8497[90] = + _PTROFF_42_13_10_6_0_0_;
	O8497[91] = + _PTROFF_45_16_10_7_0_0_;
	O8497[92] = + _PTROFF_58_14_10_9_0_0_;
	O8497[93] = + _PTROFF_51_13_10_9_0_0_;
	O8497[94] = + _PTROFF_44_13_10_7_0_0_;
	O8497[95] = + _PTROFF_44_13_10_6_1_0_;
	{long i; for (i = 96; i < 98; i++) O8497[i] = + _PTROFF_46_14_10_6_0_0_;}
	O8497[98] = + _PTROFF_50_13_10_9_0_0_;
	O8497[99] = + _PTROFF_51_14_10_9_0_0_;
	O8497[100] = + _PTROFF_43_13_10_6_0_0_;
	O8497[101] = + _PTROFF_44_15_10_6_0_0_;
	O8497[102] = + _PTROFF_51_18_10_10_0_0_;
	O8497[103] = + _PTROFF_46_14_10_7_0_0_;
	O8497[104] = + _PTROFF_59_16_10_12_0_0_;
	{long i; for (i = 113; i < 115; i++) O8497[i] = + _PTROFF_21_7_6_1_0_0_;}
	O8497[120] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 121; i < 123; i++) O8497[i] = + _PTROFF_23_9_6_1_0_0_;}
	O8497[123] = + _PTROFF_24_9_6_1_0_0_;
	O8497[124] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 129; i < 131; i++) O8497[i] = + _PTROFF_29_14_8_2_0_0_;}
	O8497[137] = + _PTROFF_48_19_10_9_0_0_;
	O8497[140] = + _PTROFF_48_18_10_9_0_0_;
}

long O8498[141];
void O8498_init () {
	O8498[0] = + _CHROFF_2_0_;
	O8498[1] = + _CHROFF_4_0_;
	O8498[2] = + _CHROFF_5_0_;
	O8498[3] = + _CHROFF_10_0_;
	O8498[17] = + _CHROFF_6_0_;
	O8498[40] = + _CHROFF_8_0_;
	O8498[42] = + _CHROFF_16_1_;
	O8498[44] = + _CHROFF_42_1_;
	O8498[46] = + _CHROFF_46_1_;
	O8498[50] = + _CHROFF_47_1_;
	O8498[51] = + _CHROFF_49_1_;
	O8498[52] = + _CHROFF_47_1_;
	{long i; for (i = 56; i < 59; i++) O8498[i] = + _CHROFF_49_1_;}
	O8498[67] = + _CHROFF_49_1_;
	O8498[68] = + _CHROFF_51_1_;
	{long i; for (i = 69; i < 71; i++) O8498[i] = + _CHROFF_49_1_;}
	{long i; for (i = 71; i < 73; i++) O8498[i] = + _CHROFF_59_1_;}
	O8498[73] = + _CHROFF_65_1_;
	O8498[74] = + _CHROFF_68_1_;
	O8498[90] = + _CHROFF_42_1_;
	O8498[91] = + _CHROFF_45_1_;
	O8498[92] = + _CHROFF_58_1_;
	O8498[93] = + _CHROFF_51_1_;
	{long i; for (i = 94; i < 96; i++) O8498[i] = + _CHROFF_44_1_;}
	{long i; for (i = 96; i < 98; i++) O8498[i] = + _CHROFF_46_1_;}
	O8498[98] = + _CHROFF_50_1_;
	O8498[99] = + _CHROFF_51_1_;
	O8498[100] = + _CHROFF_43_1_;
	O8498[101] = + _CHROFF_44_1_;
	O8498[102] = + _CHROFF_51_1_;
	O8498[103] = + _CHROFF_46_1_;
	O8498[104] = + _CHROFF_59_1_;
	{long i; for (i = 113; i < 115; i++) O8498[i] = + _CHROFF_21_1_;}
	{long i; for (i = 120; i < 123; i++) O8498[i] = + _CHROFF_23_1_;}
	O8498[123] = + _CHROFF_24_1_;
	O8498[124] = + _CHROFF_26_1_;
	{long i; for (i = 129; i < 131; i++) O8498[i] = + _CHROFF_29_1_;}
	O8498[137] = + _CHROFF_48_1_;
	O8498[140] = + _CHROFF_48_1_;
}

long O8509[141];
void O8509_init () {
	{long i; for (i = 0; i < 4; i++) O8509[i] =  + _REFACS_1_;}
	O8509[17] =  + _REFACS_2_;
	O8509[40] =  + _REFACS_3_;
	O8509[42] =  + _REFACS_8_;
	O8509[44] =  + _REFACS_26_;
	O8509[46] =  + _REFACS_27_;
	O8509[50] =  + _REFACS_27_;
	O8509[51] =  + _REFACS_28_;
	O8509[52] =  + _REFACS_27_;
	{long i; for (i = 56; i < 59; i++) O8509[i] =  + _REFACS_28_;}
	{long i; for (i = 67; i < 71; i++) O8509[i] =  + _REFACS_28_;}
	{long i; for (i = 71; i < 73; i++) O8509[i] =  + _REFACS_32_;}
	{long i; for (i = 73; i < 75; i++) O8509[i] =  + _REFACS_35_;}
	O8509[90] =  + _REFACS_26_;
	O8509[91] =  + _REFACS_27_;
	O8509[92] =  + _REFACS_30_;
	O8509[93] =  + _REFACS_28_;
	O8509[94] =  + _REFACS_27_;
	O8509[95] =  + _REFACS_26_;
	{long i; for (i = 96; i < 98; i++) O8509[i] =  + _REFACS_27_;}
	{long i; for (i = 98; i < 100; i++) O8509[i] =  + _REFACS_28_;}
	{long i; for (i = 100; i < 102; i++) O8509[i] =  + _REFACS_27_;}
	O8509[102] =  + _REFACS_30_;
	O8509[103] =  + _REFACS_28_;
	O8509[104] =  + _REFACS_32_;
	{long i; for (i = 113; i < 115; i++) O8509[i] =  + _REFACS_11_;}
	{long i; for (i = 120; i < 124; i++) O8509[i] =  + _REFACS_12_;}
	O8509[124] =  + _REFACS_13_;
	{long i; for (i = 129; i < 131; i++) O8509[i] =  + _REFACS_15_;}
	O8509[137] =  + _REFACS_27_;
	O8509[140] =  + _REFACS_27_;
}

long O8511[141];
void O8511_init () {
	O8511[0] = + _CHROFF_2_1_;
	O8511[1] = + _CHROFF_4_1_;
	O8511[2] = + _CHROFF_5_1_;
	O8511[3] = + _CHROFF_10_1_;
	O8511[17] = + _CHROFF_6_1_;
	O8511[40] = + _CHROFF_8_1_;
	O8511[42] = + _CHROFF_16_2_;
	O8511[44] = + _CHROFF_42_2_;
	O8511[46] = + _CHROFF_46_2_;
	O8511[50] = + _CHROFF_47_2_;
	O8511[51] = + _CHROFF_49_2_;
	O8511[52] = + _CHROFF_47_2_;
	{long i; for (i = 56; i < 59; i++) O8511[i] = + _CHROFF_49_2_;}
	O8511[67] = + _CHROFF_49_2_;
	O8511[68] = + _CHROFF_51_2_;
	{long i; for (i = 69; i < 71; i++) O8511[i] = + _CHROFF_49_2_;}
	{long i; for (i = 71; i < 73; i++) O8511[i] = + _CHROFF_59_2_;}
	O8511[73] = + _CHROFF_65_2_;
	O8511[74] = + _CHROFF_68_2_;
	O8511[90] = + _CHROFF_42_2_;
	O8511[91] = + _CHROFF_45_2_;
	O8511[92] = + _CHROFF_58_2_;
	O8511[93] = + _CHROFF_51_2_;
	{long i; for (i = 94; i < 96; i++) O8511[i] = + _CHROFF_44_2_;}
	{long i; for (i = 96; i < 98; i++) O8511[i] = + _CHROFF_46_2_;}
	O8511[98] = + _CHROFF_50_2_;
	O8511[99] = + _CHROFF_51_2_;
	O8511[100] = + _CHROFF_43_2_;
	O8511[101] = + _CHROFF_44_2_;
	O8511[102] = + _CHROFF_51_2_;
	O8511[103] = + _CHROFF_46_2_;
	O8511[104] = + _CHROFF_59_2_;
	{long i; for (i = 113; i < 115; i++) O8511[i] = + _CHROFF_21_2_;}
	{long i; for (i = 120; i < 123; i++) O8511[i] = + _CHROFF_23_2_;}
	O8511[123] = + _CHROFF_24_2_;
	O8511[124] = + _CHROFF_26_2_;
	{long i; for (i = 129; i < 131; i++) O8511[i] = + _CHROFF_29_2_;}
	O8511[137] = + _CHROFF_48_2_;
	O8511[140] = + _CHROFF_48_2_;
}

long O8543[140];
void O8543_init () {
	{long i; for (i = 0; i < 3; i++) O8543[i] =  + _REFACS_2_;}
	O8543[39] =  + _REFACS_4_;
	O8543[41] =  + _REFACS_9_;
	O8543[43] =  + _REFACS_27_;
	O8543[45] =  + _REFACS_28_;
	O8543[49] =  + _REFACS_28_;
	O8543[50] =  + _REFACS_29_;
	O8543[51] =  + _REFACS_28_;
	{long i; for (i = 55; i < 58; i++) O8543[i] =  + _REFACS_29_;}
	{long i; for (i = 66; i < 70; i++) O8543[i] =  + _REFACS_29_;}
	{long i; for (i = 70; i < 72; i++) O8543[i] =  + _REFACS_33_;}
	{long i; for (i = 72; i < 74; i++) O8543[i] =  + _REFACS_36_;}
	O8543[89] =  + _REFACS_27_;
	O8543[90] =  + _REFACS_28_;
	O8543[91] =  + _REFACS_31_;
	O8543[92] =  + _REFACS_29_;
	O8543[93] =  + _REFACS_28_;
	O8543[94] =  + _REFACS_27_;
	{long i; for (i = 95; i < 97; i++) O8543[i] =  + _REFACS_28_;}
	{long i; for (i = 97; i < 99; i++) O8543[i] =  + _REFACS_29_;}
	{long i; for (i = 99; i < 101; i++) O8543[i] =  + _REFACS_28_;}
	O8543[101] =  + _REFACS_31_;
	O8543[102] =  + _REFACS_29_;
	O8543[103] =  + _REFACS_33_;
	{long i; for (i = 112; i < 114; i++) O8543[i] =  + _REFACS_12_;}
	{long i; for (i = 119; i < 123; i++) O8543[i] =  + _REFACS_13_;}
	O8543[123] =  + _REFACS_14_;
	{long i; for (i = 128; i < 130; i++) O8543[i] =  + _REFACS_16_;}
	O8543[136] =  + _REFACS_28_;
	O8543[139] =  + _REFACS_28_;
}

long O8544[140];
void O8544_init () {
	{long i; for (i = 0; i < 3; i++) O8544[i] =  + _REFACS_3_;}
	O8544[39] =  + _REFACS_5_;
	O8544[41] =  + _REFACS_10_;
	O8544[43] =  + _REFACS_28_;
	O8544[45] =  + _REFACS_29_;
	O8544[49] =  + _REFACS_29_;
	O8544[50] =  + _REFACS_30_;
	O8544[51] =  + _REFACS_29_;
	{long i; for (i = 55; i < 58; i++) O8544[i] =  + _REFACS_30_;}
	{long i; for (i = 66; i < 70; i++) O8544[i] =  + _REFACS_30_;}
	{long i; for (i = 70; i < 72; i++) O8544[i] =  + _REFACS_34_;}
	{long i; for (i = 72; i < 74; i++) O8544[i] =  + _REFACS_37_;}
	O8544[89] =  + _REFACS_28_;
	O8544[90] =  + _REFACS_29_;
	O8544[91] =  + _REFACS_32_;
	O8544[92] =  + _REFACS_30_;
	O8544[93] =  + _REFACS_29_;
	O8544[94] =  + _REFACS_28_;
	{long i; for (i = 95; i < 97; i++) O8544[i] =  + _REFACS_29_;}
	{long i; for (i = 97; i < 99; i++) O8544[i] =  + _REFACS_30_;}
	{long i; for (i = 99; i < 101; i++) O8544[i] =  + _REFACS_29_;}
	O8544[101] =  + _REFACS_32_;
	O8544[102] =  + _REFACS_30_;
	O8544[103] =  + _REFACS_34_;
	{long i; for (i = 112; i < 114; i++) O8544[i] =  + _REFACS_13_;}
	{long i; for (i = 119; i < 123; i++) O8544[i] =  + _REFACS_14_;}
	O8544[123] =  + _REFACS_15_;
	{long i; for (i = 128; i < 130; i++) O8544[i] =  + _REFACS_17_;}
	O8544[136] =  + _REFACS_29_;
	O8544[139] =  + _REFACS_29_;
}

long O8564[73];
void O8564_init () {
	{long i; for (i = 0; i < 2; i++) O8564[i] =  + _REFACS_4_;}
	O8564[38] =  + _REFACS_6_;
	{long i; for (i = 69; i < 71; i++) O8564[i] =  + _REFACS_35_;}
	{long i; for (i = 71; i < 73; i++) O8564[i] =  + _REFACS_38_;}
}

long O8571[73];
void O8571_init () {
	O8571[0] = + _CHROFF_5_2_;
	O8571[1] = + _CHROFF_10_2_;
	O8571[38] = + _CHROFF_8_2_;
	{long i; for (i = 69; i < 71; i++) O8571[i] = + _CHROFF_59_3_;}
	O8571[71] = + _CHROFF_65_3_;
	O8571[72] = + _CHROFF_68_3_;
}

long O8577[73];
void O8577_init () {
	O8577[0] = + _CHROFF_5_3_;
	O8577[1] = + _CHROFF_10_3_;
	O8577[38] = + _CHROFF_8_3_;
	{long i; for (i = 69; i < 71; i++) O8577[i] = + _CHROFF_59_4_;}
	O8577[71] = + _CHROFF_65_4_;
	O8577[72] = + _CHROFF_68_4_;
}

long O8621[121];
void O8621_init () {
	O8621[0] = + _LNGOFF_1_1_0_0_;
	O8621[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O8621[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O8621[i] = + _LNGOFF_2_1_0_0_;}
	O8621[6] = + _LNGOFF_4_1_0_0_;
	O8621[12] = + _LNGOFF_2_1_0_0_;
	O8621[13] = + _LNGOFF_6_3_0_1_;
	O8621[43] = + _LNGOFF_37_9_6_0_;
	O8621[44] = + _LNGOFF_38_9_6_0_;
	O8621[45] = + _LNGOFF_37_9_6_0_;
	O8621[46] = + _LNGOFF_47_12_10_1_;
	O8621[47] = + _LNGOFF_49_12_10_1_;
	O8621[48] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 49; i < 52; i++) O8621[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 52; i < 55; i++) O8621[i] = + _LNGOFF_49_13_10_1_;}
	O8621[72] = + _LNGOFF_43_9_6_0_;
	O8621[73] = + _LNGOFF_37_9_6_0_;
	O8621[75] = + _LNGOFF_37_10_6_0_;
	O8621[79] = + _LNGOFF_37_9_6_0_;
	O8621[80] = + _LNGOFF_37_10_6_0_;
	O8621[83] = + _LNGOFF_41_9_6_0_;
	O8621[87] = + _LNGOFF_45_16_10_1_;
	O8621[88] = + _LNGOFF_58_14_10_1_;
	O8621[89] = + _LNGOFF_51_13_10_1_;
	O8621[94] = + _LNGOFF_50_13_10_1_;
	O8621[95] = + _LNGOFF_51_14_10_1_;
	O8621[100] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 105; i < 107; i++) O8621[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 107; i < 109; i++) O8621[i] = + _LNGOFF_25_6_6_0_;}
	O8621[115] = + _LNGOFF_18_6_6_0_;
	O8621[120] = + _LNGOFF_26_8_6_1_;
}

long O8655[120];
void O8655_init () {
	O8655[0] =  + _REFACS_1_;
	O8655[4] =  + _REFACS_1_;
	O8655[5] =  + _REFACS_2_;
	O8655[12] =  + _REFACS_3_;
	O8655[45] =  + _REFACS_30_;
	O8655[46] =  + _REFACS_31_;
	O8655[47] =  + _REFACS_30_;
	{long i; for (i = 51; i < 54; i++) O8655[i] =  + _REFACS_31_;}
	O8655[86] =  + _REFACS_30_;
	O8655[87] =  + _REFACS_33_;
	O8655[88] =  + _REFACS_31_;
	{long i; for (i = 93; i < 95; i++) O8655[i] =  + _REFACS_31_;}
	O8655[99] =  + _REFACS_35_;
	{long i; for (i = 106; i < 108; i++) O8655[i] =  + _REFACS_15_;}
	O8655[119] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y8655_pgtype0[] = {618,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype1[] = {618,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype2[] = {618,1095,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype3[] = {618,1095,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype4[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype5[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype6[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype7[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype8[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype9[] = {618,1057,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype10[] = {618,1091,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype11[] = {618,1089,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype12[] = {618,1107,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype13[] = {618,1090,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype14[] = {618,1090,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype15[] = {618,1090,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype16[] = {618,1107,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype17[] = {618,1107,0xFFFF};
static EIF_TYPE_INDEX Y8655_pgtype18[] = {618,1095,0xFFFF};
EIF_TYPE_INDEX *Y8655_gen_type [120];
EIF_TYPE_INDEX Y8655 [120];
void Y8655_init (void)
{
	egc_routines_types [8655] = Y8655;
	egc_routines_gen_types [8655] = Y8655_gen_type;
	egc_routines_offset [8655] = 1145;
	Y8655_gen_type [0] = Y8655_pgtype0;
	Y8655_gen_type [4] = Y8655_pgtype1;
	Y8655_gen_type [5] = Y8655_pgtype2;
	Y8655_gen_type [12] = Y8655_pgtype3;
	Y8655_gen_type [45] = Y8655_pgtype4;
	Y8655_gen_type [46] = Y8655_pgtype5;
	Y8655_gen_type [47] = Y8655_pgtype6;
	Y8655_gen_type [51] = Y8655_pgtype7;
	Y8655_gen_type [52] = Y8655_pgtype8;
	Y8655_gen_type [53] = Y8655_pgtype9;
	Y8655_gen_type [86] = Y8655_pgtype10;
	Y8655_gen_type [87] = Y8655_pgtype11;
	Y8655_gen_type [88] = Y8655_pgtype12;
	Y8655_gen_type [93] = Y8655_pgtype13;
	Y8655_gen_type [94] = Y8655_pgtype14;
	Y8655_gen_type [99] = Y8655_pgtype15;
	Y8655_gen_type [106] = Y8655_pgtype16;
	Y8655_gen_type [107] = Y8655_pgtype17;
	Y8655_gen_type [119] = Y8655_pgtype18;
	Y8655[0] = 618;
	{long i; for (i = 4; i < 6; i++) Y8655[i] = 618;};
	Y8655[12] = 618;
	{long i; for (i = 45; i < 48; i++) Y8655[i] = 618;};
	{long i; for (i = 51; i < 54; i++) Y8655[i] = 618;};
	{long i; for (i = 86; i < 89; i++) Y8655[i] = 618;};
	{long i; for (i = 93; i < 95; i++) Y8655[i] = 618;};
	Y8655[99] = 618;
	{long i; for (i = 106; i < 108; i++) Y8655[i] = 618;};
	Y8655[119] = 618;
}

long O8692[129];
void O8692_init () {
	O8692[0] =  + _REFACS_1_;
	O8692[32] =  + _REFACS_29_;
	O8692[34] =  + _REFACS_30_;
	O8692[38] =  + _REFACS_31_;
	O8692[39] =  + _REFACS_32_;
	O8692[40] =  + _REFACS_31_;
	{long i; for (i = 44; i < 47; i++) O8692[i] =  + _REFACS_32_;}
	{long i; for (i = 55; i < 59; i++) O8692[i] =  + _REFACS_31_;}
	{long i; for (i = 59; i < 61; i++) O8692[i] =  + _REFACS_36_;}
	{long i; for (i = 61; i < 63; i++) O8692[i] =  + _REFACS_39_;}
	O8692[78] =  + _REFACS_29_;
	O8692[79] =  + _REFACS_31_;
	O8692[80] =  + _REFACS_34_;
	O8692[81] =  + _REFACS_32_;
	O8692[82] =  + _REFACS_30_;
	O8692[83] =  + _REFACS_29_;
	{long i; for (i = 84; i < 86; i++) O8692[i] =  + _REFACS_30_;}
	{long i; for (i = 86; i < 88; i++) O8692[i] =  + _REFACS_32_;}
	{long i; for (i = 88; i < 90; i++) O8692[i] =  + _REFACS_30_;}
	O8692[90] =  + _REFACS_33_;
	O8692[91] =  + _REFACS_31_;
	O8692[92] =  + _REFACS_36_;
	O8692[125] =  + _REFACS_30_;
	O8692[128] =  + _REFACS_30_;
}

long O8693[129];
void O8693_init () {
	O8693[0] =  + _REFACS_2_;
	O8693[32] =  + _REFACS_30_;
	O8693[34] =  + _REFACS_31_;
	O8693[38] =  + _REFACS_32_;
	O8693[39] =  + _REFACS_33_;
	O8693[40] =  + _REFACS_32_;
	{long i; for (i = 44; i < 47; i++) O8693[i] =  + _REFACS_33_;}
	{long i; for (i = 55; i < 59; i++) O8693[i] =  + _REFACS_32_;}
	{long i; for (i = 59; i < 61; i++) O8693[i] =  + _REFACS_37_;}
	{long i; for (i = 61; i < 63; i++) O8693[i] =  + _REFACS_40_;}
	O8693[78] =  + _REFACS_30_;
	O8693[79] =  + _REFACS_32_;
	O8693[80] =  + _REFACS_35_;
	O8693[81] =  + _REFACS_33_;
	O8693[82] =  + _REFACS_31_;
	O8693[83] =  + _REFACS_30_;
	{long i; for (i = 84; i < 86; i++) O8693[i] =  + _REFACS_31_;}
	{long i; for (i = 86; i < 88; i++) O8693[i] =  + _REFACS_33_;}
	{long i; for (i = 88; i < 90; i++) O8693[i] =  + _REFACS_31_;}
	O8693[90] =  + _REFACS_34_;
	O8693[91] =  + _REFACS_32_;
	O8693[92] =  + _REFACS_37_;
	O8693[125] =  + _REFACS_31_;
	O8693[128] =  + _REFACS_31_;
}

long O8701[128];
void O8701_init () {
	{long i; for (i = 0; i < 2; i++) O8701[i] =  + _REFACS_6_;}
	O8701[30] =  + _REFACS_26_;
	O8701[31] =  + _REFACS_31_;
	O8701[32] =  + _REFACS_27_;
	O8701[33] =  + _REFACS_32_;
	O8701[34] =  + _REFACS_27_;
	O8701[35] =  + _REFACS_28_;
	O8701[36] =  + _REFACS_27_;
	O8701[37] =  + _REFACS_33_;
	O8701[38] =  + _REFACS_34_;
	O8701[39] =  + _REFACS_33_;
	{long i; for (i = 40; i < 43; i++) O8701[i] =  + _REFACS_28_;}
	{long i; for (i = 43; i < 46; i++) O8701[i] =  + _REFACS_34_;}
	{long i; for (i = 46; i < 50; i++) O8701[i] =  + _REFACS_28_;}
	{long i; for (i = 50; i < 52; i++) O8701[i] =  + _REFACS_32_;}
	{long i; for (i = 52; i < 54; i++) O8701[i] =  + _REFACS_35_;}
	{long i; for (i = 54; i < 58; i++) O8701[i] =  + _REFACS_33_;}
	{long i; for (i = 58; i < 60; i++) O8701[i] =  + _REFACS_38_;}
	{long i; for (i = 60; i < 62; i++) O8701[i] =  + _REFACS_41_;}
	O8701[62] =  + _REFACS_26_;
	O8701[63] =  + _REFACS_30_;
	O8701[64] =  + _REFACS_28_;
	{long i; for (i = 65; i < 67; i++) O8701[i] =  + _REFACS_27_;}
	O8701[67] =  + _REFACS_26_;
	{long i; for (i = 68; i < 70; i++) O8701[i] =  + _REFACS_27_;}
	{long i; for (i = 70; i < 72; i++) O8701[i] =  + _REFACS_28_;}
	O8701[72] =  + _REFACS_27_;
	O8701[73] =  + _REFACS_28_;
	O8701[74] =  + _REFACS_32_;
	O8701[75] =  + _REFACS_27_;
	O8701[76] =  + _REFACS_30_;
	O8701[77] =  + _REFACS_31_;
	O8701[78] =  + _REFACS_33_;
	O8701[79] =  + _REFACS_36_;
	O8701[80] =  + _REFACS_34_;
	O8701[81] =  + _REFACS_32_;
	O8701[82] =  + _REFACS_31_;
	{long i; for (i = 83; i < 85; i++) O8701[i] =  + _REFACS_32_;}
	{long i; for (i = 85; i < 87; i++) O8701[i] =  + _REFACS_34_;}
	{long i; for (i = 87; i < 89; i++) O8701[i] =  + _REFACS_32_;}
	O8701[89] =  + _REFACS_35_;
	O8701[90] =  + _REFACS_33_;
	O8701[91] =  + _REFACS_38_;
	{long i; for (i = 114; i < 116; i++) O8701[i] =  + _REFACS_15_;}
	{long i; for (i = 116; i < 118; i++) O8701[i] =  + _REFACS_18_;}
	O8701[119] =  + _REFACS_27_;
	O8701[122] =  + _REFACS_27_;
	O8701[124] =  + _REFACS_32_;
	O8701[127] =  + _REFACS_32_;
}

long O8702[128];
void O8702_init () {
	O8702[0] = + _CHROFF_7_1_;
	O8702[1] = + _CHROFF_8_1_;
	O8702[30] = + _CHROFF_35_1_;
	O8702[31] = + _CHROFF_42_3_;
	O8702[32] = + _CHROFF_37_1_;
	O8702[33] = + _CHROFF_46_3_;
	O8702[34] = + _CHROFF_37_1_;
	O8702[35] = + _CHROFF_38_1_;
	O8702[36] = + _CHROFF_37_1_;
	O8702[37] = + _CHROFF_47_3_;
	O8702[38] = + _CHROFF_49_3_;
	O8702[39] = + _CHROFF_47_3_;
	{long i; for (i = 40; i < 43; i++) O8702[i] = + _CHROFF_39_1_;}
	{long i; for (i = 43; i < 46; i++) O8702[i] = + _CHROFF_49_3_;}
	{long i; for (i = 46; i < 50; i++) O8702[i] = + _CHROFF_39_1_;}
	{long i; for (i = 50; i < 52; i++) O8702[i] = + _CHROFF_47_1_;}
	O8702[52] = + _CHROFF_50_1_;
	O8702[53] = + _CHROFF_53_1_;
	O8702[54] = + _CHROFF_49_3_;
	O8702[55] = + _CHROFF_51_3_;
	{long i; for (i = 56; i < 58; i++) O8702[i] = + _CHROFF_49_3_;}
	{long i; for (i = 58; i < 60; i++) O8702[i] = + _CHROFF_59_5_;}
	O8702[60] = + _CHROFF_65_5_;
	O8702[61] = + _CHROFF_68_5_;
	O8702[62] = + _CHROFF_35_1_;
	O8702[63] = + _CHROFF_43_1_;
	{long i; for (i = 64; i < 67; i++) O8702[i] = + _CHROFF_37_1_;}
	O8702[67] = + _CHROFF_35_1_;
	{long i; for (i = 68; i < 70; i++) O8702[i] = + _CHROFF_36_1_;}
	{long i; for (i = 70; i < 72; i++) O8702[i] = + _CHROFF_37_1_;}
	O8702[72] = + _CHROFF_36_1_;
	O8702[73] = + _CHROFF_37_1_;
	O8702[74] = + _CHROFF_41_1_;
	O8702[75] = + _CHROFF_36_1_;
	O8702[76] = + _CHROFF_40_1_;
	O8702[77] = + _CHROFF_42_3_;
	O8702[78] = + _CHROFF_45_3_;
	O8702[79] = + _CHROFF_58_3_;
	O8702[80] = + _CHROFF_51_3_;
	{long i; for (i = 81; i < 83; i++) O8702[i] = + _CHROFF_44_3_;}
	{long i; for (i = 83; i < 85; i++) O8702[i] = + _CHROFF_46_3_;}
	O8702[85] = + _CHROFF_50_3_;
	O8702[86] = + _CHROFF_51_3_;
	O8702[87] = + _CHROFF_43_3_;
	O8702[88] = + _CHROFF_44_3_;
	O8702[89] = + _CHROFF_51_3_;
	O8702[90] = + _CHROFF_46_3_;
	O8702[91] = + _CHROFF_59_3_;
	{long i; for (i = 114; i < 116; i++) O8702[i] = + _CHROFF_21_1_;}
	{long i; for (i = 116; i < 118; i++) O8702[i] = + _CHROFF_29_3_;}
	O8702[119] = + _CHROFF_36_1_;
	O8702[122] = + _CHROFF_36_1_;
	O8702[124] = + _CHROFF_48_3_;
	O8702[127] = + _CHROFF_48_3_;
}

long O8703[128];
void O8703_init () {
	O8703[0] = + _CHROFF_7_2_;
	O8703[1] = + _CHROFF_8_2_;
	O8703[30] = + _CHROFF_35_2_;
	O8703[31] = + _CHROFF_42_4_;
	O8703[32] = + _CHROFF_37_2_;
	O8703[33] = + _CHROFF_46_4_;
	O8703[34] = + _CHROFF_37_2_;
	O8703[35] = + _CHROFF_38_2_;
	O8703[36] = + _CHROFF_37_2_;
	O8703[37] = + _CHROFF_47_4_;
	O8703[38] = + _CHROFF_49_4_;
	O8703[39] = + _CHROFF_47_4_;
	{long i; for (i = 40; i < 43; i++) O8703[i] = + _CHROFF_39_2_;}
	{long i; for (i = 43; i < 46; i++) O8703[i] = + _CHROFF_49_4_;}
	{long i; for (i = 46; i < 50; i++) O8703[i] = + _CHROFF_39_2_;}
	{long i; for (i = 50; i < 52; i++) O8703[i] = + _CHROFF_47_2_;}
	O8703[52] = + _CHROFF_50_2_;
	O8703[53] = + _CHROFF_53_2_;
	O8703[54] = + _CHROFF_49_4_;
	O8703[55] = + _CHROFF_51_4_;
	{long i; for (i = 56; i < 58; i++) O8703[i] = + _CHROFF_49_4_;}
	{long i; for (i = 58; i < 60; i++) O8703[i] = + _CHROFF_59_6_;}
	O8703[60] = + _CHROFF_65_6_;
	O8703[61] = + _CHROFF_68_6_;
	O8703[62] = + _CHROFF_35_2_;
	O8703[63] = + _CHROFF_43_2_;
	{long i; for (i = 64; i < 67; i++) O8703[i] = + _CHROFF_37_2_;}
	O8703[67] = + _CHROFF_35_2_;
	{long i; for (i = 68; i < 70; i++) O8703[i] = + _CHROFF_36_2_;}
	{long i; for (i = 70; i < 72; i++) O8703[i] = + _CHROFF_37_2_;}
	O8703[72] = + _CHROFF_36_2_;
	O8703[73] = + _CHROFF_37_2_;
	O8703[74] = + _CHROFF_41_2_;
	O8703[75] = + _CHROFF_36_2_;
	O8703[76] = + _CHROFF_40_2_;
	O8703[77] = + _CHROFF_42_4_;
	O8703[78] = + _CHROFF_45_4_;
	O8703[79] = + _CHROFF_58_4_;
	O8703[80] = + _CHROFF_51_4_;
	{long i; for (i = 81; i < 83; i++) O8703[i] = + _CHROFF_44_4_;}
	{long i; for (i = 83; i < 85; i++) O8703[i] = + _CHROFF_46_4_;}
	O8703[85] = + _CHROFF_50_4_;
	O8703[86] = + _CHROFF_51_4_;
	O8703[87] = + _CHROFF_43_4_;
	O8703[88] = + _CHROFF_44_4_;
	O8703[89] = + _CHROFF_51_4_;
	O8703[90] = + _CHROFF_46_4_;
	O8703[91] = + _CHROFF_59_4_;
	{long i; for (i = 114; i < 116; i++) O8703[i] = + _CHROFF_21_2_;}
	{long i; for (i = 116; i < 118; i++) O8703[i] = + _CHROFF_29_4_;}
	O8703[119] = + _CHROFF_36_2_;
	O8703[122] = + _CHROFF_36_2_;
	O8703[124] = + _CHROFF_48_4_;
	O8703[127] = + _CHROFF_48_4_;
}

long O8705[128];
void O8705_init () {
	O8705[0] = + _CHROFF_7_3_;
	O8705[1] = + _CHROFF_8_3_;
	O8705[30] = + _CHROFF_35_3_;
	O8705[31] = + _CHROFF_42_5_;
	O8705[32] = + _CHROFF_37_3_;
	O8705[33] = + _CHROFF_46_5_;
	O8705[34] = + _CHROFF_37_3_;
	O8705[35] = + _CHROFF_38_3_;
	O8705[36] = + _CHROFF_37_3_;
	O8705[37] = + _CHROFF_47_5_;
	O8705[38] = + _CHROFF_49_5_;
	O8705[39] = + _CHROFF_47_5_;
	{long i; for (i = 40; i < 43; i++) O8705[i] = + _CHROFF_39_3_;}
	{long i; for (i = 43; i < 46; i++) O8705[i] = + _CHROFF_49_5_;}
	{long i; for (i = 46; i < 50; i++) O8705[i] = + _CHROFF_39_3_;}
	{long i; for (i = 50; i < 52; i++) O8705[i] = + _CHROFF_47_3_;}
	O8705[52] = + _CHROFF_50_3_;
	O8705[53] = + _CHROFF_53_3_;
	O8705[54] = + _CHROFF_49_5_;
	O8705[55] = + _CHROFF_51_5_;
	{long i; for (i = 56; i < 58; i++) O8705[i] = + _CHROFF_49_5_;}
	{long i; for (i = 58; i < 60; i++) O8705[i] = + _CHROFF_59_7_;}
	O8705[60] = + _CHROFF_65_7_;
	O8705[61] = + _CHROFF_68_7_;
	O8705[62] = + _CHROFF_35_3_;
	O8705[63] = + _CHROFF_43_3_;
	{long i; for (i = 64; i < 67; i++) O8705[i] = + _CHROFF_37_3_;}
	O8705[67] = + _CHROFF_35_3_;
	{long i; for (i = 68; i < 70; i++) O8705[i] = + _CHROFF_36_3_;}
	{long i; for (i = 70; i < 72; i++) O8705[i] = + _CHROFF_37_3_;}
	O8705[72] = + _CHROFF_36_3_;
	O8705[73] = + _CHROFF_37_3_;
	O8705[74] = + _CHROFF_41_3_;
	O8705[75] = + _CHROFF_36_3_;
	O8705[76] = + _CHROFF_40_3_;
	O8705[77] = + _CHROFF_42_5_;
	O8705[78] = + _CHROFF_45_5_;
	O8705[79] = + _CHROFF_58_5_;
	O8705[80] = + _CHROFF_51_5_;
	{long i; for (i = 81; i < 83; i++) O8705[i] = + _CHROFF_44_5_;}
	{long i; for (i = 83; i < 85; i++) O8705[i] = + _CHROFF_46_5_;}
	O8705[85] = + _CHROFF_50_5_;
	O8705[86] = + _CHROFF_51_5_;
	O8705[87] = + _CHROFF_43_5_;
	O8705[88] = + _CHROFF_44_5_;
	O8705[89] = + _CHROFF_51_5_;
	O8705[90] = + _CHROFF_46_5_;
	O8705[91] = + _CHROFF_59_5_;
	{long i; for (i = 114; i < 116; i++) O8705[i] = + _CHROFF_21_3_;}
	{long i; for (i = 116; i < 118; i++) O8705[i] = + _CHROFF_29_5_;}
	O8705[119] = + _CHROFF_36_3_;
	O8705[122] = + _CHROFF_36_3_;
	O8705[124] = + _CHROFF_48_5_;
	O8705[127] = + _CHROFF_48_5_;
}

long O8734[127];
void O8734_init () {
	O8734[0] = + _CHROFF_8_4_;
	O8734[30] = + _CHROFF_42_6_;
	O8734[32] = + _CHROFF_46_6_;
	O8734[36] = + _CHROFF_47_6_;
	O8734[37] = + _CHROFF_49_6_;
	O8734[38] = + _CHROFF_47_6_;
	{long i; for (i = 42; i < 45; i++) O8734[i] = + _CHROFF_49_6_;}
	O8734[53] = + _CHROFF_49_6_;
	O8734[54] = + _CHROFF_51_6_;
	{long i; for (i = 55; i < 57; i++) O8734[i] = + _CHROFF_49_6_;}
	{long i; for (i = 57; i < 59; i++) O8734[i] = + _CHROFF_59_8_;}
	O8734[59] = + _CHROFF_65_8_;
	O8734[60] = + _CHROFF_68_8_;
	O8734[76] = + _CHROFF_42_6_;
	O8734[77] = + _CHROFF_45_6_;
	O8734[78] = + _CHROFF_58_6_;
	O8734[79] = + _CHROFF_51_6_;
	{long i; for (i = 80; i < 82; i++) O8734[i] = + _CHROFF_44_6_;}
	{long i; for (i = 82; i < 84; i++) O8734[i] = + _CHROFF_46_6_;}
	O8734[84] = + _CHROFF_50_6_;
	O8734[85] = + _CHROFF_51_6_;
	O8734[86] = + _CHROFF_43_6_;
	O8734[87] = + _CHROFF_44_6_;
	O8734[88] = + _CHROFF_51_6_;
	O8734[89] = + _CHROFF_46_6_;
	O8734[90] = + _CHROFF_59_6_;
	{long i; for (i = 115; i < 117; i++) O8734[i] = + _CHROFF_29_6_;}
	O8734[123] = + _CHROFF_48_6_;
	O8734[126] = + _CHROFF_48_6_;
}

long O8735[127];
void O8735_init () {
	O8735[0] = + _I16OFF_8_6_4_;
	O8735[30] = + _I16OFF_42_12_4_;
	O8735[32] = + _I16OFF_46_12_4_;
	O8735[36] = + _I16OFF_47_12_4_;
	O8735[37] = + _I16OFF_49_12_4_;
	O8735[38] = + _I16OFF_47_12_4_;
	{long i; for (i = 42; i < 45; i++) O8735[i] = + _I16OFF_49_13_4_;}
	O8735[53] = + _I16OFF_49_13_4_;
	O8735[54] = + _I16OFF_51_13_4_;
	{long i; for (i = 55; i < 57; i++) O8735[i] = + _I16OFF_49_14_4_;}
	O8735[57] = + _I16OFF_59_21_4_;
	O8735[58] = + _I16OFF_59_23_4_;
	O8735[59] = + _I16OFF_65_25_4_;
	O8735[60] = + _I16OFF_68_26_4_;
	O8735[76] = + _I16OFF_42_13_4_;
	O8735[77] = + _I16OFF_45_16_4_;
	O8735[78] = + _I16OFF_58_14_4_;
	O8735[79] = + _I16OFF_51_13_4_;
	{long i; for (i = 80; i < 82; i++) O8735[i] = + _I16OFF_44_13_4_;}
	{long i; for (i = 82; i < 84; i++) O8735[i] = + _I16OFF_46_14_4_;}
	O8735[84] = + _I16OFF_50_13_4_;
	O8735[85] = + _I16OFF_51_14_4_;
	O8735[86] = + _I16OFF_43_13_4_;
	O8735[87] = + _I16OFF_44_15_4_;
	O8735[88] = + _I16OFF_51_18_4_;
	O8735[89] = + _I16OFF_46_14_4_;
	O8735[90] = + _I16OFF_59_16_4_;
	{long i; for (i = 115; i < 117; i++) O8735[i] = + _I16OFF_29_14_4_;}
	O8735[123] = + _I16OFF_48_19_4_;
	O8735[126] = + _I16OFF_48_18_4_;
}

long O8736[127];
void O8736_init () {
	O8736[0] = + _I16OFF_8_6_5_;
	O8736[30] = + _I16OFF_42_12_5_;
	O8736[32] = + _I16OFF_46_12_5_;
	O8736[36] = + _I16OFF_47_12_5_;
	O8736[37] = + _I16OFF_49_12_5_;
	O8736[38] = + _I16OFF_47_12_5_;
	{long i; for (i = 42; i < 45; i++) O8736[i] = + _I16OFF_49_13_5_;}
	O8736[53] = + _I16OFF_49_13_5_;
	O8736[54] = + _I16OFF_51_13_5_;
	{long i; for (i = 55; i < 57; i++) O8736[i] = + _I16OFF_49_14_5_;}
	O8736[57] = + _I16OFF_59_21_5_;
	O8736[58] = + _I16OFF_59_23_5_;
	O8736[59] = + _I16OFF_65_25_5_;
	O8736[60] = + _I16OFF_68_26_5_;
	O8736[76] = + _I16OFF_42_13_5_;
	O8736[77] = + _I16OFF_45_16_5_;
	O8736[78] = + _I16OFF_58_14_5_;
	O8736[79] = + _I16OFF_51_13_5_;
	{long i; for (i = 80; i < 82; i++) O8736[i] = + _I16OFF_44_13_5_;}
	{long i; for (i = 82; i < 84; i++) O8736[i] = + _I16OFF_46_14_5_;}
	O8736[84] = + _I16OFF_50_13_5_;
	O8736[85] = + _I16OFF_51_14_5_;
	O8736[86] = + _I16OFF_43_13_5_;
	O8736[87] = + _I16OFF_44_15_5_;
	O8736[88] = + _I16OFF_51_18_5_;
	O8736[89] = + _I16OFF_46_14_5_;
	O8736[90] = + _I16OFF_59_16_5_;
	{long i; for (i = 115; i < 117; i++) O8736[i] = + _I16OFF_29_14_5_;}
	O8736[123] = + _I16OFF_48_19_5_;
	O8736[126] = + _I16OFF_48_18_5_;
}

long O8741[127];
void O8741_init () {
	O8741[0] =  + _REFACS_7_;
	O8741[30] =  + _REFACS_32_;
	O8741[32] =  + _REFACS_33_;
	O8741[36] =  + _REFACS_34_;
	O8741[37] =  + _REFACS_35_;
	O8741[38] =  + _REFACS_34_;
	{long i; for (i = 42; i < 45; i++) O8741[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 57; i++) O8741[i] =  + _REFACS_34_;}
	{long i; for (i = 57; i < 59; i++) O8741[i] =  + _REFACS_39_;}
	{long i; for (i = 59; i < 61; i++) O8741[i] =  + _REFACS_42_;}
	O8741[76] =  + _REFACS_32_;
	O8741[77] =  + _REFACS_34_;
	O8741[78] =  + _REFACS_37_;
	O8741[79] =  + _REFACS_35_;
	O8741[80] =  + _REFACS_33_;
	O8741[81] =  + _REFACS_32_;
	{long i; for (i = 82; i < 84; i++) O8741[i] =  + _REFACS_33_;}
	{long i; for (i = 84; i < 86; i++) O8741[i] =  + _REFACS_35_;}
	{long i; for (i = 86; i < 88; i++) O8741[i] =  + _REFACS_33_;}
	O8741[88] =  + _REFACS_36_;
	O8741[89] =  + _REFACS_34_;
	O8741[90] =  + _REFACS_39_;
	{long i; for (i = 115; i < 117; i++) O8741[i] =  + _REFACS_19_;}
	O8741[123] =  + _REFACS_33_;
	O8741[126] =  + _REFACS_33_;
}

long O8796[68];
void O8796_init () {
	{long i; for (i = 0; i < 2; i++) O8796[i] =  + _REFACS_2_;}
	{long i; for (i = 29; i < 32; i++) O8796[i] =  + _REFACS_29_;}
	{long i; for (i = 32; i < 35; i++) O8796[i] =  + _REFACS_36_;}
	{long i; for (i = 35; i < 39; i++) O8796[i] =  + _REFACS_29_;}
	{long i; for (i = 39; i < 41; i++) O8796[i] =  + _REFACS_33_;}
	{long i; for (i = 41; i < 43; i++) O8796[i] =  + _REFACS_36_;}
	{long i; for (i = 43; i < 47; i++) O8796[i] =  + _REFACS_35_;}
	{long i; for (i = 47; i < 49; i++) O8796[i] =  + _REFACS_40_;}
	{long i; for (i = 49; i < 51; i++) O8796[i] =  + _REFACS_43_;}
	O8796[55] =  + _REFACS_28_;
	O8796[67] =  + _REFACS_35_;
}

long O8797[68];
void O8797_init () {
	{long i; for (i = 0; i < 2; i++) O8797[i] = + _CHROFF_3_0_;}
	{long i; for (i = 29; i < 32; i++) O8797[i] = + _CHROFF_39_5_;}
	{long i; for (i = 32; i < 35; i++) O8797[i] = + _CHROFF_49_8_;}
	{long i; for (i = 35; i < 39; i++) O8797[i] = + _CHROFF_39_5_;}
	{long i; for (i = 39; i < 41; i++) O8797[i] = + _CHROFF_47_5_;}
	O8797[41] = + _CHROFF_50_5_;
	O8797[42] = + _CHROFF_53_5_;
	O8797[43] = + _CHROFF_49_8_;
	O8797[44] = + _CHROFF_51_8_;
	{long i; for (i = 45; i < 47; i++) O8797[i] = + _CHROFF_49_8_;}
	{long i; for (i = 47; i < 49; i++) O8797[i] = + _CHROFF_59_10_;}
	O8797[49] = + _CHROFF_65_10_;
	O8797[50] = + _CHROFF_68_10_;
	O8797[55] = + _CHROFF_37_5_;
	O8797[67] = + _CHROFF_45_8_;
}

long O8818[99];
void O8818_init () {
	O8818[0] =  + _REFACS_1_;
	{long i; for (i = 64; i < 66; i++) O8818[i] =  + _REFACS_34_;}
	{long i; for (i = 81; i < 83; i++) O8818[i] =  + _REFACS_14_;}
	{long i; for (i = 88; i < 92; i++) O8818[i] =  + _REFACS_15_;}
	O8818[92] =  + _REFACS_18_;
	{long i; for (i = 97; i < 99; i++) O8818[i] =  + _REFACS_20_;}
}

long O8820[99];
void O8820_init () {
	O8820[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 64; i < 66; i++) O8820[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 81; i < 83; i++) O8820[i] = + _PTROFF_21_7_6_1_0_1_;}
	O8820[88] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 89; i < 91; i++) O8820[i] = + _PTROFF_23_9_6_1_0_1_;}
	O8820[91] = + _PTROFF_24_9_6_1_0_1_;
	O8820[92] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 97; i < 99; i++) O8820[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O8825[71];
void O8825_init () {
	O8825[0] =  + _REFACS_1_;
	O8825[17] =  + _REFACS_36_;
	O8825[34] =  + _REFACS_36_;
	O8825[61] =  + _REFACS_33_;
	{long i; for (i = 62; i < 64; i++) O8825[i] =  + _REFACS_35_;}
	O8825[67] =  + _REFACS_34_;
	O8825[68] =  + _REFACS_37_;
	O8825[69] =  + _REFACS_35_;
	O8825[70] =  + _REFACS_40_;
}

long O8834[89];
void O8834_init () {
	O8834[0] = + _PTROFF_2_1_0_0_0_0_;
	O8834[59] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 60; i < 62; i++) O8834[i] = + _PTROFF_46_14_10_6_0_2_;}
	O8834[84] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 85; i < 87; i++) O8834[i] = + _PTROFF_23_9_6_1_0_2_;}
	O8834[87] = + _PTROFF_24_9_6_1_0_2_;
	O8834[88] = + _PTROFF_26_8_6_2_0_2_;
}

long O8836[89];
void O8836_init () {
	O8836[0] =  + _REFACS_1_;
	O8836[59] =  + _REFACS_34_;
	{long i; for (i = 60; i < 62; i++) O8836[i] =  + _REFACS_36_;}
	{long i; for (i = 84; i < 88; i++) O8836[i] =  + _REFACS_16_;}
	O8836[88] =  + _REFACS_19_;
}

long O8858[100];
void O8858_init () {
	O8858[0] =  + _REFACS_8_;
	O8858[1] =  + _REFACS_11_;
	O8858[2] =  + _REFACS_27_;
	O8858[3] =  + _REFACS_33_;
	O8858[4] =  + _REFACS_28_;
	O8858[5] =  + _REFACS_34_;
	O8858[6] =  + _REFACS_28_;
	O8858[7] =  + _REFACS_29_;
	O8858[8] =  + _REFACS_28_;
	O8858[9] =  + _REFACS_35_;
	O8858[10] =  + _REFACS_37_;
	O8858[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O8858[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O8858[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O8858[i] =  + _REFACS_30_;}
	{long i; for (i = 22; i < 24; i++) O8858[i] =  + _REFACS_34_;}
	{long i; for (i = 24; i < 26; i++) O8858[i] =  + _REFACS_37_;}
	O8858[26] =  + _REFACS_36_;
	O8858[27] =  + _REFACS_37_;
	{long i; for (i = 28; i < 30; i++) O8858[i] =  + _REFACS_36_;}
	{long i; for (i = 30; i < 32; i++) O8858[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O8858[i] =  + _REFACS_44_;}
	O8858[34] =  + _REFACS_27_;
	O8858[35] =  + _REFACS_31_;
	O8858[36] =  + _REFACS_29_;
	O8858[37] =  + _REFACS_28_;
	O8858[38] =  + _REFACS_29_;
	O8858[39] =  + _REFACS_27_;
	{long i; for (i = 40; i < 42; i++) O8858[i] =  + _REFACS_28_;}
	{long i; for (i = 42; i < 44; i++) O8858[i] =  + _REFACS_29_;}
	O8858[44] =  + _REFACS_28_;
	O8858[45] =  + _REFACS_29_;
	O8858[46] =  + _REFACS_33_;
	O8858[47] =  + _REFACS_28_;
	O8858[48] =  + _REFACS_31_;
	O8858[49] =  + _REFACS_33_;
	O8858[50] =  + _REFACS_36_;
	O8858[51] =  + _REFACS_38_;
	O8858[52] =  + _REFACS_36_;
	O8858[53] =  + _REFACS_34_;
	O8858[54] =  + _REFACS_35_;
	{long i; for (i = 55; i < 57; i++) O8858[i] =  + _REFACS_37_;}
	{long i; for (i = 57; i < 59; i++) O8858[i] =  + _REFACS_36_;}
	O8858[59] =  + _REFACS_34_;
	O8858[60] =  + _REFACS_35_;
	O8858[61] =  + _REFACS_38_;
	O8858[62] =  + _REFACS_36_;
	O8858[63] =  + _REFACS_41_;
	O8858[64] =  + _REFACS_11_;
	{long i; for (i = 65; i < 67; i++) O8858[i] =  + _REFACS_13_;}
	O8858[67] =  + _REFACS_11_;
	{long i; for (i = 68; i < 70; i++) O8858[i] =  + _REFACS_15_;}
	{long i; for (i = 70; i < 72; i++) O8858[i] =  + _REFACS_16_;}
	{long i; for (i = 72; i < 74; i++) O8858[i] =  + _REFACS_15_;}
	{long i; for (i = 74; i < 78; i++) O8858[i] =  + _REFACS_12_;}
	O8858[78] =  + _REFACS_13_;
	{long i; for (i = 79; i < 83; i++) O8858[i] =  + _REFACS_17_;}
	O8858[83] =  + _REFACS_20_;
	{long i; for (i = 84; i < 86; i++) O8858[i] =  + _REFACS_13_;}
	{long i; for (i = 86; i < 88; i++) O8858[i] =  + _REFACS_16_;}
	{long i; for (i = 88; i < 90; i++) O8858[i] =  + _REFACS_21_;}
	O8858[91] =  + _REFACS_28_;
	O8858[94] =  + _REFACS_28_;
	O8858[96] =  + _REFACS_34_;
	O8858[99] =  + _REFACS_34_;
}

long O8859[100];
void O8859_init () {
	O8859[0] =  + _REFACS_9_;
	O8859[1] =  + _REFACS_12_;
	O8859[2] =  + _REFACS_28_;
	O8859[3] =  + _REFACS_34_;
	O8859[4] =  + _REFACS_29_;
	O8859[5] =  + _REFACS_35_;
	O8859[6] =  + _REFACS_29_;
	O8859[7] =  + _REFACS_30_;
	O8859[8] =  + _REFACS_29_;
	O8859[9] =  + _REFACS_36_;
	O8859[10] =  + _REFACS_38_;
	O8859[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O8859[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O8859[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O8859[i] =  + _REFACS_31_;}
	{long i; for (i = 22; i < 24; i++) O8859[i] =  + _REFACS_35_;}
	{long i; for (i = 24; i < 26; i++) O8859[i] =  + _REFACS_38_;}
	O8859[26] =  + _REFACS_37_;
	O8859[27] =  + _REFACS_38_;
	{long i; for (i = 28; i < 30; i++) O8859[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O8859[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O8859[i] =  + _REFACS_45_;}
	O8859[34] =  + _REFACS_28_;
	O8859[35] =  + _REFACS_32_;
	O8859[36] =  + _REFACS_30_;
	O8859[37] =  + _REFACS_29_;
	O8859[38] =  + _REFACS_30_;
	O8859[39] =  + _REFACS_28_;
	{long i; for (i = 40; i < 42; i++) O8859[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 44; i++) O8859[i] =  + _REFACS_30_;}
	O8859[44] =  + _REFACS_29_;
	O8859[45] =  + _REFACS_30_;
	O8859[46] =  + _REFACS_34_;
	O8859[47] =  + _REFACS_29_;
	O8859[48] =  + _REFACS_32_;
	O8859[49] =  + _REFACS_34_;
	O8859[50] =  + _REFACS_37_;
	O8859[51] =  + _REFACS_39_;
	O8859[52] =  + _REFACS_37_;
	O8859[53] =  + _REFACS_35_;
	O8859[54] =  + _REFACS_36_;
	{long i; for (i = 55; i < 57; i++) O8859[i] =  + _REFACS_38_;}
	{long i; for (i = 57; i < 59; i++) O8859[i] =  + _REFACS_37_;}
	O8859[59] =  + _REFACS_35_;
	O8859[60] =  + _REFACS_36_;
	O8859[61] =  + _REFACS_39_;
	O8859[62] =  + _REFACS_37_;
	O8859[63] =  + _REFACS_42_;
	O8859[64] =  + _REFACS_12_;
	{long i; for (i = 65; i < 67; i++) O8859[i] =  + _REFACS_14_;}
	O8859[67] =  + _REFACS_12_;
	{long i; for (i = 68; i < 70; i++) O8859[i] =  + _REFACS_16_;}
	{long i; for (i = 70; i < 72; i++) O8859[i] =  + _REFACS_17_;}
	{long i; for (i = 72; i < 74; i++) O8859[i] =  + _REFACS_16_;}
	{long i; for (i = 74; i < 78; i++) O8859[i] =  + _REFACS_13_;}
	O8859[78] =  + _REFACS_14_;
	{long i; for (i = 79; i < 83; i++) O8859[i] =  + _REFACS_18_;}
	O8859[83] =  + _REFACS_21_;
	{long i; for (i = 84; i < 86; i++) O8859[i] =  + _REFACS_14_;}
	{long i; for (i = 86; i < 88; i++) O8859[i] =  + _REFACS_17_;}
	{long i; for (i = 88; i < 90; i++) O8859[i] =  + _REFACS_22_;}
	O8859[91] =  + _REFACS_29_;
	O8859[94] =  + _REFACS_29_;
	O8859[96] =  + _REFACS_35_;
	O8859[99] =  + _REFACS_35_;
}

long O8861[100];
void O8861_init () {
	O8861[0] =  + _REFACS_10_;
	O8861[1] =  + _REFACS_13_;
	O8861[2] =  + _REFACS_29_;
	O8861[3] =  + _REFACS_35_;
	O8861[4] =  + _REFACS_30_;
	O8861[5] =  + _REFACS_36_;
	O8861[6] =  + _REFACS_30_;
	O8861[7] =  + _REFACS_31_;
	O8861[8] =  + _REFACS_30_;
	O8861[9] =  + _REFACS_37_;
	O8861[10] =  + _REFACS_39_;
	O8861[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O8861[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O8861[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O8861[i] =  + _REFACS_32_;}
	{long i; for (i = 22; i < 24; i++) O8861[i] =  + _REFACS_36_;}
	{long i; for (i = 24; i < 26; i++) O8861[i] =  + _REFACS_39_;}
	O8861[26] =  + _REFACS_38_;
	O8861[27] =  + _REFACS_39_;
	{long i; for (i = 28; i < 30; i++) O8861[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O8861[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O8861[i] =  + _REFACS_46_;}
	O8861[34] =  + _REFACS_29_;
	O8861[35] =  + _REFACS_33_;
	O8861[36] =  + _REFACS_31_;
	O8861[37] =  + _REFACS_30_;
	O8861[38] =  + _REFACS_31_;
	O8861[39] =  + _REFACS_29_;
	{long i; for (i = 40; i < 42; i++) O8861[i] =  + _REFACS_30_;}
	{long i; for (i = 42; i < 44; i++) O8861[i] =  + _REFACS_31_;}
	O8861[44] =  + _REFACS_30_;
	O8861[45] =  + _REFACS_31_;
	O8861[46] =  + _REFACS_35_;
	O8861[47] =  + _REFACS_30_;
	O8861[48] =  + _REFACS_33_;
	O8861[49] =  + _REFACS_35_;
	O8861[50] =  + _REFACS_38_;
	O8861[51] =  + _REFACS_40_;
	O8861[52] =  + _REFACS_38_;
	O8861[53] =  + _REFACS_36_;
	O8861[54] =  + _REFACS_37_;
	{long i; for (i = 55; i < 57; i++) O8861[i] =  + _REFACS_39_;}
	{long i; for (i = 57; i < 59; i++) O8861[i] =  + _REFACS_38_;}
	O8861[59] =  + _REFACS_36_;
	O8861[60] =  + _REFACS_37_;
	O8861[61] =  + _REFACS_40_;
	O8861[62] =  + _REFACS_38_;
	O8861[63] =  + _REFACS_43_;
	O8861[64] =  + _REFACS_13_;
	{long i; for (i = 65; i < 67; i++) O8861[i] =  + _REFACS_15_;}
	O8861[67] =  + _REFACS_13_;
	{long i; for (i = 68; i < 70; i++) O8861[i] =  + _REFACS_17_;}
	{long i; for (i = 70; i < 72; i++) O8861[i] =  + _REFACS_18_;}
	{long i; for (i = 72; i < 74; i++) O8861[i] =  + _REFACS_17_;}
	{long i; for (i = 74; i < 78; i++) O8861[i] =  + _REFACS_14_;}
	O8861[78] =  + _REFACS_15_;
	{long i; for (i = 79; i < 83; i++) O8861[i] =  + _REFACS_19_;}
	O8861[83] =  + _REFACS_22_;
	{long i; for (i = 84; i < 86; i++) O8861[i] =  + _REFACS_15_;}
	{long i; for (i = 86; i < 88; i++) O8861[i] =  + _REFACS_18_;}
	{long i; for (i = 88; i < 90; i++) O8861[i] =  + _REFACS_23_;}
	O8861[91] =  + _REFACS_30_;
	O8861[94] =  + _REFACS_30_;
	O8861[96] =  + _REFACS_36_;
	O8861[99] =  + _REFACS_36_;
}

long O8862[100];
void O8862_init () {
	O8862[0] =  + _REFACS_11_;
	O8862[1] =  + _REFACS_14_;
	O8862[2] =  + _REFACS_30_;
	O8862[3] =  + _REFACS_36_;
	O8862[4] =  + _REFACS_31_;
	O8862[5] =  + _REFACS_37_;
	O8862[6] =  + _REFACS_31_;
	O8862[7] =  + _REFACS_32_;
	O8862[8] =  + _REFACS_31_;
	O8862[9] =  + _REFACS_38_;
	O8862[10] =  + _REFACS_40_;
	O8862[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O8862[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O8862[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O8862[i] =  + _REFACS_33_;}
	{long i; for (i = 22; i < 24; i++) O8862[i] =  + _REFACS_37_;}
	{long i; for (i = 24; i < 26; i++) O8862[i] =  + _REFACS_40_;}
	O8862[26] =  + _REFACS_39_;
	O8862[27] =  + _REFACS_40_;
	{long i; for (i = 28; i < 30; i++) O8862[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O8862[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O8862[i] =  + _REFACS_47_;}
	O8862[34] =  + _REFACS_30_;
	O8862[35] =  + _REFACS_34_;
	O8862[36] =  + _REFACS_32_;
	O8862[37] =  + _REFACS_31_;
	O8862[38] =  + _REFACS_32_;
	O8862[39] =  + _REFACS_30_;
	{long i; for (i = 40; i < 42; i++) O8862[i] =  + _REFACS_31_;}
	{long i; for (i = 42; i < 44; i++) O8862[i] =  + _REFACS_32_;}
	O8862[44] =  + _REFACS_31_;
	O8862[45] =  + _REFACS_32_;
	O8862[46] =  + _REFACS_36_;
	O8862[47] =  + _REFACS_31_;
	O8862[48] =  + _REFACS_34_;
	O8862[49] =  + _REFACS_36_;
	O8862[50] =  + _REFACS_39_;
	O8862[51] =  + _REFACS_41_;
	O8862[52] =  + _REFACS_39_;
	O8862[53] =  + _REFACS_37_;
	O8862[54] =  + _REFACS_38_;
	{long i; for (i = 55; i < 57; i++) O8862[i] =  + _REFACS_40_;}
	{long i; for (i = 57; i < 59; i++) O8862[i] =  + _REFACS_39_;}
	O8862[59] =  + _REFACS_37_;
	O8862[60] =  + _REFACS_38_;
	O8862[61] =  + _REFACS_41_;
	O8862[62] =  + _REFACS_39_;
	O8862[63] =  + _REFACS_44_;
	O8862[64] =  + _REFACS_14_;
	{long i; for (i = 65; i < 67; i++) O8862[i] =  + _REFACS_16_;}
	O8862[67] =  + _REFACS_14_;
	{long i; for (i = 68; i < 70; i++) O8862[i] =  + _REFACS_18_;}
	{long i; for (i = 70; i < 72; i++) O8862[i] =  + _REFACS_19_;}
	{long i; for (i = 72; i < 74; i++) O8862[i] =  + _REFACS_18_;}
	{long i; for (i = 74; i < 78; i++) O8862[i] =  + _REFACS_15_;}
	O8862[78] =  + _REFACS_16_;
	{long i; for (i = 79; i < 83; i++) O8862[i] =  + _REFACS_20_;}
	O8862[83] =  + _REFACS_23_;
	{long i; for (i = 84; i < 86; i++) O8862[i] =  + _REFACS_16_;}
	{long i; for (i = 86; i < 88; i++) O8862[i] =  + _REFACS_19_;}
	{long i; for (i = 88; i < 90; i++) O8862[i] =  + _REFACS_24_;}
	O8862[91] =  + _REFACS_31_;
	O8862[94] =  + _REFACS_31_;
	O8862[96] =  + _REFACS_37_;
	O8862[99] =  + _REFACS_37_;
}

long O8863[100];
void O8863_init () {
	O8863[0] =  + _REFACS_12_;
	O8863[1] =  + _REFACS_15_;
	O8863[2] =  + _REFACS_31_;
	O8863[3] =  + _REFACS_37_;
	O8863[4] =  + _REFACS_32_;
	O8863[5] =  + _REFACS_38_;
	O8863[6] =  + _REFACS_32_;
	O8863[7] =  + _REFACS_33_;
	O8863[8] =  + _REFACS_32_;
	O8863[9] =  + _REFACS_39_;
	O8863[10] =  + _REFACS_41_;
	O8863[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O8863[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O8863[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O8863[i] =  + _REFACS_34_;}
	{long i; for (i = 22; i < 24; i++) O8863[i] =  + _REFACS_38_;}
	{long i; for (i = 24; i < 26; i++) O8863[i] =  + _REFACS_41_;}
	O8863[26] =  + _REFACS_40_;
	O8863[27] =  + _REFACS_41_;
	{long i; for (i = 28; i < 30; i++) O8863[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O8863[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O8863[i] =  + _REFACS_48_;}
	O8863[34] =  + _REFACS_31_;
	O8863[35] =  + _REFACS_35_;
	O8863[36] =  + _REFACS_33_;
	O8863[37] =  + _REFACS_32_;
	O8863[38] =  + _REFACS_33_;
	O8863[39] =  + _REFACS_31_;
	{long i; for (i = 40; i < 42; i++) O8863[i] =  + _REFACS_32_;}
	{long i; for (i = 42; i < 44; i++) O8863[i] =  + _REFACS_33_;}
	O8863[44] =  + _REFACS_32_;
	O8863[45] =  + _REFACS_33_;
	O8863[46] =  + _REFACS_37_;
	O8863[47] =  + _REFACS_32_;
	O8863[48] =  + _REFACS_35_;
	O8863[49] =  + _REFACS_37_;
	O8863[50] =  + _REFACS_40_;
	O8863[51] =  + _REFACS_42_;
	O8863[52] =  + _REFACS_40_;
	O8863[53] =  + _REFACS_38_;
	O8863[54] =  + _REFACS_39_;
	{long i; for (i = 55; i < 57; i++) O8863[i] =  + _REFACS_41_;}
	{long i; for (i = 57; i < 59; i++) O8863[i] =  + _REFACS_40_;}
	O8863[59] =  + _REFACS_38_;
	O8863[60] =  + _REFACS_39_;
	O8863[61] =  + _REFACS_42_;
	O8863[62] =  + _REFACS_40_;
	O8863[63] =  + _REFACS_45_;
	O8863[64] =  + _REFACS_15_;
	{long i; for (i = 65; i < 67; i++) O8863[i] =  + _REFACS_17_;}
	O8863[67] =  + _REFACS_15_;
	{long i; for (i = 68; i < 70; i++) O8863[i] =  + _REFACS_19_;}
	{long i; for (i = 70; i < 72; i++) O8863[i] =  + _REFACS_20_;}
	{long i; for (i = 72; i < 74; i++) O8863[i] =  + _REFACS_19_;}
	{long i; for (i = 74; i < 78; i++) O8863[i] =  + _REFACS_16_;}
	O8863[78] =  + _REFACS_17_;
	{long i; for (i = 79; i < 83; i++) O8863[i] =  + _REFACS_21_;}
	O8863[83] =  + _REFACS_24_;
	{long i; for (i = 84; i < 86; i++) O8863[i] =  + _REFACS_17_;}
	{long i; for (i = 86; i < 88; i++) O8863[i] =  + _REFACS_20_;}
	{long i; for (i = 88; i < 90; i++) O8863[i] =  + _REFACS_25_;}
	O8863[91] =  + _REFACS_32_;
	O8863[94] =  + _REFACS_32_;
	O8863[96] =  + _REFACS_38_;
	O8863[99] =  + _REFACS_38_;
}

long O8883[100];
void O8883_init () {
	O8883[0] = + _CHROFF_13_1_;
	O8883[1] = + _CHROFF_16_3_;
	O8883[2] = + _CHROFF_35_5_;
	O8883[3] = + _CHROFF_42_8_;
	O8883[4] = + _CHROFF_37_5_;
	O8883[5] = + _CHROFF_46_8_;
	O8883[6] = + _CHROFF_37_5_;
	O8883[7] = + _CHROFF_38_5_;
	O8883[8] = + _CHROFF_37_5_;
	O8883[9] = + _CHROFF_47_8_;
	O8883[10] = + _CHROFF_49_8_;
	O8883[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O8883[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O8883[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O8883[i] = + _CHROFF_39_6_;}
	{long i; for (i = 22; i < 24; i++) O8883[i] = + _CHROFF_47_6_;}
	O8883[24] = + _CHROFF_50_6_;
	O8883[25] = + _CHROFF_53_6_;
	O8883[26] = + _CHROFF_49_9_;
	O8883[27] = + _CHROFF_51_9_;
	{long i; for (i = 28; i < 30; i++) O8883[i] = + _CHROFF_49_9_;}
	{long i; for (i = 30; i < 32; i++) O8883[i] = + _CHROFF_59_11_;}
	O8883[32] = + _CHROFF_65_11_;
	O8883[33] = + _CHROFF_68_11_;
	O8883[34] = + _CHROFF_35_5_;
	O8883[35] = + _CHROFF_43_5_;
	{long i; for (i = 36; i < 38; i++) O8883[i] = + _CHROFF_37_5_;}
	O8883[38] = + _CHROFF_37_6_;
	O8883[39] = + _CHROFF_35_5_;
	{long i; for (i = 40; i < 42; i++) O8883[i] = + _CHROFF_36_5_;}
	{long i; for (i = 42; i < 44; i++) O8883[i] = + _CHROFF_37_5_;}
	O8883[44] = + _CHROFF_36_5_;
	O8883[45] = + _CHROFF_37_5_;
	O8883[46] = + _CHROFF_41_5_;
	O8883[47] = + _CHROFF_36_5_;
	O8883[48] = + _CHROFF_40_5_;
	O8883[49] = + _CHROFF_42_8_;
	O8883[50] = + _CHROFF_45_9_;
	O8883[51] = + _CHROFF_58_8_;
	O8883[52] = + _CHROFF_51_8_;
	{long i; for (i = 53; i < 55; i++) O8883[i] = + _CHROFF_44_8_;}
	{long i; for (i = 55; i < 57; i++) O8883[i] = + _CHROFF_46_8_;}
	O8883[57] = + _CHROFF_50_8_;
	O8883[58] = + _CHROFF_51_8_;
	O8883[59] = + _CHROFF_43_8_;
	O8883[60] = + _CHROFF_44_8_;
	O8883[61] = + _CHROFF_51_8_;
	O8883[62] = + _CHROFF_46_8_;
	O8883[63] = + _CHROFF_59_8_;
	O8883[64] = + _CHROFF_16_1_;
	O8883[65] = + _CHROFF_18_1_;
	O8883[66] = + _CHROFF_23_1_;
	O8883[67] = + _CHROFF_16_1_;
	{long i; for (i = 68; i < 70; i++) O8883[i] = + _CHROFF_20_1_;}
	{long i; for (i = 70; i < 72; i++) O8883[i] = + _CHROFF_25_1_;}
	{long i; for (i = 72; i < 74; i++) O8883[i] = + _CHROFF_21_3_;}
	{long i; for (i = 74; i < 78; i++) O8883[i] = + _CHROFF_17_2_;}
	O8883[78] = + _CHROFF_18_2_;
	{long i; for (i = 79; i < 82; i++) O8883[i] = + _CHROFF_23_4_;}
	O8883[82] = + _CHROFF_24_4_;
	O8883[83] = + _CHROFF_26_4_;
	O8883[84] = + _CHROFF_19_1_;
	O8883[85] = + _CHROFF_22_1_;
	{long i; for (i = 86; i < 88; i++) O8883[i] = + _CHROFF_21_5_;}
	{long i; for (i = 88; i < 90; i++) O8883[i] = + _CHROFF_29_8_;}
	O8883[91] = + _CHROFF_36_5_;
	O8883[94] = + _CHROFF_36_5_;
	O8883[96] = + _CHROFF_48_8_;
	O8883[99] = + _CHROFF_48_8_;
}

long O8888[100];
void O8888_init () {
	O8888[0] = + _I16OFF_13_5_4_;
	O8888[1] = + _I16OFF_16_7_4_;
	O8888[2] = + _I16OFF_35_9_4_;
	O8888[3] = + _I16OFF_42_12_6_;
	O8888[4] = + _I16OFF_37_9_4_;
	O8888[5] = + _I16OFF_46_12_6_;
	O8888[6] = + _I16OFF_37_9_4_;
	O8888[7] = + _I16OFF_38_9_4_;
	O8888[8] = + _I16OFF_37_9_4_;
	O8888[9] = + _I16OFF_47_12_6_;
	O8888[10] = + _I16OFF_49_12_6_;
	O8888[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O8888[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O8888[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O8888[i] = + _I16OFF_39_10_4_;}
	O8888[22] = + _I16OFF_47_12_4_;
	O8888[23] = + _I16OFF_47_14_4_;
	O8888[24] = + _I16OFF_50_13_4_;
	O8888[25] = + _I16OFF_53_13_4_;
	O8888[26] = + _I16OFF_49_13_6_;
	O8888[27] = + _I16OFF_51_13_6_;
	{long i; for (i = 28; i < 30; i++) O8888[i] = + _I16OFF_49_14_6_;}
	O8888[30] = + _I16OFF_59_21_6_;
	O8888[31] = + _I16OFF_59_23_6_;
	O8888[32] = + _I16OFF_65_25_6_;
	O8888[33] = + _I16OFF_68_26_6_;
	O8888[34] = + _I16OFF_35_9_4_;
	O8888[35] = + _I16OFF_43_9_4_;
	{long i; for (i = 36; i < 38; i++) O8888[i] = + _I16OFF_37_9_4_;}
	O8888[38] = + _I16OFF_37_10_4_;
	O8888[39] = + _I16OFF_35_9_4_;
	{long i; for (i = 40; i < 42; i++) O8888[i] = + _I16OFF_36_9_4_;}
	O8888[42] = + _I16OFF_37_9_4_;
	O8888[43] = + _I16OFF_37_10_4_;
	O8888[44] = + _I16OFF_36_9_4_;
	O8888[45] = + _I16OFF_37_9_4_;
	O8888[46] = + _I16OFF_41_9_4_;
	O8888[47] = + _I16OFF_36_9_4_;
	O8888[48] = + _I16OFF_40_12_4_;
	O8888[49] = + _I16OFF_42_13_6_;
	O8888[50] = + _I16OFF_45_16_6_;
	O8888[51] = + _I16OFF_58_14_6_;
	O8888[52] = + _I16OFF_51_13_6_;
	{long i; for (i = 53; i < 55; i++) O8888[i] = + _I16OFF_44_13_6_;}
	{long i; for (i = 55; i < 57; i++) O8888[i] = + _I16OFF_46_14_6_;}
	O8888[57] = + _I16OFF_50_13_6_;
	O8888[58] = + _I16OFF_51_14_6_;
	O8888[59] = + _I16OFF_43_13_6_;
	O8888[60] = + _I16OFF_44_15_6_;
	O8888[61] = + _I16OFF_51_18_6_;
	O8888[62] = + _I16OFF_46_14_6_;
	O8888[63] = + _I16OFF_59_16_6_;
	O8888[64] = + _I16OFF_16_5_4_;
	O8888[65] = + _I16OFF_18_5_4_;
	O8888[66] = + _I16OFF_23_5_4_;
	O8888[67] = + _I16OFF_16_5_4_;
	{long i; for (i = 68; i < 70; i++) O8888[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 70; i < 72; i++) O8888[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 72; i < 74; i++) O8888[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 74; i < 78; i++) O8888[i] = + _I16OFF_17_6_4_;}
	O8888[78] = + _I16OFF_18_6_4_;
	O8888[79] = + _I16OFF_23_8_4_;
	{long i; for (i = 80; i < 82; i++) O8888[i] = + _I16OFF_23_9_4_;}
	O8888[82] = + _I16OFF_24_9_4_;
	O8888[83] = + _I16OFF_26_8_4_;
	O8888[84] = + _I16OFF_19_5_4_;
	O8888[85] = + _I16OFF_22_5_4_;
	{long i; for (i = 86; i < 88; i++) O8888[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 88; i < 90; i++) O8888[i] = + _I16OFF_29_14_6_;}
	O8888[91] = + _I16OFF_36_10_4_;
	O8888[94] = + _I16OFF_36_9_4_;
	O8888[96] = + _I16OFF_48_19_6_;
	O8888[99] = + _I16OFF_48_18_6_;
}

long O8889[100];
void O8889_init () {
	O8889[0] = + _I16OFF_13_5_5_;
	O8889[1] = + _I16OFF_16_7_5_;
	O8889[2] = + _I16OFF_35_9_5_;
	O8889[3] = + _I16OFF_42_12_7_;
	O8889[4] = + _I16OFF_37_9_5_;
	O8889[5] = + _I16OFF_46_12_7_;
	O8889[6] = + _I16OFF_37_9_5_;
	O8889[7] = + _I16OFF_38_9_5_;
	O8889[8] = + _I16OFF_37_9_5_;
	O8889[9] = + _I16OFF_47_12_7_;
	O8889[10] = + _I16OFF_49_12_7_;
	O8889[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O8889[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O8889[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O8889[i] = + _I16OFF_39_10_5_;}
	O8889[22] = + _I16OFF_47_12_5_;
	O8889[23] = + _I16OFF_47_14_5_;
	O8889[24] = + _I16OFF_50_13_5_;
	O8889[25] = + _I16OFF_53_13_5_;
	O8889[26] = + _I16OFF_49_13_7_;
	O8889[27] = + _I16OFF_51_13_7_;
	{long i; for (i = 28; i < 30; i++) O8889[i] = + _I16OFF_49_14_7_;}
	O8889[30] = + _I16OFF_59_21_7_;
	O8889[31] = + _I16OFF_59_23_7_;
	O8889[32] = + _I16OFF_65_25_7_;
	O8889[33] = + _I16OFF_68_26_7_;
	O8889[34] = + _I16OFF_35_9_5_;
	O8889[35] = + _I16OFF_43_9_5_;
	{long i; for (i = 36; i < 38; i++) O8889[i] = + _I16OFF_37_9_5_;}
	O8889[38] = + _I16OFF_37_10_5_;
	O8889[39] = + _I16OFF_35_9_5_;
	{long i; for (i = 40; i < 42; i++) O8889[i] = + _I16OFF_36_9_5_;}
	O8889[42] = + _I16OFF_37_9_5_;
	O8889[43] = + _I16OFF_37_10_5_;
	O8889[44] = + _I16OFF_36_9_5_;
	O8889[45] = + _I16OFF_37_9_5_;
	O8889[46] = + _I16OFF_41_9_5_;
	O8889[47] = + _I16OFF_36_9_5_;
	O8889[48] = + _I16OFF_40_12_5_;
	O8889[49] = + _I16OFF_42_13_7_;
	O8889[50] = + _I16OFF_45_16_7_;
	O8889[51] = + _I16OFF_58_14_7_;
	O8889[52] = + _I16OFF_51_13_7_;
	{long i; for (i = 53; i < 55; i++) O8889[i] = + _I16OFF_44_13_7_;}
	{long i; for (i = 55; i < 57; i++) O8889[i] = + _I16OFF_46_14_7_;}
	O8889[57] = + _I16OFF_50_13_7_;
	O8889[58] = + _I16OFF_51_14_7_;
	O8889[59] = + _I16OFF_43_13_7_;
	O8889[60] = + _I16OFF_44_15_7_;
	O8889[61] = + _I16OFF_51_18_7_;
	O8889[62] = + _I16OFF_46_14_7_;
	O8889[63] = + _I16OFF_59_16_7_;
	O8889[64] = + _I16OFF_16_5_5_;
	O8889[65] = + _I16OFF_18_5_5_;
	O8889[66] = + _I16OFF_23_5_5_;
	O8889[67] = + _I16OFF_16_5_5_;
	{long i; for (i = 68; i < 70; i++) O8889[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 70; i < 72; i++) O8889[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 72; i < 74; i++) O8889[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 74; i < 78; i++) O8889[i] = + _I16OFF_17_6_5_;}
	O8889[78] = + _I16OFF_18_6_5_;
	O8889[79] = + _I16OFF_23_8_5_;
	{long i; for (i = 80; i < 82; i++) O8889[i] = + _I16OFF_23_9_5_;}
	O8889[82] = + _I16OFF_24_9_5_;
	O8889[83] = + _I16OFF_26_8_5_;
	O8889[84] = + _I16OFF_19_5_5_;
	O8889[85] = + _I16OFF_22_5_5_;
	{long i; for (i = 86; i < 88; i++) O8889[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 88; i < 90; i++) O8889[i] = + _I16OFF_29_14_7_;}
	O8889[91] = + _I16OFF_36_10_5_;
	O8889[94] = + _I16OFF_36_9_5_;
	O8889[96] = + _I16OFF_48_19_7_;
	O8889[99] = + _I16OFF_48_18_7_;
}

long O8891[100];
void O8891_init () {
	O8891[0] = + _CHROFF_13_4_;
	O8891[1] = + _CHROFF_16_6_;
	O8891[2] = + _CHROFF_35_8_;
	O8891[3] = + _CHROFF_42_11_;
	O8891[4] = + _CHROFF_37_8_;
	O8891[5] = + _CHROFF_46_11_;
	O8891[6] = + _CHROFF_37_8_;
	O8891[7] = + _CHROFF_38_8_;
	O8891[8] = + _CHROFF_37_8_;
	O8891[9] = + _CHROFF_47_11_;
	O8891[10] = + _CHROFF_49_11_;
	O8891[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O8891[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O8891[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O8891[i] = + _CHROFF_39_9_;}
	O8891[22] = + _CHROFF_47_11_;
	O8891[23] = + _CHROFF_47_13_;
	O8891[24] = + _CHROFF_50_12_;
	O8891[25] = + _CHROFF_53_12_;
	O8891[26] = + _CHROFF_49_12_;
	O8891[27] = + _CHROFF_51_12_;
	{long i; for (i = 28; i < 30; i++) O8891[i] = + _CHROFF_49_13_;}
	O8891[30] = + _CHROFF_59_20_;
	O8891[31] = + _CHROFF_59_22_;
	O8891[32] = + _CHROFF_65_24_;
	O8891[33] = + _CHROFF_68_25_;
	O8891[34] = + _CHROFF_35_8_;
	O8891[35] = + _CHROFF_43_8_;
	{long i; for (i = 36; i < 38; i++) O8891[i] = + _CHROFF_37_8_;}
	O8891[38] = + _CHROFF_37_9_;
	O8891[39] = + _CHROFF_35_8_;
	{long i; for (i = 40; i < 42; i++) O8891[i] = + _CHROFF_36_8_;}
	O8891[42] = + _CHROFF_37_8_;
	O8891[43] = + _CHROFF_37_9_;
	O8891[44] = + _CHROFF_36_8_;
	O8891[45] = + _CHROFF_37_8_;
	O8891[46] = + _CHROFF_41_8_;
	O8891[47] = + _CHROFF_36_8_;
	O8891[48] = + _CHROFF_40_11_;
	O8891[49] = + _CHROFF_42_12_;
	O8891[50] = + _CHROFF_45_15_;
	O8891[51] = + _CHROFF_58_13_;
	O8891[52] = + _CHROFF_51_12_;
	{long i; for (i = 53; i < 55; i++) O8891[i] = + _CHROFF_44_12_;}
	{long i; for (i = 55; i < 57; i++) O8891[i] = + _CHROFF_46_13_;}
	O8891[57] = + _CHROFF_50_12_;
	O8891[58] = + _CHROFF_51_13_;
	O8891[59] = + _CHROFF_43_12_;
	O8891[60] = + _CHROFF_44_14_;
	O8891[61] = + _CHROFF_51_17_;
	O8891[62] = + _CHROFF_46_13_;
	O8891[63] = + _CHROFF_59_15_;
	O8891[64] = + _CHROFF_16_4_;
	O8891[65] = + _CHROFF_18_4_;
	O8891[66] = + _CHROFF_23_4_;
	O8891[67] = + _CHROFF_16_4_;
	{long i; for (i = 68; i < 70; i++) O8891[i] = + _CHROFF_20_4_;}
	{long i; for (i = 70; i < 72; i++) O8891[i] = + _CHROFF_25_5_;}
	{long i; for (i = 72; i < 74; i++) O8891[i] = + _CHROFF_21_6_;}
	{long i; for (i = 74; i < 78; i++) O8891[i] = + _CHROFF_17_5_;}
	O8891[78] = + _CHROFF_18_5_;
	O8891[79] = + _CHROFF_23_7_;
	{long i; for (i = 80; i < 82; i++) O8891[i] = + _CHROFF_23_8_;}
	O8891[82] = + _CHROFF_24_8_;
	O8891[83] = + _CHROFF_26_7_;
	O8891[84] = + _CHROFF_19_4_;
	O8891[85] = + _CHROFF_22_4_;
	{long i; for (i = 86; i < 88; i++) O8891[i] = + _CHROFF_21_9_;}
	{long i; for (i = 88; i < 90; i++) O8891[i] = + _CHROFF_29_13_;}
	O8891[91] = + _CHROFF_36_9_;
	O8891[94] = + _CHROFF_36_8_;
	O8891[96] = + _CHROFF_48_16_;
	O8891[99] = + _CHROFF_48_15_;
}

long O8935[98];
void O8935_init () {
	O8935[0] =  + _REFACS_32_;
	O8935[1] =  + _REFACS_38_;
	O8935[2] =  + _REFACS_33_;
	O8935[3] =  + _REFACS_39_;
	O8935[4] =  + _REFACS_33_;
	O8935[5] =  + _REFACS_34_;
	O8935[6] =  + _REFACS_33_;
	O8935[7] =  + _REFACS_40_;
	O8935[8] =  + _REFACS_42_;
	O8935[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O8935[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O8935[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O8935[i] =  + _REFACS_35_;}
	{long i; for (i = 20; i < 22; i++) O8935[i] =  + _REFACS_39_;}
	{long i; for (i = 22; i < 24; i++) O8935[i] =  + _REFACS_42_;}
	O8935[24] =  + _REFACS_41_;
	O8935[25] =  + _REFACS_42_;
	{long i; for (i = 26; i < 28; i++) O8935[i] =  + _REFACS_41_;}
	{long i; for (i = 28; i < 30; i++) O8935[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O8935[i] =  + _REFACS_49_;}
	O8935[32] =  + _REFACS_32_;
	O8935[33] =  + _REFACS_36_;
	O8935[34] =  + _REFACS_34_;
	O8935[35] =  + _REFACS_33_;
	O8935[36] =  + _REFACS_34_;
	O8935[37] =  + _REFACS_32_;
	{long i; for (i = 38; i < 40; i++) O8935[i] =  + _REFACS_33_;}
	{long i; for (i = 40; i < 42; i++) O8935[i] =  + _REFACS_34_;}
	O8935[42] =  + _REFACS_33_;
	O8935[43] =  + _REFACS_34_;
	O8935[44] =  + _REFACS_38_;
	O8935[45] =  + _REFACS_33_;
	O8935[46] =  + _REFACS_36_;
	O8935[47] =  + _REFACS_38_;
	O8935[48] =  + _REFACS_41_;
	O8935[49] =  + _REFACS_43_;
	O8935[50] =  + _REFACS_41_;
	O8935[51] =  + _REFACS_39_;
	O8935[52] =  + _REFACS_40_;
	{long i; for (i = 53; i < 55; i++) O8935[i] =  + _REFACS_42_;}
	{long i; for (i = 55; i < 57; i++) O8935[i] =  + _REFACS_41_;}
	O8935[57] =  + _REFACS_39_;
	O8935[58] =  + _REFACS_40_;
	O8935[59] =  + _REFACS_43_;
	O8935[60] =  + _REFACS_41_;
	O8935[61] =  + _REFACS_46_;
	O8935[89] =  + _REFACS_33_;
	O8935[92] =  + _REFACS_33_;
	O8935[94] =  + _REFACS_39_;
	O8935[97] =  + _REFACS_39_;
}

long O8936[98];
void O8936_init () {
	O8936[0] =  + _REFACS_33_;
	O8936[1] =  + _REFACS_39_;
	O8936[2] =  + _REFACS_34_;
	O8936[3] =  + _REFACS_40_;
	O8936[4] =  + _REFACS_34_;
	O8936[5] =  + _REFACS_35_;
	O8936[6] =  + _REFACS_34_;
	O8936[7] =  + _REFACS_41_;
	O8936[8] =  + _REFACS_43_;
	O8936[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O8936[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O8936[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O8936[i] =  + _REFACS_36_;}
	{long i; for (i = 20; i < 22; i++) O8936[i] =  + _REFACS_40_;}
	{long i; for (i = 22; i < 24; i++) O8936[i] =  + _REFACS_43_;}
	O8936[24] =  + _REFACS_42_;
	O8936[25] =  + _REFACS_43_;
	{long i; for (i = 26; i < 28; i++) O8936[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O8936[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O8936[i] =  + _REFACS_50_;}
	O8936[32] =  + _REFACS_33_;
	O8936[33] =  + _REFACS_37_;
	O8936[34] =  + _REFACS_35_;
	O8936[35] =  + _REFACS_34_;
	O8936[36] =  + _REFACS_35_;
	O8936[37] =  + _REFACS_33_;
	{long i; for (i = 38; i < 40; i++) O8936[i] =  + _REFACS_34_;}
	{long i; for (i = 40; i < 42; i++) O8936[i] =  + _REFACS_35_;}
	O8936[42] =  + _REFACS_34_;
	O8936[43] =  + _REFACS_35_;
	O8936[44] =  + _REFACS_39_;
	O8936[45] =  + _REFACS_34_;
	O8936[46] =  + _REFACS_37_;
	O8936[47] =  + _REFACS_39_;
	O8936[48] =  + _REFACS_42_;
	O8936[49] =  + _REFACS_44_;
	O8936[50] =  + _REFACS_42_;
	O8936[51] =  + _REFACS_40_;
	O8936[52] =  + _REFACS_41_;
	{long i; for (i = 53; i < 55; i++) O8936[i] =  + _REFACS_43_;}
	{long i; for (i = 55; i < 57; i++) O8936[i] =  + _REFACS_42_;}
	O8936[57] =  + _REFACS_40_;
	O8936[58] =  + _REFACS_41_;
	O8936[59] =  + _REFACS_44_;
	O8936[60] =  + _REFACS_42_;
	O8936[61] =  + _REFACS_47_;
	O8936[89] =  + _REFACS_34_;
	O8936[92] =  + _REFACS_34_;
	O8936[94] =  + _REFACS_40_;
	O8936[97] =  + _REFACS_40_;
}

long O8937[98];
void O8937_init () {
	O8937[0] =  + _REFACS_34_;
	O8937[1] =  + _REFACS_40_;
	O8937[2] =  + _REFACS_35_;
	O8937[3] =  + _REFACS_41_;
	O8937[4] =  + _REFACS_35_;
	O8937[5] =  + _REFACS_36_;
	O8937[6] =  + _REFACS_35_;
	O8937[7] =  + _REFACS_42_;
	O8937[8] =  + _REFACS_44_;
	O8937[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O8937[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O8937[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O8937[i] =  + _REFACS_37_;}
	{long i; for (i = 20; i < 22; i++) O8937[i] =  + _REFACS_41_;}
	{long i; for (i = 22; i < 24; i++) O8937[i] =  + _REFACS_44_;}
	O8937[24] =  + _REFACS_43_;
	O8937[25] =  + _REFACS_44_;
	{long i; for (i = 26; i < 28; i++) O8937[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O8937[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O8937[i] =  + _REFACS_51_;}
	O8937[32] =  + _REFACS_34_;
	O8937[33] =  + _REFACS_38_;
	O8937[34] =  + _REFACS_36_;
	O8937[35] =  + _REFACS_35_;
	O8937[36] =  + _REFACS_36_;
	O8937[37] =  + _REFACS_34_;
	{long i; for (i = 38; i < 40; i++) O8937[i] =  + _REFACS_35_;}
	{long i; for (i = 40; i < 42; i++) O8937[i] =  + _REFACS_36_;}
	O8937[42] =  + _REFACS_35_;
	O8937[43] =  + _REFACS_36_;
	O8937[44] =  + _REFACS_40_;
	O8937[45] =  + _REFACS_35_;
	O8937[46] =  + _REFACS_38_;
	O8937[47] =  + _REFACS_40_;
	O8937[48] =  + _REFACS_43_;
	O8937[49] =  + _REFACS_45_;
	O8937[50] =  + _REFACS_43_;
	O8937[51] =  + _REFACS_41_;
	O8937[52] =  + _REFACS_42_;
	{long i; for (i = 53; i < 55; i++) O8937[i] =  + _REFACS_44_;}
	{long i; for (i = 55; i < 57; i++) O8937[i] =  + _REFACS_43_;}
	O8937[57] =  + _REFACS_41_;
	O8937[58] =  + _REFACS_42_;
	O8937[59] =  + _REFACS_45_;
	O8937[60] =  + _REFACS_43_;
	O8937[61] =  + _REFACS_48_;
	O8937[89] =  + _REFACS_35_;
	O8937[92] =  + _REFACS_35_;
	O8937[94] =  + _REFACS_41_;
	O8937[97] =  + _REFACS_41_;
}

long O8967[97];
void O8967_init () {
	O8967[0] = + _LNGOFF_42_12_10_2_;
	O8967[2] = + _LNGOFF_46_12_10_2_;
	O8967[6] = + _LNGOFF_47_12_10_3_;
	O8967[7] = + _LNGOFF_49_12_10_5_;
	O8967[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O8967[i] = + _LNGOFF_49_13_10_3_;}
	O8967[23] = + _LNGOFF_49_13_10_2_;
	O8967[24] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 25; i < 27; i++) O8967[i] = + _LNGOFF_49_14_10_2_;}
	O8967[27] = + _LNGOFF_59_21_10_2_;
	O8967[28] = + _LNGOFF_59_23_10_2_;
	O8967[29] = + _LNGOFF_65_25_10_2_;
	O8967[30] = + _LNGOFF_68_26_10_2_;
	O8967[46] = + _LNGOFF_42_13_10_2_;
	O8967[47] = + _LNGOFF_45_16_10_3_;
	O8967[48] = + _LNGOFF_58_14_10_5_;
	O8967[49] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 50; i < 52; i++) O8967[i] = + _LNGOFF_44_13_10_2_;}
	{long i; for (i = 52; i < 54; i++) O8967[i] = + _LNGOFF_46_14_10_2_;}
	O8967[54] = + _LNGOFF_50_13_10_5_;
	O8967[55] = + _LNGOFF_51_14_10_5_;
	O8967[56] = + _LNGOFF_43_13_10_2_;
	O8967[57] = + _LNGOFF_44_15_10_2_;
	O8967[58] = + _LNGOFF_51_18_10_2_;
	O8967[59] = + _LNGOFF_46_14_10_2_;
	O8967[60] = + _LNGOFF_59_16_10_5_;
	O8967[93] = + _LNGOFF_48_19_10_2_;
	O8967[96] = + _LNGOFF_48_18_10_2_;
}

long O8968[97];
void O8968_init () {
	O8968[0] = + _LNGOFF_42_12_10_3_;
	O8968[2] = + _LNGOFF_46_12_10_3_;
	O8968[6] = + _LNGOFF_47_12_10_4_;
	O8968[7] = + _LNGOFF_49_12_10_6_;
	O8968[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O8968[i] = + _LNGOFF_49_13_10_4_;}
	O8968[23] = + _LNGOFF_49_13_10_3_;
	O8968[24] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 25; i < 27; i++) O8968[i] = + _LNGOFF_49_14_10_3_;}
	O8968[27] = + _LNGOFF_59_21_10_3_;
	O8968[28] = + _LNGOFF_59_23_10_3_;
	O8968[29] = + _LNGOFF_65_25_10_3_;
	O8968[30] = + _LNGOFF_68_26_10_3_;
	O8968[46] = + _LNGOFF_42_13_10_3_;
	O8968[47] = + _LNGOFF_45_16_10_4_;
	O8968[48] = + _LNGOFF_58_14_10_6_;
	O8968[49] = + _LNGOFF_51_13_10_6_;
	{long i; for (i = 50; i < 52; i++) O8968[i] = + _LNGOFF_44_13_10_3_;}
	{long i; for (i = 52; i < 54; i++) O8968[i] = + _LNGOFF_46_14_10_3_;}
	O8968[54] = + _LNGOFF_50_13_10_6_;
	O8968[55] = + _LNGOFF_51_14_10_6_;
	O8968[56] = + _LNGOFF_43_13_10_3_;
	O8968[57] = + _LNGOFF_44_15_10_3_;
	O8968[58] = + _LNGOFF_51_18_10_3_;
	O8968[59] = + _LNGOFF_46_14_10_3_;
	O8968[60] = + _LNGOFF_59_16_10_6_;
	O8968[93] = + _LNGOFF_48_19_10_3_;
	O8968[96] = + _LNGOFF_48_18_10_3_;
}

long O8969[97];
void O8969_init () {
	O8969[0] = + _LNGOFF_42_12_10_4_;
	O8969[2] = + _LNGOFF_46_12_10_4_;
	O8969[6] = + _LNGOFF_47_12_10_5_;
	O8969[7] = + _LNGOFF_49_12_10_7_;
	O8969[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O8969[i] = + _LNGOFF_49_13_10_5_;}
	O8969[23] = + _LNGOFF_49_13_10_4_;
	O8969[24] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 25; i < 27; i++) O8969[i] = + _LNGOFF_49_14_10_4_;}
	O8969[27] = + _LNGOFF_59_21_10_4_;
	O8969[28] = + _LNGOFF_59_23_10_4_;
	O8969[29] = + _LNGOFF_65_25_10_4_;
	O8969[30] = + _LNGOFF_68_26_10_4_;
	O8969[46] = + _LNGOFF_42_13_10_4_;
	O8969[47] = + _LNGOFF_45_16_10_5_;
	O8969[48] = + _LNGOFF_58_14_10_7_;
	O8969[49] = + _LNGOFF_51_13_10_7_;
	{long i; for (i = 50; i < 52; i++) O8969[i] = + _LNGOFF_44_13_10_4_;}
	{long i; for (i = 52; i < 54; i++) O8969[i] = + _LNGOFF_46_14_10_4_;}
	O8969[54] = + _LNGOFF_50_13_10_7_;
	O8969[55] = + _LNGOFF_51_14_10_7_;
	O8969[56] = + _LNGOFF_43_13_10_4_;
	O8969[57] = + _LNGOFF_44_15_10_4_;
	O8969[58] = + _LNGOFF_51_18_10_4_;
	O8969[59] = + _LNGOFF_46_14_10_4_;
	O8969[60] = + _LNGOFF_59_16_10_7_;
	O8969[93] = + _LNGOFF_48_19_10_4_;
	O8969[96] = + _LNGOFF_48_18_10_4_;
}

long O8970[97];
void O8970_init () {
	O8970[0] = + _LNGOFF_42_12_10_5_;
	O8970[2] = + _LNGOFF_46_12_10_5_;
	O8970[6] = + _LNGOFF_47_12_10_6_;
	O8970[7] = + _LNGOFF_49_12_10_8_;
	O8970[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O8970[i] = + _LNGOFF_49_13_10_6_;}
	O8970[23] = + _LNGOFF_49_13_10_5_;
	O8970[24] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 25; i < 27; i++) O8970[i] = + _LNGOFF_49_14_10_5_;}
	O8970[27] = + _LNGOFF_59_21_10_5_;
	O8970[28] = + _LNGOFF_59_23_10_5_;
	O8970[29] = + _LNGOFF_65_25_10_5_;
	O8970[30] = + _LNGOFF_68_26_10_5_;
	O8970[46] = + _LNGOFF_42_13_10_5_;
	O8970[47] = + _LNGOFF_45_16_10_6_;
	O8970[48] = + _LNGOFF_58_14_10_8_;
	O8970[49] = + _LNGOFF_51_13_10_8_;
	{long i; for (i = 50; i < 52; i++) O8970[i] = + _LNGOFF_44_13_10_5_;}
	{long i; for (i = 52; i < 54; i++) O8970[i] = + _LNGOFF_46_14_10_5_;}
	O8970[54] = + _LNGOFF_50_13_10_8_;
	O8970[55] = + _LNGOFF_51_14_10_8_;
	O8970[56] = + _LNGOFF_43_13_10_5_;
	O8970[57] = + _LNGOFF_44_15_10_5_;
	O8970[58] = + _LNGOFF_51_18_10_5_;
	O8970[59] = + _LNGOFF_46_14_10_5_;
	O8970[60] = + _LNGOFF_59_16_10_8_;
	O8970[93] = + _LNGOFF_48_19_10_5_;
	O8970[96] = + _LNGOFF_48_18_10_5_;
}

long O8975[97];
void O8975_init () {
	O8975[0] =  + _REFACS_41_;
	O8975[2] =  + _REFACS_42_;
	O8975[6] =  + _REFACS_43_;
	O8975[7] =  + _REFACS_45_;
	O8975[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O8975[i] =  + _REFACS_45_;}
	O8975[23] =  + _REFACS_44_;
	O8975[24] =  + _REFACS_45_;
	{long i; for (i = 25; i < 27; i++) O8975[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O8975[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O8975[i] =  + _REFACS_52_;}
	O8975[46] =  + _REFACS_41_;
	O8975[47] =  + _REFACS_44_;
	O8975[48] =  + _REFACS_46_;
	O8975[49] =  + _REFACS_44_;
	O8975[50] =  + _REFACS_42_;
	O8975[51] =  + _REFACS_43_;
	{long i; for (i = 52; i < 54; i++) O8975[i] =  + _REFACS_45_;}
	{long i; for (i = 54; i < 56; i++) O8975[i] =  + _REFACS_44_;}
	O8975[56] =  + _REFACS_42_;
	O8975[57] =  + _REFACS_43_;
	O8975[58] =  + _REFACS_46_;
	O8975[59] =  + _REFACS_44_;
	O8975[60] =  + _REFACS_49_;
	O8975[93] =  + _REFACS_42_;
	O8975[96] =  + _REFACS_42_;
}

long O8984[97];
void O8984_init () {
	O8984[0] = + _I16OFF_42_12_8_;
	O8984[2] = + _I16OFF_46_12_8_;
	O8984[6] = + _I16OFF_47_12_8_;
	O8984[7] = + _I16OFF_49_12_8_;
	O8984[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O8984[i] = + _I16OFF_49_13_8_;}
	O8984[23] = + _I16OFF_49_13_8_;
	O8984[24] = + _I16OFF_51_13_8_;
	{long i; for (i = 25; i < 27; i++) O8984[i] = + _I16OFF_49_14_8_;}
	O8984[27] = + _I16OFF_59_21_8_;
	O8984[28] = + _I16OFF_59_23_8_;
	O8984[29] = + _I16OFF_65_25_8_;
	O8984[30] = + _I16OFF_68_26_8_;
	O8984[46] = + _I16OFF_42_13_8_;
	O8984[47] = + _I16OFF_45_16_8_;
	O8984[48] = + _I16OFF_58_14_8_;
	O8984[49] = + _I16OFF_51_13_8_;
	{long i; for (i = 50; i < 52; i++) O8984[i] = + _I16OFF_44_13_8_;}
	{long i; for (i = 52; i < 54; i++) O8984[i] = + _I16OFF_46_14_8_;}
	O8984[54] = + _I16OFF_50_13_8_;
	O8984[55] = + _I16OFF_51_14_8_;
	O8984[56] = + _I16OFF_43_13_8_;
	O8984[57] = + _I16OFF_44_15_8_;
	O8984[58] = + _I16OFF_51_18_8_;
	O8984[59] = + _I16OFF_46_14_8_;
	O8984[60] = + _I16OFF_59_16_8_;
	O8984[93] = + _I16OFF_48_19_8_;
	O8984[96] = + _I16OFF_48_18_8_;
}

long O8985[97];
void O8985_init () {
	O8985[0] = + _I16OFF_42_12_9_;
	O8985[2] = + _I16OFF_46_12_9_;
	O8985[6] = + _I16OFF_47_12_9_;
	O8985[7] = + _I16OFF_49_12_9_;
	O8985[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O8985[i] = + _I16OFF_49_13_9_;}
	O8985[23] = + _I16OFF_49_13_9_;
	O8985[24] = + _I16OFF_51_13_9_;
	{long i; for (i = 25; i < 27; i++) O8985[i] = + _I16OFF_49_14_9_;}
	O8985[27] = + _I16OFF_59_21_9_;
	O8985[28] = + _I16OFF_59_23_9_;
	O8985[29] = + _I16OFF_65_25_9_;
	O8985[30] = + _I16OFF_68_26_9_;
	O8985[46] = + _I16OFF_42_13_9_;
	O8985[47] = + _I16OFF_45_16_9_;
	O8985[48] = + _I16OFF_58_14_9_;
	O8985[49] = + _I16OFF_51_13_9_;
	{long i; for (i = 50; i < 52; i++) O8985[i] = + _I16OFF_44_13_9_;}
	{long i; for (i = 52; i < 54; i++) O8985[i] = + _I16OFF_46_14_9_;}
	O8985[54] = + _I16OFF_50_13_9_;
	O8985[55] = + _I16OFF_51_14_9_;
	O8985[56] = + _I16OFF_43_13_9_;
	O8985[57] = + _I16OFF_44_15_9_;
	O8985[58] = + _I16OFF_51_18_9_;
	O8985[59] = + _I16OFF_46_14_9_;
	O8985[60] = + _I16OFF_59_16_9_;
	O8985[93] = + _I16OFF_48_19_9_;
	O8985[96] = + _I16OFF_48_18_9_;
}

long O9013[29];
void O9013_init () {
	O9013[0] =  + _REFACS_44_;
	O9013[4] =  + _REFACS_45_;
	O9013[5] =  + _REFACS_47_;
	O9013[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O9013[i] =  + _REFACS_47_;}
	O9013[21] =  + _REFACS_46_;
	O9013[22] =  + _REFACS_47_;
	{long i; for (i = 23; i < 25; i++) O9013[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O9013[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O9013[i] =  + _REFACS_54_;}
}

long O9027[29];
void O9027_init () {
	O9027[0] =  + _REFACS_45_;
	O9027[4] =  + _REFACS_46_;
	O9027[5] =  + _REFACS_48_;
	O9027[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O9027[i] =  + _REFACS_48_;}
	O9027[21] =  + _REFACS_47_;
	O9027[22] =  + _REFACS_48_;
	{long i; for (i = 23; i < 25; i++) O9027[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O9027[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O9027[i] =  + _REFACS_55_;}
}

long O9098[12];
void O9098_init () {
	{long i; for (i = 0; i < 2; i++) O9098[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O9098[i] =  + _REFACS_46_;}
	{long i; for (i = 8; i < 10; i++) O9098[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O9098[i] =  + _REFACS_56_;}
}

long O9099[12];
void O9099_init () {
	{long i; for (i = 0; i < 2; i++) O9099[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O9099[i] =  + _REFACS_47_;}
	{long i; for (i = 8; i < 10; i++) O9099[i] =  + _REFACS_54_;}
	{long i; for (i = 10; i < 12; i++) O9099[i] =  + _REFACS_57_;}
}

long O9105[12];
void O9105_init () {
	{long i; for (i = 0; i < 2; i++) O9105[i] = + _CHROFF_47_8_;}
	O9105[2] = + _CHROFF_50_8_;
	O9105[3] = + _CHROFF_53_8_;
	{long i; for (i = 8; i < 10; i++) O9105[i] = + _CHROFF_59_13_;}
	O9105[10] = + _CHROFF_65_13_;
	O9105[11] = + _CHROFF_68_13_;
}

long O9126[12];
void O9126_init () {
	{long i; for (i = 0; i < 2; i++) O9126[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O9126[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O9126[i] =  + _REFACS_55_;}
	{long i; for (i = 10; i < 12; i++) O9126[i] =  + _REFACS_58_;}
}

long O9129[12];
void O9129_init () {
	{long i; for (i = 0; i < 2; i++) O9129[i] = + _CHROFF_47_9_;}
	O9129[2] = + _CHROFF_50_9_;
	O9129[3] = + _CHROFF_53_9_;
	{long i; for (i = 8; i < 10; i++) O9129[i] = + _CHROFF_59_14_;}
	O9129[10] = + _CHROFF_65_14_;
	O9129[11] = + _CHROFF_68_14_;
}

long O9130[12];
void O9130_init () {
	{long i; for (i = 0; i < 2; i++) O9130[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O9130[i] =  + _REFACS_49_;}
	{long i; for (i = 8; i < 10; i++) O9130[i] =  + _REFACS_56_;}
	{long i; for (i = 10; i < 12; i++) O9130[i] =  + _REFACS_59_;}
}

long O9167[8];
void O9167_init () {
	O9167[0] =  + _REFACS_48_;
	O9167[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O9167[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O9167[i] =  + _REFACS_57_;}
	O9167[6] =  + _REFACS_60_;
	O9167[7] =  + _REFACS_63_;
}

long O9193[4];
void O9193_init () {
	O9193[0] = + _CHROFF_59_15_;
	O9193[1] = + _CHROFF_59_17_;
	O9193[2] = + _CHROFF_65_16_;
	O9193[3] = + _CHROFF_68_16_;
}

long O9194[4];
void O9194_init () {
	O9194[0] = + _CHROFF_59_16_;
	O9194[1] = + _CHROFF_59_18_;
	O9194[2] = + _CHROFF_65_17_;
	O9194[3] = + _CHROFF_68_17_;
}

long O9195[4];
void O9195_init () {
	O9195[0] = + _CHROFF_59_17_;
	O9195[1] = + _CHROFF_59_19_;
	O9195[2] = + _CHROFF_65_18_;
	O9195[3] = + _CHROFF_68_18_;
}

long O9197[4];
void O9197_init () {
	O9197[0] = + _CHROFF_59_18_;
	O9197[1] = + _CHROFF_59_20_;
	O9197[2] = + _CHROFF_65_19_;
	O9197[3] = + _CHROFF_68_19_;
}

long O9199[4];
void O9199_init () {
	O9199[0] = + _PTROFF_59_21_10_11_0_1_;
	O9199[1] = + _PTROFF_59_23_10_11_0_1_;
	O9199[2] = + _PTROFF_65_25_10_11_0_1_;
	O9199[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O9201[4];
void O9201_init () {
	O9201[0] = + _LNGOFF_59_21_10_6_;
	O9201[1] = + _LNGOFF_59_23_10_6_;
	O9201[2] = + _LNGOFF_65_25_10_6_;
	O9201[3] = + _LNGOFF_68_26_10_6_;
}

long O9202[4];
void O9202_init () {
	O9202[0] = + _LNGOFF_59_21_10_7_;
	O9202[1] = + _LNGOFF_59_23_10_7_;
	O9202[2] = + _LNGOFF_65_25_10_7_;
	O9202[3] = + _LNGOFF_68_26_10_7_;
}

long O9207[4];
void O9207_init () {
	O9207[0] = + _LNGOFF_59_21_10_8_;
	O9207[1] = + _LNGOFF_59_23_10_8_;
	O9207[2] = + _LNGOFF_65_25_10_8_;
	O9207[3] = + _LNGOFF_68_26_10_8_;
}

long O9222[4];
void O9222_init () {
	O9222[0] = + _PTROFF_59_21_10_11_0_2_;
	O9222[1] = + _PTROFF_59_23_10_11_0_2_;
	O9222[2] = + _PTROFF_65_25_10_11_0_2_;
	O9222[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O9223[4];
void O9223_init () {
	O9223[0] = + _PTROFF_59_21_10_11_0_3_;
	O9223[1] = + _PTROFF_59_23_10_11_0_3_;
	O9223[2] = + _PTROFF_65_25_10_11_0_3_;
	O9223[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O9225[4];
void O9225_init () {
	O9225[0] = + _LNGOFF_59_21_10_9_;
	O9225[1] = + _LNGOFF_59_23_10_9_;
	O9225[2] = + _LNGOFF_65_25_10_9_;
	O9225[3] = + _LNGOFF_68_26_10_9_;
}

long O9226[4];
void O9226_init () {
	O9226[0] = + _LNGOFF_59_21_10_10_;
	O9226[1] = + _LNGOFF_59_23_10_10_;
	O9226[2] = + _LNGOFF_65_25_10_10_;
	O9226[3] = + _LNGOFF_68_26_10_10_;
}

long O9410[51];
void O9410_init () {
	O9410[0] = + _CHROFF_42_10_;
	O9410[1] = + _CHROFF_45_11_;
	O9410[2] = + _CHROFF_58_10_;
	O9410[3] = + _CHROFF_51_10_;
	{long i; for (i = 4; i < 6; i++) O9410[i] = + _CHROFF_44_10_;}
	{long i; for (i = 6; i < 8; i++) O9410[i] = + _CHROFF_46_10_;}
	O9410[8] = + _CHROFF_50_10_;
	O9410[9] = + _CHROFF_51_11_;
	O9410[10] = + _CHROFF_43_10_;
	O9410[11] = + _CHROFF_44_10_;
	O9410[12] = + _CHROFF_51_13_;
	O9410[13] = + _CHROFF_46_10_;
	O9410[14] = + _CHROFF_59_10_;
	O9410[47] = + _CHROFF_48_10_;
	O9410[50] = + _CHROFF_48_10_;
}

long O9598[18];
void O9598_init () {
	{long i; for (i = 0; i < 2; i++) O9598[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O9598[i] =  + _REFACS_22_;}
	O9598[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O9598[i] =  + _REFACS_26_;}
}

long O9604[5];
void O9604_init () {
	O9604[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O9604[i] = + _PTROFF_23_9_6_1_0_3_;}
	O9604[3] = + _PTROFF_24_9_6_1_0_3_;
	O9604[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O9666[10];
void O9666_init () {
	O9666[0] = + _LNGOFF_1_1_0_0_;
	O9666[1] = + _LNGOFF_36_10_6_1_;
	{long i; for (i = 2; i < 4; i++) O9666[i] = + _LNGOFF_1_1_0_0_;}
	O9666[4] = + _LNGOFF_36_9_6_1_;
	O9666[5] = + _LNGOFF_6_5_0_0_;
	O9666[6] = + _LNGOFF_48_19_10_6_;
	O9666[7] = + _LNGOFF_6_5_0_0_;
	O9666[8] = + _LNGOFF_6_7_0_0_;
	O9666[9] = + _LNGOFF_48_18_10_6_;
}

long O9742[5];
void O9742_init () {
	O9742[0] = + _PTROFF_6_5_0_3_0_0_;
	O9742[1] = + _PTROFF_48_19_10_9_0_1_;
	O9742[2] = + _PTROFF_6_5_0_3_0_0_;
	O9742[3] = + _PTROFF_6_7_0_5_0_0_;
	O9742[4] = + _PTROFF_48_18_10_9_0_1_;
}

long O9750[5];
void O9750_init () {
	O9750[0] = + _CHROFF_6_3_;
	O9750[1] = + _CHROFF_48_17_;
	O9750[2] = + _CHROFF_6_3_;
	O9750[3] = + _CHROFF_6_5_;
	O9750[4] = + _CHROFF_48_16_;
}

long O9751[5];
void O9751_init () {
	O9751[0] = + _CHROFF_6_4_;
	O9751[1] = + _CHROFF_48_18_;
	O9751[2] = + _CHROFF_6_4_;
	O9751[3] = + _CHROFF_6_6_;
	O9751[4] = + _CHROFF_48_17_;
}

long O9755[5];
void O9755_init () {
	O9755[0] = + _CHROFF_6_0_;
	O9755[1] = + _CHROFF_48_12_;
	{long i; for (i = 2; i < 4; i++) O9755[i] = + _CHROFF_6_0_;}
	O9755[4] = + _CHROFF_48_11_;
}

long O9756[5];
void O9756_init () {
	O9756[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O9756[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O9756[2] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O9756[3] = + _R64OFF_6_7_0_5_0_5_0_0_;
	O9756[4] = + _R64OFF_48_18_10_9_0_4_0_0_;
}

long O9775[5];
void O9775_init () {
	O9775[0] =  + _REFACS_2_;
	O9775[1] =  + _REFACS_44_;
	{long i; for (i = 2; i < 4; i++) O9775[i] =  + _REFACS_2_;}
	O9775[4] =  + _REFACS_44_;
}

long O9776[5];
void O9776_init () {
	O9776[0] =  + _REFACS_3_;
	O9776[1] =  + _REFACS_45_;
	{long i; for (i = 2; i < 4; i++) O9776[i] =  + _REFACS_3_;}
	O9776[4] =  + _REFACS_45_;
}

long O9780[5];
void O9780_init () {
	O9780[0] =  + _REFACS_4_;
	O9780[1] =  + _REFACS_46_;
	{long i; for (i = 2; i < 4; i++) O9780[i] =  + _REFACS_4_;}
	O9780[4] =  + _REFACS_46_;
}

long O9781[5];
void O9781_init () {
	O9781[0] = + _CHROFF_6_1_;
	O9781[1] = + _CHROFF_48_13_;
	{long i; for (i = 2; i < 4; i++) O9781[i] = + _CHROFF_6_1_;}
	O9781[4] = + _CHROFF_48_12_;
}

long O9782[5];
void O9782_init () {
	O9782[0] =  + _REFACS_5_;
	O9782[1] =  + _REFACS_47_;
	{long i; for (i = 2; i < 4; i++) O9782[i] =  + _REFACS_5_;}
	O9782[4] =  + _REFACS_47_;
}

long O9783[5];
void O9783_init () {
	O9783[0] = + _LNGOFF_6_5_0_1_;
	O9783[1] = + _LNGOFF_48_19_10_7_;
	O9783[2] = + _LNGOFF_6_5_0_1_;
	O9783[3] = + _LNGOFF_6_7_0_1_;
	O9783[4] = + _LNGOFF_48_18_10_7_;
}

long O9784[5];
void O9784_init () {
	O9784[0] = + _LNGOFF_6_5_0_2_;
	O9784[1] = + _LNGOFF_48_19_10_8_;
	O9784[2] = + _LNGOFF_6_5_0_2_;
	O9784[3] = + _LNGOFF_6_7_0_2_;
	O9784[4] = + _LNGOFF_48_18_10_8_;
}


#ifdef __cplusplus
}
#endif
