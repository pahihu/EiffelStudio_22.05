#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4614[9])();
void R4614_init () {
	R4614[0] = (char *(*)()) F610_5057;
	R4614[1] = (char *(*)()) F611_5057;
	R4614[2] = (char *(*)()) F612_5057;
	R4614[3] = (char *(*)()) F613_5057;
	R4614[4] = (char *(*)()) F614_5057;
	R4614[5] = (char *(*)()) F615_5057;
	R4614[6] = (char *(*)()) F610_5057;
	R4614[7] = (char *(*)()) F612_5057;
	R4614[8] = (char *(*)()) F610_5057;
}

char *(*R4617[9])();
void R4617_init () {
	R4617[0] = (char *(*)()) F610_5060;
	R4617[1] = (char *(*)()) F611_5060;
	R4617[2] = (char *(*)()) F612_5060;
	R4617[3] = (char *(*)()) F613_5060;
	R4617[4] = (char *(*)()) F614_5060;
	R4617[5] = (char *(*)()) F615_5060;
	R4617[6] = (char *(*)()) F610_5060;
	R4617[7] = (char *(*)()) F612_5060;
	R4617[8] = (char *(*)()) F610_5060;
}

char *(*R4618[9])();
void R4618_init () {
	R4618[0] = (char *(*)()) F610_5061;
	R4618[1] = (char *(*)()) F611_5061;
	R4618[2] = (char *(*)()) F612_5061_4618_1;
	R4618[3] = (char *(*)()) F613_5061_4618_1;
	R4618[4] = (char *(*)()) F614_5061_4618_1;
	R4618[5] = (char *(*)()) F615_5061_4618_1;
	R4618[6] = (char *(*)()) F610_5061;
	R4618[7] = (char *(*)()) F612_5061_4618_1;
	R4618[8] = (char *(*)()) F610_5061;
}
static EIF_REFERENCE F612_5061_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F612_5061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5061_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5061_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F614_5061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5061_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F615_5061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4623[9])();
void R4623_init () {
	R4623[0] = (char *(*)()) F610_5069;
	R4623[1] = (char *(*)()) F611_5069;
	R4623[2] = (char *(*)()) F612_5069_4623_1;
	R4623[3] = (char *(*)()) F613_5069_4623_1;
	R4623[4] = (char *(*)()) F614_5069_4623_1;
	R4623[5] = (char *(*)()) F615_5069_4623_1;
	R4623[6] = (char *(*)()) F610_5069;
	R4623[7] = (char *(*)()) F612_5069_4623_1;
	R4623[8] = (char *(*)()) F610_5069;
}
static EIF_REFERENCE F612_5069_4623_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F612_5069(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5069_4623_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5069(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5069_4623_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F614_5069(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5069_4623_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F615_5069(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4624[9])();
void R4624_init () {
	R4624[0] = (char *(*)()) F610_5070;
	R4624[1] = (char *(*)()) F611_5070_4624_1;
	R4624[2] = (char *(*)()) F612_5070;
	R4624[3] = (char *(*)()) F613_5070_4624_1;
	R4624[4] = (char *(*)()) F614_5070;
	R4624[5] = (char *(*)()) F615_5070_4624_1;
	R4624[6] = (char *(*)()) F610_5070;
	R4624[7] = (char *(*)()) F612_5070;
	R4624[8] = (char *(*)()) F610_5070;
}
static EIF_REFERENCE F611_5070_4624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F611_5070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5070_4624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5070_4624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F615_5070(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R4626[9])();
void R4626_init () {
	R4626[0] = (char *(*)()) F610_5074;
	R4626[1] = (char *(*)()) F611_5074_4626_65;
	R4626[2] = (char *(*)()) F612_5074;
	R4626[3] = (char *(*)()) F613_5074_4626_65;
	R4626[4] = (char *(*)()) F614_5074;
	R4626[5] = (char *(*)()) F615_5074_4626_65;
	R4626[6] = (char *(*)()) F616_5171;
	R4626[7] = (char *(*)()) F617_5171;
	R4626[8] = (char *(*)()) F610_5074;
}
static EIF_INTEGER_32 F611_5074_4626_65 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F611_5074(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F613_5074_4626_65 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F613_5074(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F615_5074_4626_65 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F615_5074(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R4628[9])();
void R4628_init () {
	R4628[0] = (char *(*)()) F610_5081;
	R4628[1] = (char *(*)()) F611_5081_4628_3;
	R4628[2] = (char *(*)()) F612_5081;
	R4628[3] = (char *(*)()) F613_5081_4628_3;
	R4628[4] = (char *(*)()) F614_5081;
	R4628[5] = (char *(*)()) F615_5081_4628_3;
	R4628[6] = (char *(*)()) F616_5173;
	R4628[7] = (char *(*)()) F617_5173;
	R4628[8] = (char *(*)()) F610_5081;
}
static EIF_BOOLEAN F611_5081_4628_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F611_5081(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F613_5081_4628_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F613_5081(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F615_5081_4628_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F615_5081(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}

char *(*R4634[9])();
void R4634_init () {
	R4634[0] = (char *(*)()) F610_5089;
	R4634[1] = (char *(*)()) F611_5089;
	R4634[2] = (char *(*)()) F612_5089;
	R4634[3] = (char *(*)()) F613_5089;
	R4634[4] = (char *(*)()) F614_5089;
	R4634[5] = (char *(*)()) F615_5089;
	R4634[6] = (char *(*)()) F610_5089;
	R4634[7] = (char *(*)()) F612_5089;
	R4634[8] = (char *(*)()) F610_5089;
}

char *(*R4635[9])();
void R4635_init () {
	R4635[0] = (char *(*)()) F610_5090;
	R4635[1] = (char *(*)()) F611_5090;
	R4635[2] = (char *(*)()) F612_5090;
	R4635[3] = (char *(*)()) F613_5090;
	R4635[4] = (char *(*)()) F614_5090;
	R4635[5] = (char *(*)()) F615_5090;
	R4635[6] = (char *(*)()) F610_5090;
	R4635[7] = (char *(*)()) F612_5090;
	R4635[8] = (char *(*)()) F610_5090;
}

char *(*R4636[9])();
void R4636_init () {
	R4636[0] = (char *(*)()) F610_5091;
	R4636[1] = (char *(*)()) F611_5091;
	R4636[2] = (char *(*)()) F612_5091;
	R4636[3] = (char *(*)()) F613_5091;
	R4636[4] = (char *(*)()) F614_5091;
	R4636[5] = (char *(*)()) F615_5091;
	R4636[6] = (char *(*)()) F610_5091;
	R4636[7] = (char *(*)()) F612_5091;
	R4636[8] = (char *(*)()) F610_5091;
}

char *(*R4637[9])();
void R4637_init () {
	R4637[0] = (char *(*)()) F610_5092;
	R4637[1] = (char *(*)()) F611_5092;
	R4637[2] = (char *(*)()) F612_5092;
	R4637[3] = (char *(*)()) F613_5092;
	R4637[4] = (char *(*)()) F614_5092;
	R4637[5] = (char *(*)()) F615_5092;
	R4637[6] = (char *(*)()) F610_5092;
	R4637[7] = (char *(*)()) F612_5092;
	R4637[8] = (char *(*)()) F610_5092;
}

char *(*R4640[9])();
void R4640_init () {
	R4640[0] = (char *(*)()) F610_5096;
	R4640[1] = (char *(*)()) F611_5096;
	R4640[2] = (char *(*)()) F612_5096;
	R4640[3] = (char *(*)()) F613_5096;
	R4640[4] = (char *(*)()) F614_5096;
	R4640[5] = (char *(*)()) F615_5096;
	R4640[6] = (char *(*)()) F610_5096;
	R4640[7] = (char *(*)()) F612_5096;
	R4640[8] = (char *(*)()) F610_5096;
}

char *(*R4641[9])();
void R4641_init () {
	R4641[0] = (char *(*)()) F610_5097;
	R4641[1] = (char *(*)()) F611_5097;
	R4641[2] = (char *(*)()) F612_5097;
	R4641[3] = (char *(*)()) F613_5097;
	R4641[4] = (char *(*)()) F614_5097;
	R4641[5] = (char *(*)()) F615_5097;
	R4641[6] = (char *(*)()) F610_5097;
	R4641[7] = (char *(*)()) F612_5097;
	R4641[8] = (char *(*)()) F610_5097;
}

char *(*R4643[9])();
void R4643_init () {
	R4643[0] = (char *(*)()) F610_5099;
	R4643[1] = (char *(*)()) F611_5099_4643_4;
	R4643[2] = (char *(*)()) F612_5099;
	R4643[3] = (char *(*)()) F613_5099_4643_4;
	R4643[4] = (char *(*)()) F614_5099;
	R4643[5] = (char *(*)()) F615_5099_4643_4;
	R4643[6] = (char *(*)()) F610_5099;
	R4643[7] = (char *(*)()) F612_5099;
	R4643[8] = (char *(*)()) F610_5099;
}
static void F611_5099_4643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_5099(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F613_5099_4643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_5099(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F615_5099_4643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F615_5099(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R4645[9])();
void R4645_init () {
	R4645[0] = (char *(*)()) F610_5101;
	R4645[1] = (char *(*)()) F611_5101;
	R4645[2] = (char *(*)()) F612_5101;
	R4645[3] = (char *(*)()) F613_5101;
	R4645[4] = (char *(*)()) F614_5101;
	R4645[5] = (char *(*)()) F615_5101;
	R4645[6] = (char *(*)()) F610_5101;
	R4645[7] = (char *(*)()) F612_5101;
	R4645[8] = (char *(*)()) F610_5101;
}

char *(*R4646[9])();
void R4646_init () {
	R4646[0] = (char *(*)()) F610_5102;
	R4646[1] = (char *(*)()) F611_5102;
	R4646[2] = (char *(*)()) F612_5102;
	R4646[3] = (char *(*)()) F613_5102;
	R4646[4] = (char *(*)()) F614_5102;
	R4646[5] = (char *(*)()) F615_5102;
	R4646[6] = (char *(*)()) F610_5102;
	R4646[7] = (char *(*)()) F612_5102;
	R4646[8] = (char *(*)()) F610_5102;
}

char *(*R4652[9])();
void R4652_init () {
	R4652[0] = (char *(*)()) F610_5115;
	R4652[1] = (char *(*)()) F611_5115;
	R4652[2] = (char *(*)()) F612_5115;
	R4652[3] = (char *(*)()) F613_5115;
	R4652[4] = (char *(*)()) F614_5115;
	R4652[5] = (char *(*)()) F615_5115;
	R4652[6] = (char *(*)()) F616_5175;
	R4652[7] = (char *(*)()) F617_5175;
	R4652[8] = (char *(*)()) F610_5115;
}

char *(*R4661[9])();
void R4661_init () {
	R4661[0] = (char *(*)()) F610_5125;
	R4661[1] = (char *(*)()) F611_5125;
	R4661[2] = (char *(*)()) F612_5125;
	R4661[3] = (char *(*)()) F613_5125;
	R4661[4] = (char *(*)()) F614_5125;
	R4661[5] = (char *(*)()) F615_5125;
	R4661[6] = (char *(*)()) F610_5125;
	R4661[7] = (char *(*)()) F612_5125;
	R4661[8] = (char *(*)()) F610_5125;
}

char *(*R4662[9])();
void R4662_init () {
	R4662[0] = (char *(*)()) F610_5126;
	R4662[1] = (char *(*)()) F611_5126;
	R4662[2] = (char *(*)()) F612_5126;
	R4662[3] = (char *(*)()) F613_5126;
	R4662[4] = (char *(*)()) F614_5126;
	R4662[5] = (char *(*)()) F615_5126;
	R4662[6] = (char *(*)()) F610_5126;
	R4662[7] = (char *(*)()) F612_5126;
	R4662[8] = (char *(*)()) F610_5126;
}

char *(*R4669[9])();
void R4669_init () {
	R4669[0] = (char *(*)()) F610_5133;
	R4669[1] = (char *(*)()) F611_5133;
	R4669[2] = (char *(*)()) F612_5133_4669_1;
	R4669[3] = (char *(*)()) F613_5133_4669_1;
	R4669[4] = (char *(*)()) F614_5133_4669_1;
	R4669[5] = (char *(*)()) F615_5133_4669_1;
	R4669[6] = (char *(*)()) F610_5133;
	R4669[7] = (char *(*)()) F612_5133_4669_1;
	R4669[8] = (char *(*)()) F610_5133;
}
static EIF_REFERENCE F612_5133_4669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F612_5133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5133_4669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_5133_4669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F614_5133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5133_4669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F615_5133(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4670[9])();
void R4670_init () {
	R4670[0] = (char *(*)()) F610_5134;
	R4670[1] = (char *(*)()) F611_5134_4670_1;
	R4670[2] = (char *(*)()) F612_5134;
	R4670[3] = (char *(*)()) F613_5134_4670_1;
	R4670[4] = (char *(*)()) F614_5134;
	R4670[5] = (char *(*)()) F615_5134_4670_1;
	R4670[6] = (char *(*)()) F610_5134;
	R4670[7] = (char *(*)()) F612_5134;
	R4670[8] = (char *(*)()) F610_5134;
}
static EIF_REFERENCE F611_5134_4670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F611_5134(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5134_4670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5134(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_5134_4670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F615_5134(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R4671[9])();
void R4671_init () {
	R4671[0] = (char *(*)()) F610_5135;
	R4671[1] = (char *(*)()) F611_5135;
	R4671[2] = (char *(*)()) F612_5135;
	R4671[3] = (char *(*)()) F613_5135;
	R4671[4] = (char *(*)()) F614_5135;
	R4671[5] = (char *(*)()) F615_5135;
	R4671[6] = (char *(*)()) F610_5135;
	R4671[7] = (char *(*)()) F612_5135;
	R4671[8] = (char *(*)()) F610_5135;
}

char *(*R4672[9])();
void R4672_init () {
	R4672[0] = (char *(*)()) F610_5136;
	R4672[1] = (char *(*)()) F611_5136;
	R4672[2] = (char *(*)()) F612_5136;
	R4672[3] = (char *(*)()) F613_5136;
	R4672[4] = (char *(*)()) F614_5136;
	R4672[5] = (char *(*)()) F615_5136;
	R4672[6] = (char *(*)()) F610_5136;
	R4672[7] = (char *(*)()) F612_5136;
	R4672[8] = (char *(*)()) F610_5136;
}

char *(*R4673[9])();
void R4673_init () {
	R4673[0] = (char *(*)()) F610_5137;
	R4673[1] = (char *(*)()) F611_5137;
	R4673[2] = (char *(*)()) F612_5137;
	R4673[3] = (char *(*)()) F613_5137;
	R4673[4] = (char *(*)()) F614_5137;
	R4673[5] = (char *(*)()) F615_5137;
	R4673[6] = (char *(*)()) F610_5137;
	R4673[7] = (char *(*)()) F612_5137;
	R4673[8] = (char *(*)()) F610_5137;
}

char *(*R4674[9])();
void R4674_init () {
	R4674[0] = (char *(*)()) F610_5138;
	R4674[1] = (char *(*)()) F611_5138;
	R4674[2] = (char *(*)()) F612_5138;
	R4674[3] = (char *(*)()) F613_5138;
	R4674[4] = (char *(*)()) F614_5138;
	R4674[5] = (char *(*)()) F615_5138;
	R4674[6] = (char *(*)()) F610_5138;
	R4674[7] = (char *(*)()) F612_5138;
	R4674[8] = (char *(*)()) F610_5138;
}

char *(*R4675[9])();
void R4675_init () {
	R4675[0] = (char *(*)()) F610_5139;
	R4675[1] = (char *(*)()) F611_5139;
	R4675[2] = (char *(*)()) F612_5139;
	R4675[3] = (char *(*)()) F613_5139;
	R4675[4] = (char *(*)()) F614_5139;
	R4675[5] = (char *(*)()) F615_5139;
	R4675[6] = (char *(*)()) F610_5139;
	R4675[7] = (char *(*)()) F612_5139;
	R4675[8] = (char *(*)()) F610_5139;
}

char *(*R4677[9])();
void R4677_init () {
	R4677[0] = (char *(*)()) F610_5141;
	R4677[1] = (char *(*)()) F611_5141;
	R4677[2] = (char *(*)()) F612_5141;
	R4677[3] = (char *(*)()) F613_5141;
	R4677[4] = (char *(*)()) F614_5141;
	R4677[5] = (char *(*)()) F615_5141;
	R4677[6] = (char *(*)()) F610_5141;
	R4677[7] = (char *(*)()) F612_5141;
	R4677[8] = (char *(*)()) F610_5141;
}

char *(*R4678[9])();
void R4678_init () {
	R4678[0] = (char *(*)()) F610_5142;
	R4678[1] = (char *(*)()) F611_5142;
	R4678[2] = (char *(*)()) F612_5142;
	R4678[3] = (char *(*)()) F613_5142;
	R4678[4] = (char *(*)()) F614_5142;
	R4678[5] = (char *(*)()) F615_5142;
	R4678[6] = (char *(*)()) F610_5142;
	R4678[7] = (char *(*)()) F612_5142;
	R4678[8] = (char *(*)()) F610_5142;
}

char *(*R4679[9])();
void R4679_init () {
	R4679[0] = (char *(*)()) F610_5143;
	R4679[1] = (char *(*)()) F611_5143;
	R4679[2] = (char *(*)()) F612_5143;
	R4679[3] = (char *(*)()) F613_5143;
	R4679[4] = (char *(*)()) F614_5143;
	R4679[5] = (char *(*)()) F615_5143;
	R4679[6] = (char *(*)()) F610_5143;
	R4679[7] = (char *(*)()) F612_5143;
	R4679[8] = (char *(*)()) F610_5143;
}

char *(*R4683[9])();
void R4683_init () {
	R4683[0] = (char *(*)()) F610_5147;
	R4683[1] = (char *(*)()) F611_5147_4683_4;
	R4683[2] = (char *(*)()) F612_5147;
	R4683[3] = (char *(*)()) F613_5147_4683_4;
	R4683[4] = (char *(*)()) F614_5147;
	R4683[5] = (char *(*)()) F615_5147_4683_4;
	R4683[6] = (char *(*)()) F610_5147;
	R4683[7] = (char *(*)()) F612_5147;
	R4683[8] = (char *(*)()) F610_5147;
}
static void F611_5147_4683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_5147(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F613_5147_4683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_5147(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F615_5147_4683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F615_5147(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R4689[9])();
void R4689_init () {
	R4689[0] = (char *(*)()) F610_5153;
	R4689[1] = (char *(*)()) F611_5153;
	R4689[2] = (char *(*)()) F612_5153;
	R4689[3] = (char *(*)()) F613_5153;
	R4689[4] = (char *(*)()) F614_5153;
	R4689[5] = (char *(*)()) F615_5153;
	R4689[6] = (char *(*)()) F610_5153;
	R4689[7] = (char *(*)()) F612_5153;
	R4689[8] = (char *(*)()) F610_5153;
}

char *(*R4702[9])();
void R4702_init () {
	R4702[0] = (char *(*)()) F610_5166;
	R4702[1] = (char *(*)()) F611_5166;
	R4702[2] = (char *(*)()) F612_5166;
	R4702[3] = (char *(*)()) F613_5166;
	R4702[4] = (char *(*)()) F614_5166;
	R4702[5] = (char *(*)()) F615_5166;
	R4702[6] = (char *(*)()) F610_5166;
	R4702[7] = (char *(*)()) F612_5166;
	R4702[8] = (char *(*)()) F610_5166;
}

char *(*R4705[2])();
void R4705_init () {
	R4705[0] = (char *(*)()) F616_5169;
	R4705[1] = (char *(*)()) F617_5169;
}

char *(*R4718[43])();
void R4718_init () {
	R4718[0] = (char *(*)()) F619_5188;
	R4718[1] = (char *(*)()) F620_5188;
	R4718[2] = (char *(*)()) F621_5188;
	R4718[3] = (char *(*)()) F622_5188;
	R4718[4] = (char *(*)()) F623_5188;
	R4718[5] = (char *(*)()) F624_5188;
	R4718[6] = (char *(*)()) F625_5188;
	R4718[7] = (char *(*)()) F626_5188;
	R4718[8] = (char *(*)()) F627_5188;
	R4718[9] = (char *(*)()) F628_5188;
	R4718[10] = (char *(*)()) F629_5188;
	R4718[11] = (char *(*)()) F630_5188;
	R4718[12] = (char *(*)()) F619_5188;
	R4718[13] = (char *(*)()) F625_5188;
	R4718[14] = (char *(*)()) F622_5188;
	{long i; for (i = 17; i < 20; i++) R4718[i] = (char *(*)()) F619_5188;}
	R4718[24] = (char *(*)()) F619_5188;
	R4718[27] = (char *(*)()) F619_5188;
	R4718[29] = (char *(*)()) F619_5188;
	R4718[32] = (char *(*)()) F619_5188;
	{long i; for (i = 34; i < 38; i++) R4718[i] = (char *(*)()) F619_5188;}
	R4718[40] = (char *(*)()) F619_5188;
	R4718[41] = (char *(*)()) F625_5188;
	R4718[42] = (char *(*)()) F619_5188;
}

char *(*R4722[43])();
void R4722_init () {
	R4722[0] = (char *(*)()) F619_5192;
	R4722[1] = (char *(*)()) F620_5192;
	R4722[2] = (char *(*)()) F621_5192;
	R4722[3] = (char *(*)()) F622_5192;
	R4722[4] = (char *(*)()) F623_5192;
	R4722[5] = (char *(*)()) F624_5192;
	R4722[6] = (char *(*)()) F625_5192;
	R4722[7] = (char *(*)()) F626_5192;
	R4722[8] = (char *(*)()) F627_5192;
	R4722[9] = (char *(*)()) F628_5192;
	R4722[10] = (char *(*)()) F629_5192;
	R4722[11] = (char *(*)()) F630_5192;
	R4722[12] = (char *(*)()) F619_5192;
	R4722[13] = (char *(*)()) F625_5192;
	R4722[14] = (char *(*)()) F622_5192;
	{long i; for (i = 17; i < 20; i++) R4722[i] = (char *(*)()) F619_5192;}
	R4722[24] = (char *(*)()) F619_5192;
	R4722[27] = (char *(*)()) F619_5192;
	R4722[29] = (char *(*)()) F619_5192;
	R4722[32] = (char *(*)()) F619_5192;
	{long i; for (i = 34; i < 38; i++) R4722[i] = (char *(*)()) F619_5192;}
	R4722[40] = (char *(*)()) F619_5192;
	R4722[41] = (char *(*)()) F625_5192;
	R4722[42] = (char *(*)()) F619_5192;
}

char *(*R4726[43])();
void R4726_init () {
	R4726[0] = (char *(*)()) F619_5211;
	R4726[1] = (char *(*)()) F620_5211;
	R4726[2] = (char *(*)()) F621_5211;
	R4726[3] = (char *(*)()) F622_5211;
	R4726[4] = (char *(*)()) F623_5211;
	R4726[5] = (char *(*)()) F624_5211;
	R4726[6] = (char *(*)()) F625_5211;
	R4726[7] = (char *(*)()) F626_5211;
	R4726[8] = (char *(*)()) F627_5211;
	R4726[9] = (char *(*)()) F628_5211;
	R4726[10] = (char *(*)()) F629_5211;
	R4726[11] = (char *(*)()) F630_5211;
	R4726[12] = (char *(*)()) F619_5211;
	R4726[13] = (char *(*)()) F625_5211;
	R4726[14] = (char *(*)()) F622_5211;
	{long i; for (i = 17; i < 20; i++) R4726[i] = (char *(*)()) F619_5211;}
	R4726[24] = (char *(*)()) F619_5211;
	R4726[27] = (char *(*)()) F619_5211;
	R4726[29] = (char *(*)()) F619_5211;
	R4726[32] = (char *(*)()) F619_5211;
	{long i; for (i = 34; i < 38; i++) R4726[i] = (char *(*)()) F619_5211;}
	R4726[40] = (char *(*)()) F619_5211;
	R4726[41] = (char *(*)()) F625_5211;
	R4726[42] = (char *(*)()) F619_5211;
}

char *(*R4730[43])();
void R4730_init () {
	R4730[0] = (char *(*)()) F619_5252;
	R4730[1] = (char *(*)()) F620_5252_4730_262;
	R4730[2] = (char *(*)()) F621_5252_4730_262;
	R4730[3] = (char *(*)()) F622_5252_4730_262;
	R4730[4] = (char *(*)()) F623_5252_4730_262;
	R4730[5] = (char *(*)()) F624_5252_4730_262;
	R4730[6] = (char *(*)()) F625_5252_4730_262;
	R4730[7] = (char *(*)()) F626_5252_4730_262;
	R4730[8] = (char *(*)()) F627_5252_4730_262;
	R4730[9] = (char *(*)()) F628_5252_4730_262;
	R4730[10] = (char *(*)()) F629_5252_4730_262;
	R4730[11] = (char *(*)()) F630_5252_4730_262;
	R4730[12] = (char *(*)()) F619_5252;
	R4730[13] = (char *(*)()) F625_5252_4730_262;
	R4730[14] = (char *(*)()) F622_5252_4730_262;
	{long i; for (i = 17; i < 20; i++) R4730[i] = (char *(*)()) F619_5252;}
	R4730[24] = (char *(*)()) F619_5252;
	R4730[27] = (char *(*)()) F619_5252;
	R4730[29] = (char *(*)()) F619_5252;
	R4730[32] = (char *(*)()) F619_5252;
	{long i; for (i = 34; i < 38; i++) R4730[i] = (char *(*)()) F619_5252;}
	R4730[40] = (char *(*)()) F619_5252;
	R4730[41] = (char *(*)()) F625_5252_4730_262;
	R4730[42] = (char *(*)()) F619_5252;
}
static void F620_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F620_5252(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F621_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F621_5252(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F622_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F622_5252(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F623_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F623_5252(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F624_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F624_5252(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F625_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F625_5252(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F626_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F626_5252(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F627_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F627_5252(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F628_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F628_5252(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F629_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F629_5252(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F630_5252_4730_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F630_5252(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4734[3])();
void R4734_init () {
	R4734[0] = (char *(*)()) F619_5229;
	R4734[1] = (char *(*)()) F625_5229_4734_4;
	R4734[2] = (char *(*)()) F622_5229_4734_4;
}
static void F625_5229_4734_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_5229(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F622_5229_4734_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_5229(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4735[3])();
void R4735_init () {
	R4735[0] = (char *(*)()) F619_5242;
	R4735[1] = (char *(*)()) F625_5242;
	R4735[2] = (char *(*)()) F622_5242;
}

char *(*R4736[26])();
void R4736_init () {
	{long i; for (i = 0; i < 3; i++) R4736[i] = (char *(*)()) F636_5289;}
	R4736[7] = (char *(*)()) F636_5289;
	R4736[10] = (char *(*)()) F636_5289;
	R4736[12] = (char *(*)()) F636_5289;
	R4736[15] = (char *(*)()) F636_5289;
	{long i; for (i = 17; i < 21; i++) R4736[i] = (char *(*)()) F636_5289;}
	R4736[23] = (char *(*)()) F659_5393;
	R4736[24] = (char *(*)()) F660_5393_4736_262;
	R4736[25] = (char *(*)()) F659_5393;
}
static void F660_5393_4736_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_5393(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4737[26])();
void R4737_init () {
	{long i; for (i = 0; i < 3; i++) R4737[i] = (char *(*)()) F636_5290;}
	R4737[7] = (char *(*)()) F636_5290;
	R4737[10] = (char *(*)()) F636_5290;
	R4737[12] = (char *(*)()) F636_5290;
	R4737[15] = (char *(*)()) F636_5290;
	{long i; for (i = 17; i < 21; i++) R4737[i] = (char *(*)()) F636_5290;}
	R4737[23] = (char *(*)()) F659_5394;
	R4737[24] = (char *(*)()) F660_5394_4737_262;
	R4737[25] = (char *(*)()) F659_5394;
}
static void F660_5394_4737_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_5394(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4741[26])();
void R4741_init () {
	{long i; for (i = 0; i < 3; i++) R4741[i] = (char *(*)()) F634_5286;}
	R4741[7] = (char *(*)()) F634_5286;
	R4741[10] = (char *(*)()) F634_5286;
	R4741[12] = (char *(*)()) F634_5286;
	R4741[15] = (char *(*)()) F634_5286;
	{long i; for (i = 17; i < 21; i++) R4741[i] = (char *(*)()) F634_5286;}
	R4741[23] = (char *(*)()) F634_5286;
	R4741[24] = (char *(*)()) F635_5286_4741_262;
	R4741[25] = (char *(*)()) F634_5286;
}
static void F635_5286_4741_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F635_5286(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4742[26])();
void R4742_init () {
	{long i; for (i = 0; i < 3; i++) R4742[i] = (char *(*)()) F634_5287;}
	R4742[7] = (char *(*)()) F634_5287;
	R4742[10] = (char *(*)()) F634_5287;
	R4742[12] = (char *(*)()) F634_5287;
	R4742[15] = (char *(*)()) F634_5287;
	{long i; for (i = 17; i < 21; i++) R4742[i] = (char *(*)()) F634_5287;}
	R4742[23] = (char *(*)()) F634_5287;
	R4742[24] = (char *(*)()) F635_5287_4742_262;
	R4742[25] = (char *(*)()) F634_5287;
}
static void F635_5287_4742_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F635_5287(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4743[21])();
void R4743_init () {
	R4743[0] = (char *(*)()) F636_5291;
	R4743[1] = (char *(*)()) F637_5325;
	R4743[2] = (char *(*)()) F638_5326;
	R4743[7] = (char *(*)()) F637_5325;
	R4743[10] = (char *(*)()) F637_5325;
	R4743[12] = (char *(*)()) F637_5325;
	R4743[15] = (char *(*)()) F637_5325;
	{long i; for (i = 17; i < 21; i++) R4743[i] = (char *(*)()) F637_5325;}
}

static EIF_TYPE_INDEX Y4775_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype2[] = {0xFFF9,1,901,0,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype4[] = {0xFFF9,1,901,1089,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype5[] = {0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype6[] = {0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype7[] = {0xFFF9,1,901,1095,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype8[] = {0xFFF9,1,901,1057,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype9[] = {0xFFF9,1,901,865,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype10[] = {0xFFF9,1,901,1036,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype11[] = {0xFFF9,5,901,919,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype12[] = {0xFFF9,1,901,1287,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype13[] = {0xFFF9,1,901,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype14[] = {0xFFF9,1,901,987,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype15[] = {0xFFF9,7,901,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype16[] = {0xFFF9,2,901,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype17[] = {0xFFF9,4,901,907,907,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype18[] = {0xFFF9,3,901,907,907,865,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype19[] = {0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
static EIF_TYPE_INDEX Y4775_pgtype20[] = {0xFFF9,0,901,0xFFFF};
EIF_TYPE_INDEX *Y4775_gen_type [21];
EIF_TYPE_INDEX Y4775 [21];
void Y4775_init (void)
{
	egc_routines_types [4775] = Y4775;
	egc_routines_gen_types [4775] = Y4775_gen_type;
	egc_routines_offset [4775] = 635;
	Y4775_gen_type [0] = Y4775_pgtype0;
	Y4775_gen_type [1] = Y4775_pgtype1;
	Y4775_gen_type [2] = Y4775_pgtype2;
	Y4775_gen_type [3] = Y4775_pgtype3;
	Y4775_gen_type [4] = Y4775_pgtype4;
	Y4775_gen_type [5] = Y4775_pgtype5;
	Y4775_gen_type [6] = Y4775_pgtype6;
	Y4775_gen_type [7] = Y4775_pgtype7;
	Y4775_gen_type [8] = Y4775_pgtype8;
	Y4775_gen_type [9] = Y4775_pgtype9;
	Y4775_gen_type [10] = Y4775_pgtype10;
	Y4775_gen_type [11] = Y4775_pgtype11;
	Y4775_gen_type [12] = Y4775_pgtype12;
	Y4775_gen_type [13] = Y4775_pgtype13;
	Y4775_gen_type [14] = Y4775_pgtype14;
	Y4775_gen_type [15] = Y4775_pgtype15;
	Y4775_gen_type [16] = Y4775_pgtype16;
	Y4775_gen_type [17] = Y4775_pgtype17;
	Y4775_gen_type [18] = Y4775_pgtype18;
	Y4775_gen_type [19] = Y4775_pgtype19;
	Y4775_gen_type [20] = Y4775_pgtype20;
	Y4775[2] = 901;
	{long i; for (i = 4; i < 21; i++) Y4775[i] = 901;};
}

char *(*R4806[177])();
void R4806_init () {
	R4806[0] = (char *(*)()) F674_5405;
	R4806[5] = (char *(*)()) F444_4680_4806_1;
	R4806[36] = (char *(*)()) F698_5484;
	R4806[37] = (char *(*)()) F699_5484_4806_1;
	R4806[38] = (char *(*)()) F700_5484_4806_1;
	R4806[39] = (char *(*)()) F701_5484_4806_1;
	R4806[40] = (char *(*)()) F702_5484_4806_1;
	R4806[41] = (char *(*)()) F703_5484_4806_1;
	R4806[42] = (char *(*)()) F704_5484_4806_1;
	R4806[43] = (char *(*)()) F705_5484_4806_1;
	R4806[44] = (char *(*)()) F706_5484_4806_1;
	R4806[45] = (char *(*)()) F707_5484_4806_1;
	R4806[46] = (char *(*)()) F708_5484_4806_1;
	R4806[47] = (char *(*)()) F709_5484_4806_1;
	R4806[48] = (char *(*)()) F722_5512;
	R4806[49] = (char *(*)()) F723_5512_4806_1;
	R4806[50] = (char *(*)()) F724_5512_4806_1;
	R4806[51] = (char *(*)()) F725_5518;
	R4806[52] = (char *(*)()) F726_5518;
	R4806[53] = (char *(*)()) F727_5518_4806_1;
	R4806[54] = (char *(*)()) F728_5518_4806_1;
	R4806[55] = (char *(*)()) F729_5518_4806_1;
	R4806[56] = (char *(*)()) F730_5518_4806_1;
	R4806[69] = (char *(*)()) F731_5524;
	R4806[70] = (char *(*)()) F732_5524_4806_1;
	R4806[71] = (char *(*)()) F733_5524_4806_1;
	R4806[72] = (char *(*)()) F734_5524_4806_1;
	R4806[73] = (char *(*)()) F735_5524_4806_1;
	R4806[74] = (char *(*)()) F736_5524_4806_1;
	R4806[75] = (char *(*)()) F737_5524_4806_1;
	R4806[76] = (char *(*)()) F738_5524_4806_1;
	R4806[77] = (char *(*)()) F739_5524_4806_1;
	R4806[78] = (char *(*)()) F740_5524_4806_1;
	R4806[79] = (char *(*)()) F741_5524_4806_1;
	R4806[80] = (char *(*)()) F742_5524_4806_1;
	R4806[81] = (char *(*)()) F739_5524_4806_1;
	R4806[82] = (char *(*)()) F733_5524_4806_1;
	R4806[83] = (char *(*)()) F731_5524;
	R4806[84] = (char *(*)()) F732_5524_4806_1;
	R4806[85] = (char *(*)()) F733_5524_4806_1;
	R4806[86] = (char *(*)()) F734_5524_4806_1;
	R4806[87] = (char *(*)()) F735_5524_4806_1;
	R4806[88] = (char *(*)()) F736_5524_4806_1;
	R4806[89] = (char *(*)()) F737_5524_4806_1;
	R4806[90] = (char *(*)()) F738_5524_4806_1;
	R4806[91] = (char *(*)()) F739_5524_4806_1;
	R4806[92] = (char *(*)()) F740_5524_4806_1;
	R4806[93] = (char *(*)()) F741_5524_4806_1;
	R4806[94] = (char *(*)()) F742_5524_4806_1;
	R4806[95] = (char *(*)()) F731_5524;
	R4806[96] = (char *(*)()) F732_5524_4806_1;
	R4806[97] = (char *(*)()) F733_5524_4806_1;
	R4806[98] = (char *(*)()) F734_5524_4806_1;
	R4806[99] = (char *(*)()) F735_5524_4806_1;
	R4806[100] = (char *(*)()) F736_5524_4806_1;
	R4806[101] = (char *(*)()) F737_5524_4806_1;
	R4806[102] = (char *(*)()) F738_5524_4806_1;
	R4806[103] = (char *(*)()) F739_5524_4806_1;
	R4806[104] = (char *(*)()) F740_5524_4806_1;
	R4806[105] = (char *(*)()) F741_5524_4806_1;
	R4806[106] = (char *(*)()) F742_5524_4806_1;
	R4806[176] = (char *(*)()) F850_5854_4806_1;
}
static EIF_REFERENCE F444_4680_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F444_4680(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F699_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F700_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F701_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F701_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F702_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F703_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F704_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F705_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F706_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F707_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F708_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_5484_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F709_5484(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F723_5512_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F723_5512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F724_5512_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F724_5512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F727_5518_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F727_5518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F728_5518_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F728_5518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F729_5518_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F729_5518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F730_5518_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F730_5518(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F732_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F732_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F733_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F733_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F734_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F734_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F735_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F735_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F736_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F736_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F737_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F737_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F738_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F738_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F739_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F739_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F740_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F740_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F741_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F741_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F742_5524_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F742_5524(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_5854_4806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F850_5854(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4807[177])();
void R4807_init () {
	R4807[0] = (char *(*)()) F674_5406;
	R4807[5] = (char *(*)()) F444_4681;
	R4807[36] = (char *(*)()) F710_5502;
	R4807[37] = (char *(*)()) F711_5502;
	R4807[38] = (char *(*)()) F712_5502;
	R4807[39] = (char *(*)()) F713_5502;
	R4807[40] = (char *(*)()) F714_5502;
	R4807[41] = (char *(*)()) F715_5502;
	R4807[42] = (char *(*)()) F716_5502;
	R4807[43] = (char *(*)()) F717_5502;
	R4807[44] = (char *(*)()) F718_5502;
	R4807[45] = (char *(*)()) F719_5502;
	R4807[46] = (char *(*)()) F720_5502;
	R4807[47] = (char *(*)()) F721_5502;
	R4807[48] = (char *(*)()) F722_5513;
	R4807[49] = (char *(*)()) F723_5513;
	R4807[50] = (char *(*)()) F724_5513;
	R4807[51] = (char *(*)()) F725_5521;
	R4807[52] = (char *(*)()) F726_5521;
	R4807[53] = (char *(*)()) F727_5521;
	R4807[54] = (char *(*)()) F728_5521;
	R4807[55] = (char *(*)()) F729_5521;
	R4807[56] = (char *(*)()) F730_5521;
	R4807[69] = (char *(*)()) F731_5533;
	R4807[70] = (char *(*)()) F732_5533;
	R4807[71] = (char *(*)()) F733_5533;
	R4807[72] = (char *(*)()) F734_5533;
	R4807[73] = (char *(*)()) F735_5533;
	R4807[74] = (char *(*)()) F736_5533;
	R4807[75] = (char *(*)()) F737_5533;
	R4807[76] = (char *(*)()) F738_5533;
	R4807[77] = (char *(*)()) F739_5533;
	R4807[78] = (char *(*)()) F740_5533;
	R4807[79] = (char *(*)()) F741_5533;
	R4807[80] = (char *(*)()) F742_5533;
	R4807[81] = (char *(*)()) F739_5533;
	R4807[82] = (char *(*)()) F733_5533;
	R4807[83] = (char *(*)()) F731_5533;
	R4807[84] = (char *(*)()) F732_5533;
	R4807[85] = (char *(*)()) F733_5533;
	R4807[86] = (char *(*)()) F734_5533;
	R4807[87] = (char *(*)()) F735_5533;
	R4807[88] = (char *(*)()) F736_5533;
	R4807[89] = (char *(*)()) F737_5533;
	R4807[90] = (char *(*)()) F738_5533;
	R4807[91] = (char *(*)()) F739_5533;
	R4807[92] = (char *(*)()) F740_5533;
	R4807[93] = (char *(*)()) F741_5533;
	R4807[94] = (char *(*)()) F742_5533;
	R4807[95] = (char *(*)()) F731_5533;
	R4807[96] = (char *(*)()) F732_5533;
	R4807[97] = (char *(*)()) F733_5533;
	R4807[98] = (char *(*)()) F734_5533;
	R4807[99] = (char *(*)()) F735_5533;
	R4807[100] = (char *(*)()) F736_5533;
	R4807[101] = (char *(*)()) F737_5533;
	R4807[102] = (char *(*)()) F738_5533;
	R4807[103] = (char *(*)()) F739_5533;
	R4807[104] = (char *(*)()) F740_5533;
	R4807[105] = (char *(*)()) F741_5533;
	R4807[106] = (char *(*)()) F742_5533;
	R4807[176] = (char *(*)()) F850_5856;
}

char *(*R4808[177])();
void R4808_init () {
	R4808[0] = (char *(*)()) F674_5407;
	R4808[5] = (char *(*)()) F444_4687;
	R4808[36] = (char *(*)()) F710_5510;
	R4808[37] = (char *(*)()) F711_5510;
	R4808[38] = (char *(*)()) F712_5510;
	R4808[39] = (char *(*)()) F713_5510;
	R4808[40] = (char *(*)()) F714_5510;
	R4808[41] = (char *(*)()) F715_5510;
	R4808[42] = (char *(*)()) F716_5510;
	R4808[43] = (char *(*)()) F717_5510;
	R4808[44] = (char *(*)()) F718_5510;
	R4808[45] = (char *(*)()) F719_5510;
	R4808[46] = (char *(*)()) F720_5510;
	R4808[47] = (char *(*)()) F721_5510;
	R4808[48] = (char *(*)()) F722_5515;
	R4808[49] = (char *(*)()) F723_5515;
	R4808[50] = (char *(*)()) F724_5515;
	R4808[51] = (char *(*)()) F725_5522;
	R4808[52] = (char *(*)()) F726_5522;
	R4808[53] = (char *(*)()) F727_5522;
	R4808[54] = (char *(*)()) F728_5522;
	R4808[55] = (char *(*)()) F729_5522;
	R4808[56] = (char *(*)()) F730_5522;
	R4808[69] = (char *(*)()) F731_5539;
	R4808[70] = (char *(*)()) F732_5539;
	R4808[71] = (char *(*)()) F733_5539;
	R4808[72] = (char *(*)()) F734_5539;
	R4808[73] = (char *(*)()) F735_5539;
	R4808[74] = (char *(*)()) F736_5539;
	R4808[75] = (char *(*)()) F737_5539;
	R4808[76] = (char *(*)()) F738_5539;
	R4808[77] = (char *(*)()) F739_5539;
	R4808[78] = (char *(*)()) F740_5539;
	R4808[79] = (char *(*)()) F741_5539;
	R4808[80] = (char *(*)()) F742_5539;
	R4808[81] = (char *(*)()) F739_5539;
	R4808[82] = (char *(*)()) F733_5539;
	R4808[83] = (char *(*)()) F731_5539;
	R4808[84] = (char *(*)()) F732_5539;
	R4808[85] = (char *(*)()) F733_5539;
	R4808[86] = (char *(*)()) F734_5539;
	R4808[87] = (char *(*)()) F735_5539;
	R4808[88] = (char *(*)()) F736_5539;
	R4808[89] = (char *(*)()) F737_5539;
	R4808[90] = (char *(*)()) F738_5539;
	R4808[91] = (char *(*)()) F739_5539;
	R4808[92] = (char *(*)()) F740_5539;
	R4808[93] = (char *(*)()) F741_5539;
	R4808[94] = (char *(*)()) F742_5539;
	R4808[95] = (char *(*)()) F731_5539;
	R4808[96] = (char *(*)()) F732_5539;
	R4808[97] = (char *(*)()) F733_5539;
	R4808[98] = (char *(*)()) F734_5539;
	R4808[99] = (char *(*)()) F735_5539;
	R4808[100] = (char *(*)()) F736_5539;
	R4808[101] = (char *(*)()) F737_5539;
	R4808[102] = (char *(*)()) F738_5539;
	R4808[103] = (char *(*)()) F739_5539;
	R4808[104] = (char *(*)()) F740_5539;
	R4808[105] = (char *(*)()) F741_5539;
	R4808[106] = (char *(*)()) F742_5539;
	R4808[176] = (char *(*)()) F850_5857;
}

static EIF_TYPE_INDEX Y4809_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype15[] = {25,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype16[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype17[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype93[] = {934,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype94[] = {937,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4809_pgtype119[] = {937,0xFFFF};
EIF_TYPE_INDEX *Y4809_gen_type [189];
EIF_TYPE_INDEX Y4809 [189];
void Y4809_init (void)
{
	egc_routines_types [4809] = Y4809;
	egc_routines_gen_types [4809] = Y4809_gen_type;
	egc_routines_offset [4809] = 661;
	Y4809_gen_type [0] = Y4809_pgtype0;
	Y4809_gen_type [1] = Y4809_pgtype1;
	Y4809_gen_type [2] = Y4809_pgtype2;
	Y4809_gen_type [3] = Y4809_pgtype3;
	Y4809_gen_type [4] = Y4809_pgtype4;
	Y4809_gen_type [5] = Y4809_pgtype5;
	Y4809_gen_type [6] = Y4809_pgtype6;
	Y4809_gen_type [7] = Y4809_pgtype7;
	Y4809_gen_type [8] = Y4809_pgtype8;
	Y4809_gen_type [9] = Y4809_pgtype9;
	Y4809_gen_type [10] = Y4809_pgtype10;
	Y4809_gen_type [11] = Y4809_pgtype11;
	Y4809_gen_type [12] = Y4809_pgtype12;
	Y4809_gen_type [13] = Y4809_pgtype13;
	Y4809_gen_type [14] = Y4809_pgtype14;
	Y4809_gen_type [15] = Y4809_pgtype15;
	Y4809_gen_type [16] = Y4809_pgtype16;
	Y4809_gen_type [17] = Y4809_pgtype17;
	Y4809_gen_type [18] = Y4809_pgtype18;
	Y4809_gen_type [19] = Y4809_pgtype19;
	Y4809_gen_type [20] = Y4809_pgtype20;
	Y4809_gen_type [21] = Y4809_pgtype21;
	Y4809_gen_type [22] = Y4809_pgtype22;
	Y4809_gen_type [23] = Y4809_pgtype23;
	Y4809_gen_type [24] = Y4809_pgtype24;
	Y4809_gen_type [25] = Y4809_pgtype25;
	Y4809_gen_type [26] = Y4809_pgtype26;
	Y4809_gen_type [27] = Y4809_pgtype27;
	Y4809_gen_type [28] = Y4809_pgtype28;
	Y4809_gen_type [29] = Y4809_pgtype29;
	Y4809_gen_type [30] = Y4809_pgtype30;
	Y4809_gen_type [31] = Y4809_pgtype31;
	Y4809_gen_type [32] = Y4809_pgtype32;
	Y4809_gen_type [33] = Y4809_pgtype33;
	Y4809_gen_type [34] = Y4809_pgtype34;
	Y4809_gen_type [35] = Y4809_pgtype35;
	Y4809_gen_type [36] = Y4809_pgtype36;
	Y4809_gen_type [37] = Y4809_pgtype37;
	Y4809_gen_type [38] = Y4809_pgtype38;
	Y4809_gen_type [39] = Y4809_pgtype39;
	Y4809_gen_type [40] = Y4809_pgtype40;
	Y4809_gen_type [41] = Y4809_pgtype41;
	Y4809_gen_type [42] = Y4809_pgtype42;
	Y4809_gen_type [43] = Y4809_pgtype43;
	Y4809_gen_type [44] = Y4809_pgtype44;
	Y4809_gen_type [45] = Y4809_pgtype45;
	Y4809_gen_type [46] = Y4809_pgtype46;
	Y4809_gen_type [47] = Y4809_pgtype47;
	Y4809_gen_type [48] = Y4809_pgtype48;
	Y4809_gen_type [49] = Y4809_pgtype49;
	Y4809_gen_type [50] = Y4809_pgtype50;
	Y4809_gen_type [51] = Y4809_pgtype51;
	Y4809_gen_type [52] = Y4809_pgtype52;
	Y4809_gen_type [53] = Y4809_pgtype53;
	Y4809_gen_type [54] = Y4809_pgtype54;
	Y4809_gen_type [55] = Y4809_pgtype55;
	Y4809_gen_type [56] = Y4809_pgtype56;
	Y4809_gen_type [57] = Y4809_pgtype57;
	Y4809_gen_type [58] = Y4809_pgtype58;
	Y4809_gen_type [59] = Y4809_pgtype59;
	Y4809_gen_type [60] = Y4809_pgtype60;
	Y4809_gen_type [61] = Y4809_pgtype61;
	Y4809_gen_type [62] = Y4809_pgtype62;
	Y4809_gen_type [63] = Y4809_pgtype63;
	Y4809_gen_type [64] = Y4809_pgtype64;
	Y4809_gen_type [65] = Y4809_pgtype65;
	Y4809_gen_type [66] = Y4809_pgtype66;
	Y4809_gen_type [67] = Y4809_pgtype67;
	Y4809_gen_type [68] = Y4809_pgtype68;
	Y4809_gen_type [69] = Y4809_pgtype69;
	Y4809_gen_type [70] = Y4809_pgtype70;
	Y4809_gen_type [71] = Y4809_pgtype71;
	Y4809_gen_type [72] = Y4809_pgtype72;
	Y4809_gen_type [73] = Y4809_pgtype73;
	Y4809_gen_type [74] = Y4809_pgtype74;
	Y4809_gen_type [75] = Y4809_pgtype75;
	Y4809_gen_type [76] = Y4809_pgtype76;
	Y4809_gen_type [77] = Y4809_pgtype77;
	Y4809_gen_type [78] = Y4809_pgtype78;
	Y4809_gen_type [79] = Y4809_pgtype79;
	Y4809_gen_type [80] = Y4809_pgtype80;
	Y4809_gen_type [81] = Y4809_pgtype81;
	Y4809_gen_type [82] = Y4809_pgtype82;
	Y4809_gen_type [83] = Y4809_pgtype83;
	Y4809_gen_type [84] = Y4809_pgtype84;
	Y4809_gen_type [85] = Y4809_pgtype85;
	Y4809_gen_type [86] = Y4809_pgtype86;
	Y4809_gen_type [87] = Y4809_pgtype87;
	Y4809_gen_type [88] = Y4809_pgtype88;
	Y4809_gen_type [89] = Y4809_pgtype89;
	Y4809_gen_type [90] = Y4809_pgtype90;
	Y4809_gen_type [91] = Y4809_pgtype91;
	Y4809_gen_type [92] = Y4809_pgtype92;
	Y4809_gen_type [93] = Y4809_pgtype93;
	Y4809_gen_type [94] = Y4809_pgtype94;
	Y4809_gen_type [95] = Y4809_pgtype95;
	Y4809_gen_type [96] = Y4809_pgtype96;
	Y4809_gen_type [97] = Y4809_pgtype97;
	Y4809_gen_type [98] = Y4809_pgtype98;
	Y4809_gen_type [99] = Y4809_pgtype99;
	Y4809_gen_type [100] = Y4809_pgtype100;
	Y4809_gen_type [101] = Y4809_pgtype101;
	Y4809_gen_type [102] = Y4809_pgtype102;
	Y4809_gen_type [103] = Y4809_pgtype103;
	Y4809_gen_type [104] = Y4809_pgtype104;
	Y4809_gen_type [105] = Y4809_pgtype105;
	Y4809_gen_type [106] = Y4809_pgtype106;
	Y4809_gen_type [107] = Y4809_pgtype107;
	Y4809_gen_type [108] = Y4809_pgtype108;
	Y4809_gen_type [109] = Y4809_pgtype109;
	Y4809_gen_type [110] = Y4809_pgtype110;
	Y4809_gen_type [111] = Y4809_pgtype111;
	Y4809_gen_type [112] = Y4809_pgtype112;
	Y4809_gen_type [113] = Y4809_pgtype113;
	Y4809_gen_type [114] = Y4809_pgtype114;
	Y4809_gen_type [115] = Y4809_pgtype115;
	Y4809_gen_type [116] = Y4809_pgtype116;
	Y4809_gen_type [117] = Y4809_pgtype117;
	Y4809_gen_type [118] = Y4809_pgtype118;
	Y4809_gen_type [188] = Y4809_pgtype119;
	Y4809[15] = 25;
	Y4809[16] = 934;
	Y4809[17] = 907;
	Y4809[93] = 934;
	Y4809[94] = 937;
	Y4809[188] = 937;
}

char *(*R4847[6])();
void R4847_init () {
	R4847[0] = (char *(*)()) F725_5519;
	R4847[1] = (char *(*)()) F726_5519_4847_1;
	R4847[2] = (char *(*)()) F727_5519;
	R4847[3] = (char *(*)()) F728_5519_4847_1;
	R4847[4] = (char *(*)()) F729_5519;
	R4847[5] = (char *(*)()) F730_5519_4847_1;
}
static EIF_REFERENCE F726_5519_4847_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F726_5519(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F728_5519_4847_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F728_5519(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F730_5519_4847_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F730_5519(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R4850[71])();
void R4850_init () {
	R4850[0] = (char *(*)()) F710_5492;
	R4850[1] = (char *(*)()) F711_5492;
	R4850[2] = (char *(*)()) F712_5492;
	R4850[3] = (char *(*)()) F713_5492;
	R4850[4] = (char *(*)()) F714_5492;
	R4850[5] = (char *(*)()) F715_5492;
	R4850[6] = (char *(*)()) F716_5492;
	R4850[7] = (char *(*)()) F717_5492;
	R4850[8] = (char *(*)()) F718_5492;
	R4850[9] = (char *(*)()) F719_5492;
	R4850[10] = (char *(*)()) F720_5492;
	R4850[11] = (char *(*)()) F721_5492;
	R4850[12] = (char *(*)()) F710_5492;
	R4850[13] = (char *(*)()) F714_5492;
	R4850[14] = (char *(*)()) F715_5492;
	{long i; for (i = 15; i < 17; i++) R4850[i] = (char *(*)()) F710_5492;}
	{long i; for (i = 17; i < 19; i++) R4850[i] = (char *(*)()) F714_5492;}
	R4850[19] = (char *(*)()) F719_5492;
	R4850[20] = (char *(*)()) F714_5492;
	R4850[33] = (char *(*)()) F731_5526;
	R4850[34] = (char *(*)()) F732_5526;
	R4850[35] = (char *(*)()) F733_5526;
	R4850[36] = (char *(*)()) F734_5526;
	R4850[37] = (char *(*)()) F735_5526;
	R4850[38] = (char *(*)()) F736_5526;
	R4850[39] = (char *(*)()) F737_5526;
	R4850[40] = (char *(*)()) F738_5526;
	R4850[41] = (char *(*)()) F739_5526;
	R4850[42] = (char *(*)()) F740_5526;
	R4850[43] = (char *(*)()) F741_5526;
	R4850[44] = (char *(*)()) F742_5526;
	R4850[45] = (char *(*)()) F739_5526;
	R4850[46] = (char *(*)()) F733_5526;
	R4850[47] = (char *(*)()) F731_5526;
	R4850[48] = (char *(*)()) F732_5526;
	R4850[49] = (char *(*)()) F733_5526;
	R4850[50] = (char *(*)()) F734_5526;
	R4850[51] = (char *(*)()) F735_5526;
	R4850[52] = (char *(*)()) F736_5526;
	R4850[53] = (char *(*)()) F737_5526;
	R4850[54] = (char *(*)()) F738_5526;
	R4850[55] = (char *(*)()) F739_5526;
	R4850[56] = (char *(*)()) F740_5526;
	R4850[57] = (char *(*)()) F741_5526;
	R4850[58] = (char *(*)()) F742_5526;
	R4850[59] = (char *(*)()) F731_5526;
	R4850[60] = (char *(*)()) F732_5526;
	R4850[61] = (char *(*)()) F733_5526;
	R4850[62] = (char *(*)()) F734_5526;
	R4850[63] = (char *(*)()) F735_5526;
	R4850[64] = (char *(*)()) F736_5526;
	R4850[65] = (char *(*)()) F737_5526;
	R4850[66] = (char *(*)()) F738_5526;
	R4850[67] = (char *(*)()) F739_5526;
	R4850[68] = (char *(*)()) F740_5526;
	R4850[69] = (char *(*)()) F741_5526;
	R4850[70] = (char *(*)()) F742_5526;
}

char *(*R4851[71])();
void R4851_init () {
	R4851[0] = (char *(*)()) F710_5493;
	R4851[1] = (char *(*)()) F711_5493;
	R4851[2] = (char *(*)()) F712_5493;
	R4851[3] = (char *(*)()) F713_5493;
	R4851[4] = (char *(*)()) F714_5493;
	R4851[5] = (char *(*)()) F715_5493;
	R4851[6] = (char *(*)()) F716_5493;
	R4851[7] = (char *(*)()) F717_5493;
	R4851[8] = (char *(*)()) F718_5493;
	R4851[9] = (char *(*)()) F719_5493;
	R4851[10] = (char *(*)()) F720_5493;
	R4851[11] = (char *(*)()) F721_5493;
	R4851[12] = (char *(*)()) F710_5493;
	R4851[13] = (char *(*)()) F714_5493;
	R4851[14] = (char *(*)()) F715_5493;
	{long i; for (i = 15; i < 17; i++) R4851[i] = (char *(*)()) F710_5493;}
	{long i; for (i = 17; i < 19; i++) R4851[i] = (char *(*)()) F714_5493;}
	R4851[19] = (char *(*)()) F719_5493;
	R4851[20] = (char *(*)()) F714_5493;
	R4851[33] = (char *(*)()) F743_5545;
	R4851[34] = (char *(*)()) F744_5545;
	R4851[35] = (char *(*)()) F745_5545;
	R4851[36] = (char *(*)()) F746_5545;
	R4851[37] = (char *(*)()) F747_5545;
	R4851[38] = (char *(*)()) F748_5545;
	R4851[39] = (char *(*)()) F749_5545;
	R4851[40] = (char *(*)()) F750_5545;
	R4851[41] = (char *(*)()) F751_5545;
	R4851[42] = (char *(*)()) F752_5545;
	R4851[43] = (char *(*)()) F753_5545;
	R4851[44] = (char *(*)()) F754_5545;
	R4851[45] = (char *(*)()) F755_5551;
	R4851[46] = (char *(*)()) F756_5557;
	R4851[47] = (char *(*)()) F757_5563;
	R4851[48] = (char *(*)()) F758_5563;
	R4851[49] = (char *(*)()) F759_5563;
	R4851[50] = (char *(*)()) F760_5563;
	R4851[51] = (char *(*)()) F761_5563;
	R4851[52] = (char *(*)()) F762_5563;
	R4851[53] = (char *(*)()) F763_5563;
	R4851[54] = (char *(*)()) F764_5563;
	R4851[55] = (char *(*)()) F765_5563;
	R4851[56] = (char *(*)()) F766_5563;
	R4851[57] = (char *(*)()) F767_5563;
	R4851[58] = (char *(*)()) F768_5563;
	R4851[59] = (char *(*)()) F769_5569;
	R4851[60] = (char *(*)()) F770_5569;
	R4851[61] = (char *(*)()) F771_5569;
	R4851[62] = (char *(*)()) F772_5569;
	R4851[63] = (char *(*)()) F773_5569;
	R4851[64] = (char *(*)()) F774_5569;
	R4851[65] = (char *(*)()) F775_5569;
	R4851[66] = (char *(*)()) F776_5569;
	R4851[67] = (char *(*)()) F777_5569;
	R4851[68] = (char *(*)()) F778_5569;
	R4851[69] = (char *(*)()) F779_5569;
	R4851[70] = (char *(*)()) F780_5569;
}

char *(*R4859[21])();
void R4859_init () {
	R4859[0] = (char *(*)()) F710_5504;
	R4859[1] = (char *(*)()) F711_5504;
	R4859[2] = (char *(*)()) F712_5504;
	R4859[3] = (char *(*)()) F713_5504;
	R4859[4] = (char *(*)()) F714_5504;
	R4859[5] = (char *(*)()) F715_5504;
	R4859[6] = (char *(*)()) F716_5504;
	R4859[7] = (char *(*)()) F717_5504;
	R4859[8] = (char *(*)()) F718_5504;
	R4859[9] = (char *(*)()) F719_5504;
	R4859[10] = (char *(*)()) F720_5504;
	R4859[11] = (char *(*)()) F721_5504;
	R4859[12] = (char *(*)()) F710_5504;
	R4859[13] = (char *(*)()) F714_5504;
	R4859[14] = (char *(*)()) F715_5504;
	{long i; for (i = 15; i < 17; i++) R4859[i] = (char *(*)()) F710_5504;}
	{long i; for (i = 17; i < 19; i++) R4859[i] = (char *(*)()) F714_5504;}
	R4859[19] = (char *(*)()) F719_5504;
	R4859[20] = (char *(*)()) F714_5504;
}

char *(*R4862[71])();
void R4862_init () {
	R4862[0] = (char *(*)()) F710_5509;
	R4862[1] = (char *(*)()) F711_5509;
	R4862[2] = (char *(*)()) F712_5509;
	R4862[3] = (char *(*)()) F713_5509;
	R4862[4] = (char *(*)()) F714_5509;
	R4862[5] = (char *(*)()) F715_5509;
	R4862[6] = (char *(*)()) F716_5509;
	R4862[7] = (char *(*)()) F717_5509;
	R4862[8] = (char *(*)()) F718_5509;
	R4862[9] = (char *(*)()) F719_5509;
	R4862[10] = (char *(*)()) F720_5509;
	R4862[11] = (char *(*)()) F721_5509;
	R4862[12] = (char *(*)()) F722_5514;
	R4862[13] = (char *(*)()) F723_5514;
	R4862[14] = (char *(*)()) F724_5514;
	{long i; for (i = 15; i < 17; i++) R4862[i] = (char *(*)()) F710_5509;}
	{long i; for (i = 17; i < 19; i++) R4862[i] = (char *(*)()) F714_5509;}
	R4862[19] = (char *(*)()) F719_5509;
	R4862[20] = (char *(*)()) F714_5509;
	R4862[33] = (char *(*)()) F731_5538;
	R4862[34] = (char *(*)()) F732_5538;
	R4862[35] = (char *(*)()) F733_5538;
	R4862[36] = (char *(*)()) F734_5538;
	R4862[37] = (char *(*)()) F735_5538;
	R4862[38] = (char *(*)()) F736_5538;
	R4862[39] = (char *(*)()) F737_5538;
	R4862[40] = (char *(*)()) F738_5538;
	R4862[41] = (char *(*)()) F739_5538;
	R4862[42] = (char *(*)()) F740_5538;
	R4862[43] = (char *(*)()) F741_5538;
	R4862[44] = (char *(*)()) F742_5538;
	R4862[45] = (char *(*)()) F739_5538;
	R4862[46] = (char *(*)()) F733_5538;
	R4862[47] = (char *(*)()) F731_5538;
	R4862[48] = (char *(*)()) F732_5538;
	R4862[49] = (char *(*)()) F733_5538;
	R4862[50] = (char *(*)()) F734_5538;
	R4862[51] = (char *(*)()) F735_5538;
	R4862[52] = (char *(*)()) F736_5538;
	R4862[53] = (char *(*)()) F737_5538;
	R4862[54] = (char *(*)()) F738_5538;
	R4862[55] = (char *(*)()) F739_5538;
	R4862[56] = (char *(*)()) F740_5538;
	R4862[57] = (char *(*)()) F741_5538;
	R4862[58] = (char *(*)()) F742_5538;
	R4862[59] = (char *(*)()) F731_5538;
	R4862[60] = (char *(*)()) F732_5538;
	R4862[61] = (char *(*)()) F733_5538;
	R4862[62] = (char *(*)()) F734_5538;
	R4862[63] = (char *(*)()) F735_5538;
	R4862[64] = (char *(*)()) F736_5538;
	R4862[65] = (char *(*)()) F737_5538;
	R4862[66] = (char *(*)()) F738_5538;
	R4862[67] = (char *(*)()) F739_5538;
	R4862[68] = (char *(*)()) F740_5538;
	R4862[69] = (char *(*)()) F741_5538;
	R4862[70] = (char *(*)()) F742_5538;
}

char *(*R4863[71])();
void R4863_init () {
	R4863[0] = (char *(*)()) F710_5511;
	R4863[1] = (char *(*)()) F711_5511;
	R4863[2] = (char *(*)()) F712_5511;
	R4863[3] = (char *(*)()) F713_5511;
	R4863[4] = (char *(*)()) F714_5511;
	R4863[5] = (char *(*)()) F715_5511;
	R4863[6] = (char *(*)()) F716_5511;
	R4863[7] = (char *(*)()) F717_5511;
	R4863[8] = (char *(*)()) F718_5511;
	R4863[9] = (char *(*)()) F719_5511;
	R4863[10] = (char *(*)()) F720_5511;
	R4863[11] = (char *(*)()) F721_5511;
	R4863[12] = (char *(*)()) F722_5516;
	R4863[13] = (char *(*)()) F723_5516;
	R4863[14] = (char *(*)()) F724_5516;
	R4863[15] = (char *(*)()) F725_5523;
	R4863[16] = (char *(*)()) F726_5523;
	R4863[17] = (char *(*)()) F727_5523;
	R4863[18] = (char *(*)()) F728_5523;
	R4863[19] = (char *(*)()) F729_5523;
	R4863[20] = (char *(*)()) F730_5523;
	R4863[33] = (char *(*)()) F743_5548;
	R4863[34] = (char *(*)()) F744_5548;
	R4863[35] = (char *(*)()) F745_5548;
	R4863[36] = (char *(*)()) F746_5548;
	R4863[37] = (char *(*)()) F747_5548;
	R4863[38] = (char *(*)()) F748_5548;
	R4863[39] = (char *(*)()) F749_5548;
	R4863[40] = (char *(*)()) F750_5548;
	R4863[41] = (char *(*)()) F751_5548;
	R4863[42] = (char *(*)()) F752_5548;
	R4863[43] = (char *(*)()) F753_5548;
	R4863[44] = (char *(*)()) F754_5548;
	R4863[45] = (char *(*)()) F755_5554;
	R4863[46] = (char *(*)()) F756_5560;
	R4863[47] = (char *(*)()) F757_5566;
	R4863[48] = (char *(*)()) F758_5566;
	R4863[49] = (char *(*)()) F759_5566;
	R4863[50] = (char *(*)()) F760_5566;
	R4863[51] = (char *(*)()) F761_5566;
	R4863[52] = (char *(*)()) F762_5566;
	R4863[53] = (char *(*)()) F763_5566;
	R4863[54] = (char *(*)()) F764_5566;
	R4863[55] = (char *(*)()) F765_5566;
	R4863[56] = (char *(*)()) F766_5566;
	R4863[57] = (char *(*)()) F767_5566;
	R4863[58] = (char *(*)()) F768_5566;
	R4863[59] = (char *(*)()) F731_5540;
	R4863[60] = (char *(*)()) F732_5540;
	R4863[61] = (char *(*)()) F733_5540;
	R4863[62] = (char *(*)()) F734_5540;
	R4863[63] = (char *(*)()) F735_5540;
	R4863[64] = (char *(*)()) F736_5540;
	R4863[65] = (char *(*)()) F737_5540;
	R4863[66] = (char *(*)()) F738_5540;
	R4863[67] = (char *(*)()) F739_5540;
	R4863[68] = (char *(*)()) F740_5540;
	R4863[69] = (char *(*)()) F741_5540;
	R4863[70] = (char *(*)()) F742_5540;
}

char *(*R4865[21])();
void R4865_init () {
	R4865[0] = (char *(*)()) F710_5490;
	R4865[1] = (char *(*)()) F711_5490;
	R4865[2] = (char *(*)()) F712_5490;
	R4865[3] = (char *(*)()) F713_5490;
	R4865[4] = (char *(*)()) F714_5490;
	R4865[5] = (char *(*)()) F715_5490;
	R4865[6] = (char *(*)()) F716_5490;
	R4865[7] = (char *(*)()) F717_5490;
	R4865[8] = (char *(*)()) F718_5490;
	R4865[9] = (char *(*)()) F719_5490;
	R4865[10] = (char *(*)()) F720_5490;
	R4865[11] = (char *(*)()) F721_5490;
	R4865[12] = (char *(*)()) F710_5490;
	R4865[13] = (char *(*)()) F714_5490;
	R4865[14] = (char *(*)()) F715_5490;
	{long i; for (i = 15; i < 17; i++) R4865[i] = (char *(*)()) F710_5490;}
	{long i; for (i = 17; i < 19; i++) R4865[i] = (char *(*)()) F714_5490;}
	R4865[19] = (char *(*)()) F719_5490;
	R4865[20] = (char *(*)()) F714_5490;
}

char *(*R4878[38])();
void R4878_init () {
	R4878[0] = (char *(*)()) F743_5549;
	R4878[1] = (char *(*)()) F744_5549;
	R4878[2] = (char *(*)()) F745_5549;
	R4878[3] = (char *(*)()) F746_5549;
	R4878[4] = (char *(*)()) F747_5549;
	R4878[5] = (char *(*)()) F748_5549;
	R4878[6] = (char *(*)()) F749_5549;
	R4878[7] = (char *(*)()) F750_5549;
	R4878[8] = (char *(*)()) F751_5549;
	R4878[9] = (char *(*)()) F752_5549;
	R4878[10] = (char *(*)()) F753_5549;
	R4878[11] = (char *(*)()) F754_5549;
	R4878[12] = (char *(*)()) F755_5555;
	R4878[13] = (char *(*)()) F756_5561;
	R4878[14] = (char *(*)()) F757_5567;
	R4878[15] = (char *(*)()) F758_5567;
	R4878[16] = (char *(*)()) F759_5567;
	R4878[17] = (char *(*)()) F760_5567;
	R4878[18] = (char *(*)()) F761_5567;
	R4878[19] = (char *(*)()) F762_5567;
	R4878[20] = (char *(*)()) F763_5567;
	R4878[21] = (char *(*)()) F764_5567;
	R4878[22] = (char *(*)()) F765_5567;
	R4878[23] = (char *(*)()) F766_5567;
	R4878[24] = (char *(*)()) F767_5567;
	R4878[25] = (char *(*)()) F768_5567;
	R4878[26] = (char *(*)()) F769_5571;
	R4878[27] = (char *(*)()) F770_5571;
	R4878[28] = (char *(*)()) F771_5571;
	R4878[29] = (char *(*)()) F772_5571;
	R4878[30] = (char *(*)()) F773_5571;
	R4878[31] = (char *(*)()) F774_5571;
	R4878[32] = (char *(*)()) F775_5571;
	R4878[33] = (char *(*)()) F776_5571;
	R4878[34] = (char *(*)()) F777_5571;
	R4878[35] = (char *(*)()) F778_5571;
	R4878[36] = (char *(*)()) F779_5571;
	R4878[37] = (char *(*)()) F780_5571;
}

char *(*R4880[12])();
void R4880_init () {
	R4880[0] = (char *(*)()) F743_5544;
	R4880[1] = (char *(*)()) F744_5544;
	R4880[2] = (char *(*)()) F745_5544;
	R4880[3] = (char *(*)()) F746_5544;
	R4880[4] = (char *(*)()) F747_5544;
	R4880[5] = (char *(*)()) F748_5544;
	R4880[6] = (char *(*)()) F749_5544;
	R4880[7] = (char *(*)()) F750_5544;
	R4880[8] = (char *(*)()) F751_5544;
	R4880[9] = (char *(*)()) F752_5544;
	R4880[10] = (char *(*)()) F753_5544;
	R4880[11] = (char *(*)()) F754_5544;
}

char *(*R4888[12])();
void R4888_init () {
	R4888[0] = (char *(*)()) F757_5562;
	R4888[1] = (char *(*)()) F758_5562;
	R4888[2] = (char *(*)()) F759_5562;
	R4888[3] = (char *(*)()) F760_5562;
	R4888[4] = (char *(*)()) F761_5562;
	R4888[5] = (char *(*)()) F762_5562;
	R4888[6] = (char *(*)()) F763_5562;
	R4888[7] = (char *(*)()) F764_5562;
	R4888[8] = (char *(*)()) F765_5562;
	R4888[9] = (char *(*)()) F766_5562;
	R4888[10] = (char *(*)()) F767_5562;
	R4888[11] = (char *(*)()) F768_5562;
}

char *(*R4891[12])();
void R4891_init () {
	R4891[0] = (char *(*)()) F769_5568;
	R4891[1] = (char *(*)()) F770_5568;
	R4891[2] = (char *(*)()) F771_5568;
	R4891[3] = (char *(*)()) F772_5568;
	R4891[4] = (char *(*)()) F773_5568;
	R4891[5] = (char *(*)()) F774_5568;
	R4891[6] = (char *(*)()) F775_5568;
	R4891[7] = (char *(*)()) F776_5568;
	R4891[8] = (char *(*)()) F777_5568;
	R4891[9] = (char *(*)()) F778_5568;
	R4891[10] = (char *(*)()) F779_5568;
	R4891[11] = (char *(*)()) F780_5568;
}

char *(*R5002[12])();
void R5002_init () {
	R5002[0] = (char *(*)()) F786_5703;
	R5002[1] = (char *(*)()) F787_5703;
	R5002[2] = (char *(*)()) F788_5703;
	R5002[3] = (char *(*)()) F789_5703;
	R5002[4] = (char *(*)()) F790_5703;
	R5002[5] = (char *(*)()) F791_5703;
	R5002[6] = (char *(*)()) F792_5703;
	R5002[7] = (char *(*)()) F793_5703;
	R5002[8] = (char *(*)()) F794_5703;
	R5002[9] = (char *(*)()) F795_5703;
	R5002[10] = (char *(*)()) F796_5703;
	R5002[11] = (char *(*)()) F797_5703;
}

char *(*R5003[12])();
void R5003_init () {
	R5003[0] = (char *(*)()) F786_5704;
	R5003[1] = (char *(*)()) F787_5704;
	R5003[2] = (char *(*)()) F788_5704;
	R5003[3] = (char *(*)()) F789_5704;
	R5003[4] = (char *(*)()) F790_5704;
	R5003[5] = (char *(*)()) F791_5704;
	R5003[6] = (char *(*)()) F792_5704;
	R5003[7] = (char *(*)()) F793_5704;
	R5003[8] = (char *(*)()) F794_5704;
	R5003[9] = (char *(*)()) F795_5704;
	R5003[10] = (char *(*)()) F796_5704;
	R5003[11] = (char *(*)()) F797_5704;
}

char *(*R5005[12])();
void R5005_init () {
	R5005[0] = (char *(*)()) F786_5690;
	R5005[1] = (char *(*)()) F787_5690;
	R5005[2] = (char *(*)()) F788_5690;
	R5005[3] = (char *(*)()) F789_5690;
	R5005[4] = (char *(*)()) F790_5690;
	R5005[5] = (char *(*)()) F791_5690;
	R5005[6] = (char *(*)()) F792_5690;
	R5005[7] = (char *(*)()) F793_5690;
	R5005[8] = (char *(*)()) F794_5690;
	R5005[9] = (char *(*)()) F795_5690;
	R5005[10] = (char *(*)()) F796_5690;
	R5005[11] = (char *(*)()) F797_5690;
}

char *(*R5006[12])();
void R5006_init () {
	R5006[0] = (char *(*)()) F786_5691;
	R5006[1] = (char *(*)()) F787_5691_5006_262;
	R5006[2] = (char *(*)()) F788_5691_5006_262;
	R5006[3] = (char *(*)()) F789_5691_5006_262;
	R5006[4] = (char *(*)()) F790_5691_5006_262;
	R5006[5] = (char *(*)()) F791_5691_5006_262;
	R5006[6] = (char *(*)()) F792_5691_5006_262;
	R5006[7] = (char *(*)()) F793_5691_5006_262;
	R5006[8] = (char *(*)()) F794_5691_5006_262;
	R5006[9] = (char *(*)()) F795_5691_5006_262;
	R5006[10] = (char *(*)()) F796_5691_5006_262;
	R5006[11] = (char *(*)()) F797_5691_5006_262;
}
static void F787_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F787_5691(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F788_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F788_5691(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F789_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F789_5691(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F790_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F790_5691(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F791_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F791_5691(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F792_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F792_5691(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F793_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F793_5691(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F794_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F794_5691(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F795_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F795_5691(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F796_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F796_5691(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F797_5691_5006_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F797_5691(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5015[12])();
void R5015_init () {
	R5015[0] = (char *(*)()) F786_5706;
	R5015[1] = (char *(*)()) F787_5706;
	R5015[2] = (char *(*)()) F788_5706;
	R5015[3] = (char *(*)()) F789_5706;
	R5015[4] = (char *(*)()) F790_5706;
	R5015[5] = (char *(*)()) F791_5706;
	R5015[6] = (char *(*)()) F792_5706;
	R5015[7] = (char *(*)()) F793_5706;
	R5015[8] = (char *(*)()) F794_5706;
	R5015[9] = (char *(*)()) F795_5706;
	R5015[10] = (char *(*)()) F796_5706;
	R5015[11] = (char *(*)()) F797_5706;
}

char *(*R5016[12])();
void R5016_init () {
	R5016[0] = (char *(*)()) F786_5708;
	R5016[1] = (char *(*)()) F787_5708_5016_262;
	R5016[2] = (char *(*)()) F788_5708_5016_262;
	R5016[3] = (char *(*)()) F789_5708_5016_262;
	R5016[4] = (char *(*)()) F790_5708_5016_262;
	R5016[5] = (char *(*)()) F791_5708_5016_262;
	R5016[6] = (char *(*)()) F792_5708_5016_262;
	R5016[7] = (char *(*)()) F793_5708_5016_262;
	R5016[8] = (char *(*)()) F794_5708_5016_262;
	R5016[9] = (char *(*)()) F795_5708_5016_262;
	R5016[10] = (char *(*)()) F796_5708_5016_262;
	R5016[11] = (char *(*)()) F797_5708_5016_262;
}
static void F787_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F787_5708(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F788_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F788_5708(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F789_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F789_5708(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F790_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F790_5708(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F791_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F791_5708(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F792_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F792_5708(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F793_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F793_5708(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F794_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F794_5708(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F795_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F795_5708(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F796_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F796_5708(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F797_5708_5016_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F797_5708(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5017[12])();
void R5017_init () {
	R5017[0] = (char *(*)()) F786_5709;
	R5017[1] = (char *(*)()) F787_5709_5017_262;
	R5017[2] = (char *(*)()) F788_5709_5017_262;
	R5017[3] = (char *(*)()) F789_5709_5017_262;
	R5017[4] = (char *(*)()) F790_5709_5017_262;
	R5017[5] = (char *(*)()) F791_5709_5017_262;
	R5017[6] = (char *(*)()) F792_5709_5017_262;
	R5017[7] = (char *(*)()) F793_5709_5017_262;
	R5017[8] = (char *(*)()) F794_5709_5017_262;
	R5017[9] = (char *(*)()) F795_5709_5017_262;
	R5017[10] = (char *(*)()) F796_5709_5017_262;
	R5017[11] = (char *(*)()) F797_5709_5017_262;
}
static void F787_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F787_5709(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F788_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F788_5709(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F789_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F789_5709(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F790_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F790_5709(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F791_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F791_5709(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F792_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F792_5709(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F793_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F793_5709(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F794_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F794_5709(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F795_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F795_5709(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F796_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F796_5709(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F797_5709_5017_262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F797_5709(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5018[12])();
void R5018_init () {
	R5018[0] = (char *(*)()) F786_5710;
	R5018[1] = (char *(*)()) F787_5710_5018_4;
	R5018[2] = (char *(*)()) F788_5710_5018_4;
	R5018[3] = (char *(*)()) F789_5710_5018_4;
	R5018[4] = (char *(*)()) F790_5710_5018_4;
	R5018[5] = (char *(*)()) F791_5710_5018_4;
	R5018[6] = (char *(*)()) F792_5710_5018_4;
	R5018[7] = (char *(*)()) F793_5710_5018_4;
	R5018[8] = (char *(*)()) F794_5710_5018_4;
	R5018[9] = (char *(*)()) F795_5710_5018_4;
	R5018[10] = (char *(*)()) F796_5710_5018_4;
	R5018[11] = (char *(*)()) F797_5710_5018_4;
}
static void F787_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F787_5710(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F788_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F788_5710(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F789_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F789_5710(Current, *(EIF_BOOLEAN *)arg1);
}
static void F790_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F790_5710(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F791_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F791_5710(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F792_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F792_5710(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F793_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F793_5710(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F794_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F794_5710(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F795_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F795_5710(Current, *(EIF_POINTER *)arg1);
}
static void F796_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F796_5710(Current, *(EIF_REAL_32 *)arg1);
}
static void F797_5710_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_5710(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5020[12])();
void R5020_init () {
	R5020[0] = (char *(*)()) F786_5712;
	R5020[1] = (char *(*)()) F787_5712_5020_270;
	R5020[2] = (char *(*)()) F788_5712_5020_270;
	R5020[3] = (char *(*)()) F789_5712_5020_270;
	R5020[4] = (char *(*)()) F790_5712_5020_270;
	R5020[5] = (char *(*)()) F791_5712_5020_270;
	R5020[6] = (char *(*)()) F792_5712_5020_270;
	R5020[7] = (char *(*)()) F793_5712_5020_270;
	R5020[8] = (char *(*)()) F794_5712_5020_270;
	R5020[9] = (char *(*)()) F795_5712_5020_270;
	R5020[10] = (char *(*)()) F796_5712_5020_270;
	R5020[11] = (char *(*)()) F797_5712_5020_270;
}
static void F787_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F787_5712(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F788_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F788_5712(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F789_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F789_5712(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F790_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F790_5712(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F791_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F791_5712(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F792_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F792_5712(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F793_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F793_5712(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F794_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F794_5712(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F795_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F795_5712(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F796_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F796_5712(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F797_5712_5020_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F797_5712(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5023[12])();
void R5023_init () {
	R5023[0] = (char *(*)()) F786_5715;
	R5023[1] = (char *(*)()) F787_5715;
	R5023[2] = (char *(*)()) F788_5715;
	R5023[3] = (char *(*)()) F789_5715;
	R5023[4] = (char *(*)()) F790_5715;
	R5023[5] = (char *(*)()) F791_5715;
	R5023[6] = (char *(*)()) F792_5715;
	R5023[7] = (char *(*)()) F793_5715;
	R5023[8] = (char *(*)()) F794_5715;
	R5023[9] = (char *(*)()) F795_5715;
	R5023[10] = (char *(*)()) F796_5715;
	R5023[11] = (char *(*)()) F797_5715;
}

char *(*R5024[12])();
void R5024_init () {
	R5024[0] = (char *(*)()) F786_5716;
	R5024[1] = (char *(*)()) F787_5716;
	R5024[2] = (char *(*)()) F788_5716;
	R5024[3] = (char *(*)()) F789_5716;
	R5024[4] = (char *(*)()) F790_5716;
	R5024[5] = (char *(*)()) F791_5716;
	R5024[6] = (char *(*)()) F792_5716;
	R5024[7] = (char *(*)()) F793_5716;
	R5024[8] = (char *(*)()) F794_5716;
	R5024[9] = (char *(*)()) F795_5716;
	R5024[10] = (char *(*)()) F796_5716;
	R5024[11] = (char *(*)()) F797_5716;
}

char *(*R5025[12])();
void R5025_init () {
	R5025[0] = (char *(*)()) F786_5717;
	R5025[1] = (char *(*)()) F787_5717;
	R5025[2] = (char *(*)()) F788_5717;
	R5025[3] = (char *(*)()) F789_5717;
	R5025[4] = (char *(*)()) F790_5717;
	R5025[5] = (char *(*)()) F791_5717;
	R5025[6] = (char *(*)()) F792_5717;
	R5025[7] = (char *(*)()) F793_5717;
	R5025[8] = (char *(*)()) F794_5717;
	R5025[9] = (char *(*)()) F795_5717;
	R5025[10] = (char *(*)()) F796_5717;
	R5025[11] = (char *(*)()) F797_5717;
}

char *(*R5026[12])();
void R5026_init () {
	R5026[0] = (char *(*)()) F786_5718;
	R5026[1] = (char *(*)()) F787_5718;
	R5026[2] = (char *(*)()) F788_5718;
	R5026[3] = (char *(*)()) F789_5718;
	R5026[4] = (char *(*)()) F790_5718;
	R5026[5] = (char *(*)()) F791_5718;
	R5026[6] = (char *(*)()) F792_5718;
	R5026[7] = (char *(*)()) F793_5718;
	R5026[8] = (char *(*)()) F794_5718;
	R5026[9] = (char *(*)()) F795_5718;
	R5026[10] = (char *(*)()) F796_5718;
	R5026[11] = (char *(*)()) F797_5718;
}

char *(*R5027[12])();
void R5027_init () {
	R5027[0] = (char *(*)()) F786_5719;
	R5027[1] = (char *(*)()) F787_5719;
	R5027[2] = (char *(*)()) F788_5719;
	R5027[3] = (char *(*)()) F789_5719;
	R5027[4] = (char *(*)()) F790_5719;
	R5027[5] = (char *(*)()) F791_5719;
	R5027[6] = (char *(*)()) F792_5719;
	R5027[7] = (char *(*)()) F793_5719;
	R5027[8] = (char *(*)()) F794_5719;
	R5027[9] = (char *(*)()) F795_5719;
	R5027[10] = (char *(*)()) F796_5719;
	R5027[11] = (char *(*)()) F797_5719;
}

char *(*R5030[12])();
void R5030_init () {
	R5030[0] = (char *(*)()) F786_5722;
	R5030[1] = (char *(*)()) F787_5722;
	R5030[2] = (char *(*)()) F788_5722;
	R5030[3] = (char *(*)()) F789_5722;
	R5030[4] = (char *(*)()) F790_5722;
	R5030[5] = (char *(*)()) F791_5722;
	R5030[6] = (char *(*)()) F792_5722;
	R5030[7] = (char *(*)()) F793_5722;
	R5030[8] = (char *(*)()) F794_5722;
	R5030[9] = (char *(*)()) F795_5722;
	R5030[10] = (char *(*)()) F796_5722;
	R5030[11] = (char *(*)()) F797_5722;
}

char *(*R5033[12])();
void R5033_init () {
	R5033[0] = (char *(*)()) F786_5725;
	R5033[1] = (char *(*)()) F787_5725;
	R5033[2] = (char *(*)()) F788_5725;
	R5033[3] = (char *(*)()) F789_5725;
	R5033[4] = (char *(*)()) F790_5725;
	R5033[5] = (char *(*)()) F791_5725;
	R5033[6] = (char *(*)()) F792_5725;
	R5033[7] = (char *(*)()) F793_5725;
	R5033[8] = (char *(*)()) F794_5725;
	R5033[9] = (char *(*)()) F795_5725;
	R5033[10] = (char *(*)()) F796_5725;
	R5033[11] = (char *(*)()) F797_5725;
}

char *(*R5036[12])();
void R5036_init () {
	R5036[0] = (char *(*)()) F786_5728;
	R5036[1] = (char *(*)()) F787_5728;
	R5036[2] = (char *(*)()) F788_5728;
	R5036[3] = (char *(*)()) F789_5728;
	R5036[4] = (char *(*)()) F790_5728;
	R5036[5] = (char *(*)()) F791_5728;
	R5036[6] = (char *(*)()) F792_5728;
	R5036[7] = (char *(*)()) F793_5728;
	R5036[8] = (char *(*)()) F794_5728;
	R5036[9] = (char *(*)()) F795_5728;
	R5036[10] = (char *(*)()) F796_5728;
	R5036[11] = (char *(*)()) F797_5728;
}

char *(*R5038[12])();
void R5038_init () {
	R5038[0] = (char *(*)()) F786_5730;
	R5038[1] = (char *(*)()) F787_5730;
	R5038[2] = (char *(*)()) F788_5730;
	R5038[3] = (char *(*)()) F789_5730;
	R5038[4] = (char *(*)()) F790_5730;
	R5038[5] = (char *(*)()) F791_5730;
	R5038[6] = (char *(*)()) F792_5730;
	R5038[7] = (char *(*)()) F793_5730;
	R5038[8] = (char *(*)()) F794_5730;
	R5038[9] = (char *(*)()) F795_5730;
	R5038[10] = (char *(*)()) F796_5730;
	R5038[11] = (char *(*)()) F797_5730;
}

char *(*R5045[12])();
void R5045_init () {
	R5045[0] = (char *(*)()) F786_5738;
	R5045[1] = (char *(*)()) F787_5738;
	R5045[2] = (char *(*)()) F788_5738;
	R5045[3] = (char *(*)()) F789_5738;
	R5045[4] = (char *(*)()) F790_5738;
	R5045[5] = (char *(*)()) F791_5738;
	R5045[6] = (char *(*)()) F792_5738;
	R5045[7] = (char *(*)()) F793_5738;
	R5045[8] = (char *(*)()) F794_5738;
	R5045[9] = (char *(*)()) F795_5738;
	R5045[10] = (char *(*)()) F796_5738;
	R5045[11] = (char *(*)()) F797_5738;
}

char *(*R5092[29])();
void R5092_init () {
	R5092[0] = (char *(*)()) F904_7081_5092_1;
	R5092[1] = (char *(*)()) F905_7081_5092_1;
	R5092[3] = (char *(*)()) F907_7180_5092_1;
	R5092[4] = (char *(*)()) F908_7180_5092_1;
	R5092[6] = (char *(*)()) F910_7279_5092_1;
	R5092[7] = (char *(*)()) F911_7279_5092_1;
	R5092[9] = (char *(*)()) F913_7378_5092_1;
	R5092[10] = (char *(*)()) F914_7378_5092_1;
	R5092[24] = (char *(*)()) F928_7835_5092_1;
	R5092[25] = (char *(*)()) F929_7835_5092_1;
	R5092[27] = (char *(*)()) F931_7901_5092_1;
	R5092[28] = (char *(*)()) F932_7901_5092_1;
}
static EIF_REFERENCE F904_7081_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F904_7081(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F905_7081_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F905_7081(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F907_7180_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F907_7180(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F908_7180_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F908_7180(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F910_7279_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F910_7279(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F911_7279_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F911_7279(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F913_7378_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F913_7378(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F914_7378_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F914_7378(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_7835_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F928_7835(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_7835_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_7835(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_7901_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F931_7901(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_7901_5092_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F932_7901(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5332[430])();
void R5332_init () {
	R5332[0] = (char *(*)()) F857_6259;
	R5332[429] = (char *(*)()) F1287_13081;
}

char *(*R5340[432])();
void R5340_init () {
	R5340[0] = (char *(*)()) F856_6140;
	R5340[2] = (char *(*)()) F857_6283;
	R5340[431] = (char *(*)()) F857_6283;
}

char *(*R5342[432])();
void R5342_init () {
	R5342[0] = (char *(*)()) F856_6139;
	R5342[2] = (char *(*)()) F857_6311;
	R5342[431] = (char *(*)()) F857_6311;
}

char *(*R5345[432])();
void R5345_init () {
	R5345[0] = (char *(*)()) F856_6185;
	R5345[2] = (char *(*)()) F857_6333;
	R5345[431] = (char *(*)()) F1287_13104;
}

char *(*R5347[430])();
void R5347_init () {
	R5347[0] = (char *(*)()) F857_6336;
	R5347[429] = (char *(*)()) F1287_13102;
}

char *(*R5375[430])();
void R5375_init () {
	R5375[0] = (char *(*)()) F857_6366;
	R5375[429] = (char *(*)()) F1287_13099;
}

char *(*R5388[430])();
void R5388_init () {
	R5388[0] = (char *(*)()) F857_6373;
	R5388[429] = (char *(*)()) F1287_13093;
}

char *(*R5419[430])();
void R5419_init () {
	R5419[0] = (char *(*)()) F857_6224;
	R5419[429] = (char *(*)()) F859_6505;
}

char *(*R5444[430])();
void R5444_init () {
	R5444[0] = (char *(*)()) F857_6258;
	R5444[429] = (char *(*)()) F1287_13080;
}

char *(*R5513[430])();
void R5513_init () {
	R5513[0] = (char *(*)()) F858_6499;
	R5513[429] = (char *(*)()) F857_6382;
}

char *(*R5514[430])();
void R5514_init () {
	R5514[0] = (char *(*)()) F857_6383;
	R5514[429] = (char *(*)()) F1287_13136;
}

char *(*R5820[160])();
void R5820_init () {
	R5820[0] = (char *(*)()) F869_6805;
	R5820[1] = (char *(*)()) F870_6847;
	R5820[2] = (char *(*)()) F871_6847;
	R5820[3] = (char *(*)()) F872_6847;
	R5820[4] = (char *(*)()) F873_6847;
	R5820[5] = (char *(*)()) F874_6847;
	R5820[6] = (char *(*)()) F875_6847;
	R5820[7] = (char *(*)()) F876_6847;
	R5820[8] = (char *(*)()) F877_6847;
	R5820[9] = (char *(*)()) F878_6847;
	R5820[10] = (char *(*)()) F879_6847;
	R5820[11] = (char *(*)()) F880_6847;
	R5820[12] = (char *(*)()) F881_6847;
	R5820[13] = (char *(*)()) F882_6847;
	R5820[14] = (char *(*)()) F883_6847;
	R5820[15] = (char *(*)()) F884_6847;
	R5820[16] = (char *(*)()) F885_6847;
	R5820[17] = (char *(*)()) F886_6847;
	R5820[18] = (char *(*)()) F887_6847;
	R5820[19] = (char *(*)()) F888_6847;
	R5820[20] = (char *(*)()) F889_6847;
	R5820[21] = (char *(*)()) F890_6847;
	R5820[22] = (char *(*)()) F891_6847;
	R5820[23] = (char *(*)()) F892_6847;
	R5820[24] = (char *(*)()) F893_6847;
	R5820[25] = (char *(*)()) F894_6847;
	R5820[26] = (char *(*)()) F895_6847;
	R5820[27] = (char *(*)()) F896_6847;
	R5820[28] = (char *(*)()) F897_6847;
	R5820[29] = (char *(*)()) F898_6847;
	R5820[30] = (char *(*)()) F899_6847;
	R5820[31] = (char *(*)()) F900_6847;
	R5820[32] = (char *(*)()) F901_6847;
	R5820[33] = (char *(*)()) F902_6899;
	{long i; for (i = 35; i < 37; i++) R5820[i] = (char *(*)()) F903_7006;}
	{long i; for (i = 38; i < 40; i++) R5820[i] = (char *(*)()) F906_7104;}
	{long i; for (i = 41; i < 43; i++) R5820[i] = (char *(*)()) F909_7203;}
	{long i; for (i = 44; i < 46; i++) R5820[i] = (char *(*)()) F912_7302;}
	{long i; for (i = 47; i < 49; i++) R5820[i] = (char *(*)()) F915_7401;}
	{long i; for (i = 50; i < 52; i++) R5820[i] = (char *(*)()) F918_7495;}
	{long i; for (i = 53; i < 55; i++) R5820[i] = (char *(*)()) F921_7589;}
	{long i; for (i = 56; i < 58; i++) R5820[i] = (char *(*)()) F924_7684;}
	{long i; for (i = 59; i < 61; i++) R5820[i] = (char *(*)()) F927_7779;}
	{long i; for (i = 62; i < 64; i++) R5820[i] = (char *(*)()) F930_7845;}
	{long i; for (i = 65; i < 67; i++) R5820[i] = (char *(*)()) F933_7912;}
	{long i; for (i = 68; i < 70; i++) R5820[i] = (char *(*)()) F936_7953;}
	{long i; for (i = 71; i < 73; i++) R5820[i] = (char *(*)()) F939_8001;}
	{long i; for (i = 73; i < 104; i++) R5820[i] = (char *(*)()) F942_8022;}
	R5820[104] = (char *(*)()) F973_8048;
	R5820[105] = (char *(*)()) F974_8048;
	{long i; for (i = 107; i < 112; i++) R5820[i] = (char *(*)()) F975_8056;}
	R5820[115] = (char *(*)()) F981_8115;
	R5820[117] = (char *(*)()) F981_8115;
	{long i; for (i = 119; i < 121; i++) R5820[i] = (char *(*)()) F981_8115;}
	R5820[159] = (char *(*)()) F1028_8879;
}

char *(*R5878[32])();
void R5878_init () {
	R5878[0] = (char *(*)()) F870_6843;
	R5878[1] = (char *(*)()) F871_6843;
	R5878[2] = (char *(*)()) F872_6843;
	R5878[3] = (char *(*)()) F873_6843;
	R5878[4] = (char *(*)()) F874_6843;
	R5878[5] = (char *(*)()) F875_6843;
	R5878[6] = (char *(*)()) F876_6843;
	R5878[7] = (char *(*)()) F877_6843;
	R5878[8] = (char *(*)()) F878_6843;
	R5878[9] = (char *(*)()) F879_6843;
	R5878[10] = (char *(*)()) F880_6843;
	R5878[11] = (char *(*)()) F881_6843;
	R5878[12] = (char *(*)()) F882_6843;
	R5878[13] = (char *(*)()) F883_6843;
	R5878[14] = (char *(*)()) F884_6843;
	R5878[15] = (char *(*)()) F885_6843;
	R5878[16] = (char *(*)()) F886_6843;
	R5878[17] = (char *(*)()) F887_6843;
	R5878[18] = (char *(*)()) F888_6843;
	R5878[19] = (char *(*)()) F889_6843;
	R5878[20] = (char *(*)()) F890_6843;
	R5878[21] = (char *(*)()) F891_6843;
	R5878[22] = (char *(*)()) F892_6843;
	R5878[23] = (char *(*)()) F893_6843;
	R5878[24] = (char *(*)()) F894_6843;
	R5878[25] = (char *(*)()) F895_6843;
	R5878[26] = (char *(*)()) F896_6843;
	R5878[27] = (char *(*)()) F897_6843;
	R5878[28] = (char *(*)()) F898_6843;
	R5878[29] = (char *(*)()) F899_6843;
	R5878[30] = (char *(*)()) F900_6843;
	R5878[31] = (char *(*)()) F901_6843;
}

char *(*R5879[32])();
void R5879_init () {
	R5879[0] = (char *(*)()) F870_6844;
	R5879[1] = (char *(*)()) F871_6844;
	R5879[2] = (char *(*)()) F872_6844;
	R5879[3] = (char *(*)()) F873_6844;
	R5879[4] = (char *(*)()) F874_6844;
	R5879[5] = (char *(*)()) F875_6844;
	R5879[6] = (char *(*)()) F876_6844;
	R5879[7] = (char *(*)()) F877_6844;
	R5879[8] = (char *(*)()) F878_6844;
	R5879[9] = (char *(*)()) F879_6844;
	R5879[10] = (char *(*)()) F880_6844;
	R5879[11] = (char *(*)()) F881_6844;
	R5879[12] = (char *(*)()) F882_6844;
	R5879[13] = (char *(*)()) F883_6844;
	R5879[14] = (char *(*)()) F884_6844;
	R5879[15] = (char *(*)()) F885_6844;
	R5879[16] = (char *(*)()) F886_6844;
	R5879[17] = (char *(*)()) F887_6844;
	R5879[18] = (char *(*)()) F888_6844;
	R5879[19] = (char *(*)()) F889_6844;
	R5879[20] = (char *(*)()) F890_6844;
	R5879[21] = (char *(*)()) F891_6844;
	R5879[22] = (char *(*)()) F892_6844;
	R5879[23] = (char *(*)()) F893_6844;
	R5879[24] = (char *(*)()) F894_6844;
	R5879[25] = (char *(*)()) F895_6844;
	R5879[26] = (char *(*)()) F896_6844;
	R5879[27] = (char *(*)()) F897_6844;
	R5879[28] = (char *(*)()) F898_6844;
	R5879[29] = (char *(*)()) F899_6844;
	R5879[30] = (char *(*)()) F900_6844;
	R5879[31] = (char *(*)()) F901_6844;
}

char *(*R5880[32])();
void R5880_init () {
	R5880[0] = (char *(*)()) F870_6845;
	R5880[1] = (char *(*)()) F871_6845;
	R5880[2] = (char *(*)()) F872_6845;
	R5880[3] = (char *(*)()) F873_6845;
	R5880[4] = (char *(*)()) F874_6845;
	R5880[5] = (char *(*)()) F875_6845;
	R5880[6] = (char *(*)()) F876_6845;
	R5880[7] = (char *(*)()) F877_6845;
	R5880[8] = (char *(*)()) F878_6845;
	R5880[9] = (char *(*)()) F879_6845;
	R5880[10] = (char *(*)()) F880_6845;
	R5880[11] = (char *(*)()) F881_6845;
	R5880[12] = (char *(*)()) F882_6845;
	R5880[13] = (char *(*)()) F883_6845;
	R5880[14] = (char *(*)()) F884_6845;
	R5880[15] = (char *(*)()) F885_6845;
	R5880[16] = (char *(*)()) F886_6845;
	R5880[17] = (char *(*)()) F887_6845;
	R5880[18] = (char *(*)()) F888_6845;
	R5880[19] = (char *(*)()) F889_6845;
	R5880[20] = (char *(*)()) F890_6845;
	R5880[21] = (char *(*)()) F891_6845;
	R5880[22] = (char *(*)()) F892_6845;
	R5880[23] = (char *(*)()) F893_6845;
	R5880[24] = (char *(*)()) F894_6845;
	R5880[25] = (char *(*)()) F895_6845;
	R5880[26] = (char *(*)()) F896_6845;
	R5880[27] = (char *(*)()) F897_6845;
	R5880[28] = (char *(*)()) F898_6845;
	R5880[29] = (char *(*)()) F899_6845;
	R5880[30] = (char *(*)()) F900_6845;
	R5880[31] = (char *(*)()) F901_6845;
}

char *(*R5881[32])();
void R5881_init () {
	R5881[0] = (char *(*)()) F870_6846;
	R5881[1] = (char *(*)()) F871_6846;
	R5881[2] = (char *(*)()) F872_6846;
	R5881[3] = (char *(*)()) F873_6846;
	R5881[4] = (char *(*)()) F874_6846;
	R5881[5] = (char *(*)()) F875_6846;
	R5881[6] = (char *(*)()) F876_6846;
	R5881[7] = (char *(*)()) F877_6846;
	R5881[8] = (char *(*)()) F878_6846;
	R5881[9] = (char *(*)()) F879_6846;
	R5881[10] = (char *(*)()) F880_6846;
	R5881[11] = (char *(*)()) F881_6846;
	R5881[12] = (char *(*)()) F882_6846;
	R5881[13] = (char *(*)()) F883_6846;
	R5881[14] = (char *(*)()) F884_6846;
	R5881[15] = (char *(*)()) F885_6846;
	R5881[16] = (char *(*)()) F886_6846;
	R5881[17] = (char *(*)()) F887_6846;
	R5881[18] = (char *(*)()) F888_6846;
	R5881[19] = (char *(*)()) F889_6846;
	R5881[20] = (char *(*)()) F890_6846;
	R5881[21] = (char *(*)()) F891_6846;
	R5881[22] = (char *(*)()) F892_6846;
	R5881[23] = (char *(*)()) F893_6846;
	R5881[24] = (char *(*)()) F894_6846;
	R5881[25] = (char *(*)()) F895_6846;
	R5881[26] = (char *(*)()) F896_6846;
	R5881[27] = (char *(*)()) F897_6846;
	R5881[28] = (char *(*)()) F898_6846;
	R5881[29] = (char *(*)()) F899_6846;
	R5881[30] = (char *(*)()) F900_6846;
	R5881[31] = (char *(*)()) F901_6846;
}

char *(*R5886[32])();
void R5886_init () {
	R5886[0] = (char *(*)()) F870_6852;
	R5886[1] = (char *(*)()) F871_6852;
	R5886[2] = (char *(*)()) F872_6852;
	R5886[3] = (char *(*)()) F873_6852;
	R5886[4] = (char *(*)()) F874_6852;
	R5886[5] = (char *(*)()) F875_6852;
	R5886[6] = (char *(*)()) F876_6852;
	R5886[7] = (char *(*)()) F877_6852;
	R5886[8] = (char *(*)()) F878_6852;
	R5886[9] = (char *(*)()) F879_6852;
	R5886[10] = (char *(*)()) F880_6852;
	R5886[11] = (char *(*)()) F881_6852;
	R5886[12] = (char *(*)()) F882_6852;
	R5886[13] = (char *(*)()) F883_6852;
	R5886[14] = (char *(*)()) F884_6852;
	R5886[15] = (char *(*)()) F885_6852;
	R5886[16] = (char *(*)()) F886_6852;
	R5886[17] = (char *(*)()) F887_6852;
	R5886[18] = (char *(*)()) F888_6852;
	R5886[19] = (char *(*)()) F889_6852;
	R5886[20] = (char *(*)()) F890_6852;
	R5886[21] = (char *(*)()) F891_6852;
	R5886[22] = (char *(*)()) F892_6852;
	R5886[23] = (char *(*)()) F893_6852;
	R5886[24] = (char *(*)()) F894_6852;
	R5886[25] = (char *(*)()) F895_6852;
	R5886[26] = (char *(*)()) F896_6852;
	R5886[27] = (char *(*)()) F897_6852;
	R5886[28] = (char *(*)()) F898_6852;
	R5886[29] = (char *(*)()) F899_6852;
	R5886[30] = (char *(*)()) F900_6852;
	R5886[31] = (char *(*)()) F901_6852;
}

char *(*R5891[32])();
void R5891_init () {
	R5891[0] = (char *(*)()) F870_6860;
	R5891[1] = (char *(*)()) F871_6860_5891_1;
	R5891[2] = (char *(*)()) F872_6860_5891_1;
	R5891[3] = (char *(*)()) F873_6860_5891_1;
	R5891[4] = (char *(*)()) F874_6860_5891_1;
	R5891[5] = (char *(*)()) F875_6860_5891_1;
	R5891[6] = (char *(*)()) F876_6860_5891_1;
	R5891[7] = (char *(*)()) F877_6860_5891_1;
	R5891[8] = (char *(*)()) F878_6860_5891_1;
	R5891[9] = (char *(*)()) F879_6860_5891_1;
	R5891[10] = (char *(*)()) F880_6860_5891_1;
	R5891[11] = (char *(*)()) F881_6860_5891_1;
	R5891[12] = (char *(*)()) F882_6860_5891_1;
	R5891[13] = (char *(*)()) F883_6860_5891_1;
	R5891[14] = (char *(*)()) F884_6860_5891_1;
	R5891[15] = (char *(*)()) F885_6860_5891_1;
	R5891[16] = (char *(*)()) F886_6860;
	R5891[17] = (char *(*)()) F887_6860;
	R5891[18] = (char *(*)()) F888_6860_5891_1;
	R5891[19] = (char *(*)()) F889_6860_5891_1;
	R5891[20] = (char *(*)()) F890_6860_5891_1;
	R5891[21] = (char *(*)()) F891_6860_5891_1;
	R5891[22] = (char *(*)()) F892_6860_5891_1;
	R5891[23] = (char *(*)()) F893_6860_5891_1;
	R5891[24] = (char *(*)()) F894_6860_5891_1;
	R5891[25] = (char *(*)()) F895_6860_5891_1;
	R5891[26] = (char *(*)()) F896_6860_5891_1;
	R5891[27] = (char *(*)()) F897_6860_5891_1;
	R5891[28] = (char *(*)()) F898_6860_5891_1;
	R5891[29] = (char *(*)()) F899_6860_5891_1;
	R5891[30] = (char *(*)()) F900_6860_5891_1;
	R5891[31] = (char *(*)()) F901_6860_5891_1;
}
static EIF_REFERENCE F871_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F871_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F872_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {943,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 943, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F873_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F874_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F874_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F875_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F876_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F876_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F877_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F877_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F878_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F878_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F879_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F879_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F880_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F880_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F881_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F882_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F884_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F885_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F888_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {945,910,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 945, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F889_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {947,934,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 947, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F890_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {949,931,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 949, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F891_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {951,937,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 951, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F892_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {953,922,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 953, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F893_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {955,913,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 955, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F894_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {957,916,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 957, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F895_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {959,907,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 959, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F896_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {961,925,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 961, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F897_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {963,928,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 963, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F898_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {965,919,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 965, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F899_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {967,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 967, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F900_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {969,940,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 969, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6860_5891_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F901_6860(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {971,904,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 971, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}

char *(*R5901[32])();
void R5901_init () {
	R5901[0] = (char *(*)()) F870_6872;
	R5901[1] = (char *(*)()) F871_6872;
	R5901[2] = (char *(*)()) F872_6872;
	R5901[3] = (char *(*)()) F873_6872;
	R5901[4] = (char *(*)()) F874_6872;
	R5901[5] = (char *(*)()) F875_6872;
	R5901[6] = (char *(*)()) F876_6872;
	R5901[7] = (char *(*)()) F877_6872;
	R5901[8] = (char *(*)()) F878_6872;
	R5901[9] = (char *(*)()) F879_6872;
	R5901[10] = (char *(*)()) F880_6872;
	R5901[11] = (char *(*)()) F881_6872;
	R5901[12] = (char *(*)()) F882_6872;
	R5901[13] = (char *(*)()) F883_6872;
	R5901[14] = (char *(*)()) F884_6872;
	R5901[15] = (char *(*)()) F885_6872;
	R5901[16] = (char *(*)()) F886_6872;
	R5901[17] = (char *(*)()) F887_6872;
	R5901[18] = (char *(*)()) F888_6872;
	R5901[19] = (char *(*)()) F889_6872;
	R5901[20] = (char *(*)()) F890_6872;
	R5901[21] = (char *(*)()) F891_6872;
	R5901[22] = (char *(*)()) F892_6872;
	R5901[23] = (char *(*)()) F893_6872;
	R5901[24] = (char *(*)()) F894_6872;
	R5901[25] = (char *(*)()) F895_6872;
	R5901[26] = (char *(*)()) F896_6872;
	R5901[27] = (char *(*)()) F897_6872;
	R5901[28] = (char *(*)()) F898_6872;
	R5901[29] = (char *(*)()) F899_6872;
	R5901[30] = (char *(*)()) F900_6872;
	R5901[31] = (char *(*)()) F901_6872;
}

char *(*R6047[2])();
void R6047_init () {
	R6047[0] = (char *(*)()) F904_7088;
	R6047[1] = (char *(*)()) F905_7088;
}

char *(*R6050[2])();
void R6050_init () {
	R6050[0] = (char *(*)()) F904_7091;
	R6050[1] = (char *(*)()) F905_7091;
}

char *(*R6102[2])();
void R6102_init () {
	R6102[0] = (char *(*)()) F907_7186;
	R6102[1] = (char *(*)()) F908_7186;
}

char *(*R6103[2])();
void R6103_init () {
	R6103[0] = (char *(*)()) F907_7187;
	R6103[1] = (char *(*)()) F908_7187;
}

char *(*R6105[2])();
void R6105_init () {
	R6105[0] = (char *(*)()) F907_7189;
	R6105[1] = (char *(*)()) F908_7189;
}

char *(*R6107[2])();
void R6107_init () {
	R6107[0] = (char *(*)()) F907_7191;
	R6107[1] = (char *(*)()) F908_7191;
}

char *(*R6159[2])();
void R6159_init () {
	R6159[0] = (char *(*)()) F910_7286;
	R6159[1] = (char *(*)()) F911_7286;
}

char *(*R6162[2])();
void R6162_init () {
	R6162[0] = (char *(*)()) F910_7289;
	R6162[1] = (char *(*)()) F911_7289;
}

char *(*R6212[2])();
void R6212_init () {
	R6212[0] = (char *(*)()) F913_7382;
	R6212[1] = (char *(*)()) F914_7382;
}

char *(*R6215[2])();
void R6215_init () {
	R6215[0] = (char *(*)()) F913_7385;
	R6215[1] = (char *(*)()) F914_7385;
}

char *(*R6218[2])();
void R6218_init () {
	R6218[0] = (char *(*)()) F913_7388;
	R6218[1] = (char *(*)()) F914_7388;
}

char *(*R6272[2])();
void R6272_init () {
	R6272[0] = (char *(*)()) F916_7482;
	R6272[1] = (char *(*)()) F917_7482;
}

char *(*R6318[2])();
void R6318_init () {
	R6318[0] = (char *(*)()) F919_7570;
	R6318[1] = (char *(*)()) F920_7570;
}

char *(*R6319[2])();
void R6319_init () {
	R6319[0] = (char *(*)()) F919_7571;
	R6319[1] = (char *(*)()) F920_7571;
}

char *(*R6321[2])();
void R6321_init () {
	R6321[0] = (char *(*)()) F919_7573;
	R6321[1] = (char *(*)()) F920_7573;
}

char *(*R6324[2])();
void R6324_init () {
	R6324[0] = (char *(*)()) F919_7576;
	R6324[1] = (char *(*)()) F920_7576;
}

char *(*R6325[2])();
void R6325_init () {
	R6325[0] = (char *(*)()) F919_7577;
	R6325[1] = (char *(*)()) F920_7577;
}

char *(*R6373[2])();
void R6373_init () {
	R6373[0] = (char *(*)()) F922_7667;
	R6373[1] = (char *(*)()) F923_7667;
}

char *(*R6374[2])();
void R6374_init () {
	R6374[0] = (char *(*)()) F922_7668;
	R6374[1] = (char *(*)()) F923_7668;
}

char *(*R6377[2])();
void R6377_init () {
	R6377[0] = (char *(*)()) F922_7671;
	R6377[1] = (char *(*)()) F923_7671;
}

char *(*R6425[2])();
void R6425_init () {
	R6425[0] = (char *(*)()) F925_7761;
	R6425[1] = (char *(*)()) F926_7761;
}

char *(*R6426[2])();
void R6426_init () {
	R6426[0] = (char *(*)()) F925_7762;
	R6426[1] = (char *(*)()) F926_7762;
}

char *(*R6427[2])();
void R6427_init () {
	R6427[0] = (char *(*)()) F925_7763;
	R6427[1] = (char *(*)()) F926_7763;
}

char *(*R6428[2])();
void R6428_init () {
	R6428[0] = (char *(*)()) F925_7764;
	R6428[1] = (char *(*)()) F926_7764;
}

char *(*R6430[2])();
void R6430_init () {
	R6430[0] = (char *(*)()) F925_7766;
	R6430[1] = (char *(*)()) F926_7766;
}

char *(*R6476[2])();
void R6476_init () {
	R6476[0] = (char *(*)()) F928_7824;
	R6476[1] = (char *(*)()) F929_7824;
}

char *(*R6483[2])();
void R6483_init () {
	R6483[0] = (char *(*)()) F928_7828;
	R6483[1] = (char *(*)()) F929_7828;
}

char *(*R6510[2])();
void R6510_init () {
	R6510[0] = (char *(*)()) F931_7890;
	R6510[1] = (char *(*)()) F932_7890;
}

char *(*R6517[2])();
void R6517_init () {
	R6517[0] = (char *(*)()) F931_7894;
	R6517[1] = (char *(*)()) F932_7894;
}

char *(*R6531[2])();
void R6531_init () {
	R6531[0] = (char *(*)()) F934_7948;
	R6531[1] = (char *(*)()) F935_7948;
}

char *(*R6655[5])();
void R6655_init () {
	R6655[0] = (char *(*)()) F976_8093;
	R6655[1] = (char *(*)()) F977_8096;
	R6655[2] = (char *(*)()) F978_8096;
	R6655[3] = (char *(*)()) F979_8096;
	R6655[4] = (char *(*)()) F978_8096;
}

char *(*R6679[4])();
void R6679_init () {
	R6679[0] = (char *(*)()) F977_8095;
	R6679[1] = (char *(*)()) F978_8095_6679_1;
	R6679[2] = (char *(*)()) F979_8095_6679_1;
	R6679[3] = (char *(*)()) F978_8095_6679_1;
}
static EIF_REFERENCE F978_8095_6679_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F978_8095(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_8095_6679_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F979_8095(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R6680[4])();
void R6680_init () {
	R6680[0] = (char *(*)()) F977_8097;
	R6680[1] = (char *(*)()) F978_8097_6680_5;
	R6680[2] = (char *(*)()) F979_8097_6680_5;
	R6680[3] = (char *(*)()) F978_8097_6680_5;
}
static EIF_REFERENCE F978_8097_6680_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F978_8097(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_8097_6680_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F979_8097(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R6684[4])();
void R6684_init () {
	R6684[0] = (char *(*)()) F977_8104;
	R6684[1] = (char *(*)()) F978_8104_6684_606;
	R6684[2] = (char *(*)()) F979_8104_6684_606;
	R6684[3] = (char *(*)()) F978_8104_6684_606;
}
static EIF_REFERENCE F978_8104_6684_606 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F978_8104(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_8104_6684_606 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F979_8104(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6685_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6685_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6685_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6685_pgtype3[] = {940,0xFFFF};
EIF_TYPE_INDEX *Y6685_gen_type [4];
EIF_TYPE_INDEX Y6685 [4];
void Y6685_init (void)
{
	egc_routines_types [6685] = Y6685;
	egc_routines_gen_types [6685] = Y6685_gen_type;
	egc_routines_offset [6685] = 976;
	Y6685_gen_type [0] = Y6685_pgtype0;
	Y6685_gen_type [1] = Y6685_pgtype1;
	Y6685_gen_type [2] = Y6685_pgtype2;
	Y6685_gen_type [3] = Y6685_pgtype3;
	Y6685[3] = 940;
}

char *(*R6686[6])();
void R6686_init () {
	R6686[0] = (char *(*)()) F983_8202;
	R6686[2] = (char *(*)()) F985_8278;
	R6686[4] = (char *(*)()) F983_8202;
	R6686[5] = (char *(*)()) F985_8278;
}

char *(*R6688[6])();
void R6688_init () {
	R6688[0] = (char *(*)()) F984_8263;
	R6688[2] = (char *(*)()) F986_8338;
	R6688[4] = (char *(*)()) F988_8394;
	R6688[5] = (char *(*)()) F989_8485;
}

char *(*R6689[6])();
void R6689_init () {
	R6689[0] = (char *(*)()) F984_8261;
	R6689[2] = (char *(*)()) F986_8337;
	R6689[4] = (char *(*)()) F988_8392;
	R6689[5] = (char *(*)()) F989_8484;
}

char *(*R6690[6])();
void R6690_init () {
	R6690[0] = (char *(*)()) F983_8214;
	R6690[2] = (char *(*)()) F981_8109;
	R6690[4] = (char *(*)()) F983_8214;
	R6690[5] = (char *(*)()) F981_8109;
}

char *(*R6700[6])();
void R6700_init () {
	R6700[0] = (char *(*)()) F983_8232;
	R6700[2] = (char *(*)()) F985_8309;
	R6700[4] = (char *(*)()) F983_8232;
	R6700[5] = (char *(*)()) F985_8309;
}

char *(*R6702[6])();
void R6702_init () {
	R6702[0] = (char *(*)()) F983_8234;
	R6702[2] = (char *(*)()) F985_8311;
	R6702[4] = (char *(*)()) F983_8234;
	R6702[5] = (char *(*)()) F985_8311;
}

char *(*R6703[6])();
void R6703_init () {
	R6703[0] = (char *(*)()) F984_8273;
	R6703[2] = (char *(*)()) F986_8347;
	R6703[4] = (char *(*)()) F452_4698;
	R6703[5] = (char *(*)()) F447_4698;
}

char *(*R6705[6])();
void R6705_init () {
	R6705[0] = (char *(*)()) F983_8235;
	R6705[2] = (char *(*)()) F985_8312;
	R6705[4] = (char *(*)()) F983_8235;
	R6705[5] = (char *(*)()) F985_8312;
}

char *(*R6706[6])();
void R6706_init () {
	R6706[0] = (char *(*)()) F983_8236;
	R6706[2] = (char *(*)()) F981_8126;
	R6706[4] = (char *(*)()) F983_8236;
	R6706[5] = (char *(*)()) F981_8126;
}

char *(*R6725[6])();
void R6725_init () {
	R6725[0] = (char *(*)()) F983_8223;
	R6725[2] = (char *(*)()) F985_8300;
	R6725[4] = (char *(*)()) F983_8223;
	R6725[5] = (char *(*)()) F985_8300;
}

char *(*R6726[6])();
void R6726_init () {
	R6726[0] = (char *(*)()) F983_8222;
	R6726[2] = (char *(*)()) F985_8299;
	R6726[4] = (char *(*)()) F983_8222;
	R6726[5] = (char *(*)()) F985_8299;
}

char *(*R6736[6])();
void R6736_init () {
	R6736[0] = (char *(*)()) F983_8219;
	R6736[2] = (char *(*)()) F985_8296;
	R6736[4] = (char *(*)()) F983_8219;
	R6736[5] = (char *(*)()) F985_8296;
}

char *(*R6766[6])();
void R6766_init () {
	R6766[0] = (char *(*)()) F984_8270;
	R6766[2] = (char *(*)()) F986_8345;
	R6766[4] = (char *(*)()) F988_8472;
	R6766[5] = (char *(*)()) F989_8563;
}

char *(*R6770[6])();
void R6770_init () {
	R6770[0] = (char *(*)()) F984_8274;
	R6770[2] = (char *(*)()) F986_8349;
	R6770[4] = (char *(*)()) F988_8475;
	R6770[5] = (char *(*)()) F989_8567;
}

char *(*R6808[5])();
void R6808_init () {
	R6808[0] = (char *(*)()) F984_8276;
	R6808[4] = (char *(*)()) F983_8253;
}

char *(*R6841[4])();
void R6841_init () {
	R6841[0] = (char *(*)()) F986_8340;
	R6841[3] = (char *(*)()) F989_8535;
}

char *(*R6849[4])();
void R6849_init () {
	R6849[0] = (char *(*)()) F986_8351;
	R6849[3] = (char *(*)()) F985_8330;
}

char *(*R6857[2])();
void R6857_init () {
	R6857[0] = (char *(*)()) F988_8474;
	R6857[1] = (char *(*)()) F989_8565;
}

char *(*R6860[2])();
void R6860_init () {
	R6860[0] = (char *(*)()) F988_8413;
	R6860[1] = (char *(*)()) F989_8504;
}

char *(*R6880[2])();
void R6880_init () {
	R6880[0] = (char *(*)()) F988_8407;
	R6880[1] = (char *(*)()) F989_8498;
}

char *(*R6890[2])();
void R6890_init () {
	R6890[0] = (char *(*)()) F988_8457;
	R6890[1] = (char *(*)()) F989_8548;
}

char *(*R7024[48])();
void R7024_init () {
	R7024[0] = (char *(*)()) F1064_9393;
	R7024[1] = (char *(*)()) F1065_9395;
	R7024[2] = (char *(*)()) F1066_9408;
	R7024[3] = (char *(*)()) F1067_9416;
	R7024[5] = (char *(*)()) F1069_9440;
	R7024[6] = (char *(*)()) F1070_9473;
	{long i; for (i = 8; i < 10; i++) R7024[i] = (char *(*)()) F1072_9507;}
	R7024[11] = (char *(*)()) F1072_9507;
	R7024[13] = (char *(*)()) F1076_9555;
	R7024[15] = (char *(*)()) F1079_9583;
	R7024[17] = (char *(*)()) F1081_9607;
	R7024[18] = (char *(*)()) F1082_9630;
	R7024[19] = (char *(*)()) F1083_9638;
	R7024[23] = (char *(*)()) F1087_9697;
	R7024[29] = (char *(*)()) F1093_9754;
	R7024[32] = (char *(*)()) F1096_9775;
	R7024[38] = (char *(*)()) F1102_9835;
	R7024[47] = (char *(*)()) F1111_9895;
}

char *(*R7030[16])();
void R7030_init () {
	R7030[0] = (char *(*)()) F1096_9775;
	R7030[15] = (char *(*)()) F1111_9895;
}

char *(*R7032[39])();
void R7032_init () {
	R7032[0] = (char *(*)()) F1064_9393;
	R7032[1] = (char *(*)()) F1065_9395;
	R7032[2] = (char *(*)()) F1066_9408;
	R7032[3] = (char *(*)()) F1067_9416;
	R7032[5] = (char *(*)()) F1069_9440;
	R7032[6] = (char *(*)()) F1070_9473;
	{long i; for (i = 8; i < 10; i++) R7032[i] = (char *(*)()) F1072_9507;}
	R7032[11] = (char *(*)()) F1072_9507;
	R7032[13] = (char *(*)()) F1076_9555;
	R7032[38] = (char *(*)()) F1102_9835;
}

char *(*R7034[39])();
void R7034_init () {
	R7034[0] = (char *(*)()) F1064_9393;
	R7034[1] = (char *(*)()) F1065_9395;
	R7034[2] = (char *(*)()) F1066_9408;
	R7034[3] = (char *(*)()) F1067_9416;
	R7034[5] = (char *(*)()) F1069_9440;
	R7034[6] = (char *(*)()) F1070_9473;
	{long i; for (i = 8; i < 10; i++) R7034[i] = (char *(*)()) F1072_9507;}
	R7034[11] = (char *(*)()) F1072_9507;
	R7034[13] = (char *(*)()) F1076_9555;
	R7034[15] = (char *(*)()) F1079_9583;
	R7034[17] = (char *(*)()) F1081_9607;
	R7034[18] = (char *(*)()) F1082_9630;
	R7034[19] = (char *(*)()) F1083_9638;
	R7034[23] = (char *(*)()) F1087_9697;
	R7034[38] = (char *(*)()) F1102_9835;
}

char *(*R7054[8])();
void R7054_init () {
	R7054[0] = (char *(*)()) F1070_9473;
	{long i; for (i = 2; i < 4; i++) R7054[i] = (char *(*)()) F1072_9507;}
	R7054[5] = (char *(*)()) F1072_9507;
	R7054[7] = (char *(*)()) F1076_9555;
}

char *(*R7090[91])();
void R7090_init () {
	R7090[0] = (char *(*)()) F1021_8748;
	R7090[2] = (char *(*)()) F1023_8786;
	R7090[3] = (char *(*)()) F1024_8802;
	R7090[4] = (char *(*)()) F1025_8817;
	R7090[5] = (char *(*)()) F1026_8837;
	R7090[7] = (char *(*)()) F1028_8886;
	R7090[8] = (char *(*)()) F1029_8917;
	R7090[9] = (char *(*)()) F1030_8927;
	R7090[14] = (char *(*)()) F1034_8989;
	R7090[31] = (char *(*)()) F1052_9186;
	R7090[43] = (char *(*)()) F1064_9394;
	R7090[44] = (char *(*)()) F1065_9396;
	R7090[45] = (char *(*)()) F1066_9409;
	R7090[46] = (char *(*)()) F1067_9417;
	R7090[48] = (char *(*)()) F1069_9441;
	R7090[49] = (char *(*)()) F1070_9477;
	{long i; for (i = 51; i < 53; i++) R7090[i] = (char *(*)()) F1072_9508;}
	R7090[54] = (char *(*)()) F1072_9508;
	R7090[56] = (char *(*)()) F1076_9556;
	R7090[58] = (char *(*)()) F1079_9584;
	R7090[60] = (char *(*)()) F1081_9608;
	R7090[61] = (char *(*)()) F1082_9631;
	R7090[62] = (char *(*)()) F1083_9639;
	R7090[66] = (char *(*)()) F1087_9698;
	R7090[72] = (char *(*)()) F1093_9755;
	R7090[75] = (char *(*)()) F1096_9776;
	R7090[81] = (char *(*)()) F1102_9825;
	R7090[90] = (char *(*)()) F1111_9896;
}

char *(*R7091[91])();
void R7091_init () {
	R7091[0] = (char *(*)()) F1021_8749;
	R7091[2] = (char *(*)()) F1023_8785;
	R7091[3] = (char *(*)()) F1024_8801;
	R7091[4] = (char *(*)()) F1025_8816;
	R7091[5] = (char *(*)()) F1026_8836;
	R7091[7] = (char *(*)()) F1028_8885;
	R7091[8] = (char *(*)()) F1029_8916;
	R7091[9] = (char *(*)()) F1030_8926;
	R7091[14] = (char *(*)()) F1034_8988;
	R7091[31] = (char *(*)()) F1052_9185;
	{long i; for (i = 43; i < 47; i++) R7091[i] = (char *(*)()) F866_6754;}
	{long i; for (i = 48; i < 50; i++) R7091[i] = (char *(*)()) F866_6754;}
	{long i; for (i = 51; i < 53; i++) R7091[i] = (char *(*)()) F866_6754;}
	R7091[54] = (char *(*)()) F1074_9517;
	R7091[56] = (char *(*)()) F866_6754;
	R7091[58] = (char *(*)()) F866_6754;
	{long i; for (i = 60; i < 63; i++) R7091[i] = (char *(*)()) F866_6754;}
	R7091[66] = (char *(*)()) F866_6754;
	R7091[72] = (char *(*)()) F866_6754;
	R7091[75] = (char *(*)()) F866_6754;
	R7091[81] = (char *(*)()) F866_6754;
	R7091[90] = (char *(*)()) F866_6754;
}

char *(*R7092[91])();
void R7092_init () {
	R7092[0] = (char *(*)()) F1018_8692;
	{long i; for (i = 2; i < 6; i++) R7092[i] = (char *(*)()) F1018_8692;}
	{long i; for (i = 7; i < 10; i++) R7092[i] = (char *(*)()) F1018_8692;}
	R7092[14] = (char *(*)()) F1034_8950;
	R7092[31] = (char *(*)()) F1018_8692;
	{long i; for (i = 43; i < 47; i++) R7092[i] = (char *(*)()) F1018_8692;}
	R7092[48] = (char *(*)()) F1018_8692;
	R7092[49] = (char *(*)()) F1070_9443;
	{long i; for (i = 51; i < 53; i++) R7092[i] = (char *(*)()) F1072_9494;}
	R7092[54] = (char *(*)()) F1075_9549;
	R7092[56] = (char *(*)()) F1077_9558;
	R7092[58] = (char *(*)()) F1018_8692;
	{long i; for (i = 60; i < 63; i++) R7092[i] = (char *(*)()) F1018_8692;}
	R7092[66] = (char *(*)()) F1018_8692;
	R7092[72] = (char *(*)()) F1018_8692;
	R7092[75] = (char *(*)()) F1018_8692;
	R7092[81] = (char *(*)()) F1018_8692;
	R7092[90] = (char *(*)()) F1018_8692;
}

char *(*R7271[48])();
void R7271_init () {
	{long i; for (i = 0; i < 4; i++) R7271[i] = (char *(*)()) F1058_9279;}
	{long i; for (i = 5; i < 7; i++) R7271[i] = (char *(*)()) F1058_9279;}
	{long i; for (i = 8; i < 10; i++) R7271[i] = (char *(*)()) F1058_9279;}
	R7271[11] = (char *(*)()) F1058_9279;
	R7271[13] = (char *(*)()) F1058_9279;
	R7271[15] = (char *(*)()) F1058_9279;
	{long i; for (i = 17; i < 20; i++) R7271[i] = (char *(*)()) F1058_9279;}
	R7271[23] = (char *(*)()) F1058_9279;
	R7271[29] = (char *(*)()) F1092_9753;
	R7271[32] = (char *(*)()) F1089_9732;
	R7271[38] = (char *(*)()) F1058_9279;
	R7271[47] = (char *(*)()) F1111_9890;
}

char *(*R7273[48])();
void R7273_init () {
	{long i; for (i = 0; i < 3; i++) R7273[i] = (char *(*)()) F1031_8930;}
	R7273[3] = (char *(*)()) F1067_9411;
	{long i; for (i = 5; i < 7; i++) R7273[i] = (char *(*)()) F1031_8930;}
	{long i; for (i = 8; i < 10; i++) R7273[i] = (char *(*)()) F1031_8930;}
	R7273[11] = (char *(*)()) F1074_9523;
	R7273[13] = (char *(*)()) F1031_8930;
	R7273[15] = (char *(*)()) F1031_8930;
	{long i; for (i = 17; i < 19; i++) R7273[i] = (char *(*)()) F1031_8930;}
	R7273[19] = (char *(*)()) F1083_9633;
	R7273[23] = (char *(*)()) F1031_8930;
	R7273[29] = (char *(*)()) F1031_8930;
	R7273[32] = (char *(*)()) F1096_9770;
	R7273[38] = (char *(*)()) F1031_8930;
	R7273[47] = (char *(*)()) F1096_9770;
}

char *(*R7330[51])();
void R7330_init () {
	R7330[0] = (char *(*)()) F1036_9001;
	{long i; for (i = 12; i < 16; i++) R7330[i] = (char *(*)()) F1036_9001;}
	{long i; for (i = 17; i < 19; i++) R7330[i] = (char *(*)()) F1036_9001;}
	{long i; for (i = 20; i < 22; i++) R7330[i] = (char *(*)()) F1036_9001;}
	R7330[23] = (char *(*)()) F1074_9521;
	R7330[25] = (char *(*)()) F1036_9001;
	R7330[27] = (char *(*)()) F1036_9001;
	{long i; for (i = 29; i < 32; i++) R7330[i] = (char *(*)()) F1036_9001;}
	R7330[35] = (char *(*)()) F1036_9001;
	R7330[50] = (char *(*)()) F1036_9001;
}

char *(*R7331[51])();
void R7331_init () {
	R7331[0] = (char *(*)()) F1036_9002;
	{long i; for (i = 12; i < 16; i++) R7331[i] = (char *(*)()) F1036_9002;}
	{long i; for (i = 17; i < 19; i++) R7331[i] = (char *(*)()) F1036_9002;}
	{long i; for (i = 20; i < 22; i++) R7331[i] = (char *(*)()) F1036_9002;}
	R7331[23] = (char *(*)()) F1074_9522;
	R7331[25] = (char *(*)()) F1036_9002;
	R7331[27] = (char *(*)()) F1036_9002;
	{long i; for (i = 29; i < 32; i++) R7331[i] = (char *(*)()) F1036_9002;}
	R7331[35] = (char *(*)()) F1036_9002;
	R7331[50] = (char *(*)()) F1036_9002;
}

char *(*R7332[51])();
void R7332_init () {
	R7332[0] = (char *(*)()) F1036_9003;
	{long i; for (i = 12; i < 16; i++) R7332[i] = (char *(*)()) F1036_9003;}
	{long i; for (i = 17; i < 19; i++) R7332[i] = (char *(*)()) F1036_9003;}
	{long i; for (i = 20; i < 22; i++) R7332[i] = (char *(*)()) F1036_9003;}
	R7332[23] = (char *(*)()) F1074_9525;
	R7332[25] = (char *(*)()) F1036_9003;
	R7332[27] = (char *(*)()) F1036_9003;
	{long i; for (i = 29; i < 32; i++) R7332[i] = (char *(*)()) F1036_9003;}
	R7332[35] = (char *(*)()) F1036_9003;
	R7332[50] = (char *(*)()) F1036_9003;
}

char *(*R7333[51])();
void R7333_init () {
	R7333[0] = (char *(*)()) F1036_9004;
	{long i; for (i = 12; i < 16; i++) R7333[i] = (char *(*)()) F1036_9004;}
	{long i; for (i = 17; i < 19; i++) R7333[i] = (char *(*)()) F1036_9004;}
	{long i; for (i = 20; i < 22; i++) R7333[i] = (char *(*)()) F1036_9004;}
	R7333[23] = (char *(*)()) F1074_9524;
	R7333[25] = (char *(*)()) F1036_9004;
	R7333[27] = (char *(*)()) F1036_9004;
	{long i; for (i = 29; i < 32; i++) R7333[i] = (char *(*)()) F1036_9004;}
	R7333[35] = (char *(*)()) F1036_9004;
	R7333[50] = (char *(*)()) F1036_9004;
}

char *(*R7566[14])();
void R7566_init () {
	{long i; for (i = 0; i < 2; i++) R7566[i] = (char *(*)()) F1056_9244;}
	{long i; for (i = 2; i < 4; i++) R7566[i] = (char *(*)()) F1059_9320;}
	{long i; for (i = 5; i < 7; i++) R7566[i] = (char *(*)()) F1059_9320;}
	{long i; for (i = 8; i < 10; i++) R7566[i] = (char *(*)()) F1059_9320;}
	R7566[11] = (char *(*)()) F1059_9320;
	R7566[13] = (char *(*)()) F1059_9320;
}

char *(*R7569[14])();
void R7569_init () {
	{long i; for (i = 0; i < 2; i++) R7569[i] = (char *(*)()) F1056_9253;}
	{long i; for (i = 2; i < 4; i++) R7569[i] = (char *(*)()) F1066_9405;}
	{long i; for (i = 5; i < 7; i++) R7569[i] = (char *(*)()) F1066_9405;}
	{long i; for (i = 8; i < 10; i++) R7569[i] = (char *(*)()) F1066_9405;}
	R7569[11] = (char *(*)()) F1066_9405;
	R7569[13] = (char *(*)()) F1066_9405;
}

char *(*R7962[158])();
void R7962_init () {
	R7962[0] = (char *(*)()) F1124_10108;
	R7962[2] = (char *(*)()) F1126_10129;
	R7962[4] = (char *(*)()) F1128_10176;
	R7962[7] = (char *(*)()) F1130_10197;
	R7962[9] = (char *(*)()) F1133_10260;
	R7962[11] = (char *(*)()) F1135_10343;
	R7962[13] = (char *(*)()) F1137_10549;
	R7962[15] = (char *(*)()) F1139_10611;
	R7962[20] = (char *(*)()) F1141_10625;
	{long i; for (i = 74; i < 76; i++) R7962[i] = (char *(*)()) F1187_11300;}
	{long i; for (i = 84; i < 86; i++) R7962[i] = (char *(*)()) F1187_11300;}
	R7962[87] = (char *(*)()) F1187_11300;
	{long i; for (i = 88; i < 90; i++) R7962[i] = (char *(*)()) F1212_11633;}
	R7962[91] = (char *(*)()) F1212_11633;
	R7962[108] = (char *(*)()) F1185_11241;
	{long i; for (i = 112; i < 114; i++) R7962[i] = (char *(*)()) F1185_11241;}
	R7962[118] = (char *(*)()) F1185_11241;
	R7962[131] = (char *(*)()) F1254_12492;
	R7962[137] = (char *(*)()) F1254_12492;
	R7962[141] = (char *(*)()) F1265_12565;
	R7962[154] = (char *(*)()) F1278_12850;
	R7962[156] = (char *(*)()) F1280_12980;
	R7962[157] = (char *(*)()) F1281_13017;
}

char *(*R8510[138])();
void R8510_init () {
	R8510[0] = (char *(*)()) F1141_10634;
	{long i; for (i = 54; i < 56; i++) R8510[i] = (char *(*)()) F1197_11412;}
	R8510[64] = (char *(*)()) F1141_10634;
	R8510[65] = (char *(*)()) F1209_11532;
	R8510[67] = (char *(*)()) F1211_11576;
	{long i; for (i = 68; i < 70; i++) R8510[i] = (char *(*)()) F1141_10634;}
	R8510[71] = (char *(*)()) F1141_10634;
	R8510[88] = (char *(*)()) F1232_11919;
	R8510[92] = (char *(*)()) F1236_12087;
	R8510[93] = (char *(*)()) F1237_12095;
	R8510[98] = (char *(*)()) F1141_10634;
	R8510[111] = (char *(*)()) F1255_12497;
	R8510[117] = (char *(*)()) F1261_12513;
	R8510[121] = (char *(*)()) F1261_12513;
	R8510[134] = (char *(*)()) F1141_10634;
	R8510[137] = (char *(*)()) F1141_10634;
}

char *(*R8512[138])();
void R8512_init () {
	R8512[0] = (char *(*)()) F1141_10637;
	{long i; for (i = 54; i < 56; i++) R8512[i] = (char *(*)()) F1141_10637;}
	{long i; for (i = 64; i < 66; i++) R8512[i] = (char *(*)()) F1141_10637;}
	{long i; for (i = 67; i < 70; i++) R8512[i] = (char *(*)()) F1141_10637;}
	R8512[71] = (char *(*)()) F1141_10637;
	R8512[88] = (char *(*)()) F1141_10637;
	{long i; for (i = 92; i < 94; i++) R8512[i] = (char *(*)()) F1141_10637;}
	R8512[98] = (char *(*)()) F1242_12220;
	R8512[111] = (char *(*)()) F1141_10637;
	R8512[117] = (char *(*)()) F1141_10637;
	R8512[121] = (char *(*)()) F1141_10637;
	R8512[134] = (char *(*)()) F1278_12851;
	R8512[137] = (char *(*)()) F1281_13018;
}

char *(*R8513[138])();
void R8513_init () {
	R8513[0] = (char *(*)()) F1141_10638;
	{long i; for (i = 54; i < 56; i++) R8513[i] = (char *(*)()) F1141_10638;}
	{long i; for (i = 64; i < 66; i++) R8513[i] = (char *(*)()) F1141_10638;}
	{long i; for (i = 67; i < 70; i++) R8513[i] = (char *(*)()) F1141_10638;}
	R8513[71] = (char *(*)()) F1141_10638;
	R8513[88] = (char *(*)()) F1141_10638;
	{long i; for (i = 92; i < 94; i++) R8513[i] = (char *(*)()) F1141_10638;}
	R8513[98] = (char *(*)()) F1141_10638;
	R8513[111] = (char *(*)()) F1141_10638;
	R8513[117] = (char *(*)()) F1141_10638;
	R8513[121] = (char *(*)()) F1141_10638;
	R8513[134] = (char *(*)()) F1278_12864;
	R8513[137] = (char *(*)()) F1281_13002;
}

char *(*R8515[138])();
void R8515_init () {
	R8515[0] = (char *(*)()) F1141_10640;
	{long i; for (i = 54; i < 56; i++) R8515[i] = (char *(*)()) F1141_10640;}
	{long i; for (i = 64; i < 66; i++) R8515[i] = (char *(*)()) F1141_10640;}
	{long i; for (i = 67; i < 70; i++) R8515[i] = (char *(*)()) F1141_10640;}
	R8515[71] = (char *(*)()) F1141_10640;
	R8515[88] = (char *(*)()) F1141_10640;
	{long i; for (i = 92; i < 94; i++) R8515[i] = (char *(*)()) F1141_10640;}
	R8515[98] = (char *(*)()) F1141_10640;
	R8515[111] = (char *(*)()) F1141_10640;
	R8515[117] = (char *(*)()) F1141_10640;
	R8515[121] = (char *(*)()) F1141_10640;
	R8515[134] = (char *(*)()) F1278_12865;
	R8515[137] = (char *(*)()) F1141_10640;
}

char *(*R8518[138])();
void R8518_init () {
	R8518[0] = (char *(*)()) F1141_10643;
	{long i; for (i = 54; i < 56; i++) R8518[i] = (char *(*)()) F1141_10643;}
	{long i; for (i = 64; i < 66; i++) R8518[i] = (char *(*)()) F1141_10643;}
	{long i; for (i = 67; i < 70; i++) R8518[i] = (char *(*)()) F1141_10643;}
	R8518[71] = (char *(*)()) F1141_10643;
	R8518[88] = (char *(*)()) F1141_10643;
	{long i; for (i = 92; i < 94; i++) R8518[i] = (char *(*)()) F1141_10643;}
	R8518[98] = (char *(*)()) F1141_10643;
	R8518[111] = (char *(*)()) F1141_10643;
	R8518[117] = (char *(*)()) F1141_10643;
	R8518[121] = (char *(*)()) F1141_10643;
	R8518[134] = (char *(*)()) F1278_12866;
	R8518[137] = (char *(*)()) F1141_10643;
}

char *(*R8520[138])();
void R8520_init () {
	R8520[0] = (char *(*)()) F1141_10645;
	{long i; for (i = 54; i < 56; i++) R8520[i] = (char *(*)()) F1141_10645;}
	{long i; for (i = 64; i < 66; i++) R8520[i] = (char *(*)()) F1141_10645;}
	{long i; for (i = 67; i < 70; i++) R8520[i] = (char *(*)()) F1141_10645;}
	R8520[71] = (char *(*)()) F1141_10645;
	R8520[88] = (char *(*)()) F1141_10645;
	{long i; for (i = 92; i < 94; i++) R8520[i] = (char *(*)()) F1141_10645;}
	R8520[98] = (char *(*)()) F1141_10645;
	R8520[111] = (char *(*)()) F1141_10645;
	R8520[117] = (char *(*)()) F1141_10645;
	R8520[121] = (char *(*)()) F1141_10645;
	R8520[134] = (char *(*)()) F1278_12867;
	R8520[137] = (char *(*)()) F1141_10645;
}

char *(*R8521[138])();
void R8521_init () {
	R8521[0] = (char *(*)()) F1141_10646;
	{long i; for (i = 54; i < 56; i++) R8521[i] = (char *(*)()) F1141_10646;}
	{long i; for (i = 64; i < 66; i++) R8521[i] = (char *(*)()) F1141_10646;}
	R8521[67] = (char *(*)()) F1210_11567;
	{long i; for (i = 68; i < 70; i++) R8521[i] = (char *(*)()) F1141_10646;}
	R8521[71] = (char *(*)()) F1141_10646;
	R8521[88] = (char *(*)()) F1141_10646;
	{long i; for (i = 92; i < 94; i++) R8521[i] = (char *(*)()) F1141_10646;}
	R8521[98] = (char *(*)()) F1242_12219;
	R8521[111] = (char *(*)()) F1141_10646;
	R8521[117] = (char *(*)()) F1141_10646;
	R8521[121] = (char *(*)()) F1141_10646;
	R8521[134] = (char *(*)()) F1141_10646;
	R8521[137] = (char *(*)()) F1141_10646;
}

char *(*R8531[138])();
void R8531_init () {
	R8531[0] = (char *(*)()) F1142_10657;
	{long i; for (i = 54; i < 56; i++) R8531[i] = (char *(*)()) F1185_11226;}
	{long i; for (i = 64; i < 66; i++) R8531[i] = (char *(*)()) F1185_11226;}
	R8531[67] = (char *(*)()) F1185_11226;
	{long i; for (i = 68; i < 70; i++) R8531[i] = (char *(*)()) F1142_10657;}
	R8531[71] = (char *(*)()) F1142_10657;
	R8531[88] = (char *(*)()) F1185_11226;
	{long i; for (i = 92; i < 94; i++) R8531[i] = (char *(*)()) F1185_11226;}
	R8531[98] = (char *(*)()) F1185_11226;
	R8531[111] = (char *(*)()) F1142_10657;
	R8531[117] = (char *(*)()) F1142_10657;
	R8531[121] = (char *(*)()) F1142_10657;
	R8531[134] = (char *(*)()) F1185_11226;
	R8531[137] = (char *(*)()) F1185_11226;
}

char *(*R8532[138])();
void R8532_init () {
	R8532[0] = (char *(*)()) F1142_10658;
	{long i; for (i = 54; i < 56; i++) R8532[i] = (char *(*)()) F1185_11227;}
	{long i; for (i = 64; i < 66; i++) R8532[i] = (char *(*)()) F1185_11227;}
	R8532[67] = (char *(*)()) F1185_11227;
	{long i; for (i = 68; i < 70; i++) R8532[i] = (char *(*)()) F1142_10658;}
	R8532[71] = (char *(*)()) F1142_10658;
	R8532[88] = (char *(*)()) F1185_11227;
	{long i; for (i = 92; i < 94; i++) R8532[i] = (char *(*)()) F1185_11227;}
	R8532[98] = (char *(*)()) F1185_11227;
	R8532[111] = (char *(*)()) F1142_10658;
	R8532[117] = (char *(*)()) F1142_10658;
	R8532[121] = (char *(*)()) F1142_10658;
	R8532[134] = (char *(*)()) F1185_11227;
	R8532[137] = (char *(*)()) F1185_11227;
}

char *(*R8540[138])();
void R8540_init () {
	R8540[0] = (char *(*)()) F1142_10666;
	{long i; for (i = 54; i < 56; i++) R8540[i] = (char *(*)()) F1142_10666;}
	{long i; for (i = 64; i < 66; i++) R8540[i] = (char *(*)()) F1142_10666;}
	{long i; for (i = 67; i < 70; i++) R8540[i] = (char *(*)()) F1142_10666;}
	R8540[71] = (char *(*)()) F1142_10666;
	R8540[88] = (char *(*)()) F1142_10666;
	R8540[92] = (char *(*)()) F1142_10666;
	R8540[93] = (char *(*)()) F1237_12094;
	R8540[98] = (char *(*)()) F1142_10666;
	R8540[111] = (char *(*)()) F1142_10666;
	R8540[117] = (char *(*)()) F1142_10666;
	R8540[121] = (char *(*)()) F1142_10666;
	R8540[134] = (char *(*)()) F1142_10666;
	R8540[137] = (char *(*)()) F1142_10666;
}

char *(*R8546[138])();
void R8546_init () {
	R8546[0] = (char *(*)()) F1142_10672;
	{long i; for (i = 54; i < 56; i++) R8546[i] = (char *(*)()) F1142_10672;}
	{long i; for (i = 64; i < 66; i++) R8546[i] = (char *(*)()) F1142_10672;}
	{long i; for (i = 67; i < 70; i++) R8546[i] = (char *(*)()) F1142_10672;}
	R8546[71] = (char *(*)()) F1142_10672;
	R8546[88] = (char *(*)()) F1142_10672;
	{long i; for (i = 92; i < 94; i++) R8546[i] = (char *(*)()) F1142_10672;}
	R8546[98] = (char *(*)()) F1142_10672;
	R8546[111] = (char *(*)()) F1142_10672;
	R8546[117] = (char *(*)()) F1142_10672;
	R8546[121] = (char *(*)()) F1142_10672;
	R8546[134] = (char *(*)()) F1278_12876;
	R8546[137] = (char *(*)()) F1142_10672;
}

char *(*R8547[138])();
void R8547_init () {
	R8547[0] = (char *(*)()) F1142_10673;
	{long i; for (i = 54; i < 56; i++) R8547[i] = (char *(*)()) F1142_10673;}
	{long i; for (i = 64; i < 66; i++) R8547[i] = (char *(*)()) F1142_10673;}
	R8547[67] = (char *(*)()) F1142_10673;
	{long i; for (i = 68; i < 70; i++) R8547[i] = (char *(*)()) F1212_11609;}
	R8547[71] = (char *(*)()) F1212_11609;
	R8547[88] = (char *(*)()) F1142_10673;
	{long i; for (i = 92; i < 94; i++) R8547[i] = (char *(*)()) F1142_10673;}
	R8547[98] = (char *(*)()) F1142_10673;
	R8547[111] = (char *(*)()) F1142_10673;
	R8547[117] = (char *(*)()) F1142_10673;
	R8547[121] = (char *(*)()) F1142_10673;
	R8547[134] = (char *(*)()) F1142_10673;
	R8547[137] = (char *(*)()) F1142_10673;
}

char *(*R8551[138])();
void R8551_init () {
	R8551[0] = (char *(*)()) F1143_10707;
	{long i; for (i = 54; i < 56; i++) R8551[i] = (char *(*)()) F1142_10677;}
	{long i; for (i = 64; i < 66; i++) R8551[i] = (char *(*)()) F1142_10677;}
	R8551[67] = (char *(*)()) F1142_10677;
	R8551[68] = (char *(*)()) F1212_11622;
	R8551[69] = (char *(*)()) F1213_11681;
	R8551[71] = (char *(*)()) F1212_11622;
	R8551[88] = (char *(*)()) F1142_10677;
	{long i; for (i = 92; i < 94; i++) R8551[i] = (char *(*)()) F1142_10677;}
	R8551[98] = (char *(*)()) F1142_10677;
	R8551[111] = (char *(*)()) F1142_10677;
	R8551[117] = (char *(*)()) F1142_10677;
	R8551[134] = (char *(*)()) F1142_10677;
	R8551[137] = (char *(*)()) F1142_10677;
}


#ifdef __cplusplus
}
#endif
