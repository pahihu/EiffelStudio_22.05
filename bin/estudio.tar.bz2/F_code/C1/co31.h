
#ifndef _C1_co31_
#define _C1_co31_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F31_726(EIF_REFERENCE);
extern EIF_REFERENCE F31_727(EIF_REFERENCE);
extern EIF_REFERENCE F31_728(EIF_REFERENCE);
extern EIF_REFERENCE F31_729(EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
