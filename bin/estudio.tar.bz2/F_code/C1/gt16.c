/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt16.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F16_281
static EIF_NATURAL_8 inline_F16_281 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F16_281
#endif
#ifndef INLINE_F16_282
static EIF_NATURAL_8 inline_F16_282 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F16_282
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F16_281 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F16_281 ();
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F16_282 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F16_282 ();
	return Result;
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
