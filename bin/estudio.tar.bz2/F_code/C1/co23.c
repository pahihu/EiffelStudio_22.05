/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co23.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F23_503 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (275,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F23_504 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (276,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F23_505 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (277,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F23_506 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (278,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F23_507 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (279,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F23_508 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (280,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F23_509 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (281,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F23_510 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (282,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit23 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
