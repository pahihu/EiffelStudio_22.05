/*
 * Code for class PRODUCT_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRODUCT_NAMES}.workbench_name */

EIF_REFERENCE F9_140 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (237,RTMS_EX_H("EiffelStudio",12,1072716399));
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
