/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt15.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F15_272
static EIF_POINTER inline_F15_272 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F15_272
#endif
#ifndef INLINE_F15_279
static EIF_POINTER inline_F15_279 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F15_279
#endif
#ifndef INLINE_F15_280
static EIF_POINTER inline_F15_280 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F15_280
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F15_272 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_272 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F15_279 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_279 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F15_280 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_280 ();
	return Result;
}

void EIF_Minit15 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
