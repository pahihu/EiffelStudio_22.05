
#ifndef _C1_gd11_
#define _C1_gd11_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_147(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F11_150(EIF_REFERENCE);
extern EIF_INTEGER_32 F11_152(EIF_REFERENCE);
extern void EIF_Minit11(void);

#ifdef __cplusplus
}
#endif

#endif
