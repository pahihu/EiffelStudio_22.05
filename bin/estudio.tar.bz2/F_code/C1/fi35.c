/*
 * Code for class FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi35.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F36_780 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = F869_6791(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F852_5878(RTCW(tr1), arg1);
		tb1 = F852_5901(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE_UTILITIES}.directory_exists */
EIF_BOOLEAN F36_781 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6703[Dtype(RTCW(arg1))-983])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F852_5876(RTCW(tr1), arg1);
		tb1 = F852_5901(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE_UTILITIES}.create_directory */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F36_785 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = RTLNS(eif_new_type(851, 0x00).id, 851, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F852_5876(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = F852_5901(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			F852_5881(RTCW(loc2));
		}
	}
	RTE_E
	RTXSC;
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.file_path_exists */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F36_791 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	tb1 = '\0';
	tb2 = F869_6791(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN) !loc2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(857, 0x00).id, 857, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F857_6225(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		Result = '\0';
		tb1 = F857_6259(RTCW(loc1));
		if (tb1) {
			tb1 = F857_6266(RTCW(loc1));
			Result = tb1;
		}
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit35 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
