/*
 * Code for class COMPILER_PROFILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co5.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER_PROFILE}.initialize_from_arguments */
void F5_68 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F5_108(Current);
	loc1 = RTLNS(eif_new_type(138, 0x00).id, 138, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(320,F5_69, (Current));
	ti4_1 = F138_2912(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F5_95(Current);
	} else {
		tr1 = RTOUCR(321,F5_70, (Current));
		ti4_1 = F138_2912(RTCW(loc1), tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F5_96(Current);
		}
	}
	tr1 = RTOUCR(322,F5_71, (Current));
	ti4_1 = F138_2912(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F5_97(Current);
	}
	tr1 = RTOUCR(323,F5_72, (Current));
	ti4_1 = F138_2912(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F5_98(Current);
	}
	tr1 = RTOUCR(324,F5_73, (Current));
	loc3 = F138_2912(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F138_2915(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F138_2910(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F5_86(Current, loc2)) {
			F5_99(Current, loc2);
		}
	}
	tr1 = RTOUCR(325,F5_74, (Current));
	loc3 = F138_2912(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F138_2915(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F138_2910(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F5_91(Current, loc2)) {
			F5_100(Current, loc2);
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.compat_option_name */

EIF_REFERENCE F5_69 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (320,RTMS_EX_H("compat",6,2031575924));
}

/* {COMPILER_PROFILE}.experiment_option_name */

EIF_REFERENCE F5_70 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (321,RTMS_EX_H("experiment",10,207796852));
}

/* {COMPILER_PROFILE}.full_option_name */

EIF_REFERENCE F5_71 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (322,RTMS_EX_H("full",4,1718971500));
}

/* {COMPILER_PROFILE}.safe_option_name */

EIF_REFERENCE F5_72 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (323,RTMS_EX_H("safe",4,1935763045));
}

/* {COMPILER_PROFILE}.platform_option_name */

EIF_REFERENCE F5_73 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (324,RTMS_EX_H("platform",8,459690093));
}

/* {COMPILER_PROFILE}.capabilty_option_name */

EIF_REFERENCE F5_74 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (325,RTMS_EX_H("capability",10,950653049));
}

/* {COMPILER_PROFILE}.is_compatible_mode */
EIF_BOOLEAN F5_79 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 1U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 1U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_experimental_mode */
EIF_BOOLEAN F5_81 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 2U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_platform_valid */
EIF_BOOLEAN F5_86 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb3 = F981_8148(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb3 = F981_8148(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTMS_EX_H("macintosh",9,458551400);
		tb2 = F981_8148(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTMS_EX_H("vxworks",7,1368523123);
		tb1 = F981_8148(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_capability_valid */
EIF_BOOLEAN F5_91 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tr1 = RTOUCR(326,F5_120, (Current));
	tb2 = F981_8151(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTOUCR(327,F5_121, (Current));
		tb2 = F981_8151(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTOUCR(328,F5_122, (Current));
		tb1 = F981_8151(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.set_compatible_mode */
void F5_95 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_experimental_mode */
void F5_96 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_full_class_checking_mode */
void F5_97 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_safe_mode */
void F5_98 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 8U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_platform */
void F5_99 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb1 = F981_8148(RTCW(arg1), tr1);
	if (tb1) {
		F5_101(Current);
	} else {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = F981_8148(RTCW(arg1), tr1);
		if (tb1) {
			F5_102(Current);
		} else {
			tr1 = RTMS_EX_H("macintosh",9,458551400);
			tb1 = F981_8148(RTCW(arg1), tr1);
			if (tb1) {
				F5_103(Current);
			} else {
				tr1 = RTMS_EX_H("vxworks",7,1368523123);
				tb1 = F981_8148(RTCW(arg1), tr1);
				if (tb1) {
					F5_104(Current);
				}
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability */
void F5_100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(326,F5_120, (Current));
	tb1 = F981_8151(RTCW(arg1), tr1);
	if (tb1) {
		F5_105(Current);
	} else {
		tr1 = RTOUCR(327,F5_121, (Current));
		tb1 = F981_8151(RTCW(arg1), tr1);
		if (tb1) {
			F5_106(Current);
		} else {
			tr1 = RTOUCR(328,F5_122, (Current));
			tb1 = F981_8151(RTCW(arg1), tr1);
			if (tb1) {
				F5_107(Current);
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_windows_platform */
void F5_101 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 32U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_unix_platform */
void F5_102 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 16U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_mac_platform */
void F5_103 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 48U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_vxworks_platform */
void F5_104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 64U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_warning */
void F5_105 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 512U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 256U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_error */
void F5_106 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 256U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 512U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_strict */
void F5_107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1024U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.reset */
void F5_108 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
}

/* {COMPILER_PROFILE}.capability_value_warning */

EIF_REFERENCE F5_120 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (326,RTMS_EX_H("warning",7,1809215079));
}

/* {COMPILER_PROFILE}.capability_value_error */

EIF_REFERENCE F5_121 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (327,RTMS_EX_H("error",5,1920877938));
}

/* {COMPILER_PROFILE}.capability_value_strict */

EIF_REFERENCE F5_122 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (328,RTMS_EX_H("strict",6,2146499444));
}

void EIF_Minit5 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
