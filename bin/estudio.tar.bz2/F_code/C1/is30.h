
#ifndef _C1_is30_
#define _C1_is30_

#ifdef __cplusplus
extern "C" {
#endif

extern void F30_722(EIF_REFERENCE);
extern EIF_NATURAL_16 F30_724(EIF_REFERENCE, EIF_POINTER);
extern void F30_725(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
