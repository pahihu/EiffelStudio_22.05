
#ifndef _C1_gd6_
#define _C1_gd6_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F6_133(EIF_REFERENCE);
extern void EIF_Minit6(void);

#ifdef __cplusplus
}
#endif

#endif
