/*
 * Code for class GDK_HELPERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd11.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F11_147
static void inline_F11_147 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F11_147
#endif
#ifndef INLINE_F11_150
static EIF_POINTER inline_F11_150 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F11_150
#endif
#ifndef INLINE_F11_152
static EIF_INTEGER_32 inline_F11_152 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F11_152
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_HELPERS}.device_get_position */
void F11_147 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F11_147 ((EIF_POINTER) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
}

/* {GDK_HELPERS}.default_device */
EIF_POINTER F11_150 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F11_150 ();
	return Result;
}

/* {GDK_HELPERS}.default_cursor_size */
EIF_INTEGER_32 F11_152 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F11_152 ();
	return Result;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
