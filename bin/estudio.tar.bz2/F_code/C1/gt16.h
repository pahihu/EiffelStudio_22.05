
#ifndef _C1_gt16_
#define _C1_gt16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F16_281(EIF_REFERENCE);
extern EIF_NATURAL_8 F16_282(EIF_REFERENCE);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
