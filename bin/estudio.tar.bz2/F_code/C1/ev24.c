/*
 * Code for class EV_STOCK_PIXMAPS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev24.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS}.information_pixmap */
static EIF_REFERENCE F24_515_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(267)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = F262_4198(RTCV(RTOUCR(268,F24_535, (Current))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_515 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(267,F24_515_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.error_pixmap */
static EIF_REFERENCE F24_516_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(83)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = F262_4199(RTCV(RTOUCR(268,F24_535, (Current))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_516 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(83,F24_516_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.default_window_icon */
static EIF_REFERENCE F24_519_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(50)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = F262_4206(RTCV(RTOUCR(268,F24_535, (Current))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_519 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(50,F24_519_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.standard_cursor */
static EIF_REFERENCE F24_521_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(269)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1023, 0x00).id, 1023, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1024_8790(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_521 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(269,F24_521_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.help_cursor */
static EIF_REFERENCE F24_523_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(80)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1023, 0x00).id, 1023, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1024_8790(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_523 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(80,F24_523_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.ibeam_cursor */
static EIF_REFERENCE F24_524_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(270)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1023, 0x00).id, 1023, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1024_8790(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_524 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(270,F24_524_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.no_cursor */
static EIF_REFERENCE F24_525_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(271)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1023, 0x00).id, 1023, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1024_8790(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_525 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(271,F24_525_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.sizeall_cursor */
static EIF_REFERENCE F24_526_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(272)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1023, 0x00).id, 1023, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1024_8790(RTCW(tr1), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_526 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(272,F24_526_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.implementation */
static EIF_REFERENCE F24_535_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(268)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(261, 0x00).id, 261, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_535 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(268,F24_535_body,(Current));
}

void EIF_Minit24 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
