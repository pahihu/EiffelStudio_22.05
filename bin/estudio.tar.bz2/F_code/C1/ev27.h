
#ifndef _C1_ev27_
#define _C1_ev27_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F27_568(EIF_REFERENCE);
extern EIF_REFERENCE F27_571(EIF_REFERENCE);
extern EIF_REFERENCE F27_575(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit27(void);
extern void F849_5843(EIF_REFERENCE, EIF_REFERENCE);
extern void F1028_8847(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);

#ifdef __cplusplus
}
#endif

#endif
