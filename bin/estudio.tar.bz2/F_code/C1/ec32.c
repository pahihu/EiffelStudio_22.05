/*
 * Code for class EC_ACTION_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ec32.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EC_ACTION_PARSER}.parse */
void F32_734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	loc4 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(68,F32_738, (Current)))+ _LNGOFF_1_1_0_2_);
	tb1 = '\0';
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6725[Dtype(RTCW(arg1))-983])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 > loc4)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6766[Dtype(RTCW(arg1))-983])(arg1, ((EIF_INTEGER_32) 1L), loc4);
		tr2 = RTOUCR(68,F32_738, (Current));
		tb2 = F981_8148(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = F981_8165(RTCW(arg1));
		F983_8204(RTCW(loc1), tr1);
		F988_8447(RTCW(loc1), loc4);
		tr1 = F981_8165(RTCV(RTOUCR(69,F31_726, (Current))));
		loc2 = F32_737(Current, tr1);
		tr1 = F981_8165(RTCV(RTOUCR(70,F31_728, (Current))));
		tr1 = F32_737(Current, tr1);
		F988_8425(RTCW(loc2), tr1);
		tr1 = F981_8165(RTCV(RTOUCR(71,F31_727, (Current))));
		tr1 = F32_737(Current, tr1);
		F988_8425(RTCW(loc2), tr1);
		tr1 = F32_737(Current, loc1);
		F988_8425(RTCW(loc2), tr1);
		tr1 = F981_8165(RTCV(RTOUCR(71,F31_727, (Current))));
		loc3 = F32_737(Current, tr1);
		tr1 = F32_737(Current, loc1);
		F988_8425(RTCW(loc3), tr1);
	}
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc2;
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {EC_ACTION_PARSER}.label */
EIF_REFERENCE F32_737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	F988_8416(RTCW(Result), (EIF_CHARACTER_32) 60U);
	F988_8438(RTCW(Result), (EIF_CHARACTER_32) 62U);
	RTLE;
	return Result;
}

/* {EC_ACTION_PARSER}.eis_incoming */

EIF_REFERENCE F32_738 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (68,RTMS32_EX_H("e\000\000\000i\000\000\000s\000\000\000i\000\000\000:\000\000\000",5,1769946938));
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
