
#ifndef _C1_gt7_
#define _C1_gt7_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F7_134(EIF_REFERENCE);
extern EIF_BOOLEAN F7_135(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit7(void);

#ifdef __cplusplus
}
#endif

#endif
