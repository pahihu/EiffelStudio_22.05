
#ifndef _C1_gt15_
#define _C1_gt15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F15_272(EIF_REFERENCE);
extern EIF_POINTER F15_279(EIF_REFERENCE);
extern EIF_POINTER F15_280(EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
