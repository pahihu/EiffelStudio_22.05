/*
 * Code for class COMMAND_PROTOCOL_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co31.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMMAND_PROTOCOL_NAMES}.compiler_module */

EIF_REFERENCE F31_726 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (69,RTMS_EX_H("com.eiffel.compiler",19,1071610226));
}

/* {COMMAND_PROTOCOL_NAMES}.eis_incoming_module */

EIF_REFERENCE F31_727 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (71,RTMS_EX_H("com.eiffel.eis_incoming",23,117361511));
}

/* {COMMAND_PROTOCOL_NAMES}.project_ready */

EIF_REFERENCE F31_728 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (70,RTMS_EX_H("project_ready",13,1070011769));
}

/* {COMMAND_PROTOCOL_NAMES}.eiffel_studio_key */

EIF_REFERENCE F31_729 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (25,RTMS_EX_H("06504BCF-876A-4F90-B7DA-ED15920217BB",36,775164482));
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
