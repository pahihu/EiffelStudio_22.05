
#ifndef _C1_gt10_
#define _C1_gt10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F10_142(EIF_REFERENCE);
extern EIF_INTEGER_32 F10_143(EIF_REFERENCE);
extern EIF_INTEGER_32 F10_144(EIF_REFERENCE);
extern void EIF_Minit10(void);

#ifdef __cplusplus
}
#endif

#endif
