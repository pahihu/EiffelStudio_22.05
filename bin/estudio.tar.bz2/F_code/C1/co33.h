
#ifndef _C1_co33_
#define _C1_co33_

#ifdef __cplusplus
extern "C" {
#endif

extern void F33_741(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F33_742(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F33_743(EIF_REFERENCE);
extern EIF_BOOLEAN F33_744(EIF_REFERENCE);
extern void F33_746(EIF_REFERENCE);
extern void EIF_Minit33(void);

#ifdef __cplusplus
}
#endif

#endif
