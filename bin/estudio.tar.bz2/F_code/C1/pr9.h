
#ifndef _C1_pr9_
#define _C1_pr9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F9_140(EIF_REFERENCE);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
