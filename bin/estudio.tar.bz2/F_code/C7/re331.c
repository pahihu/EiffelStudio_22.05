/*
 * Code for class reference REAL_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REAL_32}.is_less */
EIF_BOOLEAN F928_7820 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	Result = F927_7790(Current, tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.truncated_to_integer */
EIF_INTEGER_32 F928_7824 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F927_7801(Current);
}

/* {REAL_32}.to_double */
EIF_REAL_64 F928_7826 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_64) F927_7803(Current);
}

/* {REAL_32}.floor_real_32 */
EIF_REAL_32 F928_7828 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_32) F927_7808(Current);
}

/* {REAL_32}.plus */
EIF_REAL_32 F928_7829 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F927_7811(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.minus */
EIF_REAL_32 F928_7830 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F927_7812(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.product */
EIF_REAL_32 F928_7831 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F927_7813(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.quotient */
EIF_REAL_32 F928_7832 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = arg1;
	tr1 = F927_7814(Current, tr1);
	Result = *(EIF_REAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {REAL_32}.opposite */
EIF_REAL_32 F928_7835 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return *(EIF_REAL_32 *)F927_7817(Current);
}

/* {REAL_32}.out */
EIF_REFERENCE F928_7843 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F927_7818(Current);
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
