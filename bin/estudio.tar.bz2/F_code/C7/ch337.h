
#ifndef _C7_ch337_
#define _C7_ch337_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F934_7947(EIF_REFERENCE);
extern EIF_NATURAL_32 F934_7948(EIF_REFERENCE);
extern EIF_CHARACTER_8 F934_7949(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern EIF_NATURAL_32 F933_7913(EIF_REFERENCE);
extern EIF_CHARACTER_8 F933_7928(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
