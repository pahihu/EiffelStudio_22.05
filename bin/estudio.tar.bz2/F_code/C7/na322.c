/*
 * Code for class reference NATURAL_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na322.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_32}.is_less */
EIF_BOOLEAN F919_7561 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	Result = F918_7502(Current, tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.plus */
EIF_NATURAL_32 F919_7562 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7511(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.minus */
EIF_NATURAL_32 F919_7563 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7512(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.integer_quotient */
EIF_NATURAL_32 F919_7567 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7517(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.integer_remainder */
EIF_NATURAL_32 F919_7568 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7518(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.as_natural_8 */
EIF_NATURAL_8 F919_7570 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_8) F918_7523(Current);
}

/* {NATURAL_32}.as_natural_16 */
EIF_NATURAL_16 F919_7571 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_16) F918_7524(Current);
}

/* {NATURAL_32}.as_natural_64 */
EIF_NATURAL_64 F919_7573 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F918_7526(Current);
}

/* {NATURAL_32}.as_integer_32 */
EIF_INTEGER_32 F919_7576 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F918_7529(Current);
}

/* {NATURAL_32}.as_integer_64 */
EIF_INTEGER_64 F919_7577 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_64) F918_7530(Current);
}

/* {NATURAL_32}.to_character_8 */
EIF_CHARACTER_8 F919_7580 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) F918_7548(Current);
}

/* {NATURAL_32}.to_character_32 */
EIF_CHARACTER_32 F919_7581 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_32) F918_7549(Current);
}

/* {NATURAL_32}.bit_and */
EIF_NATURAL_32 F919_7582 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7550(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.bit_or */
EIF_NATURAL_32 F919_7583 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F918_7551(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_32}.bit_not */
EIF_NATURAL_32 F919_7585 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return *(EIF_NATURAL_32 *)F918_7553(Current);
}

/* {NATURAL_32}.bit_shift_left */
EIF_NATURAL_32 F919_7586 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_32 *)F918_7555(Current, arg1);
}

/* {NATURAL_32}.bit_shift_right */
EIF_NATURAL_32 F919_7587 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_32 *)F918_7556(Current, arg1);
}

void EIF_Minit322 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
