/*
 * Code for class TUPLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "tu304.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TUPLE}.item */
EIF_REFERENCE F902_6873 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg1)) {
		case 1U:
			Result = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_BOOLEAN *)Result = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, arg1);
			break;
		case 2U:
			Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)Result = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, arg1);
			break;
		case 14U:
			Result = RTLNS(eif_new_type(934, 0x00).id, 934, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)Result = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, arg1);
			break;
		case 3U:
			Result = RTLNS(eif_new_type(931, 0x00).id, 931, _OBJSIZ_0_0_0_0_0_0_0_1_);
			*(EIF_REAL_64 *)Result = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, arg1);
			break;
		case 4U:
			Result = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)Result = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, arg1);
			break;
		case 5U:
			Result = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
			*(EIF_POINTER *)Result = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, arg1);
			break;
		case 10U:
			Result = RTLNS(eif_new_type(925, 0x00).id, 925, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_NATURAL_8 *)Result = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, arg1);
			break;
		case 11U:
			Result = RTLNS(eif_new_type(922, 0x00).id, 922, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_NATURAL_16 *)Result = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, arg1);
			break;
		case 12U:
			Result = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_NATURAL_32 *)Result = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, arg1);
			break;
		case 13U:
			Result = RTLNS(eif_new_type(916, 0x00).id, 916, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)Result = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, arg1);
			break;
		case 6U:
			Result = RTLNS(eif_new_type(913, 0x00).id, 913, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_INTEGER_8 *)Result = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, arg1);
			break;
		case 7U:
			Result = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_INTEGER_16 *)Result = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, arg1);
			break;
		case 8U:
			Result = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)Result = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, arg1);
			break;
		case 9U:
			Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_INTEGER_64 *)Result = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, arg1);
			break;
		case 0U:
			Result = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, arg1);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {TUPLE}.reference_item */
EIF_REFERENCE F902_6875 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	Result = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, arg1);
	RTLE;
	return Result;
}

/* {TUPLE}.boolean_item */
EIF_BOOLEAN F902_6876 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, arg1);
	return Result;
}

/* {TUPLE}.character_8_item */
EIF_CHARACTER_8 F902_6877 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	
	Result = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, arg1);
	return Result;
}

/* {TUPLE}.character_32_item */
EIF_CHARACTER_32 F902_6879 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	
	
	Result = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, arg1);
	return Result;
}

/* {TUPLE}.real_64_item */
EIF_REAL_64 F902_6881 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	
	Result = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, arg1);
	return Result;
}

/* {TUPLE}.double_item */
EIF_REAL_64 F902_6882 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_REAL_64) (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, arg1);
}

/* {TUPLE}.natural_8_item */
EIF_NATURAL_8 F902_6883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, arg1);
	return Result;
}

/* {TUPLE}.natural_16_item */
EIF_NATURAL_16 F902_6884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	
	
	Result = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, arg1);
	return Result;
}

/* {TUPLE}.natural_32_item */
EIF_NATURAL_32 F902_6885 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, arg1);
	return Result;
}

/* {TUPLE}.natural_64_item */
EIF_NATURAL_64 F902_6886 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	
	
	Result = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, arg1);
	return Result;
}

/* {TUPLE}.integer_8_item */
EIF_INTEGER_8 F902_6887 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, arg1);
	return Result;
}

/* {TUPLE}.integer_16_item */
EIF_INTEGER_16 F902_6888 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	
	
	Result = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, arg1);
	return Result;
}

/* {TUPLE}.integer_32_item */
EIF_INTEGER_32 F902_6889 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, arg1);
	return Result;
}

/* {TUPLE}.integer_64_item */
EIF_INTEGER_64 F902_6891 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	
	
	Result = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, arg1);
	return Result;
}

/* {TUPLE}.pointer_item */
EIF_POINTER F902_6892 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, arg1);
	return Result;
}

/* {TUPLE}.real_32_item */
EIF_REAL_32 F902_6893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	
	
	Result = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, arg1);
	return Result;
}

/* {TUPLE}.object_comparison */
EIF_BOOLEAN F902_6895 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (Current);
	return Result;
}

/* {TUPLE}.is_equal */
EIF_BOOLEAN F902_6896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc3 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (Current);
	tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (arg1);
	if ((EIF_BOOLEAN)(loc3 == tb1)) {
		if (loc3) {
			loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (arg1);
			if ((EIF_BOOLEAN)(loc2 == ti4_1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
					tr1 = F902_6873(Current, loc1);
					tr2 = F902_6873(RTCW(arg1), loc1);
					Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
					loc1++;
				}
			}
		} else {
			Result = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (Current, arg1);
			RTLE;
			return (EIF_BOOLEAN) Result;
		}
	}
	RTLE;
	return Result;
}

/* {TUPLE}.compare_objects */
void F902_6897 (EIF_REFERENCE Current)
{
	GTCX
	
	
	eif_builtin_TUPLE_set_object_comparison__b_ (Current, (EIF_BOOLEAN) 1);
}

/* {TUPLE}.hash_code */
EIF_INTEGER_32 F902_6899 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_64 tu8_1;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_INTEGER_16 ti2_1;
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, loc1)) {
			case 1U:
				tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, loc1);
				loc3 = (tb1 ? 1L : 0L);
				break;
			case 2U:
				tc1 = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (tc1);
				break;
			case 14U:
				tw1 = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (tw1);
				break;
			case 3U:
				tr8_1 = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tr8_1)));
				break;
			case 4U:
				tr4_1 = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tr4_1)));
				break;
			case 5U:
				tp1 = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tp1)));
				break;
			case 10U:
				tu1_1 = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu1_1)));
				break;
			case 11U:
				tu2_1 = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu2_1)));
				break;
			case 12U:
				tu4_1 = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu4_1)));
				break;
			case 13U:
				tu8_1 = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu8_1)));
				break;
			case 6U:
				ti1_1 = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti1_1)));
				break;
			case 7U:
				ti2_1 = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti2_1)));
				break;
			case 8U:
				ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti4_1)));
				break;
			case 9U:
				ti8_1 = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti8_1)));
				break;
			case 0U:
				tr1 = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, loc1);
				loc4 = RTCCL(tr1);
				loc4 = RTRV(eif_new_type(867, 0x00),loc4);
				if (EIF_TEST(loc4)) {
					loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5820[Dtype(loc4)-868])(loc4);
				} else {
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
		tr1 = RTOUCR(2,F902_7003, (Current));
		ti4_1 = F679_5462(RTCW(tr1), loc1);
		Result += (EIF_INTEGER_32) (loc3 * ti4_1);
		loc1++;
	}
	ti4_1 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (Result)));
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {TUPLE}.valid_index */
EIF_BOOLEAN F902_6900 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1L))) {
		Result = (EIF_BOOLEAN) (arg1 <= (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current));
	}
	RTLE;
	return Result;
}

/* {TUPLE}.valid_type_for_index */
EIF_BOOLEAN F902_6901 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(18);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLR(9,loc9);
	RTLR(10,loc10);
	RTLR(11,loc11);
	RTLR(12,loc12);
	RTLR(13,loc13);
	RTLR(14,loc14);
	RTLR(15,loc15);
	RTLR(16,loc16);
	RTLR(17,loc1);
	RTLIU(18);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		if ((EIF_BOOLEAN)((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2) == ((EIF_NATURAL_8) 0U))) {
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
			tr1 = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (tr1, arg2);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5886[Dtype(RTCW(tr1))-869])(tr1);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
		}
	} else {
		switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2)) {
			case 1U:
				loc3 = RTCCL(arg1);
				loc3 = RTRV(eif_new_type(938, 0x00),loc3);
				Result = (EIF_BOOLEAN) EIF_TEST(loc3);
				break;
			case 2U:
				loc4 = RTCCL(arg1);
				loc4 = RTRV(eif_new_type(935, 0x00),loc4);
				Result = (EIF_BOOLEAN) EIF_TEST(loc4);
				break;
			case 14U:
				loc5 = RTCCL(arg1);
				loc5 = RTRV(eif_new_type(932, 0x00),loc5);
				Result = (EIF_BOOLEAN) EIF_TEST(loc5);
				break;
			case 3U:
				loc6 = RTCCL(arg1);
				loc6 = RTRV(eif_new_type(929, 0x00),loc6);
				Result = (EIF_BOOLEAN) EIF_TEST(loc6);
				break;
			case 4U:
				loc7 = RTCCL(arg1);
				loc7 = RTRV(eif_new_type(926, 0x00),loc7);
				Result = (EIF_BOOLEAN) EIF_TEST(loc7);
				break;
			case 5U:
				loc8 = RTCCL(arg1);
				loc8 = RTRV(eif_new_type(941, 0x00),loc8);
				Result = (EIF_BOOLEAN) EIF_TEST(loc8);
				break;
			case 10U:
				loc9 = RTCCL(arg1);
				loc9 = RTRV(eif_new_type(923, 0x00),loc9);
				Result = (EIF_BOOLEAN) EIF_TEST(loc9);
				break;
			case 11U:
				loc10 = RTCCL(arg1);
				loc10 = RTRV(eif_new_type(920, 0x00),loc10);
				Result = (EIF_BOOLEAN) EIF_TEST(loc10);
				break;
			case 12U:
				loc11 = RTCCL(arg1);
				loc11 = RTRV(eif_new_type(917, 0x00),loc11);
				Result = (EIF_BOOLEAN) EIF_TEST(loc11);
				break;
			case 13U:
				loc12 = RTCCL(arg1);
				loc12 = RTRV(eif_new_type(914, 0x00),loc12);
				Result = (EIF_BOOLEAN) EIF_TEST(loc12);
				break;
			case 6U:
				loc13 = RTCCL(arg1);
				loc13 = RTRV(eif_new_type(911, 0x00),loc13);
				Result = (EIF_BOOLEAN) EIF_TEST(loc13);
				break;
			case 7U:
				loc14 = RTCCL(arg1);
				loc14 = RTRV(eif_new_type(908, 0x00),loc14);
				Result = (EIF_BOOLEAN) EIF_TEST(loc14);
				break;
			case 8U:
				loc15 = RTCCL(arg1);
				loc15 = RTRV(eif_new_type(905, 0x00),loc15);
				Result = (EIF_BOOLEAN) EIF_TEST(loc15);
				break;
			case 9U:
				loc16 = RTCCL(arg1);
				loc16 = RTRV(eif_new_type(902, 0x00),loc16);
				Result = (EIF_BOOLEAN) EIF_TEST(loc16);
				break;
			case 0U:
				loc1 = RTLNS(eif_new_type(240, 0x00).id, 240, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = RTCCL(arg1);
				loc2 = (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_dynamic_type__o_i4 (tr1);
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
				tr1 = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (tr1, arg2);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5881[Dtype(RTCW(tr1))-869])(tr1);
				Result = F241_4020(RTCW(loc1), loc2, ti4_1);
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
	return Result;
}

/* {TUPLE}.count */
EIF_INTEGER_32 F902_6902 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
	return Result;
}

/* {TUPLE}.lower */
EIF_INTEGER_32 F902_6903 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {TUPLE}.is_empty */
EIF_BOOLEAN F902_6905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {TUPLE}.put */
void F902_6906 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_64 tu8_1;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_INTEGER_16 ti2_1;
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,loc10);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc14);
	RTLR(16,tr1);
	RTLIU(17);
	
	RTGC;
	switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2)) {
		case 1U:
			loc1 = RTCCL(arg1);
			loc1 = RTRV(eif_new_type(938, 0x00),loc1);
			if (EIF_TEST(loc1)) {
				tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_boolean__b_i4_ (Current, tb1, arg2);
			}
			break;
		case 2U:
			loc2 = RTCCL(arg1);
			loc2 = RTRV(eif_new_type(935, 0x00),loc2);
			if (EIF_TEST(loc2)) {
				tc1 = *(EIF_CHARACTER_8 *)(loc2+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_character_8__c1_i4_ (Current, tc1, arg2);
			}
			break;
		case 14U:
			loc3 = RTCCL(arg1);
			loc3 = RTRV(eif_new_type(932, 0x00),loc3);
			if (EIF_TEST(loc3)) {
				tw1 = *(EIF_CHARACTER_32 *)(loc3+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_character_32__c4_i4_ (Current, tw1, arg2);
			}
			break;
		case 3U:
			loc4 = RTCCL(arg1);
			loc4 = RTRV(eif_new_type(929, 0x00),loc4);
			if (EIF_TEST(loc4)) {
				tr8_1 = *(EIF_REAL_64 *)(loc4+ _R64OFF_0_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_real_64__r8_i4_ (Current, tr8_1, arg2);
			}
			break;
		case 4U:
			loc5 = RTCCL(arg1);
			loc5 = RTRV(eif_new_type(926, 0x00),loc5);
			if (EIF_TEST(loc5)) {
				tr4_1 = *(EIF_REAL_32 *)(loc5+ _R32OFF_0_0_0_0_0_);
				eif_builtin_TUPLE_put_real_32__r4_i4_ (Current, tr4_1, arg2);
			}
			break;
		case 5U:
			loc6 = RTCCL(arg1);
			loc6 = RTRV(eif_new_type(941, 0x00),loc6);
			if (EIF_TEST(loc6)) {
				tp1 = *(EIF_POINTER *)(loc6+ _PTROFF_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_pointer__p_i4_ (Current, tp1, arg2);
			}
			break;
		case 10U:
			loc7 = RTCCL(arg1);
			loc7 = RTRV(eif_new_type(923, 0x00),loc7);
			if (EIF_TEST(loc7)) {
				tu1_1 = *(EIF_NATURAL_8 *)(loc7+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_natural_8__u1_i4_ (Current, tu1_1, arg2);
			}
			break;
		case 11U:
			loc8 = RTCCL(arg1);
			loc8 = RTRV(eif_new_type(920, 0x00),loc8);
			if (EIF_TEST(loc8)) {
				tu2_1 = *(EIF_NATURAL_16 *)(loc8+ _I16OFF_0_0_0_);
				eif_builtin_TUPLE_put_natural_16__u2_i4_ (Current, tu2_1, arg2);
			}
			break;
		case 12U:
			loc9 = RTCCL(arg1);
			loc9 = RTRV(eif_new_type(917, 0x00),loc9);
			if (EIF_TEST(loc9)) {
				tu4_1 = *(EIF_NATURAL_32 *)(loc9+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_natural_32__u4_i4_ (Current, tu4_1, arg2);
			}
			break;
		case 13U:
			loc10 = RTCCL(arg1);
			loc10 = RTRV(eif_new_type(914, 0x00),loc10);
			if (EIF_TEST(loc10)) {
				tu8_1 = *(EIF_NATURAL_64 *)(loc10+ _I64OFF_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_natural_64__u8_i4_ (Current, tu8_1, arg2);
			}
			break;
		case 6U:
			loc11 = RTCCL(arg1);
			loc11 = RTRV(eif_new_type(911, 0x00),loc11);
			if (EIF_TEST(loc11)) {
				ti1_1 = *(EIF_INTEGER_8 *)(loc11+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_integer_8__i1_i4_ (Current, ti1_1, arg2);
			}
			break;
		case 7U:
			loc12 = RTCCL(arg1);
			loc12 = RTRV(eif_new_type(908, 0x00),loc12);
			if (EIF_TEST(loc12)) {
				ti2_1 = *(EIF_INTEGER_16 *)(loc12+ _I16OFF_0_0_0_);
				eif_builtin_TUPLE_put_integer_16__i2_i4_ (Current, ti2_1, arg2);
			}
			break;
		case 8U:
			loc13 = RTCCL(arg1);
			loc13 = RTRV(eif_new_type(905, 0x00),loc13);
			if (EIF_TEST(loc13)) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc13+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_integer_32__i4_i4_ (Current, ti4_1, arg2);
			}
			break;
		case 9U:
			loc14 = RTCCL(arg1);
			loc14 = RTRV(eif_new_type(902, 0x00),loc14);
			if (EIF_TEST(loc14)) {
				ti8_1 = *(EIF_INTEGER_64 *)(loc14+ _I64OFF_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_integer_64__i8_i4_ (Current, ti8_1, arg2);
			}
			break;
		case 0U:
			tr1 = RTCCL(arg1);
			eif_builtin_TUPLE_put_reference__o_i4_ (Current, tr1, arg2);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
}

/* {TUPLE}.put_reference */
void F902_6907 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	eif_builtin_TUPLE_put_reference__o_i4_ (Current, arg1, arg2);
	RTLE;
}

/* {TUPLE}.put_boolean */
void F902_6908 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_boolean__b_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_character_8 */
void F902_6909 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_character_8__c1_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_character_32 */
void F902_6911 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_character_32__c4_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_real_64 */
void F902_6913 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_real_64__r8_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_real_32 */
void F902_6915 (EIF_REFERENCE Current, EIF_REAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_real_32__r4_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_pointer */
void F902_6917 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_pointer__p_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_natural_8 */
void F902_6918 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_natural_8__u1_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_natural_16 */
void F902_6919 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_natural_16__u2_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_natural_32 */
void F902_6920 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_natural_32__u4_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_natural_64 */
void F902_6921 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_natural_64__u8_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_integer_32 */
void F902_6922 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_integer_32__i4_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_integer */
void F902_6923 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_integer_32__i4_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_integer_8 */
void F902_6924 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_integer_8__i1_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_integer_16 */
void F902_6925 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_integer_16__i2_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.put_integer_64 */
void F902_6926 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	eif_builtin_TUPLE_put_integer_64__i8_i4_ (Current, arg1, arg2);
}

/* {TUPLE}.correct_mismatch */
void F902_6981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOUCR(3,F608_5024, (Current));
	tr2 = RTOUCR(4,F902_7001, (Current));
	tr1 = F610_5063(RTCW(tr1), tr2);
	loc4 = RTCCL(tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {785,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTRV(typres0,loc4);
	}
	if (EIF_TEST(loc4)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5002[Dtype(loc4)-785])(loc4);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4476[Dtype(loc4)-539])(loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			tr1 = RTCCL(loc3);
			if (F902_6901(Current, tr1, loc1)) {
				tr1 = RTCCL(loc3);
				F902_6906(Current, tr1, loc1);
			} else {
				F608_5023(Current);
			}
			loc1++;
		}
	} else {
		F608_5023(Current);
	}
	RTLE;
}

/* {TUPLE}.item_code */
EIF_NATURAL_8 F902_6982 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = (EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg1);
	return Result;
}

/* {TUPLE}.area_name */

EIF_REFERENCE F902_7001 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (4,RTMS_EX_H("area",4,1634887009));
}

/* {TUPLE}.internal_primes */
static EIF_REFERENCE F902_7003_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(678, 0x00).id, 678, _OBJSIZ_0_1_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F902_7003 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2,F902_7003_body,(Current));
}

/* {TUPLE}.set_object_comparison */
void F902_7004 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	eif_builtin_TUPLE_set_object_comparison__b_ (Current, arg1);
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
