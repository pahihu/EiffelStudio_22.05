/*
 * Code for class EV_ABSTRACT_PICK_AND_DROPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev300.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.init_drop_actions */
void F866_6753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc2 = F862_6671(Current);
	loc1 = RTOUCR(263,F866_6755, (Current));
	tr1 = F636_5308(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,901,612,907,907,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1267_90, (EIF_POINTER) _A1267_90, (EIF_POINTER)(F613_5103),tr2, 1, 0);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(tr1))-600])(tr1, tr3);
	tr1 = F636_5309(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,612,907,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1267_96, (EIF_POINTER) _A1267_96, (EIF_POINTER)(F613_5109),tr2, 1, 0);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(tr1))-600])(tr1, tr3);
	RTLE;
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.create_interface_objects */
void F866_6754 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (ANY.do_nothing) */
		tr1 = RTOUCR(263,F866_6755, (Current));
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.pnd_targets */
static EIF_REFERENCE F866_6755_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(263)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1130_10183(RTCW(tr1));
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_27_);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F866_6755 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(263,F866_6755_body,(Current));
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.default_pixmaps */
static EIF_REFERENCE F866_6756_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(51)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(23, 0x00).id, 23, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F866_6756 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(51,F866_6756_body,(Current));
}

void EIF_Minit300 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
