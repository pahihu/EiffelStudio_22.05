/*
 * Code for class EV_GTK_CALLBACK_MARSHAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev301.h"
#include <ev_any_imp.h>
#include <ev_gtk_callback_marshal.h>
#include "../C7/ev301.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F867_6772
static void inline_F867_6772 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	c_ev_gtk_callback_marshal_init ((EIF_REFERENCE) arg1, (void (*) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER, EIF_POINTER, EIF_POINTER)) arg2);
	;
}
#define INLINE_F867_6772
#endif
#ifndef INLINE_F867_6775
static void inline_F867_6775 (EIF_BOOLEAN arg1)
{
	c_ev_gtk_callback_marshal_set_is_enabled((int)arg1)
	;
}
#define INLINE_F867_6775
#endif
#ifndef INLINE_F97_1921
static void inline_F97_1921 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	g_value_set_boolean ((GValue*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F97_1921
#endif
#ifndef INLINE_F867_6774
static int inline_F867_6774 (void)
{
	return (int) ((EIF_BOOLEAN) c_ev_gtk_callback_marshal_is_enabled)
	;
}
#define INLINE_F867_6774
#endif
#ifndef INLINE_F867_6777
static EIF_INTEGER_32 inline_F867_6777 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_OBJECT arg3, EIF_BOOLEAN arg4)
{
	return (EIF_INTEGER_32) (c_ev_gtk_callback_marshal_signal_connect((gpointer) arg1, (gchar*) arg2, (EIF_OBJECT) arg3, (gboolean) arg4))
	;
}
#define INLINE_F867_6777
#endif
#ifndef INLINE_F867_6778
static EIF_NATURAL_32 inline_F867_6778 (EIF_INTEGER_32 arg1, EIF_OBJECT arg2)
{
	return (EIF_NATURAL_32) (c_ev_gtk_callback_marshal_timeout_connect((gint) arg1, (EIF_OBJECT) arg2))
	;
}
#define INLINE_F867_6778
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_CALLBACK_MARSHAL}.default_create */
void F867_6757 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTOUCP(203,F867_6758, (Current));
}

/* {EV_GTK_CALLBACK_MARSHAL}.initialize */
static void F867_6758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTOUDV(203)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	inline_F867_6772(Current, (EIF_POINTER) F867_6766);
	inline_F867_6775((EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
#undef Result
}

void F867_6758 (EIF_REFERENCE Current)
{
	GTCX
	RTOUCP(203,F867_6758_body,(Current));
}

/* {EV_GTK_CALLBACK_MARSHAL}.dimension_tuple */
EIF_REFERENCE F867_6759 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(204,F867_6767, (Current));
	
	eif_put_integer_32_item(RTCW(Result),1,arg1);
	
	eif_put_integer_32_item(RTCW(Result),2,arg2);
	
	eif_put_integer_32_item(RTCW(Result),3,arg3);
	
	eif_put_integer_32_item(RTCW(Result),4,arg4);
	RTLE;
	return Result;
}

/* {EV_GTK_CALLBACK_MARSHAL}.signal_connect */
void F867_6760 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = F867_6777(Current, arg1, tp1, arg3, arg4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_GTK_CALLBACK_MARSHAL}.signal_connect_after */
void F867_6761 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	F867_6760(Current, arg1, arg2, arg3, (EIF_BOOLEAN) 1);
}

/* {EV_GTK_CALLBACK_MARSHAL}.marshal */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F867_6766 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc12 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(12);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,loc7);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,loc9);
	RTLR(8,loc11);
	RTLR(9,loc2);
	RTLR(10,loc14);
	RTLR(11,saved_except);
	RTLIU(12);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		loc6 = arg1;
		{
			static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,1,901,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc6 = RTRV(typres0,loc6);
		}
		if (EIF_TEST(loc6)) {
			if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
				loc3 = RTOUCR(205,F867_6769, (Current));
				
				eif_put_pointer_item(RTCW(loc3),1,arg3);
			}
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6655[Dtype(RTCW(arg1))-975])(arg1, loc3);
		} else {
			loc7 = arg1;
			{
				static EIF_TYPE_INDEX typarr0[] = {978,0xFFF9,0,901,973,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc7 = RTRV(typres0,loc7);
			}
			if (EIF_TEST(loc7)) {
				if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
					loc3 = RTOUCR(205,F867_6769, (Current));
					
					eif_put_pointer_item(RTCW(loc3),1,arg3);
				}
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc7+ _PTROFF_4_2_0_3_0_2_))(
					*(EIF_POINTER *)(loc7+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(loc7 + _REFACS_1_), loc3);
				tp1 = tp1;
				loc4 = RTLNS(eif_new_type(973, 0x00).id, 973, _OBJSIZ_0_0_0_0_0_1_0_0_);
				*(EIF_POINTER *)loc4 = tp1;
				tr1 = RTCCL(loc4);
				RTOB(*(EIF_BOOLEAN *), eif_new_type(940, 0x00), tr1, loc8, tb1);
				if (tb1) {
					loc5 = (EIF_BOOLEAN) loc8;
				}
			} else {
				loc9 = arg1;
				{
					static EIF_TYPE_INDEX typarr0[] = {979,0xFFF9,1,901,973,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc9 = RTRV(typres0,loc9);
				}
				if (EIF_TEST(loc9)) {
					if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
						loc3 = RTOUCR(205,F867_6769, (Current));
						
						eif_put_pointer_item(RTCW(loc3),1,arg3);
					}
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc9+ _PTROFF_4_3_0_3_0_2_))(
						*(EIF_POINTER *)(loc9+ _PTROFF_4_3_0_3_0_1_),
						*(EIF_REFERENCE *)(loc9 + _REFACS_1_), loc3);
					tb1 = tb1;
					loc4 = RTLNS(eif_new_type(940, 0x00).id, 940, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_BOOLEAN *)loc4 = tb1;
					tr1 = RTCCL(loc4);
					RTOB(*(EIF_BOOLEAN *), eif_new_type(940, 0x00), tr1, loc10, tb1);
					if (tb1) {
						loc5 = (EIF_BOOLEAN) loc10;
					}
				} else {
					loc11 = arg1;
					{
						static EIF_TYPE_INDEX typarr0[] = {976,0xFFF9,0,901,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc11 = RTRV(typres0,loc11);
					}
					if (EIF_TEST(loc11)) {
						if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
							loc2 = RTOUCR(206,F867_6771, (Current));
							
							eif_put_integer_32_item(RTCW(loc2),1,arg2);
							
							eif_put_pointer_item(RTCW(loc2),2,arg3);
						}
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6680[Dtype(loc11)-976])(loc11, loc2);
						tr1 = RTCCL(loc4);
						RTOB(*(EIF_BOOLEAN *), eif_new_type(940, 0x00), tr1, loc12, tb1);
						if (tb1) {
							loc5 = (EIF_BOOLEAN) loc12;
						}
					} else {
						if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
							loc2 = RTOUCR(206,F867_6771, (Current));
							
							eif_put_integer_32_item(RTCW(loc2),1,arg2);
							
							eif_put_pointer_item(RTCW(loc2),2,arg3);
						}
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6655[Dtype(RTCW(arg1))-975])(arg1, loc2);
					}
				}
			}
		}
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(arg4 != tp1)) {
			inline_F97_1921(arg4, loc5);
		}
	} else {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
			RTCT0("attached {EV_APPLICATION_IMP} (create {EV_ENVIRONMENT}).implementation.application_i as app_imp", EX_CHECK);
			tr1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
			F1018_8683(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			tr1 = F1130_10183(RTCW(tr1));
			loc14 = tr1;
			loc14 = RTRV(eif_new_type(1136, 0x00),loc14);
			if (EIF_TEST(loc14)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = F1136_10434(loc14);
			F1136_10429(loc14, tr1);
		}
	}
	RTE_E
	RTXSC;
	loc1++;
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
		RTER;
	} else {
		tr1 = RTMS_EX_H("Error: An exception was raised when during handling of a previous exception\012",76,1274026506);
		F1_27(Current, tr1);
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_GTK_CALLBACK_MARSHAL}.internal_dimension_tuple */
static EIF_REFERENCE F867_6767_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(204)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,901,907,907,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 5, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F867_6767 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(204,F867_6767_body,(Current));
}

/* {EV_GTK_CALLBACK_MARSHAL}.pointer_tuple */
static EIF_REFERENCE F867_6769_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(205)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F867_6769 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(205,F867_6769_body,(Current));
}

/* {EV_GTK_CALLBACK_MARSHAL}.integer_pointer_tuple */
static EIF_REFERENCE F867_6771_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(206)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,907,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F867_6771 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(206,F867_6771_body,(Current));
}

/* {EV_GTK_CALLBACK_MARSHAL}.c_ev_gtk_callback_marshal_init */
void F867_6772 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F867_6772 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {EV_GTK_CALLBACK_MARSHAL}.c_ev_gtk_callback_marshal_is_enabled */
EIF_BOOLEAN F867_6774 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F867_6774 ());
	return Result;
}

/* {EV_GTK_CALLBACK_MARSHAL}.c_ev_gtk_callback_marshal_set_is_enabled */
void F867_6775 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	inline_F867_6775 ((EIF_BOOLEAN) arg1);
}

/* {EV_GTK_CALLBACK_MARSHAL}.set_eif_oid_in_c_object */
void F867_6776 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	set_eif_oid_in_c_object((arg1), (arg2), (arg3));
}

/* {EV_GTK_CALLBACK_MARSHAL}.c_signal_connect */
EIF_INTEGER_32 F867_6777 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg3);
	RTLIU(1);
	
	{
		EIF_POINTER larg1 = arg1;
		EIF_POINTER larg2 = arg2;
		EIF_OBJECT larg3 = &arg3;
		EIF_BOOLEAN larg4 = arg4;
		Result = inline_F867_6777 ((EIF_POINTER) larg1, (EIF_POINTER) larg2, (EIF_OBJECT) larg3, (EIF_BOOLEAN) larg4);
	}
	RTLE;
	return Result;
}

/* {EV_GTK_CALLBACK_MARSHAL}.c_ev_gtk_callback_marshal_timeout_connect */
EIF_NATURAL_32 F867_6778 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg2);
	RTLIU(1);
	
	{
		EIF_INTEGER_32 larg1 = arg1;
		EIF_OBJECT larg2 = &arg2;
		Result = inline_F867_6778 ((EIF_INTEGER_32) larg1, (EIF_OBJECT) larg2);
	}
	RTLE;
	return Result;
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
