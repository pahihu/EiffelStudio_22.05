/*
 * Code for class POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po345.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F974_8048 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F942_8022(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F974_8049 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F942_8027(Current);
}

/* {POINTER}.plus */
EIF_POINTER F974_8050 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F942_8028(Current, arg1);
}

/* {POINTER}.out */
EIF_REFERENCE F974_8052 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F942_8039(Current);
}

void EIF_Minit345 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
