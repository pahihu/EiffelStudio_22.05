
#ifndef _C7_ch339_
#define _C7_ch339_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F938_7998(EIF_REFERENCE);
extern EIF_CHARACTER_32 F938_7999(EIF_REFERENCE);
extern void EIF_Minit339(void);
extern EIF_NATURAL_32 F936_7952(EIF_REFERENCE);
extern EIF_CHARACTER_32 F936_7969(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
