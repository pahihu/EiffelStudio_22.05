
#ifndef _C15_dy712_
#define _C15_dy712_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F565_4918(EIF_REFERENCE);
extern void F565_4924(EIF_REFERENCE, EIF_REFERENCE);
extern void F565_4925(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit712(void);
extern char *(*R4446[])();
extern char *(*R4407[])();
extern char *(*R4413[])();
extern char *(*R4417[])();

#ifdef __cplusplus
}
#endif

#endif
