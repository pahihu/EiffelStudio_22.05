
#ifndef _C15_ar709_
#define _C15_ar709_

#ifdef __cplusplus
extern "C" {
#endif

extern void F757_5562(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F757_5563(EIF_REFERENCE);
extern EIF_REFERENCE F757_5564(EIF_REFERENCE);
extern EIF_REFERENCE F757_5566(EIF_REFERENCE);
extern EIF_INTEGER_32 F757_5567(EIF_REFERENCE);
extern void EIF_Minit709(void);
extern char *(*R4888[])();
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
