
#ifndef _C15_li716_
#define _C15_li716_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F577_4932(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F577_4933(EIF_REFERENCE);
extern EIF_BOOLEAN F577_4934(EIF_REFERENCE);
extern void EIF_Minit716(void);
extern char *(*R4441[])();
extern char *(*R4447[])();
extern char *(*R4449[])();
extern char *(*R4407[])();
extern char *(*R4296[])();
extern char *(*R4453[])();
extern char *(*R4414[])();
extern char *(*R4418[])();
extern char *(*R4420[])();
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
