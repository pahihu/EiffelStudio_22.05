
#ifndef _C15_dy735_
#define _C15_dy735_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F390_4664(EIF_REFERENCE);
extern void EIF_Minit735(void);

#ifdef __cplusplus
}
#endif

#endif
