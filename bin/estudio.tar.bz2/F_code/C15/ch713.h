
#ifndef _C15_ch713_
#define _C15_ch713_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F553_4894(EIF_REFERENCE);
extern EIF_REFERENCE F553_4895(EIF_REFERENCE);
extern EIF_BOOLEAN F553_4896(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F553_4898(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F553_4899(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F553_4901(EIF_REFERENCE);
extern void F553_4903(EIF_REFERENCE);
extern EIF_BOOLEAN F553_4906(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F553_4907(EIF_REFERENCE);
extern EIF_BOOLEAN F553_4909(EIF_REFERENCE);
extern void F553_4914(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit713(void);
extern EIF_BOOLEAN F325_4622(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4441[])();
extern char *(*R4447[])();
extern char *(*R4405[])();
extern char *(*R4449[])();
extern char *(*R4407[])();
extern char *(*R4296[])();
extern char *(*R4453[])();
extern char *(*R4414[])();
extern char *(*R4419[])();
extern char *(*R4566[])();
extern char *(*R4302[])();
extern char *(*R4420[])();
extern char *(*R4406[])();
extern char *(*R4423[])();
extern char *(*R4427[])();

#ifdef __cplusplus
}
#endif

#endif
