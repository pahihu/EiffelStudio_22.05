
#ifndef _C15_dy715_
#define _C15_dy715_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F391_4664(EIF_REFERENCE);
extern void EIF_Minit715(void);

#ifdef __cplusplus
}
#endif

#endif
