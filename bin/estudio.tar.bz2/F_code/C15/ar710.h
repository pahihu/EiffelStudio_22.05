
#ifndef _C15_ar710_
#define _C15_ar710_

#ifdef __cplusplus
extern "C" {
#endif

extern void F743_5544(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5545(EIF_REFERENCE);
extern EIF_REFERENCE F743_5546(EIF_REFERENCE);
extern EIF_REFERENCE F743_5548(EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5549(EIF_REFERENCE);
extern void EIF_Minit710(void);
extern char *(*R4880[])();
extern char *(*R4722[])();
extern char *(*R4726[])();
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
