
#ifndef _C15_re741_
#define _C15_re741_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F517_4760(EIF_REFERENCE);
extern void EIF_Minit741(void);
extern void F713_5490(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4862[])();
extern EIF_TYPE_INDEX Y4250[];
extern EIF_TYPE_INDEX *Y4250_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
