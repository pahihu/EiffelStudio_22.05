
#ifndef _C15_ge704_
#define _C15_ge704_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F731_5524(EIF_REFERENCE);
extern EIF_INTEGER_32 F731_5526(EIF_REFERENCE);
extern EIF_BOOLEAN F731_5533(EIF_REFERENCE);
extern void F731_5538(EIF_REFERENCE);
extern void F731_5539(EIF_REFERENCE);
extern EIF_REFERENCE F731_5540(EIF_REFERENCE);
extern void EIF_Minit704(void);
extern char *(*R4878[])();
extern char *(*R4851[])();
extern char *(*R4476[])();
extern long O4877[];
extern long O4879[];

#ifdef __cplusplus
}
#endif

#endif
