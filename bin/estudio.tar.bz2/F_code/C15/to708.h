
#ifndef _C15_to708_
#define _C15_to708_

#ifdef __cplusplus
extern "C" {
#endif

extern void F246_4176(EIF_REFERENCE, EIF_INTEGER_32);
extern void F246_4177(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F246_4183(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit708(void);
extern char *(*R5006[])();
extern EIF_TYPE_INDEX Y4046[];
extern EIF_TYPE_INDEX *Y4046_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
