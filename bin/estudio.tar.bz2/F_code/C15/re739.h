
#ifndef _C15_re739_
#define _C15_re739_

#ifdef __cplusplus
extern "C" {
#endif

extern void F713_5490(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F713_5492(EIF_REFERENCE);
extern EIF_INTEGER_32 F713_5493(EIF_REFERENCE);
extern EIF_INTEGER_32 F713_5494(EIF_REFERENCE);
extern EIF_INTEGER_32 F713_5495(EIF_REFERENCE);
extern EIF_REFERENCE F713_5496(EIF_REFERENCE);
extern EIF_BOOLEAN F713_5502(EIF_REFERENCE);
extern EIF_BOOLEAN F713_5503(EIF_REFERENCE);
extern EIF_BOOLEAN F713_5504(EIF_REFERENCE);
extern void F713_5509(EIF_REFERENCE);
extern void F713_5510(EIF_REFERENCE);
extern EIF_REFERENCE F713_5511(EIF_REFERENCE);
extern void EIF_Minit739(void);
extern char *(*R4480[])();
extern char *(*R4477[])();
extern char *(*R4478[])();

#ifdef __cplusplus
}
#endif

#endif
