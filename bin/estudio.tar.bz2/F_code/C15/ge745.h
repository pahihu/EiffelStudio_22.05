
#ifndef _C15_ge745_
#define _C15_ge745_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F732_5524(EIF_REFERENCE);
extern EIF_INTEGER_32 F732_5526(EIF_REFERENCE);
extern EIF_BOOLEAN F732_5533(EIF_REFERENCE);
extern void F732_5538(EIF_REFERENCE);
extern void F732_5539(EIF_REFERENCE);
extern EIF_REFERENCE F732_5540(EIF_REFERENCE);
extern void EIF_Minit745(void);
extern char *(*R4878[])();
extern char *(*R4851[])();
extern long O4877[];
extern long O4879[];

#ifdef __cplusplus
}
#endif

#endif
