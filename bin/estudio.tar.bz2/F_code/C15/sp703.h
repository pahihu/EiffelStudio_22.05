
#ifndef _C15_sp703_
#define _C15_sp703_

#ifdef __cplusplus
extern "C" {
#endif

extern void F769_5568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F769_5569(EIF_REFERENCE);
extern EIF_REFERENCE F769_5570(EIF_REFERENCE);
extern EIF_INTEGER_32 F769_5571(EIF_REFERENCE);
extern void EIF_Minit703(void);
extern char *(*R4891[])();
extern char *(*R4478[])();
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
