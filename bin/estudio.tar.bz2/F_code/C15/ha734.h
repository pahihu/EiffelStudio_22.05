
#ifndef _C15_ha734_
#define _C15_ha734_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F725_5518(EIF_REFERENCE);
extern EIF_REFERENCE F725_5519(EIF_REFERENCE);
extern EIF_BOOLEAN F725_5521(EIF_REFERENCE);
extern void F725_5522(EIF_REFERENCE);
extern EIF_REFERENCE F725_5523(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern char *(*R4645[])();
extern char *(*R4646[])();
extern char *(*R5002[])();
extern char *(*R4859[])();
extern char *(*R4476[])();
extern long O4654[];
extern long O4655[];

#ifdef __cplusplus
}
#endif

#endif
