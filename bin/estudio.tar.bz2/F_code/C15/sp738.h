
#ifndef _C15_sp738_
#define _C15_sp738_

#ifdef __cplusplus
extern "C" {
#endif

extern void F770_5568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F770_5569(EIF_REFERENCE);
extern EIF_REFERENCE F770_5570(EIF_REFERENCE);
extern EIF_INTEGER_32 F770_5571(EIF_REFERENCE);
extern void EIF_Minit738(void);
extern EIF_INTEGER_32 F787_5702(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
