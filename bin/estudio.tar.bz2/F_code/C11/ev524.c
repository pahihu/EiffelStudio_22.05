/*
 * Code for class EV_SENSITIVE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev524.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_IMP}.is_sensitive */
EIF_BOOLEAN F1164_10980 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_IMP}.has_parent */
EIF_BOOLEAN F1164_10984 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8795[Dtype(Current)-1197])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTLE;
	return Result;
}

/* {EV_SENSITIVE_IMP}.parent_is_sensitive */
EIF_BOOLEAN F1164_10986 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8795[Dtype(Current)-1197])(Current);
	loc1 = RTRV(eif_new_type(1056, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = F1057_9271(RTCW(loc1));
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit524 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
