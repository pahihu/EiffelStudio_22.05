
#ifndef _C11_ev502_
#define _C11_ev502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1138_10600(EIF_REFERENCE);
extern void EIF_Minit502(void);
extern EIF_REFERENCE F1114_9915(EIF_REFERENCE);
extern EIF_BOOLEAN F1114_9914(EIF_REFERENCE);
extern void F637_5325(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
