/*
 * Code for class EV_ANY_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev505.h"
#include <ev_any_imp.h>
#include "eif_built_in.h"
#include <ev_gtk_callback_marshal.h>
#include <ev_gtk.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F96_1382
static EIF_POINTER inline_F96_1382 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F96_1382
#endif
#ifndef INLINE_F96_1381
static int inline_F96_1381 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F96_1381
#endif
#ifndef INLINE_F96_1383
static EIF_POINTER inline_F96_1383 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F96_1383
#endif
#ifndef INLINE_F99_2152
static int inline_F99_2152 (EIF_POINTER arg1)
{
	return (int) (GTK_IS_WIDGET(arg1))
	;
}
#define INLINE_F99_2152
#endif
#ifndef INLINE_F96_1380
static EIF_NATURAL_32 inline_F96_1380 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F96_1380
#endif
#ifndef INLINE_F1141_10624
static EIF_REFERENCE inline_F1141_10624 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1141_10624
#endif
#ifndef INLINE_F97_1768
static void inline_F97_1768 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F97_1768
#endif
#ifndef INLINE_F867_6774
static int inline_F867_6774 (void)
{
	return (int) ((EIF_BOOLEAN) c_ev_gtk_callback_marshal_is_enabled)
	;
}
#define INLINE_F867_6774
#endif
#ifndef INLINE_F867_6775
static void inline_F867_6775 (EIF_BOOLEAN arg1)
{
	c_ev_gtk_callback_marshal_set_is_enabled((int)arg1)
	;
}
#define INLINE_F867_6775
#endif
#ifndef INLINE_F96_1387
static void inline_F96_1387 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F96_1387
#endif
#ifndef INLINE_F96_1384
static void inline_F96_1384 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F96_1384
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY_IMP}.c_object */
EIF_POINTER F1141_10620 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
}


/* {EV_ANY_IMP}.set_c_object */
void F1141_10622 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8510[dtype-1143])(Current)) {
		loc1 = (EIF_POINTER) gtk_event_box_new();
		tp1 = inline_F96_1382(loc1);
		loc1 = (EIF_POINTER) tp1;
		gtk_container_add((GtkContainer*) loc1, (GtkWidget*) arg1);
		gtk_widget_show((GtkWidget*) arg1);
	} else {
		if (EIF_TEST (inline_F96_1381(arg1))) {
			*(EIF_BOOLEAN *)(Current + O8498[dtype-1140]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = inline_F96_1382(arg1);
		} else {
			loc1 = (EIF_POINTER) arg1;
			tp1 = inline_F96_1383(loc1);
			loc1 = (EIF_POINTER) tp1;
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5720[dtype-861]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_IDENTIFIED_ROUTINES_eif_current_object_id__i4 (Current);
		*(EIF_INTEGER_32 *)(Current + O5720[dtype-861]) = (EIF_INTEGER_32) ti4_1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5720[dtype-861]);
	set_eif_oid_in_c_object((loc1), (ti4_1), ((EIF_POINTER) A505_84));
	*(EIF_POINTER *)(Current + O8497[dtype-1140]) = (EIF_POINTER) loc1;
	tb1 = '\0';
	if (EIF_TEST (inline_F99_2152(loc1))) {
		tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN)(inline_F96_1380(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L))) {
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tu4_1 = inline_F96_1380(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" /= 2 !\012",8,1002112522);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr1 = RTLNS(eif_new_type(95, 0x00).id, 95, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F96_1378(RTCW(tr1), tr2);
		}
	} else {
		if ((EIF_BOOLEAN)(inline_F96_1380(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tu4_1 = inline_F96_1380(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" /= 1 !\012",8,985335306);
			tr2 = F989_8535(RTCW(tr2), tr3);
			tr1 = RTLNS(eif_new_type(95, 0x00).id, 95, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F96_1378(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {EV_ANY_IMP}.update_gtk_name */
void F1141_10623 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	
	
	RTGC;
}

/* {EV_ANY_IMP}.eif_object_from_c */
EIF_REFERENCE F1141_10624 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	Result = inline_F1141_10624 ((EIF_POINTER) arg1);
	RTLE;
	return Result;
}

/* {EV_ANY_IMP}.destroy */
void F1141_10625 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1141_10632(Current, tp2);
	loc1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F99_2152(loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
			} else {
				inline_F97_1768(loc1);
			}
		} else {
			inline_F97_1768(loc1);
		}
	}
	F1114_9930(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_ANY_IMP}.real_signal_connect */
void F1141_10626 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOUCR(49,F1141_10647, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F849_5843(RTCW(tr2), arg2);
	F867_6760(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1141_10631(Current, arg1, arg2, ti4_1);
	RTLE;
}

/* {EV_ANY_IMP}.real_signal_connect_after */
void F1141_10627 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOUCR(49,F1141_10647, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = F1137_10585(RTCW(loc1), arg2);
	F867_6760(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1141_10631(Current, arg1, arg2, ti4_1);
	RTLE;
}

/* {EV_ANY_IMP}.record_signal_connection */
void F1141_10631 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_REFERENCE *)(Current + O8509[dtype-1140]);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			{
				EIF_TYPE_INDEX typarr0[] = {618,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					static EIF_TYPE_INDEX typarr2[] = {576,845,0xFFFF};
					EIF_TYPE typres2;
					static EIF_TYPE typcache2 = {INVALID_DTYPE, 0};
					
					typres2 = (typcache2.id != INVALID_DTYPE ? typcache2 : (typcache2 = eif_compound_id(Dftype(Current), typarr2)));
					l_type = eif_final_id(Y4441,Y4441_gen_type,typres2.id,405);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				loc1 = RTLNS(typres0.id, 618, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F619_5188(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O8509[dtype-1140]) = (EIF_REFERENCE) loc1;
		}
		tr1 = RTLNS(eif_new_type(845, 0x00).id, 845, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F846_5812(RTCW(tr1), arg1, arg3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4462[Dtype(RTCW(loc1))-600])(loc1, tr1);
	}
	RTLE;
}

/* {EV_ANY_IMP}.disconnect_all_recorded_connections */
void F1141_10632 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8509[dtype-1140]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4407[Dtype(loc1)-600])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4406[Dtype(loc1)-600])(loc1);
			if (tb1) break;
			tb2 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4441[Dtype(loc1)-600])(loc1);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tb3 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_0_0_);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\01';
				tb3 = !arg1;
				if (!tb3) {
					tp1 = *(EIF_POINTER *)(loc2+ _PTROFF_0_1_0_1_0_0_);
					tb2 = (EIF_BOOLEAN)(tp1 == arg1);
				}
				if (tb2) {
					F846_5815(loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4446[Dtype(loc1)-600])(loc1);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4420[Dtype(loc1)-600])(loc1);
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4446[Dtype(loc1)-600])(loc1);
			}
		}
		tb2 = F445_4698(loc1);
		if (tb2) {
			*(EIF_REFERENCE *)(Current + O8509[dtype-1140]) = (EIF_REFERENCE) NULL;
		} else {
			{
				/* INLINED CODE (ANY.do_nothing) */
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
}

/* {EV_ANY_IMP}.needs_event_box */
EIF_BOOLEAN F1141_10634 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.dispose */
void F1141_10636 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F99_2152(loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			inline_F97_1768(loc1);
		} else {
			inline_F97_1768(loc1);
		}
	}
	F862_6677(Current);
	RTLE;
}

/* {EV_ANY_IMP}.c_object_dispose */
void F1141_10637 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8511[dtype-1140])) {
		*(EIF_BOOLEAN *)(Current + O8511[dtype-1140]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = EIF_TEST (inline_F867_6774());
		inline_F867_6775((EIF_BOOLEAN) 0);
		loc1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
				inline_F97_1768(loc1);
			} else {
				if (EIF_TEST (inline_F99_2152(loc1))) {
					inline_F97_1768(loc1);
				} else {
					inline_F96_1387(loc1);
				}
			}
			inline_F96_1384(loc1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current + O8497[dtype-1140]) = (EIF_POINTER) tp2;
		}
		F1114_9930(Current, (EIF_BOOLEAN) 1);
		inline_F867_6775(loc2);
	}
	RTLE;
}

/* {EV_ANY_IMP}.process_draw_event */
EIF_BOOLEAN F1141_10638 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_configure_event */
EIF_BOOLEAN F1141_10640 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_button_event */
void F1141_10643 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ANY_IMP}.process_scroll_event */
EIF_BOOLEAN F1141_10645 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.visual_widget */
EIF_POINTER F1141_10646 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8510[dtype-1143])(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		RTLE;
		return (EIF_POINTER) (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	} else {
		RTLE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	}/* NOTREACHED */
	
}

/* {EV_ANY_IMP}.app_implementation */
static EIF_REFERENCE F1141_10647_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(49)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	loc1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(loc1));
	RTCT0("attached {EV_APPLICATION_IMP} env.implementation.application_i as l_app_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	tr1 = F1130_10183(RTCW(tr1));
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1136, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1141_10647 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(49,F1141_10647_body,(Current));
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
