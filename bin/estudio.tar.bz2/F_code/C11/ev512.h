
#ifndef _C11_ev512_
#define _C11_ev512_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1152_10825(EIF_REFERENCE);
extern EIF_REFERENCE F1152_10826(EIF_REFERENCE);
extern void EIF_Minit512(void);
extern char *(*R8674[])();
extern char *(*R8675[])();

#ifdef __cplusplus
}
#endif

#endif
