/*
 * Code for class EV_WIDGET_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_I}.internal_pointer_style */
EIF_REFERENCE F1184_11176 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + O8544[Dtype(Current)-1141]);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc1 = Current;
		loc1 = RTRV(eif_new_type(1084, 0x00), loc1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			Result = RTOUCR(270,F24_524, (RTCV(RTOUCR(274,F136_2893, (Current)))));
		} else {
			Result = RTOUCR(269,F24_521, (RTCV(RTOUCR(274,F136_2893, (Current)))));
		}
	} else {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_I}.disable_default_processing_on_key */
EIF_BOOLEAN F1184_11201 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8937[Dtype(Current)-1183]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc1+ _PTROFF_4_3_0_3_0_0_))(
			*(EIF_POINTER *)(loc1+ _PTROFF_4_3_0_3_0_1_),
			*(EIF_REFERENCE *)(loc1 + _REFACS_1_), arg1);
		tb1 = tb1;
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
