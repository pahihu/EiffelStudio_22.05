/*
 * Code for class EV_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev545.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F99_2187
static void inline_F99_2187 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F99_2187
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_IMP}.make */
void F1185_11206 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1142_10649(Current);
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	gtk_widget_set_redraw_on_allocate((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	F1114_9929(Current, (EIF_BOOLEAN) 1);
	F1185_11211(Current, *(EIF_POINTER *)(Current + O8497[dtype-1140]));
	F1185_11212(Current, *(EIF_POINTER *)(Current + O8497[dtype-1140]));
	RTLE;
}

/* {EV_WIDGET_IMP}.init_file_drop_actions */
void F1185_11210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_WIDGET_IMP}.init_gtk_allocate_event_signal_connection */
void F1185_11211 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((arg1)))) {
		loc1 = RTOUCR(49,F1141_10647, (Current));
		tr1 = RTOUCR(291,F18_425, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,866,907,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O5720[Dtype(Current)-861]);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,1,901,973,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A301_333_3, (EIF_POINTER) _A301_333_3, (EIF_POINTER)(F865_6729),tr2, 1, 1);
		}
		F1141_10626(Current, arg1, tr1, tr5);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.init_gtk_mapping_signal_connection */
void F1185_11212 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOUCR(49,F1141_10647, (Current));
	tr1 = RTOUCR(288,F18_419, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,866,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A301_326, (EIF_POINTER) _A301_326, (EIF_POINTER)(F865_6722),tr2, 1, 0);
	}
	F1141_10627(Current, arg1, tr1, tr3);
	tr1 = RTOUCR(289,F18_420, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,866,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A301_327, (EIF_POINTER) _A301_327, (EIF_POINTER)(F865_6723),tr2, 1, 0);
	}
	F1141_10627(Current, arg1, tr1, tr3);
	tr1 = RTOUCR(290,F18_421, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,866,973,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A301_328, (EIF_POINTER) _A301_328, (EIF_POINTER)(F865_6724),tr2, 1, 0);
	}
	F1141_10627(Current, arg1, tr1, tr3);
	RTLE;
}

/* {EV_WIDGET_IMP}.on_key_event */
void F1185_11213 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	if (arg3) {
		tr1 = *(EIF_REFERENCE *)(Current + O2798[dtype-127]);
		loc1 = tr1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1287,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			F637_5325(loc1, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2800[dtype-127]);
		loc2 = tr1;
		if ((EIF_BOOLEAN) (EIF_TEST(loc2) && (EIF_BOOLEAN)(arg2 != NULL))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,987,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg2;
			RTAR(tr1,arg2);
			(RTNA((loc2, tr1)));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O2802[dtype-127]);
		loc3 = tr1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc3))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1287,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			F637_5325(loc3, tr1);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_size_allocate */
void F1185_11214 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O8984[dtype-1184]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	if (!(EIF_BOOLEAN)(arg3 != ti4_1)) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8985[dtype-1184]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb1 = (EIF_BOOLEAN)(arg4 != ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8979[Dtype(loc5)-1197])(loc5);
		}
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - loc1);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - loc1);
		ti2_1 = (EIF_INTEGER_16) arg3;
		*(EIF_INTEGER_16 *)(Current + O8984[dtype-1184]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg4;
		*(EIF_INTEGER_16 *)(Current + O8985[dtype-1184]) = (EIF_INTEGER_16) ti2_1;
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O2809[dtype-127]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tb2 = F445_4698(loc6);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_42_);
			tr1 = F867_6759(RTCW(tr1), loc2, loc3, arg3, arg4);
			F637_5325(loc6, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9022[Dtype(loc7)-1197])(loc7, Current);
		}
	} else {
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_focus_changed */
void F1185_11215 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if (arg1) {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_17_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F103_2504(RTCV(RTOUCR(49,F1141_10647, (Current))));
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1114_9915(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2804[dtype-127]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F637_5325(loc1, NULL);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_18_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F103_2506(RTCV(RTOUCR(49,F1141_10647, (Current))));
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1114_9915(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2806[dtype-127]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F637_5325(loc2, NULL);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_pointer_enter_leave */
void F1185_11216 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if (arg1) {
		tr1 = *(EIF_REFERENCE *)(Current + O2792[dtype-127]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F637_5325(loc1, NULL);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O2796[dtype-127]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F637_5325(loc2, NULL);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.call_button_event_actions */
void F1185_11217 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 9, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg2;
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg3;
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg4;
	((EIF_TYPED_VALUE *)tr1+4)->it_r8 = arg5;
	((EIF_TYPED_VALUE *)tr1+5)->it_r8 = arg6;
	((EIF_TYPED_VALUE *)tr1+6)->it_r8 = arg7;
	((EIF_TYPED_VALUE *)tr1+7)->it_i4 = arg8;
	((EIF_TYPED_VALUE *)tr1+8)->it_i4 = arg9;
	loc1 = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg1 != (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
		if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_3BUTTON_PRESS)) {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 4L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)))) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_13_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F103_2496(RTCV(RTOUCR(49,F1141_10647, (Current))));
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,0,0,907,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 3, 0);
				}
				tr3 = F1114_9915(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O2794[dtype-127]);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,907,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 2, 1);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc2;
				(RTNA((loc3, tr1)));
			}
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 5L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)))) {
				tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_13_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = F103_2496(RTCV(RTOUCR(49,F1141_10647, (Current))));
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,0,0,907,0xFFFF};
						EIF_TYPE typres0;
						{
							EIF_TYPE l_type;
							l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
							typarr0[3] = l_type.annotations | 0xFF00;
							typarr0[4] = l_type.id;
						}
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1114_9915(Current);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_i4 = (EIF_INTEGER_32) -loc2;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
				}
				tr1 = *(EIF_REFERENCE *)(Current + O2794[dtype-127]);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,907,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNTS(typres0.id, 2, 1);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_i4 = (EIF_INTEGER_32) -loc2;
					(RTNA((loc4, tr1)));
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)))) {
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
				tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_10_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = F103_2490(RTCV(RTOUCR(49,F1141_10647, (Current))));
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,901,0,0,907,907,907,0xFFFF};
						EIF_TYPE typres0;
						{
							EIF_TYPE l_type;
							l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
							typarr0[3] = l_type.annotations | 0xFF00;
							typarr0[4] = l_type.id;
						}
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr2 = RTLNTS(typres0.id, 5, 0);
					}
					tr3 = F1114_9915(Current);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
					((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
					((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
				}
				tr1 = *(EIF_REFERENCE *)(Current + O2786[dtype-127]);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					F637_5325(loc5, loc1);
				}
			} else {
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
					tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_11_);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						tr1 = F103_2492(RTCV(RTOUCR(49,F1141_10647, (Current))));
						{
							EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,901,0,0,907,907,907,0xFFFF};
							EIF_TYPE typres0;
							{
								EIF_TYPE l_type;
								l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
								typarr0[3] = l_type.annotations | 0xFF00;
								typarr0[4] = l_type.id;
							}
							
							typres0 = eif_compound_id(dftype, typarr0);
							tr2 = RTLNTS(typres0.id, 5, 0);
						}
						tr3 = F1114_9915(Current);
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
						((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
						((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
					}
					tr1 = *(EIF_REFERENCE *)(Current + O2788[dtype-127]);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						F637_5325(loc6, loc1);
					}
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)))) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_12_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F103_2494(RTCV(RTOUCR(49,F1141_10647, (Current))));
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,901,0,0,907,907,907,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y7965,Y7965_gen_type,dftype,1113);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 5, 0);
				}
				tr3 = F1114_9915(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
				((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
				((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O2790[dtype-127]);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				F637_5325(loc7, loc1);
			}
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.parent */
EIF_REFERENCE F1185_11218 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8975[Dtype(Current)-1184]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7965[Dtype(loc1)-1113]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_WIDGET_IMP}.width */
EIF_INTEGER_32 F1185_11224 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1142_10674(Current);
	if ((EIF_BOOLEAN) !F1142_10678(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8967[dtype-1184]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8967[dtype-1184]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.height */
EIF_INTEGER_32 F1185_11225 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1142_10675(Current);
	if ((EIF_BOOLEAN) !F1142_10678(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8968[dtype-1184]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8968[dtype-1184]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1185_11226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1142_10657(Current);
	if ((EIF_BOOLEAN) !F1142_10678(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8969[dtype-1184]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8969[dtype-1184]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1185_11227 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1142_10658(Current);
	if ((EIF_BOOLEAN) !F1142_10678(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8970[dtype-1184]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8970[dtype-1184]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.set_minimum_width */
void F1185_11228 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8532[dtype-1143])(Current);
	tr1 = RTLNS(eif_new_type(96, 0x00).id, 96, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F97_1803(RTCW(tr1), tp1, arg1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1209, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1142_10661(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		F1202_11436(loc2, ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1192, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1142_10661(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			(RTNA((loc3, F1114_9915(Current), ti4_1)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.set_minimum_height */
void F1185_11229 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8531[dtype-1143])(Current);
	tr1 = RTLNS(eif_new_type(96, 0x00).id, 96, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F97_1803(RTCW(tr1), tp1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1209, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1142_10662(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		F1202_11437(loc2, ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1192, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1142_10662(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			(RTNA((loc3, F1114_9915(Current), ti4_1)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.set_minimum_size */
void F1185_11230 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(96, 0x00).id, 96, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F97_1803(RTCW(tr1), *(EIF_POINTER *)(Current + O8497[dtype-1140]), arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1209, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1142_10661(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		ti4_2 = F1142_10662(Current);
		ti4_2 = eif_max_int32 (arg2,ti4_2);
		F1210_11558(loc2, ti4_1, ti4_2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1192, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1142_10661(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			ti4_2 = F1142_10662(Current);
			ti4_2 = eif_max_int32 (arg2,ti4_2);
			(RTNA((loc3, F1114_9915(Current), ti4_1, ti4_2)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.refresh_now */
void F1185_11238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1) != tp2)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		inline_F99_2187(tp1);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.process_pending_events */
void F1185_11239 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1137_10480(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_WIDGET_IMP}.set_parent_imp */
void F1185_11240 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O8975[Dtype(Current)-1184]) = (EIF_REFERENCE) arg1;
}

/* {EV_WIDGET_IMP}.destroy */
void F1185_11241 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		loc1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			gdk_window_set_cursor((GdkWindow*) loc1, (GdkCursor*) tp2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O8975[dtype-1184]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1114_9915(loc2);
			tr2 = F1114_9915(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4430[Dtype(RTCW(tr1))-539])(tr1, tr2);
		}
		F1141_10625(Current);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_widget_mapped */
void F1185_11243 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8544[dtype-1141]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8543[dtype-1141]) != loc1))) {
		F1142_10668(Current, loc1);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_widget_unmapped */
void F1185_11244 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O8543[Dtype(Current)-1141]) = (EIF_REFERENCE) NULL;
}

/* {EV_WIDGET_IMP}.on_widget_hidden */
void F1185_11245 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O8543[Dtype(Current)-1141]) = (EIF_REFERENCE) NULL;
}

/* {EV_WIDGET_IMP}.internal_x_y_offset */
EIF_INTEGER_32 F1185_11246 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {EV_WIDGET_IMP}.propagate_foreground_color_internal */
void F1185_11247 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((arg2)))) {
		loc3 = (EIF_REFERENCE) arg1;
		loc4 = (EIF_POINTER) gtk_container_get_children((GtkContainer*) arg2);
		loc1 = (EIF_POINTER) loc4;
		for (;;) {
			tb1 = !loc1;
			if (tb1) break;
			loc2 = (EIF_POINTER) (((GList *)loc1)->data);
			F1153_10839(Current, loc2, loc3);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((loc2)))) {
				F1185_11247(Current, loc3, loc2);
			}
			tp1 = (EIF_POINTER) (((GList *)loc1)->next);
			loc1 = (EIF_POINTER) tp1;
		}
		g_list_free((GList*) loc4);
	} else {
		F1153_10839(Current, arg2, loc3);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.propagate_background_color_internal */
void F1185_11248 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((arg2)))) {
		loc3 = (EIF_REFERENCE) arg1;
		loc4 = (EIF_POINTER) gtk_container_get_children((GtkContainer*) arg2);
		loc1 = (EIF_POINTER) loc4;
		for (;;) {
			tb1 = !loc1;
			if (tb1) break;
			loc2 = (EIF_POINTER) (((GList *)loc1)->data);
			F1153_10837(Current, loc2, loc3);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_CONTAINER((loc2)))) {
				F1185_11248(Current, loc3, loc2);
			}
			tp1 = (EIF_POINTER) (((GList *)loc1)->next);
			loc1 = (EIF_POINTER) tp1;
		}
		g_list_free((GList*) loc4);
	} else {
		F1153_10837(Current, arg2, loc3);
	}
	RTLE;
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
