/*
 * Code for class EV_WIDGET_LIST_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_LIST_I}.update_for_pick_and_drop */
void F1188_11310 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1145_10764(Current);
	F1145_10774(Current);
	for (;;) {
		if (F1145_10767(Current)) break;
		tr1 = F1145_10762(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O7088[Dtype(tr1)-1017]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R8959[Dtype(RTCW(tr1))-1197])(tr1, arg1);
		F1145_10776(Current);
	}
	F1145_10778(Current, loc1);
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
