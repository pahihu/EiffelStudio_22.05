
#ifndef _C11_ev546_
#define _C11_ev546_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1186_11254(EIF_REFERENCE);
extern void F1186_11265(EIF_REFERENCE);
extern void F1186_11266(EIF_REFERENCE);
extern void EIF_Minit546(void);
extern EIF_REFERENCE F1114_9915(EIF_REFERENCE);
extern void F1059_9328(EIF_REFERENCE);
extern void F1059_9327(EIF_REFERENCE);
extern EIF_REFERENCE F1152_10826(EIF_REFERENCE);
extern EIF_REFERENCE F1152_10825(EIF_REFERENCE);
extern char *(*R4447[])();
extern char *(*R4405[])();
extern char *(*R4406[])();
extern char *(*R4407[])();
extern char *(*R8989[])();
extern char *(*R7333[])();
extern char *(*R4302[])();
extern char *(*R4420[])();
extern char *(*R7332[])();
extern char *(*R4449[])();

#ifdef __cplusplus
}
#endif

#endif
