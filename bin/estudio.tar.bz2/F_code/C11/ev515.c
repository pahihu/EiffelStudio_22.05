/*
 * Code for class EV_DOCKABLE_SOURCE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev515.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable_filter */
void F1155_10894 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8734[dtype-1154])) {
		tr1 = *(EIF_REFERENCE *)(Current + O8544[dtype-1141]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8741[dtype-1154]) = (EIF_REFERENCE) tr1;
		ti2_1 = (EIF_INTEGER_16) arg2;
		*(EIF_INTEGER_16 *)(Current + O2877[dtype-135]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg3;
		*(EIF_INTEGER_16 *)(Current + O2878[dtype-135]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg8;
		*(EIF_INTEGER_16 *)(Current + O8735[dtype-1154]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg9;
		*(EIF_INTEGER_16 *)(Current + O8736[dtype-1154]) = (EIF_INTEGER_16) ti2_1;
		*(EIF_BOOLEAN *)(Current + O8734[dtype-1154]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.dragable_motion */
void F1155_10898 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O8734[dtype-1154])) {
		tb1 = '\01';
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8735[dtype-1154]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg6));
		if (!(EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O8736[dtype-1154]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg7));
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L));
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current + O8734[dtype-1154]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			F1155_10902(Current, arg1, arg2, ((EIF_INTEGER_32) 1L), arg3, arg4, arg5, arg6, arg7);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2877[dtype-135]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2878[dtype-135]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2877[dtype-135]);
			ti4_3 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2878[dtype-135]);
			ti4_4 = (EIF_INTEGER_32) ti2_1;
			F1155_10903(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_INTEGER_32) (arg6 + (EIF_INTEGER_32) (ti4_3 - arg1)), (EIF_INTEGER_32) (arg7 + (EIF_INTEGER_32) (ti4_4 - arg2)));
		}
	} else {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		F1154_10888(Current, arg1, arg2, tr8_1, tr8_2, (EIF_REAL_64) 0.5, arg6, arg7);
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable */
void F1155_10902 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1183_11148(Current);
	tr1 = RTOUCR(49,F1141_10647, (Current));
	F1137_10552(RTCW(tr1), Current);
	tr1 = F1114_9915(Current);
	F1154_10886(Current, arg7, arg8, tr1);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.real_start_dragging */
void F1155_10903 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(299,F1154_10881, (Current));
	F1142_10667(Current, tr1);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.end_dragable */
void F1155_10905 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1154_10860(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8741[Dtype(Current)-1154]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1142_10668(Current, loc1);
		} else {
			tr1 = RTOUCR(269,F24_521, (RTCV(RTOUCR(274,F136_2893, (Current)))));
			F1142_10668(Current, tr1);
		}
		F1183_11149(Current);
		tr1 = RTOUCR(49,F1141_10647, (Current));
		F1137_10552(RTCW(tr1), NULL);
		F1154_10879(Current);
	}
	F1155_10906(Current);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.reset_drag_data */
void F1155_10906 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8734[dtype-1154]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_16 *)(Current + O2877[dtype-135]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O2878[dtype-135]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O8735[dtype-1154]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O8736[dtype-1154]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_REFERENCE *)(Current + O8741[dtype-1154]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.update_buttons */
void F1155_10911 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit515 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
