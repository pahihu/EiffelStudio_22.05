/*
 * Code for class EV_GTK_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev506.h"
#include <string.h>
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F97_1806
static void inline_F97_1806 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F97_1806
#endif
#ifndef INLINE_F96_1384
static void inline_F96_1384 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F96_1384
#endif
#ifndef INLINE_F1141_10624
static EIF_REFERENCE inline_F1141_10624 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1141_10624
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WIDGET_IMP}.gdk_events_mask */
static EIF_INTEGER_32 F1142_10648_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 300)

	
	RTEV;
	RTGC;
	RTOTP;
	ti4_1 = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	Result = eif_bit_or(ti4_1,ti4_2);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1142_10648 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,300,F1142_10648_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.make */
void F1142_10649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8521[dtype-1143])(Current);
	loc2 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	ti4_1 = RTOUCB(EIF_INTEGER_32,300,F1142_10648, (Current));
	gtk_widget_add_events((GtkWidget*) loc1, (gint) ti4_1);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		ti4_1 = RTOUCB(EIF_INTEGER_32,300,F1142_10648, (Current));
		gtk_widget_add_events((GtkWidget*) loc2, (gint) ti4_1);
	}
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc2)))) {
		gtk_widget_realize((GtkWidget*) loc2);
	} else {
		gtk_widget_show((GtkWidget*) loc2);
	}
	F1114_9929(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.screen_x */
EIF_INTEGER_32 F1142_10650 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8521[dtype-1143])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) loc3);
		Result = (EIF_INTEGER_32) loc1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.screen_y */
EIF_INTEGER_32 F1142_10651 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8521[dtype-1143])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) loc3, (gint*) (EIF_INTEGER_32 *) &(loc1));
		Result = (EIF_INTEGER_32) loc1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1142_10654 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = F1137_10576(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
	return RTRV(eif_new_type(1184, 0x00), Result);
}

/* {EV_GTK_WIDGET_IMP}.minimum_width */
EIF_INTEGER_32 F1142_10655 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8531[Dtype(Current)-1143])(Current);
}

/* {EV_GTK_WIDGET_IMP}.minimum_height */
EIF_INTEGER_32 F1142_10656 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8532[Dtype(Current)-1143])(Current);
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1142_10657 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		Result = F1142_10659(Current);
		loc1 = F1142_10661(Current);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			Result = (EIF_INTEGER_32) loc1;
		}
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1142_10658 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		Result = F1142_10660(Current);
		loc1 = F1142_10662(Current);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			Result = (EIF_INTEGER_32) loc1;
		}
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.width_request */
EIF_INTEGER_32 F1142_10659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F97_1806(tp1, (EIF_INTEGER_32 *) &(Result), tp3);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.height_request */
EIF_INTEGER_32 F1142_10660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F97_1806(tp1, tp3, (EIF_INTEGER_32 *) &(Result));
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_width */
EIF_INTEGER_32 F1142_10661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCV(RTOUCR(301,F1142_10665, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->width);
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_height */
EIF_INTEGER_32 F1142_10662 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCV(RTOUCR(301,F1142_10665, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->height);
}

/* {EV_GTK_WIDGET_IMP}.reusable_requisition_struct */
static EIF_REFERENCE F1142_10665_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(301)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(852, 0x00).id, 852, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkRequisition);
	F853_5935(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1142_10665 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(301,F1142_10665_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.event_widget */
EIF_POINTER F1142_10666 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8521[dtype-1143])(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) loc1))) {
		RTLE;
		return (EIF_POINTER) loc1;
	} else {
		RTLE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WIDGET_IMP}.set_pointer_style */
void F1142_10667 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O8544[dtype-1141]))) {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current)) {
			F1142_10668(Current, arg1);
		}
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O8544[dtype-1141]) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_pointer_style */
void F1142_10668 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O8543[dtype-1141]))) {
		RTCT0("attached {EV_POINTER_STYLE_IMP} a_cursor.implementation as a_cursor_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1125, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		loc2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = F1126_10135(loc3);
			gdk_window_set_cursor((GdkWindow*) loc2, (GdkCursor*) loc1);
			inline_F96_1384(loc1);
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + O8543[dtype-1141]) = (EIF_REFERENCE) arg1;
		}
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.pointer_style */
EIF_REFERENCE F1142_10670 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8544[Dtype(Current)-1141]);
}


/* {EV_GTK_WIDGET_IMP}.set_focus */
void F1142_10671 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8547[dtype-1143])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8546[dtype-1143])(Current);
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_focus */
void F1142_10672 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc4 = RTOUCR(49,F1141_10647, (Current));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_29_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F1137_10559(RTCW(loc4));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc3 = F1114_9915(Current);
		if ((EIF_BOOLEAN)(loc3 != loc5)) {
			F1058_9295(loc5);
		}
	}
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
		loc1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8521[dtype-1143])(Current);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) loc2))) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			loc2 = tp1;
		}
	}
	gtk_window_set_focus((GtkWindow*) loc1, (GtkWidget*) loc2);
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) loc2));
	}
	if (tb1) {
		gtk_widget_grab_focus((GtkWidget*) loc2);
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.has_focus */
EIF_BOOLEAN F1142_10673 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1142_10683(Current, (EIF_BOOLEAN) 1);
}

/* {EV_GTK_WIDGET_IMP}.width */
EIF_INTEGER_32 F1142_10674 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8531[dtype-1143])(Current);
	tb1 = '\01';
	if (!F1142_10678(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		}
		free(loc3);
	}
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.height */
EIF_INTEGER_32 F1142_10675 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8532[dtype-1143])(Current);
	tb1 = '\01';
	if (!F1142_10678(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		}
		free(loc3);
	}
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.show */
void F1142_10677 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_widget_show((GtkWidget*) tp1);
}

/* {EV_GTK_WIDGET_IMP}.is_show_requested */
EIF_BOOLEAN F1142_10678 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) tp1));
}

/* {EV_GTK_WIDGET_IMP}.is_displayed */
EIF_BOOLEAN F1142_10679 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8497[dtype-1140]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
	}
	if (Result) {
		loc1 = F1142_10681(Current);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O8497[Dtype(loc1)-1140]);
			Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_gtk_window_imp */
EIF_REFERENCE F1142_10680 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNTY2(eif_new_type(1142, 0x00), 0x00);
		tr2 = inline_F1141_10624(loc1);
		Result = F870_6857(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window_imp */
EIF_REFERENCE F1142_10681 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNTY2(eif_new_type(1211, 0x00), 0x00);
	tr2 = F1142_10680(Current);
	Result = F870_6857(tr1, tr2);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window */
EIF_REFERENCE F1142_10682 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1142_10680(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1211, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7965[Dtype(loc1)-1113]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WIDGET_IMP}.has_focus_internal */
EIF_BOOLEAN F1142_10683 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	tb1 = '\0';
	tb2 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb2) {
		tb2 = '\01';
		if (arg1) {
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) loc1));
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) loc1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 != tp1)) {
			tr1 = RTOUCR(49,F1141_10647, (Current));
			loc3 = F1137_10575(RTCW(tr1), loc2);
			loc3 = RTRV(eif_new_type(1184, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == Current);
			}
		}
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
