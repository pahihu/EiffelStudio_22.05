/*
 * Code for class EV_DOCKABLE_SOURCE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev514.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_I}.is_dock_executing */
EIF_BOOLEAN F1154_10860 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2875[Dtype(Current)-135]) != NULL);
}

/* {EV_DOCKABLE_SOURCE_I}.is_dockable */
EIF_BOOLEAN F1154_10862 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O8702[Dtype(Current)-1153]);
}


/* {EV_DOCKABLE_SOURCE_I}.is_external_docking_enabled */
EIF_BOOLEAN F1154_10864 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8703[Dtype(Current)-1153]);
}

/* {EV_DOCKABLE_SOURCE_I}.is_external_docking_relative */
EIF_BOOLEAN F1154_10866 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8705[Dtype(Current)-1153]);
}

/* {EV_DOCKABLE_SOURCE_I}.get_next_target */
EIF_REFERENCE F1154_10867 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,Result);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	loc3 = F1058_9279(RTCW(arg1));
	loc1 = loc3;
	loc1 = RTRV(eif_new_type(1058, 0x00), loc1);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1040, 0x00), loc2);
	tb1 = '\0';
	tb2 = '\0';
	loc4 = loc3;
	if (EIF_TEST(loc4)) {
		tr1 = F1058_9283(loc4);
		loc5 = tr1;
		tb2 = EIF_TEST(loc5);
	}
	if (tb2) {
		tb2 = F1041_9050(loc5);
		tb1 = tb2;
	}
	if (tb1) {
		Result = (EIF_REFERENCE) loc5;
	} else {
		tb1 = '\0';
		loc6 = loc2;
		if (EIF_TEST(loc6)) {
			tb2 = F1041_9050(loc6);
			tb1 = tb2;
		}
		if (tb1) {
			Result = (EIF_REFERENCE) loc6;
		}
	}
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result != NULL) || (EIF_BOOLEAN)(loc1 == NULL))) break;
		loc3 = F1058_9279(RTCW(loc1));
		loc1 = loc3;
		loc1 = RTRV(eif_new_type(1058, 0x00), loc1);
		loc2 = loc1;
		loc2 = RTRV(eif_new_type(1040, 0x00), loc2);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = F1058_9283(RTCW(loc3));
			loc7 = tr1;
			tb2 = EIF_TEST(loc7);
		}
		if (tb2) {
			tb2 = F1041_9050(loc7);
			tb1 = tb2;
		}
		if (tb1) {
			Result = (EIF_REFERENCE) loc7;
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F1041_9050(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) {
				Result = (EIF_REFERENCE) loc2;
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.closest_dockable_target */
EIF_REFERENCE F1154_10868 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc5);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = F1142_10654(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + O7965[Dtype(loc1)-1113]);
		loc2 = RTRV(eif_new_type(1040, 0x00), loc2);
		loc3 = loc2;
		loc3 = RTRV(eif_new_type(1101, 0x00), loc3);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O8936[Dtype(loc1)-1183]);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tb2 = F1041_9050(loc4);
			tb1 = tb2;
		}
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc4;
		} else {
			tb1 = '\0';
			tb2 = '\0';
			loc5 = loc2;
			if (EIF_TEST(loc5)) {
				tb3 = F1041_9050(loc5);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tb2 = (EIF_BOOLEAN)(F1154_10883(Current) != NULL);
				}
				tb1 = tb2;
			}
			if (tb1) {
				RTLE;
				return (EIF_REFERENCE) loc2;
			} else {
				tr1 = F1114_9915(RTCW(loc1));
				Result = F1154_10867(Current, tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.complete_dock */
void F1154_10879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc25 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc26 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc41 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc42 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(40);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,loc29);
	RTLR(3,loc7);
	RTLR(4,loc30);
	RTLR(5,loc32);
	RTLR(6,tr1);
	RTLR(7,loc11);
	RTLR(8,loc14);
	RTLR(9,loc33);
	RTLR(10,loc31);
	RTLR(11,loc34);
	RTLR(12,loc5);
	RTLR(13,loc19);
	RTLR(14,loc13);
	RTLR(15,loc35);
	RTLR(16,loc12);
	RTLR(17,loc10);
	RTLR(18,loc6);
	RTLR(19,loc9);
	RTLR(20,loc3);
	RTLR(21,tr2);
	RTLR(22,tr3);
	RTLR(23,loc36);
	RTLR(24,loc1);
	RTLR(25,loc2);
	RTLR(26,loc37);
	RTLR(27,loc28);
	RTLR(28,loc38);
	RTLR(29,loc39);
	RTLR(30,loc40);
	RTLR(31,loc21);
	RTLR(32,loc24);
	RTLR(33,loc17);
	RTLR(34,loc16);
	RTLR(35,loc15);
	RTLR(36,loc41);
	RTLR(37,loc20);
	RTLR(38,loc42);
	RTLR(39,loc27);
	RTLIU(40);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + O2886[dtype-135]) = (EIF_REFERENCE) NULL;
	loc8 = F1154_10868(Current);
	loc29 = F1154_10882(Current);
	loc29 = RTRV(eif_new_type(1184, 0), loc29);
	if ((EIF_BOOLEAN)(loc29 != NULL)) {
		loc7 = F1185_11218(RTCW(loc29));
		loc7 = RTRV(eif_new_type(1072, 0x00), loc7);
	} else {
		loc30 = F1154_10883(Current);
		loc30 = RTRV(eif_new_type(1245, 0), loc30);
		RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc30 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9562[Dtype(RTCW(loc30))-1254])(loc30);
		loc32 = tr1;
		if (EIF_TEST(loc32)) {
			loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7271[Dtype(loc32)-1063])(loc32);
			loc7 = RTRV(eif_new_type(1072, 0x00), loc7);
		}
	}
	loc11 = loc8;
	loc11 = RTRV(eif_new_type(1101, 0x00), loc11);
	loc14 = loc8;
	loc14 = RTRV(eif_new_type(1058, 0x00), loc14);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc29 != NULL) && (EIF_BOOLEAN)(loc14 == NULL)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc30 != NULL) && (EIF_BOOLEAN)(loc11 == NULL)))) {
		loc8 = (EIF_REFERENCE) NULL;
	}
	if ((EIF_BOOLEAN)(loc8 == NULL)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O2876[dtype-135]);
		loc33 = tr1;
		if (EIF_TEST(loc33)) {
			tb2 = F1154_10864(loc33);
			tb1 = tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN)(loc7 == NULL)) {
				loc31 = RTLNSMART(eif_new_type(1072, 0).id);
				F1018_8683(RTCW(loc31));
				RTAR(Current, loc31);
				*(EIF_REFERENCE *)(Current + O2886[dtype-135]) = (EIF_REFERENCE) loc31;
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					tr1 = F1142_10681(RTCW(loc29));
					loc34 = tr1;
					tb1 = EIF_TEST(loc34);
				}
				if (tb1) {
					loc5 = *(EIF_REFERENCE *)(loc34 + O7965[Dtype(loc34)-1113]);
					tr1 = F1114_9915(RTCW(loc29));
					loc19 = F1058_9279(RTCW(tr1));
					loc19 = RTRV(eif_new_type(1040, 0x00), loc19);
					RTCT0("original_parent_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc19 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					F1073_9512(RTCW(loc31), loc19);
					ti4_1 = F1154_10885(Current, loc29);
					F1073_9513(RTCW(loc31), ti4_1);
				} else {
					RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc30 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc13 = F1254_12491(RTCW(loc30));
					loc13 = RTRV(eif_new_type(1184, 0x00), loc13);
					RTCT0("parent_is_widget", EX_CHECK);
					if ((EIF_BOOLEAN)(loc13 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = F1142_10681(RTCW(loc13));
					loc35 = tr1;
					if (EIF_TEST(loc35)) {
						loc5 = *(EIF_REFERENCE *)(loc35 + O7965[Dtype(loc35)-1113]);
					}
					RTCT0("original_widget_window /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = F1114_9915(RTCW(loc30));
					loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7271[Dtype(RTCW(tr1))-1063])(tr1);
					loc12 = RTRV(eif_new_type(1040, 0x00), loc12);
					RTCT0("parent_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					F1073_9512(RTCW(loc31), loc12);
					loc10 = loc30;
					loc10 = RTRV(eif_new_type(1269, 0x00), loc10);
					RTCT0("item_was_tool_bar_button", EX_CHECK);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					ti4_1 = F1154_10885(Current, loc10);
					F1073_9513(RTCW(loc31), ti4_1);
					loc11 = loc12;
					loc11 = RTRV(eif_new_type(1101, 0x00), loc11);
					RTCT0("tool_bar_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc18 = *(EIF_INTEGER_32 *)(RTCW(loc31)+ _LNGOFF_7_4_0_1_);
					loc18 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc18 - ((EIF_INTEGER_32) 1L));
					tb1 = '\0';
					tb2 = F445_4698(RTCW(loc11));
					if ((EIF_BOOLEAN) !tb2) {
						tb1 = (EIF_BOOLEAN) (loc18 >= ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						F1155_10911(Current, loc11, loc18, loc18);
					}
				}
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					tr1 = F1114_9915(RTCW(loc29));
					loc6 = F1058_9279(RTCW(tr1));
					loc6 = RTRV(eif_new_type(1062, 0x00), loc6);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc6 != NULL)) {
						tr1 = F1114_9915(RTCW(loc29));
						tb2 = F1063_9383(RTCW(loc6), tr1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						F1073_9514(RTCW(loc31));
					}
				}
				F1154_10889(Current);
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					tr1 = F1114_9915(RTCW(loc29));
					F1059_9320(RTCW(loc31), tr1);
				} else {
					RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc30 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc11 = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_5_3_0_1_0_0_0_0_);
					F1018_8683(RTCW(loc11));
					F1059_9320(RTCW(loc31), loc11);
					loc9 = *(EIF_REFERENCE *)(RTCW(loc30) + O7965[Dtype(loc30)-1113]);
					loc9 = RTRV(eif_new_type(1093, 0x00), loc9);
					RTCT0("item_was_tool_bar_button", EX_CHECK);
					if ((EIF_BOOLEAN)(loc9 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					F1056_9244(RTCW(loc11), loc9);
				}
				loc3 = *(EIF_REFERENCE *)(RTCW(loc31) + _REFACS_3_);
				loc3 = RTRV(eif_new_type(1206, 0x00), loc3);
				RTCT0("dialog_imp_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				F1215_11713(RTCW(loc3));
				tr1 = F1014_8657(RTCW(loc31));
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,0,1072,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 3, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
				RTAR(tr2,Current);
				((EIF_TYPED_VALUE *)tr2+2)->it_r = loc31;
				RTAR(tr2,loc31);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3= RTLNRF(typres0.id, (EIF_POINTER) __A514_100, (EIF_POINTER) _A514_100, (EIF_POINTER)(F1154_10880),tr2, 1, 0);
				}
				F634_5271(RTCW(tr1), tr3);
				F1154_10887(Current, loc31);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O2875[dtype-135]);
				loc36 = tr1;
				if (EIF_TEST(loc36)) {
					tb2 = F1154_10866(loc36);
					tb1 = tb2;
				}
				if (tb1) {
					RTCT0("original_widget_window /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					F1072_9505(RTCW(loc31), loc5);
				} else {
					F1070_9470(RTCW(loc31));
				}
				loc1 = loc31;
				loc1 = RTRV(eif_new_type(1058, 0x00), loc1);
			} else {
				F1154_10887(Current, loc7);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1225[dtype-76]) != NULL)) {
				tr1 = F77_1221(Current);
				F637_5325(RTCW(tr1), NULL);
			}
		}
	} else {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_REFERENCE *)(RTCW(loc8) + O7088[Dtype(loc8)-1017]);
		loc2 = RTRV(eif_new_type(1184, 0x00), loc2);
		RTCT0("target_widget_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2) + O7965[Dtype(loc2)-1113]);
		loc1 = RTRV(eif_new_type(1058, 0x00), loc1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == NULL) || (EIF_BOOLEAN)(loc8 != NULL)) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2886[dtype-135]) == NULL))) {
		loc11 = loc8;
		loc11 = RTRV(eif_new_type(1101, 0x00), loc11);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc29 != NULL))) {
			loc26 = '\0';
			tr1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
			F1018_8683(RTCW(tr1));
			tr1 = F1025_8804(RTCW(tr1));
			loc37 = tr1;
			if (EIF_TEST(loc37)) {
				tr1 = F1034_8952(loc37);
				loc26 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			RTCT0("l_widget_source_being_docked /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc29 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = '\0';
			if (loc26) {
				tr1 = F1142_10682(RTCW(loc29));
				tb1 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			if (tb1) {
				RTCT0("container /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc14 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc28 = *(EIF_REFERENCE *)(RTCW(loc14) + O7088[Dtype(loc14)-1017]);
				loc28 = RTRV(eif_new_type(1186, 0x00), loc28);
				RTCT0("container_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc28 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = F1142_10681(RTCW(loc28));
				loc38 = tr1;
				if (EIF_TEST(loc38)) {
					F1204_11473(loc38);
				}
			}
			tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				F1154_10889(Current);
				F1154_10890(Current);
			}
			loc39 = loc7;
			if (EIF_TEST(loc39)) {
				F1070_9455(loc39);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1225[dtype-76]) != NULL)) {
				tr1 = F77_1221(Current);
				F637_5325(RTCW(tr1), NULL);
			}
		} else {
			loc40 = loc7;
			if (EIF_TEST(loc40)) {
				F1154_10887(Current, loc40);
			}
		}
	}
	if ((EIF_BOOLEAN)(loc29 == NULL)) {
		RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc30 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc9 = *(EIF_REFERENCE *)(RTCW(loc30) + O7965[Dtype(loc30)-1113]);
		loc9 = RTRV(eif_new_type(1093, 0x00), loc9);
		RTCT0("tool_bar_button_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc9 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc11 = loc8;
		loc11 = RTRV(eif_new_type(1101, 0x00), loc11);
		if ((EIF_BOOLEAN)(loc11 != NULL)) {
			tr1 = F1092_9753(RTCV(RTOUCR(307,F136_2902, (Current))));
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				loc21 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9562[Dtype(RTCW(loc30))-1254])(loc30);
				loc21 = RTRV(eif_new_type(1101, 0x00), loc21);
				RTCT0("original_tool_bar_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc21 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc24 = loc9;
				loc24 = RTRV(eif_new_type(1091, 0x00), loc24);
				RTCT0("tool_bar_item /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc24 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = RTOUCR(307,F136_2902, (Current));
				loc22 = F1056_9230(RTCW(loc21), tr1, ((EIF_INTEGER_32) 1L));
				loc23 = F1056_9230(RTCW(loc21), loc24, ((EIF_INTEGER_32) 1L));
				tr1 = F1092_9753(RTCW(loc24));
				loc25 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == loc11);
				F1154_10889(Current);
				F1154_10891(Current);
				if ((EIF_BOOLEAN) (loc25 && (EIF_BOOLEAN)(loc23 == (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 2L))))) {
					F1155_10911(Current, loc11, (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 1L)));
				}
				if ((EIF_BOOLEAN)(loc21 == loc11)) {
					loc17 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
					loc17 = RTRV(eif_new_type(1231, 0x00), loc17);
					RTCT0("tool_bar_imp_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc17 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					{
						/* INLINED CODE (EV_TOOL_BAR_IMP.block_selection_for_docking) */
						(void) RTCW(loc17);
						/* END INLINED CODE */
					}
					;
				}
			} else {
				loc17 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
				loc17 = RTRV(eif_new_type(1231, 0x00), loc17);
				RTCT0("tool_bar_imp_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc17 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				ti4_1 = F1232_11933(RTCW(loc17));
				tr1 = F1056_9229(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tr1 == loc9)) {
					loc18 = F1056_9230(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
					ti4_1 = F1056_9233(RTCW(loc11));
					if ((EIF_BOOLEAN) (loc18 < ti4_1)) {
						loc16 = F1056_9229(RTCW(loc11), (EIF_INTEGER_32) (loc18 + ((EIF_INTEGER_32) 1L)));
						loc16 = RTRV(eif_new_type(1092, 0x00), loc16);
					}
					if ((EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 1L))) {
						loc15 = F1056_9229(RTCW(loc11), (EIF_INTEGER_32) (loc18 - ((EIF_INTEGER_32) 1L)));
						loc15 = RTRV(eif_new_type(1092, 0x00), loc15);
					}
					tr1 = F1052_9164(RTCV(RTOUCR(308,F136_2906, (Current))));
					ti4_1 = F783_5619(RTCW(tr1));
					ti2_1 = *(EIF_INTEGER_16 *)(Current + O2888[dtype-135]);
					ti4_2 = (EIF_INTEGER_32) ti2_1;
					if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
						if ((EIF_BOOLEAN)(loc16 != NULL)) {
							F1056_9253(RTCW(loc11), loc16);
						} else {
							if ((EIF_BOOLEAN)(loc15 == NULL)) {
								ti4_1 = F1056_9230(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
								F1056_9239(RTCW(loc11), ti4_1);
								tr1 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_6_0_0_1_0_0_0_0_);
								F1018_8683(RTCW(tr1));
								F1056_9248(RTCW(loc11), tr1);
							}
						}
					} else {
						if ((EIF_BOOLEAN)(loc15 != NULL)) {
							F1056_9253(RTCW(loc11), loc15);
						} else {
							if ((EIF_BOOLEAN)(loc16 == NULL)) {
								ti4_1 = F1056_9230(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
								F1056_9239(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
								tr1 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_6_0_0_1_0_0_0_0_);
								F1018_8683(RTCW(tr1));
								F1056_9248(RTCW(loc11), tr1);
							}
						}
					}
					loc22 = F1056_9230(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
					F1155_10911(Current, loc11, loc22, loc22);
				}
			}
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1225[dtype-76]) != NULL)) {
			tr1 = F77_1221(Current);
			F637_5325(RTCW(tr1), NULL);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O2875[dtype-135]);
	loc41 = tr1;
	if (EIF_TEST(loc41)) {
		loc20 = *(EIF_REFERENCE *)(loc41 + O7965[Dtype(loc41)-1113]);
		loc20 = RTRV(eif_new_type(1057, 0x00), loc20);
		if ((EIF_BOOLEAN)(loc20 != NULL)) {
			tr1 = F1012_8635(RTCW(loc20));
			F636_5298(RTCW(tr1));
		} else {
			loc9 = *(EIF_REFERENCE *)(loc41 + O7965[Dtype(loc41)-1113]);
			loc9 = RTRV(eif_new_type(1093, 0x00), loc9);
			if ((EIF_BOOLEAN)(loc9 != NULL)) {
				tr1 = (RTNA((RTCW(loc9))), ((EIF_REFERENCE) 0));
				F636_5298(RTCW(tr1));
			} else {
				RTCT0("type_not_supported", EX_CHECK);
					RTCF0;
			}
		}
	}
	*(EIF_REFERENCE *)(Current + O2875[dtype-135]) = (EIF_REFERENCE) NULL;
	tb1 = '\0';
	if (loc26) {
		tr1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1018_8683(RTCW(tr1));
		tr1 = F1025_8804(RTCW(tr1));
		loc42 = tr1;
		tb1 = EIF_TEST(loc42);
	}
	if (tb1) {
		loc27 = F1034_8952(loc42);
		if ((EIF_BOOLEAN)(loc27 != NULL)) {
			F1070_9469(RTCW(loc27));
		}
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.close_dockable_dialog */
void F1154_10880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,tr1);
	RTLR(12,loc9);
	RTLR(13,Current);
	RTLR(14,tr2);
	RTLIU(15);
	
	RTGC;
	loc1 = F1059_9311(RTCW(arg1));
	F1066_9406(RTCW(arg1));
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc3 = RTRV(eif_new_type(1065, 0x00), loc3);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb2 = F1066_9398(RTCW(loc3));
		tb1 = tb2;
	}
	if (tb1) {
		F1059_9320(RTCW(loc3), loc1);
	}
	loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc4 = RTRV(eif_new_type(1059, 0x00), loc4);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_4_0_1_);
		tb1 = F553_4906(RTCW(loc4), loc2);
		if (tb1) {
			F1056_9239(RTCW(loc4), loc2);
		} else {
			ti4_1 = F1056_9233(RTCW(loc4));
			F1056_9239(RTCW(loc4), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		}
		F1056_9248(RTCW(loc4), loc1);
		loc5 = loc4;
		loc5 = RTRV(eif_new_type(1062, 0x00), loc5);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_7_3_);
			if (tb1) {
				F1063_9390(RTCW(loc5), loc1);
			}
		}
	}
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc6 = RTRV(eif_new_type(1101, 0x00), loc6);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		loc7 = loc1;
		loc7 = RTRV(eif_new_type(1101, 0x00), loc7);
		RTCT0("old_parent_was_tool_bar", EX_CHECK);
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc8 = F1056_9229(RTCW(loc7), ((EIF_INTEGER_32) 1L));
		loc8 = RTRV(eif_new_type(1093, 0x00), loc8);
		RTCT0("tool_bar_button /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1056_9257(RTCW(loc7));
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_4_0_1_);
		tb1 = F553_4906(RTCW(loc6), loc2);
		if (tb1) {
			F1056_9239(RTCW(loc6), loc2);
		} else {
			ti4_1 = F1056_9233(RTCW(loc6));
			F1056_9239(RTCW(loc6), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		}
		F1056_9248(RTCW(loc6), loc8);
		loc10 = (EIF_REFERENCE) loc8;
	} else {
		loc10 = (EIF_REFERENCE) loc1;
	}
	tb1 = '\0';
	loc11 = arg1;
	if (EIF_TEST(loc11)) {
		tr1 = *(EIF_REFERENCE *)(loc11 + _REFACS_6_);
		loc12 = tr1;
		tb1 = EIF_TEST(loc12);
	}
	if (tb1) {
		loc9 = *(EIF_REFERENCE *)(loc12 + O7088[Dtype(loc12)-1017]);
		loc9 = RTRV(eif_new_type(1164, 0x00), loc9);
	}
	RTCT0("target_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F80_1226(RTCW(loc9));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1036,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc10;
		RTAR(tr2,loc10);
		F637_5325(RTCW(tr1), tr2);
	}
	F1070_9455(RTCW(arg1));
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.drag_cursor */
static EIF_REFERENCE F1154_10881_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(299)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(23, 0x00).id, 23, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOUCR(272,F24_526, (RTCW(tr1)));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1154_10881 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(299,F1154_10881_body,(Current));
}

/* {EV_DOCKABLE_SOURCE_I}.widget_source_being_docked */
EIF_REFERENCE F1154_10882 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2875[dtype-135]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = *(EIF_REFERENCE *)(loc2 + O7965[Dtype(loc2)-1113]);
		loc1 = RTRV(eif_new_type(1057, 0x00), loc1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			Result = *(EIF_REFERENCE *)(Current + O2875[dtype-135]);
			RTLE;
			return RTRV(eif_new_type(1184, 0x00), Result);
		}
	}
	RTLE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.item_source_being_docked */
EIF_REFERENCE F1154_10883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	
	
	Result = *(EIF_REFERENCE *)(Current + O2875[Dtype(Current)-135]);
	return RTRV(eif_new_type(1245, 0x00), Result);
}

/* {EV_DOCKABLE_SOURCE_I}.position_in_parent */
EIF_INTEGER_32 F1154_10885 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + O7965[Dtype(arg1)-1113]);
	loc3 = RTRV(eif_new_type(1057, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc1 = F1058_9279(RTCW(loc3));
		loc1 = RTRV(eif_new_type(1065, 0x00), loc1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
		loc2 = F1058_9279(RTCW(loc3));
		loc2 = RTRV(eif_new_type(1062, 0x00), loc2);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			Result = F1056_9230(RTCW(loc2), loc3, ((EIF_INTEGER_32) 1L));
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	} else {
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + O7965[Dtype(arg1)-1113]);
		loc4 = RTRV(eif_new_type(1093, 0x00), loc4);
		RTCT0("source_was_widget_or_tool_bar_button", EX_CHECK);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc5 = (RTNA((RTCW(loc4))), ((EIF_REFERENCE) 0));
		loc5 = RTRV(eif_new_type(1101, 0x00), loc5);
		RTCT0("tool_bar /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1056_9230(RTCW(loc5), loc4, ((EIF_INTEGER_32) 1L));
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.initialize_transport */
void F1154_10886 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg3);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1224[dtype-76]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O1224[dtype-76]);
		F637_5325(RTCW(tr1), NULL);
	}
	loc1 = arg3;
	loc1 = RTRV(eif_new_type(1057, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1012_8635(RTCW(loc1));
		F636_5296(RTCW(tr1));
	} else {
		loc2 = arg3;
		loc2 = RTRV(eif_new_type(1093, 0x00), loc2);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = (RTNA((RTCW(loc2))), ((EIF_REFERENCE) 0));
			F636_5296(RTCW(tr1));
		} else {
		}
	}
	tr1 = F1037_9010(RTCW(arg3));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = *(EIF_REFERENCE *)(loc3 + O7088[Dtype(loc3)-1017]);
		*(EIF_REFERENCE *)(Current + O2875[dtype-135]) = RTRV(eif_new_type(1153, 0), tr1);
		RTAR(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O7088[Dtype(arg3)-1017]);
		*(EIF_REFERENCE *)(Current + O2875[dtype-135]) = RTRV(eif_new_type(1153, 0), tr1);
		RTAR(Current, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O7088[Dtype(arg3)-1017]);
	*(EIF_REFERENCE *)(Current + O2876[dtype-135]) = RTRV(eif_new_type(1153, 0), tr1);
	RTAR(Current, tr1);
	ti2_1 = (EIF_INTEGER_16) arg1;
	*(EIF_INTEGER_16 *)(Current + O2888[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg2;
	*(EIF_INTEGER_16 *)(Current + O2889[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.move_dialog_to_pointer */
void F1154_10887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc3 = F1039_9037(RTCW(arg1));
	ti4_1 = F1059_9326(RTCW(arg1));
	ti4_2 = F1039_9036(RTCW(arg1));
	ti4_3 = F1059_9325(RTCW(arg1));
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - ti4_1) - (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - ti4_3) / ((EIF_INTEGER_32) 2L)));
	tr1 = F1052_9164(RTCV(RTOUCR(308,F136_2906, (Current))));
	loc1 = F783_5619(RTCW(tr1));
	tr1 = F1052_9164(RTCV(RTOUCR(308,F136_2906, (Current))));
	loc2 = F783_5621(RTCW(tr1));
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O2877[dtype-135]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	F1040_9042(RTCW(arg1), (EIF_INTEGER_32) (loc1 - ti4_1));
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O2878[dtype-135]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	F1040_9043(RTCW(arg1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - ti4_1) - loc3));
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.execute_dragging */
void F1154_10888 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc15);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc16);
	RTLR(6,loc4);
	RTLR(7,loc6);
	RTLR(8,tr2);
	RTLR(9,loc14);
	RTLR(10,loc5);
	RTLR(11,loc17);
	RTLR(12,loc18);
	RTLR(13,loc19);
	RTLR(14,loc11);
	RTLR(15,loc10);
	RTLIU(16);
	
	RTGC;
	loc2 = F1154_10868(Current);
	tr1 = F1154_10882(Current);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb1 = (EIF_BOOLEAN)(loc2 != RTOUCR(297,F136_2899, (Current)));
		}
		if (tb1) {
			loc3 = loc2;
			loc3 = RTRV(eif_new_type(1058, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = F1041_9049(RTCW(loc2));
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					tb1 = '\01';
					tb2 = '\01';
					if (!(EIF_BOOLEAN)(loc2 == NULL)) {
						tb3 = '\0';
						if ((EIF_BOOLEAN)(loc2 != NULL)) {
							tr1 = F1041_9049(RTCW(loc2));
							tb3 = (EIF_BOOLEAN)(tr1 == NULL);
						}
						tb2 = tb3;
					}
					if (!tb2) {
						tb2 = '\0';
						tb3 = '\0';
						if ((EIF_BOOLEAN)(loc2 != NULL)) {
							tr1 = F1041_9049(RTCW(loc2));
							tb3 = (EIF_BOOLEAN)(tr1 != NULL);
						}
						if (tb3) {
							tb2 = (EIF_BOOLEAN) !loc12;
						}
						tb1 = tb2;
					}
					if (tb1) break;
					loc1++;
					tr1 = F1041_9049(RTCW(loc2));
					loc16 = tr1;
					if (EIF_TEST(loc16)) {
						tr1 = F1114_9915(loc15);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc16+ _PTROFF_4_3_0_3_0_0_))(
							*(EIF_POINTER *)(loc16+ _PTROFF_4_3_0_3_0_1_),
							*(EIF_REFERENCE *)(loc16 + _REFACS_1_), tr1);
						loc12 = tb2;
						if (loc12) {
							loc2 = F1154_10867(Current, loc3);
						}
					}
				}
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					loc3 = loc2;
					loc3 = RTRV(eif_new_type(1058, 0x00), loc3);
					RTCT0("container_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
					if ((EIF_BOOLEAN)(tr1 != loc3)) {
						F136_2901(Current);
					}
					loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + O7088[Dtype(loc3)-1017]);
					loc4 = RTRV(eif_new_type(1196, 0x00), loc4);
					loc6 = *(EIF_REFERENCE *)(RTCW(loc3) + O7088[Dtype(loc3)-1017]);
					loc6 = RTRV(eif_new_type(1199, 0x00), loc6);
				}
			}
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				loc7 = F1194_11392(RTCW(loc4));
				if ((EIF_BOOLEAN)(loc7 != ((EIF_INTEGER_32) -1L))) {
					tb2 = '\01';
					ti4_1 = F1146_10799(RTCW(loc4));
					if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tb3 = '\01';
						ti4_1 = F1146_10799(RTCW(loc4));
						ti4_1 = eif_min_int32 (loc7,ti4_1);
						tr1 = F1146_10798(RTCW(loc4), ti4_1);
						if (!(EIF_BOOLEAN)(tr1 == RTOUCR(297,F136_2899, (Current)))) {
							ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1L));
							tr1 = F1146_10798(RTCW(loc4), ti4_1);
							tb3 = (EIF_BOOLEAN)(tr1 == RTOUCR(297,F136_2899, (Current)));
						}
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(loc15 + O7965[Dtype(loc15)-1113]);
						loc8 = F1145_10768(RTCW(loc4), tr1, ((EIF_INTEGER_32) 1L));
						tb2 = '\0';
						tr1 = F1185_11218(loc15);
						tr2 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_26_);
						if ((EIF_BOOLEAN)(tr1 == tr2)) {
							tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 == loc7) || (EIF_BOOLEAN)(loc8 == (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L))));
						}
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(loc15 + O7965[Dtype(loc15)-1113]);
							loc13 = F1145_10768(RTCW(loc4), tr1, ((EIF_INTEGER_32) 1L));
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc13 == loc7) || (EIF_BOOLEAN)((EIF_INTEGER_32) (loc13 + ((EIF_INTEGER_32) 1L)) == loc7))) {
								F136_2901(Current);
							}
						} else {
							tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
							if ((EIF_BOOLEAN)(tr1 != NULL)) {
								tr1 = RTOUCR(306,F136_2900, (Current));
								loc9 = F1154_10885(Current, tr1);
								if ((EIF_BOOLEAN) (loc9 < loc7)) {
									loc7--;
								}
							}
							loc14 = F1142_10681(RTCW(loc4));
							RTCT0("l_top_level_window_imp /= Void", EX_CHECK);
							if ((EIF_BOOLEAN)(loc14 != NULL)) {
								RTCK0;
							} else {
								RTCF0;
							}
							F1204_11473(RTCW(loc14));
							F136_2901(Current);
							loc5 = F1145_10764(RTCW(loc4));
							F1145_10777(RTCW(loc4), loc7);
							tr1 = RTOUCR(297,F136_2899, (Current));
							F1145_10785(RTCW(loc4), tr1);
							tr1 = RTOUCR(297,F136_2899, (Current));
							F1197_11409(RTCW(loc4), tr1, (EIF_BOOLEAN) 0);
							F1145_10778(RTCW(loc4), loc5);
							F1204_11474(RTCW(loc14));
						}
					}
				}
			}
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + O9167[Dtype(loc6)-1207]);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F136_2901(Current);
					tr1 = RTOUCR(297,F136_2899, (Current));
					F1200_11422(RTCW(loc6), tr1);
				}
			}
		} else {
			if ((EIF_BOOLEAN)(loc2 != RTOUCR(297,F136_2899, (Current)))) {
				F136_2901(Current);
			}
		}
	} else {
		tb2 = '\0';
		loc17 = loc2;
		if (EIF_TEST(loc17)) {
			tr1 = F1154_10883(Current);
			loc18 = tr1;
			tb2 = EIF_TEST(loc18);
		}
		if (tb2) {
			tr1 = F1041_9049(loc17);
			loc19 = tr1;
			if (EIF_TEST(loc19)) {
				loc11 = *(EIF_REFERENCE *)(loc18 + O7965[Dtype(loc18)-1113]);
				loc11 = RTRV(eif_new_type(1093, 0x00), loc11);
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc19+ _PTROFF_4_3_0_3_0_0_))(
						*(EIF_POINTER *)(loc19+ _PTROFF_4_3_0_3_0_1_),
						*(EIF_REFERENCE *)(loc19 + _REFACS_1_), loc11);
					tb2 = tb2;
					if ((EIF_BOOLEAN) !tb2) {
						loc10 = *(EIF_REFERENCE *)(loc17 + O7088[Dtype(loc17)-1017]);
						loc10 = RTRV(eif_new_type(1231, 0x00), loc10);
					}
				}
			} else {
				loc10 = *(EIF_REFERENCE *)(loc17 + O7088[Dtype(loc17)-1017]);
				loc10 = RTRV(eif_new_type(1231, 0x00), loc10);
			}
			if ((EIF_BOOLEAN)(loc10 != NULL)) {
				loc7 = F1232_11933(RTCW(loc10));
				if ((EIF_BOOLEAN)(loc7 != ((EIF_INTEGER_32) -1L))) {
					ti4_1 = F1146_10799(RTCW(loc10));
					if ((EIF_BOOLEAN) (loc7 < ti4_1)) {
						loc7++;
					}
					tb2 = '\01';
					ti4_1 = F1146_10799(RTCW(loc10));
					ti4_1 = eif_min_int32 (loc7,ti4_1);
					tr1 = F1146_10798(RTCW(loc10), ti4_1);
					if (!(EIF_BOOLEAN)(tr1 == RTOUCR(307,F136_2902, (Current)))) {
						ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1L));
						tr1 = F1146_10798(RTCW(loc10), ti4_1);
						tb2 = (EIF_BOOLEAN)(tr1 == RTOUCR(307,F136_2902, (Current)));
					}
					if ((EIF_BOOLEAN) !tb2) {
						loc11 = *(EIF_REFERENCE *)(loc18 + O7965[Dtype(loc18)-1113]);
						loc11 = RTRV(eif_new_type(1093, 0x00), loc11);
						loc8 = F1145_10768(RTCW(loc10), loc11, ((EIF_INTEGER_32) 1L));
						tb2 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9562[Dtype(loc18)-1254])(loc18);
						tr2 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_25_);
						if ((EIF_BOOLEAN)(tr1 == tr2)) {
							tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 == loc7) || (EIF_BOOLEAN)(loc8 == (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L))));
						}
						if (tb2) {
							F136_2904(Current);
						} else {
							tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
							if ((EIF_BOOLEAN)(tr1 != NULL)) {
								if ((EIF_BOOLEAN) (loc9 < loc7)) {
									loc7--;
								}
							}
							F136_2904(Current);
							F1145_10777(RTCW(loc10), loc7);
							tr1 = RTOUCR(307,F136_2902, (Current));
							F1145_10785(RTCW(loc10), tr1);
						}
					}
				}
			}
		} else {
			F136_2904(Current);
		}
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.unparent_source_being_docked */
void F1154_10889 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = F1154_10882(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1114_9915(loc1);
		tr1 = F1058_9279(RTCW(tr1));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tr1 = F1114_9915(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7569[Dtype(loc2)-1063])(loc2, tr1);
	} else {
		tb1 = '\0';
		tr1 = F1154_10883(Current);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = F1114_9915(loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7271[Dtype(RTCW(tr1))-1063])(tr1);
			loc4 = tr1;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			tr1 = F1114_9915(loc3);
			F1056_9253(loc4, tr1);
		} else {
		}
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.replace_insert_label */
void F1154_10890 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		loc3 = *(EIF_REFERENCE *)(loc6 + O7088[Dtype(loc6)-1017]);
		loc3 = RTRV(eif_new_type(1164, 0x00), loc3);
	}
	loc4 = F1154_10882(Current);
	RTCT0("l_widget_source_being_docked /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("target_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
	loc1 = RTRV(eif_new_type(1062, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1114_9915(RTCW(loc4));
		tr2 = RTOUCR(297,F136_2899, (Current));
		ti4_1 = F1056_9230(RTCW(loc1), tr2, ((EIF_INTEGER_32) 1L));
		F1056_9249(RTCW(loc1), tr1, ti4_1);
	}
	loc2 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
	loc2 = RTRV(eif_new_type(1065, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = F1114_9915(RTCW(loc4));
		F1059_9321(RTCW(loc2), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F80_1226(RTCW(loc3));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1057,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		tr3 = F1114_9915(RTCW(loc4));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		F637_5325(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_I}.replace_insert_sep */
void F1154_10891 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc1 = F1092_9753(RTCV(RTOUCR(307,F136_2902, (Current))));
	loc1 = RTRV(eif_new_type(1101, 0x00), loc1);
	RTCT0("parent_was_tool_bar", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1154_10883(Current);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc2 = *(EIF_REFERENCE *)(loc7 + O7965[Dtype(loc7)-1113]);
		loc2 = RTRV(eif_new_type(1091, 0x00), loc2);
	}
	RTCT0("tool_bar_item_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = loc2;
	loc3 = RTRV(eif_new_type(1036, 0x00), loc3);
	RTCT0("source_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTOUCR(307,F136_2902, (Current));
	loc4 = F1056_9230(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTOUCR(307,F136_2902, (Current));
	ti4_1 = F1056_9230(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
	F1056_9249(RTCW(loc1), loc2, ti4_1);
	if ((EIF_BOOLEAN)(loc5 == (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)))) {
		F1155_10911(Current, loc1, loc5, loc4);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F1011_8632(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1036,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc3;
		RTAR(tr2,loc3);
		F637_5325(RTCW(tr1), tr2);
	}
	RTLE;
}

void EIF_Minit514 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
