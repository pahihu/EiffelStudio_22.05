/*
 * Code for class EV_GTK_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev507.h"
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include <ev_gtk.h>
#include "eif_helpers.h"
#include "eif_misc.h"
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WINDOW_IMP}.set_blocking_window */
void F1143_10686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O7088[Dtype(arg1)-1017]);
			loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
			RTCT0("l_internal_blocking_window /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O8564[dtype-1142]) = (EIF_REFERENCE) loc1;
			F1212_11614(RTCW(loc1), Current);
		} else {
			loc1 = *(EIF_REFERENCE *)(Current + O8564[dtype-1142]);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				F1212_11615(RTCW(loc1), Current);
				*(EIF_REFERENCE *)(Current + O8564[dtype-1142]) = (EIF_REFERENCE) NULL;
			}
		}
	} else {
		*(EIF_REFERENCE *)(Current + O8564[dtype-1142]) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.blocking_window */
EIF_REFERENCE F1143_10687 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8564[Dtype(Current)-1142]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1114_9914(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7965[Dtype(loc1)-1113]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WINDOW_IMP}.window_position_enum */
EIF_INTEGER_32 F1143_10688 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1143_10687(Current) != NULL)) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_CENTER_ON_PARENT;
	} else {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8563[Dtype(Current)-1143])(Current);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WINDOW_IMP}.default_window_position */
EIF_INTEGER_32 F1143_10689 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_NONE;
}

/* {EV_GTK_WINDOW_IMP}.set_size */
void F1143_10693 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1142_10655(Current);
	loc1 = eif_max_int32 (arg1,ti4_1);
	ti4_1 = F1142_10656(Current);
	loc2 = eif_max_int32 (arg2,ti4_1);
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	gtk_window_resize((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	*(EIF_BOOLEAN *)(Current + O8571[dtype-1142]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tb1 = '\0';
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current)) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8582[dtype-1143])(Current);
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8587[dtype-1143])(Current);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.width */
EIF_INTEGER_32 F1143_10694 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O8571[dtype-1142])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result), (EIF_INTEGER_32*) tp3);
		ti4_1 = F1142_10655(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		Result = F1142_10674(Current);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.height */
EIF_INTEGER_32 F1143_10695 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O8571[dtype-1142])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8553[dtype-1143])(Current);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) tp3, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result));
		ti4_1 = F1142_10656(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		Result = F1142_10675(Current);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.set_x_position */
void F1143_10696 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1143_10704(Current);
	F1143_10698(Current, arg1, ti4_1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.set_y_position */
void F1143_10697 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1143_10702(Current);
	F1143_10698(Current, ti4_1, arg1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.set_position */
void F1143_10698 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_11_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_12_);
	gtk_window_move((GtkWindow*) tp1, (gint) (EIF_INTEGER_32) (arg1 - ti4_1), (gint) (EIF_INTEGER_32) (arg2 - ti4_2));
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.client_width */
EIF_INTEGER_32 F1143_10700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.client_height */
EIF_INTEGER_32 F1143_10701 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.x_position */
EIF_INTEGER_32 F1143_10702 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_x */
EIF_INTEGER_32 F1143_10703 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.y_position */
EIF_INTEGER_32 F1143_10704 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_y */
EIF_INTEGER_32 F1143_10705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(49,F1141_10647, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.default_wm_decorations */
EIF_INTEGER_32 F1143_10706 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {EV_GTK_WINDOW_IMP}.show */
void F1143_10707 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1142_10678(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		ti4_1 = F1143_10688(Current);
		gtk_window_set_position((GtkWindow*) tp1, (GtkWindowPosition) ti4_1);
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.hide */
void F1143_10708 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1142_10678(Current)) {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O8564[dtype-1142]);
		loc5 = tr1;
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O8577[dtype-1142]) && EIF_TEST(loc5))) {
			tb3 = F1114_9914(loc5);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1142_10678(loc5);
			tb1 = tb2;
		}
		if (tb1) {
			F1212_11650(loc5);
		}
		loc1 = F1143_10702(Current);
		loc2 = F1143_10704(Current);
		loc3 = F1143_10694(Current);
		loc4 = F1143_10695(Current);
		*(EIF_BOOLEAN *)(Current + O8577[dtype-1142]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1143_10686(Current, NULL);
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_widget_hide((GtkWidget*) tp1);
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		gdk_window_hide((GdkWindow*) tp1);
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc3, (gint) loc4);
		tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
		gtk_window_move((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.close */
void F1143_10709 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8575[dtype-1143])(Current);
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	gtk_window_close((GtkWindow*) tp1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.show_relative_to_window */
void F1143_10712 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1143_10686(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8551[Dtype(Current)-1143])(Current);
	F1143_10686(Current, arg1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.process_key_event */
void F1143_10717 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc13 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc8);
	RTLR(4,loc6);
	RTLR(5,loc15);
	RTLR(6,loc16);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,loc2);
	RTLR(10,loc9);
	RTLR(11,loc14);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc19);
	RTLR(15,tr3);
	RTLIU(16);
	
	RTGC;
	RTAOMS(10716,3);
	loc5 = RTOUCR(49,F1141_10647, (Current));
	loc1 = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN) !F226_3613(Current, loc1)) {
			if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828432L))) {
				loc1 = (EIF_NATURAL_32) GDK_KEY_F11;
			} else {
				if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828433L))) {
					loc1 = (EIF_NATURAL_32) GDK_KEY_F12;
				} else {
					loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
			}
		}
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			loc3 = RTLNS(eif_new_type(1287, 0x00).id, 1287, _OBJSIZ_0_0_0_1_0_0_0_0_);
			ti4_1 = F226_3612(Current, loc1);
			F1288_13138(RTCW(loc3), ti4_1);
		}
	}
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventKey *)arg1)->type) == (EIF_INTEGER_32) GDK_KEY_PRESS)) {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc8 = Current;
		loc8 = RTRV(eif_new_type(1211, 0x00), loc8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
			loc6 = *(EIF_REFERENCE *)(RTCW(loc8) + O9130[Dtype(loc8)-1203]);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tb2 = F445_4698(RTCW(loc6));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc15 = F619_5195(RTCW(loc6), ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN)(loc15 != NULL)) {
					loc16 = *(EIF_REFERENCE *)(RTCW(loc15) + _REFACS_1_);
					loc16 = RTRV(eif_new_type(1127, 0x00), loc16);
					RTCT0("l_accel_imp /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc16 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + O9126[Dtype(loc8)-1203]);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
					tb1 = F1137_10484(RTCW(loc5));
					tb2 = F1137_10485(RTCW(loc5));
					tb3 = F1137_10486(RTCW(loc5));
					ti4_1 = F1127_10159(RTCW(loc16), ti4_1, tb1, tb2, tb3);
					loc15 = F611_5063(RTCW(tr1), ti4_1);
					if ((EIF_BOOLEAN)(loc15 != NULL)) {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,655,0xFFF9,0,901,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 3, 0);
						}
						tr2 = F1026_8819(RTCW(loc15));
						((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
						RTAR(tr1,tr2);
						
						{
							static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2= RTLNRF(typres0.id, (EIF_POINTER) __A265_175, (EIF_POINTER) _A265_175, (EIF_POINTER)(F637_5325),tr1, 1, 0);
						}
						F1136_10398(RTCW(loc5), tr2);
					}
				}
			}
		}
		loc2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_47_);
		F988_8454(RTCW(loc2));
		tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_49_16_0_20_0_3_);
		loc17 = (EIF_BOOLEAN) EIF_TEST(gtk_im_context_filter_keypress((GtkIMContext*) tp1, (GdkEventKey*) arg1));
		if ((EIF_BOOLEAN) !loc7) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F981_8118(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb1 = tb2;
			}
			if (tb1) {
				loc13 = F988_8393(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb1 = '\0';
				tb2 = '\0';
				tb3 = (loc13 <= 0xFF);
				if (tb3) {
					tc1 = (EIF_CHARACTER_8) loc13;
					tr1 = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_CHARACTER_8 *)tr1 = tc1;
					tb3 = F936_7983(RTCW(tr1));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					ti4_1 = (EIF_INTEGER_32) (loc13);
					tb1 = (EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 127L));
				}
				if (tb1) {
					loc2 = (EIF_REFERENCE) NULL;
				}
			} else {
				loc2 = (EIF_REFERENCE) NULL;
			}
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = F1288_13147(RTCW(loc3));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
				tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
			}
			if (tb2) {
				tb2 = F1288_13142(RTCW(loc3));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				switch (ti4_1) {
					case 39L:
						RTCOMS32(tr1,10716,0," \000\000\000",1,32);
						loc2 = (EIF_REFERENCE) tr1;
						break;
					case 41L:
						RTCOMS32(tr1,10716,1,"\012\000\000\000",1,10);
						loc2 = (EIF_REFERENCE) tr1;
						break;
					case 43L:
						RTCOMS32(tr1,10716,2,"\011\000\000\000",1,9);
						loc2 = (EIF_REFERENCE) tr1;
						break;
					default:
						loc2 = (EIF_REFERENCE) NULL;
						break;
				}
			}
		}
	}
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	tp1 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
	loc9 = F1137_10575(RTCW(loc5), tp1);
	loc9 = RTRV(eif_new_type(1184, 0x00), loc9);
	loc14 = (EIF_REFERENCE) Current;
	if ((EIF_BOOLEAN)(loc9 == NULL)) {
		loc9 = RTCCL(loc14);
		loc9 = RTRV(eif_new_type(1184, 0x00), loc9);
		if ((EIF_BOOLEAN)(loc9 == NULL)) {
			loc10 = RTCCL(loc14);
			loc10 = RTRV(eif_new_type(1180, 0x00), loc10);
		}
	}
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		tb3 = F1164_10980(RTCW(loc9));
		tb2 = tb3;
	}
	if (tb2) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8940[Dtype(RTCW(loc9))-1197])(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			loc12 = F1184_11201(RTCW(loc9), loc3);
			if ((EIF_BOOLEAN) !loc12) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 43L));
				if (loc18) {
					tb1 = F1137_10486(RTCW(loc5));
					if (tb1) {
						F1136_10423(RTCW(loc5), ((EIF_NATURAL_8) 2U));
					} else {
						F1136_10423(RTCW(loc5), ((EIF_NATURAL_8) 1U));
					}
				}
				loc11 = loc9;
				loc11 = RTRV(eif_new_type(1139, 0x00), loc11);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc11) + O9410[Dtype(loc11)-1230]);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					loc12 = '\01';
					tb1 = F1288_13145(RTCW(loc3));
					if (!tb1) {
						loc12 = loc18;
					}
				}
			}
		}
		if ((EIF_BOOLEAN) !loc12) {
			gtk_main_do_event((GdkEvent*) arg1);
		}
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tr1 = F1137_10560(RTCW(loc5));
		loc19 = tr1;
		if (EIF_TEST(loc19)) {
			tb3 = loc4;
		}
		if (tb3) {
			tb2 = (EIF_BOOLEAN)(loc3 != NULL);
		}
		if (tb2) {
			tb2 = '\01';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
			if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 42L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 96L));
			}
			tb1 = tb2;
		}
		if (tb1) {
			tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			F1183_11167(loc19, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), tr8_1, tr8_2, tr8_3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		} else {
			if (loc4) {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_14_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F103_2498(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,1057,1287,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1114_9915(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
				}
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_15_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F103_2500(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,1057,987,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1114_9915(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
					RTAR(tr2,loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
				}
			} else {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_16_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F103_2502(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,1057,1287,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1114_9915(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
				}
			}
			if ((EIF_BOOLEAN) !loc12) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8583[dtype-1143])(Current, loc3, loc2, loc4);
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc9 != loc14)) {
				tb2 = F1114_9914(RTCW(loc9));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1185_11213(RTCW(loc9), loc3, loc2, loc4);
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc10 != NULL) && loc4)) {
			(RTNA((RTCW(loc10), loc3, loc2, loc4)));
		}
		gtk_main_do_event((GdkEvent*) arg1);
	}
	if (loc18) {
		F1136_10423(RTCW(loc5), ((EIF_NATURAL_8) 0U));
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.on_size_allocate */
void F1143_10719 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8571[Dtype(Current)-1142]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_GTK_WINDOW_IMP}.forbid_resize */
void F1143_10720 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	loc2 = F1143_10694(Current);
	loc3 = F1143_10695(Current);
	(((GdkGeometry *)loc1)->max_width = (gint)(loc2));
	(((GdkGeometry *)loc1)->max_height = (gint)(loc3));
	(((GdkGeometry *)loc1)->min_width = (gint)(loc2));
	(((GdkGeometry *)loc1)->min_height = (gint)(loc3));
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	ti4_1 = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	ti4_2 = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	gtk_window_set_geometry_hints((GtkWindow*) tp1, (GtkWidget*) tp3, (GdkGeometry*) loc1, (GdkWindowHints) ti4_1);
	free(loc1);
	RTLE;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
