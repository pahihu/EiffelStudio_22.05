/*
 * Code for class EV_TEXTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev537.h"
#include "eif_built_in.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F99_2319
static void inline_F99_2319 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F99_2319
#endif
#ifndef INLINE_F99_2320
static void inline_F99_2320 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F99_2320
#endif
#ifndef INLINE_F98_2095
static void inline_F98_2095 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F98_2095
#endif
#ifndef INLINE_F98_2097
static void inline_F98_2097 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F98_2097
#endif
#ifndef INLINE_F99_2228
static EIF_INTEGER_32 inline_F99_2228 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F99_2228
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE_IMP}.textable_imp_initialize */
void F1177_11038 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	*(EIF_POINTER *)(Current + O8834[dtype-1176]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2319(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2320(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F98_2095(tp1, ((EIF_INTEGER_32) 2L));
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F98_2097(tp1, ((EIF_INTEGER_32) 2L));
	RTLE;
}

/* {EV_TEXTABLE_IMP}.text */
EIF_REFERENCE F1177_11039 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8836[dtype-1176]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F981_8165(loc2);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
		loc1 = (EIF_POINTER) gtk_label_get_label((GtkLabel*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr1 = RTLNS(eif_new_type(848, 0x00).id, 848, _OBJSIZ_0_1_0_1_0_1_0_0_);
			F849_5845(RTCW(tr1), loc1);
			Result = F849_5841(RTCW(tr1));
		} else {
			Result = F981_8165(RTMS_EX_H("",0,0));
		}
	}
	RTLE;
	return Result;
}

/* {EV_TEXTABLE_IMP}.align_text_center */
void F1177_11041 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2319(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2320(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	ti4_1 = inline_F99_2228();
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTLE;
}

/* {EV_TEXTABLE_IMP}.align_text_left */
void F1177_11042 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2319(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2320(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTLE;
}

/* {EV_TEXTABLE_IMP}.align_text_right */
void F1177_11043 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2319(tp1, (EIF_REAL_32) 1.0);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	inline_F99_2320(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTLE;
}

/* {EV_TEXTABLE_IMP}.set_text */
void F1177_11044 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8835[dtype-1235])(Current)) {
		loc2 = F981_8165(RTCW(arg1));
		if ((EIF_BOOLEAN)(loc2 == arg1)) {
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O8836[dtype-1176]) = (EIF_REFERENCE) tr1;
		} else {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + O8836[dtype-1176]) = (EIF_REFERENCE) loc2;
		}
		tr1 = RTOUCR(49,F1141_10647, (Current));
		tr2 = F1177_11049(Current, arg1);
		loc1 = F1137_10585(RTCW(tr1), tr2);
		tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text_with_mnemonic((GtkLabel*) tp1, (gchar*) tp2);
	} else {
		tr1 = RTOUCR(49,F1141_10647, (Current));
		loc1 = F1137_10585(RTCW(tr1), arg1);
		*(EIF_REFERENCE *)(Current + O8836[dtype-1176]) = (EIF_REFERENCE) NULL;
		tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
		gtk_widget_hide((GtkWidget*) tp1);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8834[dtype-1176]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_TEXTABLE_IMP}.accelerators_enabled */
EIF_BOOLEAN F1177_11047 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_TEXTABLE_IMP}.u_lined_filter */
EIF_REFERENCE F1177_11049 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F981_8165(RTCW(arg1));
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		loc2 = F988_8392(RTCW(Result), loc1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			if ((EIF_BOOLEAN)(Result == arg1)) {
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
				Result = (EIF_REFERENCE) tr1;
			}
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
				loc2 = F988_8392(RTCW(Result), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					F988_8446(RTCW(Result), loc1);
					loc1--;
				} else {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
					F988_8412(RTCW(Result), tw1, loc1);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F988_8412(RTCW(Result), tw1, loc1);
			}
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				if ((EIF_BOOLEAN)(Result == arg1)) {
					tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
					Result = (EIF_REFERENCE) tr1;
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F988_8443(RTCW(Result), tw1, loc1);
			}
		}
		loc1--;
	}
	RTLE;
	return Result;
}

void EIF_Minit537 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
