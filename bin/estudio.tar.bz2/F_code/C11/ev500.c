/*
 * Code for class EV_APPLICATION_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev500.h"
#include "eif_built_in.h"
#include "eif_memory.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_I}.make */
void F1136_10346 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {618,975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F619_5188(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b) {
		tr1 = RTLNSMART(eif_new_type(850, 0).id);
		F851_5860(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
		tr1 = RTLNSMART(eif_new_type(850, 0).id);
		F851_5860(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {612,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F613_5057(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {624,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F625_5188(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(130, 0x00).id, 130, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1287, 0x00).id, 1287, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F1288_13138(RTCW(loc1), ((EIF_INTEGER_32) 27L));
	tr1 = RTLNSMART(eif_new_type(1025, 0).id);
	F1026_8818(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1025, 0).id);
	F1026_8818(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A500_300, (EIF_POINTER) _A500_300, (EIF_POINTER)(F1136_10443),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr2;
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A500_243, (EIF_POINTER) _A500_243, (EIF_POINTER)(F1136_10386),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr2;
	F1136_10377(Current, *(EIF_REFERENCE *)(Current + _REFACS_30_));
	F1136_10378(Current, *(EIF_REFERENCE *)(Current + _REFACS_31_));
	tr1 = RTOUCR(78,F1136_10437, (Current));
	F170_3295(RTCW(tr1), (EIF_BOOLEAN) 1);
	tr1 = F103_2473(Current);
	F637_5325(RTCW(tr1), NULL);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	F1136_10375(Current, (EIF_BOOLEAN) 1);
	F1114_9929(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_APPLICATION_I}.process_event_queue */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1136_10352 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_3;
	EIF_INTEGER_32  EIF_VOLATILE ti4_4;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc5);
	RTLR(7,saved_except);
	RTLIU(8);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		F1137_10478(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_2_)) {
			*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN) (arg1 && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_))) {
				(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) == ((EIF_NATURAL_32) 1500U))) {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_)) {
						plsc();
						eif_mem_coalesc();
					}
					*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			} else {
				*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			}
		}
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN) !F1114_9914(Current)) {
			tb2 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_);
		}
		if (tb1) {
			if (F1136_10394(Current)) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_25_) == NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F619_5209(RTCW(tr1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr1 = F619_5192(RTCW(tr1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
						loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					}
				} else {
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F619_5209(RTCW(tr2));
						tr1 = F786_5723(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F619_5209(RTCW(tr2));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = F619_5192(RTCW(tr2));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F619_5209(RTCW(tr3));
					/* INLINED CODE (SPECIAL.copy_data) */
					sp_copy_data(RTCW(tr1),tr2,((EIF_INTEGER_32) 0L),((EIF_INTEGER_32) 0L),ti4_1);
					RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + ti4_1);
					/* END INLINED CODE */
					;
					loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				}
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4431[Dtype(RTCW(tr1))-609])(tr1);
				}
				F1136_10395(Current);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			if (F1136_10391(Current)) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_24_) == NULL)) {
					ti4_1 = F619_5209(RTCW(loc1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						tr1 = F619_5192(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
						loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					}
				} else {
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F619_5209(RTCW(loc1));
						tr1 = F786_5723(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F619_5209(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr2 = F619_5192(RTCW(loc1));
					ti4_1 = F619_5209(RTCW(loc1));
					/* INLINED CODE (SPECIAL.copy_data) */
					sp_copy_data(RTCW(tr1),tr2,((EIF_INTEGER_32) 0L),((EIF_INTEGER_32) 0L),ti4_1);
					RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + ti4_1);
					/* END INLINED CODE */
					;
					loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				}
				F1136_10392(Current);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc6);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb1 = F1114_9914(Current);
					}
					if (tb1) break;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc6) + (loc7));
					/* END INLINED CODE */
					tr1 = tr2;
					F1136_10354(Current, tr1);
					loc7++;
				}
				F786_5728(RTCW(loc6));
			}
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc5);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb2 = F1114_9914(Current);
					}
					if (tb2) break;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc5) + (loc7));
					/* END INLINED CODE */
					tr1 = tr2;
					(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
						*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
						*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_));
					loc7++;
				}
				F786_5728(RTCW(loc5));
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tb3 = '\0';
			if (arg1) {
				tb3 = (EIF_BOOLEAN) !F1114_9914(Current);
			}
			if (tb3) {
				F1137_10478(Current);
				tb3 = '\0';
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F619_5209(RTCW(tr1));
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				if (tb3) {
					F1137_10476(Current, ((EIF_INTEGER_32) 20L));
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
			tr1 = F1136_10434(Current);
			F1136_10429(Current, tr1);
		}
	}
	RTE_E
	RTXSC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (loc3) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1136_10395(Current);
	}
	if (loc2) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1136_10392(Current);
	}
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		loc4++;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.call_separate_action */
void F1136_10354 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F976_8093(RTCW(arg1), NULL);
}

/* {EV_APPLICATION_I}.set_invoke_garbage_collection_when_inactive */
void F1136_10375 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_) = (EIF_BOOLEAN) arg1;
}

/* {EV_APPLICATION_I}.set_captured_widget */
void F1136_10376 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_I}.set_help_accelerator */
void F1136_10377 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_39_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F1026_8819(RTCW(tr1));
		tb2 = F619_5200(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F1026_8819(RTCW(tr1));
		F634_5271(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_contextual_help_accelerator */
void F1136_10378 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_40_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F1026_8819(RTCW(tr1));
		tb2 = F619_5200(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F1026_8819(RTCW(tr1));
		F634_5271(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_locked_window */
void F1136_10380 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_I}.enable_contextual_help */
void F1136_10386 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1137_10475(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) loc1;
		tr1 = F1012_8636(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) tr1;
		tr1 = F1012_8636(loc1);
		F634_5283(RTCW(tr1));
		tr1 = F1012_8636(loc1);
		tr2 = RTOUCR(79,F1136_10445, (Current));
		F636_5292(RTCW(tr1), tr2);
		tr1 = F1058_9281(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(23, 0x00).id, 23, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = RTOUCR(80,F24_523, (RTCW(tr1)));
		F1058_9302(loc1, tr1);
		F1058_9294(loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.display_help_for_widget */
void F1136_10387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F1033_8946(RTCW(arg1));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr2 = F977_8097(RTCW(loc1), NULL);
		F131_2852(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.try_idle_lock */
EIF_BOOLEAN F1136_10391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		Result = F851_5864(RTCW(tr1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.idle_unlock */
void F1136_10392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		F851_5865(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.kamikaze_lock */
void F1136_10393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F851_5863(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.try_kamikaze_lock */
EIF_BOOLEAN F1136_10394 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		Result = F851_5864(RTCW(tr1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.kamikaze_unlock */
void F1136_10395 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F851_5865(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.do_once_on_idle */
void F1136_10398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1136_10393(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F619_5200(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(tr1))-600])(tr1, arg1);
	}
	if ((EIF_BOOLEAN) !F1136_10436(Current)) {
		{
			/* INLINED CODE (EV_APPLICATION_I.wake_up_gui_thread) */
			/* END INLINED CODE */
		}
		;
	}
	F1136_10395(Current);
	RTLE;
}

/* {EV_APPLICATION_I}.increase_action_sequence_call_counter */
void F1136_10400 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_1_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
}

/* {EV_APPLICATION_I}.pnd_screen */
static EIF_REFERENCE F1136_10407_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(81)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1051, 0x00).id, 1051, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1050_9115(RTCW(Result));
	tr1 = RTOUCR(18,F34_747, (RTCV(RTOUCR(82,F1136_10408, (Current)))));
	F1036_9003(RTCW(Result), tr1);
	F1050_9143(RTCW(Result));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1136_10407 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(81,F1136_10407_body,(Current));
}

/* {EV_APPLICATION_I}.stock_colors */
static EIF_REFERENCE F1136_10408_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(82)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(33, 0x00).id, 33, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1136_10408 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(82,F1136_10408_body,(Current));
}

/* {EV_APPLICATION_I}.set_x_y_origin */
void F1136_10411 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {EV_APPLICATION_I}.draw_rubber_band */
void F1136_10415 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(81,F1136_10407, (Current));
	F1050_9127(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_APPLICATION_I}.erase_rubber_band */
void F1136_10416 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_)) {
		tr1 = RTOUCR(81,F1136_10407, (Current));
		F1050_9127(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_pnd_pointer_coords */
void F1136_10419 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {EV_APPLICATION_I}.create_target_menu */
void F1136_10420 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_BOOLEAN arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc7);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc15);
	RTLR(11,loc16);
	RTLR(12,loc17);
	RTLR(13,arg6);
	RTLR(14,loc18);
	RTLR(15,arg7);
	RTLR(16,loc19);
	RTLR(17,loc4);
	RTLR(18,loc6);
	RTLR(19,loc5);
	RTLR(20,loc8);
	RTLR(21,loc9);
	RTLR(22,loc20);
	RTLR(23,arg5);
	RTLR(24,loc14);
	RTLR(25,loc21);
	RTLR(26,loc22);
	RTLIU(27);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	loc11 = RTLNS(eif_new_type(1110, 0x00).id, 1110, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc11));
	loc3 = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
	loc1 = F613_5071(RTCW(loc2));
	F613_5096(RTCW(loc2));
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {979,0xFFF9,2,901,24,24,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A500_308_2_3, (EIF_POINTER) _A500_308_2_3, (EIF_POINTER)(0),tr1, 1, 2);
	}
	loc7 = (EIF_REFERENCE) tr4;
	for (;;) {
		tb1 = F613_5091(RTCW(loc2));
		if (tb1) break;
		tb2 = '\0';
		ti4_1 = F613_5069(RTCW(loc2));
		tr1 = F862_6672(RTCW(loc3), ti4_1);
		loc15 = tr1;
		loc15 = RTRV(eif_new_type(865, 0x00),loc15);
		if (EIF_TEST(loc15)) {
			tb3 = '\01';
			loc16 = loc15;
			loc16 = RTRV(eif_new_type(1053, 0x00),loc16);
			if (!((EIF_BOOLEAN) !EIF_TEST(loc16))) {
				tb4 = F1018_8687(loc16);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			tb2 = '\0';
			loc17 = RTCCL(arg6);
			if (EIF_TEST(loc17)) {
				tr1 = F1009_8627(loc15);
				tr2 = RTCCL(loc17);
				tb3 = F638_5328(RTCW(tr1), tr2);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\0';
				loc18 = loc15;
				loc18 = RTRV(eif_new_type(1056, 0x00),loc18);
				if (EIF_TEST(loc18)) {
					tb3 = '\0';
					tb4 = F1018_8687(loc18);
					if ((EIF_BOOLEAN) !tb4) {
						tb4 = F1057_9271(loc18);
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					tb2 = tb3;
				}
				if ((EIF_BOOLEAN) !tb2) {
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc10 && (EIF_BOOLEAN)(arg7 != NULL))) {
						tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_6_0_0_1_0_0_0_0_);
						tr2 = RTMS_EX_H("Pick",4,1349084011);
						F1096_9769(RTCW(tr1), tr2, arg7);
						F1056_9244(RTCW(loc11), tr1);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					tr1 = *(EIF_REFERENCE *)(loc15 + O5780[Dtype(loc15)-865]);
					loc19 = tr1;
					if (EIF_TEST(loc19)) {
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 2, 0);
						}
						((EIF_TYPED_VALUE *)tr1+1)->it_r = loc17;
						RTAR(tr1,loc17);
						loc4 = F977_8097(loc19, tr1);
					}
					if ((EIF_BOOLEAN)(loc4 != NULL)) {
						(RTNA((RTCW(loc4), loc15)));
						{
							static EIF_TYPE_INDEX typarr0[] = {176,24,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc6 = RTLNS(typres0.id, 176, _OBJSIZ_2_0_0_0_0_0_0_0_);
						}
						F177_3312(RTCW(loc6), loc4, loc7);
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {311,176,24,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								loc5 = RTLNS(typres0.id, 311, _OBJSIZ_4_1_0_1_0_0_0_0_);
							}
							F312_4589(RTCW(loc5), loc6);
						} else {
							F312_4601(RTCW(loc5), loc6);
						}
						loc4 = (EIF_REFERENCE) NULL;
					}
				}
			}
		}
		F613_5097(RTCW(loc2));
	}
	if (loc13) {
		{
			static EIF_TYPE_INDEX typarr0[] = {618,24,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc8 = RTLNS(typres0.id, 618, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F619_5188(RTCW(loc8), ((EIF_INTEGER_32) 0L));
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,3,901,975,0xFFF9,0,901,311,176,24,618,24,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A500_309_2_3_4, (EIF_POINTER) _A500_309_2_3_4, (EIF_POINTER)(0),tr1, 1, 3);
			}
			loc9 = (EIF_REFERENCE) tr4;
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_1_), loc9, loc5, loc8);
		}
		loc12 = F1056_9233(RTCW(loc11));
		tr1 = F1054_9204(RTCW(arg5));
		loc20 = tr1;
		if (EIF_TEST(loc20)) {
			loc14 = (EIF_REFERENCE) RTCCL(arg6);
			RTCT0("l_pebble /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc14 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTCCL(loc14);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc20 + _REFACS_1_), loc11, loc8, arg5, tr1);
		} else {
			F619_5219(RTCW(loc8));
			for (;;) {
				tb2 = F577_4933(RTCW(loc8));
				if (tb2) break;
				tr1 = F619_5193(RTCW(loc8));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				loc21 = tr1;
				if (EIF_TEST(loc21)) {
					loc14 = (EIF_REFERENCE) RTCCL(arg6);
					RTCT0("l_pebble /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc14 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = RTLNS(eif_new_type(1095, 0x00).id, 1095, _OBJSIZ_6_0_0_1_0_0_0_0_);
					tr2 = F619_5193(RTCW(loc8));
					tr2 = (RTNA((RTCW(tr2))), ((EIF_REFERENCE) 0));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,637,0xFFF9,1,901,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 3, 0);
					}
					tr4 = F1009_8627(loc21);
					((EIF_TYPED_VALUE *)tr3+1)->it_r = tr4;
					RTAR(tr3,tr4);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr4+1)->it_r = loc14;
					RTAR(tr4,loc14);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = tr4;
					RTAR(tr3,tr4);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A248_180, (EIF_POINTER) _A248_180, (EIF_POINTER)(F638_5326),tr3, 1, 0);
					}
					F1096_9769(RTCW(tr1), tr2, tr4);
					F1056_9244(RTCW(loc11), tr1);
				}
				F619_5221(RTCW(loc8));
			}
		}
		tb3 = '\0';
		tb4 = F1018_8687(RTCW(loc11));
		if ((EIF_BOOLEAN) !tb4) {
			ti4_1 = F1056_9233(RTCW(loc11));
			tb3 = (EIF_BOOLEAN) (ti4_1 > loc12);
		}
		if (tb3) {
			F1111_9892(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg7 != NULL) && (EIF_BOOLEAN) !arg8)) {
				(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_0_))(
					*(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(RTCW(arg7) + _REFACS_1_));
			}
		}
	} else {
		tr1 = F1054_9204(RTCW(arg5));
		loc22 = tr1;
		if (EIF_TEST(loc22)) {
			loc11 = RTLNS(eif_new_type(1110, 0x00).id, 1110, _OBJSIZ_6_1_0_1_0_0_0_0_);
			F1018_8683(RTCW(loc11));
			{
				static EIF_TYPE_INDEX typarr0[] = {618,24,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNS(typres0.id, 618, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F619_5188(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			tr2 = RTCCL(arg6);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc22 + _REFACS_1_), loc11, tr1, arg5, tr2);
			tb3 = '\0';
			tb4 = '\0';
			tb5 = F1018_8687(RTCW(loc11));
			if ((EIF_BOOLEAN) !tb5) {
				ti4_1 = F1056_9233(RTCW(loc11));
				tb4 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if (tb4) {
				tb3 = (EIF_BOOLEAN) !F1137_10484(Current);
			}
			if (tb3) {
				F1111_9892(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
			}
		}
	}
	tb3 = F613_5093(RTCW(loc2), loc1);
	if (tb3) {
		F613_5098(RTCW(loc2), loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_tab_navigation_state */
void F1136_10423 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_49_14_) = (EIF_NATURAL_8) arg1;
}

/* {EV_APPLICATION_I}.call_post_launch_actions */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1136_10428 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = F103_2471(Current);
		F637_5325(RTCW(tr1), NULL);
	} else {
		tr1 = F1136_10434(Current);
		F1136_10429(Current, tr1);
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.on_exception_action */
void F1136_10429 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1070_9469(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1058_9295(loc3);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL))) {
		tb2 = F445_4698(RTCV(F103_2484(Current)));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = F103_2484(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,183,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4743[Dtype(RTCW(tr1))-635])(tr1, tr2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc1 = RTLNSMART(eif_new_type(1071, 0).id);
		F1018_8683(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) loc1;
		F1136_10430(Current, loc1, arg1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.raise_default_exception_dialog */
void F1136_10430 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTCFDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc6);
	RTLR(5,loc4);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,loc9);
	RTLR(9,loc3);
	RTLR(10,arg1);
	RTLR(11,loc5);
	RTLR(12,loc7);
	RTLR(13,Current);
	RTLR(14,tr2);
	RTLR(15,tr3);
	RTLR(16,loc8);
	RTLR(17,loc13);
	RTLR(18,loc12);
	RTLIU(19);
	
	RTGC;
	loc1 = F184_3391(RTCW(arg2));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		loc1 = (EIF_REFERENCE) tr1;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\015';
		F988_8451(RTCW(loc1), tw1);
	}
	loc2 = RTLNS(eif_new_type(1086, 0x00).id, 1086, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc2));
	F1087_9687(RTCW(loc2));
	F1085_9654(RTCW(loc2));
	loc6 = RTLNS(eif_new_type(1028, 0x00).id, 1028, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(loc6));
	F1029_8896(RTCW(loc6), ((EIF_INTEGER_32) 4L));
	F1049_9097(RTCW(loc2), loc6);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1047_9084(RTCW(loc2), loc1);
	} else {
		tr1 = RTMS_EX_H("No trace available.",19,2146208046);
		F1047_9084(RTCW(loc2), tr1);
	}
	loc4 = RTLNS(eif_new_type(1064, 0x00).id, 1064, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc4));
	loc10 = RTLNS(eif_new_type(1063, 0x00).id, 1063, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc10));
	F1063_9386(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	F1063_9388(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	tr1 = RTLNS(eif_new_type(23, 0x00).id, 23, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(83,F24_516, (RTCW(tr1)));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	F1056_9244(RTCW(loc10), tr1);
	tr1 = F553_4894(RTCW(loc10));
	F1063_9390(RTCW(loc10), tr1);
	tr1 = F553_4894(RTCW(loc10));
	F1058_9305(RTCW(tr1), ((EIF_INTEGER_32) 32L), ((EIF_INTEGER_32) 32L));
	loc11 = RTLNS(eif_new_type(1080, 0x00).id, 1080, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc11));
	F1048_9094(RTCW(loc11));
	tr1 = RTMS_EX_H("The following uncaught exception has occurred:\012\012Click Ignore to continue or Quit to exit the application",104,940859246);
	F1047_9084(RTCW(loc11), tr1);
	F1056_9244(RTCW(loc10), loc11);
	F1056_9244(RTCW(loc4), loc10);
	F1063_9390(RTCW(loc4), loc10);
	loc9 = RTLNS(eif_new_type(1066, 0x00).id, 1066, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc9));
	loc3 = RTLNS(eif_new_type(1063, 0x00).id, 1063, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc3));
	F1059_9320(RTCW(loc9), loc3);
	F1063_9388(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	F1063_9386(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	F1056_9244(RTCW(loc3), loc2);
	tr1 = RTMS_EX_H("Exception Trace",15,1881935717);
	F1047_9084(RTCW(loc9), tr1);
	F1056_9244(RTCW(loc4), loc9);
	F1059_9320(RTCW(arg1), loc4);
	loc5 = RTLNS(eif_new_type(1063, 0x00).id, 1063, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc5));
	F1056_9244(RTCW(loc4), loc5);
	F1063_9390(RTCW(loc4), loc5);
	loc7 = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Ignore",6,1997112421);
	F1047_9082(RTCW(loc7), tr1);
	tr1 = F1015_8659(RTCW(loc7));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,1071,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A437_267, (EIF_POINTER) _A437_267, (EIF_POINTER)(F1070_9455),tr2, 1, 0);
	}
	F634_5271(RTCW(tr1), tr3);
	tr1 = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	F1056_9244(RTCW(loc5), tr1);
	F1056_9244(RTCW(loc5), loc7);
	F1063_9390(RTCW(loc5), loc7);
	loc8 = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Quit",4,1366649204);
	F1047_9082(RTCW(loc8), tr1);
	ti4_1 = F1039_9038(RTCW(loc7));
	F1058_9303(RTCW(loc8), ti4_1);
	tr1 = F1015_8659(RTCW(loc8));
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A500_68, (EIF_POINTER) _A500_68, (EIF_POINTER)(F1114_9912),tr2, 1, 0);
	}
	F634_5271(RTCW(tr1), tr3);
	F1056_9244(RTCW(loc5), loc8);
	F1063_9390(RTCW(loc5), loc8);
	F1063_9386(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	F1063_9388(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	tr1 = F184_3389(RTCW(arg2));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		loc12 = (EIF_REFERENCE) loc13;
	} else {
		loc12 = RTMS_EX_H("",0,0);
	}
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000c\000\000\000a\000\000\000u\000\000\000g\000\000\000h\000\000\000t\000\000\000 \000\000\000E\000\000\000x\000\000\000c\000\000\000e\000\000\000p\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000:\000\000\000 \000\000\000",20,182364448);
	tr2 = F981_8165(RTCW(loc12));
	tr1 = F988_8444(tr1, tr2);
	F1070_9464(RTCW(arg1), tr1);
	F1058_9304(RTCW(arg1), ((EIF_INTEGER_32) 350L));
	F1040_9047(RTCW(arg1), ((EIF_INTEGER_32) 500L), ((EIF_INTEGER_32) 300L));
	F1071_9484(RTCW(arg1));
	F1058_9293(RTCW(loc7));
	RTLE;
}

/* {EV_APPLICATION_I}.new_exception */
EIF_REFERENCE F1136_10434 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F119_2599(RTCV(RTOUCR(14,F182_3358, (Current))));
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_APPLICATION_I}.wake_up_gui_thread */
void F1136_10435 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_APPLICATION_I}.is_gui_thread */
EIF_BOOLEAN F1136_10436 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(78,F1136_10437, (Current));
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O3228[Dtype(tr1)-166]);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.is_gui_thread_cell */
static EIF_REFERENCE F1136_10437_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(78)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {169,940,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 169, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F170_3295(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1136_10437 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(78,F1136_10437_body,(Current));
}

/* {EV_APPLICATION_I}.help_handler */
void F1136_10443 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1137_10475(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1136_10387(Current, loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.contextual_help_procedure */
static EIF_REFERENCE F1136_10445_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(79)
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,8,901,907,907,907,931,931,931,907,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A500_303_2_3_4_5_6_7_8_9, (EIF_POINTER) _A500_303_2_3_4_5_6_7_8_9, (EIF_POINTER)(F1136_10446),tr1, 1, 8);
	}
	Result = (EIF_REFERENCE) tr4;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1136_10445 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(79,F1136_10445_body,(Current));
}

/* {EV_APPLICATION_I}.contextual_help */
void F1136_10446 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
		F1136_10447(Current);
		loc1 = F1052_9166(RTCV(RTOUCR(81,F1136_10407, (Current))));
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1136_10387(Current, loc1);
		}
	}
	RTLE;
}

/* {EV_APPLICATION_I}.disable_contextual_help */
void F1136_10447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1012_8636(loc1);
			F553_4914(RTCW(tr1), loc2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1058_9302(loc1, loc3);
		}
		F1058_9295(loc1);
	} else {
	}
	RTLE;
}

/* {EV_APPLICATION_I}.inline-agent#1 of create_target_menu */
EIF_BOOLEAN F1136_13711 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tr1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (RTNA((RTCW(arg2))), ((EIF_REFERENCE) 0));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tb1 = F983_8231(loc1, loc2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_APPLICATION_I}.inline-agent#2 of create_target_menu */
void F1136_13712 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(arg3))-600])(arg3, tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
	}
	RTLE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
