
#ifndef _C11_ev523_
#define _C11_ev523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1163_10970(EIF_REFERENCE);
extern void EIF_Minit523(void);
extern EIF_BOOLEAN F1164_10986(EIF_REFERENCE);
extern EIF_BOOLEAN F1164_10984(EIF_REFERENCE);
extern EIF_BOOLEAN F1164_10980(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
