
#ifndef _C11_ev544_
#define _C11_ev544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1184_11176(EIF_REFERENCE);
extern EIF_BOOLEAN F1184_11201(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit544(void);
extern EIF_REFERENCE F24_524(EIF_REFERENCE);
extern EIF_REFERENCE F136_2893(EIF_REFERENCE);
extern EIF_REFERENCE F24_521(EIF_REFERENCE);
extern long O8544[];
extern long O8937[];

#ifdef __cplusplus
}
#endif

#endif
