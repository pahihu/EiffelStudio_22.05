
#ifndef _C11_ev524_
#define _C11_ev524_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1164_10980(EIF_REFERENCE);
extern EIF_BOOLEAN F1164_10984(EIF_REFERENCE);
extern EIF_BOOLEAN F1164_10986(EIF_REFERENCE);
extern void EIF_Minit524(void);
extern EIF_BOOLEAN F1114_9914(EIF_REFERENCE);
extern EIF_BOOLEAN F1057_9271(EIF_REFERENCE);
extern char *(*R8795[])();
extern long O8497[];

#ifdef __cplusplus
}
#endif

#endif
