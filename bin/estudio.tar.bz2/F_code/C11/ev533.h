
#ifndef _C11_ev533_
#define _C11_ev533_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1173_11016(EIF_REFERENCE);
extern void F1173_11018(EIF_REFERENCE, EIF_REFERENCE);
extern void F1173_11020(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1173_11021(EIF_REFERENCE);
extern EIF_POINTER F1173_11023(EIF_REFERENCE);
extern void EIF_Minit533(void);
extern void F1281_12996(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1281_12992(EIF_REFERENCE);
extern EIF_INTEGER_32 F1281_12991(EIF_REFERENCE);
extern long O8818[];
extern long O8820[];

#ifdef __cplusplus
}
#endif

#endif
