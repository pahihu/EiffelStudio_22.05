/*
 * Code for class EV_CONTAINER_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CONTAINER_I}.interface_item */
EIF_REFERENCE F1186_11254 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8989[Dtype(Current)-1197])(Current);
	RTCT0("l_item /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_CONTAINER_I}.propagate_foreground_color */
void F1186_11265 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	tr1 = F1114_9915(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4302[Dtype(RTCW(tr1))-311])(tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {417,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = loc1;
		loc3 = RTRV(typres0, loc3);
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4447[Dtype(RTCW(loc3))-600])(loc3);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4407[Dtype(RTCW(loc1))-600])(loc1);
	loc5 = F1152_10825(Current);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4406[Dtype(RTCW(loc1))-600])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4405[Dtype(RTCW(loc1))-600])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7332[Dtype(RTCW(tr1))-1051])(tr1, loc5);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4405[Dtype(RTCW(loc1))-600])(loc1);
		loc2 = RTRV(eif_new_type(1058, 0x00), loc2);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1059_9327(RTCW(loc2));
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4420[Dtype(RTCW(loc1))-600])(loc1);
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCT0("cur /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4449[Dtype(RTCW(loc3))-600])(loc3, loc4);
	}
	RTLE;
}

/* {EV_CONTAINER_I}.propagate_background_color */
void F1186_11266 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	tr1 = F1114_9915(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4302[Dtype(RTCW(tr1))-311])(tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {417,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = loc1;
		loc3 = RTRV(typres0, loc3);
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4447[Dtype(RTCW(loc3))-600])(loc3);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4407[Dtype(RTCW(loc1))-600])(loc1);
	loc5 = F1152_10826(Current);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4406[Dtype(RTCW(loc1))-600])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4405[Dtype(RTCW(loc1))-600])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7333[Dtype(RTCW(tr1))-1051])(tr1, loc5);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4405[Dtype(RTCW(loc1))-600])(loc1);
		loc2 = RTRV(eif_new_type(1058, 0x00), loc2);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1059_9328(RTCW(loc2));
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4420[Dtype(RTCW(loc1))-600])(loc1);
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCT0("cur /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4449[Dtype(RTCW(loc3))-600])(loc3, loc4);
	}
	RTLE;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
