/*
 * Code for class EV_CONTAINER_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev547.h"
#include <ev_any_imp.h>
#include "eif_built_in.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1141_10624
static EIF_REFERENCE inline_F1141_10624 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1141_10624
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CONTAINER_IMP}.make */
void F1187_11281 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1185_11206(Current);
	tr1 = RTLNSMART(eif_new_type(941, 0).id);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9013[dtype-1186]) = (EIF_REFERENCE) tr1;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8689[dtype-1197])(Current);
	F1153_10836(Current, tp1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.container_widget */
EIF_POINTER F1187_11282 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8689[Dtype(Current)-1197])(Current);
}

/* {EV_CONTAINER_IMP}.client_width */
EIF_INTEGER_32 F1187_11283 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8754[Dtype(Current)-1197])(Current);
}

/* {EV_CONTAINER_IMP}.client_height */
EIF_INTEGER_32 F1187_11284 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8755[Dtype(Current)-1197])(Current);
}

/* {EV_CONTAINER_IMP}.background_pixmap */
EIF_REFERENCE F1187_11285 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O9027[Dtype(Current)-1186]);
}


/* {EV_CONTAINER_IMP}.replace */
void F1187_11286 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8989[dtype-1197])(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = *(EIF_REFERENCE *)(loc2 + O7088[Dtype(loc2)-1017]);
		loc1 = RTRV(eif_new_type(1184, 0x00), loc1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1187_11302(Current, loc1);
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9012[dtype-1197])(Current);
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8497[Dtype(loc1)-1140]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) R9024[dtype-1197])(Current, tp1, tp2);
		}
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O7088[Dtype(arg1)-1017]);
		loc1 = RTRV(eif_new_type(1184, 0x00), loc1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9012[dtype-1197])(Current);
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8497[Dtype(loc1)-1140]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32)) R9023[dtype-1197])(Current, tp1, tp2, ((EIF_INTEGER_32) 1L));
			F1187_11301(Current, loc1);
		}
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.set_radio_group */
void F1187_11289 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9013[Dtype(Current)-1186]);
	F942_8023(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.radio_group */
EIF_POINTER F1187_11290 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9013[Dtype(Current)-1186]);
	Result = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_0_0_0_0_0_);
	RTLE;
	return Result;
}

/* {EV_CONTAINER_IMP}.add_radio_button */
void F1187_11293 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1237, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(F1187_11290(Current) != tp1)) {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			tp2 = F1187_11290(Current);
			gtk_radio_button_set_group((GtkRadioButton*) tp1, (GSList*) tp2);
		} else {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 0);
		}
		tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		tp1 = (EIF_POINTER) gtk_radio_button_get_group((GtkRadioButton*) tp1);
		F1187_11289(Current, tp1);
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.remove_radio_button */
void F1187_11294 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc5);
	RTLIU(4);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1237, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tp1 = F1187_11290(Current);
		loc2 = (EIF_INTEGER_32) g_slist_length((GSList*) tp1);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
		tp1 = F1187_11290(Current);
		tp2 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		loc3 = (EIF_INTEGER_32) g_slist_index((GSList*) tp1, (gpointer) tp2);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc3) > ((EIF_INTEGER_32) 0L))) {
			tp1 = F1187_11290(Current);
			loc4 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) loc2);
		} else {
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tp1 = F1187_11290(Current);
				loc4 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			}
		}
		tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gtk_radio_button_set_group((GtkRadioButton*) tp1, (GSList*) tp3);
		tb1 = !loc4;
		if ((EIF_BOOLEAN) !tb1) {
			tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc4);
			loc5 = inline_F1141_10624(tp1);
			loc5 = RTRV(eif_new_type(1237, 0x00), loc5);
			RTCT0("an_item_imp_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tp1 = (RTNA((RTCW(loc5))), ((EIF_POINTER) 0));
			F1187_11289(Current, tp1);
		} else {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			F1187_11289(Current, tp2);
		}
		tb1 = (RTNA((RTCW(loc1))), ((EIF_BOOLEAN) 0));
		if (tb1) {
			tb1 = !F1187_11290(Current);
			if ((EIF_BOOLEAN) !tb1) {
				tp1 = F1187_11290(Current);
				tp1 = (EIF_POINTER) (((GSList *)tp1)->data);
				gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
			}
		} else {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.internal_set_background_pixmap */
void F1187_11295 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	tr1 = RTLNS(eif_new_type(33, 0x00).id, 33, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(43,F34_750, (RTCW(tr1)));
	F1153_10837(Current, tp1, tr1);
	tb1 = '\0';
	tb2 = '\0';
	loc3 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8689[dtype-1197])(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc3;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc3 != *(EIF_POINTER *)(Current + O8497[dtype-1140]));
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(33, 0x00).id, 33, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = RTOUCR(43,F34_750, (RTCW(tr1)));
		F1153_10837(Current, loc3, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9027[dtype-1186]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1280, 0x00), loc1);
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tp1 = F1281_12994(RTCW(loc1));
		loc2 = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) tp1);
		gtk_widget_show((GtkWidget*) loc2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8689[dtype-1197])(Current);
		gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc2);
	} else {
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.set_background_pixmap */
void F1187_11296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9027[Dtype(Current)-1186]) = (EIF_REFERENCE) tr1;
	F1187_11295(Current, arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.propagate_foreground_color */
void F1187_11298 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1186_11265(Current);
	tr1 = F1152_10825(Current);
	tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
	F1185_11247(Current, tr1, tp1);
	tb1 = '\0';
	tb2 = '\0';
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8689[dtype-1197])(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc1 != *(EIF_POINTER *)(Current + O8497[dtype-1140]));
	}
	if (tb1) {
		tr1 = F1152_10825(Current);
		F1185_11247(Current, tr1, loc1);
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.propagate_background_color */
void F1187_11299 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1186_11266(Current);
	tr1 = F1152_10826(Current);
	tp1 = *(EIF_POINTER *)(Current + O8497[Dtype(Current)-1140]);
	F1185_11248(Current, tr1, tp1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.destroy */
void F1187_11300 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1114_9915(Current);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4424[Dtype(RTCW(tr1))-600])(tr1);
	if (tb1) {
		tr1 = F1114_9915(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4431[Dtype(RTCW(tr1))-609])(tr1);
	}
	F1185_11241(Current);
	RTLE;
}

/* {EV_CONTAINER_IMP}.on_new_item */
void F1187_11301 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1187_11293(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8974[Dtype(RTCW(arg1))-1197])(arg1, Current);
	RTLE;
}

/* {EV_CONTAINER_IMP}.on_removed_item */
void F1187_11302 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8974[Dtype(RTCW(arg1))-1197])(arg1, NULL);
	F1187_11294(Current, arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.child_has_resized */
void F1187_11303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_CONTAINER_IMP}.set_parent_imp */
void F1187_11304 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1185_11240(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O9027[dtype-1186]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8975[dtype-1184]) == NULL))) {
		F1187_11295(Current, loc1);
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.gtk_insert_i_th */
void F1187_11305 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	gtk_container_add((GtkContainer*) arg1, (GtkWidget*) arg2);
}

/* {EV_CONTAINER_IMP}.gtk_container_remove */
void F1187_11306 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	gtk_container_remove((GtkContainer*) arg1, (GtkWidget*) arg2);
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
