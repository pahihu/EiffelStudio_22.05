/*
 * Code for class EV_PICK_AND_DROPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev543.h"
#include "eif_built_in.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F99_2278
static void inline_F99_2278 (EIF_POINTER arg1)
{
	gtk_menu_shell_cancel((GtkMenuShell*)arg1);
	;
}
#define INLINE_F99_2278
#endif
#ifndef INLINE_F99_2163
static EIF_POINTER inline_F99_2163 (EIF_POINTER arg1)
{
	return gtk_widget_get_display ((GtkWidget *)arg1)
	;
}
#define INLINE_F99_2163
#endif
#ifndef INLINE_F6_133
static EIF_INTEGER_32 inline_F6_133 (void)
{
	return GDK_SEAT_CAPABILITY_ALL;
	;
}
#define INLINE_F6_133
#endif
#ifndef INLINE_F96_1400
static void inline_F96_1400 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F96_1400
#endif
#ifndef INLINE_F11_150
static EIF_POINTER inline_F11_150 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F11_150
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_IMP}.button_actions_handled_by_signals */
EIF_BOOLEAN F1183_11144 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_pointer_motion */
void F1183_11145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_16 loc5 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc6 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc7 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc8 = (EIF_INTEGER_16) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc9);
	RTLIU(6);
	
	RTGC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc4 = (EIF_REFERENCE) Current;
	loc1 = Current;
	loc1 = RTRV(eif_new_type(1154, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = '\0';
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8922[dtype-1197])(Current)) {
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O8734[Dtype(loc1)-1154]);
			if (!tb3) {
				tr1 = F1137_10561(RTCV(RTOUCR(49,F1141_10647, (Current))));
				tb2 = (EIF_BOOLEAN)(tr1 == loc1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
			ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
			tr8_1 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 3L));
			tr8_2 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 4L));
			tr8_3 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 5L));
			ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
			ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
			F1155_10898(RTCW(loc1), ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		} else {
			tb1 = '\0';
			tb2 = '\0';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O8734[Dtype(loc1)-1154]);
			if (tb3) {
				tb2 = F1182_11116(Current);
			}
			if (tb2) {
				tr1 = F1137_10560(RTCV(RTOUCR(49,F1141_10647, (Current))));
				tb1 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			if (tb1) {
				loc5 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O2877[Dtype(loc1)-135]);
				loc6 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O2878[Dtype(loc1)-135]);
				tb1 = '\01';
				ti4_1 = (EIF_INTEGER_32) loc5;
				ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
				ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
				ti4_2 = ((EIF_INTEGER_32) 3L);
				if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
					ti4_1 = (EIF_INTEGER_32) loc6;
					ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
					ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
					ti4_2 = ((EIF_INTEGER_32) 3L);
					tb1 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
				}
				if (tb1) {
					loc7 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O8735[Dtype(loc1)-1154]);
					loc8 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O8736[Dtype(loc1)-1154]);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					F1155_10906(RTCW(loc1));
					ti4_1 = (EIF_INTEGER_32) loc5;
					ti4_2 = (EIF_INTEGER_32) loc6;
					ti4_3 = (EIF_INTEGER_32) loc7;
					ti4_4 = (EIF_INTEGER_32) loc8;
					F1183_11164(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 1, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, ti4_3, ti4_4, (EIF_BOOLEAN) 0);
				}
			}
		}
		tr1 = F1137_10561(RTCV(RTOUCR(49,F1141_10647, (Current))));
		if ((EIF_BOOLEAN)(tr1 == loc1)) {
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	tb1 = '\0';
	if (loc3) {
		tr1 = F1137_10560(RTCV(RTOUCR(49,F1141_10647, (Current))));
		tb1 = (EIF_BOOLEAN)(tr1 == loc4);
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
		ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
		tr8_1 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		tr8_2 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		tr8_3 = F902_6882(RTCW(arg1), ((EIF_INTEGER_32) 5L));
		ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
		ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
		F1182_11129(Current, ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	tb1 = '\0';
	if (loc2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8914[dtype-1197])(Current);
		loc9 = tr1;
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		F637_5325(loc9, arg1);
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_capture */
void F1183_11148 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1183_11150(Current)) {
		loc2 = (EIF_POINTER) gtk_grab_get_current();
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 != tp1)) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_MENU((loc2)))) {
				inline_F99_2278(loc2);
			}
		}
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8547[dtype-1143])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8546[dtype-1143])(Current);
		}
		loc1 = *(EIF_REFERENCE *)(Current + O7965[dtype-1113]);
		loc1 = RTRV(eif_new_type(1057, 0x00), loc1);
		tr1 = RTOUCR(49,F1141_10647, (Current));
		F1136_10376(RTCW(tr1), loc1);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[dtype-1143])(Current);
		gtk_grab_add((GtkWidget*) tp1);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1142_10681(Current))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8917[dtype-1197])(Current);
		}
		F1137_10572(RTCV(RTOUCR(49,F1141_10647, (Current))));
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.disable_capture */
void F1183_11149 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1183_11150(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[dtype-1143])(Current);
		gtk_grab_remove((GtkWidget*) tp1);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1142_10681(Current))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8918[dtype-1197])(Current);
		}
		tr1 = RTOUCR(49,F1141_10647, (Current));
		F1136_10376(RTCW(tr1), NULL);
	}
	F1137_10571(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.has_capture */
EIF_BOOLEAN F1183_11150 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(49,F1141_10647, (Current))) + _REFACS_29_);
	if (!(EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + O7965[Dtype(Current)-1113]))) {
		tr1 = F1137_10560(RTCV(RTOUCR(49,F1141_10647, (Current))));
		Result = (EIF_BOOLEAN)(tr1 == Current);
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.grab_keyboard_and_mouse */
void F1183_11151 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[dtype-1143])(Current);
	loc2 = inline_F99_2163(tp1);
	loc3 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc2);
	F1137_10572(RTCV(RTOUCR(49,F1141_10647, (Current))));
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[dtype-1143])(Current);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	ti4_1 = inline_F6_133();
	loc1 = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) loc3, (GdkWindow*) tp1, (GdkSeatCapabilities) ti4_1, (gboolean) (EIF_BOOLEAN) 1, (GdkCursor*) loc4, (const GdkEvent*) loc4, (GdkSeatGrabPrepareFunc) loc4, (gpointer) loc4);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.release_keyboard_and_mouse */
void F1183_11152 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[Dtype(Current)-1143])(Current);
	loc1 = inline_F99_2163(tp1);
	loc2 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc1);
	gdk_seat_ungrab((GdkSeat*) loc2);
	F1137_10571(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.activate_docking_source_hint */
void F1183_11153 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(49,F1141_10647, (Current));
	F1137_10556(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.deactivate_docking_source_hint */
void F1183_11154 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1137_10557(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.draw_rubber_band */
void F1183_11155 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1136_10415(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.erase_rubber_band */
void F1183_11156 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1136_10416(RTCV(RTOUCR(49,F1141_10647, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_transport */
void F1183_11157 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8883[Dtype(Current)-1181]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pre_pick_steps */
void F1183_11159 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8540[dtype-1143])(Current);
	tp1 = inline_F99_2163(tp1);
	inline_F96_1400(tp1);
	tr1 = F1182_11131(Current);
	F1182_11130(Current, tr1);
	loc1 = *(EIF_REFERENCE *)(Current + O8858[dtype-1181]);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTOUCR(49,F1141_10647, (Current));
		tr2 = RTCCL(loc1);
		F1137_10553(RTCW(tr1), Current, tr2);
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1267[dtype-85]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O1267[dtype-85]);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,907,907,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		(RTNA((RTCW(tr1), tr2)));
	}
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O2888[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O2889[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O8888[dtype-1181]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O8889[dtype-1181]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
		tr1 = RTOUCR(49,F1141_10647, (Current));
		F1136_10411(RTCW(tr1), arg3, arg4);
	} else {
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8888[dtype-1181]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8754[dtype-1197])(Current))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8754[dtype-1197])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O8888[dtype-1181]) = (EIF_INTEGER_16) ti2_1;
		}
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8889[dtype-1181]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8755[dtype-1197])(Current))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8755[dtype-1197])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O8889[dtype-1181]) = (EIF_INTEGER_16) ti2_1;
		}
		tr1 = RTOUCR(49,F1141_10647, (Current));
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8888[dtype-1181]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8889[dtype-1181]);
		ti4_2 = (EIF_INTEGER_32) ti2_1;
		F1136_10411(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
	}
	F1182_11136(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.able_to_transport */
EIF_BOOLEAN F1183_11162 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	tb2 = '\0';
	if (F1182_11116(Current)) {
		tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8922[Dtype(Current)-1197])(Current);
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1182_11115(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1182_11118(Current);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_mouse_button_event */
void F1183_11163 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != ti4_1);
	loc1 = RTOUCR(49,F1141_10647, (Current));
	loc3 = F1137_10559(RTCW(loc1));
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
	loc2 = F1142_10681(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb1 = F1137_10559(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				loc4 = Current;
				loc4 = RTRV(eif_new_type(1154, 0x00), loc4);
				tb1 = '\0';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
					tb2 = (EIF_BOOLEAN)(loc4 != NULL);
				}
				if (tb2) {
					tb2 = '\01';
					if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8922[dtype-1197])(Current)) {
						tb2 = F1183_11162(Current, arg4);
					}
					tb1 = tb2;
				}
				if (tb1) {
					F1155_10894(RTCW(loc4), arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
				}
				if (tb1) {
					F1155_10905(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
			} else {
				tb1 = '\01';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
					tb3 = '\0';
					tb4 = '\0';
					if (F1182_11115(Current)) {
						tb4 = (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 3L));
					}
					if (tb4) {
						tb3 = (EIF_BOOLEAN) !F1182_11118(Current);
					}
					tb2 = tb3;
				}
				if (!tb2) {
					tb1 = F1183_11166(Current, arg4, loc6);
				}
				if (tb1) {
					F1183_11164(Current, arg2, arg3, arg4, loc6, arg5, arg6, arg7, arg8, arg9, (EIF_BOOLEAN) 0);
					tr1 = *(EIF_REFERENCE *)(Current + O8858[dtype-1181]);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
				}
			}
		} else {
			loc5 = (EIF_REFERENCE) Current;
			loc4 = loc5;
			loc4 = RTRV(eif_new_type(1154, 0x00), loc4);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
			}
			if (tb1) {
				F1155_10905(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
				tr1 = F1137_10560(RTCW(loc1));
				tb1 = (EIF_BOOLEAN)(tr1 == loc5);
			}
			if (tb1) {
				F1183_11167(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
		}
		if (loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R8915[dtype-1197])(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.start_transport */
void F1183_11164 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_BOOLEAN arg10)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	F1182_11135(Current, arg1, arg2, arg8, arg9);
	loc2 = *(EIF_REFERENCE *)(Current + O8858[Dtype(Current)-1181]);
	F1182_11102(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		{
			EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,901,0,0,907,907,907,907,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
		RTAR(tr1,loc2);
		((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+4)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr1+5)->it_i4 = arg8;
		((EIF_TYPED_VALUE *)tr1+6)->it_i4 = arg9;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {975,0xFFF9,0,901,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2= RTLNRF(typres0.id, (EIF_POINTER) __A543_232, (EIF_POINTER) _A543_232, (EIF_POINTER)(0),tr1, 1, 0);
		}
		loc1 = (EIF_REFERENCE) tr2;
	}
	if (F1183_11166(Current, arg3, arg4)) {
		tr1 = RTOUCR(49,F1141_10647, (Current));
		tr2 = F1183_11165(Current);
		tr3 = RTCCL(loc2);
		F1136_10420(RTCW(tr1), arg1, arg2, arg8, arg9, tr2, tr3, loc1, arg10);
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_));
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pebble_source */
EIF_REFERENCE F1183_11165 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1114_9915(Current);
}

/* {EV_PICK_AND_DROPABLE_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1183_11166 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1182_11117(Current)) {
		tb2 = F1182_11118(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.end_transport */
void F1183_11167 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc1);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	F1183_11149(Current);
	loc3 = RTOUCR(49,F1141_10647, (Current));
	F1183_11154(Current);
	F1183_11156(Current);
	F1182_11136(Current, (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN) !F1114_9914(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8544[dtype-1141]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1142_10668(Current, loc6);
		} else {
			tp1 = *(EIF_POINTER *)(Current + O8497[dtype-1140]);
			loc5 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc5 != tp1)) {
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp1 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				tp2 = tp1;
				gdk_window_set_cursor((GdkWindow*) loc5, (GdkCursor*) tp2);
			}
		}
	}
	loc4 = *(EIF_REFERENCE *)(Current + O8858[dtype-1181]);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		tr1 = RTCCL(loc4);
		F1137_10554(RTCW(loc3), tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc4;
		RTAR(tr1,loc4);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = '\01';
		if (!F1183_11162(Current, arg3)) {
			tb1 = F1183_11166(Current, arg3, (EIF_BOOLEAN) 0);
		}
		if (tb1) {
			loc1 = F1182_11131(Current);
			tb1 = '\0';
			loc7 = loc1;
			if (EIF_TEST(loc7)) {
				tr1 = F1009_8627(loc7);
				tr2 = RTCCL(loc4);
				tb2 = F638_5328(RTCW(tr1), tr2);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = F1009_8627(loc7);
				F638_5326(RTCW(tr1), loc2);
				tr1 = F103_2478(RTCW(loc3));
				F638_5326(RTCW(tr1), loc2);
			} else {
				tr1 = F103_2480(RTCW(loc3));
				F638_5326(RTCW(tr1), loc2);
			}
		} else {
			tr1 = F103_2480(RTCW(loc3));
			F638_5326(RTCW(tr1), loc2);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1269[dtype-85]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O1269[dtype-85]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,901,865,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
			RTAR(tr2,loc1);
			(RTNA((RTCW(tr1), tr2)));
		}
	}
	F1183_11157(Current);
	F1183_11168(Current, arg3);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.post_drop_steps */
void F1183_11168 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(49,F1141_10647, (Current));
	F1136_10411(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1182_11102(Current);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.real_pointed_target */
EIF_REFERENCE F1183_11169 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	loc7 = RTOUCR(49,F1141_10647, (Current));
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_49_8_);
	if (tb1) {
	} else {
		F1137_10566(RTCW(loc7));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc1 = eif_pointer_item(RTCW(tr1),1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc2 = eif_integer_32_item(RTCW(tr1),2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc3 = eif_integer_32_item(RTCW(tr1),3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		loc4 = F1137_10577(RTCW(loc7), loc1);
		loc4 = RTRV(eif_new_type(1182, 0x00), loc4);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc4) + O8497[Dtype(loc4)-1140]);
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
		}
		if (tb2) {
			tb2 = F1114_9914(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
			tr2 = F1114_9915(RTCW(loc4));
			ti4_1 = F862_6671(RTCW(tr2));
			tb1 = F613_5065(RTCW(tr1), ti4_1);
			if (tb1) {
				Result = *(EIF_REFERENCE *)(RTCW(loc4) + O7965[Dtype(loc4)-1113]);
			}
			loc5 = loc4;
			loc5 = RTRV(eif_new_type(223, 0x00), loc5);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tp1 = *(EIF_POINTER *)(RTCW(loc4) + O8497[Dtype(loc4)-1140]);
				tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
				tp2 = inline_F11_150();
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp3 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				tp4 = tp3;
				loc1 = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) tp1, (GdkDevice *) tp2, (gint*) (EIF_INTEGER_32 *) &(loc2), (gint*) (EIF_INTEGER_32 *) &(loc3), (GdkModifierType*) tp4);
				loc6 = F1232_11931(RTCW(loc5), loc2, loc3);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
					tr2 = F1114_9915(RTCW(loc6));
					ti4_1 = F862_6671(RTCW(tr2));
					tb2 = F613_5065(RTCW(tr1), ti4_1);
					tb1 = tb2;
				}
				if (tb1) {
					Result = *(EIF_REFERENCE *)(RTCW(loc6) + O7965[Dtype(loc6)-1113]);
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.inline-agent#1 of start_transport */
void F1183_13720 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8858[dtype-1181]) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F1183_11148(Current);
		F1183_11159(Current, arg2, arg3, arg4, arg5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O1273[dtype-85]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O1273[dtype-85]);
			tr2 = RTCCL(arg1);
			tb2 = F638_5328(RTCW(tr1), tr2);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O8862[dtype-1181]);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				F1142_10668(Current, loc1);
			} else {
				tr1 = RTOUCR(265,F136_2889, (Current));
				F1142_10668(Current, tr1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O8863[dtype-1181]);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				F1142_10668(Current, loc2);
			} else {
				tr1 = RTOUCR(266,F136_2890, (Current));
				F1142_10668(Current, tr1);
			}
		}
	}
	tr1 = F1183_11165(Current);
	F1183_11153(Current, arg4, arg5, tr1);
	RTLE;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
