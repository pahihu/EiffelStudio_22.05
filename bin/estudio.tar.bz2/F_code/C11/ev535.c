/*
 * Code for class EV_FONTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev535.h"
#include "eif_built_in.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F13_240
static EIF_POINTER inline_F13_240 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F13_240
#endif
#ifndef INLINE_F13_243
static EIF_POINTER inline_F13_243 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F13_243
#endif
#ifndef INLINE_F13_244
static void inline_F13_244 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F13_244
#endif
#ifndef INLINE_F99_2322
static void inline_F99_2322 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_label_set_attributes ((GtkLabel *)arg1, (PangoAttrList *)arg2);
	;
}
#define INLINE_F99_2322
#endif
#ifndef INLINE_F13_245
static void inline_F13_245 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F13_245
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONTABLE_IMP}.font */
EIF_REFERENCE F1175_11029 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + O8825[Dtype(Current)-1174]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = RTLNS(eif_new_type(1028, 0x00).id, 1028, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1018_8683(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {EV_FONTABLE_IMP}.set_font */
void F1175_11030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8825[dtype-1174]) != arg1)) {
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8825[dtype-1174]) = (EIF_REFERENCE) loc1;
		RTCT0("attached {EV_FONT_IMP} l_private_font.implementation as font_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1134, 0x00),loc4);
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8824[dtype-1208])(Current);
		if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_LABEL((tp1)))) {
			loc2 = inline_F13_240();
			tp1 = *(EIF_POINTER *)(loc4+ _PTROFF_3_2_0_8_0_0_);
			loc3 = inline_F13_243(tp1);
			inline_F13_244(loc2, loc3);
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8824[dtype-1208])(Current);
			inline_F99_2322(tp1, loc2);
			inline_F13_245(loc2);
		} else {
		}
	}
	RTLE;
}

/* {EV_FONTABLE_IMP}.fontable_widget */
EIF_POINTER F1175_11032 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8823[Dtype(Current)-1208])(Current);
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
