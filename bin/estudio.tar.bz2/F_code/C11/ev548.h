
#ifndef _C11_ev548_
#define _C11_ev548_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1188_11310(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit548(void);
extern void F1145_10778(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_10776(EIF_REFERENCE);
extern void F1145_10774(EIF_REFERENCE);
extern EIF_REFERENCE F1145_10764(EIF_REFERENCE);
extern EIF_BOOLEAN F1145_10767(EIF_REFERENCE);
extern EIF_REFERENCE F1145_10762(EIF_REFERENCE);
extern char *(*R8959[])();
extern long O7088[];

#ifdef __cplusplus
}
#endif

#endif
