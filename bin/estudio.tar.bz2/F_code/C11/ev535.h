
#ifndef _C11_ev535_
#define _C11_ev535_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1175_11029(EIF_REFERENCE);
extern void F1175_11030(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1175_11032(EIF_REFERENCE);
extern void EIF_Minit535(void);
extern void F1018_8683(EIF_REFERENCE);
extern char *(*R8823[])();
extern char *(*R8824[])();
extern long O8825[];

#ifdef __cplusplus
}
#endif

#endif
