/*
 * Code for class EV_MENU_ITEM_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev511.h"
#include <ev_any_imp.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1141_10624
static EIF_REFERENCE inline_F1141_10624 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1141_10624
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_LIST_IMP}.insert_i_th */
void F1151_10813 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1260, 0x00), loc1);
	RTCT0("an_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]);
	F1151_10814(Current, loc1, arg2);
	loc3 = loc1;
	loc3 = RTRV(eif_new_type(1263, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		F1145_10777(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]) == (EIF_INTEGER_32) (F1146_10799(Current) + ((EIF_INTEGER_32) 1L)))) {
				tb2 = '\0';
				tr1 = F1146_10798(Current, *(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]));
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_3_);
					tb2 = F1151_10816(Current, tr1);
				}
				tb1 = tb2;
			}
			if (tb1) break;
			loc4 = F1146_10798(Current, *(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]));
			loc4 = RTRV(eif_new_type(1262, 0x00), loc4);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				if ((EIF_BOOLEAN)(tp1 != loc7)) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			}
			F1145_10776(Current);
		}
	} else {
		loc4 = loc1;
		loc4 = RTRV(eif_new_type(1262, 0x00), loc4);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			loc3 = F1151_10815(Current, arg2);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp2 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				if ((EIF_BOOLEAN)(tp1 != tp2)) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			} else {
				(RTNA((RTCW(loc4), F1151_10820(Current))));
				loc6 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp1 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				if ((EIF_BOOLEAN)(F1151_10820(Current) != tp1)) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				F1151_10819(Current, tp1);
			}
		}
	}
	if ((EIF_BOOLEAN) !F1151_10816(Current, loc1)) {
		loc5 = loc1;
		loc5 = RTRV(eif_new_type(1261, 0x00), loc5);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tb2 = (RTNA((RTCW(loc5))), ((EIF_BOOLEAN) 0));
			if (tb2) {
				(RTNA((RTCW(loc5))));
			}
		}
	}
	F1145_10777(Current, loc2);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.insert_menu_item */
void F1151_10814 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = F1261_12517(RTCW(arg1));
	gtk_menu_shell_insert((GtkMenuShell*) tp1, (GtkWidget*) tp2, (gint) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	tr1 = *(EIF_REFERENCE *)(Current + O8655[dtype-1145]);
	F619_5223(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + O8655[dtype-1145]);
	tr2 = F1114_9915(RTCW(arg1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4574[Dtype(RTCW(tr1))-618])(tr1, tr2);
	F1254_12494(RTCW(arg1), Current);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.separator_imp_by_index */
EIF_REFERENCE F1151_10815 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = F1145_10764(Current);
	F1145_10774(Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]) == (EIF_INTEGER_32) (F1146_10799(Current) + ((EIF_INTEGER_32) 1L)))) {
			tb1 = (EIF_BOOLEAN)(arg1 == loc2);
		}
		if (tb1) break;
		loc3 = F1146_10798(Current, *(EIF_INTEGER_32 *)(Current + O8621[dtype-1144]));
		loc3 = RTRV(eif_new_type(1098, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			Result = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
			Result = RTRV(eif_new_type(1263, 0x00), Result);
		}
		F1145_10776(Current);
		loc2++;
	}
	F1145_10778(Current, loc1);
	RTLE;
	return Result;
}

/* {EV_MENU_ITEM_LIST_IMP}.is_menu_separator_imp */
EIF_BOOLEAN F1151_10816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1263, 0x00), loc1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != NULL);
}

/* {EV_MENU_ITEM_LIST_IMP}.remove_i_th */
void F1151_10817 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc8);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8655[dtype-1145]);
	tr1 = F619_5194(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1253, 0x00), loc1);
	RTCT0("item_imp_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8497[Dtype(loc1)-1140]);
	gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) tp2);
	tr1 = *(EIF_REFERENCE *)(Current + O8655[dtype-1145]);
	F619_5223(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8655[dtype-1145]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4446[Dtype(RTCW(tr1))-600])(tr1);
	F1254_12494(RTCW(loc1), NULL);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1262, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb1 = (RTNA((RTCW(loc2))), ((EIF_BOOLEAN) 0));
		if (tb1) {
			tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) g_slist_length((GSList*) tp1) > ((EIF_INTEGER_32) 1L))) {
				tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
				loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 0L));
				tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
				if ((EIF_BOOLEAN)(loc6 == tp1)) {
					tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
					loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 1L));
				}
				loc2 = inline_F1141_10624(loc6);
				loc2 = RTRV(eif_new_type(1262, 0x00), loc2);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					(RTNA((RTCW(loc2))));
				}
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
			gtk_radio_menu_item_set_group((GtkRadioMenuItem*) tp1, (GSList*) loc7);
		}
	} else {
		loc3 = loc1;
		loc3 = RTRV(eif_new_type(1263, 0x00), loc3);
		loc8 = *(EIF_REFERENCE *)(Current + O7965[dtype-1113]);
		RTCT0("l_interface /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti4_1 = F1056_9233(RTCW(loc8));
			tb1 = (EIF_BOOLEAN) (arg1 <= ti4_1);
		}
		if (tb1) {
			loc3 = F1151_10815(Current, arg1);
			loc4 = F1056_9227(RTCW(loc8));
			F1056_9239(RTCW(loc8), arg1);
			for (;;) {
				tb1 = '\01';
				tb2 = F577_4933(RTCW(loc8));
				if (!tb2) {
					tr1 = F1056_9226(RTCW(loc8));
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
					tb1 = F1151_10816(Current, tr1);
				}
				if (tb1) break;
				tr1 = F1056_9226(RTCW(loc8));
				loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
				loc2 = RTRV(eif_new_type(1262, 0x00), loc2);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc2), tp1)));
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc3), tp1)));
					} else {
						(RTNA((RTCW(loc2), F1151_10820(Current))));
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						F1151_10819(Current, tp1);
					}
					(RTNA((RTCW(loc2))));
				}
				F1056_9238(RTCW(loc8));
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && (EIF_BOOLEAN)(loc3 == NULL))) {
				F1151_10819(Current, loc7);
			}
			F1056_9239(RTCW(loc8), loc4);
		}
	}
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group_ref */
EIF_REFERENCE F1151_10818 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNS(eif_new_type(941, 0x00).id, 941, _OBJSIZ_0_0_0_0_0_1_0_0_);
		tr1 = RTCCL(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MENU_ITEM_LIST_IMP}.set_radio_group */
void F1151_10819 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1151_10818(Current);
	F942_8023(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group */
EIF_POINTER F1151_10820 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_POINTER *)(RTCV(F1151_10818(Current))+ _PTROFF_0_0_0_0_0_0_);
	RTLE;
	return Result;
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
