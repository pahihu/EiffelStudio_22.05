/*
 * Code for class EV_PICK_AND_DROPABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev542.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_I}.reset_pebble_function */
void F1182_11102 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8859[dtype-1181]) != NULL)) {
		*(EIF_REFERENCE *)(Current + O8858[dtype-1181]) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_pick_and_drop */
EIF_BOOLEAN F1182_11115 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8891[dtype-1181]) == ((EIF_INTEGER_8) 0L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8891[dtype-1181]) == ((EIF_INTEGER_8) 3L)));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_drag_and_drop */
EIF_BOOLEAN F1182_11116 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8891[Dtype(Current)-1181]) == ((EIF_INTEGER_8) 1L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_target_menu */
EIF_BOOLEAN F1182_11117 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8891[Dtype(Current)-1181]) == ((EIF_INTEGER_8) 2L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_configurable_target_menu */
EIF_BOOLEAN F1182_11118 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8891[Dtype(Current)-1181]) == ((EIF_INTEGER_8) 3L));
}

/* {EV_PICK_AND_DROPABLE_I}.execute */
void F1182_11129 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1183_11156(Current);
	ti2_1 = (EIF_INTEGER_16) arg6;
	*(EIF_INTEGER_16 *)(Current + O2888[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg7;
	*(EIF_INTEGER_16 *)(Current + O2889[dtype-135]) = (EIF_INTEGER_16) ti2_1;
	tr1 = F1182_11141(Current);
	F1136_10419(RTCW(tr1), arg6, arg7);
	F1183_11155(Current);
	loc1 = F1182_11131(Current);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1053, 0x00), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(264,F1182_11142, (Current))) + _REFACS_1_);
	loc3 = F1130_10183(RTCW(tr1));
	loc3 = RTRV(eif_new_type(1136, 0x00), loc3);
	RTCT0("application /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F103_2482(RTCW(loc3));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,901,907,907,1053,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr2+3)->it_r = loc2;
		RTAR(tr2,loc2);
		F637_5325(RTCW(tr1), tr2);
	}
	F1182_11130(Current, loc1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.update_pointer_style */
void F1182_11130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8858[dtype-1181]);
	loc1 = RTCCL(tr1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1))) {
		tr1 = F1009_8627(RTCW(arg1));
		tr2 = RTCCL(loc1);
		tb2 = F638_5328(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O8862[dtype-1181]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1142_10668(Current, loc2);
		} else {
			tr1 = RTOUCR(265,F136_2889, (Current));
			F1142_10668(Current, tr1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8863[dtype-1181]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1142_10668(Current, loc3);
		} else {
			tr1 = RTOUCR(266,F136_2890, (Current));
			F1142_10668(Current, tr1);
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.pointed_target */
EIF_REFERENCE F1182_11131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = F1183_11169(Current);
	Result = (EIF_REFERENCE) loc1;
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1057, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O7088[Dtype(loc2)-1017]);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O8935[Dtype(tr1)-1183]);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2888[dtype-135]);
			loc4 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1039_9034(RTCW(loc2));
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ti4_1);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2889[dtype-135]);
			loc5 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1039_9035(RTCW(loc2));
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ti4_1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,907,907,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc4;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc5;
			Result = F977_8097(RTCW(loc3), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.call_pebble_function */
void F1182_11135 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8859[dtype-1181]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,901,907,907,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6680[Dtype(loc1)-976])(loc1, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8858[dtype-1181]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.modify_widget_appearance */
void F1182_11136 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = F1137_10489(RTCV(F1182_11141(Current)));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4407[Dtype(RTCW(loc2))-600])(loc2);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4406[Dtype(RTCW(loc2))-600])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4405[Dtype(RTCW(loc2))-600])(loc2);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O7088[Dtype(tr1)-1017]);
		loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
		RTCT0("window_implementation_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1204_11483(RTCW(loc1), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4420[Dtype(RTCW(loc2))-600])(loc2);
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.application_implementation */
EIF_REFERENCE F1182_11141 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(264,F1182_11142, (Current))) + _REFACS_1_);
	Result = F1130_10183(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.environment */
static EIF_REFERENCE F1182_11142_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(264)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1024, 0x00).id, 1024, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1182_11142 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(264,F1182_11142_body,(Current));
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
