
#ifndef _C21_fi1009_
#define _C21_fi1009_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F453_4698(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern char *(*R4453[])();

#ifdef __cplusplus
}
#endif

#endif
