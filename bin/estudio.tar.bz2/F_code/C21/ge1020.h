
#ifndef _C21_ge1020_
#define _C21_ge1020_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F738_5524(EIF_REFERENCE);
extern EIF_INTEGER_32 F738_5526(EIF_REFERENCE);
extern EIF_BOOLEAN F738_5533(EIF_REFERENCE);
extern void F738_5538(EIF_REFERENCE);
extern void F738_5539(EIF_REFERENCE);
extern EIF_REFERENCE F738_5540(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern char *(*R4878[])();
extern char *(*R4851[])();
extern long O4877[];
extern long O4879[];

#ifdef __cplusplus
}
#endif

#endif
