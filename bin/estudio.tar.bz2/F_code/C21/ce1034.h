
#ifndef _C21_ce1034_
#define _C21_ce1034_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F169_3294(EIF_REFERENCE);
extern void F169_3295(EIF_REFERENCE, EIF_NATURAL_64);
extern void F169_3296(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1034(void);

#ifdef __cplusplus
}
#endif

#endif
