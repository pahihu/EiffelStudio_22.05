
#ifndef _C21_ce1036_
#define _C21_ce1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F171_3294(EIF_REFERENCE);
extern void F171_3295(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F171_3296(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1036(void);

#ifdef __cplusplus
}
#endif

#endif
