/*
 * Code for class CONTAINER [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1001.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F306_4469 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O4298[Dtype(Current)-297]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONTAINER}.compare_references */
void F306_4470 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O4298[Dtype(Current)-297]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

void EIF_Minit1001 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
