
#ifndef _C21_se1039_
#define _C21_se1039_

#ifdef __cplusplus
extern "C" {
#endif

extern void F489_4711(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1039(void);
extern void F627_5229(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
