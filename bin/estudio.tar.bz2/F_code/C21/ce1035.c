/*
 * Code for class CELL [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce1035.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_BOOLEAN F170_3294 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O3228[Dtype(Current)-166]);
}


/* {CELL}.put */
void F170_3295 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3228[Dtype(Current)-166]) = (EIF_BOOLEAN) arg1;
}

/* {CELL}.replace */
void F170_3296 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3228[Dtype(Current)-166]) = (EIF_BOOLEAN) arg1;
}

void EIF_Minit1035 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
