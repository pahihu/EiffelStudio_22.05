
#ifndef _C21_co1001_
#define _C21_co1001_

#ifdef __cplusplus
extern "C" {
#endif

extern void F306_4469(EIF_REFERENCE);
extern void F306_4470(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
