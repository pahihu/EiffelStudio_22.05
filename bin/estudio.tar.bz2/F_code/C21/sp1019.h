
#ifndef _C21_sp1019_
#define _C21_sp1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F776_5568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F776_5569(EIF_REFERENCE);
extern EIF_REFERENCE F776_5570(EIF_REFERENCE);
extern EIF_INTEGER_32 F776_5571(EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern EIF_INTEGER_32 F793_5702(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
