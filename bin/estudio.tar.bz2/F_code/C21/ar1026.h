
#ifndef _C21_ar1026_
#define _C21_ar1026_

#ifdef __cplusplus
extern "C" {
#endif

extern void F764_5562(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F764_5563(EIF_REFERENCE);
extern EIF_REFERENCE F764_5564(EIF_REFERENCE);
extern EIF_REFERENCE F764_5566(EIF_REFERENCE);
extern EIF_INTEGER_32 F764_5567(EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
