/*
 * Code for class DYNAMIC_CHAIN [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1029.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F572_4918 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F572_4924 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F626_5225(Current, arg1);
	if ((EIF_BOOLEAN) !F333_4628(Current)) {
		F626_5242(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F572_4925 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F626_5219(Current);
	F626_5225(Current, arg1);
	for (;;) {
		if (F333_4628(Current)) break;
		F626_5242(Current);
		F626_5225(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1029 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
