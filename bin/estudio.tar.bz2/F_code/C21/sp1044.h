
#ifndef _C21_sp1044_
#define _C21_sp1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F777_5568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F777_5569(EIF_REFERENCE);
extern EIF_REFERENCE F777_5570(EIF_REFERENCE);
extern EIF_INTEGER_32 F777_5571(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern EIF_INTEGER_32 F794_5702(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
