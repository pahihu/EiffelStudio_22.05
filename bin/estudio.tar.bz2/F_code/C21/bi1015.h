
#ifndef _C21_bi1015_
#define _C21_bi1015_

#ifdef __cplusplus
extern "C" {
#endif

extern void F344_4641(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1015(void);
extern void F333_4624(EIF_REFERENCE, EIF_NATURAL_32);
extern void F626_5221(EIF_REFERENCE);
extern EIF_BOOLEAN F453_4698(EIF_REFERENCE);
extern EIF_BOOLEAN F584_4934(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
