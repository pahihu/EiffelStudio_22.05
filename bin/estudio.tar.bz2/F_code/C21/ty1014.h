
#ifndef _C21_ty1014_
#define _C21_ty1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F706_5484(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern char *(*R4476[])();
extern char *(*R4850[])();
extern char *(*R4863[])();

#ifdef __cplusplus
}
#endif

#endif
