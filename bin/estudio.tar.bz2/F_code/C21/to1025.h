
#ifndef _C21_to1025_
#define _C21_to1025_

#ifdef __cplusplus
extern "C" {
#endif

extern void F253_4176(EIF_REFERENCE, EIF_INTEGER_32);
extern void F253_4177(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F253_4183(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern void F793_5691(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4046[];
extern EIF_TYPE_INDEX *Y4046_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
