
#ifndef _C21_re1011_
#define _C21_re1011_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F522_4760(EIF_REFERENCE);
extern void EIF_Minit1011(void);
extern void F718_5490(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4862[])();
extern EIF_TYPE_INDEX Y4250[];
extern EIF_TYPE_INDEX *Y4250_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
