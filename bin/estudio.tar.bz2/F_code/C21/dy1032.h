
#ifndef _C21_dy1032_
#define _C21_dy1032_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F399_4664(EIF_REFERENCE);
extern void EIF_Minit1032(void);

#ifdef __cplusplus
}
#endif

#endif
