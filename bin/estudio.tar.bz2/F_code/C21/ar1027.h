
#ifndef _C21_ar1027_
#define _C21_ar1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F750_5544(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F750_5545(EIF_REFERENCE);
extern EIF_REFERENCE F750_5546(EIF_REFERENCE);
extern EIF_REFERENCE F750_5548(EIF_REFERENCE);
extern EIF_INTEGER_32 F750_5549(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern EIF_REFERENCE F626_5192(EIF_REFERENCE);
extern EIF_INTEGER_32 F626_5211(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
