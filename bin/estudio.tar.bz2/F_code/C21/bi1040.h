
#ifndef _C21_bi1040_
#define _C21_bi1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F345_4641(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1040(void);
extern void F627_5221(EIF_REFERENCE);
extern EIF_BOOLEAN F452_4698(EIF_REFERENCE);
extern EIF_BOOLEAN F585_4934(EIF_REFERENCE);
extern void F332_4624(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
