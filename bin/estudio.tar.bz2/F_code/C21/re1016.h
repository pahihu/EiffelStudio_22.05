
#ifndef _C21_re1016_
#define _C21_re1016_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F476_4704(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern char *(*R4454[])();

#ifdef __cplusplus
}
#endif

#endif
