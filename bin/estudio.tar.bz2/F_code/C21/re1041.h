
#ifndef _C21_re1041_
#define _C21_re1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F477_4704(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern char *(*R4454[])();

#ifdef __cplusplus
}
#endif

#endif
