/*
 * Code for class BILINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1040.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F345_4641 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (F585_4934(Current)) {
		tb1 = (EIF_BOOLEAN) !F452_4698(Current);
	}
	if (tb1) {
		F627_5221(Current);
	}
	F332_4624(Current, arg1);
	RTLE;
}

void EIF_Minit1040 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
