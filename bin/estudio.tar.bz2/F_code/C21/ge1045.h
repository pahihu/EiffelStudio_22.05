
#ifndef _C21_ge1045_
#define _C21_ge1045_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F739_5524(EIF_REFERENCE);
extern EIF_INTEGER_32 F739_5526(EIF_REFERENCE);
extern EIF_BOOLEAN F739_5533(EIF_REFERENCE);
extern void F739_5538(EIF_REFERENCE);
extern void F739_5539(EIF_REFERENCE);
extern EIF_REFERENCE F739_5540(EIF_REFERENCE);
extern void EIF_Minit1045(void);
extern char *(*R4878[])();
extern char *(*R4851[])();
extern long O4877[];
extern long O4879[];

#ifdef __cplusplus
}
#endif

#endif
