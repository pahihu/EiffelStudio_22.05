
#ifndef _C21_co1008_
#define _C21_co1008_

#ifdef __cplusplus
extern "C" {
#endif

extern void F357_4649(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1008(void);
extern char *(*R4295[])();
extern char *(*R4429[])();

#ifdef __cplusplus
}
#endif

#endif
