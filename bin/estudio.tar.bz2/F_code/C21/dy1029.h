
#ifndef _C21_dy1029_
#define _C21_dy1029_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F572_4918(EIF_REFERENCE);
extern void F572_4924(EIF_REFERENCE, EIF_NATURAL_32);
extern void F572_4925(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1029(void);
extern void F626_5225(EIF_REFERENCE, EIF_NATURAL_32);
extern void F626_5242(EIF_REFERENCE);
extern EIF_BOOLEAN F333_4628(EIF_REFERENCE);
extern void F626_5219(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
