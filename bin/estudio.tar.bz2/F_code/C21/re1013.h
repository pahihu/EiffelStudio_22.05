
#ifndef _C21_re1013_
#define _C21_re1013_

#ifdef __cplusplus
extern "C" {
#endif

extern void F718_5490(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F718_5492(EIF_REFERENCE);
extern EIF_INTEGER_32 F718_5493(EIF_REFERENCE);
extern EIF_INTEGER_32 F718_5494(EIF_REFERENCE);
extern EIF_INTEGER_32 F718_5495(EIF_REFERENCE);
extern EIF_REFERENCE F718_5496(EIF_REFERENCE);
extern EIF_BOOLEAN F718_5502(EIF_REFERENCE);
extern EIF_BOOLEAN F718_5503(EIF_REFERENCE);
extern EIF_BOOLEAN F718_5504(EIF_REFERENCE);
extern void F718_5509(EIF_REFERENCE);
extern void F718_5510(EIF_REFERENCE);
extern EIF_REFERENCE F718_5511(EIF_REFERENCE);
extern void EIF_Minit1013(void);
extern char *(*R4480[])();
extern char *(*R4477[])();
extern char *(*R4478[])();

#ifdef __cplusplus
}
#endif

#endif
