
#ifndef _C21_ce1035_
#define _C21_ce1035_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F170_3294(EIF_REFERENCE);
extern void F170_3295(EIF_REFERENCE, EIF_BOOLEAN);
extern void F170_3296(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit1035(void);
extern long O3228[];

#ifdef __cplusplus
}
#endif

#endif
