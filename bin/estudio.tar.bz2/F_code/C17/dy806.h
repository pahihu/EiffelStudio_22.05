
#ifndef _C17_dy806_
#define _C17_dy806_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F393_4664(EIF_REFERENCE);
extern void EIF_Minit806(void);

#ifdef __cplusplus
}
#endif

#endif
