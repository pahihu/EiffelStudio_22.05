
#ifndef _C17_fi814_
#define _C17_fi814_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F448_4698(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern char *(*R4453[])();

#ifdef __cplusplus
}
#endif

#endif
