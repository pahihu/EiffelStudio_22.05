
#ifndef _C17_ge833_
#define _C17_ge833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F734_5524(EIF_REFERENCE);
extern EIF_INTEGER_32 F734_5526(EIF_REFERENCE);
extern EIF_BOOLEAN F734_5533(EIF_REFERENCE);
extern void F734_5538(EIF_REFERENCE);
extern void F734_5539(EIF_REFERENCE);
extern EIF_REFERENCE F734_5540(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R4878[])();
extern char *(*R4851[])();
extern long O4877[];
extern long O4879[];

#ifdef __cplusplus
}
#endif

#endif
