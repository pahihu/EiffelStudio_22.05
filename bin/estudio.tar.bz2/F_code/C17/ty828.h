
#ifndef _C17_ty828_
#define _C17_ty828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F703_5484(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R4476[])();
extern char *(*R4850[])();
extern char *(*R4863[])();

#ifdef __cplusplus
}
#endif

#endif
