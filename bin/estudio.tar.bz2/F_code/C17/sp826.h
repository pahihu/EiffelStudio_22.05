
#ifndef _C17_sp826_
#define _C17_sp826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F772_5568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F772_5569(EIF_REFERENCE);
extern EIF_REFERENCE F772_5570(EIF_REFERENCE);
extern EIF_INTEGER_32 F772_5571(EIF_REFERENCE);
extern void EIF_Minit826(void);
extern EIF_INTEGER_32 F789_5702(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
