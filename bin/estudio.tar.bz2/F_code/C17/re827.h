
#ifndef _C17_re827_
#define _C17_re827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F715_5490(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5492(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5493(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5494(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5495(EIF_REFERENCE);
extern EIF_REFERENCE F715_5496(EIF_REFERENCE);
extern EIF_BOOLEAN F715_5502(EIF_REFERENCE);
extern EIF_BOOLEAN F715_5503(EIF_REFERENCE);
extern EIF_BOOLEAN F715_5504(EIF_REFERENCE);
extern void F715_5509(EIF_REFERENCE);
extern void F715_5510(EIF_REFERENCE);
extern EIF_REFERENCE F715_5511(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern char *(*R4480[])();
extern char *(*R4862[])();
extern char *(*R4477[])();
extern char *(*R4478[])();
extern long O4866[];
extern long O4870[];
extern long O4871[];
extern long O4872[];
extern long O4873[];
extern long O4874[];

#ifdef __cplusplus
}
#endif

#endif
