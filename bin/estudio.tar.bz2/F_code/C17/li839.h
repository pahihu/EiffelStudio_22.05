
#ifndef _C17_li839_
#define _C17_li839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F329_4622(EIF_REFERENCE, EIF_BOOLEAN);
extern void F329_4624(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F329_4628(EIF_REFERENCE);
extern EIF_BOOLEAN F329_4630(EIF_REFERENCE);
extern EIF_REFERENCE F329_4637(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern EIF_BOOLEAN F449_4698(EIF_REFERENCE);
extern char *(*R4405[])();
extern char *(*R4406[])();
extern char *(*R4407[])();
extern char *(*R4413[])();
extern char *(*R4418[])();
extern char *(*R4420[])();
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
