
#ifndef _C17_dy801_
#define _C17_dy801_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F567_4918(EIF_REFERENCE);
extern void F567_4924(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F567_4925(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit801(void);
extern EIF_BOOLEAN F327_4628(EIF_REFERENCE);
extern void F621_5225(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F621_5242(EIF_REFERENCE);
extern void F621_5219(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
