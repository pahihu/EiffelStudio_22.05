
#ifndef _C17_bi847_
#define _C17_bi847_

#ifdef __cplusplus
extern "C" {
#endif

extern void F340_4641(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit847(void);
extern void F329_4624(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F449_4698(EIF_REFERENCE);
extern char *(*R4420[])();
extern char *(*R4421[])();

#ifdef __cplusplus
}
#endif

#endif
