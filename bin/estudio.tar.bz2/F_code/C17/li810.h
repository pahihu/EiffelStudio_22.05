
#ifndef _C17_li810_
#define _C17_li810_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F328_4622(EIF_REFERENCE, EIF_INTEGER_32);
extern void F328_4624(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F328_4628(EIF_REFERENCE);
extern EIF_BOOLEAN F328_4630(EIF_REFERENCE);
extern EIF_REFERENCE F328_4637(EIF_REFERENCE);
extern void EIF_Minit810(void);
extern char *(*R4405[])();
extern char *(*R4406[])();
extern char *(*R4407[])();
extern char *(*R4296[])();
extern char *(*R4413[])();
extern char *(*R4418[])();
extern char *(*R4420[])();
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
