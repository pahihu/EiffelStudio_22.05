
#ifndef _C17_re817_
#define _C17_re817_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F518_4760(EIF_REFERENCE);
extern void EIF_Minit817(void);
extern void F714_5490(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4862[])();
extern EIF_TYPE_INDEX Y4250[];
extern EIF_TYPE_INDEX *Y4250_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
