
#ifndef _C17_ar808_
#define _C17_ar808_

#ifdef __cplusplus
extern "C" {
#endif

extern void F759_5562(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F759_5563(EIF_REFERENCE);
extern EIF_REFERENCE F759_5564(EIF_REFERENCE);
extern EIF_REFERENCE F759_5566(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_5567(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern EIF_TYPE_INDEX Y4809[];
extern EIF_TYPE_INDEX *Y4809_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
