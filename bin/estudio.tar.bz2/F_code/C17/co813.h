
#ifndef _C17_co813_
#define _C17_co813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F301_4469(EIF_REFERENCE);
extern void F301_4470(EIF_REFERENCE);
extern void EIF_Minit813(void);
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
