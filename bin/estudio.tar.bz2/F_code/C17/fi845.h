
#ifndef _C17_fi845_
#define _C17_fi845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F449_4698(EIF_REFERENCE);
extern void EIF_Minit845(void);
extern char *(*R4453[])();

#ifdef __cplusplus
}
#endif

#endif
