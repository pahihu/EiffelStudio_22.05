
#ifndef _C17_ty820_
#define _C17_ty820_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F702_5484(EIF_REFERENCE);
extern void EIF_Minit820(void);
extern char *(*R4476[])();
extern char *(*R4850[])();
extern char *(*R4863[])();

#ifdef __cplusplus
}
#endif

#endif
