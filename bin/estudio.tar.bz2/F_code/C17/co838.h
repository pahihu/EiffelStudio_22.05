
#ifndef _C17_co838_
#define _C17_co838_

#ifdef __cplusplus
extern "C" {
#endif

extern void F302_4469(EIF_REFERENCE);
extern void F302_4470(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern long O4298[];

#ifdef __cplusplus
}
#endif

#endif
