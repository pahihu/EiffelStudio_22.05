
#ifndef _C17_re829_
#define _C17_re829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F519_4760(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern void F715_5490(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4862[])();
extern EIF_TYPE_INDEX Y4250[];
extern EIF_TYPE_INDEX *Y4250_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
