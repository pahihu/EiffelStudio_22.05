
#ifndef _C17_se837_
#define _C17_se837_

#ifdef __cplusplus
extern "C" {
#endif

extern void F484_4711(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit837(void);
extern char *(*R4427[])();

#ifdef __cplusplus
}
#endif

#endif
