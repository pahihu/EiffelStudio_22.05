
#ifndef _C17_co844_
#define _C17_co844_

#ifdef __cplusplus
extern "C" {
#endif

extern void F353_4649(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit844(void);
extern char *(*R4295[])();
extern char *(*R4429[])();

#ifdef __cplusplus
}
#endif

#endif
