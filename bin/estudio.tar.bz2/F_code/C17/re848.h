
#ifndef _C17_re848_
#define _C17_re848_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F472_4704(EIF_REFERENCE);
extern void EIF_Minit848(void);
extern char *(*R4454[])();

#ifdef __cplusplus
}
#endif

#endif
