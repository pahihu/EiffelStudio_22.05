
#ifndef _C17_co824_
#define _C17_co824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F352_4649(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit824(void);
extern char *(*R4295[])();
extern char *(*R4429[])();

#ifdef __cplusplus
}
#endif

#endif
