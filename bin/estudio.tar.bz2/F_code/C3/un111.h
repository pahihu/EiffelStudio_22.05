
#ifndef _C3_un111_
#define _C3_un111_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F123_2728(EIF_REFERENCE);
extern void EIF_Minit111(void);
extern void F856_6133(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
