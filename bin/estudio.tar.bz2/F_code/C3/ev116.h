
#ifndef _C3_ev116_
#define _C3_ev116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F128_2798(EIF_REFERENCE);
extern EIF_REFERENCE F128_2801(EIF_REFERENCE);
static EIF_REFERENCE F128_2802_body(EIF_REFERENCE);
extern EIF_REFERENCE F128_2802(EIF_REFERENCE);
extern EIF_REFERENCE F128_2803(EIF_REFERENCE);
extern EIF_REFERENCE F128_2805(EIF_REFERENCE);
extern EIF_REFERENCE F128_2815(EIF_REFERENCE);
extern void EIF_Minit116(void);
extern void F1185_11210(EIF_REFERENCE, EIF_REFERENCE);
extern void F636_5288(EIF_REFERENCE);
extern long O2781[];
extern long O2784[];
extern long O2786[];
extern long O2788[];
extern long O2798[];

#ifdef __cplusplus
}
#endif

#endif
