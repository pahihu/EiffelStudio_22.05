/*
 * Code for class RT_DEBUGGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rt130.h"
#include "eif_main.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F142_3040
static void inline_F142_3040 (EIF_BOOLEAN arg1)
{
	#ifdef WORKBENCH
	set_debug_mode (arg1 ? 1 : 0);
#endif
	;
}
#define INLINE_F142_3040
#endif
#ifndef INLINE_F142_3041
static int inline_F142_3041 (void)
{
	#ifdef WORKBENCH
	return EIF_TEST(is_debug_mode());
#else
	return EIF_FALSE;
#endif
	;
}
#define INLINE_F142_3041
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RT_DEBUGGER}.disable_debug */
void F142_3039 (EIF_REFERENCE Current)
{
	GTCX
	
	
	inline_F142_3040((EIF_BOOLEAN) 0);
}

/* {RT_DEBUGGER}.set_debug_state */
void F142_3040 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	inline_F142_3040 ((EIF_BOOLEAN) arg1);
}

/* {RT_DEBUGGER}.debug_state */
EIF_BOOLEAN F142_3041 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F142_3041 ());
	return Result;
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
