
#ifndef _C3_ev132_
#define _C3_ev132_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F144_3049(EIF_REFERENCE);
extern void F144_3051(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit132(void);
extern void F636_5288(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
