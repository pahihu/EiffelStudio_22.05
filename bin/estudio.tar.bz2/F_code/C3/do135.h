
#ifndef _C3_do135_
#define _C3_do135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F147_3072(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F147_3074(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F147_3077(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F147_3080(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F147_3082(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
