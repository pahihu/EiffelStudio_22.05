
#ifndef _C3_pr123_
#define _C3_pr123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F135_2880(EIF_REFERENCE);
extern EIF_BOOLEAN F135_2882(EIF_REFERENCE);
extern void EIF_Minit123(void);
extern void F851_5863(EIF_REFERENCE);
extern void F851_5865(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
