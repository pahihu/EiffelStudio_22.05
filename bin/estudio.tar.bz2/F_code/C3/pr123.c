/*
 * Code for class PROCESS_IO_LISTENER_THREAD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_IO_LISTENER_THREAD}.set_exit_signal */
void F135_2880 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F851_5863(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F851_5865(RTCW(tr1));
	RTLE;
}

/* {PROCESS_IO_LISTENER_THREAD}.should_thread_exit */
EIF_BOOLEAN F135_2882 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F851_5863(RTCW(tr1));
	Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F851_5865(RTCW(tr1));
	RTLE;
	return Result;
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
