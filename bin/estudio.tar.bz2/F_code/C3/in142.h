
#ifndef _C3_in142_
#define _C3_in142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F154_3155(EIF_REFERENCE);
extern EIF_BOOLEAN F154_3156(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit142(void);
extern void F790_5710(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
