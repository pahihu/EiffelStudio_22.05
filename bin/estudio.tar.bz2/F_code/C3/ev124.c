/*
 * Code for class EV_SHARED_TRANSPORT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev124.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_TRANSPORT_I}.default_accept_cursor */
static EIF_REFERENCE F136_2889_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(265)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(269,F24_521, (RTCV(RTOUCR(274,F136_2893, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2889 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(265,F136_2889_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_deny_cursor */
static EIF_REFERENCE F136_2890_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(266)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(271,F24_525, (RTCV(RTOUCR(274,F136_2893, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2890 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(266,F136_2890_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_pixmaps */
static EIF_REFERENCE F136_2893_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(274)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(23, 0x00).id, 23, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2893 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(274,F136_2893_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label */
static EIF_REFERENCE F136_2899_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(297)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1058_9305(RTCW(Result), ((EIF_INTEGER_32) 10L), ((EIF_INTEGER_32) 10L));
	loc1 = RTLNS(eif_new_type(1081, 0x00).id, 1081, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1018_8683(RTCW(loc1));
	F1082_9623(RTCW(loc1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 2L));
	tr1 = RTLNS(eif_new_type(33, 0x00).id, 33, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F34_771(RTCW(tr1));
	F1036_9003(RTCW(loc1), tr1);
	F1050_9121(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1050_9121(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(33, 0x00).id, 33, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(16,F34_748, (RTCW(tr1)));
	F1036_9003(RTCW(loc1), tr1);
	F1050_9121(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	F1050_9121(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L));
	F1044_9068(RTCW(Result), loc1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2899 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(297,F136_2899_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label_imp */
static EIF_REFERENCE F136_2900_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(306)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTOUCR(297,F136_2899, (Current));
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O7088[Dtype(tr1)-1017]);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2900 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(306,F136_2900_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_label */
void F136_2901 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc1 = F1058_9279(RTCV(RTOUCR(297,F136_2899, (Current))));
		loc1 = RTRV(eif_new_type(1065, 0x00), loc1);
		tr1 = RTOUCR(297,F136_2899, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7569[Dtype(loc5)-1063])(loc5, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOUCR(297,F136_2899, (Current));
			tb2 = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (loc1, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			loc2 = F1058_9279(RTCW(loc1));
			loc2 = RTRV(eif_new_type(1062, 0x00), loc2);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				loc3 = F1056_9230(RTCW(loc2), loc1, ((EIF_INTEGER_32) 1L));
				loc4 = F1063_9383(RTCW(loc2), loc1);
				F1056_9253(RTCW(loc2), loc1);
				F1056_9239(RTCW(loc2), loc3);
				F1056_9248(RTCW(loc2), loc1);
				if ((EIF_BOOLEAN) !loc4) {
					F1063_9390(RTCW(loc2), loc1);
				}
			}
		}
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.insert_sep */
static EIF_REFERENCE F136_2902_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(307)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2902 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(307,F136_2902_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_sep */
void F136_2904 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1092_9753(RTCV(RTOUCR(307,F136_2902, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOUCR(307,F136_2902, (Current));
		F1056_9253(loc1, tr1);
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.internal_screen */
static EIF_REFERENCE F136_2906_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(308)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1051, 0x00).id, 1051, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1018_8683(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_2906 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(308,F136_2906_body,(Current));
}

void EIF_Minit124 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
