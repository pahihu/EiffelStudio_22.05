/*
 * Code for class PROCESS_UNIX_OS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr110.h"
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include "eif_process.h"
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F122_2708
static void inline_F122_2708 (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	{
  int rc;
  rc = dup2(arg1, arg2);
  if (rc < 0) {
	    eraise(Strerror(errno), EN_SYS);
  }
}
	;
}
#define INLINE_F122_2708
#endif
#ifndef INLINE_F122_2709
static void inline_F122_2709 (EIF_INTEGER_32 arg1)
{
	{
	 int rc;
	  rc = close(arg1);
	  if (rc != 0) {
	    eraise(Strerror(errno), EN_SYS);
	  }
}
	;
}
#define INLINE_F122_2709
#endif
#ifndef INLINE_F122_2712
static void inline_F122_2712 (void)
{
	{
	setpgid (0, 0);
}
	;
}
#define INLINE_F122_2712
#endif
#ifndef INLINE_F122_2726
static void inline_F122_2726 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	{
				  char ** arguments;
 				  arguments = (char **) arg1;
				  arguments[arg2] = (char *) arg3;
				}
	;
}
#define INLINE_F122_2726
#endif
#ifndef INLINE_F122_2724
static void inline_F122_2724 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	{
				  int max_descriptors;
				  int k, rc;
  				  if (arg4 == EIF_TRUE) {
				    max_descriptors = getdtablesize();
					for (k = 3; k < max_descriptors; k++) {
					    rc = fcntl(k, F_SETFD, 1);
					    if (rc == -1 && errno != EBADF) {
						      eraise(Strerror(errno), EN_SYS);
					    }
			  	    }
				  }
				  if (arg3 == NULL) {
				    (void) execv((char *) arg1, (char **) arg2);
				  } else {
				    (void) execve((char *) arg1, (char **) arg2, (char **) arg3);
				  }
				  _exit(127);
				}
	;
}
#define INLINE_F122_2724
#endif
#ifndef INLINE_F122_2723
static void inline_F122_2723 (EIF_INTEGER_32* arg1)
{
	{
  pid_t pid;
  pid = fork();
  *arg1 = (EIF_INTEGER)pid;
}
	;
}
#define INLINE_F122_2723
#endif
#ifndef INLINE_F122_2719
static void inline_F122_2719 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	{
	  char *result;
	  result = (char *) malloc((unsigned) (strlen((char *) arg1) + 1));
	  if (result == NULL) {
    	enomem();
	  }
	  strcpy(result, arg1);
	  *arg2 = result;
	}
	;
}
#define INLINE_F122_2719
#endif
#ifndef INLINE_F122_2725
static void inline_F122_2725 (EIF_INTEGER_32 arg1, EIF_POINTER* arg2)
{
	{
	EIF_POINTER result;
	result = (EIF_POINTER) malloc((size_t) (arg1 * sizeof(char *)));
	if (result == NULL) {
		enomem();
	}
	*arg2 = result;
}
	;
}
#define INLINE_F122_2725
#endif
#ifndef INLINE_F122_2720
static void inline_F122_2720 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	{
  int rc;
  int fd[2];
  EIF_INTEGER * read_ptr;
  EIF_INTEGER * write_ptr;
  rc = pipe(fd);
  if (rc != 0) {
    eraise(Strerror(errno), EN_SYS);
  }
  read_ptr = (EIF_INTEGER *) arg1;
  write_ptr = (EIF_INTEGER *) arg2;
  *read_ptr = fd[0];
  *write_ptr = fd[1];
}
	;
}
#define INLINE_F122_2720
#endif
#ifndef INLINE_F122_2722
static void inline_F122_2722 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN* arg3, EIF_INTEGER_32* arg4, EIF_BOOLEAN* arg5)
{
	{
  pid_t rc;
  int status;
  
  rc = waitpid((pid_t) arg1, &status, (arg2 ? 0 : WNOHANG) | WUNTRACED);
  *(EIF_BOOLEAN *) arg5 = (rc != -1);
  if (rc != -1) {				    
	  if (rc == 0) { /* No process has status to report yet */
	    *(EIF_BOOLEAN *) arg3 = EIF_FALSE;
	  } else { /* Process reported status */
	    *(EIF_BOOLEAN *) arg3 = EIF_TRUE;
	  }
	  *(EIF_INTEGER *) arg4 = (EIF_INTEGER) status;
  }
}
	;
}
#define INLINE_F122_2722
#endif
#ifndef INLINE_F122_2727
static void inline_F122_2727 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F122_2727
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_UNIX_OS}.duplicate_file_descriptor */
void F122_2708 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F122_2708 ((EIF_INTEGER_32) arg1, (EIF_INTEGER_32) arg2);
}

/* {PROCESS_UNIX_OS}.close_file_descriptor */
void F122_2709 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	inline_F122_2709 ((EIF_INTEGER_32) arg1);
}

/* {PROCESS_UNIX_OS}.fork_process */
EIF_INTEGER_32 F122_2711 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F122_2716(Current);
}

/* {PROCESS_UNIX_OS}.new_process_group */
void F122_2712 (EIF_REFERENCE Current)
{
	GTCX
	
	
	inline_F122_2712 ();
}

/* {PROCESS_UNIX_OS}.exec_process */
void F122_2713 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc2 = F540_4826(RTCW(arg2));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_1_);
	loc4 = F122_2718(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	loc5 = RTLNS(eif_new_type(264, 0x00).id, 264, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F265_4238(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F540_4819(RTCW(arg2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + loc1) - ((EIF_INTEGER_32) 1L)));
		F265_4252(RTCW(loc5), tr1);
		tp1 = F265_4244(RTCW(loc5));
		tp1 = F122_2717(Current, tp1);
		inline_F122_2726(loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), tp1);
		loc1++;
	}
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	inline_F122_2726(loc4, loc2, tp2);
	loc5 = RTLNS(eif_new_type(264, 0x00).id, 264, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F265_4237(RTCW(loc5), arg1);
	tp1 = F265_4244(RTCW(loc5));
	inline_F122_2724(tp1, loc4, arg4, arg3);
	RTLE;
}

/* {PROCESS_UNIX_OS}.unix_fork_process */
EIF_INTEGER_32 F122_2716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	inline_F122_2723((EIF_INTEGER_32 *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.str_dup */
EIF_POINTER F122_2717 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	inline_F122_2719(arg1, (EIF_POINTER *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.unix_allocate_arg_memory */
EIF_POINTER F122_2718 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	inline_F122_2725(arg1, (EIF_POINTER *) &(Result));
	return Result;
}

/* {PROCESS_UNIX_OS}.c_str_dup */
void F122_2719 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	
	
	inline_F122_2719 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
}

/* {PROCESS_UNIX_OS}.unix_pipe */
void F122_2720 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F122_2720 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {PROCESS_UNIX_OS}.unix_waitpid */
void F122_2722 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN* arg3, EIF_INTEGER_32* arg4, EIF_BOOLEAN* arg5)
{
	GTCX
	
	
	EIF_ENTER_C;
	inline_F122_2722 ((EIF_INTEGER_32) arg1, (EIF_BOOLEAN) arg2, (EIF_BOOLEAN*) arg3, (EIF_INTEGER_32*) arg4, (EIF_BOOLEAN*) arg5);
	EIF_EXIT_C;
	RTGC;
}

/* {PROCESS_UNIX_OS}.c_unix_fork_process */
void F122_2723 (EIF_REFERENCE Current, EIF_INTEGER_32* arg1)
{
	GTCX
	
	
	inline_F122_2723 ((EIF_INTEGER_32*) arg1);
}

/* {PROCESS_UNIX_OS}.unix_exec_process */
void F122_2724 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4)
{
	GTCX
	
	
	inline_F122_2724 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_BOOLEAN) arg4);
}

/* {PROCESS_UNIX_OS}.c_unix_allocate_arg_memory */
void F122_2725 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER* arg2)
{
	GTCX
	
	
	inline_F122_2725 ((EIF_INTEGER_32) arg1, (EIF_POINTER*) arg2);
}

/* {PROCESS_UNIX_OS}.unix_set_arg_value */
void F122_2726 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	inline_F122_2726 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_POINTER) arg3);
}

/* {PROCESS_UNIX_OS}.attach_terminals */
void F122_2727 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	inline_F122_2727 ((EIF_INTEGER_32) arg1);
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
