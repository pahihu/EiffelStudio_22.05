/*
 * Code for class THREAD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "th122.h"
#include "../C3/th122.h"
#include "eif_threads.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {THREAD}.make */
void F134_2857 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(850, 0).id);
	F851_5860(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2855[Dtype(Current)-133]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {THREAD}.launch */
void F134_2861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1285, 0x00).id, 1285, _OBJSIZ_1_1_0_0_0_1_0_0_);
	F1286_13054(RTCW(tr1));
	F134_2862(Current, tr1);
	RTLE;
}

/* {THREAD}.launch_with_attributes */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F134_2862 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	if ((EIF_BOOLEAN) !F134_2867(Current)) {
		tr1 = RTOUCR(304,F134_2875, (Current));
		F170_3295(RTCW(tr1), (EIF_BOOLEAN) 0);
	} else {
		tp1 = F258_4187(RTCW(arg1));
		F134_2876(Current, Current, (EIF_POINTER) F134_2871, (EIF_POINTER) F134_2873, tp1);
		tp1 = (EIF_POINTER) eif_thr_last_thread();
		*(EIF_POINTER *)(Current + O2839[dtype-133]) = (EIF_POINTER) tp1;
		tr1 = RTOUCR(304,F134_2875, (Current));
		F170_3295(RTCW(tr1), (EIF_BOOLEAN) 1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	RTE_E
	RTXSC;
	tr1 = RTOUCR(304,F134_2875, (Current));
	F170_3295(RTCW(tr1), (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {THREAD}.is_launchable */
EIF_BOOLEAN F134_2867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	tb2 = F851_5862(RTCW(tr1));
	if (tb2) {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tb1 = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O2839[dtype-133]) == tp1);
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O2840[dtype-133]);
	}
	RTLE;
	return Result;
}

/* {THREAD}.join */
void F134_2869 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O2840[Dtype(Current)-133])) {
		F134_2877(Current, Current, (EIF_POINTER) F134_2872);
	}
	RTLE;
}

/* {THREAD}.join_with_timeout */
EIF_BOOLEAN F134_2870 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O2840[Dtype(Current)-133])) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) F134_2878(Current, Current, (EIF_POINTER) F134_2872, arg1);
	}/* NOTREACHED */
	
}

/* {THREAD}.thr_main */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F134_2871 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_POINTER  EIF_VOLATILE tp2;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2841[dtype-268])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current + O2840[dtype-133]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O2839[dtype-133]) = (EIF_POINTER) tp2;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	RTE_E
	RTXSC;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current + O2840[dtype-133]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O2839[dtype-133]) = (EIF_POINTER) tp2;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {THREAD}.thr_get_terminated */
EIF_BOOLEAN F134_2872 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	Result = *(EIF_BOOLEAN *)(Current + O2840[dtype-133]);
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	RTLE;
	return Result;
}

/* {THREAD}.thr_set_terminated */
void F134_2873 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5863(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current + O2840[dtype-133]) = (EIF_BOOLEAN) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O2855[dtype-133]);
	F851_5865(RTCW(tr1));
	RTLE;
}

/* {THREAD}.is_last_launch_successful_cell */
static EIF_REFERENCE F134_2875_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(304)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {169,940,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 169, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F170_3295(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_2875 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(304,F134_2875_body,(Current));
}

/* {THREAD}.create_thread_with_attr */
void F134_2876 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_POINTER larg3 = arg3;
		EIF_POINTER larg4 = arg4;eif_thr_create_with_attr((EIF_OBJECT) larg1, (EIF_PROCEDURE) larg2, (EIF_PROCEDURE) larg3, (EIF_POINTER) larg4);
		
	}
	RTLE;
}

/* {THREAD}.thread_wait */
void F134_2877 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;eif_thr_wait((EIF_OBJECT) larg1, (EIF_BOOLEAN_FUNCTION) larg2);
		
	}
	RTLE;
}

/* {THREAD}.thread_wait_with_timeout */
EIF_BOOLEAN F134_2878 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_NATURAL_64 arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_NATURAL_64 larg3 = arg3;Result = (EIF_BOOLEAN) EIF_TEST(eif_thr_wait_with_timeout((EIF_OBJECT) larg1, (EIF_BOOLEAN_FUNCTION) larg2, (EIF_NATURAL_64) larg3));
		
	}
	RTLE;
	return Result;
}

/* {THREAD}.last_created_thread */
EIF_POINTER F134_2879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_thr_last_thread();
	
	return Result;
}

void EIF_Minit122 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
