/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei103.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F115_2566 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (55,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_library_env */

EIF_REFERENCE F115_2567 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (56,RTMS_EX_H("ISE_LIBRARY",11,552576601));
}

/* {EIFFEL_CONSTANTS}.eiffel_library_env */

EIF_REFERENCE F115_2568 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (57,RTMS_EX_H("EIFFEL_LIBRARY",14,1735641689));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F115_2569 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (58,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F115_2570 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (59,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_precomp_env */

EIF_REFERENCE F115_2571 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (60,RTMS_EX_H("ISE_PRECOMP",11,185338448));
}

/* {EIFFEL_CONSTANTS}.ise_platform_env */

EIF_REFERENCE F115_2572 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (61,RTMS_EX_H("ISE_PLATFORM",12,1318550605));
}

/* {EIFFEL_CONSTANTS}.ise_c_compiler_env */

EIF_REFERENCE F115_2573 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (62,RTMS_EX_H("ISE_C_COMPILER",14,1981921618));
}

/* {EIFFEL_CONSTANTS}.ise_c_compiler_ver_env */

EIF_REFERENCE F115_2574 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (63,RTMS_EX_H("ISE_C_COMPILER_VER",18,1420636498));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F115_2576 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (64,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.ise_app_data_env */

EIF_REFERENCE F115_2577 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (65,RTMS_EX_H("ISE_APP_DATA",12,1175984961));
}

/* {EIFFEL_CONSTANTS}.ec_name_env */

EIF_REFERENCE F115_2578 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (29,RTMS_EX_H("EC_NAME",7,1814519621));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F115_2584_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(66)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F115_2586(Current, ti4_1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F115_2584 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(66,F115_2584_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F115_2585_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(67)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F115_2586(Current, ti4_1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F115_2585 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(67,F115_2585_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F115_2586 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(988, 0x00).id, 988, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_8278(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		F989_8529(RTCW(Result), (EIF_CHARACTER_8) '0');
	}
	F989_8519(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit103 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
