
#ifndef _C3_th120_
#define _C3_th120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F132_2853(EIF_REFERENCE);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
