/*
 * Code for class ES_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "es127.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ES_ARGUMENTS}.environment_arguments_prepended */
EIF_BOOLEAN F139_2923 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ES_ARGUMENTS}.arguments_program_name */
EIF_REFERENCE F139_2924 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr1 = RTMS_EX_H("ec",2,25955);
	F984_8256(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {ES_ARGUMENTS}.arguments_environment_name */
static EIF_REFERENCE F139_2925_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(329)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS32_EX_H("I\000\000\000S\000\000\000E\000\000\000_\000\000\000",4,1230194015);
	tr3 = F984_8269(RTCV(F139_2924(Current)));
	tr2 = F988_8444(tr2, tr3);
	tr3 = F981_8165(RTMS_EX_H("_FLAGS",6,1466661715));
	tr2 = F988_8444(RTCW(tr2), tr3);
	F984_8257(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F139_2925 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(329,F139_2925_body,(Current));
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
