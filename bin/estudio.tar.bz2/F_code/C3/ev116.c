/*
 * Code for class EV_WIDGET_ACTION_SEQUENCES_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev116.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_ACTION_SEQUENCES_I}.file_drop_actions */
EIF_REFERENCE F128_2798 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2781[dtype-127]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {636,0xFFF9,1,901,576,987,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 636, _OBJSIZ_9_2_0_2_0_0_0_0_);
		}
		F636_5288(RTCW(Result));
		F1185_11210(Current, Result);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O2781[dtype-127]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_motion_actions */
EIF_REFERENCE F128_2801 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2784[dtype-127]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(650, 0x00).id, 650, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F636_5288(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O2784[dtype-127]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_motion_actions_internal */
static EIF_REFERENCE F128_2802_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F128_2802 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O2784[Dtype(Current)-127]);
	if (!r) {
		if (RTAT(eif_new_type(650, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F128_2802_body (Current));
			*(EIF_REFERENCE *)(Current + O2784[Dtype(Current)-127]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_button_press_actions */
EIF_REFERENCE F128_2803 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2786[dtype-127]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(654, 0x00).id, 654, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F636_5288(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O2786[dtype-127]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_double_press_actions */
EIF_REFERENCE F128_2805 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2788[dtype-127]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(654, 0x00).id, 654, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F636_5288(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O2788[dtype-127]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_press_actions */
EIF_REFERENCE F128_2815 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O2798[dtype-127]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(647, 0x00).id, 647, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F636_5288(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O2798[dtype-127]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
