/*
 * Code for class SYSTEM_ENCODINGS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy115.h"
#include "eif_langinfo.h"
#include "eif_built_in.h"
#include "string.h"
#include <locale.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F127_2796
static EIF_POINTER inline_F127_2796 (void)
{
	return nl_langinfo (CODESET);
	;
}
#define INLINE_F127_2796
#endif
#ifndef INLINE_F127_2795
static int inline_F127_2795 (void)
{
	setlocale (LC_ALL, "");
return (EIF_BOOLEAN)(strcmp (nl_langinfo (CODESET), "UTF-8") == 0);
	;
}
#define INLINE_F127_2795
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS_IMP}.system_code_page */
EIF_REFERENCE F127_2792 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = inline_F127_2796();
	ti4_1 = (EIF_INTEGER_32) strlen((void *) loc1);
	Result = F126_2782(Current, loc1, ti4_1);
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.console_code_page */
EIF_REFERENCE F127_2793 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (EIF_TEST (inline_F127_2795())) {
		Result = RTMS_EX_H("UTF-8",5,1414538040);
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			Result = RTMS_EX_H("UTF-8",5,1414538040);
		} else {
			Result = F127_2792(Current);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.is_utf8_activated */
EIF_BOOLEAN F127_2795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F127_2795 ());
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_current_codeset */
EIF_POINTER F127_2796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F127_2796 ();
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_strlen */
EIF_INTEGER_32 F127_2797 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) strlen((void *) arg1);
	
	return Result;
}

void EIF_Minit115 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
