
#ifndef _C3_rt130_
#define _C3_rt130_

#ifdef __cplusplus
extern "C" {
#endif

extern void F142_3039(EIF_REFERENCE);
extern void F142_3040(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F142_3041(EIF_REFERENCE);
extern void EIF_Minit130(void);

#ifdef __cplusplus
}
#endif

#endif
