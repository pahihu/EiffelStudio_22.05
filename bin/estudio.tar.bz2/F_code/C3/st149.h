
#ifndef _C3_st149_
#define _C3_st149_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F161_3271(EIF_REFERENCE);
extern EIF_INTEGER_32 F161_3272(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit149(void);
extern char *(*R6688[])();
extern char *(*R6725[])();
extern char *(*R6849[])();

#ifdef __cplusplus
}
#endif

#endif
