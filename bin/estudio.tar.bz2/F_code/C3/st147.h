
#ifndef _C3_st147_
#define _C3_st147_

#ifdef __cplusplus
extern "C" {
#endif

extern void F159_3254(EIF_REFERENCE);
extern EIF_INTEGER_32 F159_3258(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F159_3264(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit147(void);
extern void F792_5712(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R6688[])();
extern char *(*R6725[])();
extern char *(*R3204[])();
extern char *(*R3206[])();

#ifdef __cplusplus
}
#endif

#endif
