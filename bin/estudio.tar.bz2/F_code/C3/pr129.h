
#ifndef _C3_pr129_
#define _C3_pr129_

#ifdef __cplusplus
extern "C" {
#endif

extern void F141_3018(EIF_REFERENCE, EIF_REFERENCE);
extern void F141_3019(EIF_REFERENCE);
extern void F141_3021(EIF_REFERENCE, EIF_REFERENCE);
extern void F141_3023(EIF_REFERENCE);
extern void F141_3036(EIF_REFERENCE);
extern void EIF_Minit129(void);
extern void F105_2517(EIF_REFERENCE, EIF_REFERENCE);
extern void F140_2937(EIF_REFERENCE);
extern void F140_3013(EIF_REFERENCE);
extern void F140_2933(EIF_REFERENCE);
extern void F273_4363(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
