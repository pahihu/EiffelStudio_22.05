
#ifndef _C3_ec104_
#define _C3_ec104_

#ifdef __cplusplus
extern "C" {
#endif

extern void F116_2587(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit104(void);
extern EIF_REFERENCE F54_986(EIF_REFERENCE);
extern void F1287_13104(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
