/*
 * Code for class PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr129.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS}.redirect_output_to_agent */
void F141_3018 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {PROCESS}.cancel_output_redirection */
void F141_3019 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F140_2933(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {PROCESS}.redirect_error_to_agent */
void F141_3021 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {PROCESS}.cancel_error_redirection */
void F141_3023 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F140_2937(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {PROCESS}.initialize_parameter */
void F141_3036 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F140_3013(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) NULL;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4096L);
	tr1 = RTLNS(eif_new_type(272, 0x00).id, 272, _OBJSIZ_3_3_0_2_0_1_0_0_);
	F273_4363(RTCW(tr1), ((EIF_INTEGER_32) 250L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	F105_2517(RTCW(tr1), Current);
	RTLE;
}

void EIF_Minit129 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
