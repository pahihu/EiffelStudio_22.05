
#ifndef _C3_st148_
#define _C3_st148_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F160_3267(EIF_REFERENCE);
extern EIF_INTEGER_32 F160_3268(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit148(void);
extern char *(*R6688[])();
extern char *(*R6725[])();
extern char *(*R6808[])();

#ifdef __cplusplus
}
#endif

#endif
