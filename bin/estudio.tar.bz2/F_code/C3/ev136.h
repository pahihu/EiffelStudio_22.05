
#ifndef _C3_ev136_
#define _C3_ev136_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F148_3088(EIF_REFERENCE);
extern EIF_POINTER F148_3089(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
