
#ifndef _C3_ev118_
#define _C3_ev118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F130_2836(EIF_REFERENCE);
extern EIF_REFERENCE F130_2848(EIF_REFERENCE);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
