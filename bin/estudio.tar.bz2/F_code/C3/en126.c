/*
 * Code for class ENVIRONMENT_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en126.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENVIRONMENT_ARGUMENTS}.argument */
EIF_REFERENCE F138_2910 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOUCR(330,F138_2921, (Current));
		Result = F291_4442(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	} else {
		ti4_1 = F619_5209(RTCV(F138_2920(Current)));
		if ((EIF_BOOLEAN) (arg1 <= ti4_1)) {
			Result = F138_2919(Current, arg1);
		} else {
			Result = F138_2918(Current, arg1);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.index_of_word_option */
EIF_INTEGER_32 F138_2912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(330,F138_2921, (Current));
	Result = F291_4447(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F619_5209(RTCV(F138_2920(Current)));
		Result += ti4_1;
	} else {
		loc2 = F619_5209(RTCV(F138_2920(Current)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tr1 = F138_2919(Current, loc1);
				tb1 = F138_2917(Current, tr1, arg1);
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 <= loc2)) {
			RTLE;
			return (EIF_INTEGER_32) loc1;
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_sign */
EIF_REFERENCE F138_2913 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(74,F291_4454, (RTCV(RTOUCR(330,F138_2921, (Current)))));
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.argument_count */
EIF_INTEGER_32 F138_2915 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	ti4_1 = F619_5209(RTCV(F138_2920(Current)));
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_word_equal */
EIF_BOOLEAN F138_2917 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tw1 = *(EIF_CHARACTER_32 *)(RTCV(F138_2913(Current))+ _LNGOFF_0_0_0_0_);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(tw1 == tw2)) {
		tb1 = F981_8151(RTCW(arg1), arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6703[Dtype(RTCW(arg1))-983])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6689[Dtype(RTCW(arg1))-983])(arg1, ((EIF_INTEGER_32) 1L));
			tw2 = *(EIF_CHARACTER_32 *)(RTCV(F138_2913(Current))+ _LNGOFF_0_0_0_0_);
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6725[Dtype(RTCW(arg1))-983])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6766[Dtype(RTCW(arg1))-983])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
			Result = F981_8151(RTCW(tr1), arg2);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_argument_item */
EIF_REFERENCE F138_2918 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(330,F138_2921, (Current));
	ti4_1 = F619_5209(RTCV(F138_2920(Current)));
	Result = F291_4442(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ti4_1));
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_argument_item */
EIF_REFERENCE F138_2919 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F138_2920(Current);
	Result = F619_5194(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_arguments */
EIF_REFERENCE F138_2920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {618,983,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 618, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F619_5188(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
		tr1 = RTOUCR(305,F137_2909, (Current));
		tr2 = RTOUCR(329,F139_2925, (Current));
		loc4 = F268_4323(RTCW(tr1), tr2);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb2 = F981_8124(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
			loc5 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F981_8106(RTCW(loc5));
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = F988_8392(RTCW(loc4), loc1);
				if (loc6) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					if ((EIF_BOOLEAN)(loc3 == tw1)) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						F988_8439(RTCW(loc5), loc3);
					}
				} else {
					switch (loc3) {
						case (EIF_CHARACTER_8) '\"':
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							break;
						case (EIF_CHARACTER_8) '\011':
						case (EIF_CHARACTER_8) ' ':
							tb1 = F452_4698(RTCW(loc5));
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_1_0_0_4_0_0_0_0_);
								F983_8204(RTCW(tr1), loc5);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(Result))-600])(Result, tr1);
								F988_8454(RTCW(loc5));
							}
							break;
						default:
							F988_8439(RTCW(loc5), loc3);
							break;
					}
				}
				loc1++;
			}
			if (loc6) {
			} else {
				tb1 = F452_4698(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F983_8204(RTCW(tr1), loc5);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4427[Dtype(RTCW(Result))-600])(Result, tr1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_arguments */
static EIF_REFERENCE F138_2921_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(330)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(290, 0x00).id, 290, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F138_2921 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(330,F138_2921_body,(Current));
}

void EIF_Minit126 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
