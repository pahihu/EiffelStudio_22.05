
#ifndef _C3_un109_
#define _C3_un109_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_INTEGER_32 F121_2675_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F121_2675(EIF_REFERENCE);
extern EIF_INTEGER_32 F121_2699(EIF_REFERENCE);
extern EIF_INTEGER_32 F121_2705(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit109(void);

#ifdef __cplusplus
}
#endif

#endif
