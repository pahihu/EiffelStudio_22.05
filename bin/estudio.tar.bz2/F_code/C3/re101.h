
#ifndef _C3_re101_
#define _C3_re101_

#ifdef __cplusplus
extern "C" {
#endif

extern void F113_2562(EIF_REFERENCE, EIF_REFERENCE);
extern void F113_2563(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
