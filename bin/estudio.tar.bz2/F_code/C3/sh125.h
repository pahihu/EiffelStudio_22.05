
#ifndef _C3_sh125_
#define _C3_sh125_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F137_2909_body(EIF_REFERENCE);
extern EIF_REFERENCE F137_2909(EIF_REFERENCE);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
