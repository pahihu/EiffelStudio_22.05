
#ifndef _C3_nu141_
#define _C3_nu141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F153_3133(EIF_REFERENCE);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
