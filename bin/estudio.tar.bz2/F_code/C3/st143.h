
#ifndef _C3_st143_
#define _C3_st143_

#ifdef __cplusplus
extern "C" {
#endif

extern void F155_3172(EIF_REFERENCE, EIF_BOOLEAN);
extern void F155_3173(EIF_REFERENCE, EIF_BOOLEAN);
extern void F155_3174(EIF_REFERENCE, EIF_REFERENCE);
extern void F155_3175(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit143(void);
extern void F985_8280(EIF_REFERENCE, EIF_REFERENCE);
extern long O3132[];
extern long O3133[];

#ifdef __cplusplus
}
#endif

#endif
