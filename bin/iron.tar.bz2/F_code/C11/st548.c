/*
 * Code for class STRING_ENVIRONMENT_EXPANDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_ENVIRONMENT_EXPANDER}.use_environment_variables */
EIF_BOOLEAN F1100_9331 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {STRING_ENVIRONMENT_EXPANDER}.variable_32 */
EIF_REFERENCE F1100_9333 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F1100_9331(Current)) {
		if (F450_5994(Current)) {
			tr1 = F450_5996(Current);
			Result = F1448_15160(RTCW(tr1), arg1);
		} else {
			tr1 = RTOUCR(33,F1095_9251, (Current));
			Result = F455_6049(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
