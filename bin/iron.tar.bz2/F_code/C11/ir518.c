/*
 * Code for class IRON_REPOSITORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY}.initialize */
void F713_7957 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7020[Dtype(Current)-1190])(Current);
}

/* {IRON_REPOSITORY}.location_string */
EIF_REFERENCE F713_7961 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7024[Dtype(Current)-1190])(Current);
	Result = F1429_14879(RTCW(tr1));
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.new_cursor */
EIF_REFERENCE F713_7963 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.package_associated_with_id */
EIF_REFERENCE F713_7964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc1)-515])(loc1);
		if (tb1) break;
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tb2 = F1168_10049(RTCW(arg1), tr1);
		if (tb2) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc1)-515])(loc1);
	}
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.packages_associated_with_name */
EIF_REFERENCE F713_7965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1059_8908(RTCW(Result), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc2)-515])(loc2);
		if (tb1) break;
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
		tb2 = F1193_10953(RTCW(loc1), arg1);
		if (tb2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(Result))-936])(Result, loc1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc2)-515])(loc2);
	}
	tb2 = F870_8129(RTCW(Result));
	if (tb2) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.package_associated_with_uri */
EIF_REFERENCE F713_7966 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = F1429_14879(RTCW(arg1));
	loc2 = F713_7961(Current);
	tb1 = F1174_10340(RTCW(loc1), loc2);
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O8704[Dtype(loc1)-1173]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc1))-1171])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc3)-515])(loc3);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc3)-515])(loc3);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
			loc4 = F1059_8922(RTCW(tr1));
			for (;;) {
				tb2 = F659_7888(loc4);
				if (tb2) break;
				if ((EIF_BOOLEAN)(Result != NULL)) break;
				tr1 = F659_7879(loc4);
				tb3 = F1174_10340(RTCW(loc1), tr1);
				if (tb3) {
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc3)-515])(loc3);
				}
				F659_7894(loc4);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc3)-515])(loc3);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.is_located_at */
EIF_BOOLEAN F713_7967 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7024[Dtype(Current)-1190])(Current);
	Result = F1429_14881(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {IRON_REPOSITORY}.set_package_list */
void F713_7971 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
