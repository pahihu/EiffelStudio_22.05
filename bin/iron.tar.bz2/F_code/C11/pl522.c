/*
 * Code for class PLAIN_TEXT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pl522.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PLAIN_TEXT_FILE}.make_with_name */
void F937_8420 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F936_8192(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1172, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.make_with_path */
void F937_8421 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F936_8193(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1172, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.is_plain_text */
EIF_BOOLEAN F937_8422 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {PLAIN_TEXT_FILE}.put_string_32 */
void F937_8443 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F937_8444(Current, arg1);
}

/* {PLAIN_TEXT_FILE}.put_string_general */
void F937_8444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc4 = F937_8465(Current);
	tr1 = RTLNS(eif_new_type(344, 0x01).id, 344, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc2 = RTOUCR(250,F345_5028, (RTCW(tr1)));
	F69_1335(RTCW(loc2), loc4, arg1);
	tb1 = F69_1336(RTCW(loc2));
	if (tb1) {
		loc1 = F69_1332(RTCW(loc2));
	} else {
		tr1 = RTLNS(eif_new_type(344, 0x01).id, 344, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc3 = RTOUCR(251,F345_5026, (RTCW(tr1)));
		F69_1335(RTCW(loc2), loc3, arg1);
		tb1 = F69_1336(RTCW(loc2));
		if (tb1) {
			loc1 = F69_1332(RTCW(loc2));
			tb1 = F69_1338(RTCW(loc3), loc4);
			if ((EIF_BOOLEAN) !tb1) {
				F69_1335(RTCW(loc3), loc4, loc1);
				tb1 = F69_1336(RTCW(loc3));
				if (tb1) {
					loc1 = F69_1332(RTCW(loc3));
				}
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8482[Dtype(RTCW(arg1))-1171])(arg1);
			if (tb1) {
				loc1 = F1168_10060(RTCW(arg1));
			} else {
				tr2 = F1168_10066(RTCW(arg1));
				tr1 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
				loc1 = F86_1632(RTCW(tr1), tr2);
			}
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(Current)-563])(Current, loc1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_integer */
void F937_8446 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7341[dtype-936])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7337[dtype-936])(Current);
	ti4_1 = F295_4092(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_7_2_1_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_natural_8 */
void F937_8455 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7341[dtype-936])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7337[dtype-936])(Current);
	tu1_1 = F295_4095(RTCW(tr1));
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_5_5_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.encoding */
EIF_REFERENCE F937_8465 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7331[Dtype(Current)-936])(Current);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {PLAIN_TEXT_FILE}.default_encoding */
static EIF_REFERENCE F937_8466_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
#define Result RTOTRR
	RTOUDR(252)

	
	RTEV;
	RTOTP;
	tr1 = RTLNS(eif_new_type(344, 0x01).id, 344, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOUCR(251,F345_5026, (RTCW(tr1)));
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F937_8466 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(252,F937_8466_body,(Current));
}

/* {PLAIN_TEXT_FILE}.ctoi_convertor */
static EIF_REFERENCE F937_8472_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(253)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(294, 0x01).id, 294, _OBJSIZ_2_3_0_3_0_0_2_0_);
	F295_4079(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(249,F937_8473, (Current));
	F293_4047(RTCW(Result), tr1);
	F293_4046(RTCW(Result), (EIF_BOOLEAN) 1);
	F293_4045(RTCW(Result), (EIF_BOOLEAN) 0);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F937_8472 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(253,F937_8472_body,(Current));
}

/* {PLAIN_TEXT_FILE}.internal_leading_separators */

EIF_REFERENCE F937_8473 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (249,RTMS_EX_H(" \012\015\011",4,537529609));
}

/* {PLAIN_TEXT_FILE}.read_number_sequence */
void F937_8475 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3849[Dtype(RTCW(arg1))-293])(arg1, arg2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7189[dtype-936])(Current)) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_);
		}
		if (tb1) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6282[dtype-936])(Current);
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7189[dtype-936])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R3855[Dtype(RTCW(arg1))-293])(arg1, *(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3847[Dtype(RTCW(arg1))-293])(arg1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) tb2;
		}
	}
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_integer_with_no_type */
void F937_8476 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7337[Dtype(Current)-936])(Current);
	F937_8475(Current, tr1, ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_)) {
		F937_8477(Current);
	}
	RTLE;
}

/* {PLAIN_TEXT_FILE}.return_characters */
void F937_8477 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_) == (EIF_CHARACTER_8) '\012')) {
		tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7059[dtype-936])(Current);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7059[dtype-936])(Current);
	RTLE;
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
