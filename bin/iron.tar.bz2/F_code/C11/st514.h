
#ifndef _C11_st514_
#define _C11_st514_

#ifdef __cplusplus
extern "C" {
#endif

extern void F684_7911(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F684_7912(EIF_REFERENCE);
extern EIF_REFERENCE F684_7913(EIF_REFERENCE);
extern EIF_REFERENCE F684_7915(EIF_REFERENCE);
extern EIF_INTEGER_32 F684_7916(EIF_REFERENCE);
extern void EIF_Minit514(void);
extern EIF_INTEGER_32 F1174_10357(EIF_REFERENCE);
extern char *(*R8702[])();

#ifdef __cplusplus
}
#endif

#endif
