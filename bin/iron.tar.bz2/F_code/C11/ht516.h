
#ifndef _C11_ht516_
#define _C11_ht516_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F711_7956(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern EIF_BOOLEAN F659_7888(EIF_REFERENCE);
extern void F659_7894(EIF_REFERENCE);
extern EIF_REFERENCE F659_7879(EIF_REFERENCE);
extern EIF_REFERENCE F1059_8922(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
