
#ifndef _C11_sh543_
#define _C11_sh543_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1095_9251_body(EIF_REFERENCE);
extern EIF_REFERENCE F1095_9251(EIF_REFERENCE);
extern void EIF_Minit543(void);

#ifdef __cplusplus
}
#endif

#endif
