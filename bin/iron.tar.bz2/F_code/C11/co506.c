/*
 * Code for class CONF_LOAD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co506.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD}.make */
void F593_7523 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F283_3900(Current);
	F48_1051(RTCV(F283_3902(Current)));
	RTLE;
}

/* {CONF_LOAD}.report_error */
void F593_7531 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {CONF_LOAD}.reset_error */
void F593_7532 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {CONF_LOAD}.retrieve_configuration */
void F593_7540 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	F593_7532(Current);
	F593_7544(Current, arg1, NULL, NULL);
	RTLE;
}

/* {CONF_LOAD}.add_warning */
void F593_7543 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1058,0xFF01,570,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1059_8908(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(loc1))-867])(loc1, arg1);
	RTLE;
}

/* {CONF_LOAD}.recursive_retrieve_configuration */
void F593_7544 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,arg3);
	RTLR(10,tr3);
	RTLR(11,loc3);
	RTLR(12,loc6);
	RTLR(13,loc7);
	RTLR(14,tr4);
	RTLR(15,loc8);
	RTLIU(16);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(591, 0x01).id, 591, _OBJSIZ_26_3_0_1_0_0_0_0_);
	tr1 = F1168_10066(RTCW(arg1));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F592_7437(RTCW(loc1), tr1, tr2);
	F593_7551(Current, arg1, loc1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_0_);
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_2_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_8_2_) = (EIF_BOOLEAN) tb1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		F593_7531(Current, tr1);
	} else {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			loc2 = (EIF_REFERENCE) arg2;
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = RTLNS(eif_new_type(63, 0x01).id, 63, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F64_1302(RTCW(loc2));
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
					RTAR(Current, loc4);
					*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc4;
					tr1 = F1380_13293(loc4);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						tr1 = eif_boxed_item(arg3,2);
						tb1 = !RTEQ(tr1, loc5);
					}
					if (tb1) {
						tr1 = RTLNS(eif_new_type(579, 0x01).id, 579, _OBJSIZ_4_0_0_0_0_0_0_0_);
						tr2 = eif_boxed_item(arg3,1);
						tr3 = eif_boxed_item(arg3,2);
						F580_7373(RTCW(tr1), tr2, arg1, tr3, loc5);
						F593_7531(Current, tr1);
					} else {
						if ((EIF_BOOLEAN)(arg3 != NULL)) {
							
							eif_put_reference_item(RTCW(arg3),1,arg1);
							loc3 = (EIF_REFERENCE) arg3;
						} else {
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1170,0xFF01,1186,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
								tr1 = RTLNTS(typres0.id, 3, 0);
							}
							((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
							RTAR(tr1,arg1);
							((EIF_TYPED_VALUE *)tr1+2)->it_r = loc5;
							RTAR(tr1,loc5);
							loc3 = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						loc3 = (EIF_REFERENCE) arg3;
					} else {
						loc3 = (EIF_REFERENCE) NULL;
					}
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_8_3_))) {
					tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_4_);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						tr1 = F1381_13302(loc4);
						F593_7546(Current, arg1, tr1, loc3, loc2);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tr1 = RTLNS(eif_new_type(578, 0x01).id, 578, _OBJSIZ_3_0_0_0_0_0_0_0_);
						tr2 = *(EIF_REFERENCE *)(loc4 + _REFACS_2_);
						F579_7368(RTCW(tr1), arg1, tr2, loc6);
						F593_7543(Current, tr1);
					} else {
						tr1 = F1381_13302(loc4);
						F593_7546(Current, arg1, tr1, loc3, loc2);
					}
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					F1380_13295(loc7, arg1);
					F1380_13296(loc7);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						tr1 = eif_boxed_item(arg3,2);
						tr2 = *(EIF_REFERENCE *)(loc7 + _REFACS_5_);
						tb1 = !RTEQ(tr1, tr2);
					}
					if (tb1) {
						tb1 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_16_2_);
						if (tb1) {
							tr1 = RTLNS(eif_new_type(579, 0x01).id, 579, _OBJSIZ_4_0_0_0_0_0_0_0_);
							tr2 = eif_boxed_item(arg3,1);
							tr3 = eif_boxed_item(arg3,2);
							F580_7373(RTCW(tr1), tr2, arg1, tr3, NULL);
							F593_7531(Current, tr1);
						} else {
							tr1 = RTLNS(eif_new_type(579, 0x01).id, 579, _OBJSIZ_4_0_0_0_0_0_0_0_);
							tr2 = eif_boxed_item(arg3,1);
							tr3 = eif_boxed_item(arg3,2);
							tr4 = *(EIF_REFERENCE *)(loc7 + _REFACS_5_);
							F580_7373(RTCW(tr1), tr2, arg1, tr3, tr4);
							F593_7531(Current, tr1);
						}
					}
				} else {
					F424_5537(RTCW(loc1));
					tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_2_);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_8_2_) = (EIF_BOOLEAN) tb1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
					loc8 = tr1;
					if (EIF_TEST(loc8)) {
						F593_7531(Current, loc8);
						tr1 = RTMS_EX_H("Tag \"system\" not found",22,1606008420);
						F582_7398(loc8, tr1);
					} else {
						F593_7532(Current);
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD}.retrieve_redirected_configuration */
void F593_7546 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,arg4);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,arg3);
	RTLIU(10);
	
	RTGC;
	loc1 = F593_7549(Current, arg2, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg4));
	loc2 = F1059_8922(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F659_7888(loc2);
		if (tb2) break;
		tr1 = F659_7879(loc2);
		tb3 = F1194_11003(RTCW(loc1), tr1);
		tb1 = tb3;
		F659_7894(loc2);
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(577, 0x01).id, 577, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = F1194_11030(RTCW(loc1));
		tr3 = *(EIF_REFERENCE *)(RTCW(arg4));
		F578_7364(RTCW(tr1), tr2, tr3);
		F593_7531(Current, tr1);
	} else {
		F64_1304(RTCW(arg4), loc1);
		tr1 = F1194_11030(RTCW(loc1));
		F593_7544(Current, tr1, arg4, arg3);
	}
	RTLE;
}

/* {CONF_LOAD}.conf_location_value_to_path */
EIF_REFERENCE F593_7548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1194_10991(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1173_10213(RTCW(loc1), arg1);
		tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
		tr2 = RTMS32_EX_H("/\000\000\000",1,47);
		F1173_10229(RTCW(loc1), tr1, tr2);
		tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1194_10991(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_LOAD}.conf_redirection_location_for_file */
EIF_REFERENCE F593_7549 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	Result = F593_7548(Current, arg1);
	tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1194_10991(RTCW(tr1), arg2);
	tr1 = F1194_11006(RTCW(tr1));
	tr1 = F1194_11011(RTCW(Result), tr1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {CONF_LOAD}.parse_file */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F593_7551 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,arg2);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc1);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc5);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,loc11);
	RTLR(15,saved_except);
	RTLIU(16);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc6) {
		F593_7532(Current);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
		if (tb1) {
			tr1 = RTLNS(eif_new_type(580, 0x01).id, 580, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr2 = F1168_10066(RTCW(arg1));
			F581_7379(RTCW(tr1), tr2);
			F593_7531(Current, tr1);
		} else {
			tr1 = RTLNS(eif_new_type(332, 0x01).id, 332, _OBJSIZ_5_5_0_5_0_0_0_0_);
			F332_4661(RTCW(tr1));
			loc2 = (EIF_REFERENCE) tr1;
			F327_4615(RTCW(arg2), loc2);
			tr1 = RTLNS(eif_new_type(334, 0x01).id, 334, _OBJSIZ_4_0_0_0_0_0_0_0_);
			F335_4766(RTCW(tr1), arg2);
			loc4 = (EIF_REFERENCE) tr1;
			F327_4615(RTCW(loc4), loc2);
			tr1 = RTLNS(eif_new_type(335, 0x01).id, 335, _OBJSIZ_8_1_0_0_0_0_0_0_);
			F336_4783(RTCW(tr1), loc4);
			loc3 = (EIF_REFERENCE) tr1;
			F327_4615(RTCW(loc3), loc2);
			F332_4668(RTCW(loc2), loc3);
			tr1 = RTLNS(eif_new_type(936, 0x01).id, 936, _OBJSIZ_5_7_2_4_1_1_2_1_);
			F937_8420(RTCW(tr1), arg1);
			loc1 = (EIF_REFERENCE) tr1;
			tb1 = '\0';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[Dtype(RTCW(loc1))-568])(loc1);
			if (tb2) {
				tb2 = F936_8234(RTCW(loc1));
				tb1 = tb2;
			}
			if (tb1) {
				F936_8262(RTCW(loc1));
			}
			tb1 = F936_8252(RTCW(loc1));
			if (tb1) {
				F332_4665(RTCW(loc2), loc1);
				F936_8279(RTCW(loc1));
			} else {
				tr1 = RTLNS(eif_new_type(580, 0x01).id, 580, _OBJSIZ_3_0_0_0_0_0_0_0_);
				tr2 = F1168_10066(RTCW(arg1));
				F581_7379(RTCW(tr1), tr2);
				F593_7531(Current, tr1);
			}
		}
	} else {
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					loc5 = (EIF_REFERENCE) loc8;
				} else {
					loc5 = F332_4677(RTCW(loc2));
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
				ti4_1 = F1188_10675(RTCW(loc5));
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_1_);
				F582_7397(loc7, tr1, ti4_1, ti4_2);
				F582_7395(loc7);
			} else {
				F424_5537(RTCW(arg2));
			}
		} else {
			F424_5537(RTCW(arg2));
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			F593_7531(Current, loc9);
		} else {
		}
	}
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_26_1_);
		tb1 = tb2;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_) = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			tb2 = F870_8129(loc11);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7162[Dtype(loc10)-1053])(loc10, loc11);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
