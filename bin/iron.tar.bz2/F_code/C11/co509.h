
#ifndef _C11_co509_
#define _C11_co509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F596_7696(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit509(void);
extern void F961_8559(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F961_8564(EIF_REFERENCE, EIF_REFERENCE);
extern void F961_8605(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1114_9633(EIF_REFERENCE);
extern char *(*R8527[])();
extern char *(*R8528[])();

#ifdef __cplusplus
}
#endif

#endif
