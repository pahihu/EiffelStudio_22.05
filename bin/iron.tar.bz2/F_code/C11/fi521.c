/*
 * Code for class FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi521.h"
#include "eif_file.h"
#include "eif_retrieve.h"
#include "eif_store.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE}.make_with_name */
void F936_8192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F936_8355(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp2;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.make_with_path */
void F936_8193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F936_8356(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp2;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.make_open_read */
void F936_8194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7164[Dtype(Current)-936])(Current, arg1);
	F936_8262(Current);
	RTLE;
}

/* {FILE}.make_open_append */
void F936_8196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7164[Dtype(Current)-936])(Current, arg1);
	F936_8264(Current);
	RTLE;
}

/* {FILE}.make_open_temporary_with_prefix */
void F936_8201 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	tr2 = RTMS32_EX_H("X\000\000\000X\000\000\000X\000\000\000X\000\000\000X\000\000\000X\000\000\000",6,1655875672);
	tr1 = F1173_10271(RTCW(tr1), tr2);
	F936_8355(Current, tr1);
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6221[dtype-563])(Current);
	loc1 = (EIF_INTEGER_32) eif_file_mkstemp((EIF_FILENAME) tp1, (EIF_BOOLEAN) tb1);
	tr1 = RTOUCR(483,F936_8361, (Current));
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tr1 = F476_6135(RTCW(tr1), tp1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7164[dtype-936])(Current, tr1);
	F936_8271(Current, loc1);
	RTLE;
}

/* {FILE}.path */
EIF_REFERENCE F936_8202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	F1194_10995(RTCW(Result), tp1);
	RTLE;
	return Result;
}

/* {FILE}.item */
EIF_CHARACTER_8 F936_8204 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6282[dtype-936])(Current);
	Result = *(EIF_CHARACTER_8 *)(Current + O6222[dtype-562]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7059[dtype-936])(Current);
	RTLE;
	return Result;
}

/* {FILE}.position */
EIF_INTEGER_32 F936_8205 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F936_8251(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_file_tell((FILE*) tp1);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {FILE}.descriptor */
EIF_INTEGER_32 F936_8206 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O7177[dtype-935]);
	Result = (EIF_INTEGER_32) eif_file_fd((FILE*) tp1);
	*(EIF_BOOLEAN *)(Current + O7325[dtype-935]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
	return Result;
}

/* {FILE}.descriptor_available */
EIF_BOOLEAN F936_8207 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O7325[Dtype(Current)-935]);
}


/* {FILE}.date */
EIF_INTEGER_32 F936_8217 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) eif_file_date((EIF_FILENAME) tp1);
	RTLE;
	return Result;
}

/* {FILE}.retrieved */
EIF_REFERENCE F936_8219 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(529, 0x01).id, 529, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(10,F530_6451, (RTCW(tr1)));
	{
		/* INLINED CODE (ANY.do_nothing) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	ti4_1 = F936_8206(Current);
	Result = (EIF_REFERENCE) eretrieve(ti4_1);
	RTLE;
	return Result;
}

/* {FILE}.count */
EIF_INTEGER_32 F936_8222 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[dtype-568])(Current)) {
		if ((EIF_BOOLEAN) !F936_8253(Current)) {
			F936_8363(Current);
			Result = F476_6121(RTCV(RTOUCR(483,F936_8361, (Current))));
		} else {
			tp1 = *(EIF_POINTER *)(Current + O7177[dtype-935]);
			Result = (EIF_INTEGER_32) eif_file_size((FILE*) tp1);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {FILE}.after */
EIF_BOOLEAN F936_8223 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F936_8251(Current)) {
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7189[dtype-936])(Current)) {
			tb1 = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[dtype-908])(Current) == ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE}.before */
EIF_BOOLEAN F936_8224 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F936_8251(Current);
}

/* {FILE}.off */
EIF_BOOLEAN F936_8225 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[dtype-908])(Current) == ((EIF_INTEGER_32) 0L))) {
		tb1 = F936_8251(Current);
	}
	if (!tb1) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7189[dtype-936])(Current);
	}
	RTLE;
	return Result;
}

/* {FILE}.end_of_file */
EIF_BOOLEAN F936_8226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) tp1));
}

/* {FILE}.exists */
EIF_BOOLEAN F936_8227 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F936_8251(Current)) {
		tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
		Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {FILE}.is_readable */
EIF_BOOLEAN F936_8230 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6148(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_writable */
EIF_BOOLEAN F936_8231 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6149(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_executable */
EIF_BOOLEAN F936_8232 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6150(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_creatable */
EIF_BOOLEAN F936_8233 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F936_8353(Current))+ _LNGOFF_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_creatable((EIF_FILENAME) tp1, (EIF_INTEGER) ti4_1));
	RTLE;
	return Result;
}

/* {FILE}.is_plain */
EIF_BOOLEAN F936_8234 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6140(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_directory */
EIF_BOOLEAN F936_8236 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6142(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_access_readable */
EIF_BOOLEAN F936_8246 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6156(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.is_access_writable */
EIF_BOOLEAN F936_8247 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6157(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.file_readable */
EIF_BOOLEAN F936_8250 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) >= ((EIF_INTEGER_32) 4L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 1L)))) {
		Result = F916_8184(Current);
	}
	RTLE;
	return Result;
}

/* {FILE}.is_closed */
EIF_BOOLEAN F936_8251 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[Dtype(Current)-935]) == ((EIF_INTEGER_32) 0L));
}

/* {FILE}.is_open_read */
EIF_BOOLEAN F936_8252 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 5L)));
}

/* {FILE}.is_open_write */
EIF_BOOLEAN F936_8253 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 5L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) == ((EIF_INTEGER_32) 3L)));
}

/* {FILE}.extendible */
EIF_BOOLEAN F936_8256 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O7316[Dtype(Current)-935]) >= ((EIF_INTEGER_32) 2L));
}

/* {FILE}.open_read */
void F936_8262 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R7258[dtype-936])(Current, tp1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {FILE}.open_write */
void F936_8263 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R7258[dtype-936])(Current, tp1, ((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTLE;
}

/* {FILE}.open_append */
void F936_8264 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R7258[dtype-936])(Current, tp1, ((EIF_INTEGER_32) 2L));
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	RTLE;
}

/* {FILE}.create_read_write */
void F936_8266 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R7258[dtype-936])(Current, tp1, ((EIF_INTEGER_32) 4L));
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	RTLE;
}

/* {FILE}.fd_open_read_write */
void F936_8271 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7274[dtype-936])(Current, arg1, ((EIF_INTEGER_32) 3L));
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	RTLE;
}

/* {FILE}.close */
void F936_8279 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R7259[dtype-936])(Current, *(EIF_POINTER *)(Current + O7177[dtype-935]));
	*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O7177[dtype-935]) = (EIF_POINTER) tp2;
	*(EIF_BOOLEAN *)(Current + O7325[dtype-935]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {FILE}.start */
void F936_8280 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
}

/* {FILE}.forth */
void F936_8282 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O7177[dtype-935]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current + O7177[dtype-935]);
	tc1 = F936_8370(Current, tp1);
	eif_do_nothing_value.it_c1 = tc1;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7189[dtype-936])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7059[dtype-936])(Current);
	}
	RTLE;
}

/* {FILE}.back */
void F936_8283 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) -1L));
}

/* {FILE}.go */
void F936_8285 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) arg1);
}

/* {FILE}.new_cursor */
EIF_REFERENCE F936_8288 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(545, 0x01).id, 545, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tr1 = F936_8353(Current);
	F546_6544(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {FILE}.extend */
void F936_8289 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6254[Dtype(Current)-936])(Current, arg1);
}

/* {FILE}.put_string */
void F936_8301 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
		tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
		F936_8390(Current, tp1, loc2, loc1);
	}
	RTLE;
}

/* {FILE}.put_character */
void F936_8304 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	eif_file_pc((FILE*) tp1, (EIF_CHARACTER) arg1);
}

/* {FILE}.put_new_line */
void F936_8306 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	F936_8388(Current, tp1);
}

/* {FILE}.new_line */
void F936_8307 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	F936_8388(Current, tp1);
}

/* {FILE}.rename_path */
void F936_8313 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = F1194_11032(RTCW(arg1));
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	eif_file_rename((EIF_FILENAME) tp1, (EIF_FILENAME) tp2);
	F936_8356(Current, arg1);
	RTLE;
}

/* {FILE}.change_date */
EIF_INTEGER_32 F936_8319 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F936_8363(Current);
	Result = F476_6126(RTCV(RTOUCR(483,F936_8361, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.independent_store */
void F936_8323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F936_8206(Current);
	sstore((EIF_INTEGER) ti4_1, (EIF_REFERENCE) arg1);
	RTLE;
}

/* {FILE}.delete */
void F936_8325 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F936_8353(Current))+ _PTROFF_0_1_0_1_0_0_);
	eif_file_unlink((EIF_FILENAME) tp1);
	RTLE;
}

/* {FILE}.reset_path */
void F936_8327 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F936_8356(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7316[dtype-935]) != ((EIF_INTEGER_32) 0L))) {
		F936_8279(Current);
	}
	*(EIF_INTEGER_32 *)(Current + O6224[dtype-562]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_REAL_32 *)(Current + O6234[dtype-562]) = (EIF_REAL_32) (EIF_REAL_32) (EIF_REAL_64) 0.0;
	*(EIF_REAL_64 *)(Current + O6236[dtype-562]) = (EIF_REAL_64) (EIF_REAL_64) 0.0;
	*(EIF_CHARACTER_8 *)(Current + O6222[dtype-562]) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(tr1))-1172])(tr1);
	RTLE;
}

/* {FILE}.read_character */
void F936_8334 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O7177[dtype-935]);
	tc1 = F936_8370(Current, tp1);
	*(EIF_CHARACTER_8 *)(Current + O6222[dtype-562]) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {FILE}.read_line */
void F936_8338 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(Current);
	loc3 = *(EIF_REFERENCE *)(RTCW(loc5));
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8506[Dtype(RTCW(loc5))-1171])(loc5);
	for (;;) {
		if (loc4) break;
		tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
		loc2 += (EIF_INTEGER_32) eif_file_gs((FILE*) tp1, (char*) loc3, (EIF_INTEGER) loc1, (EIF_INTEGER) loc2);
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			F1176_10466(RTCW(loc5), loc1);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 2048L))) {
				F1176_10450(RTCW(loc5), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1024L)));
			} else {
				F898_8137(RTCW(loc5));
			}
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8506[Dtype(RTCW(loc5))-1171])(loc5);
			loc2--;
			loc3 = *(EIF_REFERENCE *)(RTCW(loc5));
		} else {
			F1176_10466(RTCW(loc5), loc2);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {FILE}.read_line_thread_aware */
void F936_8340 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLIU(3);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(Current);
	loc7 = RTOUCR(247,F936_8362, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(loc4))-1172])(loc4);
	loc1 = F503_6422(RTCW(loc7));
	for (;;) {
		if (loc3) break;
		tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
		tp2 = F503_6420(RTCW(loc7));
		loc2 = F936_8374(Current, tp1, tp2, loc1, ((EIF_INTEGER_32) 0L));
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O8704[Dtype(loc4)-1173]);
		loc6 = eif_min_int32 (loc2,loc1);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc6);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= loc1);
		F1176_10450(RTCW(loc4), loc6);
		F1176_10466(RTCW(loc4), loc6);
		ti4_1 = eif_min_int32 (loc2,loc1);
		F503_6414(RTCW(loc7), loc4, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
	}
	RTLE;
}

/* {FILE}.read_stream */
void F936_8341 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current);
	F1176_10450(RTCW(loc2), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	ti4_1 = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) loc1, (EIF_INTEGER) arg1);
	F1176_10466(RTCW(loc2), ti4_1);
	RTLE;
}

/* {FILE}.read_stream_thread_aware */
void F936_8343 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current);
	loc2 = RTOUCR(247,F936_8362, (Current));
	F503_6428(RTCW(loc2), arg1);
	tp1 = *(EIF_POINTER *)(Current + O7177[Dtype(Current)-935]);
	tp2 = F503_6420(RTCW(loc2));
	loc1 = F936_8375(Current, tp1, tp2, arg1);
	F503_6428(RTCW(loc2), loc1);
	F1176_10450(RTCW(loc3), loc1);
	F1176_10466(RTCW(loc3), loc1);
	F503_6416(RTCW(loc2), loc3);
	RTLE;
}

/* {FILE}.copy_to */
void F936_8349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[dtype-908])(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51200L);
	loc5 = *(EIF_REFERENCE *)(Current);
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	F1174_10304(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc4 = F936_8205(Current);
	if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
		F936_8285(Current, ((EIF_INTEGER_32) 0L));
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 >= loc3)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6295[dtype-936])(Current, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(RTCW(arg1))-563])(arg1, *(EIF_REFERENCE *)(Current));
		loc2 += loc1;
	}
	if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
		F936_8285(Current, loc4);
	}
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc5;
	RTLE;
}

/* {FILE}.file_open */
EIF_POINTER F936_8350 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_open((EIF_FILENAME) arg1, (int) arg2);
	
	return Result;
}

/* {FILE}.file_close */
void F936_8351 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_close((FILE*) arg1);
	
}

/* {FILE}.internal_name_pointer */
EIF_REFERENCE F936_8353 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FILE}.set_name */
void F936_8355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTOUCR(483,F936_8361, (Current));
	tr1 = F476_6134(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.set_path */
void F936_8356 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1194_11030(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F1194_11032(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.buffered_file_info */
static EIF_REFERENCE F936_8361_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(483)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(475, 0x01).id, 475, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F476_6117(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F936_8361 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(483,F936_8361_body,(Current));
}

/* {FILE}.read_data_buffer */
static EIF_REFERENCE F936_8362_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(247)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F503_6399(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F936_8362 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(247,F936_8362_body,(Current));
}

/* {FILE}.set_buffer */
void F936_8363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(483,F936_8361, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr3 = F936_8353(Current);
	F476_6164(RTCW(tr1), tr2, tr3);
	RTLE;
}

/* {FILE}.file_unlink */
void F936_8365 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_unlink((EIF_FILENAME) arg1);
	
}

/* {FILE}.file_dopen */
EIF_POINTER F936_8366 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_dopen((int) arg1, (int) arg2);
	
	return Result;
}

/* {FILE}.file_fd */
EIF_INTEGER_32 F936_8369 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_fd((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_gc */
EIF_CHARACTER_8 F936_8370 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) eif_file_gc((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_gs */
EIF_INTEGER_32 F936_8371 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gs((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	return Result;
}

/* {FILE}.file_gss */
EIF_INTEGER_32 F936_8372 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gss((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	return Result;
}

/* {FILE}.file_gs_ta */
EIF_INTEGER_32 F936_8374 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_INTEGER_32) eif_file_gs((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_gss_ta */
EIF_INTEGER_32 F936_8375 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_INTEGER_32) eif_file_gss((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_size */
EIF_INTEGER_32 F936_8378 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_size((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_tell */
EIF_INTEGER_32 F936_8380 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_tell((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_rename */
void F936_8382 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	eif_file_rename((EIF_FILENAME) arg1, (EIF_FILENAME) arg2);
	
}

/* {FILE}.file_tnwl */
void F936_8388 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	EIF_ENTER_C;eif_file_tnwl((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
}

/* {FILE}.file_ps */
void F936_8390 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	EIF_ENTER_C;eif_file_ps((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
}

/* {FILE}.file_pc */
void F936_8391 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	
	eif_file_pc((FILE*) arg1, (EIF_CHARACTER) arg2);
	
}

/* {FILE}.file_go */
void F936_8392 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_go((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.file_move */
void F936_8394 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_move((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.file_feof */
EIF_BOOLEAN F936_8395 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) arg1));
	
	return Result;
}

/* {FILE}.file_exists */
EIF_BOOLEAN F936_8396 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) arg1));
	
	return Result;
}

/* {FILE}.file_creatable */
EIF_BOOLEAN F936_8399 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_creatable((EIF_FILENAME) arg1, (EIF_INTEGER) arg2));
	
	return Result;
}

/* {FILE}.c_retrieved */
EIF_REFERENCE F936_8400 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	Result = (EIF_REFERENCE) eretrieve(arg1);
	
	RTLE;
	return Result;
}

/* {FILE}.c_independent_store */
void F936_8403 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	GTCX
	
	sstore((EIF_INTEGER) arg1, (EIF_REFERENCE) arg2);
	
}

/* {FILE}.eif_file_date */
EIF_INTEGER_32 F936_8404 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_date((EIF_FILENAME) arg1);
	
	return Result;
}

/* {FILE}.eif_temp_file */
EIF_INTEGER_32 F936_8406 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_mkstemp((EIF_FILENAME) arg1, (EIF_BOOLEAN) arg2);
	
	return Result;
}

/* {FILE}.set_read_mode */
void F936_8418 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O7316[Dtype(Current)-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {FILE}.set_write_mode */
void F936_8419 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O7316[Dtype(Current)-935]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
