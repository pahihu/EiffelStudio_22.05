/*
 * Code for class IRON_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir545.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_UTILITIES}.build_package_archive_command */
EIF_REFERENCE F1097_9272 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,arg1);
	RTLR(6,loc3);
	RTLR(7,arg2);
	RTLR(8,loc1);
	RTLR(9,arg3);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTMS_EX_H("IRON_BUILD_ARCHIVE_COMMAND_PATTERN",34,347940430);
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1171_10139(RTCW(Result), loc2);
		tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000S\000\000\000O\000\000\000U\000\000\000R\000\000\000C\000\000\000E\000\000\000D\000\000\000I\000\000\000R\000\000\000#\000\000\000#\000\000\000",13,181549347);
		tr2 = F1194_11030(RTCW(arg1));
		F1173_10229(RTCW(Result), tr1, tr2);
		tr1 = F1194_11007(RTCW(arg2));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000A\000\000\000R\000\000\000C\000\000\000H\000\000\000I\000\000\000V\000\000\000E\000\000\000D\000\000\000I\000\000\000R\000\000\000#\000\000\000#\000\000\000",14,1933062691);
			tr2 = F1194_11006(RTCW(arg2));
			tr2 = F1194_11030(RTCW(tr2));
			F1173_10229(RTCW(Result), tr1, tr2);
			tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000A\000\000\000R\000\000\000C\000\000\000H\000\000\000I\000\000\000V\000\000\000E\000\000\000N\000\000\000A\000\000\000M\000\000\000E\000\000\000#\000\000\000#\000\000\000",15,881634595);
			tr2 = F1194_11030(loc3);
			F1173_10229(RTCW(Result), tr1, tr2);
		} else {
			tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000A\000\000\000R\000\000\000C\000\000\000H\000\000\000I\000\000\000V\000\000\000E\000\000\000D\000\000\000I\000\000\000R\000\000\000#\000\000\000#\000\000\000",14,1933062691);
			tr2 = F1168_10066(RTMS_EX_H(".",1,46));
			F1173_10229(RTCW(Result), tr1, tr2);
			tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000A\000\000\000R\000\000\000C\000\000\000H\000\000\000I\000\000\000V\000\000\000E\000\000\000N\000\000\000A\000\000\000M\000\000\000E\000\000\000#\000\000\000#\000\000\000",15,881634595);
			tr2 = F1194_11030(RTCW(arg2));
			F1173_10229(RTCW(Result), tr1, tr2);
		}
	} else {
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1168_10007(RTCW(Result));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7910[Dtype(RTCW(arg3))-1102])(arg3);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1194_10990(RTCW(loc1));
		}
		tr1 = RTMS_EX_H("iron_build_archive",18,1808998245);
		tr1 = F1194_11018(RTCW(loc1), tr1);
		loc1 = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = RTMS_EX_H("bat",3,6447476);
			tr1 = F1194_11021(RTCW(loc1), tr1);
			loc1 = (EIF_REFERENCE) tr1;
		}
		tr1 = F1097_9279(Current, loc1);
		F1173_10252(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1173_10265(RTCW(Result), tw1);
		tr1 = F1097_9279(Current, arg1);
		F1173_10252(RTCW(Result), tr1);
		tr1 = F1194_11007(RTCW(arg2));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F1173_10265(RTCW(Result), tw1);
			tr1 = F1194_11006(RTCW(arg2));
			tr1 = F1097_9279(Current, tr1);
			F1173_10252(RTCW(Result), tr1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F1173_10265(RTCW(Result), tw1);
			tr1 = F1097_9279(Current, loc4);
			F1173_10252(RTCW(Result), tr1);
		} else {
			tr1 = RTMS_EX_H(" . ",3,2108960);
			F1173_10251(RTCW(Result), tr1);
			tr1 = F1097_9279(Current, arg2);
			F1173_10252(RTCW(Result), tr1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			F1173_10265(RTCW(Result), tw1);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_UTILITIES}.extract_package_archive_command */
EIF_REFERENCE F1097_9273 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,arg1);
	RTLR(6,arg2);
	RTLR(7,loc1);
	RTLR(8,arg3);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTMS_EX_H("IRON_EXTRACT_ARCHIVE_COMMAND_PATTERN",36,1903888974);
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1171_10139(RTCW(Result), loc2);
		tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000A\000\000\000R\000\000\000C\000\000\000H\000\000\000I\000\000\000V\000\000\000E\000\000\000N\000\000\000A\000\000\000M\000\000\000E\000\000\000#\000\000\000#\000\000\000",15,881634595);
		tr2 = F1194_11030(RTCW(arg1));
		F1173_10229(RTCW(Result), tr1, tr2);
		tr1 = RTMS32_EX_H("#\000\000\000#\000\000\000F\000\000\000O\000\000\000L\000\000\000D\000\000\000E\000\000\000R\000\000\000N\000\000\000A\000\000\000M\000\000\000E\000\000\000#\000\000\000#\000\000\000",14,607800611);
		tr2 = F1194_11030(RTCW(arg2));
		F1173_10229(RTCW(Result), tr1, tr2);
	} else {
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1168_10007(RTCW(Result));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7910[Dtype(RTCW(arg3))-1102])(arg3);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1194_10990(RTCW(loc1));
		}
		tr1 = RTMS_EX_H("iron_extract_archive",20,254196837);
		tr1 = F1194_11018(RTCW(loc1), tr1);
		loc1 = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = RTMS_EX_H("bat",3,6447476);
			tr1 = F1194_11021(RTCW(loc1), tr1);
			loc1 = (EIF_REFERENCE) tr1;
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
		tr1 = F1194_11030(RTCW(loc1));
		F1173_10252(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1173_10265(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
		tr1 = F1194_11030(RTCW(arg1));
		F1173_10252(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1173_10265(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
		tr1 = F1194_11030(RTCW(arg2));
		F1173_10252(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1173_10265(RTCW(Result), tw1);
	}
	RTLE;
	return Result;
}

/* {IRON_UTILITIES}.build_package_archive */
EIF_REFERENCE F1097_9274 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(15);
	RTLR(0,arg1);
	RTLR(1,loc7);
	RTLR(2,loc5);
	RTLR(3,arg2);
	RTLR(4,loc1);
	RTLR(5,loc6);
	RTLR(6,arg3);
	RTLR(7,loc2);
	RTLR(8,loc4);
	RTLR(9,tr1);
	RTLR(10,tr2);
	RTLR(11,arg4);
	RTLR(12,Current);
	RTLR(13,loc3);
	RTLR(14,Result);
	RTLIU(15);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc7 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	} else {
		loc7 = RTMS_EX_H("",0,0);
	}
	loc5 = F1194_11010(RTCW(arg2));
	loc1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F562_6842(RTCW(loc1), loc5);
	tb1 = F562_6865(RTCW(loc1));
	if (tb1) {
		loc6 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(loc6), arg3);
		tb1 = F936_8227(RTCW(loc6));
		if (tb1) {
			F936_8325(RTCW(loc6));
		}
		loc6 = (EIF_REFERENCE) NULL;
		loc2 = RTLNS(eif_new_type(174, 0x01).id, 174, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = F1194_11010(RTCW(arg2));
		tr2 = F1194_11010(RTCW(arg3));
		loc4 = F1097_9272(Current, tr1, tr2, arg4);
		tr1 = F1194_11030(RTCW(loc5));
		loc3 = F175_2752(RTCW(loc2), loc4, tr1);
		tr1 = RTMS_EX_H(".tmp.output.proc.",17,216946478);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc7);
		F1107_9489(RTCW(loc3), tr1);
		F1107_9494(RTCW(loc3));
		F1108_9511(RTCW(loc3));
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_21_6_);
		if (tb1) {
			F1108_9512(RTCW(loc3));
		}
		loc6 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		tr1 = RTMS_EX_H(".tmp.output.proc.",17,216946478);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc7);
		F936_8192(RTCW(loc6), tr1);
		F1097_9277(Current, loc6);
		Result = RTLNS(eif_new_type(58, 0x01).id, 58, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F59_1221(RTCW(Result), arg3);
		tb1 = F59_1225(RTCW(Result));
		if ((EIF_BOOLEAN) !tb1) {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_UTILITIES}.extract_package_archive */
void F1097_9275 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg4);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	tr1 = F1193_10966(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1097_9276(Current, loc1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {IRON_UTILITIES}.extract_package_archive_file */
void F1097_9276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc5);
	RTLR(1,arg2);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,arg1);
	RTLR(6,arg4);
	RTLR(7,Current);
	RTLR(8,loc3);
	RTLR(9,tr1);
	RTLR(10,loc6);
	RTLIU(11);
	
	RTGC;
	loc5 = F1194_11010(RTCW(arg2));
	loc1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F562_6842(RTCW(loc1), loc5);
	tb1 = F562_6865(RTCW(loc1));
	if (tb1) {
		F562_6871(RTCW(loc1));
	}
	tb1 = F562_6865(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		F562_6845(RTCW(loc1));
	}
	loc2 = RTLNS(eif_new_type(174, 0x01).id, 174, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc4 = F1097_9273(Current, arg1, loc5, arg4);
	tr1 = F1194_11030(RTCW(loc5));
	loc3 = F175_2752(RTCW(loc2), loc4, tr1);
	tr1 = RTMS_EX_H(".tmp.output.proc",16,1712120419);
	tr1 = F1194_11018(RTCW(loc5), tr1);
	tr1 = F1194_11030(RTCW(tr1));
	F1107_9489(RTCW(loc3), tr1);
	F1107_9494(RTCW(loc3));
	F1108_9511(RTCW(loc3));
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_21_6_);
	if (tb1) {
		F1108_9512(RTCW(loc3));
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_21_10_);
		if ((EIF_BOOLEAN) !tb1) {
		}
	}
	loc6 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = RTMS_EX_H(".tmp.output.proc",16,1712120419);
	tr1 = F1194_11018(RTCW(loc5), tr1);
	F936_8193(RTCW(loc6), tr1);
	F1097_9277(Current, loc6);
	RTLE;
}

/* {IRON_UTILITIES}.delete_file */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1097_9277 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 5L))) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[Dtype(RTCW(arg1))-568])(arg1);
		if (tb1) {
			F936_8325(RTCW(arg1));
		}
	}
	RTE_E
	RTXSC;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	F455_6065(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 1000000L));
	loc1++;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {IRON_UTILITIES}.safe_path_name_in_script */
EIF_REFERENCE F1097_9279 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F1194_11030(RTCW(arg1));
	F1171_10139(RTCW(Result), tr1);
	tb1 = F878_8129(RTCW(Result));
	if (tb1) {
		Result = RTMS32_EX_H("",0,0);
	} else {
		tw1 = F1173_10219(RTCW(Result), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		if ((EIF_BOOLEAN)(tw1 == tw2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			tw1 = F1173_10219(RTCW(Result), ti4_1);
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(tw1 != tw2)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				F1173_10265(RTCW(Result), tw1);
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc3)) break;
				tw1 = F1173_10219(RTCW(Result), loc1);
				tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				loc3 = F1120_9843(RTCW(tr1));
				loc1++;
			}
			if (loc3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				F1173_10243(RTCW(Result), tw1);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				F1173_10265(RTCW(Result), tw1);
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
