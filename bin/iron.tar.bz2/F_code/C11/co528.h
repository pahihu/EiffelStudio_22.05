
#ifndef _C11_co528_
#define _C11_co528_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1075_8998(EIF_REFERENCE, EIF_REFERENCE);
extern void F1075_8999(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1075_9000(EIF_REFERENCE, EIF_REFERENCE);
extern void F1075_9001(EIF_REFERENCE, EIF_REFERENCE);
extern void F1075_9002(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit528(void);
extern void F961_8558(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8908(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1168_10007(EIF_REFERENCE);
extern EIF_REFERENCE F1168_10067(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
