
#ifndef _C11_kl530_
#define _C11_kl530_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1077_9036_body(EIF_REFERENCE);
extern EIF_REFERENCE F1077_9036(EIF_REFERENCE);
extern void EIF_Minit530(void);

#ifdef __cplusplus
}
#endif

#endif
