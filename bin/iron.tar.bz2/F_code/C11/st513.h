
#ifndef _C11_st513_
#define _C11_st513_

#ifdef __cplusplus
extern "C" {
#endif

extern void F683_7905(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F683_7906(EIF_REFERENCE);
extern EIF_REFERENCE F683_7907(EIF_REFERENCE);
extern EIF_REFERENCE F683_7909(EIF_REFERENCE);
extern EIF_INTEGER_32 F683_7910(EIF_REFERENCE);
extern void EIF_Minit513(void);
extern EIF_INTEGER_32 F1171_10189(EIF_REFERENCE);
extern char *(*R8622[])();

#ifdef __cplusplus
}
#endif

#endif
