
#ifndef _C11_ht512_
#define _C11_ht512_

#ifdef __cplusplus
extern "C" {
#endif

extern void F611_7748(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
static EIF_REFERENCE F611_7820_body(EIF_REFERENCE);
extern EIF_REFERENCE F611_7820(EIF_REFERENCE);
extern void EIF_Minit512(void);
extern void F1174_10304(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1076_9029(EIF_REFERENCE, EIF_REFERENCE);
extern void F1174_10306(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8728[])();
extern long O8704[];

#ifdef __cplusplus
}
#endif

#endif
