
#ifndef _C11_co527_
#define _C11_co527_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1071_8974(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit527(void);
extern void F1059_8908(EIF_REFERENCE, EIF_INTEGER_32);
extern void F714_7977(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
