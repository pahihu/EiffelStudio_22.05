/*
 * Code for class CONF_VISIBLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VISIBLE}.add_visible */
void F596_7696 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,arg2);
	RTLR(9,loc6);
	RTLR(10,arg4);
	RTLR(11,loc4);
	RTLR(12,tr1);
	RTLIU(13);
	
	RTGC;
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc7 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc7 = RTLNSMART(typres0.id);
		}
		F961_8559(RTCW(loc7), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc7;
	}
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8528[Dtype(RTCW(arg1))-1171])(arg1);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8528[Dtype(RTCW(arg3))-1171])(arg3);
	} else {
		loc3 = (EIF_REFERENCE) loc5;
	}
	loc2 = F961_8564(RTCW(loc7), loc5);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc1 = eif_boxed_item(loc2,2);
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(arg2))-1171])(arg2);
		if ((EIF_BOOLEAN)(arg4 != NULL)) {
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(arg4))-1171])(arg4);
		} else {
			loc4 = (EIF_REFERENCE) loc6;
		}
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,0xFF01,1170,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 970, _OBJSIZ_7_4_0_7_0_0_0_0_);
			}
			F961_8559(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		}
		F961_8605(RTCW(loc1), loc4, loc6);
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		
		eif_put_reference_item(RTCW(loc2),1,loc3);
		
		eif_put_reference_item(RTCW(loc2),2,loc1);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
		RTAR(tr1,loc3);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
		RTAR(tr1,loc1);
		loc2 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc2));
	}
	F961_8605(RTCW(loc7), loc2, loc5);
	RTLE;
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
