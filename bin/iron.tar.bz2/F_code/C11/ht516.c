/*
 * Code for class HTTP_CLIENT_REQUEST_FORM_PARAMETERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ht516.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HTTP_CLIENT_REQUEST_FORM_PARAMETERS}.has_file_parameter */
EIF_BOOLEAN F711_7956 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1059_8922(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F659_7888(loc1);
		if (tb2) break;
		tr1 = F659_7879(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1243, 0x01),loc2);
		tb1 = EIF_TEST(loc2);
		F659_7894(loc1);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTLE;
	return Result;
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
