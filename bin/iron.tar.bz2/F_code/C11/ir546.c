/*
 * Code for class IRON_REMOTE_NODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir546.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REMOTE_NODE}.make_with_repository */
void F1098_9282 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {IRON_REMOTE_NODE}.packages */
EIF_REFERENCE F1098_9286 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,Result);
	RTLR(6,loc3);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1429_14879(RTCW(tr1));
	loc1 = F1098_9296(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F79_1450(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10900[Dtype(RTCW(loc1))-1383])(loc1, tr1, NULL);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_8_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = RTMS_EX_H("ERROR: connection failed",24,869744228);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_6_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				Result = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F1059_8908(RTCW(Result), ((EIF_INTEGER_32) 5L));
			loc3 = RTLNS(eif_new_type(479, 0x01).id, 479, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr1 = F480_6186(RTCW(loc3), loc4, *(EIF_REFERENCE *)(Current + _REFACS_2_));
			loc5 = tr1;
			if ((EIF_TRUE)) {
				loc6 = F1059_8922(loc5);
				for (;;) {
					tb1 = F659_7888(loc6);
					if (tb1) break;
					tr1 = F659_7879(loc6);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(Result))-936])(Result, tr1);
					F659_7894(loc6);
				}
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = RTMS_EX_H("ERROR: invalid package data",27,76035169);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				RTLE;
				return (EIF_REFERENCE) NULL;
			}
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = RTMS_EX_H("ERROR: empty response body",26,752985977);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.download_package_archive */
void F1098_9287 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc8);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Current);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,arg2);
	RTLR(8,loc6);
	RTLR(9,loc5);
	RTLR(10,tr2);
	RTLR(11,loc4);
	RTLR(12,loc7);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tr1 = F1429_14879(loc8);
		loc1 = F1098_9296(Current, tr1);
		loc2 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_10_1_0_0_0_0_0_0_);
		F70_1344(RTCW(loc2));
		F1383_13409(RTCW(loc1), ((EIF_INTEGER_32) 0L));
		loc3 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(loc3), arg2);
		tb1 = F936_8227(RTCW(loc3));
		if (tb1) {
			if (arg3) {
				F936_8325(RTCW(loc3));
			} else {
				loc6 = RTLNS(eif_new_type(1075, 0x01).id, 1075, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F1076_9009(RTCW(loc6), ((EIF_INTEGER_32) 1L));
				loc5 = RTLNS(eif_new_type(1183, 0x01).id, 1183, _OBJSIZ_2_1_0_0_0_0_1_0_);
				ti4_1 = F936_8217(RTCW(loc3));
				ti8_1 = (EIF_INTEGER_64) ti4_1;
				F1184_10572(RTCW(loc5), ti8_1);
				tr1 = RTOUCR(539,F43_920, (Current));
				tr2 = F1184_10585(RTCW(loc5));
				F611_7748(RTCW(loc6), tr1, tr2);
				F70_1363(RTCW(loc2), loc6);
			}
		}
		tr1 = RTMS_EX_H("tmp-download",12,1400852068);
		loc4 = F1194_11021(RTCW(arg2), tr1);
		loc3 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(loc3), loc4);
		F936_8266(RTCW(loc3));
		F70_1372(RTCW(loc2), loc3);
		tr1 = RTMS_EX_H("",0,0);
		loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10900[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_8_0_);
		if (tb1) {
			F936_8279(RTCW(loc3));
			F936_8325(RTCW(loc3));
		} else {
			F936_8279(RTCW(loc3));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_8_1_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 304L))) {
				F936_8325(RTCW(loc3));
			} else {
				F936_8313(RTCW(loc3), arg2);
				tb1 = '\0';
				tb2 = F936_8227(RTCW(loc3));
				if (tb2) {
					tb2 = F874_8129(RTCW(loc3));
					tb1 = tb2;
				}
				if (tb1) {
					F936_8325(RTCW(loc3));
				}
			}
		}
	} else {
		loc3 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(loc3), arg2);
		tb1 = F936_8227(RTCW(loc3));
		if (tb1) {
			F936_8325(RTCW(loc3));
		}
	}
	RTLE;
}

/* {IRON_REMOTE_NODE}.publish_package */
void F1098_9290 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_REFERENCE arg8, EIF_REFERENCE arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(20);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg8);
	RTLR(4,arg9);
	RTLR(5,arg6);
	RTLR(6,loc2);
	RTLR(7,arg1);
	RTLR(8,arg2);
	RTLR(9,arg3);
	RTLR(10,arg4);
	RTLR(11,arg5);
	RTLR(12,loc5);
	RTLR(13,loc3);
	RTLR(14,loc6);
	RTLR(15,loc7);
	RTLR(16,arg7);
	RTLR(17,loc8);
	RTLR(18,loc4);
	RTLR(19,loc9);
	RTLIU(20);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1429_14879(RTCW(tr1));
	loc1 = F1098_9295(Current, tr1, arg8, arg9);
	if ((EIF_BOOLEAN)(arg6 != NULL)) {
	}
	F1383_13409(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	loc2 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_10_1_0_0_0_0_0_0_);
	F70_1345(RTCW(loc2));
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTMS_EX_H("id",2,26980);
		F70_1365(RTCW(loc2), tr1, arg1);
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = RTMS_EX_H("name",4,1851878757);
		F70_1365(RTCW(loc2), tr1, arg2);
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = RTMS_EX_H("title",5,1770128485);
		F70_1365(RTCW(loc2), tr1, arg3);
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		tr1 = RTMS_EX_H("description",11,801826414);
		F70_1365(RTCW(loc2), tr1, arg4);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		tr1 = F1098_9300(Current, arg5);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		tr1 = RTMS_EX_H("package_info",12,1500959855);
		F70_1365(RTCW(loc2), tr1, loc5);
	}
	if ((EIF_BOOLEAN)(arg6 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F79_1451(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10902[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2, NULL);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F79_1452(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg6);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10902[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2, NULL);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_8_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = RTMS_EX_H("[Error] Publish package failed!\012",32,1201724426);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc6);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTMS_EX_H("[Error] Publish package failed!",31,1254594593);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 401L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tr1 = RTMS_EX_H("[Error] Publish package not authorized!",39,2060812833);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc7);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			} else {
				tr1 = RTMS_EX_H("[Error] Publish package not authorized!",39,2060812833);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			}
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 500L))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = RTMS_EX_H("[Error] Server reported internal error!",39,281339169);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg7 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
					loc8 = tr1;
					tb1 = EIF_TEST(loc8);
				}
				if (tb1) {
					loc4 = RTLNS(eif_new_type(479, 0x01).id, 479, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tr1 = F480_6188(RTCW(loc4), loc8, *(EIF_REFERENCE *)(Current + _REFACS_2_));
					loc9 = tr1;
					if (EIF_TEST(loc9)) {
						F207_3116(RTCW(arg7), loc9);
					}
				}
			}
		}
	}
	RTLE;
}

/* {IRON_REMOTE_NODE}.add_indexes */
void F1098_9291 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,tr2);
	RTLR(8,loc4);
	RTLR(9,arg2);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1429_14879(RTCW(tr1));
	loc1 = F1098_9295(Current, tr1, arg3, arg4);
	loc2 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_10_1_0_0_0_0_0_0_);
	F70_1345(RTCW(loc2));
	tr1 = RTMS_EX_H("id",2,26980);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr2 = F1168_10067(RTCW(tr2));
	F70_1365(RTCW(loc2), tr1, tr2);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(arg2))-635])(arg2);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc4)-515])(loc4);
		if (tb1) break;
		tr1 = RTMS_EX_H("map[]",5,1635590493);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
		tr2 = F1168_10060(RTCW(tr2));
		F70_1365(RTCW(loc2), tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc4)-515])(loc4);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F79_1455(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10902[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2, NULL);
	tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_8_0_);
	if (tb2) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = RTMS_EX_H("[Error] Adding maps failed!\012",28,1463393546);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc5);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTMS_EX_H("[Error] Adding maps failed!",27,1649880609);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 401L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = RTMS_EX_H("[Error] Adding maps not authorized!",35,130451233);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {IRON_REMOTE_NODE}.upload_package_archive */
void F1098_9292 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,tr2);
	RTLR(8,loc3);
	RTLR(9,arg1);
	RTLR(10,arg5);
	RTLR(11,loc4);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1429_14879(RTCW(tr1));
	loc1 = F1098_9295(Current, tr1, arg3, arg4);
	loc2 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_10_1_0_0_0_0_0_0_);
	F70_1345(RTCW(loc2));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tr1 = F1194_11030(RTCW(tr1));
	F70_1369(RTCW(loc2), tr1);
	tr1 = RTMS_EX_H("Content-Type",12,1604261989);
	tr2 = RTMS_EX_H("application/zip",15,1736660848);
	F70_1361(RTCW(loc2), tr1, tr2);
	F1383_13409(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F79_1454(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10902[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2, NULL);
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
		F207_3116(RTCW(arg5), tr1);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_8_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTMS_EX_H("[Error] archive uploading failed!\012",34,365754122);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc4);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTMS_EX_H("[Error] archive uploading failed [",34,365753947);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
			tr2 = eif_out__i4_s1(ti4_1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
			tr2 = RTMS_EX_H("]!",2,23841);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 401L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = RTMS_EX_H("[Error] archive uploading not authorized!",41,1966750753);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 404L))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = RTMS_EX_H("[Error] package not found!",26,457990945);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	F70_1369(RTCW(loc2), NULL);
	RTLE;
}

/* {IRON_REMOTE_NODE}.delete_package */
void F1098_9293 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,arg1);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1429_14879(RTCW(tr1));
	loc1 = F1098_9295(Current, tr1, arg2, arg3);
	loc2 = RTLNS(eif_new_type(69, 0x01).id, 69, _OBJSIZ_10_1_0_0_0_0_0_0_);
	F70_1345(RTCW(loc2));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F79_1453(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R10908[Dtype(RTCW(loc1))-1383])(loc1, tr1, loc2);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_8_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTMS_EX_H("[Error] Delete package failed!\012",31,543127818);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc4);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTMS_EX_H("[Error] Delete package failed!",30,337665313);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_8_1_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 401L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr1 = RTMS_EX_H("[Error] Delete package not authorized!",38,178083105);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {IRON_REMOTE_NODE}.http_client */
static EIF_REFERENCE F1098_9294_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(540)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(353, 0x01).id, 353, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1098_9294 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(540,F1098_9294_body,(Current));
}

/* {IRON_REMOTE_NODE}.new_auth_session */
EIF_REFERENCE F1098_9295 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	Result = F1098_9296(Current, arg1);
	F1383_13415(RTCW(Result), arg2, arg3);
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.new_session */
EIF_REFERENCE F1098_9296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc1 = RTOUCR(540,F1098_9294, (Current));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4708[Dtype(RTCW(loc1))-351])(loc1, arg1);
	tr1 = F1098_9297(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = eif_boxed_item(loc2,1);
		ti4_1 = eif_integer_32_item(loc2,2);
		F1383_13422(RTCW(Result), tr1, ti4_1);
	}
	ti4_1 = F1098_9298(Current, ((EIF_INTEGER_32) 30L));
	F1383_13410(RTCW(Result), ti4_1);
	ti4_1 = F1098_9299(Current, ((EIF_INTEGER_32) 60L));
	F1383_13409(RTCW(Result), ti4_1);
	F1383_13412(RTCW(Result), (EIF_BOOLEAN) 1);
	tr1 = RTMS_EX_H("Accept",6,1796147828);
	tr2 = RTMS_EX_H("application/json",16,1936556398);
	F1383_13413(RTCW(Result), tr1, tr2);
	tr1 = RTOUCR(217,F78_1442, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1383_13413(RTCW(Result), tr1, tr2);
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.proxy_information */
EIF_REFERENCE F1098_9297 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,loc4);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTOUCR(218,F78_1443, (Current));
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb1 = '\01';
		tb2 = F878_8129(loc5);
		if (!tb2) {
			tb2 = F1171_10169(loc5);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
		} else {
			tb1 = F1168_10038(loc5);
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,65534,1312,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 3, 0);
				}
				ti4_1 = F1168_10072(loc5);
				((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
				Result = (EIF_REFERENCE) tr1;
			} else {
				loc4 = F1168_10060(loc5);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O8704[Dtype(loc4)-1173]);
				loc2 = F1174_10318(RTCW(loc4), (EIF_CHARACTER_8) ':', ti4_1);
				if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
					loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc4))-1171])(loc4, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O8704[Dtype(loc4)-1173]);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc4))-1171])(loc4, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
					loc4 = (EIF_REFERENCE) tr1;
					tb1 = F1168_10038(RTCW(loc4));
					if (tb1) {
						loc1 = F1168_10072(RTCW(loc4));
					}
				} else {
					loc3 = (EIF_REFERENCE) loc4;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
				}
				if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1173,1312,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
					RTAR(tr1,loc3);
					((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc1;
					Result = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.connect_timeout */
EIF_INTEGER_32 F1098_9298 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTOUCR(219,F78_1444, (Current));
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F878_8129(loc1);
		if (tb1) {
		} else {
			tb1 = F1168_10038(loc1);
			if (tb1) {
				Result = F1168_10072(loc1);
				RTLE;
				return (EIF_INTEGER_32) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.timeout */
EIF_INTEGER_32 F1098_9299 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTOUCR(220,F78_1445, (Current));
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F878_8129(loc1);
		if (tb1) {
		} else {
			tb1 = F1168_10038(loc1);
			if (tb1) {
				Result = F1168_10072(loc1);
				RTLE;
				return (EIF_INTEGER_32) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_REMOTE_NODE}.file_content */
EIF_REFERENCE F1098_9300 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F936_8193(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F936_8227(RTCW(loc1));
	if (tb2) {
		tb2 = F936_8246(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = F936_8222(RTCW(loc1));
		F1174_10304(RTCW(Result), ti4_1);
		F936_8262(RTCW(loc1));
		for (;;) {
			if (loc2) break;
			F936_8343(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			loc2 = '\01';
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8704[Dtype(tr1)-1173]);
			if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 1024L))) {
				tb2 = F742_7994(RTCW(loc1));
				tb1 = tb2;
			}
			if (!tb1) {
				tb1 = F936_8226(RTCW(loc1));
				loc2 = tb1;
			}
		}
		F936_8279(RTCW(loc1));
	}
	RTLE;
	return Result;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
