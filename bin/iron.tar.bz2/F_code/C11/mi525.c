/*
 * Code for class MISMATCH_INFORMATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi525.h"
#include "../C18/ha871.h"
#include "../C11/mi525.h"
#include <eif_retrieve.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_INFORMATION}.default_create */
void F970_8670 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F961_8558(Current, ((EIF_INTEGER_32) 5L));
	RTOUCP(243,F970_8680, (Current));
	RTLE;
}

/* {MISMATCH_INFORMATION}.class_name */
EIF_REFERENCE F970_8671 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached {STRING_8} item (type_name_key) as r", EX_CHECK);
	tr1 = RTOUCR(244,F970_8674, (Current));
	tr1 = F961_8564(Current, tr1);
	loc1 = RTCCL(tr1);
	loc1 = RTRV(eif_new_type(1175, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {MISMATCH_INFORMATION}.type_name_key */

EIF_REFERENCE F970_8674 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (244,RTMS_EX_H("_type_name",10,803527013));
}

/* {MISMATCH_INFORMATION}.out */
EIF_REFERENCE F970_8677 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F970_8671(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8704[Dtype(tr1)-1173]);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_);
	F1174_10304(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + ti4_1) + (EIF_INTEGER_32) (((EIF_INTEGER_32) 40L) * ti4_2)));
	tr1 = RTMS_EX_H("Attributes of original class ",29,488257824);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	tr1 = F970_8671(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	tr1 = RTMS_EX_H(": ",2,14880);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	F1176_10420(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)));
	tr1 = RTMS_EX_H(" item",5,1769481581);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)) != ((EIF_INTEGER_32) 1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) 's');
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\012');
	F961_8597(Current);
	for (;;) {
		if (F961_8592(Current)) break;
		loc2 = F961_8571(Current);
		if (!RTEQ(loc2, RTOUCR(244,F970_8674, (Current)))) {
			tr1 = RTMS_EX_H("  ",2,8224);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				tr1 = RTMS_EX_H("Void",4,1450142052);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, loc2);
			}
			tr1 = RTMS_EX_H(": ",2,14880);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			loc1 = F961_8570(Current);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = RTMS_EX_H("Void",4,1450142052);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(loc1))-1])(loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\012');
		}
		F961_8598(Current);
	}
	RTLE;
	return Result;
}

/* {MISMATCH_INFORMATION}.internal_put */
void F970_8678 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTCCL(arg1);
	tr2 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10307(RTCW(tr2), arg2);
	F961_8604(Current, tr1, tr2);
	RTLE;
}

/* {MISMATCH_INFORMATION}.set_string_versions */
void F970_8679 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg1 == tp1)) {
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	} else {
		loc1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1174_10307(RTCW(loc1), arg1);
		tb1 = F1175_10373(RTCW(loc1));
		if (tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
		} else {
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
		}
	}
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg2 == tp1)) {
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	} else {
		loc1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1174_10307(RTCW(loc1), arg2);
		tb1 = F1175_10373(RTCW(loc1));
		if (tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
		} else {
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
		}
	}
	RTLE;
}

/* {MISMATCH_INFORMATION}.set_callback_pointers */
static void F970_8680_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	RTOUDV(243)

	
	RTEV;
	RTOTP;
	F970_8681(Current, Current, (EIF_POINTER) F961_8612, (EIF_POINTER) F970_8678, (EIF_POINTER) F970_8679);
	RTOTE;
	RTEE;
#undef Result
}

void F970_8680 (EIF_REFERENCE Current)
{
	GTCX
	RTOUCP(243,F970_8680_body,(Current));
}

/* {MISMATCH_INFORMATION}.set_mismatch_information_access */
void F970_8681 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_POINTER larg3 = arg3;
		EIF_POINTER larg4 = arg4;set_mismatch_information_access((EIF_OBJECT) larg1, (EIF_PROCEDURE) larg2, (EIF_PROCEDURE) larg3, (EIF_PROCEDURE) larg4);
		
	}
	RTLE;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
