
#ifndef _C11_kl533_
#define _C11_kl533_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F1080_9077(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1080_9081(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit533(void);

#ifdef __cplusplus
}
#endif

#endif
