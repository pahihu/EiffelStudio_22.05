/*
 * Code for class IRON_FS_CATALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir547.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_FS_CATALOG}.make */
void F1099_9301 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tr1 = RTLNSMART(eif_new_type(1110, 1).id);
	F1109_9534(RTCW(tr1), arg1, arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(120,F1103_9357, (RTCW(arg1)));
	F1099_9303(Current, tr1);
	tr1 = RTOUCR(121,F1103_9358, (RTCW(arg1)));
	F1099_9303(Current, tr1);
	tr1 = RTOUCR(119,F1103_9359, (RTCW(arg1)));
	F1099_9303(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr1 = F68_1318(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1099_9302(Current);
	RTLE;
}

/* {IRON_FS_CATALOG}.load_repositories */
void F1099_9302 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc1)-515])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		F1099_9317(Current, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc1)-515])(loc1);
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.ensure_folder_exists */
void F1099_9303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F562_6842(RTCW(loc1), arg1);
	tb1 = F562_6865(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		F562_6845(RTCW(loc1));
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.layout */
EIF_REFERENCE F1099_9304 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {IRON_FS_CATALOG}.repositories */
EIF_REFERENCE F1099_9307 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {IRON_FS_CATALOG}.register_repository */
void F1099_9308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	F68_1323(RTCW(tr1), arg1);
	F1099_9317(Current, arg1);
	RTLE;
}

/* {IRON_FS_CATALOG}.unregister_repository */
void F1099_9309 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	F68_1324(RTCW(tr1), arg1);
	tr1 = F200_2988(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1103_9360(RTCW(tr2), loc1);
		F1103_9371(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1103_9364(RTCW(tr2), loc1);
		F1103_9371(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1111_9574(RTCW(tr1));
	RTLE;
}

/* {IRON_FS_CATALOG}.repository */
EIF_REFERENCE F1099_9310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc1)-515])(loc1);
		if (tb1) break;
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		tb2 = F713_7967(RTCW(tr1), arg1);
		if (tb2) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc1)-515])(loc1);
	}
	RTLE;
	return Result;
}

/* {IRON_FS_CATALOG}.is_package_installed */
EIF_BOOLEAN F1099_9311 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1111_9583(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {IRON_FS_CATALOG}.installed_packages */
EIF_REFERENCE F1099_9312 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1111_9569(RTCW(tr1));
	RTLE;
	return Result;
}

/* {IRON_FS_CATALOG}.available_path_associated_with_uri */
EIF_REFERENCE F1099_9314 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc5);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,Result);
	RTLIU(11);
	
	RTGC;
	loc2 = F1429_14879(RTCW(arg1));
	loc3 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(loc3));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc5)-515])(loc5);
		if (tb1) break;
		if ((EIF_BOOLEAN)(loc1 != NULL)) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
		tr1 = F713_7961(RTCW(tr1));
		tb2 = F1174_10340(RTCW(loc2), tr1);
		if (tb2) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc5)-515])(loc5);
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F713_7961(RTCW(loc1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8704[Dtype(tr1)-1173]);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc2))-1171])(loc2, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
		loc2 = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
		for (;;) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc6)-515])(loc6);
			if (tb2) break;
			if ((EIF_BOOLEAN)(loc4 != NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
			loc7 = F1059_8922(RTCW(tr1));
			for (;;) {
				tb3 = F659_7888(loc7);
				if (tb3) break;
				if ((EIF_BOOLEAN)(loc4 != NULL)) break;
				tr1 = F659_7879(loc7);
				tb4 = F1174_10340(RTCW(loc2), tr1);
				if (tb4) {
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(loc3))-1172])(loc3);
					tr1 = F659_7879(loc7);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8704[Dtype(tr1)-1173]);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc2))-1171])(loc2, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc3))-1175])(loc3, tr1);
				}
				F659_7894(loc7);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc6)-515])(loc6);
		}
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			Result = F1103_9368(RTCW(tr1), loc4);
			tb4 = '\0';
			if ((EIF_BOOLEAN)(Result != NULL)) {
				tr1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
				F562_6842(RTCW(tr1), Result);
				tb5 = F562_6865(RTCW(tr1));
				tb4 = tb5;
			}
			if (tb4) {
				tr1 = F1194_11018(RTCW(Result), loc3);
				RTLE;
				return (EIF_REFERENCE) tr1;
			} else {
				RTLE;
				return (EIF_REFERENCE) NULL;
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_FS_CATALOG}.update */
void F1099_9315 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc1)-515])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		F1099_9316(Current, tr1, (EIF_BOOLEAN) 0);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc1)-515])(loc1);
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.update_repository */
void F1099_9316 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLR(4,loc7);
	RTLR(5,loc1);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc2);
	RTLR(11,tr3);
	RTLR(12,loc4);
	RTLR(13,loc12);
	RTLR(14,loc5);
	RTLR(15,loc3);
	RTLIU(16);
	
	RTGC;
	if ((EIF_BOOLEAN) !arg2) {
		tr1 = RTMS_EX_H("Updating repository ",20,287200544);
		tr2 = F713_7961(RTCW(arg1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
		tr2 = RTMS_EX_H(" ...\012",5,775024138);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
		F1_27(Current, tr1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7030[Dtype(RTCW(arg1))-1190])(arg1);
	loc7 = arg1;
	loc7 = RTRV(eif_new_type(1194, 0x01),loc7);
	if (EIF_TEST(loc7)) {
		loc1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_4_1_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOUCR(267,F200_2982, (Current));
		F1098_9282(RTCW(loc1), tr1, tr2, loc7);
		tr1 = F1098_9286(RTCW(loc1));
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			loc6 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_4_0_);
			if (loc6) {
				loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc8)-635])(loc8);
				for (;;) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc9)-515])(loc9);
					if (tb1) break;
					if ((EIF_BOOLEAN) !arg2) {
						tr1 = RTMS_EX_H("- ",2,11552);
						F1_27(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc9)-515])(loc9);
						tr1 = F1193_10958(RTCW(tr1));
						F1_27(Current, tr1);
						tr1 = RTMS_EX_H("\012",1,10);
						F1_27(Current, tr1);
					}
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc9)-515])(loc9);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7031[Dtype(RTCW(arg1))-1190])(arg1, tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc9)-515])(loc9);
				}
			} else {
				if ((EIF_BOOLEAN) !arg2) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
					loc10 = tr1;
					if (EIF_TEST(loc10)) {
						tr1 = RTMS_EX_H("ERROR: ",7,1861797408);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc10);
						tr2 = RTMS_EX_H("\012",1,10);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
						F1_27(Current, tr1);
					} else {
						tr1 = RTMS_EX_H("ERROR: unable to get packages information!\012",43,1607138826);
						F1_27(Current, tr1);
					}
				}
			}
		}
	} else {
		loc11 = arg1;
		loc11 = RTRV(eif_new_type(1190, 0x01),loc11);
		if (EIF_TEST(loc11)) {
			tb2 = F1191_10793(loc11);
			if (tb2) {
				loc2 = RTLNS(eif_new_type(185, 0x01).id, 185, _OBJSIZ_3_1_0_2_0_0_0_0_);
				F186_2852(RTCW(loc2));
				tr1 = RTMS_EX_H("package.iron",12,1500847982);
				F186_2855(RTCW(loc2), tr1);
				{
					static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1175,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 3L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("EIFGENs",7,1708946035);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H(".svn",4,779318894);
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H(".git",4,778529140);
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
				F186_2860(RTCW(loc2), tr1);
				F186_2854(RTCW(loc2), (EIF_BOOLEAN) 1);
				tr1 = *(EIF_REFERENCE *)(loc11 + _REFACS_1_);
				F186_2861(RTCW(loc2), tr1);
				loc4 = RTLNS(eif_new_type(73, 0x01).id, 73, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
				for (;;) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc12)-515])(loc12);
					if (tb2) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc12)-515])(loc12);
					loc5 = F74_1420(RTCW(loc4), tr1);
					loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R3790[Dtype(RTCW(loc5))-288])(loc5, loc11);
					if ((EIF_BOOLEAN) !arg2) {
						tr1 = RTMS_EX_H("- ",2,11552);
						F1_27(Current, tr1);
						tr1 = F1193_10958(RTCW(loc3));
						F1_27(Current, tr1);
						tr1 = RTMS_EX_H("\012",1,10);
						F1_27(Current, tr1);
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3795[Dtype(RTCW(loc5))-288])(loc5);
						if ((EIF_BOOLEAN) !tb3) {
							tr1 = RTMS_EX_H("!Warning: expected file name is \"",33,954620962);
							F1_27(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3796[Dtype(RTCW(loc5))-288])(loc5);
							F1_27(Current, tr1);
							tr1 = RTMS_EX_H("\" instead of \"",14,1406818594);
							F1_27(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc12)-515])(loc12);
							F1_27(Current, tr1);
							tr1 = RTMS_EX_H("\"\012",2,8714);
							F1_27(Current, tr1);
						}
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7031[Dtype(RTCW(arg1))-1190])(arg1, loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc12)-515])(loc12);
				}
			} else {
				if ((EIF_BOOLEAN) !arg2) {
					tr1 = RTMS_EX_H("ERROR: Repository \"",19,1227460642);
					tr2 = F713_7961(loc11);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("\" does not exist!\012",18,1096950026);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					F1_27(Current, tr1);
				}
			}
		} else {
			tr1 = RTMS_EX_H("Local repository update is not yet implemented\012",47,1308228106);
			F1_27(Current, tr1);
		}
	}
	F1099_9318(Current, arg1);
	RTLE;
}

/* {IRON_FS_CATALOG}.fill_repository */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1099_9317 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTLD;
	RTXD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,saved_except);
	RTLIU(7);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc2 = F1103_9361(RTCW(tr1), arg1);
		tr1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(tr1), loc2);
		loc1 = (EIF_REFERENCE) tr1;
		tb1 = '\0';
		tb2 = F936_8227(RTCW(loc1));
		if (tb2) {
			tb2 = F936_8246(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			F936_8262(RTCW(loc1));
			tr1 = F936_8219(RTCW(loc1));
			loc4 = RTCCL(tr1);
			loc4 = RTRV(eif_new_type(712, 0x01),loc4);
			if (EIF_TEST(loc4)) {
				tr1 = *(EIF_REFERENCE *)(loc4);
				F713_7971(RTCW(arg1), tr1);
			}
			F936_8279(RTCW(loc1));
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7030[Dtype(RTCW(arg1))-1190])(arg1);
	}
	RTE_E
	RTXSC;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {IRON_FS_CATALOG}.save_updated_repository */
void F1099_9318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	F68_1325(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1103_9361(RTCW(tr1), arg1);
	tr1 = F1194_11006(RTCW(loc2));
	F1099_9303(Current, tr1);
	loc1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F936_8193(RTCW(loc1), loc2);
	F936_8266(RTCW(loc1));
	F936_8323(RTCW(loc1), arg1);
	F936_8279(RTCW(loc1));
	RTLE;
}

/* {IRON_FS_CATALOG}.download_package */
void F1099_9320 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1103_9365(RTCW(tr1), arg2);
	tr1 = F1194_11006(RTCW(loc2));
	F1099_9303(Current, tr1);
	tb1 = F1193_10949(RTCW(arg2));
	if (tb1) {
		loc3 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_4_1_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOUCR(267,F200_2982, (Current));
		F1098_9282(RTCW(loc3), tr1, tr2, arg1);
		F1098_9287(RTCW(loc3), arg2, loc2, arg3);
		loc1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F936_8193(RTCW(loc1), loc2);
		tb1 = F936_8227(RTCW(loc1));
		if (tb1) {
			tr1 = F1194_11010(RTCW(loc2));
			tr1 = F1194_11012(RTCW(tr1));
			F1193_10985(RTCW(arg2), tr1);
		}
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.install_package */
void F1099_9321 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1194, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1099_9323(Current, loc1, arg2, arg3);
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1190, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1099_9322(Current, loc2, arg2);
		} else {
		}
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.install_fs_package */
void F1099_9322 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1103_9366(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1103_9368(RTCW(tr1), arg2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F562_6842(RTCW(loc3), loc4);
		tb1 = F562_6865(RTCW(loc3));
		if (tb1) {
			loc1 = RTLNS(eif_new_type(52, 0x01).id, 52, _OBJSIZ_4_0_0_0_0_0_0_0_);
			F53_1090(RTCW(loc1), arg2, loc2, loc4);
			F53_1098(RTCW(loc1));
			F1099_9325(Current, arg2);
		}
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.install_web_package */
void F1099_9323 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc5);
	RTLR(1,arg2);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc1);
	RTLR(9,loc8);
	RTLR(10,loc4);
	RTLR(11,tr2);
	RTLR(12,loc10);
	RTLR(13,arg1);
	RTLIU(14);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_7_);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		tb1 = F1193_10948(RTCW(arg2));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc3 = F1103_9370(RTCW(tr1), arg2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc2 = F1103_9366(RTCW(tr1), arg2);
			loc6 = RTLNS(eif_new_type(1096, 0x01).id, 1096, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr1 = F1194_11006(RTCW(loc3));
			F1099_9303(Current, tr1);
			loc7 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
			F936_8193(RTCW(loc7), loc3);
			tb1 = F936_8227(RTCW(loc7));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc1 = F1103_9368(RTCW(tr1), arg2);
			}
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc1 = F1103_9369(RTCW(tr1), arg2);
				loc8 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
				F562_6842(RTCW(loc8), loc1);
				tb1 = F562_6865(RTCW(loc8));
				if (tb1) {
					tr1 = RTMS_EX_H("-",1,45);
					tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					loc4 = F1194_11020(RTCW(loc1), tr1);
					F562_6842(RTCW(loc8), loc4);
					tb1 = F562_6865(RTCW(loc8));
					if (tb1) {
						loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc4 = (EIF_REFERENCE) loc1;
						for (;;) {
							tb1 = F562_6865(RTCW(loc8));
							if ((EIF_BOOLEAN) !tb1) break;
							loc9++;
							tr1 = RTMS_EX_H("-",1,45);
							tr2 = eif_out__i4_s1(loc9);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
							loc4 = F1194_11020(RTCW(loc1), tr1);
							F562_6842(RTCW(loc8), loc4);
						}
					}
					loc1 = (EIF_REFERENCE) loc4;
					loc7 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
					F936_8193(RTCW(loc7), loc3);
					F936_8266(RTCW(loc7));
					tr1 = F1194_11029(RTCW(loc1));
					F936_8301(RTCW(loc7), tr1);
					F936_8279(RTCW(loc7));
				}
			}
			F1097_9275(RTCW(loc6), arg2, loc1, (EIF_BOOLEAN) 1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
			loc8 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F562_6842(RTCW(loc8), loc1);
			tb2 = F562_6865(RTCW(loc8));
			if (tb2) {
				tb2 = F562_6864(RTCW(loc8));
				if ((EIF_BOOLEAN) !tb2) {
					loc10 = RTLNS(eif_new_type(52, 0x01).id, 52, _OBJSIZ_4_0_0_0_0_0_0_0_);
					F53_1090(RTCW(loc10), arg2, loc2, loc1);
					F53_1098(RTCW(loc10));
					F1099_9325(Current, arg2);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr2 = F562_6846(RTCW(loc8));
					F1103_9371(RTCW(tr1), tr2);
				}
			}
		} else {
			F1099_9320(Current, arg1, arg2, arg3);
			tb2 = F1193_10948(RTCW(arg2));
			if (tb2) {
				F1099_9321(Current, arg1, arg2, arg3);
			}
		}
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.uninstall_package */
void F1099_9324 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F1103_9366(RTCW(tr2), arg1);
	F1103_9372(RTCW(tr1), tr2);
	tb1 = F1193_10947(RTCW(arg1));
	if (tb1) {
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1103_9368(RTCW(tr2), arg1);
		F1103_9371(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1103_9370(RTCW(tr2), arg1);
		F1103_9372(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1103_9365(RTCW(tr2), arg1);
		F1103_9372(RTCW(tr1), tr2);
	}
	tr1 = F1099_9312(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7066[Dtype(RTCW(tr1))-1053])(tr1, arg1);
	RTLE;
}

/* {IRON_FS_CATALOG}.on_package_just_installed */
void F1099_9325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1099_9312(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(tr1))-936])(tr1, arg1);
	RTLE;
}

/* {IRON_FS_CATALOG}.setup_package_installation */
void F1099_9326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	struct eif_ex_70 sloc4;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) sloc4.data;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	memset (&sloc4.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc4.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc4.overhead, eif_new_type(76, 0x00).id);
	RTLI(20);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLR(8,loc9);
	RTLR(9,loc5);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,loc10);
	RTLR(13,loc6);
	RTLR(14,tr4);
	RTLR(15,tr5);
	RTLR(16,tr6);
	RTLR(17,loc11);
	RTLR(18,loc12);
	RTLR(19,arg2);
	RTLIU(20);
	
	RTGC;
	loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = RTLNS(eif_new_type(73, 0x01).id, 73, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1103_9368(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = RTMS_EX_H("package.iron",12,1500847982);
		loc3 = F1194_11018(RTCW(loc2), tr1);
		tb1 = '\0';
		tb2 = F77_1439(RTCW(loc4), loc3);
		if (tb2) {
			tr1 = F74_1420(RTCW(loc1), loc3);
			loc8 = tr1;
			tb1 = (EIF_TRUE);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_2_);
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,1167,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc5 = RTLNS(typres0.id, 970, _OBJSIZ_7_4_0_7_0_0_0_0_);
				}
				F961_8558(RTCW(loc5), ((EIF_INTEGER_32) 3L));
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = RTMS_EX_H("IRON_PATH",9,490076488);
				tr1 = F455_6049(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H("IRON_PATH",9,490076488);
				F961_8605(RTCW(loc5), tr1, tr2);
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = RTMS_EX_H("IRON_PACKAGE_PATH",17,1539500104);
				tr1 = F455_6049(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H("IRON_PACKAGE_PATH",17,1539500104);
				F961_8605(RTCW(loc5), tr1, tr2);
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = RTMS_EX_H("IRON_PACKAGE_NAME",17,1505943877);
				tr1 = F455_6049(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H("IRON_PACKAGE_NAME",17,1505943877);
				F961_8605(RTCW(loc5), tr1, tr2);
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
				tr2 = F1194_11030(RTCW(tr2));
				tr3 = RTMS_EX_H("IRON_PATH",9,490076488);
				F455_6062(RTCW(tr1), tr2, tr3);
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = F1194_11030(RTCW(loc2));
				tr3 = RTMS_EX_H("IRON_PACKAGE_PATH",17,1539500104);
				F455_6062(RTCW(tr1), tr2, tr3);
				tr1 = RTOUCR(33,F1095_9251, (Current));
				tr2 = F1193_10956(RTCW(arg1));
				tr3 = RTMS_EX_H("IRON_PACKAGE_NAME",17,1505943877);
				F455_6062(RTCW(tr1), tr2, tr3);
				loc10 = F1059_8922(loc9);
				for (;;) {
					tb1 = F659_7888(loc10);
					if (tb1) break;
					tr1 = F659_7879(loc10);
					tr1 = eif_boxed_item(tr1,1);
					tr2 = RTMS_EX_H("compile_library",15,520152953);
					tb2 = F1168_10049(RTCW(tr1), tr2);
					if (tb2) {
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,207,1312,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc6 = RTLNS(typres0.id, 207, _OBJSIZ_0_0_0_1_0_0_0_0_);
						}
						F208_3115(RTCW(loc6), ((EIF_INTEGER_32) 0L));
						if (arg3) {
							tr1 = F1099_9327(Current);
							tr2 = F659_7879(loc10);
							tr2 = eif_boxed_item(tr2,2);
							tr2 = F1194_11018(RTCW(loc2), tr2);
							{
								EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
								EIF_TYPE typres0;
								typarr0[4] = dftype;
								
								typres0 = eif_compound_id(dftype, typarr0);
								tr3 = RTLNTS(typres0.id, 2, 0);
							}
							((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
							RTAR(tr3,Current);
							
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,1,1113,0xFF01,1175,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr6= RTLNRF(typres0.id, (EIF_POINTER) __A547_71_2, (EIF_POINTER) _A547_71_2, (EIF_POINTER)(0),tr3, 1, 1);
							}
							F1099_9328(Current, tr1, tr2, tr6, loc6);
						} else {
							tr1 = F1099_9327(Current);
							tr2 = F659_7879(loc10);
							tr2 = eif_boxed_item(tr2,2);
							tr2 = F1194_11018(RTCW(loc2), tr2);
							{
								EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
								EIF_TYPE typres0;
								typarr0[4] = dftype;
								
								typres0 = eif_compound_id(dftype, typarr0);
								tr3 = RTLNTS(typres0.id, 2, 0);
							}
							((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
							RTAR(tr3,Current);
							
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,1,1113,0xFF01,1175,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr6= RTLNRF(typres0.id, (EIF_POINTER) __A547_72_2, (EIF_POINTER) _A547_72_2, (EIF_POINTER)(0),tr3, 1, 1);
							}
							F1099_9328(Current, tr1, tr2, tr6, loc6);
						}
						tb2 = '\0';
						if (loc7) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O3052[Dtype(loc6)-206]);
							tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						loc7 = (EIF_BOOLEAN) tb2;
					} else {
						if ((EIF_BOOLEAN) !arg3) {
							tr1 = RTMS_EX_H(" ##setup \"",10,1995020066);
							F1_27(Current, tr1);
							tr1 = F659_7879(loc10);
							F1_27(Current, tr1);
							tr1 = RTMS_EX_H("\" ignored.##",12,310531363);
							F1_27(Current, tr1);
						}
					}
					F659_7894(loc10);
				}
				loc11 = F961_8573(RTCW(loc5));
				for (;;) {
					tb2 = F650_7876(loc11);
					if (tb2) break;
					tr1 = F650_7873(loc11);
					loc12 = tr1;
					if (EIF_TEST(loc12)) {
						tr1 = RTOUCR(33,F1095_9251, (Current));
						tr2 = F650_7874(loc11);
						F455_6062(RTCW(tr1), loc12, tr2);
					} else {
						tr1 = RTOUCR(33,F1095_9251, (Current));
						tr2 = RTMS_EX_H("",0,0);
						tr3 = F650_7874(loc11);
						F455_6062(RTCW(tr1), tr2, tr3);
					}
					F650_7877(loc11);
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		F209_3116(RTCW(arg2), loc7);
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.finish_freezing_command_name */
EIF_REFERENCE F1099_9327 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = RTOUCR(33,F1095_9251, (Current));
	tr2 = RTMS_EX_H("ISE_EIFFEL",10,960687436);
	tr1 = F455_6049(RTCW(tr1), tr2);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = RTOUCR(33,F1095_9251, (Current));
		tr2 = RTMS_EX_H("ISE_PLATFORM",12,1318550605);
		tr1 = F455_6049(RTCW(tr1), tr2);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1194_10991(RTCW(loc1), loc2);
			tr1 = RTMS_EX_H("studio",6,49025135);
			tr1 = F1194_11018(RTCW(loc1), tr1);
			tr2 = RTMS_EX_H("spec",4,1936745827);
			tr1 = F1194_11018(RTCW(tr1), tr2);
			tr1 = F1194_11018(RTCW(tr1), loc3);
			tr2 = RTMS_EX_H("bin",3,6449518);
			tr1 = F1194_11018(RTCW(tr1), tr2);
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = RTMS_EX_H("finish_freezing.exe",19,244396133);
			tr1 = F1194_11018(RTCW(loc1), tr1);
			tr1 = F1194_11030(RTCW(tr1));
			tr2 = RTMS32_EX_H(" \000\000\000-\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",9,400209785);
			tr1 = F1172_10200(RTCW(tr1), tr2);
			Result = F1168_10066(RTCW(tr1));
		} else {
			tr1 = RTMS_EX_H("finish_freezing",15,427748711);
			tr1 = F1194_11018(RTCW(loc1), tr1);
			tr1 = F1194_11030(RTCW(tr1));
			tr2 = RTMS32_EX_H(" \000\000\000-\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",9,400209785);
			tr1 = F1172_10200(RTCW(tr1), tr2);
			Result = F1168_10066(RTCW(tr1));
		}
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			Result = RTMS32_EX_H("f\000\000\000i\000\000\000n\000\000\000i\000\000\000s\000\000\000h\000\000\000_\000\000\000f\000\000\000r\000\000\000e\000\000\000e\000\000\000z\000\000\000i\000\000\000n\000\000\000g\000\000\000.\000\000\000b\000\000\000a\000\000\000t\000\000\000 \000\000\000-\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",28,60498297);
		} else {
			Result = RTMS32_EX_H("f\000\000\000i\000\000\000n\000\000\000i\000\000\000s\000\000\000h\000\000\000_\000\000\000f\000\000\000r\000\000\000e\000\000\000e\000\000\000z\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000-\000\000\000l\000\000\000i\000\000\000b\000\000\000r\000\000\000a\000\000\000r\000\000\000y\000\000\000",24,938760569);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_FS_CATALOG}.execute_command_line */
void F1099_9328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,loc3);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(174, 0x01).id, 174, _OBJSIZ_0_0_0_0_0_0_0_0_);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc3 = F1194_11030(RTCW(arg2));
	}
	loc2 = F175_2752(RTCW(loc1), arg1, loc3);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		F1107_9490(RTCW(loc2), arg3);
		F1107_9494(RTCW(loc2));
	} else {
		F1107_9491(RTCW(loc2));
	}
	F1108_9511(RTCW(loc2));
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_21_6_);
	if (tb1) {
		F1108_9512(RTCW(loc2));
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_21_6_);
		if (tb1) {
			ti4_1 = F1106_9481(RTCW(loc2));
			F208_3116(RTCW(arg4), ti4_1);
		} else {
			F208_3116(RTCW(arg4), ((EIF_INTEGER_32) -1L));
		}
	}
	RTLE;
}

/* {IRON_FS_CATALOG}.inline-agent#1 of setup_package_installation */
void F1099_15542 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {IRON_FS_CATALOG}.inline-agent#2 of setup_package_installation */
void F1099_15543 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1_27(Current, arg1);
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
