/*
 * Code for class RAW_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra523.h"
#include "eif_file.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RAW_FILE}.read_integer */
void F938_8505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_6_2_4_1_0_);
	ti4_1 = (EIF_INTEGER_32) eif_file_gib((FILE*) tp1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_2_1_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {RAW_FILE}.read_natural_8 */
void F938_8511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F938_8526(Current);
	F938_8523(Current, tr1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	tr1 = F938_8526(Current);
	tu1_1 = F547_6563(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_4_4_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {RAW_FILE}.read_to_managed_pointer */
void F938_8523 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = RTPOF(tp1,arg2);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_4_6_2_4_1_0_);
	ti4_1 = (EIF_INTEGER_32) fread((void*) tp1, (size_t) ((EIF_INTEGER_32) 1L), (size_t) arg3, (FILE*) tp2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_2_2_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {RAW_FILE}.file_fread */
EIF_INTEGER_32 F938_8525 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) fread((void*) arg1, (size_t) arg2, (size_t) arg3, (FILE*) arg4);
	
	return Result;
}

/* {RAW_FILE}.integer_buffer */
EIF_REFERENCE F938_8526 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = RTLNS(eif_new_type(546, 0x01).id, 546, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F547_6552(RTCW(Result), ((EIF_INTEGER_32) 16L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {RAW_FILE}.file_gib */
EIF_INTEGER_32 F938_8528 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gib((FILE*) arg1);
	
	return Result;
}

/* {RAW_FILE}.file_open */
EIF_POINTER F938_8531 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_binary_open((EIF_FILENAME) arg1, (int) arg2);
	
	return Result;
}

/* {RAW_FILE}.file_dopen */
EIF_POINTER F938_8532 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_binary_dopen((int) arg1, (int) arg2);
	
	return Result;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
