/*
 * Code for class NET_HTTP_CLIENT_REQUEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ne544.h"
#include "eif_built_in.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NET_HTTP_CLIENT_REQUEST}.net_http_client_version */

EIF_REFERENCE F1096_9253 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (613,RTMS_EX_H("0.1",3,3157553));
}

/* {NET_HTTP_CLIENT_REQUEST}.session_socket */
EIF_REFERENCE F1096_9254 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_11_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb2 = F41_848(loc2, arg1, arg2);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(loc2);
		if (arg3) {
			loc3 = loc1;
			loc3 = RTRV(eif_new_type(569, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				Result = (EIF_REFERENCE) loc3;
			} else {
				loc1 = (EIF_REFERENCE) NULL;
			}
		} else {
			loc4 = loc1;
			loc4 = RTRV(eif_new_type(569, 0x01),loc4);
			if (EIF_TEST(loc4)) {
				loc1 = (EIF_REFERENCE) NULL;
			}
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_7_7_);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc1 = (EIF_REFERENCE) NULL;
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		F1385_13447(RTCW(tr1), NULL);
		if (arg3) {
			Result = RTLNS(eif_new_type(569, 0x01).id, 569, _OBJSIZ_7_12_2_14_1_0_3_1_);
			F568_7284(RTCW(Result), arg2, arg1);
		} else {
			Result = RTLNS(eif_new_type(568, 0x01).id, 568, _OBJSIZ_7_12_2_14_1_0_3_1_);
			F568_7284(RTCW(Result), arg2, arg1);
		}
		ti4_1 = F448_5978(Current);
		F568_7292(RTCW(Result), ti4_1);
		ti4_1 = F448_5977(Current);
		tu8_1 = F117_2059(RTCW(Result), ti4_1);
		F567_7258(RTCW(Result), tu8_1);
		F567_7233(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {NET_HTTP_CLIENT_REQUEST}.response */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F1096_9255 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc10 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc13 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc14 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc24 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc25 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc26 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc27 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc28 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc41 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc42 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc43 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(41);
	RTLR(0,loc18);
	RTLR(1,Current);
	RTLR(2,loc29);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc30);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,loc31);
	RTLR(11,loc8);
	RTLR(12,loc22);
	RTLR(13,loc32);
	RTLR(14,loc33);
	RTLR(15,loc15);
	RTLR(16,loc34);
	RTLR(17,loc6);
	RTLR(18,loc35);
	RTLR(19,loc16);
	RTLR(20,tr3);
	RTLR(21,loc36);
	RTLR(22,loc21);
	RTLR(23,loc17);
	RTLR(24,loc20);
	RTLR(25,loc37);
	RTLR(26,loc19);
	RTLR(27,loc24);
	RTLR(28,loc9);
	RTLR(29,loc38);
	RTLR(30,loc5);
	RTLR(31,loc39);
	RTLR(32,loc3);
	RTLR(33,loc10);
	RTLR(34,loc23);
	RTLR(35,loc40);
	RTLR(36,loc12);
	RTLR(37,loc41);
	RTLR(38,loc42);
	RTLR(39,loc1);
	RTLR(40,saved_except);
	RTLIU(41);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc28) {
		loc18 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc18 != NULL)) {
			loc25 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc18) + _REFACS_9_);
			loc29 = tr1;
			if (EIF_TEST(loc29)) {
				tr1 = RTMS_EX_H("HTTP/1.0",8,303094320);
				tb1 = F1174_10332(loc29, tr1);
				loc25 = tb1;
			}
		}
		tr1 = RTLNS(eif_new_type(70, 0x01).id, 70, _OBJSIZ_8_1_0_1_0_0_0_0_);
		F71_1385(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		Result = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTMS_EX_H("https://",8,441357103);
		loc14 = F1168_10054(RTCW(tr1), tr2);
		tr1 = RTLNS(eif_new_type(1428, 0x01).id, 1428, _OBJSIZ_6_2_0_1_0_0_0_0_);
		F1429_14845(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		loc2 = (EIF_REFERENCE) tr1;
		loc13 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O12166[Dtype(loc2)-1428]);
		if ((EIF_BOOLEAN)(loc13 == ((EIF_INTEGER_32) 0L))) {
			if (loc14) {
				loc13 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 443L);
			} else {
				loc13 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
			}
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
		loc30 = tr1;
		if (EIF_TEST(loc30)) {
			loc4 = (EIF_REFERENCE) loc30;
		} else {
			tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_6_0_0_1_0_0_0_0_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1168_10060(RTCW(tr2));
			F1116_9763(RTCW(tr1), tr2);
			loc7 = (EIF_REFERENCE) tr1;
			loc4 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_2_);
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		loc31 = tr1;
		if (EIF_TEST(loc31)) {
		}
		loc8 = F1096_9254(Current, loc4, loc13, loc14, loc18);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc8)+ _CHROFF_7_7_);
		if (tb1) {
			tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1168_10007(RTCW(tr1));
			loc22 = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTMS_EX_H("Authorization",13,1468366446);
			tb1 = F961_8566(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				tb1 = '\0';
				tr1 = F448_5973(Current);
				loc32 = tr1;
				if (EIF_TEST(loc32)) {
					tr1 = F448_5974(Current);
					loc33 = tr1;
					tb1 = EIF_TEST(loc33);
				}
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1180, 0x01).id, 1180, _OBJSIZ_4_0_0_0_0_0_0_0_);
					F1181_10515(RTCW(tr1), loc32, loc33);
					loc15 = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc15));
					loc34 = tr1;
					if (EIF_TEST(loc34)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = RTMS_EX_H("Authorization",13,1468366446);
						F961_8605(RTCW(tr1), loc34, tr2);
					}
				}
			}
			tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
			F1174_10306(RTCW(tr1), tr2);
			loc6 = (EIF_REFERENCE) tr1;
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
			loc35 = tr1;
			if (EIF_TEST(loc35)) {
				tb2 = F1175_10373(loc35);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc6))-1175])(loc6, (EIF_CHARACTER_8) '\?');
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc6))-1175])(loc6, loc35);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTMS_EX_H("User-Agent",10,847703156);
			tb1 = F961_8566(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_unix__b) {
					loc16 = RTMS_EX_H("Unix",4,1433299320);
				} else {
					if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
						loc16 = RTMS_EX_H("Windows",7,583767667);
					} else {
						if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
							loc16 = RTMS_EX_H("Mac",3,5071203);
						} else {
							if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_vms__b) {
								loc16 = RTMS_EX_H("VMS",3,5655891);
							} else {
								if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_vxworks__b) {
									loc16 = RTMS_EX_H("VxWorks",7,294508659);
								} else {
									loc16 = RTMS_EX_H("Unknown",7,1902194030);
								}
							}
						}
					}
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTMS_EX_H("eiffelhttpclient/",17,159008559);
				tr3 = RTOUCR(613,F1096_9253, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr2)-1174])(tr2, tr3);
				tr3 = RTMS_EX_H(" (",2,8232);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr2))-1174])(tr2, tr3);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr2))-1174])(tr2, loc16);
				tr3 = RTMS_EX_H(")",1,41);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr2))-1174])(tr2, tr3);
				tr3 = RTMS_EX_H("User-Agent",10,847703156);
				F961_8605(RTCW(tr1), tr2, tr3);
			}
			loc27 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTMS_EX_H("Transfer-Encoding",17,2046553703);
			tr1 = F961_8564(RTCW(tr1), tr2);
			loc36 = tr1;
			if (EIF_TEST(loc36)) {
				tr1 = RTMS_EX_H("chunked",7,346719076);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(loc36)-1174])(loc36, tr1);
				loc27 = tb1;
			}
			if ((EIF_BOOLEAN)(loc18 != NULL)) {
				tb1 = F70_1359(RTCW(loc18));
				if (tb1) {
					loc21 = *(EIF_REFERENCE *)(RTCW(loc18) + _REFACS_5_);
				}
				tb1 = F70_1358(RTCW(loc18));
				if (tb1) {
					loc17 = *(EIF_REFERENCE *)(RTCW(loc18) + _REFACS_4_);
				}
				if ((EIF_BOOLEAN)(loc17 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					tr2 = RTMS_EX_H("Content-Type",12,1604261989);
					tb1 = F961_8566(RTCW(tr1), tr2);
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr2 = RTMS_EX_H("application/x-www-form-urlencoded",33,632002404);
						tr3 = RTMS_EX_H("Content-Type",12,1604261989);
						F961_8605(RTCW(tr1), tr2, tr3);
					}
					if ((EIF_BOOLEAN) !loc27) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17) + O8704[Dtype(loc17)-1173]);
						tr2 = eif_out__i4_s1(ti4_1);
						tr3 = RTMS_EX_H("Content-Length",14,547995240);
						F961_8605(RTCW(tr1), tr2, tr3);
					}
				} else {
					if ((EIF_BOOLEAN)(loc21 != NULL)) {
						tr1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
						F936_8192(RTCW(tr1), loc21);
						loc20 = (EIF_REFERENCE) tr1;
						tb1 = '\0';
						tb2 = F936_8227(RTCW(loc20));
						if (tb2) {
							tb2 = F936_8246(RTCW(loc20));
							tb1 = tb2;
						}
						if (tb1) {
							if ((EIF_BOOLEAN) !loc27) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								ti4_1 = F936_8222(RTCW(loc20));
								tr2 = eif_out__i4_s1(ti4_1);
								tr3 = RTMS_EX_H("Content-Length",14,547995240);
								F961_8605(RTCW(tr1), tr2, tr3);
							}
						}
					} else {
						tb1 = '\0';
						tb2 = F70_1357(RTCW(loc18));
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc18) + _REFACS_3_);
							loc37 = tr1;
							tb1 = (EIF_TRUE);
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							tr2 = RTMS_EX_H("Content-Type",12,1604261989);
							loc19 = F961_8564(RTCW(tr1), tr2);
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc19 != NULL)) {
								tr1 = RTMS_EX_H("application/x-www-form-urlencoded",33,632002404);
								tb2 = F1174_10340(RTCW(loc19), tr1);
								tb1 = tb2;
							}
							if (tb1) {
								loc17 = F70_1377(RTCW(loc18));
							} else {
								tb1 = '\01';
								tb2 = '\0';
								if ((EIF_BOOLEAN)(loc19 != NULL)) {
									tr1 = RTMS_EX_H("multipart/form-data",19,1299947873);
									tb3 = F1174_10340(RTCW(loc19), tr1);
									tb2 = tb3;
								}
								if (!tb2) {
									tb2 = F711_7956(loc37);
									tb1 = tb2;
								}
								if (tb1) {
									loc24 = F1096_9270(Current, loc37);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									tr2 = RTMS_EX_H("multipart/form-data; boundary=",30,780964157);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr2)-1174])(tr2, loc24);
									tr3 = RTMS_EX_H("Content-Type",12,1604261989);
									F961_8605(RTCW(tr1), tr2, tr3);
									loc17 = F1096_9259(Current, loc37, loc24);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									tr2 = RTMS_EX_H("application/x-www-form-urlencoded",33,632002404);
									tr3 = RTMS_EX_H("Content-Type",12,1604261989);
									F961_8605(RTCW(tr1), tr2, tr3);
									loc17 = F70_1377(RTCW(loc18));
								}
							}
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17) + O8704[Dtype(loc17)-1173]);
							tr2 = eif_out__i4_s1(ti4_1);
							tr3 = RTMS_EX_H("Content-Length",14,547995240);
							F961_8605(RTCW(tr1), tr2, tr3);
							if (loc27) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = RTMS_EX_H("Transfer-Encoding",17,2046553703);
								F961_8610(RTCW(tr1), tr2);
								loc27 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
						}
					}
				}
			}
			tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8528[Dtype(RTCW(tr2))-1171])(tr2);
			F1174_10306(RTCW(tr1), tr2);
			loc9 = (EIF_REFERENCE) tr1;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc9))-1175])(loc9, (EIF_CHARACTER_8) ' ');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, loc6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc9))-1175])(loc9, (EIF_CHARACTER_8) ' ');
			if (loc25) {
				tr1 = RTMS_EX_H("HTTP/1.0",8,303094320);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			} else {
				tr1 = RTMS_EX_H("HTTP/1.1",8,303094321);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			}
			tr1 = RTOUCR(614,F164_2673, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			tr1 = RTOUCR(615,F164_2671, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			tr1 = RTMS_EX_H(": ",2,14880);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTOUCR(615,F164_2671, (Current));
			tr1 = F961_8564(RTCW(tr1), tr2);
			loc38 = tr1;
			if (EIF_TEST(loc38)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, loc38);
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, loc4);
				if (loc14) {
					if ((EIF_BOOLEAN)(loc13 != ((EIF_INTEGER_32) 443L))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc9))-1175])(loc9, (EIF_CHARACTER_8) ':');
						F1176_10420(RTCW(loc9), loc13);
					}
				} else {
					if ((EIF_BOOLEAN)(loc13 != ((EIF_INTEGER_32) 80L))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc9))-1175])(loc9, (EIF_CHARACTER_8) ':');
						F1176_10420(RTCW(loc9), loc13);
					}
				}
			}
			tr1 = RTOUCR(614,F164_2673, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTMS_EX_H("Connection",10,2015825262);
			tb1 = F961_8566(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				if (loc25) {
					tr1 = RTMS_EX_H("Connection: keep-alive",22,2134188645);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
					tr1 = RTOUCR(614,F164_2673, (Current));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
				}
			}
			loc5 = (EIF_REFERENCE) NULL;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = F870_8129(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				loc39 = F961_8573(RTCW(tr1));
				for (;;) {
					tb1 = F650_7876(loc39);
					if (tb1) break;
					loc3 = F650_7874(loc39);
					tr1 = RTMS_EX_H("Host",4,1215263604);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8511[Dtype(RTCW(loc3))-1171])(loc3, tr1);
					if (tb2) {
					} else {
						tr1 = RTMS_EX_H("Cookie",6,2001890149);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8511[Dtype(RTCW(loc3))-1171])(loc3, tr1);
						if (tb2) {
							loc5 = F650_7873(loc39);
						} else {
							tr1 = F650_7874(loc39);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
							tr1 = RTMS_EX_H(": ",2,14880);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
							tr1 = F650_7873(loc39);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
							tr1 = RTOUCR(614,F164_2673, (Current));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
						}
					}
					F650_7877(loc39);
				}
			}
			if ((EIF_BOOLEAN)(loc5 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
			}
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTMS_EX_H("Cookie: ",8,2036389408);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, loc5);
				tr1 = RTOUCR(614,F164_2673, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			}
			tr1 = RTOUCR(614,F164_2673, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc9))-1175])(loc9, tr1);
			tb2 = F567_7245(RTCW(loc8));
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tb2 = F1383_13369(RTCW(tr1));
				if (tb2) {
					tr1 = RTMS_EX_H("> Sending:\012",11,485789194);
					F1096_9256(Current, tr1);
					F1096_9256(Current, loc9);
				}
				F565_7112(RTCW(loc8), loc9);
				if ((EIF_BOOLEAN)(loc17 != NULL)) {
					if (loc27) {
						ti4_1 = F448_5982(Current);
						F1096_9261(Current, loc17, ti4_1, loc8);
					} else {
						F565_7112(RTCW(loc8), loc17);
					}
				}
				if ((EIF_BOOLEAN)(loc20 != NULL)) {
					if (loc27) {
						ti4_1 = F936_8222(RTCW(loc20));
						ti4_2 = F448_5982(Current);
						F1096_9264(Current, loc20, ti4_1, ti4_2, loc8);
					} else {
						ti4_1 = F936_8222(RTCW(loc20));
						F1096_9265(Current, loc20, ti4_1, loc8);
					}
				}
				if (F1096_9257(Current, loc8)) {
					tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1168_10007(RTCW(tr1));
					loc10 = (EIF_REFERENCE) tr1;
					F1096_9267(Current, Result, loc8, loc10);
					tr1 = *(EIF_REFERENCE *)(Current);
					tb2 = F1383_13370(RTCW(tr1));
					if (tb2) {
						tr1 = RTMS_EX_H("< Receiving:\012",13,798060298);
						F1096_9256(Current, tr1);
						F1096_9256(Current, loc10);
					}
					loc23 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_4_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8684[Dtype(RTCW(loc10))-1174])(loc10);
					F71_1408(RTCW(Result), tr1);
					tr1 = RTOUCR(614,F164_2673, (Current));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc10))-1175])(loc10, tr1);
					tb2 = *(EIF_BOOLEAN *)(RTCW(Result)+ _CHROFF_8_0_);
					if ((EIF_BOOLEAN) !tb2) {
						loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						tb2 = '\0';
						tr1 = RTMS_EX_H("Content-Length",14,547995240);
						tr1 = F71_1397(RTCW(Result), tr1);
						loc40 = tr1;
						if (EIF_TEST(loc40)) {
							tb3 = F1168_10038(loc40);
							tb2 = tb3;
						}
						if (tb2) {
							loc11 = F1168_10072(loc40);
						}
						tr1 = RTMS_EX_H("Location",8,52138606);
						loc12 = F71_1397(RTCW(Result), tr1);
						tr1 = RTMS_EX_H("Set-Cookie",10,1847670373);
						tr1 = F71_1397(RTCW(Result), tr1);
						loc41 = tr1;
						if (EIF_TEST(loc41)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							F1383_13408(RTCW(tr1), loc41);
						}
						tr1 = RTMS_EX_H("Connection",10,2015825262);
						tr1 = F71_1397(RTCW(Result), tr1);
						loc42 = tr1;
						if (EIF_TEST(loc42)) {
							tr1 = RTMS_EX_H("keep-alive",10,576698981);
							loc26 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(loc42)-1174])(loc42, tr1);
						} else {
							loc26 = F71_1402(RTCW(Result));
							loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc26;
						}
						F1096_9268(Current, Result, loc8, loc11, loc10);
						F71_1408(RTCW(Result), loc23);
						F71_1407(RTCW(Result), loc10, loc18);
						if (loc26) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = RTLNS(eif_new_type(40, 0x01).id, 40, _OBJSIZ_2_0_0_1_0_0_0_0_);
							F41_844(RTCW(tr2), loc8, loc4, loc13);
							F1385_13447(RTCW(tr1), tr2);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current);
							F1385_13447(RTCW(tr1), NULL);
						}
						tb2 = '\0';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_8_1_0_0_);
						if (F1096_9258(Current, ti4_1)) {
							tb2 = (EIF_BOOLEAN)(loc12 != NULL);
						}
						if (tb2) {
							ti4_1 = F71_1396(RTCW(Result));
							if ((EIF_BOOLEAN) (ti4_1 < F448_5979(Current))) {
								F448_5962(Current, loc12, loc18);
								loc1 = F1096_9255(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_4_);
								tr3 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
								F71_1409(RTCW(loc1), tr1, tr2, tr3);
								Result = (EIF_REFERENCE) loc1;
							}
						}
						if ((EIF_BOOLEAN) !loc26) {
							F565_7096(RTCW(loc8));
						}
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(Current);
					tb2 = F1383_13371(RTCW(tr1));
					if (tb2) {
						tr1 = RTMS_EX_H("Debug: Read Timeout!\012",21,1876485386);
						F1096_9256(Current, tr1);
					}
					tr1 = RTMS_EX_H("Read Timeout",12,537157236);
					F71_1389(RTCW(Result), tr1);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current);
				tb2 = F1383_13371(RTCW(tr1));
				if (tb2) {
					tr1 = RTMS_EX_H("Debug: Write Timeout!\012",22,276185098);
					F1096_9256(Current, tr1);
				}
				tr1 = RTMS_EX_H("Write Timeout",13,1818943348);
				F71_1389(RTCW(Result), tr1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb2 = F1383_13371(RTCW(tr1));
			if (tb2) {
				tr1 = RTMS_EX_H("Debug: Could not connect!\012",26,964102666);
				F1096_9256(Current, tr1);
			}
			tr1 = RTMS_EX_H("Could not connect",17,293773172);
			F71_1389(RTCW(Result), tr1);
		}
	} else {
		tr1 = RTLNS(eif_new_type(70, 0x01).id, 70, _OBJSIZ_8_1_0_1_0_0_0_0_);
		F71_1385(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTMS_EX_H("Error: internal error",21,167678066);
		F71_1389(RTCW(Result), tr1);
	}
	RTE_E
	RTXSC;
	loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {NET_HTTP_CLIENT_REQUEST}.log */
void F1096_9256 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(34,F100_1807, (RTCV(RTOUCR(2,F1_24, (Current)))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(RTCW(tr1))-563])(tr1, arg1);
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.is_ready_for_reading */
EIF_BOOLEAN F1096_9257 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = F567_7244(RTCW(arg1));
	return (EIF_BOOLEAN) tb1;
}

/* {NET_HTTP_CLIENT_REQUEST}.is_redirection_http_status */
EIF_BOOLEAN F1096_9258 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 300L)) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 400L)));
}

/* {NET_HTTP_CLIENT_REQUEST}.form_date_and_uploaded_files_to_mime_string */
EIF_REFERENCE F1096_9259 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,Current);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(Result), ((EIF_INTEGER_32) 100L));
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(arg1))-635])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc1)-515])(loc1);
		if (tb1) break;
		tr1 = RTMS_EX_H("--",2,11565);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, arg2);
		tr1 = RTOUCR(614,F164_2673, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		tr1 = RTMS_EX_H("Content-Disposition: form-data; name=",37,1978777149);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\"');
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr1 = F1096_9260(Current, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\"');
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1243, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = *(EIF_REFERENCE *)(loc2);
			loc3 = tr1;
			tb2 = EIF_TEST(loc3);
		}
		if (tb2) {
			tr1 = RTMS_EX_H("; filename=",11,364312381);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\"');
			tr1 = F1096_9260(Current, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '\"');
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTOUCR(614,F164_2673, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			tr1 = RTMS_EX_H("Content-Type: ",14,597285920);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, loc4);
		}
		tr1 = RTOUCR(614,F164_2673, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		tr1 = RTOUCR(614,F164_2673, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc1)-515])(loc1);
		F1245_11173(RTCW(tr1), Result);
		tr1 = RTOUCR(614,F164_2673, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc1)-515])(loc1);
	}
	tr1 = RTMS_EX_H("--",2,11565);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, arg2);
	tr1 = RTMS_EX_H("--",2,11565);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
	RTLE;
	return Result;
}

/* {NET_HTTP_CLIENT_REQUEST}.string_to_mime_encoded_string */
EIF_REFERENCE F1096_9260 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	
	tr1 = F86_1634(RTCW(loc1), arg1);
	return (EIF_REFERENCE) tr1;
}

/* {NET_HTTP_CLIENT_REQUEST}.put_string_using_chunked_transfer_encoding */
void F1096_9261 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc1, (EIF_INTEGER_32) (loc1 + arg2));
		F1096_9262(Current, tr1, NULL, arg3);
		loc1 += arg2;
	}
	F1096_9263(Current, NULL, NULL, arg3);
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.put_chunk */
void F1096_9262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	tr1 = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = ti4_1;
	loc1 = F1311_11668(RTCW(tr1));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(loc1))-960])(loc1, loc2));
		if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0')) break;
		loc2++;
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 1L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O8704[Dtype(loc1)-1173]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc1))-1171])(loc1, loc2, ti4_1);
		loc1 = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, arg2);
	}
	tr1 = RTOUCR(616,F1096_9271, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	F565_7112(RTCW(arg3), loc1);
	F565_7112(RTCW(arg3), arg1);
	tr1 = RTOUCR(616,F1096_9271, (Current));
	F565_7112(RTCW(arg3), tr1);
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.put_chunk_end */
void F1096_9263 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	F1176_10420(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, arg1);
	}
	tr1 = RTOUCR(616,F1096_9271, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	F565_7112(RTCW(arg3), loc1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg2))-1171])(arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F565_7112(RTCW(arg3), arg2);
	}
	tr1 = RTOUCR(616,F1096_9271, (Current));
	F565_7112(RTCW(arg3), tr1);
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.append_file_content_to_socket_using_chunked_transfer_encoding */
void F1096_9264 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg4);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 >= ((EIF_INTEGER_32) 0L))) {
		loc2 = (EIF_INTEGER_32) arg2;
	} else {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(arg1))-908])(arg1);
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		loc1 = F936_8252(RTCW(arg1));
		tb1 = F936_8252(RTCW(arg1));
		if (tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			F936_8262(RTCW(arg1));
		}
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
				tb2 = F742_7994(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) break;
			ti4_1 = eif_min_int32 (loc2,arg3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6297[Dtype(RTCW(arg1))-936])(arg1, ti4_1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1096_9262(Current, tr1, NULL, arg4);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6238[Dtype(arg1)-562]);
			loc2 -= ti4_1;
		}
		if ((EIF_BOOLEAN) !loc1) {
			F936_8279(RTCW(arg1));
		}
		F1096_9263(Current, NULL, NULL, arg4);
	}
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.append_file_content_to_socket */
void F1096_9265 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 >= ((EIF_INTEGER_32) 0L))) {
		loc2 = (EIF_INTEGER_32) arg2;
	} else {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(arg1))-908])(arg1);
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		loc1 = F936_8252(RTCW(arg1));
		tb1 = F936_8252(RTCW(arg1));
		if (tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			F936_8262(RTCW(arg1));
		}
		loc3 = F448_5981(Current);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
				tb2 = F742_7994(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) break;
			ti4_1 = eif_min_int32 (loc2,loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6297[Dtype(RTCW(arg1))-936])(arg1, ti4_1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F565_7112(RTCW(arg3), tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6238[Dtype(arg1)-562]);
			loc2 -= ti4_1;
		}
		if ((EIF_BOOLEAN) !loc1) {
			F936_8279(RTCW(arg1));
		}
	}
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.append_socket_header_content_to */
void F1096_9267 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,Current);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTMS_EX_H("",0,0);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tr1 = RTMS_EX_H("\015",1,13);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(RTCW(loc1))-1174])(loc1, tr1);
		if (!tb3) {
			tb3 = F565_7145(RTCW(arg2));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_8_0_);
			tb1 = tb2;
		}
		if (tb1) break;
		F569_7328(RTCW(arg2));
		loc1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(loc1))-1171])(loc1);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb2 = F1383_13371(RTCW(tr1));
			if (tb2) {
				tr1 = RTMS_EX_H("Debug: ERROR: zero byte read when receiving header.\012",52,502854666);
				F1096_9256(Current, tr1);
			}
			tr1 = RTMS_EX_H("Read zero byte, expecting header line",37,1137936485);
			F71_1389(RTCW(arg1), tr1);
		} else {
			tr1 = RTMS_EX_H("\015",1,13);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(RTCW(loc1))-1174])(loc1, tr1);
			if (tb2) {
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(arg3))-1175])(arg3, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg3))-1175])(arg3, (EIF_CHARACTER_8) '\012');
			}
		}
	}
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.append_socket_content_to */
void F1096_9268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,arg4);
	RTLR(6,loc6);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	tb1 = F565_7145(RTCW(arg2));
	if (tb1) {
		if ((EIF_BOOLEAN) (arg3 >= ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb1 = F1383_13371(RTCW(tr1));
			if (tb1) {
				tr1 = RTMS_EX_H("Debug: Content-Length=",22,1309658173);
				tr2 = eif_out__i4_s1(arg3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
				tr2 = RTMS_EX_H("\012",1,10);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
				F1096_9256(Current, tr1);
			}
			loc2 = (EIF_INTEGER_32) arg3;
			for (;;) {
				tb1 = '\01';
				tb2 = '\01';
				if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
					tb3 = F565_7145(RTCW(arg2));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (!tb2) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_8_0_);
					tb1 = tb2;
				}
				if (tb1) break;
				F569_7326(RTCW(arg2), loc2);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
				loc5 += ti4_1;
				tr1 = *(EIF_REFERENCE *)(Current);
				tb2 = F1383_13371(RTCW(tr1));
				if (tb2) {
					tr1 = RTMS_EX_H("Debug:   - byte read=",21,609204541);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
					tr2 = eif_out__i4_s1(ti4_1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("\012",1,10);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					F1096_9256(Current, tr1);
					tr1 = RTMS_EX_H("Debug:   - current count=",25,341904957);
					tr2 = eif_out__i4_s1(loc5);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("\012",1,10);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					F1096_9256(Current, tr1);
				}
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
				loc2 -= ti4_1;
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(arg4))-1175])(arg4, tr1);
			}
		} else {
			tb2 = '\0';
			tr1 = RTMS_EX_H("Transfer-Encoding",17,2046553703);
			tr1 = F71_1397(RTCW(arg1), tr1);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				tr1 = RTMS_EX_H("chunked",7,346719076);
				tb3 = F1174_10330(loc6, tr1);
				tb2 = tb3;
			}
			if (tb2) {
				F1096_9269(Current, arg1, arg2, arg4);
			} else {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc4 = F448_5981(Current);
				loc3 = (EIF_INTEGER_32) loc4;
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (loc3 < loc4)) {
						tb3 = F565_7145(RTCW(arg2));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) break;
					F569_7326(RTCW(arg2), loc4);
					loc1 = *(EIF_REFERENCE *)(RTCW(arg2));
					loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
					loc5 += loc3;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(arg4))-1175])(arg4, loc1);
				}
			}
		}
	}
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.append_socket_chunked_content_to */
void F1096_9269 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc6);
	RTLR(3,arg2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLR(7,arg3);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1383_13371(RTCW(tr1));
	if (tb1) {
		tr1 = RTMS_EX_H("Debug: Chunked encoding\012",24,103349002);
		F1096_9256(Current, tr1);
	}
	loc6 = RTLNS(eif_new_type(293, 0x01).id, 293, _OBJSIZ_2_4_0_3_0_0_2_0_);
	F294_4053(RTCW(loc6));
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			tb2 = F565_7145(RTCW(arg2));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F569_7328(RTCW(arg2));
		loc1 = *(EIF_REFERENCE *)(RTCW(arg2));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8587[Dtype(RTCW(loc1))-1172])(loc1);
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F1383_13371(RTCW(tr1));
		if (tb2) {
			tr1 = RTMS_EX_H("Debug:   - chunk info=\'",23,726410023);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc1);
			tr2 = RTMS_EX_H("\'\012",2,9994);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			F1096_9256(Current, tr1);
		}
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc1))-1174])(loc1, (EIF_CHARACTER_8) ';', ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8584[Dtype(RTCW(loc1))-1172])(loc1, (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
		}
		tb2 = F874_8129(RTCW(loc1));
		if (tb2) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			ti4_1 = ((EIF_INTEGER_32) 3L);
			F294_4059(RTCW(loc6), loc1, ti4_1);
			tb2 = F294_4057(RTCW(loc6));
			if (tb2) {
				loc3 = F294_4067(RTCW(loc6));
			} else {
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F1383_13371(RTCW(tr1));
		if (tb2) {
			tr1 = RTMS_EX_H("Debug:   - chunk size=",22,1480614717);
			tr2 = eif_out__i4_s1(loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
			tr2 = RTMS_EX_H("\012",1,10);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			F1096_9256(Current, tr1);
		}
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
			loc2 = (EIF_INTEGER_32) loc3;
			for (;;) {
				tb2 = '\01';
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
					tb4 = F565_7145(RTCW(arg2));
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				if (!tb3) {
					tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_8_0_);
					tb2 = tb3;
				}
				if (tb2) break;
				F569_7326(RTCW(arg2), loc2);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
				loc5 += ti4_1;
				tr1 = *(EIF_REFERENCE *)(Current);
				tb3 = F1383_13371(RTCW(tr1));
				if (tb3) {
					tr1 = RTMS_EX_H("Debug:   - byte read=",21,609204541);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
					tr2 = eif_out__i4_s1(ti4_1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("\012",1,10);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					F1096_9256(Current, tr1);
					tr1 = RTMS_EX_H("Debug:   - current count=",25,341904957);
					tr2 = eif_out__i4_s1(loc5);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("\012",1,10);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					F1096_9256(Current, tr1);
				}
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_7_12_2_2_);
				loc2 -= ti4_1;
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(arg3))-1175])(arg3, tr1);
			}
			F569_7325(RTCW(arg2));
			F569_7325(RTCW(arg2));
			tr1 = *(EIF_REFERENCE *)(Current);
			tb3 = F1383_13371(RTCW(tr1));
			if (tb3) {
				tr1 = RTMS_EX_H("Debug:   - Found CRNL \012",23,518128138);
				F1096_9256(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {NET_HTTP_CLIENT_REQUEST}.new_mime_boundary */
EIF_REFERENCE F1096_9270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Result);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(arg1))-635])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc6)-515])(loc6);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
		ti4_1 = F1245_11170(RTCW(tr1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8624[Dtype(tr1)-1170]);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + ti4_1) + ti4_2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc6)-515])(loc6);
	}
	loc2 = RTLNS(eif_new_type(867, 0x01).id, 867, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F868_8096(RTCW(loc2), loc4);
	F867_8086(RTCW(loc2));
	F867_8085(RTCW(loc2));
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 10L));
	tr4_2 = F868_8105(RTCW(loc2));
	loc3 = (EIF_INTEGER_32) (EIF_REAL_32) (tr4_1 * tr4_2);
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10305(RTCW(Result), (EIF_CHARACTER_8) '-', (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) + loc3));
	loc1 = RTMS_EX_H("_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",63,1917739610);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result) + O8704[Dtype(Result)-1173]);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 40L))) break;
		F867_8085(RTCW(loc2));
		tr4_1 = F868_8105(RTCW(loc2));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O8704[Dtype(loc1)-1173]);
		tr4_2 = (EIF_REAL_32) (ti4_2);
		ti4_2 = (EIF_INTEGER_32) (EIF_REAL_32) (tr4_1 * tr4_2);
		loc5 = eif_max_int32 (ti4_2,((EIF_INTEGER_32) 1L));
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(loc1))-960])(loc1, loc5));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, tc1);
	}
	RTLE;
	return Result;
}

/* {NET_HTTP_CLIENT_REQUEST}.crlf */

EIF_REFERENCE F1096_9271 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (616,RTMS_EX_H("\015\012",2,3338));
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
