/*
 * Code for class UC_UTF8_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UTF8_ROUTINES}.encoded_first_value */
EIF_INTEGER_32 F1087_9160 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result %= ((EIF_INTEGER_32) 32L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				Result %= ((EIF_INTEGER_32) 16L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')) {
					return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8L));
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_next_value */
EIF_INTEGER_32 F1087_9161 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 64L));
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_byte_count */
EIF_INTEGER_32 F1087_9166 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_byte_count */
EIF_INTEGER_32 F1087_9168 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		tb1 = '\0';
		tr1 = RTOUCR(671,F1077_9036, (Current));
		tr2 = RTOUCR(672,F1087_9205, (Current));
		tb2 = F21_183(RTCW(tr1), arg1, tr2);
		if (tb2) {
			loc4 = arg1;
			loc4 = RTRV(eif_new_type(1175, 0x01),loc4);
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			loc3 = (EIF_INTEGER_32) arg2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > arg3)) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(loc4)-960])(loc4, loc3));
				Result += F1087_9170(Current, tc1);
				loc3++;
			}
		} else {
			tb1 = '\0';
			tr1 = RTOUCR(671,F1077_9036, (Current));
			tr2 = RTOUCR(673,F1087_9206, (Current));
			tb2 = F21_183(RTCW(tr1), arg1, tr2);
			if (tb2) {
				loc5 = arg1;
				loc5 = RTRV(eif_new_type(1451, 0x01),loc5);
				tb1 = EIF_TEST(loc5);
			}
			if (tb1) {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
				}
				if (tb1) {
					Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
				} else {
					loc1 = F1452_15370(loc5, arg2);
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
						Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
					} else {
						loc2 = F1452_15369(loc5, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
					}
				}
			} else {
				loc6 = arg1;
				loc6 = RTRV(eif_new_type(1452, 0x01),loc6);
				if (EIF_TEST(loc6)) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6);
						tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
					}
					if (tb1) {
						Result = *(EIF_INTEGER_32 *)(loc6);
						RTLE;
						return (EIF_INTEGER_32) Result;
					} else {
						loc1 = (RTNA((loc6, arg2)), ((EIF_INTEGER_32) 0));
						ti4_1 = *(EIF_INTEGER_32 *)(loc6);
						if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
							Result = *(EIF_INTEGER_32 *)(loc6);
							Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
						} else {
							loc2 = (RTNA((loc6, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)))), ((EIF_INTEGER_32) 0));
							RTLE;
							return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
						}
					}
				} else {
					loc3 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 > arg3)) break;
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, loc3);
						Result += F1087_9171(Current, tw1);
						loc3++;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.character_byte_count */
EIF_INTEGER_32 F1087_9169 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1087_9170(Current, arg1);
}

/* {UC_UTF8_ROUTINES}.character_8_byte_count */
EIF_INTEGER_32 F1087_9170 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}/* NOTREACHED */
	
}

/* {UC_UTF8_ROUTINES}.character_32_byte_count */
EIF_INTEGER_32 F1087_9171 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	Result = F1087_9173(Current, tu4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.code_byte_count */
EIF_INTEGER_32 F1087_9172 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1114111L))) {
		tu4_1 = (EIF_NATURAL_32) arg1;
		Result = F1087_9173(Current, tu4_1);
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.natural_32_code_byte_count */
EIF_INTEGER_32 F1087_9173 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 128U))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 2048U))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 57343U))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 65536U))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					} else {
						if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))) {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						} else {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
					}
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.string_to_utf8 */
EIF_REFERENCE F1087_9176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	Result = F1087_9177(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_to_utf8 */
EIF_REFERENCE F1087_9177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = F1087_9168(Current, arg1, arg2, arg3);
	F1174_10304(RTCW(Result), ti4_1);
	F1087_9180(Current, Result, arg1, arg2, arg3);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.append_substring_to_utf8 */
void F1087_9180 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		loc1 = (EIF_INTEGER_32) arg3;
		loc2 = (EIF_INTEGER_32) arg4;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg2))-1171])(arg2, loc1);
			F1087_9182(Current, arg1, tu4_1);
			loc1++;
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.append_natural_32_code_to_utf8 */
void F1087_9182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 128U))) {
		tc1 = (EIF_CHARACTER_8) arg2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, tc1);
	} else {
		if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 2048U))) {
			loc4 = (EIF_NATURAL_32) arg2;
			loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
			loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
			tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, tc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc1);
		} else {
			if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 65536U))) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 >= ((EIF_NATURAL_32) 55296U)) && (EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 57343U)))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, (EIF_CHARACTER_8) '\377');
				} else {
					loc4 = (EIF_NATURAL_32) arg2;
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 224L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc2);
				}
			} else {
				if ((EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 1114111U))) {
					loc4 = (EIF_NATURAL_32) arg2;
					loc3 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 240L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, loc3);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, (EIF_CHARACTER_8) '\377');
				}
			}
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.dummy_string */

EIF_REFERENCE F1087_9205 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (672,RTMS_EX_H("",0,0));
}

/* {UC_UTF8_ROUTINES}.dummy_uc_string */
static EIF_REFERENCE F1087_9206_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(673)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1451, 0x01).id, 1451, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F1452_15266(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1087_9206 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(673,F1087_9206_body,(Current));
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
