/*
 * Code for class CONF_TARGET_OPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co508.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TARGET_OPTION}.make_6_3 */
void F595_7660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F594_7555(Current);
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(369,F595_7689, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(370,F595_7690, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(371,F595_7691, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1184, 1).id);
	F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1184, 1).id);
	F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1184, 1).id);
	F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_TARGET_OPTION}.make_16_11 */
void F595_7661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F594_7561(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTLE;
}

/* {CONF_TARGET_OPTION}.make_19_05 */
void F595_7662 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F594_7563(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTLE;
}

/* {CONF_TARGET_OPTION}.has_capability */
EIF_BOOLEAN F595_7664 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tb5 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
	if (!tb5) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tb5 = F1185_10615(RTCW(tr1));
		tb4 = tb5;
	}
	if (!tb4) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tb4 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb3 = tb4;
	}
	if (!tb3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tb3 = F1185_10615(RTCW(tr1));
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tb1 = F1185_10615(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_TARGET_OPTION}.merge */
void F595_7687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F594_7658(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
	F1185_10628(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
	F1185_10627(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	F1185_10627(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_16_);
	F1186_10641(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_17_);
	F1186_10641(RTCW(tr1), tr2);
	RTLE;
}

/* {CONF_TARGET_OPTION}.copy */
void F595_7688 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F594_7652(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
		tr1 = RTLNSMART(eif_new_type(1184, 1).id);
		F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1185_10625(RTCW(tr1), tu1_1);
		tr1 = RTLNSMART(eif_new_type(1184, 1).id);
		F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1185_10625(RTCW(tr1), tu1_1);
		tr1 = RTLNSMART(eif_new_type(1184, 1).id);
		F1185_10611(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1185_10625(RTCW(tr1), tu1_1);
	}
	RTLE;
}

/* {CONF_TARGET_OPTION}.concurrency_name */
static EIF_REFERENCE F595_7689_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(369)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10066(RTCV(RTOUCR(372,F344_4887, (Current))));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(373,F344_4886, (Current))));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(374,F344_4888, (Current))));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F595_7689 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(369,F595_7689_body,(Current));
}

/* {CONF_TARGET_OPTION}.array_override_name */
static EIF_REFERENCE F595_7690_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(370)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 4L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOUCR(375,F344_4966, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(376,F344_4967, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(377,F344_4968, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(378,F344_4969, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F595_7690 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(370,F595_7690_body,(Current));
}

/* {CONF_TARGET_OPTION}.dead_code_name */
static EIF_REFERENCE F595_7691_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(371)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOUCR(379,F344_4899, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(380,F344_4900, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(381,F344_4901, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F595_7691 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(371,F595_7691_body,(Current));
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
