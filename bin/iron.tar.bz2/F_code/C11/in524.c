/*
 * Code for class INI_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in524.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_FILE}.make_empty */
void F948_8538 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,1170,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F971_8683(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {INI_FILE}.make_with_path */
void F948_8539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F948_8538(Current);
	F948_8550(Current, arg1);
	RTLE;
}

/* {INI_FILE}.item */
EIF_REFERENCE F948_8541 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F961_8564(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {INI_FILE}.adjusted_item */
EIF_REFERENCE F948_8542 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F961_8564(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1171_10139(RTCW(Result), loc1);
		F1173_10236(RTCW(Result));
		F1173_10237(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {INI_FILE}.new_cursor */
EIF_REFERENCE F948_8544 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F961_8573(RTCW(tr1));
	RTLE;
	return Result;
}

/* {INI_FILE}.reset */
void F948_8545 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F961_8612(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {INI_FILE}.put */
void F948_8546 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F1168_10067(RTCW(arg1));
		F961_8605(RTCW(tr1), tr2, arg2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		F961_8605(RTCW(tr1), NULL, arg2);
	}
	RTLE;
}

/* {INI_FILE}.remove */
void F948_8547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F961_8610(RTCW(tr1), arg1);
	RTLE;
}

/* {INI_FILE}.save_to */
void F948_8548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(936, 0x01).id, 936, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F937_8421(RTCW(loc1), arg1);
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[Dtype(RTCW(loc1))-568])(loc1);
	if (!(EIF_BOOLEAN) !tb2) {
		tb2 = F936_8247(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F936_8266(RTCW(loc1));
		tr1 = F948_8549(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(RTCW(loc1))-563])(loc1, tr1);
		F936_8279(RTCW(loc1));
	}
	RTLE;
}

/* {INI_FILE}.text */
EIF_REFERENCE F948_8549 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	RTLI(8);
	RTLR(0,Result);
	RTLR(1,loc3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(Result), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = F961_8573(RTCW(tr1));
	for (;;) {
		tb1 = F650_7876(loc3);
		if (tb1) break;
		tr1 = F650_7873(loc3);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = F650_7874(loc3);
			tr1 = F86_1634(RTCW(loc1), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(Result))-1175])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) ':');
			loc2 = F86_1634(RTCW(loc1), loc4);
			tr1 = RTMS_EX_H("\012",1,10);
			tr2 = RTMS_EX_H("\012+",2,2603);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8717[Dtype(RTCW(loc2))-1175])(loc2, tr1, tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(Result))-1175])(Result, loc2);
		} else {
			tr1 = RTMS_EX_H("#",1,35);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(Result))-1175])(Result, tr1);
			tr1 = F650_7874(loc3);
			tr1 = F86_1634(RTCW(loc1), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(Result))-1175])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) ':');
		}
		tr1 = RTMS_EX_H("\012",1,10);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(Result))-1175])(Result, tr1);
		F650_7877(loc3);
	}
	RTLE;
	return Result;
}

/* {INI_FILE}.import */
void F948_8550 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	struct eif_ex_79 sloc8;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) sloc8.data;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	memset (&sloc8.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc8.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc8.overhead, eif_new_type(85, 0x00).id);
	RTLI(12);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc9);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc10);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc6);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(936, 0x01).id, 936, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F937_8421(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[Dtype(RTCW(loc1))-568])(loc1);
	if (tb3) {
		tb3 = F936_8236(RTCW(loc1));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = F936_8246(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F936_8262(RTCW(loc1));
		for (;;) {
			tb1 = F742_7994(RTCW(loc1));
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6298[Dtype(RTCW(loc1))-936])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8586[Dtype(RTCW(loc2))-1172])(loc2);
			tb2 = F874_8129(RTCW(loc2));
			if (tb2) {
			} else {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(loc2))-960])(loc2, ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '#')) {
				} else {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(loc2))-960])(loc2, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '+')) {
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr1 = F961_8564(RTCW(tr1), loc3);
							loc9 = tr1;
							if (EIF_TEST(loc9)) {
								loc10 = loc9;
								loc10 = RTRV(eif_new_type(1172, 0x01),loc10);
								if (EIF_TEST(loc10)) {
									loc7 = (EIF_REFERENCE) loc10;
								} else {
									loc7 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
									F1171_10139(RTCW(loc7), loc9);
								}
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1173_10265(RTCW(loc7), tw1);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
								if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
									tr1 = F1168_10089(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
									tr1 = F86_1648(RTCW(loc8), tr1);
									F1173_10252(RTCW(loc7), tr1);
								}
								tr1 = *(EIF_REFERENCE *)(Current);
								F961_8605(RTCW(tr1), loc7, loc3);
							}
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc2))-1174])(loc2, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
						loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc2))-1174])(loc2, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) < loc5) && (EIF_BOOLEAN) (loc5 < loc4)))) {
							loc4 = (EIF_INTEGER_32) loc5;
						}
						if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8704[Dtype(loc2)-1173]);
							loc6 = F1168_10089(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - loc4));
							tr1 = F1168_10088(RTCW(loc2), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
							loc2 = (EIF_REFERENCE) tr1;
							loc3 = F86_1648(RTCW(loc8), loc2);
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = F86_1648(RTCW(loc8), loc6);
							F961_8605(RTCW(tr1), tr2, loc3);
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
			}
		}
		F936_8279(RTCW(loc1));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit524 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
