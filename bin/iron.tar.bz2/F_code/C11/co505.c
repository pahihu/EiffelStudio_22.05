/*
 * Code for class CONF_LOAD_PARSE_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_PARSE_CALLBACKS}.make_with_factory */
void F592_7437 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (XML_CALLBACKS_NULL.make) */
		/* END INLINED CODE */
	}
	;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1056,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1055_8838(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,962,0xFF01,1172,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F963_8558(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1172, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100000L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1055,0xFF01,1074,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1054_8838(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,0xFF01,1170,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F961_8558(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_start_tag */
void F592_7441 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(arg3))-1171])(arg3);
		F424_5539(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		tb1 = F872_8129(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			F1057_8887(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F1057_8885(RTCW(tr1));
		loc1 = F592_7510(Current, ti4_1, loc4);
		tr1 = RTLNSMART(eif_new_type(1172, 1).id);
		F1168_10007(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
		tb1 = '\0';
		if ((EIF_BOOLEAN)(F592_7509(Current) == ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 44L));
		}
		if (tb1) {
			loc2 = RTLNS(eif_new_type(1074, 0x01).id, 1074, _OBJSIZ_5_1_0_1_0_0_0_0_);
			F1075_8998(RTCW(loc2), loc4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			F1056_8887(RTCW(tr1), loc2);
		} else {
			if ((EIF_BOOLEAN) (F592_7509(Current) > ((EIF_INTEGER_32) 0L))) {
				loc2 = RTLNS(eif_new_type(1074, 0x01).id, 1074, _OBJSIZ_5_1_0_1_0_0_0_0_);
				F1075_8998(RTCW(loc2), loc4);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				loc3 = F1056_8885(RTCW(tr1));
				F1059_8949(RTCW(loc3), loc2);
				F1075_9002(RTCW(loc2), loc3);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				F1056_8887(RTCW(tr1), loc2);
			}
		}
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14097(RTCW(tr1), arg3);
			F424_5542(Current, tr1);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1057_8887(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_attribute */
void F592_7442 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,arg4);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = RTMS_EX_H("xmlns",5,1836744307);
		tb4 = F1168_10049(RTCW(arg3), tr1);
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tr1 = RTMS_EX_H("xsi",3,7893865);
		tb3 = F1168_10049(RTCW(arg3), tr1);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tr1 = RTMS_EX_H("schemaLocation",14,147944814);
		tb2 = F1168_10049(RTCW(arg3), tr1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(arg3))-1171])(arg3);
		if ((EIF_BOOLEAN)(F592_7509(Current) == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOUCR(306,F592_7519, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F1057_8885(RTCW(tr2));
			tr1 = F963_8564(RTCW(tr1), ti4_1);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				loc1 = F966_8564(loc3, loc2);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_22_) == NULL)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,962,0xFF01,1172,1312,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNSMART(typres0.id);
				}
				F963_8558(RTCW(tr1), ((EIF_INTEGER_32) 1L));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
				tb2 = F963_8566(RTCW(tr1), loc1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg4))-1171])(arg4);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr2 = F592_7516(Current, arg4);
					F963_8605(RTCW(tr1), tr2, loc1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14098(RTCW(tr1), arg3);
					F424_5542(Current, tr1);
				}
			} else {
				F592_7521(Current, arg3);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
			tr2 = F592_7516(Current, arg4);
			F961_8605(RTCW(tr1), tr2, loc2);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_start_tag_finish */
void F592_7443 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,loc1);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F1057_8885(RTCW(tr1));
		switch (ti4_1) {
			case 47L:
				F592_7449(Current);
				break;
			case 2L:
				F592_7450(Current);
				break;
			case 4L:
				F592_7451(Current);
				break;
			case 5L:
				F592_7452(Current);
				break;
			case 6L:
				F592_7453(Current);
				break;
			case 8L:
				F592_7469(Current, (EIF_BOOLEAN) 0);
				break;
			case 9L:
				F592_7454(Current);
				break;
			case 50L:
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[4] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,594,0xFF01,1184,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A505_639_2, (EIF_POINTER) _A505_639_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(307,F344_4996, (Current));
				F592_7455(Current, tr4, tr5);
				break;
			case 51L:
				break;
			case 52L:
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[4] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,594,0xFF01,1184,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A505_640_2, (EIF_POINTER) _A505_640_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(308,F344_4998, (Current));
				F592_7455(Current, tr4, tr5);
				break;
			case 53L:
				break;
			case 54L:
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[4] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,594,0xFF01,1184,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A505_641_2, (EIF_POINTER) _A505_641_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(309,F344_5000, (Current));
				F592_7455(Current, tr4, tr5);
				break;
			case 28L:
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					F592_7467(Current, loc1);
				} else {
				}
				break;
			case 27L:
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					F592_7465(Current, loc1);
				} else {
				}
				break;
			case 29L:
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					F592_7466(Current, loc1);
				} else {
				}
				break;
			case 10L:
			case 11L:
			case 12L:
			case 13L:
			case 14L:
			case 15L:
			case 16L:
				F592_7457(Current);
				break;
			case 7L:
				F592_7456(Current);
				break;
			case 17L:
				F592_7458(Current);
				break;
			case 18L:
				F592_7458(Current);
				break;
			case 19L:
				F592_7459(Current);
				break;
			case 20L:
				F592_7461(Current);
				break;
			case 21L:
				F592_7460(Current);
				break;
			case 22L:
				F592_7462(Current);
				break;
			case 23L:
				F592_7463(Current, (EIF_BOOLEAN) 0);
				break;
			case 45L:
				F592_7463(Current, (EIF_BOOLEAN) 1);
				break;
			case 24L:
				F592_7464(Current);
				break;
			case 38L:
				F592_7468(Current);
				break;
			case 39L:
				F592_7469(Current, (EIF_BOOLEAN) 1);
				break;
			case 41L:
				F592_7470(Current);
				break;
			case 40L:
				F592_7471(Current);
				break;
			case 42L:
				F592_7472(Current);
				break;
			case 30L:
				F592_7473(Current);
				break;
			case 31L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7474(Current, loc2);
				} else {
				}
				break;
			case 32L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7475(Current, loc2);
				} else {
				}
				break;
			case 33L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7476(Current, loc2);
				} else {
				}
				break;
			case 46L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7477(Current, loc2);
				} else {
				}
				break;
			case 48L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7478(Current, loc2);
				} else {
				}
				break;
			case 34L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7479(Current, loc2);
				} else {
				}
				break;
			case 35L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7480(Current, loc2);
				} else {
				}
				break;
			case 36L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7481(Current, loc2);
				} else {
				}
				break;
			case 37L:
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F592_7482(Current, loc2);
				} else {
				}
				break;
			case 43L:
				F592_7483(Current);
				break;
			case 44L:
				F592_7507(Current);
				break;
			default:
				if ((EIF_BOOLEAN) (F592_7509(Current) > ((EIF_INTEGER_32) 0L))) {
					F592_7507(Current);
				}
				break;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		F963_8612(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
		F961_8612(RTCW(tr1));
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_end_tag */
void F592_7444 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,arg1);
	RTLR(15,tr4);
	RTLIU(16);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		tb1 = F1168_10025(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			F592_7517(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F1057_8885(RTCW(tr1));
			switch (ti4_1) {
				case 3L:
					F592_7485(Current);
					break;
				case 25L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1170_10130(RTCW(tr1));
					F592_7486(Current);
					break;
				case 26L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1170_10130(RTCW(tr1));
					F592_7487(Current);
					break;
				default:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1170_10130(RTCW(tr1));
					if ((EIF_BOOLEAN) (F592_7509(Current) > ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						tr1 = F1056_8885(RTCW(tr1));
						F1075_9001(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_));
					} else {
						tr1 = RTOUCR(305,F404_5211, (Current));
						tr1 = F1406_14102(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_));
						F424_5542(Current, tr1);
					}
					break;
			}
		}
		tr1 = RTLNSMART(eif_new_type(1172, 1).id);
		F1168_10007(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F1057_8885(RTCW(tr1));
		switch (ti4_1) {
			case 2L:
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL)) {
					tr1 = RTLNS(eif_new_type(585, 0x01).id, 585, _OBJSIZ_2_0_0_3_0_0_0_0_);
					F586_7407(RTCW(tr1));
					F424_5540(Current, tr1);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_7_);
					loc4 = F961_8573(RTCW(tr1));
					for (;;) {
						tb1 = F650_7876(loc4);
						if (tb1) break;
						loc2 = F650_7873(loc4);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_7_);
						loc5 = tr1;
						if (EIF_TEST(loc5)) {
							tb2 = '\01';
							loc6 = loc5;
							loc6 = RTRV(eif_new_type(280, 0x01),loc6);
							if (!((EIF_BOOLEAN) !EIF_TEST(loc6))) {
								tr1 = *(EIF_REFERENCE *)(loc6);
								loc7 = tr1;
								tb2 = (EIF_BOOLEAN) !(EIF_TRUE);
							}
							if (tb2) {
							} else {
								tr1 = F1382_13320(loc3, loc7);
								loc8 = tr1;
								if ((EIF_BOOLEAN) !EIF_TEST(loc8)) {
									tr1 = RTOUCR(305,F404_5211, (Current));
									tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
									tr1 = F1406_14107(RTCW(tr1), loc7, tr2);
									F424_5542(Current, tr1);
								} else {
									tb2 = '\01';
									if (!(EIF_BOOLEAN)(loc2 == loc8)) {
										tb3 = F1192_10917(RTCW(loc2), loc8);
										tb2 = tb3;
									}
									if (tb2) {
										tr1 = RTOUCR(305,F404_5211, (Current));
										tr2 = *(EIF_REFERENCE *)(loc8 + _REFACS_4_);
										tr3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
										tr1 = F1406_14107(RTCW(tr1), tr2, tr3);
										F424_5542(Current, tr1);
									} else {
										F1192_10866(RTCW(loc2), loc8);
									}
								}
							}
						}
						F650_7877(loc4);
					}
				}
				break;
			case 4L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tb2 = '\0';
					tb3 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc10 = tr1;
					if (EIF_TEST(loc10)) {
						tr1 = *(EIF_REFERENCE *)(loc10 + _REFACS_8_);
						tb3 = (EIF_BOOLEAN)(loc9 == tr1);
					}
					if (tb3) {
						tr1 = F1192_10845(loc9);
						tb3 = F870_8129(RTCW(tr1));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						tr1 = RTLNS(eif_new_type(584, 0x01).id, 584, _OBJSIZ_2_0_0_3_0_0_0_0_);
						F585_7406(RTCW(tr1));
						F424_5540(Current, tr1);
					}
					tr1 = *(EIF_REFERENCE *)(loc9 + _REFACS_6_);
					if ((EIF_BOOLEAN)(tr1 == NULL)) {
						if ((EIF_BOOLEAN)(arg1 != NULL)) {
							F592_7488(Current, loc9, arg1);
						} else {
							tr1 = RTOUCR(310,F191_2900, (Current));
							F592_7488(Current, loc9, tr1);
						}
					}
					*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
				}
				break;
			case 7L:
				*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) NULL;
				break;
			case 8L:
				*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
				break;
			case 10L:
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[4] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,1,1113,0xFF01,1170,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A505_562_2, (EIF_POINTER) _A505_562_2, (EIF_POINTER)(F592_7446),tr1, 1, 1);
				}
				F592_7448(Current, tr4);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 12L:
			case 13L:
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[4] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,1,1113,0xFF01,1170,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A505_563_2, (EIF_POINTER) _A505_563_2, (EIF_POINTER)(F592_7447),tr1, 1, 1);
				}
				F592_7448(Current, tr4);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 11L:
			case 14L:
			case 15L:
			case 16L:
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 17L:
				*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
				break;
			case 18L:
				*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
				break;
			case 20L:
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
				break;
			case 21L:
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
				break;
			case 22L:
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) NULL;
				break;
			case 23L:
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
				}
				break;
			case 45L:
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
				}
				break;
			case 24L:
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
				}
				*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) NULL;
				break;
			case 39L:
				*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
				break;
			default:
				if ((EIF_BOOLEAN) (F592_7509(Current) > ((EIF_INTEGER_32) 0L))) {
					if ((EIF_BOOLEAN)(F592_7509(Current) == ((EIF_INTEGER_32) 1L))) {
						F592_7508(Current);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					F1056_8889(RTCW(tr1));
				}
				break;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1057_8889(RTCW(tr1));
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_content */
void F592_7445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		F1173_10254(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.create_external_cflag */
void F592_7446 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F422_5509(RTCW(tr1), arg1, loc2);
		F1192_10893(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = F1406_14187(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.create_external_linker_flag */
void F592_7447 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F422_5513(RTCW(tr1), arg1, loc2);
		F1192_10897(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = F1406_14187(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.split_external */
void F592_7448 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc3);
	RTLR(5,loc7);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,arg1);
	RTLR(9,loc10);
	RTLIU(10);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = RTOUCR(282,F421_5460, (Current));
		tb4 = F423_5526(Current, tr1);
	}
	if (tb4) {
		tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		loc5 = tr1;
		tb3 = (EIF_TRUE);
	}
	if (tb3) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		tb3 = F1171_10171(loc5, tw1);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		tb3 = F1171_10171(loc5, tw1);
		if (!tb3) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
			tb3 = F1171_10171(loc5, tw1);
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc3 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1171_10139(RTCW(loc3), loc5);
		F1173_10236(RTCW(loc3));
		F1173_10237(RTCW(loc3));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5213[Dtype(loc4)-432])(loc4);
		if (tb1) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc2)) {
					tw1 = F1173_10219(RTCW(loc3), loc1);
					tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb2 = F1120_9843(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) break;
				loc1++;
			}
			tr1 = F1173_10299(RTCW(loc3), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			F432_5697(loc4, tr1);
			F1173_10274(RTCW(loc3), loc1);
			F1173_10236(RTCW(loc3));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				loc8 = loc4;
				loc8 = RTRV(eif_new_type(436, 0x01),loc8);
				if (EIF_TEST(loc8)) {
					F1192_10901(loc7, loc8);
				} else {
					loc9 = loc4;
					loc9 = RTRV(eif_new_type(435, 0x01),loc9);
					if (EIF_TEST(loc9)) {
						F1192_10902(loc7, loc9);
					}
				}
			} else {
			}
		}
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		loc10 = tr1;
		if (EIF_TEST(loc10)) {
			tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_1_);
			F432_5698(loc10, tr1);
			tr1 = *(EIF_REFERENCE *)(loc4);
			F432_5700(loc10, tr1);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_redirection_attributes */
void F592_7449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1002L));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		if (F424_5538(Current, loc1)) {
			loc2 = RTLNS(eif_new_type(1186, 0x01).id, 1186, _OBJSIZ_0_0_3_1_0_0_1_0_);
			F1187_10650(RTCW(loc2), loc1);
		} else {
			tr1 = RTLNS(eif_new_type(588, 0x01).id, 588, _OBJSIZ_2_0_0_3_0_0_0_0_);
			F589_7415(RTCW(tr1));
			F424_5540(Current, tr1);
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTOUCR(279,F421_5466, (Current));
			if (F423_5527(Current, tr1)) {
				tb1 = F878_8129(loc4);
				if (tb1) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("location",8,59511406);
					tr1 = F1406_14099(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					loc3 = F422_5496(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), loc4, loc2);
					tb1 = '\0';
					tr1 = RTOUCR(275,F421_5474, (Current));
					if (F423_5527(Current, tr1)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
						tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1066L));
						loc5 = tr1;
						tb1 = EIF_TEST(loc5);
					}
					if (tb1) {
						F1381_13305(RTCW(loc3), loc5);
					}
					RTAR(Current, loc3);
					*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc3;
				}
			} else {
				tr1 = RTMS_EX_H("location",8,59511406);
				F592_7521(Current, tr1);
			}
		} else {
			tr1 = RTOUCR(279,F421_5466, (Current));
			if (F423_5527(Current, tr1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTMS_EX_H("location",8,59511406);
				tr1 = F1406_14101(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_system_attributes */
void F592_7450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc6);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,loc7);
	RTLR(10,tr3);
	RTLR(11,loc8);
	RTLR(12,loc9);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = F1173_10287(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1002L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1003L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = F1173_10287(loc6);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		tr1 = F1406_14103(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			if ((EIF_BOOLEAN) !F259_3591(Current, loc2)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14104(RTCW(tr1), loc1);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					if (F424_5538(Current, loc3)) {
						loc4 = RTLNS(eif_new_type(1186, 0x01).id, 1186, _OBJSIZ_0_0_3_1_0_0_1_0_);
						F1187_10650(RTCW(loc4), loc3);
					} else {
						tr1 = RTLNS(eif_new_type(588, 0x01).id, 588, _OBJSIZ_2_0_0_3_0_0_0_0_);
						F589_7415(RTCW(tr1));
						F424_5540(Current, tr1);
					}
				}
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
					if ((EIF_BOOLEAN)(loc4 == NULL)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc7 = tr3;
						if (EIF_TEST(loc7)) {
							tr3 = loc7;
						} else {
							tr3 = RTOUCR(268,F421_5488, (Current));
						}
						loc5 = F422_5497(RTCW(tr1), tr2, loc2, tr3);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc8 = tr3;
						if (EIF_TEST(loc8)) {
							tr3 = loc8;
						} else {
							tr3 = RTOUCR(268,F421_5488, (Current));
						}
						loc5 = F422_5498(RTCW(tr1), tr2, loc2, loc4, tr3);
					}
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc5;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
					loc9 = tr1;
					if (EIF_TEST(loc9)) {
						tb1 = F1171_10175(loc9);
						if (tb1) {
							tb1 = F1168_10084(loc9);
							F1382_13346(RTCW(loc5), tb1);
						} else {
							tr1 = RTOUCR(305,F404_5211, (Current));
							tr2 = RTMS_EX_H("readonly",8,1382700153);
							tr1 = F1406_14098(RTCW(tr1), tr2);
							F424_5542(Current, tr1);
						}
					}
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14105(RTCW(tr1), loc1);
					F424_5542(Current, tr1);
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_target_attributes */
void F592_7451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,tr2);
	RTLR(7,loc9);
	RTLR(8,loc4);
	RTLR(9,loc3);
	RTLR(10,loc5);
	RTLR(11,loc1);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			if ((EIF_BOOLEAN) !F259_3590(Current, loc7)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14110(RTCW(tr1), loc7);
				F424_5542(Current, tr1);
			}
			tr1 = *(EIF_REFERENCE *)(loc6 + _REFACS_7_);
			tb1 = F961_8566(RTCW(tr1), loc7);
			if (tb1) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14106(RTCW(tr1), loc7);
				F424_5542(Current, tr1);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F422_5499(RTCW(tr1), loc7, loc6);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc2;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1000L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tb1 = F1171_10175(loc8);
				if (tb1) {
					tb1 = F1168_10084(loc8);
					F1192_10915(RTCW(loc2), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(311,F344_5003, (Current));
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tb2 = F1168_10049(loc7, loc9);
				tb1 = tb2;
			}
			if (tb1) {
				F1382_13351(loc6, loc2);
				*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
			}
			F1382_13349(loc6, loc2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			loc4 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1004L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1005L));
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = RTOUCR(273,F421_5478, (Current));
				if (F423_5527(Current, tr1)) {
					tr1 = F1380_13293(loc6);
					tr2 = RTLNS(eif_new_type(1400, 0x01).id, 1400, _OBJSIZ_3_0_0_0_0_0_0_0_);
					F1401_13605(RTCW(tr2), loc4, loc2);
					tr2 = F1399_13589(RTCW(tr2));
					tb1 = F1194_11022(RTCW(tr1), tr2);
					if (tb1) {
						loc4 = (EIF_REFERENCE) NULL;
					} else {
						tr1 = RTLNS(eif_new_type(281, 0x01).id, 281, _OBJSIZ_3_1_0_0_0_0_0_0_);
						F282_3889(RTCW(tr1), loc3, loc4);
						F1192_10868(RTCW(loc2), tr1);
					}
				} else {
					tr1 = RTOUCR(312,F344_5005, (Current));
					F592_7521(Current, tr1);
				}
			}
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_7_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tb1 = (EIF_BOOLEAN)(loc3 != NULL);
			}
			if (tb1) {
				if ((EIF_BOOLEAN)(loc5 == NULL)) {
					loc5 = (EIF_REFERENCE) loc6;
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
				tb1 = F1168_10049(RTCW(loc3), tr1);
				if (tb1) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14107(RTCW(tr1), loc3, loc7);
					F424_5542(Current, tr1);
				} else {
					loc1 = F1382_13320(RTCW(loc5), loc3);
					if ((EIF_BOOLEAN)(loc1 == NULL)) {
						tr1 = RTLNS(eif_new_type(280, 0x01).id, 280, _OBJSIZ_2_0_0_0_0_0_0_0_);
						F281_3882(RTCW(tr1), loc3);
						F1192_10868(RTCW(loc2), tr1);
					} else {
						F1192_10866(RTCW(loc2), loc1);
					}
				}
			}
		} else {
			tr1 = F1406_14109(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	} else {
		F424_5537(Current);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_root_attributes */
void F592_7452 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc1);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,loc8);
	RTLR(8,loc3);
	RTLR(9,loc9);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1008L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb1 = F1171_10175(loc5);
		if (tb1) {
			loc4 = F1168_10084(loc5);
		} else {
			tr1 = F1406_14111(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1006L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		loc1 = F1173_10287(loc6);
		if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
			tr1 = F1406_14113(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc2 = F1173_10287(loc7);
		if ((EIF_BOOLEAN) !F259_3586(Current, loc2)) {
			tr1 = F1406_14114(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1009L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		loc3 = F1173_10287(loc8);
		if ((EIF_BOOLEAN) !F259_3605(Current, loc3)) {
			tr1 = F1406_14115(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc9 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 && (EIF_BOOLEAN)(loc1 == NULL)) && (EIF_BOOLEAN)(loc2 == NULL)) && (EIF_BOOLEAN)(loc3 == NULL)) || (EIF_BOOLEAN)(loc2 != NULL)) && EIF_TEST(loc9))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F422_5503(RTCW(tr1), loc1, loc2, loc3, loc4);
		F1192_10881(loc9, tr1);
	} else {
		tr1 = F1406_14112(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_version_attributes */
void F592_7453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_16 loc1 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc2 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc3 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc4 = (EIF_NATURAL_16) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc8);
	RTLR(5,loc9);
	RTLR(6,loc5);
	RTLR(7,loc10);
	RTLR(8,loc11);
	RTLR(9,loc12);
	RTLR(10,loc13);
	RTLR(11,loc14);
	RTLIU(12);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1012L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tb2 = F1168_10042(loc6);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = F1168_10076(loc6);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1013L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tb2 = F1168_10042(loc7);
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = F1168_10076(loc7);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1014L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tb2 = F1168_10042(loc8);
		tb1 = tb2;
	}
	if (tb1) {
		loc3 = F1168_10076(loc8);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1015L));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		tb2 = F1168_10042(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		loc4 = F1168_10076(loc9);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = F422_5504(RTCW(tr1), loc1, loc2, loc3, loc4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1016L));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1354_12636(RTCW(loc5), loc10);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1017L));
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1354_12635(RTCW(loc5), loc11);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1018L));
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		F1354_12638(RTCW(loc5), loc12);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1019L));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		F1354_12637(RTCW(loc5), loc13);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		F1192_10871(loc14, loc5);
	} else {
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_setting_attributes */
void F592_7454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		tr1 = F1406_14116(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		loc2 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc2)) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14118(RTCW(tr1), loc1);
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) !F426_5564(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14117(RTCW(tr1), loc1);
				F424_5542(Current, tr1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				loc3 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
				} else {
					tr1 = F1168_10066(RTCV(RTOUCR(313,F344_4958, (Current))));
					tb1 = F1171_10164(loc1, tr1);
					if (tb1) {
						tr1 = RTOUCR(285,F421_5454, (Current));
						if (F423_5526(Current, tr1)) {
							tb1 = F1171_10175(loc2);
							if (tb1) {
								tb1 = F1168_10084(loc2);
								if (tb1) {
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 1U));
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 1U));
								} else {
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 2U));
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 2U));
								}
							} else {
								tr1 = RTOUCR(305,F404_5211, (Current));
								tr1 = F1406_14118(RTCW(tr1), loc1);
								F424_5542(Current, tr1);
							}
						} else {
							tr1 = RTOUCR(305,F404_5211, (Current));
							tr1 = F1406_14117(RTCW(tr1), loc1);
							F424_5542(Current, tr1);
						}
					} else {
						tr1 = F1168_10066(RTCV(RTOUCR(314,F344_4931, (Current))));
						tb1 = F1171_10164(loc1, tr1);
						if (tb1) {
							tb1 = '\0';
							tr1 = RTOUCR(284,F421_5456, (Current));
							if (F423_5527(Current, tr1)) {
								tr1 = RTOUCR(276,F421_5472, (Current));
								tb1 = F423_5526(Current, tr1);
							}
							if (tb1) {
								tr1 = F428_5645(loc3);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
								tb1 = F1185_10612(RTCW(tr1), loc2);
								if (tb1) {
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1186_10644(RTCW(tr1), loc2);
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1185_10624(RTCW(tr1), loc2);
								} else {
									tr1 = RTOUCR(305,F404_5211, (Current));
									tr1 = F1406_14118(RTCW(tr1), loc1);
									F424_5542(Current, tr1);
								}
							} else {
								tr1 = RTOUCR(305,F404_5211, (Current));
								tr1 = F1406_14117(RTCW(tr1), loc1);
								F424_5542(Current, tr1);
							}
						} else {
							tr1 = F1168_10066(RTCV(RTOUCR(315,F344_4948, (Current))));
							tb1 = F1171_10164(loc1, tr1);
							if (tb1) {
								tr1 = F428_5645(loc3);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_16_);
								tb1 = F1186_10631(RTCW(tr1), loc2);
								if (tb1) {
									tr1 = F428_5645(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_16_);
									F1186_10644(RTCW(tr1), loc2);
								} else {
									tr1 = RTOUCR(305,F404_5211, (Current));
									tr1 = F1406_14118(RTCW(tr1), loc1);
									F424_5542(Current, tr1);
								}
							} else {
								tr1 = F1168_10066(RTCV(RTOUCR(316,F344_4934, (Current))));
								tb1 = F1171_10164(loc1, tr1);
								if (tb1) {
									tr1 = RTOUCR(272,F421_5480, (Current));
									if (F423_5526(Current, tr1)) {
										tb1 = F1171_10175(loc2);
										if (tb1) {
											tr1 = F428_5645(loc3);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
											tb1 = F1168_10084(loc2);
											if (tb1) {
												tu1_1 = ((EIF_NATURAL_8) 2U);
											} else {
												tu1_1 = ((EIF_NATURAL_8) 1U);
											}
											F1186_10643(RTCW(tr1), tu1_1);
										} else {
											tr1 = RTOUCR(305,F404_5211, (Current));
											tr1 = F1406_14118(RTCW(tr1), loc1);
											F424_5542(Current, tr1);
										}
									} else {
										tr1 = F428_5645(loc3);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
										tb1 = F1186_10631(RTCW(tr1), loc2);
										if (tb1) {
											tr1 = F428_5645(loc3);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
											F1186_10644(RTCW(tr1), loc2);
										} else {
											tr1 = RTOUCR(305,F404_5211, (Current));
											tr1 = F1406_14118(RTCW(tr1), loc1);
											F424_5542(Current, tr1);
										}
									}
								} else {
									F428_5641(loc3, loc1, loc2);
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_ordered_capability */
void F592_7455 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTOUCR(275,F421_5474, (Current));
	if (F423_5527(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,594,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		tr2 = F428_5645(loc2);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		loc1 = F1164_9998(RTCW(arg1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1067L));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tb1 = F1185_10612(RTCW(loc1), loc3);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				F1186_10644(RTCW(tr1), loc3);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(317,F344_5001, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1068L));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tb1 = F1185_10612(RTCW(loc1), loc4);
			if (tb1) {
				F1185_10624(RTCW(loc1), loc4);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(318,F344_5002, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	} else {
		tr1 = RTOUCR(305,F404_5211, (Current));
		tr1 = F1406_14097(RTCW(tr1), arg2);
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_file_rule_attributes */
void F592_7456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = F422_5507(RTCW(tr1));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1249_11281(loc2, loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1192_10884(loc3, loc1);
		} else {
			tr1 = F1406_14119(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_external_attributes */
void F592_7457 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc7 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && EIF_TEST(loc7))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F1057_8885(RTCW(tr1));
		switch (ti4_1) {
			case 10L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc2 = F422_5508(RTCW(tr1), loc1, loc7);
				F1192_10892(loc7, loc2);
				RTAR(Current, loc2);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
				break;
			case 11L:
				F592_7446(Current, loc1);
				break;
			case 12L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F422_5510(RTCW(tr1), loc1, loc7);
				F1192_10894(loc7, loc3);
				RTAR(Current, loc3);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc3;
				break;
			case 13L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F422_5511(RTCW(tr1), loc1, loc7);
				F1192_10895(loc7, loc4);
				RTAR(Current, loc4);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc4;
				break;
			case 14L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc5 = F422_5512(RTCW(tr1), loc1, loc7);
				F1192_10896(loc7, loc5);
				RTAR(Current, loc5);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc5;
				break;
			case 15L:
				F592_7447(Current, loc1);
				break;
			case 16L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc6 = F422_5514(RTCW(tr1), loc1, loc7);
				F1192_10898(loc7, loc6);
				RTAR(Current, loc6);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc6;
				break;
			default:
				tr1 = F1406_14120(RTCV(RTOUCR(305,F404_5211, (Current))));
				F424_5542(Current, tr1);
				break;
		}
	} else {
		tr1 = F1406_14120(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_action_attributes */
void F592_7458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1050L));
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTMS32_EX_H("f\000\000\000a\000\000\000l\000\000\000s\000\000\000e\000\000\000",5,1635280741);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1026L));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		tb1 = F1171_10175(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1051L));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb1 = F1168_10084(RTCW(loc1));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr2 = F422_5500(RTCW(tr2), loc5, loc4);
				loc2 = F422_5515(RTCW(tr1), loc3, tb1, tr2);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb1 = F1168_10084(RTCW(loc1));
				loc2 = F422_5515(RTCW(tr1), loc3, tb1, NULL);
			}
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc2;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F1057_8885(RTCW(tr1));
			switch (ti4_1) {
				case 17L:
					F1192_10908(loc4, loc2);
					break;
				case 18L:
					F1192_10909(loc4, loc2);
					break;
				default:
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14121(RTCW(tr1), loc3);
					F424_5542(Current, tr1);
					break;
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14122(RTCW(tr1), loc3);
			F424_5542(Current, tr1);
		}
	} else {
		tr1 = F1406_14123(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_variable_attributes */
void F592_7459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTMS32_EX_H("",0,0);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1192_10911(loc3, loc2, loc1);
		} else {
		}
	} else {
		tr1 = F1406_14124(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_library_attributes */
void F592_7460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = F1173_10287(loc4);
		tb1 = '\0';
		tb2 = '\0';
		if (F259_3588(Current, loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc6 = tr1;
			tb1 = EIF_TEST(loc6);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F422_5519(RTCW(tr1), loc1, loc5, loc6);
			loc3 = (EIF_REFERENCE) loc2;
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) loc2;
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tb1 = F1171_10175(loc7);
				if (tb1) {
					tb1 = F1168_10084(loc7);
					F1246_11218(RTCW(loc2), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1057L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tb1 = F1171_10175(loc8);
				if (tb1) {
					tb1 = F1168_10084(loc8);
					F1254_11353(RTCW(loc2), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("use_application_options",23,923843187);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				F1252_11309(RTCW(loc2), loc9);
			}
			F1192_10873(loc6, loc2);
		} else {
			if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14127(RTCW(tr1), loc4);
				F424_5542(Current, tr1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14128(RTCW(tr1), loc4);
				F424_5542(Current, tr1);
			}
		}
	} else {
		tr1 = F1406_14126(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_precompile_attributes */
void F592_7461 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc6);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLIU(13);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		loc1 = F1173_10287(loc4);
		tb1 = '\0';
		tb2 = '\0';
		if (F259_3588(Current, loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
			loc6 = tr1;
			tb2 = EIF_TEST(loc6);
		}
		if (tb2) {
			tr1 = F1192_10841(loc5);
			tb1 = (EIF_BOOLEAN)(tr1 == NULL);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F422_5520(RTCW(tr1), loc1, loc6, loc5);
			loc3 = (EIF_REFERENCE) loc2;
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) loc2;
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tb1 = F1171_10175(loc7);
				if (tb1) {
					tb1 = F1168_10084(loc7);
					F1246_11218(RTCW(loc2), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F1252_11309(RTCW(loc2), loc8);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1053L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr1 = F422_5500(RTCW(tr1), loc9, loc5);
				F1255_11361(RTCW(loc2), tr1);
			}
			F1192_10872(loc5, loc2);
		} else {
			if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14131(RTCW(tr1), loc4);
				F424_5542(Current, tr1);
			} else {
				tr1 = F1192_10841(loc5);
				loc10 = tr1;
				if (EIF_TEST(loc10)) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = *(EIF_REFERENCE *)(loc10 + _REFACS_5_);
					tr1 = F1406_14134(RTCW(tr1), loc4, tr2);
					F424_5542(Current, tr1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14132(RTCW(tr1), loc4);
					F424_5542(Current, tr1);
				}
			}
		}
	} else {
		tr1 = F1406_14130(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_assembly_attributes */
void F592_7462 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc9);
	RTLR(9,loc10);
	RTLR(10,loc3);
	RTLR(11,loc4);
	RTLR(12,loc11);
	RTLR(13,tr2);
	RTLR(14,loc12);
	RTLIU(15);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc1 = F1173_10287(loc5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		tb1 = '\0';
		tb2 = '\0';
		if (F259_3588(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc6 = tr1;
			tb1 = EIF_TEST(loc6);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb2 = F1168_10052(RTCW(loc2), tr1);
			if (tb2) {
				tb2 = '\0';
				tb3 = '\0';
				tb4 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
				tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1032L));
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1033L));
					loc8 = tr1;
					tb4 = EIF_TEST(loc8);
				}
				if (tb4) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1034L));
					loc9 = tr1;
					tb3 = EIF_TEST(loc9);
				}
				if (tb3) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1035L));
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F422_5518(RTCW(tr1), loc1, loc7, loc8, loc9, loc10, loc6);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F422_5517(RTCW(tr1), loc1, loc2, loc6);
			}
			loc4 = (EIF_REFERENCE) loc3;
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) loc3;
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc4;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				tb1 = F1171_10175(loc11);
				if (tb1) {
					tb1 = F1168_10084(loc11);
					F1246_11218(RTCW(loc3), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				F1252_11309(RTCW(loc3), loc12);
			}
			F1192_10874(loc6, loc3);
		} else {
			if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14136(RTCW(tr1), loc5);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc2 == NULL)) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14137(RTCW(tr1), loc5);
					F424_5542(Current, tr1);
				} else {
				}
			}
		}
	} else {
		tr1 = F1406_14135(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_cluster_attributes */
void F592_7463 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,loc3);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,loc9);
	RTLR(11,tr2);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc1 = F1173_10287(loc7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		tb1 = '\0';
		tb2 = '\0';
		if (F259_3588(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc8 = tr1;
			tb1 = EIF_TEST(loc8);
		}
		if (tb1) {
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc6 = F422_5500(RTCW(tr1), loc2, loc8);
			if (arg1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F422_5522(RTCW(tr1), loc1, loc6, loc8);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F422_5521(RTCW(tr1), loc1, loc6, loc8);
			}
			loc5 = (EIF_REFERENCE) loc4;
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc4;
			RTAR(Current, loc5);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc5;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tb1 = F1171_10175(loc9);
				if (tb1) {
					tb1 = F1168_10084(loc9);
					F1246_11218(RTCW(loc4), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1055L));
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				tb1 = F1171_10175(loc10);
				if (tb1) {
					tb1 = F1168_10084(loc10);
					F1249_11276(RTCW(loc4), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("hidden",6,1889579886);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1036L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				tb1 = F1171_10175(loc11);
				if (tb1) {
					tb1 = F1168_10084(loc11);
					F1249_11275(RTCW(loc4), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("recursive",9,760839013);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				F1249_11273(RTCW(loc3), loc4);
				F1249_11272(RTCW(loc4), loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_7_);
				F1399_13595(RTCW(loc6), tr1);
			}
			F1192_10875(loc8, loc4);
		} else {
			if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14140(RTCW(tr1), loc7);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14142(RTCW(tr1), loc7);
					F424_5542(Current, tr1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14141(RTCW(tr1), loc7);
					F424_5542(Current, tr1);
				}
			}
		}
	} else {
		tr1 = F1406_14139(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_override_attributes */
void F592_7464 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,loc5);
	RTLR(10,loc6);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc1 = F1173_10287(loc7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		tb1 = '\0';
		tb2 = '\0';
		if (F259_3588(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc8 = tr1;
			tb1 = EIF_TEST(loc8);
		}
		if (tb1) {
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr2 = F422_5500(RTCW(tr2), loc2, loc8);
			loc4 = F422_5523(RTCW(tr1), loc1, tr2, loc8);
			loc5 = (EIF_REFERENCE) loc4;
			loc6 = (EIF_REFERENCE) loc4;
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc4;
			RTAR(Current, loc5);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc5;
			RTAR(Current, loc6);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc6;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tb1 = F1171_10175(loc9);
				if (tb1) {
					tb1 = F1168_10084(loc9);
					F1246_11218(RTCW(loc5), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1055L));
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				tb1 = F1171_10175(loc10);
				if (tb1) {
					tb1 = F1168_10084(loc10);
					F1249_11276(RTCW(loc5), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("hidden",6,1889579886);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1036L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				tb1 = F1171_10175(loc11);
				if (tb1) {
					tb1 = F1168_10084(loc11);
					F1249_11275(RTCW(loc5), tb1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("recursive",9,760839013);
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				F1249_11273(RTCW(loc3), loc5);
				F1249_11272(RTCW(loc5), loc3);
			}
			F1192_10876(loc8, loc4);
		} else {
			if ((EIF_BOOLEAN) !F259_3588(Current, loc1)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14144(RTCW(tr1), loc7);
				F424_5542(Current, tr1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14145(RTCW(tr1), loc7);
				F424_5542(Current, tr1);
			}
		}
	} else {
		tr1 = F1406_14143(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_debug_attributes */
void F592_7465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = F1173_10287(loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1037L));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tb1 = F1171_10175(loc3);
			if (tb1) {
				tb1 = F1168_10084(loc3);
				F594_7640(RTCW(arg1), loc1, tb1);
			} else {
				tb1 = F1171_10175(loc3);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(319,F274_3792, (Current));
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				}
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14148(RTCW(tr1), loc2);
			F424_5542(Current, tr1);
		}
	} else {
		tr1 = F1406_14147(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_warning_attributes */
void F592_7466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc2)) {
		tr1 = F1406_14149(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tb1 = '\0';
		tr1 = RTOUCR(270,F421_5484, (Current));
		if (F423_5527(Current, tr1)) {
			tr1 = RTOUCR(320,F344_4910, (Current));
			tb2 = F1168_10049(loc2, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
				tb2 = F1186_10631(RTCW(tr1), loc3);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
				F1186_10644(RTCW(tr1), loc3);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14150(RTCW(tr1), loc2);
				F424_5542(Current, tr1);
			}
		} else {
			loc1 = F1173_10287(loc2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1037L));
			loc4 = tr1;
			if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14150(RTCW(tr1), loc2);
				F424_5542(Current, tr1);
			} else {
				tb1 = F1171_10175(loc4);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(319,F274_3792, (Current));
					tr1 = F1406_14098(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				} else {
					if (F426_5559(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
						tr1 = RTOUCR(320,F344_4910, (Current));
						tb1 = F1168_10049(loc2, tr1);
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
							tb1 = F1168_10084(loc4);
							if (tb1) {
								tu1_1 = ((EIF_NATURAL_8) 2U);
							} else {
								tu1_1 = ((EIF_NATURAL_8) 1U);
							}
							F1186_10643(RTCW(tr1), tu1_1);
						} else {
							tb1 = F1168_10084(loc4);
							F594_7624(RTCW(arg1), loc1, tb1);
						}
					} else {
						tr1 = RTOUCR(305,F404_5211, (Current));
						tr1 = F1406_14150(RTCW(tr1), loc2);
						F424_5542(Current, tr1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_assertions_attributes */
void F592_7467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,arg1);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = F422_5516(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1038L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb1 = F1171_10175(loc2);
		if (tb1) {
			tb1 = F1168_10084(loc2);
			if (tb1) {
				F61_1268(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("precondition",12,694692206);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1039L));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb1 = F1171_10175(loc3);
		if (tb1) {
			tb1 = F1168_10084(loc3);
			if (tb1) {
				F61_1270(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("postcondition",13,29888366);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1040L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb1 = F1171_10175(loc4);
		if (tb1) {
			tb1 = F1168_10084(loc4);
			if (tb1) {
				F61_1271(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("check",5,1752235371);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1041L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb1 = F1171_10175(loc5);
		if (tb1) {
			tb1 = F1168_10084(loc5);
			if (tb1) {
				F61_1272(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("invariant",9,997544820);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1042L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tb1 = F1171_10175(loc6);
		if (tb1) {
			tb1 = F1168_10084(loc6);
			if (tb1) {
				F61_1273(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("loop",4,1819242352);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1043L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tb1 = F1171_10175(loc7);
		if (tb1) {
			tb1 = F1168_10084(loc7);
			if (tb1) {
				F61_1269(RTCW(loc1));
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("supplier_precondition",21,1130264430);
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	F594_7639(RTCW(arg1), loc1);
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_renaming_attributes */
void F592_7468 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1047L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1048L));
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1251, 0x01),loc3);
		if (EIF_TEST(loc3)) {
			tr1 = F1173_10288(RTCW(loc1));
			tr2 = F1173_10288(RTCW(loc2));
			F1252_11311(loc3, tr1, tr2);
		} else {
		}
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14152(RTCW(tr1), loc1);
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14153(RTCW(tr1), loc2);
				F424_5542(Current, tr1);
			} else {
				tr1 = F1406_14151(RTCV(RTOUCR(305,F404_5211, (Current))));
				F424_5542(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_option_attributes */
void F592_7469 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(30);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc12);
	RTLR(15,loc13);
	RTLR(16,loc14);
	RTLR(17,loc15);
	RTLR(18,loc16);
	RTLR(19,loc17);
	RTLR(20,loc18);
	RTLR(21,loc19);
	RTLR(22,loc20);
	RTLR(23,loc21);
	RTLR(24,loc22);
	RTLR(25,loc23);
	RTLR(26,loc24);
	RTLR(27,loc25);
	RTLR(28,loc26);
	RTLR(29,loc27);
	RTLIU(30);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc3 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN) !EIF_TEST(loc3)) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr2;
		if (EIF_TEST(loc4)) {
			tr2 = loc4;
		} else {
			tr2 = RTOUCR(268,F421_5488, (Current));
		}
		tr2 = F1168_10066(RTCV(tr2));
		loc2 = F422_5506(RTCW(tr1), tr2);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = tr2;
		if (EIF_TEST(loc5)) {
			tr2 = loc5;
		} else {
			tr2 = RTOUCR(268,F421_5488, (Current));
		}
		tr2 = F1168_10066(RTCV(tr2));
		loc1 = F422_5505(RTCW(tr1), tr2);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1020L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tb1 = F1171_10175(loc6);
		if (tb1) {
			tb1 = F1168_10084(loc6);
			F594_7643(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(321,F344_4988, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1021L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tb1 = F1171_10175(loc7);
		if (tb1) {
			tb1 = F1168_10084(loc7);
			F594_7642(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(322,F344_4987, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1022L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tb1 = F1171_10175(loc8);
		if (tb1) {
			tb1 = F1168_10084(loc8);
			F594_7644(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(323,F344_4986, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1023L));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		tb1 = F1171_10175(loc9);
		if (tb1) {
			tb1 = F1168_10084(loc9);
			F594_7645(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(324,F344_4981, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1054L));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		tr1 = RTOUCR(270,F421_5484, (Current));
		if (F423_5527(Current, tr1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
			tb1 = F1186_10631(RTCW(tr1), loc10);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
				F1186_10644(RTCW(tr1), loc10);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(325,F344_4989, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tb1 = F1171_10175(loc10);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
				tb1 = F1168_10084(loc10);
				if (tb1) {
					tu1_1 = ((EIF_NATURAL_8) 2U);
				} else {
					tu1_1 = ((EIF_NATURAL_8) 1U);
				}
				F1186_10643(RTCW(tr1), tu1_1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(325,F344_4989, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1056L));
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		tb2 = F1171_10175(loc11);
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = F1168_10084(loc11);
		F594_7646(RTCW(loc1), tb1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1024L));
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		F594_7641(RTCW(loc1), loc12);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1058L));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		tb1 = F1171_10175(loc13);
		if (tb1) {
			tb1 = F1168_10084(loc13);
			F594_7647(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(326,F344_4982, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1059L));
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		tr1 = RTOUCR(277,F421_5470, (Current));
		if (F423_5527(Current, tr1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_9_);
			tb1 = F1186_10631(RTCW(tr1), loc14);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					F1186_10644(RTCW(tr1), loc14);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
					F1185_10624(RTCW(tr1), loc14);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(327,F344_4977, (Current));
					tr1 = F1406_14100(RTCW(tr1), tr2);
					F424_5543(Current, tr1);
				}
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(327,F344_4977, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tb1 = F1171_10175(loc14);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tb1 = F1168_10084(loc14);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
						F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 3U));
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 3U));
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
						F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 1U));
					}
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(327,F344_4977, (Current));
					tr1 = F1406_14100(RTCW(tr1), tr2);
					F424_5543(Current, tr1);
				}
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(327,F344_4977, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1060L));
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		tb1 = F1171_10175(loc15);
		if (tb1) {
			tb1 = F1168_10084(loc15);
			F594_7648(RTCW(loc1), tb1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTOUCR(328,F344_4980, (Current));
			tr1 = F1406_14098(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1071L));
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		tr1 = RTOUCR(269,F421_5486, (Current));
		if ((EIF_BOOLEAN) !F423_5527(Current, tr1)) {
			tr1 = RTOUCR(329,F344_4984, (Current));
			F592_7521(Current, tr1);
		} else {
			tb1 = F1171_10175(loc16);
			if (tb1) {
				tb1 = F1168_10084(loc16);
				F594_7649(RTCW(loc1), tb1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14098(RTCW(tr1), loc16);
				F424_5542(Current, tr1);
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1061L));
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		tr1 = RTOUCR(276,F421_5472, (Current));
		if ((EIF_BOOLEAN) !F423_5527(Current, tr1)) {
			tr1 = RTOUCR(330,F344_4985, (Current));
			F592_7521(Current, tr1);
		} else {
			tb1 = F1171_10175(loc17);
			if (tb1) {
				tb1 = F1168_10084(loc17);
				F594_7650(RTCW(loc1), tb1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(330,F344_4985, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1063L));
	loc18 = tr1;
	if (EIF_TEST(loc18)) {
		tr1 = RTOUCR(286,F421_5452, (Current));
		if (F423_5527(Current, tr1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
			tb1 = F1186_10631(RTCW(tr1), loc18);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					F1186_10644(RTCW(tr1), loc18);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
					F1185_10624(RTCW(tr1), loc18);
					tr1 = RTOUCR(281,F421_5462, (Current));
					if (F423_5526(Current, tr1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
						tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
						switch (tu1_1) {
							case 1U:
							case 3U:
								break;
							case 5U:
								if ((EIF_BOOLEAN)(loc2 != NULL)) {
									tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 4U));
									tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
									F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 4U));
								}
								break;
							default:
								tr1 = RTOUCR(305,F404_5211, (Current));
								tr2 = RTOUCR(331,F344_4993, (Current));
								tr1 = F1406_14098(RTCW(tr1), tr2);
								F424_5542(Current, tr1);
								break;
						}
					}
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTOUCR(331,F344_4993, (Current));
					tr1 = F1406_14100(RTCW(tr1), tr2);
					F424_5543(Current, tr1);
				}
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(331,F344_4993, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tr1 = RTOUCR(331,F344_4993, (Current));
			F592_7521(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1062L));
	loc19 = tr1;
	if (EIF_TEST(loc19)) {
		tb1 = '\01';
		tr1 = RTOUCR(287,F421_5450, (Current));
		if (!F423_5526(Current, tr1)) {
			tb2 = '\0';
			tr1 = RTOUCR(282,F421_5460, (Current));
			if (F423_5527(Current, tr1)) {
				tr1 = RTOUCR(281,F421_5462, (Current));
				tb2 = F423_5526(Current, tr1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			tb1 = F1171_10175(loc19);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = RTOUCR(287,F421_5450, (Current));
					if (F423_5526(Current, tr1)) {
						tb1 = F1168_10084(loc19);
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 4U));
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 4U));
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 1U));
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						}
					} else {
						tb1 = F1168_10084(loc19);
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 5U));
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1185_10625(RTCW(tr1), ((EIF_NATURAL_8) 5U));
						}
					}
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = RTMS_EX_H("is_void_safe",12,1531546981);
					tr1 = F1406_14100(RTCW(tr1), tr2);
					F424_5543(Current, tr1);
				}
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTMS_EX_H("is_void_safe",12,1531546981);
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tr1 = RTMS_EX_H("is_void_safe",12,1531546981);
			F592_7521(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1064L));
	loc20 = tr1;
	if (EIF_TEST(loc20)) {
		tr1 = RTOUCR(287,F421_5450, (Current));
		if (F423_5526(Current, tr1)) {
			tb1 = F1168_10041(loc20);
			if (tb1) {
				tu1_1 = F1168_10075(loc20);
				switch (tu1_1) {
					case 0U:
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						break;
					case 1U:
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 2U));
						break;
					case 2U:
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1186_10643(RTCW(tr1), ((EIF_NATURAL_8) 3U));
						break;
					default:
						tr1 = RTOUCR(305,F404_5211, (Current));
						tr2 = RTMS_EX_H("syntax_level",12,1690338668);
						tr1 = F1406_14098(RTCW(tr1), tr2);
						F424_5542(Current, tr1);
						break;
				}
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTMS_EX_H("syntax_level",12,1690338668);
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tr1 = RTMS_EX_H("syntax_level",12,1690338668);
			F592_7521(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1065L));
	loc21 = tr1;
	if (EIF_TEST(loc21)) {
		tr1 = RTOUCR(286,F421_5452, (Current));
		if (F423_5527(Current, tr1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			tb1 = F1186_10631(RTCW(tr1), loc21);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
				F1186_10644(RTCW(tr1), loc21);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(332,F344_4992, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		} else {
			tr1 = RTOUCR(332,F344_4992, (Current));
			F592_7521(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1070L));
	loc22 = tr1;
	if (EIF_TEST(loc22)) {
		tr1 = RTOUCR(273,F421_5478, (Current));
		if ((EIF_BOOLEAN) !F423_5527(Current, tr1)) {
			tr1 = RTOUCR(333,F344_4990, (Current));
			F592_7521(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			tb1 = F1186_10631(RTCW(tr1), loc22);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
				F1186_10644(RTCW(tr1), loc22);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTOUCR(333,F344_4990, (Current));
				tr1 = F1406_14098(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			}
		}
	}
	if (arg1) {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
		loc23 = tr1;
		if (EIF_TEST(loc23)) {
			tb2 = F259_3587(Current, loc23);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
			loc24 = tr1;
			tb1 = EIF_TEST(loc24);
		}
		if (tb1) {
			tr1 = F1173_10288(loc23);
			F1246_11223(loc24, loc1, tr1);
		} else {
			tr1 = F1406_14154(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc25 = tr1;
		if (EIF_TEST(loc25)) {
			F1246_11221(loc25, loc1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc26 = tr1;
			if (EIF_TEST(loc26)) {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					F428_5639(loc26, loc2);
				} else {
				}
			} else {
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc27 = tr1;
	loc27 = RTRV(eif_new_type(1253, 0x01),loc27);
	if (EIF_TEST(loc27)) {
		F592_7490(Current);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_visible_attributes */
void F592_7470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc7);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLR(8,loc5);
	RTLR(9,loc9);
	RTLR(10,loc6);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tr1 = F1173_10287(RTCW(loc3));
		loc3 = (EIF_REFERENCE) tr1;
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb1 = F259_3587(Current, loc3);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1009L));
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			loc4 = F1173_10287(loc7);
			if ((EIF_BOOLEAN) !F259_3605(Current, loc4)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14157(RTCW(tr1), loc4);
				F424_5542(Current, tr1);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1010L));
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			loc5 = F1173_10287(loc8);
			if ((EIF_BOOLEAN) !F259_3587(Current, loc5)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14158(RTCW(tr1), loc5);
				F424_5542(Current, tr1);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1011L));
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			loc6 = F1173_10287(loc9);
			if ((EIF_BOOLEAN) !F259_3605(Current, loc6)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14157(RTCW(tr1), loc6);
				F424_5542(Current, tr1);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F596_7696(RTCW(loc1), loc3, loc4, loc5, loc6);
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				F596_7696(RTCW(loc2), loc3, loc4, loc5, loc6);
			} else {
			}
		}
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			tr1 = F1406_14156(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_5_);
				tr1 = F1406_14156(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			} else {
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_uses_attributes */
void F592_7471 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1049L));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F259_3588(Current, loc2);
		}
		if (tb1) {
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb1 = F1168_10052(loc2, tr1);
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1350,0xFF01,1245,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					tr1 = RTLNS(typres0.id, 1350, _OBJSIZ_4_1_0_5_0_0_0_0_);
				}
				F1351_12546(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				F1249_11277(loc1, tr1);
			} else {
				F1249_11279(loc1, loc2);
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
			tr1 = F1406_14159(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	} else {
		F424_5537(Current);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_overrides_attributes */
void F592_7472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1049L));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F259_3588(Current, loc2);
		}
		if (tb1) {
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb1 = F1168_10052(loc2, tr1);
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1245,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					tr1 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
				}
				F1059_8908(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				F1250_11298(loc1, tr1);
			} else {
				F1250_11300(loc1, loc2);
			}
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
			tr1 = F1406_14160(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		}
	} else {
		F424_5537(Current);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_condition_attributes */
void F592_7473 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_new_type(1406, 0).id);
		F1407_14202(RTCW(loc1), loc2);
	} else {
		loc1 = RTLNSMART(eif_new_type(1406, 0).id);
		F1407_14201(RTCW(loc1));
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) loc1;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F429_5651(loc3, loc1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				F432_5699(loc4, loc1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					F429_5651(loc5, loc1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						F1246_11224(loc6, loc1);
					} else {
						tr1 = F1406_14161(RTCV(RTOUCR(305,F404_5211, (Current))));
						F424_5542(Current, tr1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_platform_attributes */
void F592_7474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F1406_14162(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
			tr1 = F1406_14163(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
				tr1 = F1406_14164(RTCV(RTOUCR(305,F404_5211, (Current))));
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1168_10085(RTCW(loc1), tw1);
				} else {
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1168_10085(RTCW(loc2), tw1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc4))-867])(loc4);
		for (;;) {
			tb1 = '\01';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc4))-867])(loc4);
			if (!tb2) {
				tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
			}
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
			loc3 = F426_5572(Current, tr1);
			if ((EIF_BOOLEAN) !F426_5554(Current, loc3)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
				tr1 = F1406_14165(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			} else {
				if (loc5) {
					F1407_14217(RTCW(arg1), loc3);
				} else {
					F1407_14216(RTCW(arg1), loc3);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_build_attributes */
void F592_7475 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F1406_14166(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
			tr1 = F1406_14167(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
				tr1 = F1406_14168(RTCV(RTOUCR(305,F404_5211, (Current))));
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1168_10085(RTCW(loc1), tw1);
				} else {
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1168_10085(RTCW(loc2), tw1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc4))-867])(loc4);
		for (;;) {
			tb1 = '\01';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc4))-867])(loc4);
			if (!tb2) {
				tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
			}
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
			loc3 = F426_5573(Current, tr1);
			if ((EIF_BOOLEAN) !F426_5555(Current, loc3)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
				tr1 = F1406_14169(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			} else {
				if (loc5) {
					F1407_14220(RTCW(arg1), loc3);
				} else {
					F1407_14219(RTCW(arg1), loc3);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_multithreaded_attributes */
void F592_7476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(284,F421_5456, (Current));
	if (F423_5526(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == NULL)) {
			tb2 = F1171_10175(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = F1406_14170(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		} else {
			tb1 = F1168_10084(RTCW(loc1));
			if (tb1) {
				F1407_14223(RTCW(arg1), ((EIF_INTEGER_32) 2048L));
			} else {
				F1407_14222(RTCW(arg1), ((EIF_INTEGER_32) 2048L));
			}
		}
	} else {
		tr1 = F1406_14161(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_concurrency_attributes */
void F592_7477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = RTOUCR(283,F421_5458, (Current));
	if (F423_5527(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL))) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("(undefined)",11,959041577);
			tr1 = F1406_14171(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL))) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTMS_EX_H("(Cannot include and exclude at the same time)",45,1282171433);
				tr1 = F1406_14171(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1168_10085(RTCW(loc2), tw1);
				} else {
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1168_10085(RTCW(loc3), tw1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
					}
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc4))-867])(loc4);
			for (;;) {
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc4))-867])(loc4);
				if (!tb2) {
					tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
				}
				if (tb1) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
				loc6 = F426_5574(Current, tr1);
				if ((EIF_BOOLEAN) !F426_5556(Current, loc6)) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
					tr1 = F1406_14171(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				} else {
					if (loc5) {
						F1407_14223(RTCW(arg1), loc6);
					} else {
						F1407_14222(RTCW(arg1), loc6);
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
			}
		}
	} else {
		tr1 = F1406_14161(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_void_safety_attributes */
void F592_7478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = RTOUCR(272,F421_5480, (Current));
	if (F423_5527(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL))) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = RTMS_EX_H("(undefined)",11,959041577);
			tr1 = F1406_14172(RTCW(tr1), tr2);
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL))) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = RTMS_EX_H("(Cannot include and exclude at the same time)",45,1282171433);
				tr1 = F1406_14172(RTCW(tr1), tr2);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1168_10085(RTCW(loc2), tw1);
				} else {
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1168_10085(RTCW(loc3), tw1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
					}
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc4))-867])(loc4);
			for (;;) {
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc4))-867])(loc4);
				if (!tb2) {
					tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
				}
				if (tb1) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
				loc6 = F426_5575(Current, tr1);
				if ((EIF_BOOLEAN) !F426_5557(Current, loc6)) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
					tr1 = F1406_14172(RTCW(tr1), tr2);
					F424_5542(Current, tr1);
				} else {
					if (loc5) {
						F1407_14226(RTCW(arg1), loc6);
					} else {
						F1407_14225(RTCW(arg1), loc6);
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
			}
		}
	} else {
		tr1 = F1406_14161(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_dotnet_attributes */
void F592_7479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1171_10175(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = F1406_14173(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tb1 = F1168_10084(RTCW(loc1));
		F1407_14228(RTCW(arg1), tb1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_dynamic_runtime_attributes */
void F592_7480 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1171_10175(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = F1406_14174(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tb1 = F1168_10084(RTCW(loc1));
		F1407_14229(RTCW(arg1), tb1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_version_condition_attributes */
void F592_7481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1045L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1046L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1052L));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc4 = RTLNS(eif_new_type(1353, 0x01).id, 1353, _OBJSIZ_4_5_4_0_0_0_0_0_);
		F1354_12604(RTCW(loc4), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_4_0_);
		if (tb1) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14175(RTCW(tr1), loc1);
			F424_5542(Current, tr1);
		}
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc5 = RTLNS(eif_new_type(1353, 0x01).id, 1353, _OBJSIZ_4_5_4_0_0_0_0_0_);
		F1354_12604(RTCW(loc5), loc2);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_4_0_);
		if (tb1) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14176(RTCW(tr1), loc2);
			F424_5542(Current, tr1);
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		if ((EIF_BOOLEAN)(loc3 == NULL)) {
			tr1 = F1406_14177(RTCV(RTOUCR(305,F404_5211, (Current))));
			F424_5542(Current, tr1);
		} else {
			if ((EIF_BOOLEAN) !F426_5565(Current, loc3)) {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr1 = F1406_14179(RTCW(tr1), loc3);
				F424_5542(Current, tr1);
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr1 = F1406_14178(RTCW(tr1), loc3);
					F424_5542(Current, tr1);
				} else {
					tb1 = '\0';
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
						tb2 = F412_5345(RTCW(loc1), loc2);
						tb1 = tb2;
					}
					if (tb1) {
						tr1 = RTOUCR(305,F404_5211, (Current));
						tr1 = F1406_14180(RTCW(tr1), loc3);
						F424_5542(Current, tr1);
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) || (EIF_BOOLEAN)(loc5 != NULL))) {
							F1407_14236(RTCW(arg1), loc4, loc5, loc3);
						} else {
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_custom_attributes */
void F592_7482 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = F1406_14181(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL)))) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr1 = F1406_14183(RTCW(tr1), loc1);
			F424_5542(Current, tr1);
		} else {
			loc4 = RTLNS(eif_new_type(51, 0x01).id, 51, _OBJSIZ_0_2_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1069L));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				tr1 = RTOUCR(273,F421_5478, (Current));
				if (F423_5527(Current, tr1)) {
					tr1 = RTOUCR(334,F592_7484, (Current));
					F964_8600(RTCW(tr1), loc5);
					tb1 = F964_8590(RTCV(RTOUCR(334,F592_7484, (Current))));
					if (tb1) {
						tu1_1 = *(EIF_NATURAL_8 *)(RTCV(RTOUCR(334,F592_7484, (Current)))+ _CHROFF_5_4_);
						F52_1088(RTCW(loc4), tu1_1);
					}
				} else {
					tr1 = RTOUCR(335,F344_5011, (Current));
					F592_7521(Current, tr1);
				}
			}
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				F1407_14232(RTCW(arg1), loc1, loc2, loc4);
			} else {
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					F52_1087(RTCW(loc4), (EIF_BOOLEAN) 1);
					F1407_14232(RTCW(arg1), loc1, loc3, loc4);
				} else {
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_mapping_attributes */
void F592_7483 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1047L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 1048L));
	tb1 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) {
		tb2 = '\01';
		if (!(EIF_BOOLEAN) !F259_3587(Current, loc1)) {
			tb2 = (EIF_BOOLEAN) !F259_3587(Current, loc2);
		}
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = F1406_14184(RTCV(RTOUCR(305,F404_5211, (Current))));
		F424_5542(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1249_11283(loc3, loc1, loc2);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				F1192_10913(loc4, loc1, loc2);
			} else {
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.match_kind */
static EIF_REFERENCE F592_7484_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(334)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,971,1330,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 971, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F972_8682(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(336,F344_5012, (Current));
	F964_8606(RTCW(Result), ((EIF_NATURAL_8) 1U), tr1);
	tr1 = RTOUCR(337,F344_5013, (Current));
	F964_8606(RTCW(Result), ((EIF_NATURAL_8) 2U), tr1);
	tr1 = RTOUCR(338,F344_5014, (Current));
	F964_8606(RTCW(Result), ((EIF_NATURAL_8) 3U), tr1);
	tr1 = RTOUCR(339,F344_5015, (Current));
	F964_8606(RTCW(Result), ((EIF_NATURAL_8) 4U), tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F592_7484 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(334,F592_7484_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_description_content */
void F592_7485 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F431_5673(loc1, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F594_7651(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				F430_5662(loc3, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					F432_5698(loc4, *(EIF_REFERENCE *)(Current + _REFACS_19_));
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						F1246_11216(loc5, *(EIF_REFERENCE *)(Current + _REFACS_19_));
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							F1192_10865(loc6, *(EIF_REFERENCE *)(Current + _REFACS_19_));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc7 = tr1;
							if (EIF_TEST(loc7)) {
								F1382_13347(loc7, *(EIF_REFERENCE *)(Current + _REFACS_19_));
							} else {
								tr1 = F1406_14185(RTCV(RTOUCR(305,F404_5211, (Current))));
								F424_5542(Current, tr1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_exclude_content */
void F592_7486 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = F426_5561(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTLNS(eif_new_type(587, 0x01).id, 587, _OBJSIZ_3_0_0_4_0_0_0_0_);
		tr2 = eif_boxed_item(loc1,1);
		ti4_1 = eif_integer_32_item(loc1,2);
		F588_7411(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), tr2, ti4_1);
		F424_5540(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F431_5669(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_4_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = RTLNS(eif_new_type(587, 0x01).id, 587, _OBJSIZ_3_0_0_4_0_0_0_0_);
				F588_7411(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), loc3, ((EIF_INTEGER_32) 0L));
				F424_5540(Current, tr1);
			}
		} else {
			F424_5537(Current);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_include_content */
void F592_7487 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = F426_5561(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTLNS(eif_new_type(587, 0x01).id, 587, _OBJSIZ_3_0_0_4_0_0_0_0_);
		tr2 = eif_boxed_item(loc1,1);
		ti4_1 = eif_integer_32_item(loc1,2);
		F588_7411(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), tr2, ti4_1);
		F424_5540(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F431_5670(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_4_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = RTLNS(eif_new_type(587, 0x01).id, 587, _OBJSIZ_3_0_0_4_0_0_0_0_);
				F588_7411(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), loc3, ((EIF_INTEGER_32) 0L));
				F424_5540(Current, tr1);
			}
		} else {
			F424_5537(Current);
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.set_default_options */
void F592_7488 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(594, 0x01).id, 594, _OBJSIZ_18_18_0_0_0_0_0_0_);
	tr2 = F594_7552(RTCW(tr1), arg2);
	loc2 = tr2;
	if (EIF_TEST(loc2)) {
		loc1 = F1192_10849(RTCW(arg1));
		F595_7687(RTCW(loc1), loc2);
		F428_5638(RTCW(arg1), loc1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.non_client_options */
static EIF_REFERENCE F592_7489_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(340)
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,0xFFF9,2,1113,0xFF01,1167,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 988, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F989_8728(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(306,F592_7519, (Current));
	tr1 = F963_8564(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = RTOUCR(341,F274_3662, (Current));
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
			loc3 = F992_8734(RTCW(loc1), loc2);
			F966_8597(loc4);
			for (;;) {
				ti4_2 = F966_8570(loc4);
				if ((EIF_BOOLEAN)(ti4_2 == loc3)) break;
				F966_8598(loc4);
			}
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1167,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			tr2 = F966_8571(loc4);
			((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
			RTAR(tr1,tr2);
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc3;
			F989_8755(RTCW(Result), tr1, loc2);
			loc2++;
		}
	}
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F592_7489 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(340,F592_7489_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.report_non_client_options */
void F592_7490 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTOUCR(340,F592_7489, (Current));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr2 = F989_8734(RTCW(loc1), loc2);
		ti4_2 = eif_integer_32_item(RTCW(tr2),2);
		tb1 = F963_8566(RTCW(tr1), ti4_2);
		if (tb1) {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = F989_8734(RTCW(loc1), loc2);
			tr2 = eif_boxed_item(tr2,1);
			tr1 = F1406_14155(RTCW(tr1), tr2);
			F424_5543(Current, tr1);
		}
		loc2++;
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_element_under_note */
void F592_7507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = F1056_8885(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	loc2 = tr1;
	if ((EIF_TRUE)) {
		tr1 = F1_14(loc2);
		F1075_9000(RTCW(loc1), tr1);
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_note */
void F592_7508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = F1056_8885(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(loc2);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			F343_4863(loc2, loc1);
		} else {
			tr1 = RTOUCR(305,F404_5211, (Current));
			tr2 = *(EIF_REFERENCE *)(loc2 + O9389[Dtype(loc2)-1245]);
			tr1 = F1406_14186(RTCW(tr1), tr2);
			F424_5543(Current, tr1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = *(EIF_REFERENCE *)(loc3);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				F343_4863(loc3, loc1);
			} else {
				tr1 = RTOUCR(305,F404_5211, (Current));
				tr2 = *(EIF_REFERENCE *)(loc3 + _REFACS_4_);
				tr1 = F1406_14186(RTCW(tr1), tr2);
				F424_5543(Current, tr1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				tr1 = *(EIF_REFERENCE *)(loc4);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F343_4863(loc4, loc1);
				} else {
					tr1 = RTOUCR(305,F404_5211, (Current));
					tr2 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
					tr1 = F1406_14186(RTCW(tr1), tr2);
					F424_5543(Current, tr1);
				}
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.note_level */
EIF_INTEGER_32 F592_7509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	RTLE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.tag_from_state_transitions */
EIF_INTEGER_32 F592_7510 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(F592_7509(Current) == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOUCR(342,F592_7518, (Current));
		tr1 = F963_8564(RTCW(tr1), arg1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			ti4_1 = F966_8564(loc3, arg2);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	} else {
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = F1168_10067(RTCW(arg2));
			loc1 = F966_8564(RTCW(loc2), tr1);
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {965,1312,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNSMART(typres0.id);
			}
			F966_8558(RTCW(loc2), ((EIF_INTEGER_32) 2L));
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) loc2;
		}
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			loc1 = F592_7511(Current);
			tr1 = F1168_10067(RTCW(arg2));
			F966_8605(RTCW(loc2), loc1, tr1);
		}
		RTLE;
		return (EIF_INTEGER_32) loc1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.new_undefined_tag_number */
EIF_INTEGER_32 F592_7511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_) = (EIF_INTEGER_32) Result;
	RTLE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.lt_gt_escaped_string */
EIF_REFERENCE F592_7516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8624[Dtype(arg1)-1170]);
	F1171_10137(RTCW(Result), ti4_1);
	F1173_10252(RTCW(Result), arg1);
	F592_7517(Current, Result);
	RTLE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.lt_gt_escape_string */
void F592_7517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(343,F192_2922, (Current));
	tr2 = RTOUCR(344,F344_5019, (Current));
	F1173_10229(RTCW(arg1), tr1, tr2);
	tr1 = RTOUCR(345,F192_2923, (Current));
	tr2 = RTOUCR(346,F344_5020, (Current));
	F1173_10229(RTCW(arg1), tr1, tr2);
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.state_transitions_tag */
static EIF_REFERENCE F592_7518_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(342)
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 962, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F963_8558(RTCW(tr1), ((EIF_INTEGER_32) 14L));
	Result = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("system",6,16556653);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 2L), tr1);
	tr1 = RTMS_EX_H("redirection",11,7276654);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 47L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 1L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("note",4,1852798053);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("target",6,709236);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 4L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 2L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 25L));
	tr1 = RTMS_EX_H("note",4,1852798053);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("root",4,1919905652);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 5L), tr1);
	tr1 = RTMS_EX_H("version",7,1397649262);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 6L), tr1);
	tr1 = RTMS_EX_H("file_rule",9,241263973);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 7L), tr1);
	tr1 = RTMS_EX_H("option",6,24682094);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 8L), tr1);
	tr1 = RTMS_EX_H("setting",7,2051971943);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 9L), tr1);
	tr1 = RTOUCR(347,F344_4995, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 49L), tr1);
	tr1 = RTMS_EX_H("mapping",7,1104548967);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 43L), tr1);
	tr1 = RTMS_EX_H("external_include",16,1852008037);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 10L), tr1);
	tr1 = RTMS_EX_H("external_cflag",14,2146934631);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 11L), tr1);
	tr1 = RTMS_EX_H("external_object",15,1998183540);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 12L), tr1);
	tr1 = RTMS_EX_H("external_library",16,1303995769);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 13L), tr1);
	tr1 = RTMS_EX_H("external_resource",17,1468082021);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 14L), tr1);
	tr1 = RTMS_EX_H("external_linker_flag",20,1131822695);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 15L), tr1);
	tr1 = RTMS_EX_H("external_make",13,2071652709);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 16L), tr1);
	tr1 = RTMS_EX_H("pre_compile_action",18,1040865902);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 17L), tr1);
	tr1 = RTMS_EX_H("post_compile_action",19,1864276334);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 18L), tr1);
	tr1 = RTMS_EX_H("variable",8,1315629925);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 19L), tr1);
	tr1 = RTMS_EX_H("precompile",10,1775433829);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 20L), tr1);
	tr1 = RTMS_EX_H("library",7,649884793);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 21L), tr1);
	tr1 = RTMS_EX_H("assembly",8,1983830905);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 22L), tr1);
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 23L), tr1);
	tr1 = RTMS_EX_H("tests",5,1702956147);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 45L), tr1);
	tr1 = RTMS_EX_H("override",8,1406443621);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 24L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 4L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("exclude",7,1351771749);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 25L), tr1);
	tr1 = RTMS_EX_H("include",7,1197897061);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 26L), tr1);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 7L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("debug",5,1701719399);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 27L), tr1);
	tr1 = RTMS_EX_H("assertions",10,1726143859);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 28L), tr1);
	tr1 = RTMS_EX_H("warning",7,1809215079);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 29L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 8L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 39L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	tr1 = RTOUCR(307,F344_4996, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 50L), tr1);
	tr1 = RTOUCR(308,F344_4998, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 52L), tr1);
	tr1 = RTOUCR(309,F344_5000, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 54L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 49L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 17L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 18L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 10L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 11L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 12L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 13L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 14L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 15L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 16L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("description",11,801826414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTMS_EX_H("option",6,24682094);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 8L), tr1);
	tr1 = RTMS_EX_H("renaming",8,1374354535);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 38L), tr1);
	tr1 = RTMS_EX_H("class_option",12,862831982);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 39L), tr1);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 22L));
	tr1 = RTMS_EX_H("visible",7,1237289573);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 41L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 21L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 20L));
	tr1 = F1_14(loc1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("renaming",8,1374354535);
	F966_8610(RTCW(loc1), tr1);
	tr1 = RTMS_EX_H("note",4,1852798053);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	tr1 = RTMS_EX_H("file_rule",9,241263973);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 7L), tr1);
	tr1 = RTMS_EX_H("mapping",7,1104548967);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 43L), tr1);
	tr1 = RTMS_EX_H("uses",4,1970496883);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 40L), tr1);
	tr1 = RTMS_EX_H("tests",5,1702956147);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 45L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 45L));
	tr1 = F1_14(loc1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 23L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 23L));
	tr1 = F1_14(loc1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F966_8610(RTCW(loc1), tr1);
	tr1 = RTMS_EX_H("override",8,1406443621);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 24L), tr1);
	tr1 = RTMS_EX_H("overrides",9,1420439155);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 42L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 24L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 9L));
	tr1 = RTMS_EX_H("platform",8,459690093);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 31L), tr1);
	tr1 = RTMS_EX_H("build",5,1970595940);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 32L), tr1);
	tr1 = RTMS_EX_H("multithreaded",13,1599663972);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 33L), tr1);
	tr1 = RTMS_EX_H("concurrency",11,300205945);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 46L), tr1);
	tr1 = RTMS_EX_H("void_safety",11,1966795897);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 48L), tr1);
	tr1 = RTMS_EX_H("dotnet",6,3372660);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 34L), tr1);
	tr1 = RTMS_EX_H("dynamic_runtime",15,1723645541);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 35L), tr1);
	tr1 = RTMS_EX_H("version",7,1397649262);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 36L), tr1);
	tr1 = RTMS_EX_H("custom",6,2132551021);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 37L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 30L));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F592_7518 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(342,F592_7518_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.tag_attributes */
static EIF_REFERENCE F592_7519_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(306)
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 962, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F963_8558(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	Result = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("uuid",4,1970628964);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1002L), tr1);
	tr1 = RTMS_EX_H("location",8,59511406);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	tr1 = RTMS_EX_H("message",7,1162241893);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1066L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 47L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("uuid",4,1970628964);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1002L), tr1);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	tr1 = RTMS_EX_H("library_target",14,997913460);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1003L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 2L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTOUCR(348,F344_5006, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTOUCR(349,F344_5004, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1005L), tr1);
	tr1 = RTOUCR(312,F344_5005, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1004L), tr1);
	tr1 = RTOUCR(311,F344_5003, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1000L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 4L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 44L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1006L), tr1);
	tr1 = RTMS_EX_H("class",5,1819086195);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	tr1 = RTMS_EX_H("feature",7,1951938661);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1009L), tr1);
	tr1 = RTMS_EX_H("all_classes",11,1867072883);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1008L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 5L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("major",5,1635202418);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1012L), tr1);
	tr1 = RTMS_EX_H("minor",5,1769682290);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1013L), tr1);
	tr1 = RTMS_EX_H("release",7,1296412773);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1014L), tr1);
	tr1 = RTMS_EX_H("build",5,1970595940);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1015L), tr1);
	tr1 = RTMS_EX_H("product",7,299891316);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1016L), tr1);
	tr1 = RTMS_EX_H("company",7,393321593);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1017L), tr1);
	tr1 = RTMS_EX_H("copyright",9,1966519156);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1018L), tr1);
	tr1 = RTMS_EX_H("trademark",9,1887934059);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1019L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 6L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 17L));
	tr1 = RTOUCR(321,F344_4988, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1020L), tr1);
	tr1 = RTOUCR(322,F344_4987, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1021L), tr1);
	tr1 = RTOUCR(323,F344_4986, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1022L), tr1);
	tr1 = RTOUCR(324,F344_4981, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1023L), tr1);
	tr1 = RTOUCR(325,F344_4989, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1054L), tr1);
	tr1 = RTOUCR(333,F344_4990, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1070L), tr1);
	tr1 = RTOUCR(350,F344_4983, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1056L), tr1);
	tr1 = RTOUCR(351,F344_4991, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1024L), tr1);
	tr1 = RTOUCR(326,F344_4982, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1058L), tr1);
	tr1 = RTOUCR(328,F344_4980, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1060L), tr1);
	tr1 = RTOUCR(329,F344_4984, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1071L), tr1);
	tr1 = RTOUCR(330,F344_4985, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1061L), tr1);
	tr1 = RTMS_EX_H("syntax_level",12,1690338668);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1064L), tr1);
	tr1 = RTOUCR(332,F344_4992, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1065L), tr1);
	tr1 = RTOUCR(327,F344_4977, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1059L), tr1);
	tr1 = RTOUCR(331,F344_4993, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1063L), tr1);
	tr1 = RTMS_EX_H("is_void_safe",12,1531546981);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1062L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 8L));
	tr1 = F1_14(loc1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("class",5,1819086195);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 39L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 9L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTOUCR(317,F344_5001, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1067L), tr1);
	tr1 = RTOUCR(318,F344_5002, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1068L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 50L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 51L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 52L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 53L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 54L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("location",8,59511406);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 10L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 12L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 13L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 14L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 16L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("command",7,342989924);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1026L), tr1);
	tr1 = RTMS_EX_H("working_directory",17,159568505);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1051L), tr1);
	tr1 = RTMS_EX_H("succeed",7,1797821540);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1050L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 17L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 18L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 19L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("location",8,59511406);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	tr1 = RTMS_EX_H("prefix",6,1922286968);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1030L), tr1);
	tr1 = RTMS_EX_H("use_application_options",23,923843187);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1057L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 21L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("location",8,59511406);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	tr1 = RTMS_EX_H("prefix",6,1922286968);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1030L), tr1);
	tr1 = RTMS_EX_H("eifgens_location",16,1182782062);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1053L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 20L));
	tr1 = F1_14(loc1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("assembly_name",13,1179631717);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1032L), tr1);
	tr1 = RTMS_EX_H("assembly_version",16,557556334);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1033L), tr1);
	tr1 = RTMS_EX_H("assembly_culture",16,1780917861);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1034L), tr1);
	tr1 = RTMS_EX_H("assembly_key",12,1052986489);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1035L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 22L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTMS_EX_H("location",8,59511406);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	tr1 = RTMS_EX_H("recursive",9,760839013);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1036L), tr1);
	tr1 = RTMS_EX_H("hidden",6,1889579886);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1055L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 23L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 45L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 24L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("name",4,1851878757);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTOUCR(319,F274_3792, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1037L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 27L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	tr1 = RTOUCR(352,F344_4904, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTOUCR(319,F274_3792, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1037L), tr1);
	tr1 = RTOUCR(353,F344_4906, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 29L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("precondition",12,694692206);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1038L), tr1);
	tr1 = RTMS_EX_H("postcondition",13,29888366);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1039L), tr1);
	tr1 = RTMS_EX_H("check",5,1752235371);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1040L), tr1);
	tr1 = RTMS_EX_H("invariant",9,997544820);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1041L), tr1);
	tr1 = RTMS_EX_H("loop",4,1819242352);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1042L), tr1);
	tr1 = RTMS_EX_H("supplier_precondition",21,1130264430);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1043L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 28L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 31L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 32L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 34L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 35L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 11L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 15L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 33L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 46L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("value",5,1635404133);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 48L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("min",3,7170414);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1045L), tr1);
	tr1 = RTMS_EX_H("max",3,7168376);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1046L), tr1);
	tr1 = RTMS_EX_H("type",4,1954115685);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1052L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 36L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTOUCR(354,F344_5008, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	tr1 = RTOUCR(355,F344_5009, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	tr1 = RTOUCR(356,F344_5010, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	tr1 = RTOUCR(335,F344_5011, (Current));
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1069L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 37L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("group",5,1920698224);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1049L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 40L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 42L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("class",5,1819086195);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	tr1 = RTMS_EX_H("feature",7,1951938661);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1009L), tr1);
	tr1 = RTMS_EX_H("class_rename",12,767457637);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1010L), tr1);
	tr1 = RTMS_EX_H("feature_rename",14,1945920613);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1011L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 41L));
	{
		static EIF_TYPE_INDEX typarr1[] = {0xFF01,962,0xFF01,973,1312,1312,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7384,Y7384_gen_type,typres1.id,960).id);
	}
	F966_8558(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("old_name",8,598495589);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1047L), tr1);
	tr1 = RTMS_EX_H("new_name",8,1407364965);
	F966_8605(RTCW(loc1), ((EIF_INTEGER_32) 1048L), tr1);
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 43L));
	F963_8605(RTCW(Result), loc1, ((EIF_INTEGER_32) 38L));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F592_7519 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(306,F592_7519_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.report_unknown_attribute */
void F592_7521 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(305,F404_5211, (Current));
	tr1 = F1406_14099(RTCW(tr1), arg1);
	F424_5542(Current, tr1);
	RTLE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#15507#302#406# of on_start_tag_finish */
EIF_REFERENCE F592_15507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
	return (EIF_REFERENCE) tr1;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#15508#302#407# of on_start_tag_finish */
EIF_REFERENCE F592_15508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
	return (EIF_REFERENCE) tr1;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#15509#302#405# of on_start_tag_finish */
EIF_REFERENCE F592_15509 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
