
#ifndef _C11_co502_
#define _C11_co502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F589_7415(EIF_REFERENCE);
extern void EIF_Minit502(void);

#ifdef __cplusplus
}
#endif

#endif
