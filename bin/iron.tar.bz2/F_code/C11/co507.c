/*
 * Code for class CONF_OPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co507.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_OPTION}.create_from_namespace */
EIF_REFERENCE F594_7552 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F421_5490(Current, arg1)) {
		tr1 = RTLNSMART(Dftype(Current));
		F594_7554(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_OPTION}.create_from_namespace_or_latest */
EIF_REFERENCE F594_7553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNSMART(Dftype(Current));
	if (F421_5490(Current, arg1)) {
		tr1 = arg1;
	} else {
		tr1 = RTOUCR(268,F421_5488, (Current));
	}
	F594_7554(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CONF_OPTION}.make_from_namespace */
void F594_7554 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(269,F421_5486, (Current));
	tb1 = F1171_10164(RTCW(arg1), tr1);
	if (tb1) {
		F594_7565(Current);
	} else {
		tr1 = RTOUCR(270,F421_5484, (Current));
		tb1 = F1171_10164(RTCW(arg1), tr1);
		if (tb1) {
			F594_7564(Current);
		} else {
			tr1 = RTOUCR(271,F421_5482, (Current));
			tb1 = F1171_10164(RTCW(arg1), tr1);
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6701[dtype-593])(Current);
			} else {
				tb1 = '\01';
				tr1 = RTOUCR(272,F421_5480, (Current));
				tb2 = F1171_10164(RTCW(arg1), tr1);
				if (!tb2) {
					tr1 = RTOUCR(273,F421_5478, (Current));
					tb2 = F1171_10164(RTCW(arg1), tr1);
					tb1 = tb2;
				}
				if (tb1) {
					F594_7562(Current);
				} else {
					tb1 = '\01';
					tr1 = RTOUCR(274,F421_5476, (Current));
					tb2 = F1171_10164(RTCW(arg1), tr1);
					if (!tb2) {
						tr1 = RTOUCR(275,F421_5474, (Current));
						tb2 = F1171_10164(RTCW(arg1), tr1);
						tb1 = tb2;
					}
					if (tb1) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R6699[dtype-593])(Current);
					} else {
						tr1 = RTOUCR(276,F421_5472, (Current));
						tb1 = F1171_10164(RTCW(arg1), tr1);
						if (tb1) {
							F594_7560(Current);
						} else {
							tb1 = '\01';
							tr1 = RTOUCR(277,F421_5470, (Current));
							tb2 = F1171_10164(RTCW(arg1), tr1);
							if (!tb2) {
								tr1 = RTOUCR(278,F421_5468, (Current));
								tb2 = F1171_10164(RTCW(arg1), tr1);
								tb1 = tb2;
							}
							if (tb1) {
								F594_7559(Current);
							} else {
								tb1 = '\01';
								tr1 = RTOUCR(279,F421_5466, (Current));
								tb2 = F1171_10164(RTCW(arg1), tr1);
								if (!tb2) {
									tr1 = RTOUCR(280,F421_5464, (Current));
									tb2 = F1171_10164(RTCW(arg1), tr1);
									tb1 = tb2;
								}
								if (tb1) {
									F594_7558(Current);
								} else {
									tb1 = '\01';
									tr1 = RTOUCR(281,F421_5462, (Current));
									tb2 = F1171_10164(RTCW(arg1), tr1);
									if (!tb2) {
										tr1 = RTOUCR(282,F421_5460, (Current));
										tb2 = F1171_10164(RTCW(arg1), tr1);
										tb1 = tb2;
									}
									if (tb1) {
										F594_7557(Current);
									} else {
										tb1 = '\01';
										tb2 = '\01';
										tb3 = '\01';
										tr1 = RTOUCR(283,F421_5458, (Current));
										tb4 = F1171_10164(RTCW(arg1), tr1);
										if (!tb4) {
											tr1 = RTOUCR(284,F421_5456, (Current));
											tb4 = F1171_10164(RTCW(arg1), tr1);
											tb3 = tb4;
										}
										if (!tb3) {
											tr1 = RTOUCR(285,F421_5454, (Current));
											tb3 = F1171_10164(RTCW(arg1), tr1);
											tb2 = tb3;
										}
										if (!tb2) {
											tr1 = RTOUCR(286,F421_5452, (Current));
											tb2 = F1171_10164(RTCW(arg1), tr1);
											tb1 = tb2;
										}
										if (tb1) {
											F594_7556(Current);
										} else {
											tb1 = '\01';
											tb2 = '\01';
											tb3 = '\01';
											tr1 = RTOUCR(287,F421_5450, (Current));
											tb4 = F1171_10164(RTCW(arg1), tr1);
											if (!tb4) {
												tr1 = RTOUCR(288,F421_5448, (Current));
												tb4 = F1171_10164(RTCW(arg1), tr1);
												tb3 = tb4;
											}
											if (!tb3) {
												tr1 = RTOUCR(289,F421_5446, (Current));
												tb3 = F1171_10164(RTCW(arg1), tr1);
												tb2 = tb3;
											}
											if (!tb2) {
												tr1 = RTOUCR(290,F421_5444, (Current));
												tb2 = F1171_10164(RTCW(arg1), tr1);
												tb1 = tb2;
											}
											if (tb1) {
												(FUNCTION_CAST(void, (EIF_REFERENCE)) R6693[dtype-593])(Current);
											} else {
												RTCT0("from_precondition", EX_CHECK);
													RTCF0;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONF_OPTION}.make_6_3 */
void F594_7555 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(291,F594_7604, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(292,F594_7609, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(293,F594_7636, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(294,F594_7629, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current + O6735[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6734[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(295,F594_7622, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1185, 1).id);
	tr2 = RTOUCR(296,F594_7623, (Current));
	F1186_10630(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_OPTION}.make_6_4 */
void F594_7556 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6693[Dtype(Current)-593])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 2U));
	RTLE;
}

/* {CONF_OPTION}.make_7_0 */
void F594_7557 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F594_7556(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	*(EIF_BOOLEAN *)(Current + O6733[Dtype(Current)-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {CONF_OPTION}.make_7_3 */
void F594_7558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F594_7557(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 4U));
	*(EIF_BOOLEAN *)(Current + O6732[Dtype(Current)-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {CONF_OPTION}.make_14_05 */
void F594_7559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F594_7558(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 5U));
	RTLE;
}

/* {CONF_OPTION}.make_15_11 */
void F594_7560 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F594_7559(Current);
	*(EIF_BOOLEAN *)(Current + O6735[Dtype(Current)-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {CONF_OPTION}.make_16_11 */
void F594_7561 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F594_7560(Current);
}

/* {CONF_OPTION}.make_18_01 */
void F594_7562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6699[Dtype(Current)-593])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTLE;
}

/* {CONF_OPTION}.make_19_05 */
void F594_7563 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F594_7562(Current);
}

/* {CONF_OPTION}.make_19_11 */
void F594_7564 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6701[Dtype(Current)-593])(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1186_10642(RTCW(tr1), ((EIF_NATURAL_8) 2U));
	RTLE;
}

/* {CONF_OPTION}.make_21_05 */
void F594_7565 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F594_7564(Current);
	*(EIF_BOOLEAN *)(Current + O6734[Dtype(Current)-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {CONF_OPTION}.is_empty_for */
EIF_BOOLEAN F594_7576 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O6704[dtype-593]) || *(EIF_BOOLEAN *)(Current + O6705[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6706[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6707[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6708[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6709[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6710[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6711[dtype-593])) || *(EIF_BOOLEAN *)(Current + O6712[dtype-593])) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_11_) != NULL))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb5 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb4 = tb5;
	}
	if (!tb4) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb4 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb3 = tb4;
	}
	if (!tb3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tr1 = RTOUCR(276,F421_5472, (Current));
		if (F421_5492(Current, arg1, tr1)) {
			tb2 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
			if (!tb3) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
				tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		Result = tb1;
	}
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {CONF_OPTION}.syntax_name */
static EIF_REFERENCE F594_7604_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(291)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 4L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("o\000\000\000b\000\000\000s\000\000\000o\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000",8,2004093797);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000i\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000a\000\000\000l\000\000\000",12,1290118508);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000r\000\000\000d\000\000\000",8,157435492);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("p\000\000\000r\000\000\000o\000\000\000v\000\000\000i\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000a\000\000\000l\000\000\000",11,1227139436);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7604 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(291,F594_7604_body,(Current));
}

/* {CONF_OPTION}.array_name */
static EIF_REFERENCE F594_7609_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(292)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000m\000\000\000a\000\000\000t\000\000\000c\000\000\000h\000\000\000_\000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",14,1494271346);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000m\000\000\000a\000\000\000t\000\000\000c\000\000\000h\000\000\000_\000\000\000w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",16,1759222119);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000r\000\000\000d\000\000\000",8,157435492);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7609 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(292,F594_7609_body,(Current));
}

/* {CONF_OPTION}.warning_name */
static EIF_REFERENCE F594_7622_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(295)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",7,1809215079);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",5,1920877938);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7622 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(295,F594_7622_body,(Current));
}

/* {CONF_OPTION}.warning_term_name */
static EIF_REFERENCE F594_7623_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(296)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("c\000\000\000u\000\000\000r\000\000\000r\000\000\000e\000\000\000n\000\000\000t\000\000\000",7,438973044);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("a\000\000\000l\000\000\000l\000\000\000",3,6384748);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7623 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(296,F594_7623_body,(Current));
}

/* {CONF_OPTION}.add_warning */
void F594_7624 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {972,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F968_8559(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	}
	F968_8605(RTCW(loc1), arg2, arg1);
	RTLE;
}

/* {CONF_OPTION}.catcall_detection_values */
static EIF_REFERENCE F594_7629_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(294)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("c\000\000\000o\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000n\000\000\000c\000\000\000e\000\000\000",11,1508810597);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("a\000\000\000l\000\000\000l\000\000\000",3,6384748);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7629 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(294,F594_7629_body,(Current));
}

/* {CONF_OPTION}.void_safety_name */
static EIF_REFERENCE F594_7636_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(293)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 5L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10066(RTCV(RTOUCR(297,F344_4894, (Current))));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(298,F344_4895, (Current))));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(299,F344_4896, (Current))));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(300,F344_4897, (Current))));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10066(RTCV(RTOUCR(301,F344_4898, (Current))));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F594_7636 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(293,F594_7636_body,(Current));
}

/* {CONF_OPTION}.set_assertions */
void F594_7639 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {CONF_OPTION}.add_debug */
void F594_7640 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {972,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F968_8559(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc1;
	}
	F968_8605(RTCW(loc1), arg2, arg1);
	RTLE;
}

/* {CONF_OPTION}.set_local_namespace */
void F594_7641 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	} else {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	}
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {CONF_OPTION}.set_profile */
void F594_7642 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6704[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6727[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_trace */
void F594_7643 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6705[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6728[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_optimize */
void F594_7644 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6706[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6729[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_debug */
void F594_7645 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6707[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6730[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_msil_application_optimize */
void F594_7646 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6708[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6731[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_full_class_checking */
void F594_7647 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6709[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6732[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_is_attached_by_default */
void F594_7648 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6710[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6733[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_is_obsolete_iteration */
void F594_7649 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6712[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6734[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_is_obsolete_routine_type */
void F594_7650 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O6711[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O6735[dtype-593]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {CONF_OPTION}.set_description */
void F594_7651 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {CONF_OPTION}.copy */
void F594_7652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1_14(loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1_14(loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = F1_14(loc3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = F1_14(loc4);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = F1_14(loc5);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = F1_14(loc6);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {CONF_OPTION}.is_equal */
EIF_BOOLEAN F594_7653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_BOOLEAN tb8;
	EIF_BOOLEAN tb9;
	EIF_BOOLEAN tb10;
	EIF_BOOLEAN tb11;
	EIF_BOOLEAN tb12;
	EIF_BOOLEAN tb13;
	EIF_BOOLEAN tb14;
	EIF_BOOLEAN tb15;
	EIF_BOOLEAN tb16;
	EIF_BOOLEAN tb17;
	EIF_BOOLEAN tb18;
	EIF_BOOLEAN tb19;
	EIF_BOOLEAN tb20;
	EIF_BOOLEAN tb21;
	EIF_BOOLEAN tb22;
	EIF_BOOLEAN tb23;
	EIF_BOOLEAN tb24;
	EIF_BOOLEAN tb25;
	EIF_BOOLEAN tb26;
	EIF_BOOLEAN tb27;
	EIF_BOOLEAN tb28;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tb5 = '\0';
	tb6 = '\0';
	tb7 = '\0';
	tb8 = '\0';
	tb9 = '\0';
	tb10 = '\0';
	tb11 = '\0';
	tb12 = '\0';
	tb13 = '\0';
	tb14 = '\0';
	tb15 = '\0';
	tb16 = '\0';
	tb17 = '\0';
	tb18 = '\0';
	tb19 = '\0';
	tb20 = '\0';
	tb21 = '\0';
	tb22 = '\0';
	tb23 = '\0';
	tb24 = '\0';
	tb25 = '\0';
	tb26 = '\0';
	tb27 = '\0';
	tb28 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if (RTEQ(*(EIF_REFERENCE *)(Current), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		tb28 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_11_), tr1);
	}
	if (tb28) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		tb27 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_3_), tr1);
	}
	if (tb27) {
		tb27 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6733[Dtype(arg1)-593]);
		tb26 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6733[dtype-593]) == tb27);
	}
	if (tb26) {
		tb26 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6710[Dtype(arg1)-593]);
		tb25 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6710[dtype-593]) == tb26);
	}
	if (tb25) {
		tb25 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6734[Dtype(arg1)-593]);
		tb24 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6734[dtype-593]) == tb25);
	}
	if (tb24) {
		tb24 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6712[Dtype(arg1)-593]);
		tb23 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6712[dtype-593]) == tb24);
	}
	if (tb23) {
		tb23 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6735[Dtype(arg1)-593]);
		tb22 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6735[dtype-593]) == tb23);
	}
	if (tb22) {
		tb22 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6711[Dtype(arg1)-593]);
		tb21 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6711[dtype-593]) == tb22);
	}
	if (tb21) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
		tb20 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_9_), tr1);
	}
	if (tb20) {
		tb20 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6730[Dtype(arg1)-593]);
		tb19 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6730[dtype-593]) == tb20);
	}
	if (tb19) {
		tb19 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6707[Dtype(arg1)-593]);
		tb18 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6707[dtype-593]) == tb19);
	}
	if (tb18) {
		tb18 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6732[Dtype(arg1)-593]);
		tb17 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6732[dtype-593]) == tb18);
	}
	if (tb17) {
		tb17 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6709[Dtype(arg1)-593]);
		tb16 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6709[dtype-593]) == tb17);
	}
	if (tb16) {
		tb16 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6731[Dtype(arg1)-593]);
		tb15 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6731[dtype-593]) == tb16);
	}
	if (tb15) {
		tb15 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6708[Dtype(arg1)-593]);
		tb14 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6708[dtype-593]) == tb15);
	}
	if (tb14) {
		tb14 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6729[Dtype(arg1)-593]);
		tb13 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6729[dtype-593]) == tb14);
	}
	if (tb13) {
		tb13 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6706[Dtype(arg1)-593]);
		tb12 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6706[dtype-593]) == tb13);
	}
	if (tb12) {
		tb12 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6727[Dtype(arg1)-593]);
		tb11 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6727[dtype-593]) == tb12);
	}
	if (tb11) {
		tb11 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6704[Dtype(arg1)-593]);
		tb10 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6704[dtype-593]) == tb11);
	}
	if (tb10) {
		tb10 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6728[Dtype(arg1)-593]);
		tb9 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6728[dtype-593]) == tb10);
	}
	if (tb9) {
		tb9 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6705[Dtype(arg1)-593]);
		tb8 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O6705[dtype-593]) == tb9);
	}
	if (tb8) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tb7 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_2_), tr1);
	}
	if (tb7) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb6 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	if (tb6) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		tb5 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_10_), tr1);
	}
	if (tb5) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		tb4 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_4_), tr1);
	}
	if (tb4) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tb3 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_5_), tr1);
	}
	if (tb3) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tb2 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_6_), tr1);
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
		tb1 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_8_), tr1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		Result = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_7_), tr1);
	}
	RTLE;
	return Result;
}

/* {CONF_OPTION}.merge_client */
void F594_7657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc3;
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc1 = F1_14(loc4);
			F968_8609(RTCW(loc1), loc3);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc1;
		}
	}
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc2 = F1_14(loc5);
			F968_8609(RTCW(loc2), loc2);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6704[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6704[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6727[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6727[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6704[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6727[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6727[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6705[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6705[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6728[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6728[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6705[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6728[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6728[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6706[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6706[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6729[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6729[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6706[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6729[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6729[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6707[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6707[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6730[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6730[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6707[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6730[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6730[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	F1186_10641(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	F1186_10641(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6708[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6708[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6731[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6731[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6708[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6731[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6731[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	RTLE;
}

/* {CONF_OPTION}.merge */
void F594_7658 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	F594_7657(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = loc1;
	} else {
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr1 = tr2;
	}
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = F1168_10066(RTMS_EX_H(".",1,46));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8614[Dtype(loc2)-1171])(loc2, tr1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8614[Dtype(RTCW(tr1))-1171])(tr1, loc3);
		} else {
			tr2 = F1_14(loc2);
			tr1 = tr2;
		}
	} else {
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = tr2;
		if (EIF_TEST(loc4)) {
			tr2 = F1_14(loc4);
			tr1 = tr2;
		} else {
			tr1 = NULL;
		}
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6709[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6709[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6732[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6732[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6709[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6732[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6732[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	F1186_10641(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6712[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6712[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6734[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6734[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6712[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6734[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6734[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6711[dtype-593])) {
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6711[Dtype(arg1)-593]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6735[Dtype(arg1)-593]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O6735[dtype-593]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O6711[dtype-593]) = (EIF_BOOLEAN) tb1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6735[Dtype(arg1)-593]);
		*(EIF_BOOLEAN *)(Current + O6735[dtype-593]) = (EIF_BOOLEAN) tb1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	F1186_10641(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F1186_10641(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	F1186_10641(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
	F1186_10641(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O6710[dtype-593])) {
		tb1 = '\0';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6710[Dtype(arg1)-593]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
			tb1 = (EIF_BOOLEAN)(tu1_1 == ((EIF_NATURAL_8) 1U));
		}
		if (tb1) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6733[Dtype(arg1)-593]);
			*(EIF_BOOLEAN *)(Current + O6710[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
			*(EIF_BOOLEAN *)(Current + O6733[dtype-593]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = '\01';
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6710[Dtype(arg1)-593]);
			if (!tb2) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6733[Dtype(arg1)-593]);
				tb1 = (*(EIF_BOOLEAN *)(Current + O6733[dtype-593]) != tb2);
			}
			*(EIF_BOOLEAN *)(Current + O6710[dtype-593]) = (EIF_BOOLEAN) tb1;
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O6733[Dtype(arg1)-593]);
			*(EIF_BOOLEAN *)(Current + O6733[dtype-593]) = (EIF_BOOLEAN) tb1;
		}
	}
	RTLE;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
