/*
 * Code for class HTTP_HEADER_MODIFIER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ht512.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HTTP_HEADER_MODIFIER}.put_header_key_value */
void F611_7748 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O8704[Dtype(arg2)-1173]);
	F1174_10304(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) + ti4_2));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, arg1);
	tr1 = RTOUCR(698,F611_7820, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, arg2);
	F1076_9029(Current, loc1);
	RTLE;
}

/* {HTTP_HEADER_MODIFIER}.colon_space */
static EIF_REFERENCE F611_7820_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(698)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1174, 0x01).id, 1174, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H(": ",2,14880);
	F1174_10306(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F611_7820 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(698,F611_7820_body,(Current));
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
