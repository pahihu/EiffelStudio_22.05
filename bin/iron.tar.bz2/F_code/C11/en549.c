/*
 * Code for class ENVIRONMENT_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en549.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENVIRONMENT_ARGUMENTS}.argument */
EIF_REFERENCE F1101_9334 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOUCR(701,F1101_9345, (Current));
		Result = F709_7927(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	} else {
		ti4_1 = F1059_8929(RTCV(F1101_9344(Current)));
		if ((EIF_BOOLEAN) (arg1 <= ti4_1)) {
			Result = F1101_9343(Current, arg1);
		} else {
			Result = F1101_9342(Current, arg1);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.index_of_word_option */
EIF_INTEGER_32 F1101_9336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(701,F1101_9345, (Current));
	Result = F709_7932(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F1059_8929(RTCV(F1101_9344(Current)));
		Result += ti4_1;
	} else {
		loc2 = F1059_8929(RTCV(F1101_9344(Current)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tr1 = F1101_9343(Current, loc1);
				tb1 = F1101_9341(Current, tr1, arg1);
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 <= loc2)) {
			RTLE;
			return (EIF_INTEGER_32) loc1;
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_sign */
EIF_REFERENCE F1101_9337 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(242,F709_7939, (RTCV(RTOUCR(701,F1101_9345, (Current)))));
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.argument_count */
EIF_INTEGER_32 F1101_9339 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	ti4_1 = F1059_8929(RTCV(F1101_9344(Current)));
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_word_equal */
EIF_BOOLEAN F1101_9341 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tw1 = *(EIF_CHARACTER_32 *)(RTCV(F1101_9337(Current))+ _LNGOFF_0_0_0_0_);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(tw1 == tw2)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8511[Dtype(RTCW(arg1))-1171])(arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, ((EIF_INTEGER_32) 1L));
			tw2 = *(EIF_CHARACTER_32 *)(RTCV(F1101_9337(Current))+ _LNGOFF_0_0_0_0_);
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8511[Dtype(RTCW(tr1))-1171])(tr1, arg2);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_argument_item */
EIF_REFERENCE F1101_9342 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(701,F1101_9345, (Current));
	ti4_1 = F1059_8929(RTCV(F1101_9344(Current)));
	Result = F709_7927(RTCW(tr1), (EIF_INTEGER_32) (arg1 - ti4_1));
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_argument_item */
EIF_REFERENCE F1101_9343 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F1101_9344(Current);
	Result = F1059_8914(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_arguments */
EIF_REFERENCE F1101_9344 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1059_8908(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
		tr1 = RTOUCR(33,F1095_9251, (Current));
		tr2 = RTOUCR(611,F1102_9349, (Current));
		loc4 = F455_6049(RTCW(tr1), tr2);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb2 = F1168_10025(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
			loc5 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1168_10007(RTCW(loc5));
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = F1173_10219(RTCW(loc4), loc1);
				if (loc6) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					if ((EIF_BOOLEAN)(loc3 == tw1)) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						F1173_10266(RTCW(loc5), loc3);
					}
				} else {
					switch (loc3) {
						case (EIF_CHARACTER_8) '\"':
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							break;
						case (EIF_CHARACTER_8) '\011':
						case (EIF_CHARACTER_8) ' ':
							tb1 = F878_8129(RTCW(loc5));
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_1_0_0_4_0_0_0_0_);
								F1171_10139(RTCW(tr1), loc5);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(Result))-867])(Result, tr1);
								F1173_10281(RTCW(loc5));
							}
							break;
						default:
							F1173_10266(RTCW(loc5), loc3);
							break;
					}
				}
				loc1++;
			}
			if (loc6) {
			} else {
				tb1 = F878_8129(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F1171_10139(RTCW(tr1), loc5);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(Result))-867])(Result, tr1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_arguments */
static EIF_REFERENCE F1101_9345_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(701)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(708, 0x01).id, 708, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1101_9345 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(701,F1101_9345_body,(Current));
}

void EIF_Minit549 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
