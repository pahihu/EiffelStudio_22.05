#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R8732[277])();
void R8732_init () {
	{long i; for (i = 0; i < 2; i++) R8732[i] = (char *(*)()) F1176_10430;}
	R8732[276] = (char *(*)()) F1452_15320;
}

char *(*R8734[277])();
void R8734_init () {
	{long i; for (i = 0; i < 2; i++) R8734[i] = (char *(*)()) F1176_10434;}
	R8734[276] = (char *(*)()) F1452_15337;
}

char *(*R8735[277])();
void R8735_init () {
	{long i; for (i = 0; i < 2; i++) R8735[i] = (char *(*)()) F1176_10435;}
	R8735[276] = (char *(*)()) F1452_15335;
}

char *(*R8744[277])();
void R8744_init () {
	{long i; for (i = 0; i < 2; i++) R8744[i] = (char *(*)()) F1176_10458;}
	R8744[276] = (char *(*)()) F1452_15354;
}

char *(*R8745[277])();
void R8745_init () {
	{long i; for (i = 0; i < 2; i++) R8745[i] = (char *(*)()) F1176_10459;}
	R8745[276] = (char *(*)()) F1452_15355;
}

char *(*R9286[34])();
void R9286_init () {
	R9286[0] = (char *(*)()) F1196_11063;
	R9286[1] = (char *(*)()) F1197_11063;
	R9286[2] = (char *(*)()) F1198_11063;
	R9286[3] = (char *(*)()) F1199_11063;
	R9286[4] = (char *(*)()) F1200_11063;
	R9286[5] = (char *(*)()) F1201_11063;
	R9286[6] = (char *(*)()) F1202_11063;
	R9286[7] = (char *(*)()) F1203_11063;
	R9286[8] = (char *(*)()) F1204_11063;
	R9286[9] = (char *(*)()) F1205_11063;
	R9286[10] = (char *(*)()) F1206_11063;
	R9286[11] = (char *(*)()) F1207_11063;
	R9286[12] = (char *(*)()) F1208_11063;
	R9286[13] = (char *(*)()) F1209_11063;
	R9286[14] = (char *(*)()) F1210_11063;
	R9286[15] = (char *(*)()) F1211_11063;
	R9286[16] = (char *(*)()) F1212_11063;
	R9286[17] = (char *(*)()) F1213_11063;
	R9286[18] = (char *(*)()) F1214_11063;
	R9286[19] = (char *(*)()) F1215_11063;
	R9286[20] = (char *(*)()) F1216_11063;
	R9286[21] = (char *(*)()) F1217_11063;
	R9286[22] = (char *(*)()) F1218_11063;
	R9286[23] = (char *(*)()) F1219_11063;
	R9286[24] = (char *(*)()) F1220_11063;
	R9286[25] = (char *(*)()) F1221_11063;
	R9286[26] = (char *(*)()) F1222_11063;
	R9286[27] = (char *(*)()) F1223_11063;
	R9286[28] = (char *(*)()) F1224_11063;
	R9286[29] = (char *(*)()) F1225_11063;
	R9286[30] = (char *(*)()) F1226_11063;
	R9286[31] = (char *(*)()) F1227_11063;
	R9286[32] = (char *(*)()) F1228_11063;
	R9286[33] = (char *(*)()) F1229_11063;
}

char *(*R9287[34])();
void R9287_init () {
	R9287[0] = (char *(*)()) F1196_11064;
	R9287[1] = (char *(*)()) F1197_11064;
	R9287[2] = (char *(*)()) F1198_11064;
	R9287[3] = (char *(*)()) F1199_11064;
	R9287[4] = (char *(*)()) F1200_11064;
	R9287[5] = (char *(*)()) F1201_11064;
	R9287[6] = (char *(*)()) F1202_11064;
	R9287[7] = (char *(*)()) F1203_11064;
	R9287[8] = (char *(*)()) F1204_11064;
	R9287[9] = (char *(*)()) F1205_11064;
	R9287[10] = (char *(*)()) F1206_11064;
	R9287[11] = (char *(*)()) F1207_11064;
	R9287[12] = (char *(*)()) F1208_11064;
	R9287[13] = (char *(*)()) F1209_11064;
	R9287[14] = (char *(*)()) F1210_11064;
	R9287[15] = (char *(*)()) F1211_11064;
	R9287[16] = (char *(*)()) F1212_11064;
	R9287[17] = (char *(*)()) F1213_11064;
	R9287[18] = (char *(*)()) F1214_11064;
	R9287[19] = (char *(*)()) F1215_11064;
	R9287[20] = (char *(*)()) F1216_11064;
	R9287[21] = (char *(*)()) F1217_11064;
	R9287[22] = (char *(*)()) F1218_11064;
	R9287[23] = (char *(*)()) F1219_11064;
	R9287[24] = (char *(*)()) F1220_11064;
	R9287[25] = (char *(*)()) F1221_11064;
	R9287[26] = (char *(*)()) F1222_11064;
	R9287[27] = (char *(*)()) F1223_11064;
	R9287[28] = (char *(*)()) F1224_11064;
	R9287[29] = (char *(*)()) F1225_11064;
	R9287[30] = (char *(*)()) F1226_11064;
	R9287[31] = (char *(*)()) F1227_11064;
	R9287[32] = (char *(*)()) F1228_11064;
	R9287[33] = (char *(*)()) F1229_11064;
}

char *(*R9289[34])();
void R9289_init () {
	R9289[0] = (char *(*)()) F1196_11066;
	R9289[1] = (char *(*)()) F1197_11066;
	R9289[2] = (char *(*)()) F1198_11066;
	R9289[3] = (char *(*)()) F1199_11066;
	R9289[4] = (char *(*)()) F1200_11066;
	R9289[5] = (char *(*)()) F1201_11066;
	R9289[6] = (char *(*)()) F1202_11066;
	R9289[7] = (char *(*)()) F1203_11066;
	R9289[8] = (char *(*)()) F1204_11066;
	R9289[9] = (char *(*)()) F1205_11066;
	R9289[10] = (char *(*)()) F1206_11066;
	R9289[11] = (char *(*)()) F1207_11066;
	R9289[12] = (char *(*)()) F1208_11066;
	R9289[13] = (char *(*)()) F1209_11066;
	R9289[14] = (char *(*)()) F1210_11066;
	R9289[15] = (char *(*)()) F1211_11066;
	R9289[16] = (char *(*)()) F1212_11066;
	R9289[17] = (char *(*)()) F1213_11066;
	R9289[18] = (char *(*)()) F1214_11066;
	R9289[19] = (char *(*)()) F1215_11066;
	R9289[20] = (char *(*)()) F1216_11066;
	R9289[21] = (char *(*)()) F1217_11066;
	R9289[22] = (char *(*)()) F1218_11066;
	R9289[23] = (char *(*)()) F1219_11066;
	R9289[24] = (char *(*)()) F1220_11066;
	R9289[25] = (char *(*)()) F1221_11066;
	R9289[26] = (char *(*)()) F1222_11066;
	R9289[27] = (char *(*)()) F1223_11066;
	R9289[28] = (char *(*)()) F1224_11066;
	R9289[29] = (char *(*)()) F1225_11066;
	R9289[30] = (char *(*)()) F1226_11066;
	R9289[31] = (char *(*)()) F1227_11066;
	R9289[32] = (char *(*)()) F1228_11066;
	R9289[33] = (char *(*)()) F1229_11066;
}

char *(*R9294[34])();
void R9294_init () {
	R9294[0] = (char *(*)()) F1196_11072;
	R9294[1] = (char *(*)()) F1197_11072;
	R9294[2] = (char *(*)()) F1198_11072;
	R9294[3] = (char *(*)()) F1199_11072;
	R9294[4] = (char *(*)()) F1200_11072;
	R9294[5] = (char *(*)()) F1201_11072;
	R9294[6] = (char *(*)()) F1202_11072;
	R9294[7] = (char *(*)()) F1203_11072;
	R9294[8] = (char *(*)()) F1204_11072;
	R9294[9] = (char *(*)()) F1205_11072;
	R9294[10] = (char *(*)()) F1206_11072;
	R9294[11] = (char *(*)()) F1207_11072;
	R9294[12] = (char *(*)()) F1208_11072;
	R9294[13] = (char *(*)()) F1209_11072;
	R9294[14] = (char *(*)()) F1210_11072;
	R9294[15] = (char *(*)()) F1211_11072;
	R9294[16] = (char *(*)()) F1212_11072;
	R9294[17] = (char *(*)()) F1213_11072;
	R9294[18] = (char *(*)()) F1214_11072;
	R9294[19] = (char *(*)()) F1215_11072;
	R9294[20] = (char *(*)()) F1216_11072;
	R9294[21] = (char *(*)()) F1217_11072;
	R9294[22] = (char *(*)()) F1218_11072;
	R9294[23] = (char *(*)()) F1219_11072;
	R9294[24] = (char *(*)()) F1220_11072;
	R9294[25] = (char *(*)()) F1221_11072;
	R9294[26] = (char *(*)()) F1222_11072;
	R9294[27] = (char *(*)()) F1223_11072;
	R9294[28] = (char *(*)()) F1224_11072;
	R9294[29] = (char *(*)()) F1225_11072;
	R9294[30] = (char *(*)()) F1226_11072;
	R9294[31] = (char *(*)()) F1227_11072;
	R9294[32] = (char *(*)()) F1228_11072;
	R9294[33] = (char *(*)()) F1229_11072;
}

char *(*R9299[34])();
void R9299_init () {
	R9299[0] = (char *(*)()) F1196_11080;
	R9299[1] = (char *(*)()) F1197_11080_9299_1;
	R9299[2] = (char *(*)()) F1198_11080_9299_1;
	R9299[3] = (char *(*)()) F1199_11080_9299_1;
	R9299[4] = (char *(*)()) F1200_11080_9299_1;
	R9299[5] = (char *(*)()) F1201_11080_9299_1;
	R9299[6] = (char *(*)()) F1202_11080_9299_1;
	R9299[7] = (char *(*)()) F1203_11080_9299_1;
	R9299[8] = (char *(*)()) F1204_11080_9299_1;
	R9299[9] = (char *(*)()) F1205_11080_9299_1;
	R9299[10] = (char *(*)()) F1206_11080_9299_1;
	R9299[11] = (char *(*)()) F1207_11080_9299_1;
	R9299[12] = (char *(*)()) F1208_11080_9299_1;
	R9299[13] = (char *(*)()) F1209_11080_9299_1;
	R9299[14] = (char *(*)()) F1210_11080_9299_1;
	R9299[15] = (char *(*)()) F1211_11080_9299_1;
	R9299[16] = (char *(*)()) F1212_11080;
	R9299[17] = (char *(*)()) F1213_11080;
	R9299[18] = (char *(*)()) F1214_11080;
	R9299[19] = (char *(*)()) F1215_11080;
	R9299[20] = (char *(*)()) F1216_11080_9299_1;
	R9299[21] = (char *(*)()) F1217_11080_9299_1;
	R9299[22] = (char *(*)()) F1218_11080_9299_1;
	R9299[23] = (char *(*)()) F1219_11080_9299_1;
	R9299[24] = (char *(*)()) F1220_11080_9299_1;
	R9299[25] = (char *(*)()) F1221_11080_9299_1;
	R9299[26] = (char *(*)()) F1222_11080_9299_1;
	R9299[27] = (char *(*)()) F1223_11080_9299_1;
	R9299[28] = (char *(*)()) F1224_11080_9299_1;
	R9299[29] = (char *(*)()) F1225_11080_9299_1;
	R9299[30] = (char *(*)()) F1226_11080_9299_1;
	R9299[31] = (char *(*)()) F1227_11080_9299_1;
	R9299[32] = (char *(*)()) F1228_11080_9299_1;
	R9299[33] = (char *(*)()) F1229_11080_9299_1;
}
static EIF_REFERENCE F1197_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1197_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1130,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1130, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1198_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1198_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1199_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1199_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1200_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1200_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1201_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1201_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1202_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1202_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1203_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1203_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1204_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1204_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1205_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1205_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1318, 0x00).id, 1318, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1206_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1206_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1315, 0x00).id, 1315, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1207_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1207_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1208_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1208_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1309, 0x00).id, 1309, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1209_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1209_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1210_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1211_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1211_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1216_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1216_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1132,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1132, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1217_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1217_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1134,1309,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1134, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1218_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1218_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1136,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1136, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1219_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1219_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1138,1121,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1138, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1220_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1220_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1140,1336,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1140, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1221_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1221_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1142,1330,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1142, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1222_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1222_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1144,1333,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1144, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1223_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1223_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1146,1324,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1146, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1224_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1224_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1148,1327,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1148, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1225_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1225_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1150,1318,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1150, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1226_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1152,1321,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1152, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1227_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1154,1160,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1154, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1228_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1228_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1156,1315,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1156, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1229_11080_9299_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1229_11080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1158,1124,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1158, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}

char *(*R9309[34])();
void R9309_init () {
	R9309[0] = (char *(*)()) F1196_11092;
	R9309[1] = (char *(*)()) F1197_11092;
	R9309[2] = (char *(*)()) F1198_11092;
	R9309[3] = (char *(*)()) F1199_11092;
	R9309[4] = (char *(*)()) F1200_11092;
	R9309[5] = (char *(*)()) F1201_11092;
	R9309[6] = (char *(*)()) F1202_11092;
	R9309[7] = (char *(*)()) F1203_11092;
	R9309[8] = (char *(*)()) F1204_11092;
	R9309[9] = (char *(*)()) F1205_11092;
	R9309[10] = (char *(*)()) F1206_11092;
	R9309[11] = (char *(*)()) F1207_11092;
	R9309[12] = (char *(*)()) F1208_11092;
	R9309[13] = (char *(*)()) F1209_11092;
	R9309[14] = (char *(*)()) F1210_11092;
	R9309[15] = (char *(*)()) F1211_11092;
	R9309[16] = (char *(*)()) F1212_11092;
	R9309[17] = (char *(*)()) F1213_11092;
	R9309[18] = (char *(*)()) F1214_11092;
	R9309[19] = (char *(*)()) F1215_11092;
	R9309[20] = (char *(*)()) F1216_11092;
	R9309[21] = (char *(*)()) F1217_11092;
	R9309[22] = (char *(*)()) F1218_11092;
	R9309[23] = (char *(*)()) F1219_11092;
	R9309[24] = (char *(*)()) F1220_11092;
	R9309[25] = (char *(*)()) F1221_11092;
	R9309[26] = (char *(*)()) F1222_11092;
	R9309[27] = (char *(*)()) F1223_11092;
	R9309[28] = (char *(*)()) F1224_11092;
	R9309[29] = (char *(*)()) F1225_11092;
	R9309[30] = (char *(*)()) F1226_11092;
	R9309[31] = (char *(*)()) F1227_11092;
	R9309[32] = (char *(*)()) F1228_11092;
	R9309[33] = (char *(*)()) F1229_11092;
}

char *(*R9311[12])();
void R9311_init () {
	R9311[0] = (char *(*)()) F1231_11110;
	R9311[1] = (char *(*)()) F1232_11110;
	R9311[2] = (char *(*)()) F1233_11110;
	R9311[3] = (char *(*)()) F1234_11110;
	R9311[4] = (char *(*)()) F1235_11110;
	R9311[5] = (char *(*)()) F1236_11110;
	R9311[6] = (char *(*)()) F1237_11110;
	R9311[7] = (char *(*)()) F1238_11110;
	R9311[8] = (char *(*)()) F1239_11110;
	R9311[9] = (char *(*)()) F1240_11110;
	R9311[10] = (char *(*)()) F1241_11110;
	R9311[11] = (char *(*)()) F1242_11110;
}

char *(*R9312[12])();
void R9312_init () {
	R9312[0] = (char *(*)()) F1231_11111;
	R9312[1] = (char *(*)()) F1232_11111;
	R9312[2] = (char *(*)()) F1233_11111;
	R9312[3] = (char *(*)()) F1234_11111;
	R9312[4] = (char *(*)()) F1235_11111;
	R9312[5] = (char *(*)()) F1236_11111;
	R9312[6] = (char *(*)()) F1237_11111;
	R9312[7] = (char *(*)()) F1238_11111;
	R9312[8] = (char *(*)()) F1239_11111;
	R9312[9] = (char *(*)()) F1240_11111;
	R9312[10] = (char *(*)()) F1241_11111;
	R9312[11] = (char *(*)()) F1242_11111;
}

char *(*R9314[12])();
void R9314_init () {
	R9314[0] = (char *(*)()) F1231_11097;
	R9314[1] = (char *(*)()) F1232_11097;
	R9314[2] = (char *(*)()) F1233_11097;
	R9314[3] = (char *(*)()) F1234_11097;
	R9314[4] = (char *(*)()) F1235_11097;
	R9314[5] = (char *(*)()) F1236_11097;
	R9314[6] = (char *(*)()) F1237_11097;
	R9314[7] = (char *(*)()) F1238_11097;
	R9314[8] = (char *(*)()) F1239_11097;
	R9314[9] = (char *(*)()) F1240_11097;
	R9314[10] = (char *(*)()) F1241_11097;
	R9314[11] = (char *(*)()) F1242_11097;
}

char *(*R9315[12])();
void R9315_init () {
	R9315[0] = (char *(*)()) F1231_11098;
	R9315[1] = (char *(*)()) F1232_11098_9315_67;
	R9315[2] = (char *(*)()) F1233_11098_9315_67;
	R9315[3] = (char *(*)()) F1234_11098_9315_67;
	R9315[4] = (char *(*)()) F1235_11098_9315_67;
	R9315[5] = (char *(*)()) F1236_11098_9315_67;
	R9315[6] = (char *(*)()) F1237_11098_9315_67;
	R9315[7] = (char *(*)()) F1238_11098_9315_67;
	R9315[8] = (char *(*)()) F1239_11098_9315_67;
	R9315[9] = (char *(*)()) F1240_11098_9315_67;
	R9315[10] = (char *(*)()) F1241_11098_9315_67;
	R9315[11] = (char *(*)()) F1242_11098_9315_67;
}
static void F1232_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1232_11098(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1233_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1233_11098(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1234_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1234_11098(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1235_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1235_11098(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1236_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1236_11098(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1237_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1237_11098(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1238_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1238_11098(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1239_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1239_11098(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1240_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1240_11098(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1241_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1241_11098(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1242_11098_9315_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1242_11098(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R9324[12])();
void R9324_init () {
	R9324[0] = (char *(*)()) F1231_11113;
	R9324[1] = (char *(*)()) F1232_11113;
	R9324[2] = (char *(*)()) F1233_11113;
	R9324[3] = (char *(*)()) F1234_11113;
	R9324[4] = (char *(*)()) F1235_11113;
	R9324[5] = (char *(*)()) F1236_11113;
	R9324[6] = (char *(*)()) F1237_11113;
	R9324[7] = (char *(*)()) F1238_11113;
	R9324[8] = (char *(*)()) F1239_11113;
	R9324[9] = (char *(*)()) F1240_11113;
	R9324[10] = (char *(*)()) F1241_11113;
	R9324[11] = (char *(*)()) F1242_11113;
}

char *(*R9325[12])();
void R9325_init () {
	R9325[0] = (char *(*)()) F1231_11115;
	R9325[1] = (char *(*)()) F1232_11115_9325_67;
	R9325[2] = (char *(*)()) F1233_11115_9325_67;
	R9325[3] = (char *(*)()) F1234_11115_9325_67;
	R9325[4] = (char *(*)()) F1235_11115_9325_67;
	R9325[5] = (char *(*)()) F1236_11115_9325_67;
	R9325[6] = (char *(*)()) F1237_11115_9325_67;
	R9325[7] = (char *(*)()) F1238_11115_9325_67;
	R9325[8] = (char *(*)()) F1239_11115_9325_67;
	R9325[9] = (char *(*)()) F1240_11115_9325_67;
	R9325[10] = (char *(*)()) F1241_11115_9325_67;
	R9325[11] = (char *(*)()) F1242_11115_9325_67;
}
static void F1232_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1232_11115(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1233_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1233_11115(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1234_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1234_11115(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1235_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1235_11115(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1236_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1236_11115(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1237_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1237_11115(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1238_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1238_11115(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1239_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1239_11115(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1240_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1240_11115(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1241_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1241_11115(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1242_11115_9325_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1242_11115(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R9326[12])();
void R9326_init () {
	R9326[0] = (char *(*)()) F1231_11116;
	R9326[1] = (char *(*)()) F1232_11116_9326_67;
	R9326[2] = (char *(*)()) F1233_11116_9326_67;
	R9326[3] = (char *(*)()) F1234_11116_9326_67;
	R9326[4] = (char *(*)()) F1235_11116_9326_67;
	R9326[5] = (char *(*)()) F1236_11116_9326_67;
	R9326[6] = (char *(*)()) F1237_11116_9326_67;
	R9326[7] = (char *(*)()) F1238_11116_9326_67;
	R9326[8] = (char *(*)()) F1239_11116_9326_67;
	R9326[9] = (char *(*)()) F1240_11116_9326_67;
	R9326[10] = (char *(*)()) F1241_11116_9326_67;
	R9326[11] = (char *(*)()) F1242_11116_9326_67;
}
static void F1232_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1232_11116(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1233_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1233_11116(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1234_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1234_11116(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1235_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1235_11116(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1236_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1236_11116(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1237_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1237_11116(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1238_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1238_11116(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1239_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1239_11116(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1240_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1240_11116(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1241_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1241_11116(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1242_11116_9326_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1242_11116(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R9327[12])();
void R9327_init () {
	R9327[0] = (char *(*)()) F1231_11117;
	R9327[1] = (char *(*)()) F1232_11117_9327_4;
	R9327[2] = (char *(*)()) F1233_11117_9327_4;
	R9327[3] = (char *(*)()) F1234_11117_9327_4;
	R9327[4] = (char *(*)()) F1235_11117_9327_4;
	R9327[5] = (char *(*)()) F1236_11117_9327_4;
	R9327[6] = (char *(*)()) F1237_11117_9327_4;
	R9327[7] = (char *(*)()) F1238_11117_9327_4;
	R9327[8] = (char *(*)()) F1239_11117_9327_4;
	R9327[9] = (char *(*)()) F1240_11117_9327_4;
	R9327[10] = (char *(*)()) F1241_11117_9327_4;
	R9327[11] = (char *(*)()) F1242_11117_9327_4;
}
static void F1232_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1232_11117(Current, *(EIF_POINTER *)arg1);
}
static void F1233_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1233_11117(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1234_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1234_11117(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1235_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1235_11117(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1236_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1236_11117(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1237_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1237_11117(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1238_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1238_11117(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1239_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1239_11117(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1240_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1240_11117(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1241_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1241_11117(Current, *(EIF_REAL_32 *)arg1);
}
static void F1242_11117_9327_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1242_11117(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R9329[12])();
void R9329_init () {
	R9329[0] = (char *(*)()) F1231_11119;
	R9329[1] = (char *(*)()) F1232_11119_9329_22;
	R9329[2] = (char *(*)()) F1233_11119_9329_22;
	R9329[3] = (char *(*)()) F1234_11119_9329_22;
	R9329[4] = (char *(*)()) F1235_11119_9329_22;
	R9329[5] = (char *(*)()) F1236_11119_9329_22;
	R9329[6] = (char *(*)()) F1237_11119_9329_22;
	R9329[7] = (char *(*)()) F1238_11119_9329_22;
	R9329[8] = (char *(*)()) F1239_11119_9329_22;
	R9329[9] = (char *(*)()) F1240_11119_9329_22;
	R9329[10] = (char *(*)()) F1241_11119_9329_22;
	R9329[11] = (char *(*)()) F1242_11119_9329_22;
}
static void F1232_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1232_11119(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1233_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1233_11119(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1234_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1234_11119(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1235_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1235_11119(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1236_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1236_11119(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1237_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1237_11119(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1238_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1238_11119(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1239_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1239_11119(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1240_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1240_11119(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1241_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1241_11119(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1242_11119_9329_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1242_11119(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R9330[12])();
void R9330_init () {
	R9330[0] = (char *(*)()) F1231_11120;
	R9330[1] = (char *(*)()) F1232_11120;
	R9330[2] = (char *(*)()) F1233_11120;
	R9330[3] = (char *(*)()) F1234_11120;
	R9330[4] = (char *(*)()) F1235_11120;
	R9330[5] = (char *(*)()) F1236_11120;
	R9330[6] = (char *(*)()) F1237_11120;
	R9330[7] = (char *(*)()) F1238_11120;
	R9330[8] = (char *(*)()) F1239_11120;
	R9330[9] = (char *(*)()) F1240_11120;
	R9330[10] = (char *(*)()) F1241_11120;
	R9330[11] = (char *(*)()) F1242_11120;
}

char *(*R9332[12])();
void R9332_init () {
	R9332[0] = (char *(*)()) F1231_11122;
	R9332[1] = (char *(*)()) F1232_11122;
	R9332[2] = (char *(*)()) F1233_11122;
	R9332[3] = (char *(*)()) F1234_11122;
	R9332[4] = (char *(*)()) F1235_11122;
	R9332[5] = (char *(*)()) F1236_11122;
	R9332[6] = (char *(*)()) F1237_11122;
	R9332[7] = (char *(*)()) F1238_11122;
	R9332[8] = (char *(*)()) F1239_11122;
	R9332[9] = (char *(*)()) F1240_11122;
	R9332[10] = (char *(*)()) F1241_11122;
	R9332[11] = (char *(*)()) F1242_11122;
}

char *(*R9333[12])();
void R9333_init () {
	R9333[0] = (char *(*)()) F1231_11123;
	R9333[1] = (char *(*)()) F1232_11123;
	R9333[2] = (char *(*)()) F1233_11123;
	R9333[3] = (char *(*)()) F1234_11123;
	R9333[4] = (char *(*)()) F1235_11123;
	R9333[5] = (char *(*)()) F1236_11123;
	R9333[6] = (char *(*)()) F1237_11123;
	R9333[7] = (char *(*)()) F1238_11123;
	R9333[8] = (char *(*)()) F1239_11123;
	R9333[9] = (char *(*)()) F1240_11123;
	R9333[10] = (char *(*)()) F1241_11123;
	R9333[11] = (char *(*)()) F1242_11123;
}

char *(*R9334[12])();
void R9334_init () {
	R9334[0] = (char *(*)()) F1231_11124;
	R9334[1] = (char *(*)()) F1232_11124;
	R9334[2] = (char *(*)()) F1233_11124;
	R9334[3] = (char *(*)()) F1234_11124;
	R9334[4] = (char *(*)()) F1235_11124;
	R9334[5] = (char *(*)()) F1236_11124;
	R9334[6] = (char *(*)()) F1237_11124;
	R9334[7] = (char *(*)()) F1238_11124;
	R9334[8] = (char *(*)()) F1239_11124;
	R9334[9] = (char *(*)()) F1240_11124;
	R9334[10] = (char *(*)()) F1241_11124;
	R9334[11] = (char *(*)()) F1242_11124;
}

char *(*R9335[12])();
void R9335_init () {
	R9335[0] = (char *(*)()) F1231_11125;
	R9335[1] = (char *(*)()) F1232_11125;
	R9335[2] = (char *(*)()) F1233_11125;
	R9335[3] = (char *(*)()) F1234_11125;
	R9335[4] = (char *(*)()) F1235_11125;
	R9335[5] = (char *(*)()) F1236_11125;
	R9335[6] = (char *(*)()) F1237_11125;
	R9335[7] = (char *(*)()) F1238_11125;
	R9335[8] = (char *(*)()) F1239_11125;
	R9335[9] = (char *(*)()) F1240_11125;
	R9335[10] = (char *(*)()) F1241_11125;
	R9335[11] = (char *(*)()) F1242_11125;
}

char *(*R9336[12])();
void R9336_init () {
	R9336[0] = (char *(*)()) F1231_11126;
	R9336[1] = (char *(*)()) F1232_11126;
	R9336[2] = (char *(*)()) F1233_11126;
	R9336[3] = (char *(*)()) F1234_11126;
	R9336[4] = (char *(*)()) F1235_11126;
	R9336[5] = (char *(*)()) F1236_11126;
	R9336[6] = (char *(*)()) F1237_11126;
	R9336[7] = (char *(*)()) F1238_11126;
	R9336[8] = (char *(*)()) F1239_11126;
	R9336[9] = (char *(*)()) F1240_11126;
	R9336[10] = (char *(*)()) F1241_11126;
	R9336[11] = (char *(*)()) F1242_11126;
}

char *(*R9339[12])();
void R9339_init () {
	R9339[0] = (char *(*)()) F1231_11129;
	R9339[1] = (char *(*)()) F1232_11129;
	R9339[2] = (char *(*)()) F1233_11129;
	R9339[3] = (char *(*)()) F1234_11129;
	R9339[4] = (char *(*)()) F1235_11129;
	R9339[5] = (char *(*)()) F1236_11129;
	R9339[6] = (char *(*)()) F1237_11129;
	R9339[7] = (char *(*)()) F1238_11129;
	R9339[8] = (char *(*)()) F1239_11129;
	R9339[9] = (char *(*)()) F1240_11129;
	R9339[10] = (char *(*)()) F1241_11129;
	R9339[11] = (char *(*)()) F1242_11129;
}

char *(*R9342[12])();
void R9342_init () {
	R9342[0] = (char *(*)()) F1231_11132;
	R9342[1] = (char *(*)()) F1232_11132;
	R9342[2] = (char *(*)()) F1233_11132;
	R9342[3] = (char *(*)()) F1234_11132;
	R9342[4] = (char *(*)()) F1235_11132;
	R9342[5] = (char *(*)()) F1236_11132;
	R9342[6] = (char *(*)()) F1237_11132;
	R9342[7] = (char *(*)()) F1238_11132;
	R9342[8] = (char *(*)()) F1239_11132;
	R9342[9] = (char *(*)()) F1240_11132;
	R9342[10] = (char *(*)()) F1241_11132;
	R9342[11] = (char *(*)()) F1242_11132;
}

char *(*R9343[12])();
void R9343_init () {
	R9343[0] = (char *(*)()) F1231_11133;
	R9343[1] = (char *(*)()) F1232_11133_9343_8;
	R9343[2] = (char *(*)()) F1233_11133_9343_8;
	R9343[3] = (char *(*)()) F1234_11133_9343_8;
	R9343[4] = (char *(*)()) F1235_11133_9343_8;
	R9343[5] = (char *(*)()) F1236_11133_9343_8;
	R9343[6] = (char *(*)()) F1237_11133_9343_8;
	R9343[7] = (char *(*)()) F1238_11133_9343_8;
	R9343[8] = (char *(*)()) F1239_11133_9343_8;
	R9343[9] = (char *(*)()) F1240_11133_9343_8;
	R9343[10] = (char *(*)()) F1241_11133_9343_8;
	R9343[11] = (char *(*)()) F1242_11133_9343_8;
}
static EIF_REFERENCE F1232_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1232_11133(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1233_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1233_11133(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1234_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1234_11133(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1235_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1235_11133(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1236_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1236_11133(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1237_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1237_11133(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1238_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1238_11133(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1239_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1239_11133(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1240_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1240_11133(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1241_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1241_11133(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1242_11133_9343_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1242_11133(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R9345[12])();
void R9345_init () {
	R9345[0] = (char *(*)()) F1231_11135;
	R9345[1] = (char *(*)()) F1232_11135;
	R9345[2] = (char *(*)()) F1233_11135;
	R9345[3] = (char *(*)()) F1234_11135;
	R9345[4] = (char *(*)()) F1235_11135;
	R9345[5] = (char *(*)()) F1236_11135;
	R9345[6] = (char *(*)()) F1237_11135;
	R9345[7] = (char *(*)()) F1238_11135;
	R9345[8] = (char *(*)()) F1239_11135;
	R9345[9] = (char *(*)()) F1240_11135;
	R9345[10] = (char *(*)()) F1241_11135;
	R9345[11] = (char *(*)()) F1242_11135;
}

char *(*R9347[12])();
void R9347_init () {
	R9347[0] = (char *(*)()) F1231_11137;
	R9347[1] = (char *(*)()) F1232_11137;
	R9347[2] = (char *(*)()) F1233_11137;
	R9347[3] = (char *(*)()) F1234_11137;
	R9347[4] = (char *(*)()) F1235_11137;
	R9347[5] = (char *(*)()) F1236_11137;
	R9347[6] = (char *(*)()) F1237_11137;
	R9347[7] = (char *(*)()) F1238_11137;
	R9347[8] = (char *(*)()) F1239_11137;
	R9347[9] = (char *(*)()) F1240_11137;
	R9347[10] = (char *(*)()) F1241_11137;
	R9347[11] = (char *(*)()) F1242_11137;
}

char *(*R9350[12])();
void R9350_init () {
	R9350[0] = (char *(*)()) F1231_11140;
	R9350[1] = (char *(*)()) F1232_11140;
	R9350[2] = (char *(*)()) F1233_11140;
	R9350[3] = (char *(*)()) F1234_11140;
	R9350[4] = (char *(*)()) F1235_11140;
	R9350[5] = (char *(*)()) F1236_11140;
	R9350[6] = (char *(*)()) F1237_11140;
	R9350[7] = (char *(*)()) F1238_11140;
	R9350[8] = (char *(*)()) F1239_11140;
	R9350[9] = (char *(*)()) F1240_11140;
	R9350[10] = (char *(*)()) F1241_11140;
	R9350[11] = (char *(*)()) F1242_11140;
}

char *(*R9354[12])();
void R9354_init () {
	R9354[0] = (char *(*)()) F1231_11145;
	R9354[1] = (char *(*)()) F1232_11145;
	R9354[2] = (char *(*)()) F1233_11145;
	R9354[3] = (char *(*)()) F1234_11145;
	R9354[4] = (char *(*)()) F1235_11145;
	R9354[5] = (char *(*)()) F1236_11145;
	R9354[6] = (char *(*)()) F1237_11145;
	R9354[7] = (char *(*)()) F1238_11145;
	R9354[8] = (char *(*)()) F1239_11145;
	R9354[9] = (char *(*)()) F1240_11145;
	R9354[10] = (char *(*)()) F1241_11145;
	R9354[11] = (char *(*)()) F1242_11145;
}

char *(*R9377[7])();
void R9377_init () {
	{long i; for (i = 0; i < 3; i++) R9377[i] = (char *(*)()) F1246_11177;}
	R9377[4] = (char *(*)()) F1253_11313;
	{long i; for (i = 5; i < 7; i++) R9377[i] = (char *(*)()) F1246_11177;}
}

char *(*R9379[7])();
void R9379_init () {
	{long i; for (i = 0; i < 3; i++) R9379[i] = (char *(*)()) F1246_11179;}
	R9379[4] = (char *(*)()) F1246_11179;
	{long i; for (i = 5; i < 7; i++) R9379[i] = (char *(*)()) F1254_11341;}
}

char *(*R9381[7])();
void R9381_init () {
	{long i; for (i = 0; i < 3; i++) R9381[i] = (char *(*)()) F1246_11181;}
	R9381[4] = (char *(*)()) F1253_11314;
	{long i; for (i = 5; i < 7; i++) R9381[i] = (char *(*)()) F1246_11181;}
}

char *(*R9384[7])();
void R9384_init () {
	{long i; for (i = 0; i < 2; i++) R9384[i] = (char *(*)()) F1246_11184;}
	R9384[2] = (char *(*)()) F1251_11305;
	{long i; for (i = 4; i < 7; i++) R9384[i] = (char *(*)()) F1246_11184;}
}

char *(*R9392[7])();
void R9392_init () {
	{long i; for (i = 0; i < 3; i++) R9392[i] = (char *(*)()) F1249_11271;}
	R9392[4] = (char *(*)()) F1253_11317;
	{long i; for (i = 5; i < 7; i++) R9392[i] = (char *(*)()) F1254_11342;}
}

char *(*R9404[7])();
void R9404_init () {
	{long i; for (i = 0; i < 3; i++) R9404[i] = (char *(*)()) F1249_11267;}
	R9404[4] = (char *(*)()) F1253_11326;
	{long i; for (i = 5; i < 7; i++) R9404[i] = (char *(*)()) F1254_11347;}
}

char *(*R9405[7])();
void R9405_init () {
	{long i; for (i = 0; i < 3; i++) R9405[i] = (char *(*)()) F1249_11268;}
	R9405[4] = (char *(*)()) F1253_11327;
	{long i; for (i = 5; i < 7; i++) R9405[i] = (char *(*)()) F1246_11206;}
}

char *(*R9551[37])();
void R9551_init () {
	R9551[0] = (char *(*)()) F1303_11441;
	R9551[1] = (char *(*)()) F1304_11446;
	R9551[2] = (char *(*)()) F1305_11460;
	R9551[3] = (char *(*)()) F1306_11490;
	R9551[35] = (char *(*)()) F1338_12449;
	R9551[36] = (char *(*)()) F1339_12464;
}

char *(*R9610[29])();
void R9610_init () {
	R9610[0] = (char *(*)()) F1309_11592_9610_1;
	R9610[1] = (char *(*)()) F1310_11592_9610_1;
	R9610[3] = (char *(*)()) F1312_11691_9610_1;
	R9610[4] = (char *(*)()) F1313_11691_9610_1;
	R9610[6] = (char *(*)()) F1315_11790_9610_1;
	R9610[7] = (char *(*)()) F1316_11790_9610_1;
	R9610[9] = (char *(*)()) F1318_11889_9610_1;
	R9610[10] = (char *(*)()) F1319_11889_9610_1;
	R9610[27] = (char *(*)()) F1336_12412_9610_1;
	R9610[28] = (char *(*)()) F1337_12412_9610_1;
}
static EIF_REFERENCE F1309_11592_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1309_11592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1309, 0x00).id, 1309, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1310_11592_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1310_11592(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1309, 0x00).id, 1309, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1312_11691_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1312_11691(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1313_11691_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1313_11691(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1315_11790_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1315_11790(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1315, 0x00).id, 1315, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1316_11790_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1316_11790(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1315, 0x00).id, 1315, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1318_11889_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1318_11889(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1318, 0x00).id, 1318, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1319_11889_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1319_11889(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1318, 0x00).id, 1318, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1336_12412_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1336_12412(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1337_12412_9610_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1337_12412(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R9629[2])();
void R9629_init () {
	R9629[0] = (char *(*)()) F1309_11598;
	R9629[1] = (char *(*)()) F1310_11598;
}

char *(*R9630[2])();
void R9630_init () {
	R9630[0] = (char *(*)()) F1309_11599;
	R9630[1] = (char *(*)()) F1310_11599;
}

char *(*R9633[2])();
void R9633_init () {
	R9633[0] = (char *(*)()) F1309_11602;
	R9633[1] = (char *(*)()) F1310_11602;
}

char *(*R9683[2])();
void R9683_init () {
	R9683[0] = (char *(*)()) F1312_11695;
	R9683[1] = (char *(*)()) F1313_11695;
}

char *(*R9685[2])();
void R9685_init () {
	R9685[0] = (char *(*)()) F1312_11697;
	R9685[1] = (char *(*)()) F1313_11697;
}

char *(*R9686[2])();
void R9686_init () {
	R9686[0] = (char *(*)()) F1312_11698;
	R9686[1] = (char *(*)()) F1313_11698;
}

char *(*R9690[2])();
void R9690_init () {
	R9690[0] = (char *(*)()) F1312_11702;
	R9690[1] = (char *(*)()) F1313_11702;
}

char *(*R9742[2])();
void R9742_init () {
	R9742[0] = (char *(*)()) F1315_11797;
	R9742[1] = (char *(*)()) F1316_11797;
}

char *(*R9745[2])();
void R9745_init () {
	R9745[0] = (char *(*)()) F1315_11800;
	R9745[1] = (char *(*)()) F1316_11800;
}

char *(*R9795[2])();
void R9795_init () {
	R9795[0] = (char *(*)()) F1318_11893;
	R9795[1] = (char *(*)()) F1319_11893;
}

char *(*R9798[2])();
void R9798_init () {
	R9798[0] = (char *(*)()) F1318_11896;
	R9798[1] = (char *(*)()) F1319_11896;
}

char *(*R9801[2])();
void R9801_init () {
	R9801[0] = (char *(*)()) F1318_11899;
	R9801[1] = (char *(*)()) F1319_11899;
}

char *(*R9849[2])();
void R9849_init () {
	R9849[0] = (char *(*)()) F1321_11987;
	R9849[1] = (char *(*)()) F1322_11987;
}

char *(*R9855[2])();
void R9855_init () {
	R9855[0] = (char *(*)()) F1321_11993;
	R9855[1] = (char *(*)()) F1322_11993;
}

char *(*R9901[2])();
void R9901_init () {
	R9901[0] = (char *(*)()) F1324_12081;
	R9901[1] = (char *(*)()) F1325_12081;
}

char *(*R9902[2])();
void R9902_init () {
	R9902[0] = (char *(*)()) F1324_12082;
	R9902[1] = (char *(*)()) F1325_12082;
}

char *(*R9904[2])();
void R9904_init () {
	R9904[0] = (char *(*)()) F1324_12084;
	R9904[1] = (char *(*)()) F1325_12084;
}

char *(*R9907[2])();
void R9907_init () {
	R9907[0] = (char *(*)()) F1324_12087;
	R9907[1] = (char *(*)()) F1325_12087;
}

char *(*R9908[2])();
void R9908_init () {
	R9908[0] = (char *(*)()) F1324_12088;
	R9908[1] = (char *(*)()) F1325_12088;
}

char *(*R9956[2])();
void R9956_init () {
	R9956[0] = (char *(*)()) F1327_12178;
	R9956[1] = (char *(*)()) F1328_12178;
}

char *(*R9957[2])();
void R9957_init () {
	R9957[0] = (char *(*)()) F1327_12179;
	R9957[1] = (char *(*)()) F1328_12179;
}

char *(*R9960[2])();
void R9960_init () {
	R9960[0] = (char *(*)()) F1327_12182;
	R9960[1] = (char *(*)()) F1328_12182;
}

char *(*R10008[2])();
void R10008_init () {
	R10008[0] = (char *(*)()) F1330_12272;
	R10008[1] = (char *(*)()) F1331_12272;
}

char *(*R10009[2])();
void R10009_init () {
	R10009[0] = (char *(*)()) F1330_12273;
	R10009[1] = (char *(*)()) F1331_12273;
}

char *(*R10010[2])();
void R10010_init () {
	R10010[0] = (char *(*)()) F1330_12274;
	R10010[1] = (char *(*)()) F1331_12274;
}

char *(*R10011[2])();
void R10011_init () {
	R10011[0] = (char *(*)()) F1330_12275;
	R10011[1] = (char *(*)()) F1331_12275;
}

char *(*R10013[2])();
void R10013_init () {
	R10013[0] = (char *(*)()) F1330_12277;
	R10013[1] = (char *(*)()) F1331_12277;
}

char *(*R10059[2])();
void R10059_init () {
	R10059[0] = (char *(*)()) F1333_12335;
	R10059[1] = (char *(*)()) F1334_12335;
}

char *(*R10093[2])();
void R10093_init () {
	R10093[0] = (char *(*)()) F1336_12401;
	R10093[1] = (char *(*)()) F1337_12401;
}

char *(*R10100[2])();
void R10100_init () {
	R10100[0] = (char *(*)()) F1336_12405;
	R10100[1] = (char *(*)()) F1337_12405;
}

char *(*R10220[3])();
void R10220_init () {
	R10220[0] = (char *(*)()) F1351_12548;
	R10220[1] = (char *(*)()) F1352_12548;
	R10220[2] = (char *(*)()) F1353_12548;
}

char *(*R10222[3])();
void R10222_init () {
	R10222[0] = (char *(*)()) F1351_12550;
	R10222[1] = (char *(*)()) F1352_12550_10222_2;
	R10222[2] = (char *(*)()) F1353_12550_10222_2;
}
static EIF_BOOLEAN F1352_12550_10222_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1352_12550(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1353_12550_10222_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1353_12550(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R10227[3])();
void R10227_init () {
	R10227[0] = (char *(*)()) F1351_12555;
	R10227[1] = (char *(*)()) F1352_12555_10227_1;
	R10227[2] = (char *(*)()) F1353_12555_10227_1;
}
static EIF_REFERENCE F1352_12555_10227_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1352_12555(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1353_12555_10227_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1353_12555(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R10231[3])();
void R10231_init () {
	R10231[0] = (char *(*)()) F1351_12561;
	R10231[1] = (char *(*)()) F1352_12561_10231_3;
	R10231[2] = (char *(*)()) F1353_12561_10231_3;
}
static EIF_BOOLEAN F1352_12561_10231_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1352_12561(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}
static EIF_BOOLEAN F1353_12561_10231_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1353_12561(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R10232[3])();
void R10232_init () {
	R10232[0] = (char *(*)()) F1351_12562;
	R10232[1] = (char *(*)()) F1352_12562_10232_4;
	R10232[2] = (char *(*)()) F1353_12562_10232_4;
}
static void F1352_12562_10232_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1352_12562(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1353_12562_10232_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1353_12562(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R10240[3])();
void R10240_init () {
	R10240[0] = (char *(*)()) F1351_12570;
	R10240[1] = (char *(*)()) F1352_12570;
	R10240[2] = (char *(*)()) F1353_12570;
}

char *(*R10242[3])();
void R10242_init () {
	R10242[0] = (char *(*)()) F1351_12573;
	R10242[1] = (char *(*)()) F1352_12573;
	R10242[2] = (char *(*)()) F1353_12573;
}

char *(*R10245[3])();
void R10245_init () {
	R10245[0] = (char *(*)()) F1351_12576;
	R10245[1] = (char *(*)()) F1352_12576_10245_4;
	R10245[2] = (char *(*)()) F1353_12576_10245_4;
}
static void F1352_12576_10245_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1352_12576(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1353_12576_10245_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1353_12576(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R10246[3])();
void R10246_init () {
	R10246[0] = (char *(*)()) F1351_12577;
	R10246[1] = (char *(*)()) F1352_12577;
	R10246[2] = (char *(*)()) F1353_12577;
}

char *(*R10248[3])();
void R10248_init () {
	R10248[0] = (char *(*)()) F1351_12579;
	R10248[1] = (char *(*)()) F1352_12579;
	R10248[2] = (char *(*)()) F1353_12579;
}

char *(*R10249[3])();
void R10249_init () {
	R10249[0] = (char *(*)()) F1351_12580;
	R10249[1] = (char *(*)()) F1352_12580_10249_2;
	R10249[2] = (char *(*)()) F1353_12580_10249_2;
}
static EIF_BOOLEAN F1352_12580_10249_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1352_12580(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1353_12580_10249_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1353_12580(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R10263[3])();
void R10263_init () {
	R10263[0] = (char *(*)()) F1351_12594;
	R10263[1] = (char *(*)()) F1352_12594;
	R10263[2] = (char *(*)()) F1353_12594;
}

char *(*R10264[3])();
void R10264_init () {
	R10264[0] = (char *(*)()) F1351_12595;
	R10264[1] = (char *(*)()) F1352_12595;
	R10264[2] = (char *(*)()) F1353_12595;
}

char *(*R10742[3])();
void R10742_init () {
	R10742[0] = (char *(*)()) F1377_13211;
	{long i; for (i = 1; i < 3; i++) R10742[i] = (char *(*)()) F1378_13239;}
}

char *(*R10747[3])();
void R10747_init () {
	R10747[0] = (char *(*)()) F1377_13212;
	{long i; for (i = 1; i < 3; i++) R10747[i] = (char *(*)()) F1378_13234;}
}

char *(*R10749[3])();
void R10749_init () {
	R10749[0] = (char *(*)()) F1377_13213;
	{long i; for (i = 1; i < 3; i++) R10749[i] = (char *(*)()) F1378_13235;}
}

char *(*R10827[2])();
void R10827_init () {
	R10827[0] = (char *(*)()) F1381_13307;
	R10827[1] = (char *(*)()) F1382_13354;
}

char *(*R10885[2])();
void R10885_init () {
	R10885[0] = (char *(*)()) F1384_13427;
	R10885[1] = (char *(*)()) F1385_13444;
}

char *(*R10900[2])();
void R10900_init () {
	R10900[0] = (char *(*)()) F1384_13432;
	R10900[1] = (char *(*)()) F1385_13452;
}

char *(*R10902[2])();
void R10902_init () {
	R10902[0] = (char *(*)()) F1384_13434;
	R10902[1] = (char *(*)()) F1385_13454;
}

char *(*R10908[2])();
void R10908_init () {
	R10908[0] = (char *(*)()) F1384_13440;
	R10908[1] = (char *(*)()) F1385_13460;
}

char *(*R10910[2])();
void R10910_init () {
	R10910[0] = (char *(*)()) F1384_13428;
	R10910[1] = (char *(*)()) F1385_13445;
}

char *(*R12179[3])();
void R12179_init () {
	{long i; for (i = 0; i < 2; i++) R12179[i] = (char *(*)()) F1429_14873;}
	R12179[2] = (char *(*)()) F1431_14941;
}

char *(*R12245[14])();
void R12245_init () {
	R12245[0] = (char *(*)()) F1433_14949;
	R12245[1] = (char *(*)()) F1434_14956;
	R12245[2] = (char *(*)()) F1435_14960;
	R12245[3] = (char *(*)()) F1436_14963;
	R12245[4] = (char *(*)()) F1437_14967;
	R12245[5] = (char *(*)()) F1438_14971;
	R12245[6] = (char *(*)()) F1439_14974;
	R12245[7] = (char *(*)()) F1440_14977;
	R12245[8] = (char *(*)()) F1441_14980;
	R12245[9] = (char *(*)()) F1442_14984;
	R12245[10] = (char *(*)()) F1443_14988;
	R12245[11] = (char *(*)()) F1444_15009;
	{long i; for (i = 12; i < 14; i++) R12245[i] = (char *(*)()) F1445_15019;}
}

char *(*R12247[14])();
void R12247_init () {
	R12247[0] = (char *(*)()) F1433_14950;
	R12247[1] = (char *(*)()) F1434_14957;
	R12247[2] = (char *(*)()) F1435_14961;
	R12247[3] = (char *(*)()) F1436_14964;
	R12247[4] = (char *(*)()) F1437_14968;
	R12247[5] = (char *(*)()) F1438_14972;
	R12247[6] = (char *(*)()) F1439_14975;
	R12247[7] = (char *(*)()) F1440_14978;
	R12247[8] = (char *(*)()) F1441_14982;
	R12247[9] = (char *(*)()) F1442_14985;
	R12247[10] = (char *(*)()) F1443_14989;
	R12247[11] = (char *(*)()) F1444_15010;
	{long i; for (i = 12; i < 14; i++) R12247[i] = (char *(*)()) F1445_15024;}
}

char *(*R12302[2])();
void R12302_init () {
	R12302[0] = (char *(*)()) F1445_15027;
	R12302[1] = (char *(*)()) F1446_15040;
}
char *(*R2[1453])();
void R2_init () {}
char *(*R6[1453])();
void R6_init () {}

char *(*R3[1453])();
void R3_init () {
	R3[543] = (char *(*)()) F544_6529;
	R3[544] = (char *(*)()) F545_6540;
	R3[545] = (char *(*)()) F546_6550;
	R3[546] = (char *(*)()) F547_6643;
	R3[549] = (char *(*)()) F548_6650;
	R3[552] = (char *(*)()) F552_6706;
	{long i; for (i = 554; i < 556; i++) R3[i] = (char *(*)()) F554_6780;}
	{long i; for (i = 557; i < 560; i++) R3[i] = (char *(*)()) F557_6816;}
	R3[560] = (char *(*)()) F561_6838;
	R3[561] = (char *(*)()) F562_6874;
	R3[563] = (char *(*)()) F564_6998;
	{long i; for (i = 568; i < 570; i++) R3[i] = (char *(*)()) F563_6935;}
	{long i; for (i = 936; i < 938; i++) R3[i] = (char *(*)()) F563_6935;}
	R3[1176] = (char *(*)()) F561_6838;
	R3[1354] = (char *(*)()) F1355_12650;
}

char *(*R4[1453])();
void R4_init () {
	{long i; for (i = 1; i < 3; i++) R4[i] = (char *(*)()) F1_15;}
	R4[9] = (char *(*)()) F1_15;
	{long i; for (i = 11; i < 18; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 19; i < 32; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 33; i < 37; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 39; i < 48; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 50; i < 54; i++) R4[i] = (char *(*)()) F1_15;}
	R4[55] = (char *(*)()) F1_15;
	{long i; for (i = 57; i < 64; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 65; i < 79; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 80; i < 82; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 84; i < 87; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 99; i < 101; i++) R4[i] = (char *(*)()) F1_15;}
	R4[103] = (char *(*)()) F1_15;
	R4[107] = (char *(*)()) F1_15;
	R4[111] = (char *(*)()) F1_15;
	R4[115] = (char *(*)()) F1_15;
	R4[120] = (char *(*)()) F1_15;
	{long i; for (i = 128; i < 130; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 148; i < 151; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 159; i < 161; i++) R4[i] = (char *(*)()) F1_15;}
	R4[165] = (char *(*)()) F1_15;
	R4[167] = (char *(*)()) F1_15;
	R4[170] = (char *(*)()) F1_15;
	R4[174] = (char *(*)()) F1_15;
	{long i; for (i = 185; i < 189; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 190; i < 192; i++) R4[i] = (char *(*)()) F1_15;}
	R4[197] = (char *(*)()) F1_15;
	{long i; for (i = 204; i < 213; i++) R4[i] = (char *(*)()) F1_15;}
	R4[216] = (char *(*)()) F1_15;
	{long i; for (i = 218; i < 220; i++) R4[i] = (char *(*)()) F1_15;}
	R4[222] = (char *(*)()) F1_15;
	R4[229] = (char *(*)()) F1_15;
	{long i; for (i = 246; i < 248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 249; i < 251; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 252; i < 254; i++) R4[i] = (char *(*)()) F1_15;}
	R4[257] = (char *(*)()) F1_15;
	R4[263] = (char *(*)()) F1_15;
	R4[265] = (char *(*)()) F1_15;
	R4[269] = (char *(*)()) F1_15;
	{long i; for (i = 271; i < 273; i++) R4[i] = (char *(*)()) F1_15;}
	R4[278] = (char *(*)()) F1_15;
	{long i; for (i = 280; i < 282; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 288; i < 292; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 293; i < 296; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 297; i < 299; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 300; i < 303; i++) R4[i] = (char *(*)()) F1_15;}
	R4[304] = (char *(*)()) F1_15;
	R4[317] = (char *(*)()) F1_15;
	R4[318] = (char *(*)()) F110_1931;
	R4[327] = (char *(*)()) F1_15;
	R4[332] = (char *(*)()) F1_15;
	{long i; for (i = 334; i < 336; i++) R4[i] = (char *(*)()) F1_15;}
	R4[339] = (char *(*)()) F1_15;
	{long i; for (i = 343; i < 345; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 346; i < 348; i++) R4[i] = (char *(*)()) F1_15;}
	R4[349] = (char *(*)()) F1_15;
	{long i; for (i = 351; i < 354; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 355; i < 357; i++) R4[i] = (char *(*)()) F1_15;}
	R4[359] = (char *(*)()) F1_15;
	{long i; for (i = 361; i < 364; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 365; i < 368; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 369; i < 371; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 373; i < 375; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 376; i < 379; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 380; i < 384; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 385; i < 391; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 392; i < 398; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 399; i < 403; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 408; i < 411; i++) R4[i] = (char *(*)()) F1_15;}
	R4[412] = (char *(*)()) F1_15;
	{long i; for (i = 415; i < 417; i++) R4[i] = (char *(*)()) F1_15;}
	R4[418] = (char *(*)()) F1_15;
	R4[421] = (char *(*)()) F1_15;
	{long i; for (i = 429; i < 431; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 432; i < 439; i++) R4[i] = (char *(*)()) F1_15;}
	R4[441] = (char *(*)()) F1_15;
	R4[446] = (char *(*)()) F1_15;
	R4[448] = (char *(*)()) F1_15;
	{long i; for (i = 453; i < 460; i++) R4[i] = (char *(*)()) F1_15;}
	R4[475] = (char *(*)()) F476_6160;
	{long i; for (i = 478; i < 480; i++) R4[i] = (char *(*)()) F1_15;}
	R4[482] = (char *(*)()) F1_15;
	R4[484] = (char *(*)()) F1_15;
	R4[486] = (char *(*)()) F1_15;
	R4[488] = (char *(*)()) F1_15;
	R4[490] = (char *(*)()) F1_15;
	R4[492] = (char *(*)()) F1_15;
	R4[494] = (char *(*)()) F1_15;
	{long i; for (i = 497; i < 499; i++) R4[i] = (char *(*)()) F1_15;}
	R4[502] = (char *(*)()) F1_15;
	{long i; for (i = 515; i < 519; i++) R4[i] = (char *(*)()) F1_15;}
	R4[529] = (char *(*)()) F1_15;
	{long i; for (i = 543; i < 546; i++) R4[i] = (char *(*)()) F1_15;}
	R4[546] = (char *(*)()) F547_6562;
	R4[549] = (char *(*)()) F1_15;
	R4[552] = (char *(*)()) F1_15;
	{long i; for (i = 554; i < 556; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 557; i < 560; i++) R4[i] = (char *(*)()) F1_15;}
	R4[560] = (char *(*)()) F561_6837;
	R4[561] = (char *(*)()) F1_15;
	R4[563] = (char *(*)()) F1_15;
	{long i; for (i = 568; i < 570; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 577; i < 582; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 583; i < 586; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 587; i < 589; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 591; i < 593; i++) R4[i] = (char *(*)()) F1_15;}
	R4[593] = (char *(*)()) F594_7652;
	R4[594] = (char *(*)()) F595_7688;
	{long i; for (i = 635; i < 658; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 670; i < 709; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 710; i < 712; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 867; i < 869; i++) R4[i] = (char *(*)()) F1_15;}
	R4[908] = (char *(*)()) F909_8164;
	{long i; for (i = 936; i < 938; i++) R4[i] = (char *(*)()) F1_15;}
	R4[947] = (char *(*)()) F1_15;
	R4[960] = (char *(*)()) F961_8615;
	R4[961] = (char *(*)()) F962_8615;
	R4[962] = (char *(*)()) F963_8615;
	R4[963] = (char *(*)()) F964_8615;
	R4[964] = (char *(*)()) F965_8615;
	R4[965] = (char *(*)()) F966_8615;
	R4[966] = (char *(*)()) F967_8615;
	R4[967] = (char *(*)()) F968_8615;
	R4[968] = (char *(*)()) F969_8615;
	{long i; for (i = 969; i < 971; i++) R4[i] = (char *(*)()) F961_8615;}
	R4[971] = (char *(*)()) F964_8615;
	R4[972] = (char *(*)()) F968_8615;
	R4[973] = (char *(*)()) F966_8615;
	R4[974] = (char *(*)()) F969_8615;
	R4[987] = (char *(*)()) F988_8717;
	R4[988] = (char *(*)()) F989_8782;
	R4[989] = (char *(*)()) F990_8782;
	R4[990] = (char *(*)()) F991_8782;
	R4[991] = (char *(*)()) F992_8782;
	R4[992] = (char *(*)()) F993_8782;
	R4[993] = (char *(*)()) F994_8782;
	R4[994] = (char *(*)()) F995_8782;
	R4[995] = (char *(*)()) F996_8782;
	R4[996] = (char *(*)()) F997_8782;
	R4[997] = (char *(*)()) F998_8782;
	R4[998] = (char *(*)()) F999_8782;
	R4[999] = (char *(*)()) F1000_8782;
	R4[1053] = (char *(*)()) F1054_8875;
	R4[1054] = (char *(*)()) F1055_8875;
	R4[1055] = (char *(*)()) F1054_8875;
	R4[1056] = (char *(*)()) F1055_8875;
	R4[1057] = (char *(*)()) F1054_8875;
	R4[1058] = (char *(*)()) F1059_8959;
	R4[1059] = (char *(*)()) F1060_8959;
	R4[1060] = (char *(*)()) F1061_8959;
	R4[1061] = (char *(*)()) F1062_8959;
	R4[1062] = (char *(*)()) F1063_8959;
	R4[1063] = (char *(*)()) F1064_8959;
	R4[1064] = (char *(*)()) F1065_8959;
	R4[1065] = (char *(*)()) F1066_8959;
	R4[1066] = (char *(*)()) F1067_8959;
	R4[1067] = (char *(*)()) F1068_8959;
	R4[1068] = (char *(*)()) F1069_8959;
	R4[1069] = (char *(*)()) F1070_8959;
	{long i; for (i = 1070; i < 1073; i++) R4[i] = (char *(*)()) F1059_8959;}
	R4[1073] = (char *(*)()) F1062_8959;
	R4[1074] = (char *(*)()) F1059_8959;
	R4[1075] = (char *(*)()) F1_15;
	R4[1079] = (char *(*)()) F1_15;
	R4[1086] = (char *(*)()) F1_15;
	{long i; for (i = 1095; i < 1100; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1101; i < 1104; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1107] = (char *(*)()) F1_15;
	{long i; for (i = 1109; i < 1111; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1113] = (char *(*)()) F1_15;
	{long i; for (i = 1116; i < 1119; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1120; i < 1122; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1123; i < 1125; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1126; i < 1128; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1129; i < 1161; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1162] = (char *(*)()) F1162_9969;
	R4[1163] = (char *(*)()) F1164_10001;
	R4[1164] = (char *(*)()) F1165_10001;
	R4[1165] = (char *(*)()) F1166_10001;
	R4[1166] = (char *(*)()) F1165_10001;
	R4[1171] = (char *(*)()) F1172_10195;
	R4[1172] = (char *(*)()) F1171_10176;
	R4[1174] = (char *(*)()) F1175_10360;
	{long i; for (i = 1175; i < 1177; i++) R4[i] = (char *(*)()) F1174_10344;}
	{long i; for (i = 1179; i < 1188; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1190; i < 1193; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1193] = (char *(*)()) F1194_11027;
	{long i; for (i = 1194; i < 1229; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1230; i < 1242; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1244] = (char *(*)()) F1_15;
	{long i; for (i = 1248; i < 1251; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1252; i < 1255; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1302; i < 1306; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1308; i < 1310; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1311; i < 1313; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1314; i < 1316; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1317; i < 1319; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1320; i < 1322; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1323; i < 1325; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1326; i < 1328; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1329; i < 1331; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1332; i < 1334; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1335; i < 1339; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1344; i < 1350; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1350] = (char *(*)()) F1351_12572;
	R4[1351] = (char *(*)()) F1352_12572;
	R4[1352] = (char *(*)()) F1353_12572;
	{long i; for (i = 1353; i < 1355; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1371] = (char *(*)()) F1_15;
	R4[1374] = (char *(*)()) F1_15;
	{long i; for (i = 1376; i < 1379; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1380; i < 1382; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1383; i < 1385; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1399; i < 1401; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1403] = (char *(*)()) F1_15;
	{long i; for (i = 1405; i < 1407; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1408] = (char *(*)()) F1_15;
	R4[1412] = (char *(*)()) F1_15;
	R4[1420] = (char *(*)()) F1_15;
	R4[1422] = (char *(*)()) F1_15;
	R4[1424] = (char *(*)()) F1_15;
	R4[1427] = (char *(*)()) F1428_14832;
	{long i; for (i = 1428; i < 1431; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1432; i < 1447; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1448] = (char *(*)()) F1_15;
	R4[1451] = (char *(*)()) F1452_15348;
}

char *(*R5[1453])();
void R5_init () {
	{long i; for (i = 1; i < 3; i++) R5[i] = (char *(*)()) F1_8;}
	R5[9] = (char *(*)()) F1_8;
	{long i; for (i = 11; i < 18; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 19; i < 32; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 33; i < 37; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 39; i < 48; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 50; i < 54; i++) R5[i] = (char *(*)()) F1_8;}
	R5[55] = (char *(*)()) F1_8;
	{long i; for (i = 57; i < 61; i++) R5[i] = (char *(*)()) F1_8;}
	R5[61] = (char *(*)()) F62_1288;
	{long i; for (i = 62; i < 64; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 65; i < 79; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 80; i < 82; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 84; i < 87; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 99; i < 101; i++) R5[i] = (char *(*)()) F1_8;}
	R5[103] = (char *(*)()) F1_8;
	R5[107] = (char *(*)()) F1_8;
	R5[111] = (char *(*)()) F1_8;
	R5[115] = (char *(*)()) F1_8;
	R5[120] = (char *(*)()) F1_8;
	{long i; for (i = 128; i < 130; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 148; i < 151; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 159; i < 161; i++) R5[i] = (char *(*)()) F1_8;}
	R5[165] = (char *(*)()) F1_8;
	R5[167] = (char *(*)()) F1_8;
	R5[170] = (char *(*)()) F1_8;
	R5[174] = (char *(*)()) F1_8;
	{long i; for (i = 185; i < 189; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 190; i < 192; i++) R5[i] = (char *(*)()) F1_8;}
	R5[197] = (char *(*)()) F1_8;
	{long i; for (i = 204; i < 213; i++) R5[i] = (char *(*)()) F1_8;}
	R5[216] = (char *(*)()) F1_8;
	{long i; for (i = 218; i < 220; i++) R5[i] = (char *(*)()) F1_8;}
	R5[222] = (char *(*)()) F1_8;
	R5[229] = (char *(*)()) F1_8;
	{long i; for (i = 246; i < 248; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 249; i < 251; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 252; i < 254; i++) R5[i] = (char *(*)()) F1_8;}
	R5[257] = (char *(*)()) F1_8;
	R5[263] = (char *(*)()) F1_8;
	R5[265] = (char *(*)()) F1_8;
	R5[269] = (char *(*)()) F1_8;
	{long i; for (i = 271; i < 273; i++) R5[i] = (char *(*)()) F1_8;}
	R5[278] = (char *(*)()) F1_8;
	{long i; for (i = 280; i < 282; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 288; i < 292; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 293; i < 296; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 297; i < 299; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 300; i < 303; i++) R5[i] = (char *(*)()) F1_8;}
	R5[304] = (char *(*)()) F1_8;
	R5[317] = (char *(*)()) F1_8;
	R5[318] = (char *(*)()) F110_1928;
	R5[327] = (char *(*)()) F1_8;
	R5[332] = (char *(*)()) F1_8;
	{long i; for (i = 334; i < 336; i++) R5[i] = (char *(*)()) F1_8;}
	R5[339] = (char *(*)()) F1_8;
	{long i; for (i = 343; i < 345; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 346; i < 348; i++) R5[i] = (char *(*)()) F1_8;}
	R5[349] = (char *(*)()) F1_8;
	{long i; for (i = 351; i < 354; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 355; i < 357; i++) R5[i] = (char *(*)()) F1_8;}
	R5[359] = (char *(*)()) F1_8;
	{long i; for (i = 361; i < 364; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 365; i < 368; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 369; i < 371; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 373; i < 375; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 376; i < 379; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 380; i < 384; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 385; i < 391; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 392; i < 398; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 399; i < 403; i++) R5[i] = (char *(*)()) F1_8;}
	R5[408] = (char *(*)()) F409_5269;
	R5[409] = (char *(*)()) F410_5300;
	R5[410] = (char *(*)()) F411_5330;
	R5[412] = (char *(*)()) F412_5347;
	{long i; for (i = 415; i < 417; i++) R5[i] = (char *(*)()) F1_8;}
	R5[418] = (char *(*)()) F1_8;
	R5[421] = (char *(*)()) F1_8;
	R5[429] = (char *(*)()) F1_8;
	R5[430] = (char *(*)()) F431_5675;
	{long i; for (i = 432; i < 439; i++) R5[i] = (char *(*)()) F1_8;}
	R5[441] = (char *(*)()) F1_8;
	R5[446] = (char *(*)()) F1_8;
	R5[448] = (char *(*)()) F1_8;
	R5[453] = (char *(*)()) F454_6036;
	{long i; for (i = 454; i < 460; i++) R5[i] = (char *(*)()) F1_8;}
	R5[475] = (char *(*)()) F476_6159;
	{long i; for (i = 478; i < 480; i++) R5[i] = (char *(*)()) F1_8;}
	R5[482] = (char *(*)()) F1_8;
	R5[484] = (char *(*)()) F1_8;
	R5[486] = (char *(*)()) F1_8;
	R5[488] = (char *(*)()) F1_8;
	R5[490] = (char *(*)()) F1_8;
	R5[492] = (char *(*)()) F1_8;
	R5[494] = (char *(*)()) F1_8;
	{long i; for (i = 497; i < 499; i++) R5[i] = (char *(*)()) F1_8;}
	R5[502] = (char *(*)()) F1_8;
	{long i; for (i = 515; i < 519; i++) R5[i] = (char *(*)()) F1_8;}
	R5[529] = (char *(*)()) F1_8;
	{long i; for (i = 543; i < 546; i++) R5[i] = (char *(*)()) F1_8;}
	R5[546] = (char *(*)()) F547_6561;
	R5[549] = (char *(*)()) F1_8;
	R5[552] = (char *(*)()) F1_8;
	{long i; for (i = 554; i < 556; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 557; i < 560; i++) R5[i] = (char *(*)()) F1_8;}
	R5[560] = (char *(*)()) F561_6836;
	R5[561] = (char *(*)()) F1_8;
	R5[563] = (char *(*)()) F1_8;
	{long i; for (i = 568; i < 570; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 577; i < 582; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 583; i < 586; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 587; i < 589; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 591; i < 593; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 593; i < 595; i++) R5[i] = (char *(*)()) F594_7653;}
	{long i; for (i = 635; i < 658; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 670; i < 709; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 710; i < 712; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 867; i < 869; i++) R5[i] = (char *(*)()) F1_8;}
	R5[908] = (char *(*)()) F909_8151;
	{long i; for (i = 936; i < 938; i++) R5[i] = (char *(*)()) F1_8;}
	R5[947] = (char *(*)()) F1_8;
	R5[960] = (char *(*)()) F961_8581;
	R5[961] = (char *(*)()) F962_8581;
	R5[962] = (char *(*)()) F963_8581;
	R5[963] = (char *(*)()) F964_8581;
	R5[964] = (char *(*)()) F965_8581;
	R5[965] = (char *(*)()) F966_8581;
	R5[966] = (char *(*)()) F967_8581;
	R5[967] = (char *(*)()) F968_8581;
	R5[968] = (char *(*)()) F969_8581;
	R5[969] = (char *(*)()) F961_8581;
	R5[970] = (char *(*)()) F971_8687;
	R5[971] = (char *(*)()) F972_8687;
	R5[972] = (char *(*)()) F973_8687;
	R5[973] = (char *(*)()) F974_8687;
	R5[974] = (char *(*)()) F975_8687;
	R5[987] = (char *(*)()) F988_8703;
	R5[988] = (char *(*)()) F989_8744;
	R5[989] = (char *(*)()) F990_8744;
	R5[990] = (char *(*)()) F991_8744;
	R5[991] = (char *(*)()) F992_8744;
	R5[992] = (char *(*)()) F993_8744;
	R5[993] = (char *(*)()) F994_8744;
	R5[994] = (char *(*)()) F995_8744;
	R5[995] = (char *(*)()) F996_8744;
	R5[996] = (char *(*)()) F997_8744;
	R5[997] = (char *(*)()) F998_8744;
	R5[998] = (char *(*)()) F999_8744;
	R5[999] = (char *(*)()) F1000_8744;
	R5[1053] = (char *(*)()) F1030_8826;
	R5[1054] = (char *(*)()) F1033_8826;
	R5[1055] = (char *(*)()) F1030_8826;
	R5[1056] = (char *(*)()) F1033_8826;
	R5[1057] = (char *(*)()) F1030_8826;
	R5[1058] = (char *(*)()) F1059_8932;
	R5[1059] = (char *(*)()) F1060_8932;
	R5[1060] = (char *(*)()) F1061_8932;
	R5[1061] = (char *(*)()) F1062_8932;
	R5[1062] = (char *(*)()) F1063_8932;
	R5[1063] = (char *(*)()) F1064_8932;
	R5[1064] = (char *(*)()) F1065_8932;
	R5[1065] = (char *(*)()) F1066_8932;
	R5[1066] = (char *(*)()) F1067_8932;
	R5[1067] = (char *(*)()) F1068_8932;
	R5[1068] = (char *(*)()) F1069_8932;
	R5[1069] = (char *(*)()) F1070_8932;
	{long i; for (i = 1070; i < 1073; i++) R5[i] = (char *(*)()) F1059_8932;}
	R5[1073] = (char *(*)()) F1062_8932;
	R5[1074] = (char *(*)()) F1059_8932;
	R5[1075] = (char *(*)()) F1_8;
	R5[1079] = (char *(*)()) F1_8;
	R5[1086] = (char *(*)()) F1_8;
	{long i; for (i = 1095; i < 1100; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1101; i < 1104; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1107] = (char *(*)()) F1_8;
	{long i; for (i = 1109; i < 1111; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1113] = (char *(*)()) F1114_9632;
	R5[1116] = (char *(*)()) F1116_9770;
	{long i; for (i = 1117; i < 1119; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1120; i < 1122; i++) R5[i] = (char *(*)()) F1120_9819;}
	{long i; for (i = 1123; i < 1125; i++) R5[i] = (char *(*)()) F1123_9859;}
	{long i; for (i = 1126; i < 1128; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1129; i < 1161; i++) R5[i] = (char *(*)()) F1129_9925;}
	R5[1162] = (char *(*)()) F1162_9962;
	R5[1163] = (char *(*)()) F1164_10000;
	R5[1164] = (char *(*)()) F1165_10000;
	R5[1165] = (char *(*)()) F1166_10000;
	R5[1166] = (char *(*)()) F1165_10000;
	{long i; for (i = 1171; i < 1173; i++) R5[i] = (char *(*)()) F1171_10161;}
	{long i; for (i = 1174; i < 1177; i++) R5[i] = (char *(*)()) F1174_10329;}
	{long i; for (i = 1179; i < 1185; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1185] = (char *(*)()) F1186_10633;
	{long i; for (i = 1186; i < 1188; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1190; i < 1192; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1192] = (char *(*)()) F1193_10950;
	R5[1193] = (char *(*)()) F1194_11024;
	R5[1194] = (char *(*)()) F1_8;
	R5[1195] = (char *(*)()) F1196_11073;
	R5[1196] = (char *(*)()) F1197_11073;
	R5[1197] = (char *(*)()) F1198_11073;
	R5[1198] = (char *(*)()) F1199_11073;
	R5[1199] = (char *(*)()) F1200_11073;
	R5[1200] = (char *(*)()) F1201_11073;
	R5[1201] = (char *(*)()) F1202_11073;
	R5[1202] = (char *(*)()) F1203_11073;
	R5[1203] = (char *(*)()) F1204_11073;
	R5[1204] = (char *(*)()) F1205_11073;
	R5[1205] = (char *(*)()) F1206_11073;
	R5[1206] = (char *(*)()) F1207_11073;
	R5[1207] = (char *(*)()) F1208_11073;
	R5[1208] = (char *(*)()) F1209_11073;
	R5[1209] = (char *(*)()) F1210_11073;
	R5[1210] = (char *(*)()) F1211_11073;
	R5[1211] = (char *(*)()) F1212_11073;
	R5[1212] = (char *(*)()) F1213_11073;
	R5[1213] = (char *(*)()) F1214_11073;
	R5[1214] = (char *(*)()) F1215_11073;
	R5[1215] = (char *(*)()) F1216_11073;
	R5[1216] = (char *(*)()) F1217_11073;
	R5[1217] = (char *(*)()) F1218_11073;
	R5[1218] = (char *(*)()) F1219_11073;
	R5[1219] = (char *(*)()) F1220_11073;
	R5[1220] = (char *(*)()) F1221_11073;
	R5[1221] = (char *(*)()) F1222_11073;
	R5[1222] = (char *(*)()) F1223_11073;
	R5[1223] = (char *(*)()) F1224_11073;
	R5[1224] = (char *(*)()) F1225_11073;
	R5[1225] = (char *(*)()) F1226_11073;
	R5[1226] = (char *(*)()) F1227_11073;
	R5[1227] = (char *(*)()) F1228_11073;
	R5[1228] = (char *(*)()) F1229_11073;
	{long i; for (i = 1230; i < 1242; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1244] = (char *(*)()) F1_8;
	{long i; for (i = 1248; i < 1251; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1252; i < 1255; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1302; i < 1304; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1304] = (char *(*)()) F1305_11470;
	R5[1305] = (char *(*)()) F1306_11494;
	{long i; for (i = 1308; i < 1310; i++) R5[i] = (char *(*)()) F1308_11525;}
	{long i; for (i = 1311; i < 1313; i++) R5[i] = (char *(*)()) F1311_11623;}
	{long i; for (i = 1314; i < 1316; i++) R5[i] = (char *(*)()) F1314_11722;}
	{long i; for (i = 1317; i < 1319; i++) R5[i] = (char *(*)()) F1317_11821;}
	{long i; for (i = 1320; i < 1322; i++) R5[i] = (char *(*)()) F1320_11920;}
	{long i; for (i = 1323; i < 1325; i++) R5[i] = (char *(*)()) F1323_12014;}
	{long i; for (i = 1326; i < 1328; i++) R5[i] = (char *(*)()) F1326_12108;}
	{long i; for (i = 1329; i < 1331; i++) R5[i] = (char *(*)()) F1329_12203;}
	{long i; for (i = 1332; i < 1334; i++) R5[i] = (char *(*)()) F1332_12302;}
	{long i; for (i = 1335; i < 1337; i++) R5[i] = (char *(*)()) F1335_12368;}
	{long i; for (i = 1337; i < 1339; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1344] = (char *(*)()) F1345_12483;
	{long i; for (i = 1345; i < 1348; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1348] = (char *(*)()) F1349_12534;
	R5[1349] = (char *(*)()) F1_8;
	R5[1350] = (char *(*)()) F1351_12559;
	R5[1351] = (char *(*)()) F1352_12559;
	R5[1352] = (char *(*)()) F1353_12559;
	{long i; for (i = 1353; i < 1355; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1371] = (char *(*)()) F1_8;
	R5[1374] = (char *(*)()) F1_8;
	{long i; for (i = 1376; i < 1379; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1380; i < 1382; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1383; i < 1385; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1399; i < 1401; i++) R5[i] = (char *(*)()) F1399_13597;}
	R5[1403] = (char *(*)()) F1_8;
	R5[1405] = (char *(*)()) F1_8;
	R5[1406] = (char *(*)()) F1407_14237;
	R5[1408] = (char *(*)()) F1_8;
	R5[1412] = (char *(*)()) F1_8;
	R5[1420] = (char *(*)()) F1_8;
	R5[1422] = (char *(*)()) F412_5347;
	R5[1424] = (char *(*)()) F412_5347;
	R5[1427] = (char *(*)()) F1428_14828;
	{long i; for (i = 1428; i < 1431; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1432; i < 1447; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1448] = (char *(*)()) F1_8;
	R5[1451] = (char *(*)()) F1452_15305;
}


#ifdef __cplusplus
}
#endif
