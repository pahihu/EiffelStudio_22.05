#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7044[488])();
void R7044_init () {
	{long i; for (i = 0; i < 2; i++) R7044[i] = (char *(*)()) F867_8086;}
	{long i; for (i = 69; i < 71; i++) R7044[i] = (char *(*)()) F936_8280;}
	R7044[186] = (char *(*)()) F1054_8857;
	R7044[187] = (char *(*)()) F1055_8857;
	R7044[188] = (char *(*)()) F1054_8857;
	R7044[189] = (char *(*)()) F1055_8857;
	R7044[190] = (char *(*)()) F1054_8857;
	R7044[191] = (char *(*)()) F1059_8939;
	R7044[192] = (char *(*)()) F1060_8939;
	R7044[193] = (char *(*)()) F1061_8939;
	R7044[194] = (char *(*)()) F1062_8939;
	R7044[195] = (char *(*)()) F1063_8939;
	R7044[196] = (char *(*)()) F1064_8939;
	R7044[197] = (char *(*)()) F1065_8939;
	R7044[198] = (char *(*)()) F1066_8939;
	R7044[199] = (char *(*)()) F1067_8939;
	R7044[200] = (char *(*)()) F1068_8939;
	R7044[201] = (char *(*)()) F1069_8939;
	R7044[202] = (char *(*)()) F1070_8939;
	{long i; for (i = 203; i < 206; i++) R7044[i] = (char *(*)()) F1059_8939;}
	R7044[206] = (char *(*)()) F1062_8939;
	R7044[207] = (char *(*)()) F1059_8939;
	R7044[487] = (char *(*)()) F936_8280;
}

char *(*R7050[488])();
void R7050_init () {
	{long i; for (i = 0; i < 2; i++) R7050[i] = (char *(*)()) F740_7990_7050_4;}
	{long i; for (i = 69; i < 71; i++) R7050[i] = (char *(*)()) F754_8007_7050_4;}
	R7050[186] = (char *(*)()) F750_8007;
	R7050[187] = (char *(*)()) F753_8007_7050_4;
	R7050[188] = (char *(*)()) F750_8007;
	R7050[189] = (char *(*)()) F753_8007_7050_4;
	R7050[190] = (char *(*)()) F750_8007;
	R7050[191] = (char *(*)()) F1059_8945;
	R7050[192] = (char *(*)()) F1060_8945_7050_4;
	R7050[193] = (char *(*)()) F1061_8945_7050_4;
	R7050[194] = (char *(*)()) F1062_8945_7050_4;
	R7050[195] = (char *(*)()) F1063_8945_7050_4;
	R7050[196] = (char *(*)()) F1064_8945_7050_4;
	R7050[197] = (char *(*)()) F1065_8945_7050_4;
	R7050[198] = (char *(*)()) F1066_8945_7050_4;
	R7050[199] = (char *(*)()) F1067_8945_7050_4;
	R7050[200] = (char *(*)()) F1068_8945_7050_4;
	R7050[201] = (char *(*)()) F1069_8945_7050_4;
	R7050[202] = (char *(*)()) F1070_8945_7050_4;
	{long i; for (i = 203; i < 206; i++) R7050[i] = (char *(*)()) F1059_8945;}
	R7050[206] = (char *(*)()) F1062_8945_7050_4;
	R7050[207] = (char *(*)()) F1059_8945;
	R7050[487] = (char *(*)()) F754_8007_7050_4;
}
static void F740_7990_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F740_7990(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F754_8007_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F754_8007(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F753_8007_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F753_8007(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1060_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1060_8945(Current, *(EIF_POINTER *)arg1);
}
static void F1061_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1061_8945(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1062_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8945(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_8945(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1064_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1064_8945(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1065_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1065_8945(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1066_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1066_8945(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1067_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1067_8945(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1068_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1068_8945(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1069_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1069_8945(Current, *(EIF_REAL_32 *)arg1);
}
static void F1070_8945_7050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1070_8945(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7051[488])();
void R7051_init () {
	{long i; for (i = 0; i < 2; i++) R7051[i] = (char *(*)()) F867_8077;}
	{long i; for (i = 69; i < 71; i++) R7051[i] = (char *(*)()) F936_8205;}
	R7051[186] = (char *(*)()) F1054_8843;
	R7051[187] = (char *(*)()) F1055_8843;
	R7051[188] = (char *(*)()) F1054_8843;
	R7051[189] = (char *(*)()) F1055_8843;
	R7051[190] = (char *(*)()) F1054_8843;
	R7051[191] = (char *(*)()) F1059_8918;
	R7051[192] = (char *(*)()) F1060_8918;
	R7051[193] = (char *(*)()) F1061_8918;
	R7051[194] = (char *(*)()) F1062_8918;
	R7051[195] = (char *(*)()) F1063_8918;
	R7051[196] = (char *(*)()) F1064_8918;
	R7051[197] = (char *(*)()) F1065_8918;
	R7051[198] = (char *(*)()) F1066_8918;
	R7051[199] = (char *(*)()) F1067_8918;
	R7051[200] = (char *(*)()) F1068_8918;
	R7051[201] = (char *(*)()) F1069_8918;
	R7051[202] = (char *(*)()) F1070_8918;
	{long i; for (i = 203; i < 206; i++) R7051[i] = (char *(*)()) F1059_8918;}
	R7051[206] = (char *(*)()) F1062_8918;
	R7051[207] = (char *(*)()) F1059_8918;
	R7051[487] = (char *(*)()) F936_8205;
}

char *(*R7054[488])();
void R7054_init () {
	{long i; for (i = 0; i < 2; i++) R7054[i] = (char *(*)()) F740_7994;}
	{long i; for (i = 69; i < 71; i++) R7054[i] = (char *(*)()) F742_7994;}
	R7054[186] = (char *(*)()) F738_7994;
	R7054[187] = (char *(*)()) F740_7994;
	R7054[188] = (char *(*)()) F738_7994;
	R7054[189] = (char *(*)()) F740_7994;
	{long i; for (i = 190; i < 192; i++) R7054[i] = (char *(*)()) F738_7994;}
	R7054[192] = (char *(*)()) F739_7994;
	R7054[193] = (char *(*)()) F741_7994;
	R7054[194] = (char *(*)()) F740_7994;
	R7054[195] = (char *(*)()) F742_7994;
	R7054[196] = (char *(*)()) F743_7994;
	R7054[197] = (char *(*)()) F744_7994;
	R7054[198] = (char *(*)()) F745_7994;
	R7054[199] = (char *(*)()) F746_7994;
	R7054[200] = (char *(*)()) F747_7994;
	R7054[201] = (char *(*)()) F748_7994;
	R7054[202] = (char *(*)()) F749_7994;
	{long i; for (i = 203; i < 206; i++) R7054[i] = (char *(*)()) F738_7994;}
	R7054[206] = (char *(*)()) F740_7994;
	R7054[207] = (char *(*)()) F738_7994;
	R7054[487] = (char *(*)()) F742_7994;
}

char *(*R7055[488])();
void R7055_init () {
	{long i; for (i = 0; i < 2; i++) R7055[i] = (char *(*)()) F867_8079;}
	{long i; for (i = 69; i < 71; i++) R7055[i] = (char *(*)()) F936_8223;}
	R7055[186] = (char *(*)()) F1054_8849;
	R7055[187] = (char *(*)()) F1055_8849;
	R7055[188] = (char *(*)()) F1054_8849;
	R7055[189] = (char *(*)()) F1055_8849;
	R7055[190] = (char *(*)()) F1054_8849;
	R7055[191] = (char *(*)()) F1030_8827;
	R7055[192] = (char *(*)()) F1031_8827;
	R7055[193] = (char *(*)()) F1032_8827;
	R7055[194] = (char *(*)()) F1033_8827;
	R7055[195] = (char *(*)()) F1034_8827;
	R7055[196] = (char *(*)()) F1035_8827;
	R7055[197] = (char *(*)()) F1036_8827;
	R7055[198] = (char *(*)()) F1037_8827;
	R7055[199] = (char *(*)()) F1038_8827;
	R7055[200] = (char *(*)()) F1039_8827;
	R7055[201] = (char *(*)()) F1040_8827;
	R7055[202] = (char *(*)()) F1041_8827;
	{long i; for (i = 203; i < 206; i++) R7055[i] = (char *(*)()) F1030_8827;}
	R7055[206] = (char *(*)()) F1033_8827;
	R7055[207] = (char *(*)()) F1030_8827;
	R7055[487] = (char *(*)()) F936_8223;
}

char *(*R7056[22])();
void R7056_init () {
	R7056[0] = (char *(*)()) F1054_8858;
	R7056[1] = (char *(*)()) F1055_8858;
	R7056[2] = (char *(*)()) F1054_8858;
	R7056[3] = (char *(*)()) F1055_8858;
	R7056[4] = (char *(*)()) F1054_8858;
	R7056[5] = (char *(*)()) F1059_8940;
	R7056[6] = (char *(*)()) F1060_8940;
	R7056[7] = (char *(*)()) F1061_8940;
	R7056[8] = (char *(*)()) F1062_8940;
	R7056[9] = (char *(*)()) F1063_8940;
	R7056[10] = (char *(*)()) F1064_8940;
	R7056[11] = (char *(*)()) F1065_8940;
	R7056[12] = (char *(*)()) F1066_8940;
	R7056[13] = (char *(*)()) F1067_8940;
	R7056[14] = (char *(*)()) F1068_8940;
	R7056[15] = (char *(*)()) F1069_8940;
	R7056[16] = (char *(*)()) F1070_8940;
	{long i; for (i = 17; i < 20; i++) R7056[i] = (char *(*)()) F1059_8940;}
	R7056[20] = (char *(*)()) F1062_8940;
	R7056[21] = (char *(*)()) F1059_8940;
}

char *(*R7057[488])();
void R7057_init () {
	{long i; for (i = 0; i < 2; i++) R7057[i] = (char *(*)()) F867_8085;}
	{long i; for (i = 69; i < 71; i++) R7057[i] = (char *(*)()) F936_8282;}
	R7057[186] = (char *(*)()) F1054_8859;
	R7057[187] = (char *(*)()) F1055_8859;
	R7057[188] = (char *(*)()) F1054_8859;
	R7057[189] = (char *(*)()) F1055_8859;
	R7057[190] = (char *(*)()) F1054_8859;
	R7057[191] = (char *(*)()) F1059_8941;
	R7057[192] = (char *(*)()) F1060_8941;
	R7057[193] = (char *(*)()) F1061_8941;
	R7057[194] = (char *(*)()) F1062_8941;
	R7057[195] = (char *(*)()) F1063_8941;
	R7057[196] = (char *(*)()) F1064_8941;
	R7057[197] = (char *(*)()) F1065_8941;
	R7057[198] = (char *(*)()) F1066_8941;
	R7057[199] = (char *(*)()) F1067_8941;
	R7057[200] = (char *(*)()) F1068_8941;
	R7057[201] = (char *(*)()) F1069_8941;
	R7057[202] = (char *(*)()) F1070_8941;
	{long i; for (i = 203; i < 206; i++) R7057[i] = (char *(*)()) F1059_8941;}
	R7057[206] = (char *(*)()) F1062_8941;
	R7057[207] = (char *(*)()) F1059_8941;
	R7057[487] = (char *(*)()) F936_8282;
}

char *(*R7058[419])();
void R7058_init () {
	{long i; for (i = 0; i < 2; i++) R7058[i] = (char *(*)()) F936_8224;}
	R7058[117] = (char *(*)()) F1054_8850;
	R7058[118] = (char *(*)()) F1055_8850;
	R7058[119] = (char *(*)()) F1054_8850;
	R7058[120] = (char *(*)()) F1055_8850;
	R7058[121] = (char *(*)()) F1054_8850;
	R7058[122] = (char *(*)()) F1030_8828;
	R7058[123] = (char *(*)()) F1031_8828;
	R7058[124] = (char *(*)()) F1032_8828;
	R7058[125] = (char *(*)()) F1033_8828;
	R7058[126] = (char *(*)()) F1034_8828;
	R7058[127] = (char *(*)()) F1035_8828;
	R7058[128] = (char *(*)()) F1036_8828;
	R7058[129] = (char *(*)()) F1037_8828;
	R7058[130] = (char *(*)()) F1038_8828;
	R7058[131] = (char *(*)()) F1039_8828;
	R7058[132] = (char *(*)()) F1040_8828;
	R7058[133] = (char *(*)()) F1041_8828;
	{long i; for (i = 134; i < 137; i++) R7058[i] = (char *(*)()) F1030_8828;}
	R7058[137] = (char *(*)()) F1033_8828;
	R7058[138] = (char *(*)()) F1030_8828;
	R7058[418] = (char *(*)()) F936_8224;
}

char *(*R7059[419])();
void R7059_init () {
	{long i; for (i = 0; i < 2; i++) R7059[i] = (char *(*)()) F936_8283;}
	R7059[122] = (char *(*)()) F1059_8942;
	R7059[123] = (char *(*)()) F1060_8942;
	R7059[124] = (char *(*)()) F1061_8942;
	R7059[125] = (char *(*)()) F1062_8942;
	R7059[126] = (char *(*)()) F1063_8942;
	R7059[127] = (char *(*)()) F1064_8942;
	R7059[128] = (char *(*)()) F1065_8942;
	R7059[129] = (char *(*)()) F1066_8942;
	R7059[130] = (char *(*)()) F1067_8942;
	R7059[131] = (char *(*)()) F1068_8942;
	R7059[132] = (char *(*)()) F1069_8942;
	R7059[133] = (char *(*)()) F1070_8942;
	{long i; for (i = 134; i < 137; i++) R7059[i] = (char *(*)()) F1059_8942;}
	R7059[137] = (char *(*)()) F1062_8942;
	R7059[138] = (char *(*)()) F1059_8942;
	R7059[418] = (char *(*)()) F1355_12651;
}

char *(*R7060[585])();
void R7060_init () {
	{long i; for (i = 0; i < 2; i++) R7060[i] = (char *(*)()) F867_8080;}
	R7060[41] = (char *(*)()) F909_8158;
	{long i; for (i = 69; i < 71; i++) R7060[i] = (char *(*)()) F936_8256;}
	R7060[93] = (char *(*)()) F961_8585;
	R7060[94] = (char *(*)()) F962_8585;
	R7060[95] = (char *(*)()) F963_8585;
	R7060[96] = (char *(*)()) F964_8585;
	R7060[97] = (char *(*)()) F965_8585;
	R7060[98] = (char *(*)()) F966_8585;
	R7060[99] = (char *(*)()) F967_8585;
	R7060[100] = (char *(*)()) F968_8585;
	R7060[101] = (char *(*)()) F969_8585;
	{long i; for (i = 102; i < 104; i++) R7060[i] = (char *(*)()) F961_8585;}
	R7060[104] = (char *(*)()) F964_8585;
	R7060[105] = (char *(*)()) F968_8585;
	R7060[106] = (char *(*)()) F966_8585;
	R7060[107] = (char *(*)()) F969_8585;
	R7060[120] = (char *(*)()) F988_8705;
	R7060[121] = (char *(*)()) F989_8750;
	R7060[122] = (char *(*)()) F990_8750;
	R7060[123] = (char *(*)()) F991_8750;
	R7060[124] = (char *(*)()) F992_8750;
	R7060[125] = (char *(*)()) F993_8750;
	R7060[126] = (char *(*)()) F994_8750;
	R7060[127] = (char *(*)()) F995_8750;
	R7060[128] = (char *(*)()) F996_8750;
	R7060[129] = (char *(*)()) F997_8750;
	R7060[130] = (char *(*)()) F998_8750;
	R7060[131] = (char *(*)()) F999_8750;
	R7060[132] = (char *(*)()) F1000_8750;
	R7060[186] = (char *(*)()) F1018_8812;
	R7060[187] = (char *(*)()) F1021_8812;
	R7060[188] = (char *(*)()) F1018_8812;
	R7060[189] = (char *(*)()) F1021_8812;
	{long i; for (i = 190; i < 192; i++) R7060[i] = (char *(*)()) F1018_8812;}
	R7060[192] = (char *(*)()) F1019_8812;
	R7060[193] = (char *(*)()) F1020_8812;
	R7060[194] = (char *(*)()) F1021_8812;
	R7060[195] = (char *(*)()) F1022_8812;
	R7060[196] = (char *(*)()) F1023_8812;
	R7060[197] = (char *(*)()) F1024_8812;
	R7060[198] = (char *(*)()) F1025_8812;
	R7060[199] = (char *(*)()) F1026_8812;
	R7060[200] = (char *(*)()) F1027_8812;
	R7060[201] = (char *(*)()) F1028_8812;
	R7060[202] = (char *(*)()) F1029_8812;
	{long i; for (i = 203; i < 206; i++) R7060[i] = (char *(*)()) F1018_8812;}
	R7060[206] = (char *(*)()) F1021_8812;
	R7060[207] = (char *(*)()) F1018_8812;
	R7060[305] = (char *(*)()) F1173_10224;
	{long i; for (i = 308; i < 310; i++) R7060[i] = (char *(*)()) F1176_10389;}
	R7060[487] = (char *(*)()) F936_8256;
	R7060[584] = (char *(*)()) F1176_10389;
}

char *(*R7064[585])();
void R7064_init () {
	{long i; for (i = 0; i < 2; i++) R7064[i] = (char *(*)()) F867_8087_7064_4;}
	R7064[41] = (char *(*)()) F909_8160;
	{long i; for (i = 69; i < 71; i++) R7064[i] = (char *(*)()) F936_8289_7064_4;}
	R7064[93] = (char *(*)()) F961_8669;
	R7064[94] = (char *(*)()) F962_8669_7064_4;
	R7064[95] = (char *(*)()) F963_8669;
	R7064[96] = (char *(*)()) F964_8669_7064_4;
	R7064[97] = (char *(*)()) F965_8669;
	R7064[98] = (char *(*)()) F966_8669_7064_4;
	R7064[99] = (char *(*)()) F967_8669_7064_4;
	R7064[100] = (char *(*)()) F968_8669_7064_4;
	R7064[101] = (char *(*)()) F969_8669_7064_4;
	{long i; for (i = 102; i < 104; i++) R7064[i] = (char *(*)()) F961_8669;}
	R7064[104] = (char *(*)()) F964_8669_7064_4;
	R7064[105] = (char *(*)()) F968_8669_7064_4;
	R7064[106] = (char *(*)()) F966_8669_7064_4;
	R7064[107] = (char *(*)()) F969_8669_7064_4;
	R7064[120] = (char *(*)()) F988_8707_7064_4;
	R7064[121] = (char *(*)()) F989_8785;
	R7064[122] = (char *(*)()) F990_8785_7064_4;
	R7064[123] = (char *(*)()) F991_8785_7064_4;
	R7064[124] = (char *(*)()) F992_8785_7064_4;
	R7064[125] = (char *(*)()) F993_8785_7064_4;
	R7064[126] = (char *(*)()) F994_8785_7064_4;
	R7064[127] = (char *(*)()) F995_8785_7064_4;
	R7064[128] = (char *(*)()) F996_8785_7064_4;
	R7064[129] = (char *(*)()) F997_8785_7064_4;
	R7064[130] = (char *(*)()) F998_8785_7064_4;
	R7064[131] = (char *(*)()) F999_8785_7064_4;
	R7064[132] = (char *(*)()) F1000_8785_7064_4;
	R7064[186] = (char *(*)()) F1054_8865;
	R7064[187] = (char *(*)()) F1055_8865_7064_4;
	R7064[188] = (char *(*)()) F1056_8887;
	R7064[189] = (char *(*)()) F1057_8887_7064_4;
	R7064[190] = (char *(*)()) F1058_8900;
	R7064[191] = (char *(*)()) F1059_8949;
	R7064[192] = (char *(*)()) F1060_8949_7064_4;
	R7064[193] = (char *(*)()) F1061_8949_7064_4;
	R7064[194] = (char *(*)()) F1062_8949_7064_4;
	R7064[195] = (char *(*)()) F1063_8949_7064_4;
	R7064[196] = (char *(*)()) F1064_8949_7064_4;
	R7064[197] = (char *(*)()) F1065_8949_7064_4;
	R7064[198] = (char *(*)()) F1066_8949_7064_4;
	R7064[199] = (char *(*)()) F1067_8949_7064_4;
	R7064[200] = (char *(*)()) F1068_8949_7064_4;
	R7064[201] = (char *(*)()) F1069_8949_7064_4;
	R7064[202] = (char *(*)()) F1070_8949_7064_4;
	R7064[203] = (char *(*)()) F1059_8949;
	R7064[204] = (char *(*)()) F1072_8978;
	R7064[205] = (char *(*)()) F1073_8987;
	R7064[206] = (char *(*)()) F1074_8987_7064_4;
	R7064[207] = (char *(*)()) F1059_8949;
	R7064[305] = (char *(*)()) F1173_10266_7064_4;
	{long i; for (i = 308; i < 310; i++) R7064[i] = (char *(*)()) F1176_10431_7064_4;}
	R7064[487] = (char *(*)()) F936_8289_7064_4;
	R7064[584] = (char *(*)()) F1176_10431_7064_4;
}
static void F867_8087_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F867_8087(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F936_8289_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F936_8289(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F962_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F962_8669(Current, *(EIF_POINTER *)arg1);
}
static void F964_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F964_8669(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F966_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F966_8669(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F967_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F967_8669(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F968_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F968_8669(Current, *(EIF_BOOLEAN *)arg1);
}
static void F969_8669_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F969_8669(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F988_8707_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F988_8707(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F990_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F990_8785(Current, *(EIF_POINTER *)arg1);
}
static void F991_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F991_8785(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F992_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F992_8785(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F993_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F993_8785(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F994_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F994_8785(Current, *(EIF_BOOLEAN *)arg1);
}
static void F995_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F995_8785(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F996_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F996_8785(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F997_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F997_8785(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F998_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F998_8785(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F999_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F999_8785(Current, *(EIF_REAL_32 *)arg1);
}
static void F1000_8785_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1000_8785(Current, *(EIF_REAL_64 *)arg1);
}
static void F1055_8865_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1055_8865(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1057_8887_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1057_8887(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1060_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1060_8949(Current, *(EIF_POINTER *)arg1);
}
static void F1061_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1061_8949(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1062_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8949(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_8949(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1064_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1064_8949(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1065_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1065_8949(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1066_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1066_8949(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1067_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1067_8949(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1068_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1068_8949(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1069_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1069_8949(Current, *(EIF_REAL_32 *)arg1);
}
static void F1070_8949_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1070_8949(Current, *(EIF_REAL_64 *)arg1);
}
static void F1074_8987_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1074_8987(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1173_10266_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1173_10266(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1176_10431_7064_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1176_10431(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7065[585])();
void R7065_init () {
	{long i; for (i = 0; i < 2; i++) R7065[i] = (char *(*)()) F764_8013;}
	R7065[41] = (char *(*)()) F762_8013;
	{long i; for (i = 69; i < 71; i++) R7065[i] = (char *(*)()) F766_8013;}
	R7065[93] = (char *(*)()) F762_8013;
	R7065[94] = (char *(*)()) F763_8013;
	R7065[95] = (char *(*)()) F762_8013;
	R7065[96] = (char *(*)()) F768_8013;
	R7065[97] = (char *(*)()) F762_8013;
	{long i; for (i = 98; i < 100; i++) R7065[i] = (char *(*)()) F764_8013;}
	R7065[100] = (char *(*)()) F767_8013;
	R7065[101] = (char *(*)()) F771_8013;
	{long i; for (i = 102; i < 104; i++) R7065[i] = (char *(*)()) F762_8013;}
	R7065[104] = (char *(*)()) F768_8013;
	R7065[105] = (char *(*)()) F767_8013;
	R7065[106] = (char *(*)()) F764_8013;
	R7065[107] = (char *(*)()) F771_8013;
	R7065[120] = (char *(*)()) F764_8013;
	R7065[121] = (char *(*)()) F762_8013;
	R7065[122] = (char *(*)()) F763_8013;
	R7065[123] = (char *(*)()) F765_8013;
	R7065[124] = (char *(*)()) F764_8013;
	R7065[125] = (char *(*)()) F766_8013;
	R7065[126] = (char *(*)()) F767_8013;
	R7065[127] = (char *(*)()) F768_8013;
	R7065[128] = (char *(*)()) F769_8013;
	R7065[129] = (char *(*)()) F770_8013;
	R7065[130] = (char *(*)()) F771_8013;
	R7065[131] = (char *(*)()) F772_8013;
	R7065[132] = (char *(*)()) F773_8013;
	R7065[188] = (char *(*)()) F910_8183;
	R7065[189] = (char *(*)()) F911_8183;
	R7065[205] = (char *(*)()) F910_8183;
	R7065[206] = (char *(*)()) F911_8183;
	R7065[305] = (char *(*)()) F770_8013;
	{long i; for (i = 308; i < 310; i++) R7065[i] = (char *(*)()) F766_8013;}
	R7065[487] = (char *(*)()) F766_8013;
	R7065[584] = (char *(*)()) F766_8013;
}

char *(*R7066[22])();
void R7066_init () {
	R7066[0] = (char *(*)()) F1018_8818;
	R7066[1] = (char *(*)()) F1021_8818_7066_4;
	R7066[2] = (char *(*)()) F1018_8818;
	R7066[3] = (char *(*)()) F1021_8818_7066_4;
	R7066[4] = (char *(*)()) F1058_8901;
	R7066[5] = (char *(*)()) F1059_8961;
	R7066[6] = (char *(*)()) F1060_8961_7066_4;
	R7066[7] = (char *(*)()) F1061_8961_7066_4;
	R7066[8] = (char *(*)()) F1062_8961_7066_4;
	R7066[9] = (char *(*)()) F1063_8961_7066_4;
	R7066[10] = (char *(*)()) F1064_8961_7066_4;
	R7066[11] = (char *(*)()) F1065_8961_7066_4;
	R7066[12] = (char *(*)()) F1066_8961_7066_4;
	R7066[13] = (char *(*)()) F1067_8961_7066_4;
	R7066[14] = (char *(*)()) F1068_8961_7066_4;
	R7066[15] = (char *(*)()) F1069_8961_7066_4;
	R7066[16] = (char *(*)()) F1070_8961_7066_4;
	R7066[17] = (char *(*)()) F1059_8961;
	R7066[18] = (char *(*)()) F1072_8979;
	R7066[19] = (char *(*)()) F1059_8961;
	R7066[20] = (char *(*)()) F1062_8961_7066_4;
	R7066[21] = (char *(*)()) F1059_8961;
}
static void F1021_8818_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1021_8818(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1060_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1060_8961(Current, *(EIF_POINTER *)arg1);
}
static void F1061_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1061_8961(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1062_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8961(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_8961(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1064_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1064_8961(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1065_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1065_8961(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1066_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1066_8961(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1067_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1067_8961(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1068_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1068_8961(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1069_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1069_8961(Current, *(EIF_REAL_32 *)arg1);
}
static void F1070_8961_7066_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1070_8961(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7069[277])();
void R7069_init () {
	{long i; for (i = 0; i < 2; i++) R7069[i] = (char *(*)()) F1174_10327_7069_42;}
	R7069[276] = (char *(*)()) F1452_15294_7069_42;
}
static EIF_INTEGER_32 F1174_10327_7069_42 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1174_10327(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_INTEGER_32 F1452_15294_7069_42 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1452_15294(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7070[465])();
void R7070_init () {
	R7070[0] = (char *(*)()) F988_8695_7070_5;
	R7070[1] = (char *(*)()) F989_8734_7070_5;
	R7070[2] = (char *(*)()) F990_8734_7070_5;
	R7070[3] = (char *(*)()) F991_8734_7070_5;
	R7070[4] = (char *(*)()) F992_8734_7070_5;
	R7070[5] = (char *(*)()) F993_8734_7070_5;
	R7070[6] = (char *(*)()) F994_8734_7070_5;
	R7070[7] = (char *(*)()) F995_8734_7070_5;
	R7070[8] = (char *(*)()) F996_8734_7070_5;
	R7070[9] = (char *(*)()) F997_8734_7070_5;
	R7070[10] = (char *(*)()) F998_8734_7070_5;
	R7070[11] = (char *(*)()) F999_8734_7070_5;
	R7070[12] = (char *(*)()) F1000_8734_7070_5;
	R7070[66] = (char *(*)()) F1006_8792_7070_5;
	R7070[67] = (char *(*)()) F1009_8792_7070_5;
	R7070[68] = (char *(*)()) F1006_8792_7070_5;
	R7070[69] = (char *(*)()) F1009_8792_7070_5;
	R7070[70] = (char *(*)()) F1006_8792_7070_5;
	R7070[71] = (char *(*)()) F1059_8914_7070_5;
	R7070[72] = (char *(*)()) F1060_8914_7070_5;
	R7070[73] = (char *(*)()) F1061_8914_7070_5;
	R7070[74] = (char *(*)()) F1062_8914_7070_5;
	R7070[75] = (char *(*)()) F1063_8914_7070_5;
	R7070[76] = (char *(*)()) F1064_8914_7070_5;
	R7070[77] = (char *(*)()) F1065_8914_7070_5;
	R7070[78] = (char *(*)()) F1066_8914_7070_5;
	R7070[79] = (char *(*)()) F1067_8914_7070_5;
	R7070[80] = (char *(*)()) F1068_8914_7070_5;
	R7070[81] = (char *(*)()) F1069_8914_7070_5;
	R7070[82] = (char *(*)()) F1070_8914_7070_5;
	{long i; for (i = 83; i < 86; i++) R7070[i] = (char *(*)()) F1059_8914_7070_5;}
	R7070[86] = (char *(*)()) F1062_8914_7070_5;
	R7070[87] = (char *(*)()) F1059_8914_7070_5;
	R7070[185] = (char *(*)()) F1173_10219_7070_5;
	{long i; for (i = 188; i < 190; i++) R7070[i] = (char *(*)()) F1176_10383_7070_5;}
	R7070[464] = (char *(*)()) F1452_15279_7070_5;
}
static EIF_REFERENCE F988_8695_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F988_8695(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F989_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F989_8734(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F990_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F990_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F991_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F991_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F992_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F992_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F993_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F993_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F994_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F994_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F995_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F995_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F996_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F996_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F997_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F997_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F998_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F998_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F999_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F999_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1000_8734_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1000_8734(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8792_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1006_8792(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1009_8792_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1009_8792(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1059_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1059_8914(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1060_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8914_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8914(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1173_10219_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1173_10219(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1176_10383_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1176_10383(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1452_15279_7070_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1452_15279(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R7073[492])();
void R7073_init () {
	R7073[0] = (char *(*)()) F961_8604;
	R7073[1] = (char *(*)()) F962_8604_7073_9;
	R7073[2] = (char *(*)()) F963_8604_7073_9;
	R7073[3] = (char *(*)()) F964_8604_7073_9;
	R7073[4] = (char *(*)()) F965_8604_7073_9;
	R7073[5] = (char *(*)()) F966_8604_7073_9;
	R7073[6] = (char *(*)()) F967_8604_7073_9;
	R7073[7] = (char *(*)()) F968_8604_7073_9;
	R7073[8] = (char *(*)()) F969_8604_7073_9;
	{long i; for (i = 9; i < 11; i++) R7073[i] = (char *(*)()) F961_8604;}
	R7073[11] = (char *(*)()) F964_8604_7073_9;
	R7073[12] = (char *(*)()) F968_8604_7073_9;
	R7073[13] = (char *(*)()) F966_8604_7073_9;
	R7073[14] = (char *(*)()) F969_8604_7073_9;
	R7073[27] = (char *(*)()) F988_8725_7073_9;
	R7073[28] = (char *(*)()) F989_8753_7073_9;
	R7073[29] = (char *(*)()) F990_8753_7073_9;
	R7073[30] = (char *(*)()) F991_8753_7073_9;
	R7073[31] = (char *(*)()) F992_8753_7073_9;
	R7073[32] = (char *(*)()) F993_8753_7073_9;
	R7073[33] = (char *(*)()) F994_8753_7073_9;
	R7073[34] = (char *(*)()) F995_8753_7073_9;
	R7073[35] = (char *(*)()) F996_8753_7073_9;
	R7073[36] = (char *(*)()) F997_8753_7073_9;
	R7073[37] = (char *(*)()) F998_8753_7073_9;
	R7073[38] = (char *(*)()) F999_8753_7073_9;
	R7073[39] = (char *(*)()) F1000_8753_7073_9;
	R7073[93] = (char *(*)()) F1006_8806_7073_9;
	R7073[94] = (char *(*)()) F1009_8806_7073_9;
	R7073[95] = (char *(*)()) F1006_8806_7073_9;
	R7073[96] = (char *(*)()) F1009_8806_7073_9;
	R7073[97] = (char *(*)()) F1006_8806_7073_9;
	R7073[98] = (char *(*)()) F1059_8947_7073_9;
	R7073[99] = (char *(*)()) F1060_8947_7073_9;
	R7073[100] = (char *(*)()) F1061_8947_7073_9;
	R7073[101] = (char *(*)()) F1062_8947_7073_9;
	R7073[102] = (char *(*)()) F1063_8947_7073_9;
	R7073[103] = (char *(*)()) F1064_8947_7073_9;
	R7073[104] = (char *(*)()) F1065_8947_7073_9;
	R7073[105] = (char *(*)()) F1066_8947_7073_9;
	R7073[106] = (char *(*)()) F1067_8947_7073_9;
	R7073[107] = (char *(*)()) F1068_8947_7073_9;
	R7073[108] = (char *(*)()) F1069_8947_7073_9;
	R7073[109] = (char *(*)()) F1070_8947_7073_9;
	{long i; for (i = 110; i < 113; i++) R7073[i] = (char *(*)()) F1059_8947_7073_9;}
	R7073[113] = (char *(*)()) F1062_8947_7073_9;
	R7073[114] = (char *(*)()) F1059_8947_7073_9;
	R7073[212] = (char *(*)()) F1173_10239_7073_9;
	{long i; for (i = 215; i < 217; i++) R7073[i] = (char *(*)()) F1176_10404_7073_9;}
	R7073[491] = (char *(*)()) F1452_15314_7073_9;
}
static void F962_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F962_8604(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F963_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F963_8604(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F964_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F964_8604(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F965_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F965_8604(Current, arg1, *(EIF_POINTER *)arg2);
}
static void F966_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F966_8604(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F967_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F967_8604(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F968_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F968_8604(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F969_8604_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F969_8604(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F988_8725_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F988_8725(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F989_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F989_8753(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F990_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F990_8753(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F991_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F991_8753(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F992_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F992_8753(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F993_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F993_8753(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F994_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F994_8753(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F995_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F995_8753(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F996_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F996_8753(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F997_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F997_8753(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F998_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F998_8753(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F999_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F999_8753(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1000_8753_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1000_8753(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1006_8806_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1006_8806(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1009_8806_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1009_8806(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1059_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1059_8947(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1060_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1060_8947(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1061_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1061_8947(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1062_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1062_8947(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1063_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1063_8947(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1064_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1064_8947(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1065_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1065_8947(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1066_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1066_8947(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1067_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1067_8947(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1068_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1068_8947(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1069_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1069_8947(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1070_8947_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1070_8947(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1173_10239_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1173_10239(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1176_10404_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1176_10404(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1452_15314_7073_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1452_15314(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R7074[492])();
void R7074_init () {
	R7074[0] = (char *(*)()) F961_8605;
	R7074[1] = (char *(*)()) F962_8605_7074_9;
	R7074[2] = (char *(*)()) F963_8605_7074_9;
	R7074[3] = (char *(*)()) F964_8605_7074_9;
	R7074[4] = (char *(*)()) F965_8605_7074_9;
	R7074[5] = (char *(*)()) F966_8605_7074_9;
	R7074[6] = (char *(*)()) F967_8605_7074_9;
	R7074[7] = (char *(*)()) F968_8605_7074_9;
	R7074[8] = (char *(*)()) F969_8605_7074_9;
	{long i; for (i = 9; i < 11; i++) R7074[i] = (char *(*)()) F961_8605;}
	R7074[11] = (char *(*)()) F964_8605_7074_9;
	R7074[12] = (char *(*)()) F968_8605_7074_9;
	R7074[13] = (char *(*)()) F966_8605_7074_9;
	R7074[14] = (char *(*)()) F969_8605_7074_9;
	R7074[27] = (char *(*)()) F988_8725_7074_9;
	R7074[28] = (char *(*)()) F989_8753_7074_9;
	R7074[29] = (char *(*)()) F990_8753_7074_9;
	R7074[30] = (char *(*)()) F991_8753_7074_9;
	R7074[31] = (char *(*)()) F992_8753_7074_9;
	R7074[32] = (char *(*)()) F993_8753_7074_9;
	R7074[33] = (char *(*)()) F994_8753_7074_9;
	R7074[34] = (char *(*)()) F995_8753_7074_9;
	R7074[35] = (char *(*)()) F996_8753_7074_9;
	R7074[36] = (char *(*)()) F997_8753_7074_9;
	R7074[37] = (char *(*)()) F998_8753_7074_9;
	R7074[38] = (char *(*)()) F999_8753_7074_9;
	R7074[39] = (char *(*)()) F1000_8753_7074_9;
	R7074[93] = (char *(*)()) F1006_8806_7074_9;
	R7074[94] = (char *(*)()) F1009_8806_7074_9;
	R7074[95] = (char *(*)()) F1006_8806_7074_9;
	R7074[96] = (char *(*)()) F1009_8806_7074_9;
	R7074[97] = (char *(*)()) F1006_8806_7074_9;
	R7074[98] = (char *(*)()) F1059_8947_7074_9;
	R7074[99] = (char *(*)()) F1060_8947_7074_9;
	R7074[100] = (char *(*)()) F1061_8947_7074_9;
	R7074[101] = (char *(*)()) F1062_8947_7074_9;
	R7074[102] = (char *(*)()) F1063_8947_7074_9;
	R7074[103] = (char *(*)()) F1064_8947_7074_9;
	R7074[104] = (char *(*)()) F1065_8947_7074_9;
	R7074[105] = (char *(*)()) F1066_8947_7074_9;
	R7074[106] = (char *(*)()) F1067_8947_7074_9;
	R7074[107] = (char *(*)()) F1068_8947_7074_9;
	R7074[108] = (char *(*)()) F1069_8947_7074_9;
	R7074[109] = (char *(*)()) F1070_8947_7074_9;
	{long i; for (i = 110; i < 113; i++) R7074[i] = (char *(*)()) F1059_8947_7074_9;}
	R7074[113] = (char *(*)()) F1062_8947_7074_9;
	R7074[114] = (char *(*)()) F1059_8947_7074_9;
	R7074[212] = (char *(*)()) F1173_10239_7074_9;
	{long i; for (i = 215; i < 217; i++) R7074[i] = (char *(*)()) F1176_10404_7074_9;}
	R7074[491] = (char *(*)()) F1452_15314_7074_9;
}
static void F962_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F962_8605(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F963_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F963_8605(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F964_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F964_8605(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F965_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F965_8605(Current, arg1, *(EIF_POINTER *)arg2);
}
static void F966_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F966_8605(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F967_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F967_8605(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F968_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F968_8605(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F969_8605_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F969_8605(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F988_8725_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F988_8725(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F989_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F989_8753(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F990_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F990_8753(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F991_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F991_8753(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F992_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F992_8753(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F993_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F993_8753(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F994_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F994_8753(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F995_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F995_8753(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F996_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F996_8753(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F997_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F997_8753(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F998_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F998_8753(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F999_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F999_8753(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1000_8753_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1000_8753(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1006_8806_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1006_8806(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1009_8806_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1009_8806(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1059_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1059_8947(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1060_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1060_8947(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1061_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1061_8947(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1062_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1062_8947(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1063_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1063_8947(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1064_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1064_8947(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1065_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1065_8947(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1066_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1066_8947(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1067_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1067_8947(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1068_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1068_8947(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1069_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1069_8947(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1070_8947_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1070_8947(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1173_10239_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1173_10239(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1176_10404_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1176_10404(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1452_15314_7074_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1452_15314(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y7075_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype44[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype45[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype46[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype47[] = {0xFF01,1175,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype48[] = {0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype49[] = {0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype50[] = {0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype51[] = {0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype52[] = {0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype53[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype54[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype55[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype56[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype57[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype58[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype59[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype60[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype61[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype62[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype63[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype64[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype65[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype66[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype67[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype68[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype69[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype70[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype71[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype72[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype73[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype74[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype75[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype76[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype77[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype78[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype79[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype80[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype81[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype82[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype83[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype84[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype85[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype86[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype87[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype88[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype89[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype90[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype91[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype92[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype93[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype94[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype95[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype96[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype97[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype98[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype99[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype100[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype101[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype102[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype103[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype104[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype105[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype106[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype107[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype108[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype109[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype110[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype111[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype112[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype113[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype114[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype115[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype116[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype117[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype118[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype119[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype120[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype121[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype122[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype123[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype124[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype125[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype126[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype127[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype128[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype129[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype130[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype131[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype132[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype133[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype134[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype135[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype136[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype137[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype138[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype139[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype140[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype141[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype142[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype143[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype144[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype145[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype146[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype147[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype148[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype149[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype150[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype151[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype152[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype153[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype154[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype155[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype156[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype157[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y7075_pgtype158[] = {1312,0xFFFF};
EIF_TYPE_INDEX *Y7075_gen_type [668];
EIF_TYPE_INDEX Y7075 [668];
void Y7075_init (void)
{
	egc_routines_types [7075] = Y7075;
	egc_routines_gen_types [7075] = Y7075_gen_type;
	egc_routines_offset [7075] = 785;
	Y7075_gen_type [0] = Y7075_pgtype0;
	Y7075_gen_type [1] = Y7075_pgtype1;
	Y7075_gen_type [2] = Y7075_pgtype2;
	Y7075_gen_type [3] = Y7075_pgtype3;
	Y7075_gen_type [4] = Y7075_pgtype4;
	Y7075_gen_type [5] = Y7075_pgtype5;
	Y7075_gen_type [6] = Y7075_pgtype6;
	Y7075_gen_type [7] = Y7075_pgtype7;
	Y7075_gen_type [8] = Y7075_pgtype8;
	Y7075_gen_type [9] = Y7075_pgtype9;
	Y7075_gen_type [10] = Y7075_pgtype10;
	Y7075_gen_type [11] = Y7075_pgtype11;
	Y7075_gen_type [12] = Y7075_pgtype12;
	Y7075_gen_type [13] = Y7075_pgtype13;
	Y7075_gen_type [14] = Y7075_pgtype14;
	Y7075_gen_type [15] = Y7075_pgtype15;
	Y7075_gen_type [16] = Y7075_pgtype16;
	Y7075_gen_type [17] = Y7075_pgtype17;
	Y7075_gen_type [18] = Y7075_pgtype18;
	Y7075_gen_type [19] = Y7075_pgtype19;
	Y7075_gen_type [20] = Y7075_pgtype20;
	Y7075_gen_type [21] = Y7075_pgtype21;
	Y7075_gen_type [22] = Y7075_pgtype22;
	Y7075_gen_type [23] = Y7075_pgtype23;
	Y7075_gen_type [24] = Y7075_pgtype24;
	Y7075_gen_type [25] = Y7075_pgtype25;
	Y7075_gen_type [26] = Y7075_pgtype26;
	Y7075_gen_type [27] = Y7075_pgtype27;
	Y7075_gen_type [28] = Y7075_pgtype28;
	Y7075_gen_type [29] = Y7075_pgtype29;
	Y7075_gen_type [30] = Y7075_pgtype30;
	Y7075_gen_type [31] = Y7075_pgtype31;
	Y7075_gen_type [32] = Y7075_pgtype32;
	Y7075_gen_type [33] = Y7075_pgtype33;
	Y7075_gen_type [34] = Y7075_pgtype34;
	Y7075_gen_type [35] = Y7075_pgtype35;
	Y7075_gen_type [36] = Y7075_pgtype36;
	Y7075_gen_type [37] = Y7075_pgtype37;
	Y7075_gen_type [175] = Y7075_pgtype38;
	Y7075_gen_type [176] = Y7075_pgtype39;
	Y7075_gen_type [177] = Y7075_pgtype40;
	Y7075_gen_type [178] = Y7075_pgtype41;
	Y7075_gen_type [179] = Y7075_pgtype42;
	Y7075_gen_type [180] = Y7075_pgtype43;
	Y7075_gen_type [181] = Y7075_pgtype44;
	Y7075_gen_type [182] = Y7075_pgtype45;
	Y7075_gen_type [183] = Y7075_pgtype46;
	Y7075_gen_type [184] = Y7075_pgtype47;
	Y7075_gen_type [185] = Y7075_pgtype48;
	Y7075_gen_type [186] = Y7075_pgtype49;
	Y7075_gen_type [187] = Y7075_pgtype50;
	Y7075_gen_type [188] = Y7075_pgtype51;
	Y7075_gen_type [189] = Y7075_pgtype52;
	Y7075_gen_type [190] = Y7075_pgtype53;
	Y7075_gen_type [191] = Y7075_pgtype54;
	Y7075_gen_type [192] = Y7075_pgtype55;
	Y7075_gen_type [193] = Y7075_pgtype56;
	Y7075_gen_type [194] = Y7075_pgtype57;
	Y7075_gen_type [195] = Y7075_pgtype58;
	Y7075_gen_type [196] = Y7075_pgtype59;
	Y7075_gen_type [197] = Y7075_pgtype60;
	Y7075_gen_type [198] = Y7075_pgtype61;
	Y7075_gen_type [199] = Y7075_pgtype62;
	Y7075_gen_type [200] = Y7075_pgtype63;
	Y7075_gen_type [201] = Y7075_pgtype64;
	Y7075_gen_type [202] = Y7075_pgtype65;
	Y7075_gen_type [203] = Y7075_pgtype66;
	Y7075_gen_type [204] = Y7075_pgtype67;
	Y7075_gen_type [205] = Y7075_pgtype68;
	Y7075_gen_type [206] = Y7075_pgtype69;
	Y7075_gen_type [207] = Y7075_pgtype70;
	Y7075_gen_type [208] = Y7075_pgtype71;
	Y7075_gen_type [209] = Y7075_pgtype72;
	Y7075_gen_type [210] = Y7075_pgtype73;
	Y7075_gen_type [211] = Y7075_pgtype74;
	Y7075_gen_type [212] = Y7075_pgtype75;
	Y7075_gen_type [213] = Y7075_pgtype76;
	Y7075_gen_type [214] = Y7075_pgtype77;
	Y7075_gen_type [215] = Y7075_pgtype78;
	Y7075_gen_type [216] = Y7075_pgtype79;
	Y7075_gen_type [217] = Y7075_pgtype80;
	Y7075_gen_type [218] = Y7075_pgtype81;
	Y7075_gen_type [219] = Y7075_pgtype82;
	Y7075_gen_type [220] = Y7075_pgtype83;
	Y7075_gen_type [221] = Y7075_pgtype84;
	Y7075_gen_type [222] = Y7075_pgtype85;
	Y7075_gen_type [223] = Y7075_pgtype86;
	Y7075_gen_type [224] = Y7075_pgtype87;
	Y7075_gen_type [225] = Y7075_pgtype88;
	Y7075_gen_type [226] = Y7075_pgtype89;
	Y7075_gen_type [227] = Y7075_pgtype90;
	Y7075_gen_type [228] = Y7075_pgtype91;
	Y7075_gen_type [229] = Y7075_pgtype92;
	Y7075_gen_type [230] = Y7075_pgtype93;
	Y7075_gen_type [231] = Y7075_pgtype94;
	Y7075_gen_type [232] = Y7075_pgtype95;
	Y7075_gen_type [233] = Y7075_pgtype96;
	Y7075_gen_type [234] = Y7075_pgtype97;
	Y7075_gen_type [235] = Y7075_pgtype98;
	Y7075_gen_type [236] = Y7075_pgtype99;
	Y7075_gen_type [237] = Y7075_pgtype100;
	Y7075_gen_type [238] = Y7075_pgtype101;
	Y7075_gen_type [239] = Y7075_pgtype102;
	Y7075_gen_type [240] = Y7075_pgtype103;
	Y7075_gen_type [241] = Y7075_pgtype104;
	Y7075_gen_type [242] = Y7075_pgtype105;
	Y7075_gen_type [243] = Y7075_pgtype106;
	Y7075_gen_type [244] = Y7075_pgtype107;
	Y7075_gen_type [245] = Y7075_pgtype108;
	Y7075_gen_type [246] = Y7075_pgtype109;
	Y7075_gen_type [247] = Y7075_pgtype110;
	Y7075_gen_type [248] = Y7075_pgtype111;
	Y7075_gen_type [249] = Y7075_pgtype112;
	Y7075_gen_type [250] = Y7075_pgtype113;
	Y7075_gen_type [251] = Y7075_pgtype114;
	Y7075_gen_type [252] = Y7075_pgtype115;
	Y7075_gen_type [253] = Y7075_pgtype116;
	Y7075_gen_type [254] = Y7075_pgtype117;
	Y7075_gen_type [255] = Y7075_pgtype118;
	Y7075_gen_type [256] = Y7075_pgtype119;
	Y7075_gen_type [257] = Y7075_pgtype120;
	Y7075_gen_type [258] = Y7075_pgtype121;
	Y7075_gen_type [259] = Y7075_pgtype122;
	Y7075_gen_type [260] = Y7075_pgtype123;
	Y7075_gen_type [261] = Y7075_pgtype124;
	Y7075_gen_type [262] = Y7075_pgtype125;
	Y7075_gen_type [263] = Y7075_pgtype126;
	Y7075_gen_type [264] = Y7075_pgtype127;
	Y7075_gen_type [265] = Y7075_pgtype128;
	Y7075_gen_type [266] = Y7075_pgtype129;
	Y7075_gen_type [267] = Y7075_pgtype130;
	Y7075_gen_type [268] = Y7075_pgtype131;
	Y7075_gen_type [269] = Y7075_pgtype132;
	Y7075_gen_type [270] = Y7075_pgtype133;
	Y7075_gen_type [271] = Y7075_pgtype134;
	Y7075_gen_type [272] = Y7075_pgtype135;
	Y7075_gen_type [273] = Y7075_pgtype136;
	Y7075_gen_type [274] = Y7075_pgtype137;
	Y7075_gen_type [275] = Y7075_pgtype138;
	Y7075_gen_type [276] = Y7075_pgtype139;
	Y7075_gen_type [277] = Y7075_pgtype140;
	Y7075_gen_type [278] = Y7075_pgtype141;
	Y7075_gen_type [279] = Y7075_pgtype142;
	Y7075_gen_type [280] = Y7075_pgtype143;
	Y7075_gen_type [281] = Y7075_pgtype144;
	Y7075_gen_type [282] = Y7075_pgtype145;
	Y7075_gen_type [283] = Y7075_pgtype146;
	Y7075_gen_type [284] = Y7075_pgtype147;
	Y7075_gen_type [285] = Y7075_pgtype148;
	Y7075_gen_type [286] = Y7075_pgtype149;
	Y7075_gen_type [287] = Y7075_pgtype150;
	Y7075_gen_type [288] = Y7075_pgtype151;
	Y7075_gen_type [289] = Y7075_pgtype152;
	Y7075_gen_type [387] = Y7075_pgtype153;
	Y7075_gen_type [390] = Y7075_pgtype154;
	Y7075_gen_type [391] = Y7075_pgtype155;
	Y7075_gen_type [392] = Y7075_pgtype156;
	Y7075_gen_type [666] = Y7075_pgtype157;
	Y7075_gen_type [667] = Y7075_pgtype158;
	Y7075[184] = 1175;
	{long i; for (i = 185; i < 190; i++) Y7075[i] = 1167;};
	{long i; for (i = 190; i < 290; i++) Y7075[i] = 1312;};
	Y7075[387] = 1312;
	{long i; for (i = 390; i < 393; i++) Y7075[i] = 1312;};
	{long i; for (i = 666; i < 668; i++) Y7075[i] = 1312;};
}

char *(*R7077[488])();
void R7077_init () {
	{long i; for (i = 0; i < 2; i++) R7077[i] = (char *(*)()) F867_8078_7077_1;}
	R7077[41] = (char *(*)()) F909_8148;
	{long i; for (i = 69; i < 71; i++) R7077[i] = (char *(*)()) F936_8204_7077_1;}
	R7077[186] = (char *(*)()) F1054_8840;
	R7077[187] = (char *(*)()) F1055_8840_7077_1;
	R7077[188] = (char *(*)()) F1056_8885;
	R7077[189] = (char *(*)()) F1057_8885_7077_1;
	R7077[190] = (char *(*)()) F1054_8840;
	R7077[191] = (char *(*)()) F1059_8913;
	R7077[192] = (char *(*)()) F1060_8913_7077_1;
	R7077[193] = (char *(*)()) F1061_8913_7077_1;
	R7077[194] = (char *(*)()) F1062_8913_7077_1;
	R7077[195] = (char *(*)()) F1063_8913_7077_1;
	R7077[196] = (char *(*)()) F1064_8913_7077_1;
	R7077[197] = (char *(*)()) F1065_8913_7077_1;
	R7077[198] = (char *(*)()) F1066_8913_7077_1;
	R7077[199] = (char *(*)()) F1067_8913_7077_1;
	R7077[200] = (char *(*)()) F1068_8913_7077_1;
	R7077[201] = (char *(*)()) F1069_8913_7077_1;
	R7077[202] = (char *(*)()) F1070_8913_7077_1;
	{long i; for (i = 203; i < 206; i++) R7077[i] = (char *(*)()) F1059_8913;}
	R7077[206] = (char *(*)()) F1062_8913_7077_1;
	R7077[207] = (char *(*)()) F1059_8913;
	R7077[487] = (char *(*)()) F936_8204_7077_1;
}
static EIF_REFERENCE F867_8078_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F867_8078(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F936_8204_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F936_8204(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1055_8840_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1055_8840(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1057_8885_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1057_8885(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8913_7077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7077_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype108[] = {0xFF01,1406,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7077_pgtype112[] = {0xFF01,1074,0xFFFF};
EIF_TYPE_INDEX *Y7077_gen_type [575];
EIF_TYPE_INDEX Y7077 [575];
void Y7077_init (void)
{
	egc_routines_types [7077] = Y7077;
	egc_routines_gen_types [7077] = Y7077_gen_type;
	egc_routines_offset [7077] = 823;
	Y7077_gen_type [0] = Y7077_pgtype0;
	Y7077_gen_type [1] = Y7077_pgtype1;
	Y7077_gen_type [2] = Y7077_pgtype2;
	Y7077_gen_type [3] = Y7077_pgtype3;
	Y7077_gen_type [4] = Y7077_pgtype4;
	Y7077_gen_type [5] = Y7077_pgtype5;
	Y7077_gen_type [6] = Y7077_pgtype6;
	Y7077_gen_type [7] = Y7077_pgtype7;
	Y7077_gen_type [8] = Y7077_pgtype8;
	Y7077_gen_type [9] = Y7077_pgtype9;
	Y7077_gen_type [10] = Y7077_pgtype10;
	Y7077_gen_type [11] = Y7077_pgtype11;
	Y7077_gen_type [12] = Y7077_pgtype12;
	Y7077_gen_type [13] = Y7077_pgtype13;
	Y7077_gen_type [14] = Y7077_pgtype14;
	Y7077_gen_type [15] = Y7077_pgtype15;
	Y7077_gen_type [16] = Y7077_pgtype16;
	Y7077_gen_type [17] = Y7077_pgtype17;
	Y7077_gen_type [18] = Y7077_pgtype18;
	Y7077_gen_type [19] = Y7077_pgtype19;
	Y7077_gen_type [20] = Y7077_pgtype20;
	Y7077_gen_type [21] = Y7077_pgtype21;
	Y7077_gen_type [22] = Y7077_pgtype22;
	Y7077_gen_type [23] = Y7077_pgtype23;
	Y7077_gen_type [43] = Y7077_pgtype24;
	Y7077_gen_type [82] = Y7077_pgtype25;
	Y7077_gen_type [83] = Y7077_pgtype26;
	Y7077_gen_type [84] = Y7077_pgtype27;
	Y7077_gen_type [85] = Y7077_pgtype28;
	Y7077_gen_type [86] = Y7077_pgtype29;
	Y7077_gen_type [87] = Y7077_pgtype30;
	Y7077_gen_type [88] = Y7077_pgtype31;
	Y7077_gen_type [89] = Y7077_pgtype32;
	Y7077_gen_type [90] = Y7077_pgtype33;
	Y7077_gen_type [91] = Y7077_pgtype34;
	Y7077_gen_type [92] = Y7077_pgtype35;
	Y7077_gen_type [93] = Y7077_pgtype36;
	Y7077_gen_type [94] = Y7077_pgtype37;
	Y7077_gen_type [95] = Y7077_pgtype38;
	Y7077_gen_type [96] = Y7077_pgtype39;
	Y7077_gen_type [97] = Y7077_pgtype40;
	Y7077_gen_type [98] = Y7077_pgtype41;
	Y7077_gen_type [99] = Y7077_pgtype42;
	Y7077_gen_type [182] = Y7077_pgtype43;
	Y7077_gen_type [183] = Y7077_pgtype44;
	Y7077_gen_type [184] = Y7077_pgtype45;
	Y7077_gen_type [185] = Y7077_pgtype46;
	Y7077_gen_type [186] = Y7077_pgtype47;
	Y7077_gen_type [187] = Y7077_pgtype48;
	Y7077_gen_type [188] = Y7077_pgtype49;
	Y7077_gen_type [189] = Y7077_pgtype50;
	Y7077_gen_type [190] = Y7077_pgtype51;
	Y7077_gen_type [191] = Y7077_pgtype52;
	Y7077_gen_type [192] = Y7077_pgtype53;
	Y7077_gen_type [193] = Y7077_pgtype54;
	Y7077_gen_type [194] = Y7077_pgtype55;
	Y7077_gen_type [195] = Y7077_pgtype56;
	Y7077_gen_type [196] = Y7077_pgtype57;
	Y7077_gen_type [197] = Y7077_pgtype58;
	Y7077_gen_type [198] = Y7077_pgtype59;
	Y7077_gen_type [199] = Y7077_pgtype60;
	Y7077_gen_type [200] = Y7077_pgtype61;
	Y7077_gen_type [201] = Y7077_pgtype62;
	Y7077_gen_type [202] = Y7077_pgtype63;
	Y7077_gen_type [203] = Y7077_pgtype64;
	Y7077_gen_type [204] = Y7077_pgtype65;
	Y7077_gen_type [205] = Y7077_pgtype66;
	Y7077_gen_type [206] = Y7077_pgtype67;
	Y7077_gen_type [207] = Y7077_pgtype68;
	Y7077_gen_type [208] = Y7077_pgtype69;
	Y7077_gen_type [209] = Y7077_pgtype70;
	Y7077_gen_type [210] = Y7077_pgtype71;
	Y7077_gen_type [211] = Y7077_pgtype72;
	Y7077_gen_type [212] = Y7077_pgtype73;
	Y7077_gen_type [213] = Y7077_pgtype74;
	Y7077_gen_type [214] = Y7077_pgtype75;
	Y7077_gen_type [215] = Y7077_pgtype76;
	Y7077_gen_type [216] = Y7077_pgtype77;
	Y7077_gen_type [217] = Y7077_pgtype78;
	Y7077_gen_type [218] = Y7077_pgtype79;
	Y7077_gen_type [219] = Y7077_pgtype80;
	Y7077_gen_type [220] = Y7077_pgtype81;
	Y7077_gen_type [221] = Y7077_pgtype82;
	Y7077_gen_type [222] = Y7077_pgtype83;
	Y7077_gen_type [223] = Y7077_pgtype84;
	Y7077_gen_type [224] = Y7077_pgtype85;
	Y7077_gen_type [225] = Y7077_pgtype86;
	Y7077_gen_type [226] = Y7077_pgtype87;
	Y7077_gen_type [227] = Y7077_pgtype88;
	Y7077_gen_type [228] = Y7077_pgtype89;
	Y7077_gen_type [229] = Y7077_pgtype90;
	Y7077_gen_type [230] = Y7077_pgtype91;
	Y7077_gen_type [231] = Y7077_pgtype92;
	Y7077_gen_type [232] = Y7077_pgtype93;
	Y7077_gen_type [233] = Y7077_pgtype94;
	Y7077_gen_type [234] = Y7077_pgtype95;
	Y7077_gen_type [235] = Y7077_pgtype96;
	Y7077_gen_type [236] = Y7077_pgtype97;
	Y7077_gen_type [237] = Y7077_pgtype98;
	Y7077_gen_type [238] = Y7077_pgtype99;
	Y7077_gen_type [239] = Y7077_pgtype100;
	Y7077_gen_type [240] = Y7077_pgtype101;
	Y7077_gen_type [241] = Y7077_pgtype102;
	Y7077_gen_type [242] = Y7077_pgtype103;
	Y7077_gen_type [243] = Y7077_pgtype104;
	Y7077_gen_type [244] = Y7077_pgtype105;
	Y7077_gen_type [245] = Y7077_pgtype106;
	Y7077_gen_type [246] = Y7077_pgtype107;
	Y7077_gen_type [247] = Y7077_pgtype108;
	Y7077_gen_type [248] = Y7077_pgtype109;
	Y7077_gen_type [249] = Y7077_pgtype110;
	Y7077_gen_type [250] = Y7077_pgtype111;
	Y7077_gen_type [251] = Y7077_pgtype112;
	{long i; for (i = 44; i < 46; i++) Y7077[i] = 1312;};
	{long i; for (i = 112; i < 115; i++) Y7077[i] = 1124;};
	Y7077[247] = 1406;
	Y7077[251] = 1074;
	Y7077[531] = 1124;
	{long i; for (i = 566; i < 569; i++) Y7077[i] = 1124;};
	{long i; for (i = 570; i < 575; i++) Y7077[i] = 1124;};
}

char *(*R7081[22])();
void R7081_init () {
	R7081[0] = (char *(*)()) F1054_8868;
	R7081[1] = (char *(*)()) F1055_8868_7081_4;
	R7081[2] = (char *(*)()) F1054_8868;
	R7081[3] = (char *(*)()) F1055_8868_7081_4;
	R7081[4] = (char *(*)()) F1054_8868;
	R7081[5] = (char *(*)()) F1059_8952;
	R7081[6] = (char *(*)()) F1060_8952_7081_4;
	R7081[7] = (char *(*)()) F1061_8952_7081_4;
	R7081[8] = (char *(*)()) F1062_8952_7081_4;
	R7081[9] = (char *(*)()) F1063_8952_7081_4;
	R7081[10] = (char *(*)()) F1064_8952_7081_4;
	R7081[11] = (char *(*)()) F1065_8952_7081_4;
	R7081[12] = (char *(*)()) F1066_8952_7081_4;
	R7081[13] = (char *(*)()) F1067_8952_7081_4;
	R7081[14] = (char *(*)()) F1068_8952_7081_4;
	R7081[15] = (char *(*)()) F1069_8952_7081_4;
	R7081[16] = (char *(*)()) F1070_8952_7081_4;
	{long i; for (i = 17; i < 20; i++) R7081[i] = (char *(*)()) F1059_8952;}
	R7081[20] = (char *(*)()) F1062_8952_7081_4;
	R7081[21] = (char *(*)()) F1059_8952;
}
static void F1055_8868_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1055_8868(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1060_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1060_8952(Current, *(EIF_POINTER *)arg1);
}
static void F1061_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1061_8952(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1062_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8952(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_8952(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1064_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1064_8952(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1065_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1065_8952(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1066_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1066_8952(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1067_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1067_8952(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1068_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1068_8952(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1069_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1069_8952(Current, *(EIF_REAL_32 *)arg1);
}
static void F1070_8952_7081_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1070_8952(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7082[167])();
void R7082_init () {
	R7082[0] = (char *(*)()) F909_8165;
	R7082[145] = (char *(*)()) F1054_8871;
	R7082[146] = (char *(*)()) F1055_8871;
	R7082[147] = (char *(*)()) F1056_8889;
	R7082[148] = (char *(*)()) F1057_8889;
	R7082[149] = (char *(*)()) F1054_8871;
	R7082[150] = (char *(*)()) F1059_8962;
	R7082[151] = (char *(*)()) F1060_8962;
	R7082[152] = (char *(*)()) F1061_8962;
	R7082[153] = (char *(*)()) F1062_8962;
	R7082[154] = (char *(*)()) F1063_8962;
	R7082[155] = (char *(*)()) F1064_8962;
	R7082[156] = (char *(*)()) F1065_8962;
	R7082[157] = (char *(*)()) F1066_8962;
	R7082[158] = (char *(*)()) F1067_8962;
	R7082[159] = (char *(*)()) F1068_8962;
	R7082[160] = (char *(*)()) F1069_8962;
	R7082[161] = (char *(*)()) F1070_8962;
	{long i; for (i = 162; i < 164; i++) R7082[i] = (char *(*)()) F1059_8962;}
	R7082[164] = (char *(*)()) F1073_8990;
	R7082[165] = (char *(*)()) F1074_8990;
	R7082[166] = (char *(*)()) F1059_8962;
}

char *(*R7083[22])();
void R7083_init () {
	R7083[0] = (char *(*)()) F1054_8844;
	R7083[1] = (char *(*)()) F1055_8844;
	R7083[2] = (char *(*)()) F1054_8844;
	R7083[3] = (char *(*)()) F1055_8844;
	R7083[4] = (char *(*)()) F1054_8844;
	R7083[5] = (char *(*)()) F1059_8919;
	R7083[6] = (char *(*)()) F1060_8919;
	R7083[7] = (char *(*)()) F1061_8919;
	R7083[8] = (char *(*)()) F1062_8919;
	R7083[9] = (char *(*)()) F1063_8919;
	R7083[10] = (char *(*)()) F1064_8919;
	R7083[11] = (char *(*)()) F1065_8919;
	R7083[12] = (char *(*)()) F1066_8919;
	R7083[13] = (char *(*)()) F1067_8919;
	R7083[14] = (char *(*)()) F1068_8919;
	R7083[15] = (char *(*)()) F1069_8919;
	R7083[16] = (char *(*)()) F1070_8919;
	{long i; for (i = 17; i < 20; i++) R7083[i] = (char *(*)()) F1059_8919;}
	R7083[20] = (char *(*)()) F1062_8919;
	R7083[21] = (char *(*)()) F1059_8919;
}

static EIF_TYPE_INDEX Y7083_pgtype0[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype1[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype2[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype3[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype4[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype5[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype6[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype7[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype8[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype9[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype10[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype11[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype12[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype13[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype14[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype15[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype16[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype17[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype18[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype19[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype20[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype21[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype22[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype23[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype24[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype25[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype26[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype27[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype28[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype29[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype30[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype31[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype32[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype33[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype34[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype35[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype36[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype37[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype38[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype39[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype40[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype41[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype42[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype43[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype44[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype45[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype46[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype47[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype48[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype49[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype50[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype51[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype52[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype53[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype54[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype55[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype56[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype57[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype58[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype59[] = {0xFF01,345,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype60[] = {0xFF01,346,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype61[] = {0xFF01,347,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype62[] = {0xFF01,346,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype63[] = {0xFF01,347,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype64[] = {0xFF01,346,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype65[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype66[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype67[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype68[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype69[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype70[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype71[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype72[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype73[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype74[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype75[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype76[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype77[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype78[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype79[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype80[] = {0xFF01,349,0xFFFF};
static EIF_TYPE_INDEX Y7083_pgtype81[] = {0xFF01,349,0xFFFF};
EIF_TYPE_INDEX *Y7083_gen_type [240];
EIF_TYPE_INDEX Y7083 [240];
void Y7083_init (void)
{
	egc_routines_types [7083] = Y7083;
	egc_routines_gen_types [7083] = Y7083_gen_type;
	egc_routines_offset [7083] = 835;
	Y7083_gen_type [0] = Y7083_pgtype0;
	Y7083_gen_type [1] = Y7083_pgtype1;
	Y7083_gen_type [2] = Y7083_pgtype2;
	Y7083_gen_type [3] = Y7083_pgtype3;
	Y7083_gen_type [4] = Y7083_pgtype4;
	Y7083_gen_type [5] = Y7083_pgtype5;
	Y7083_gen_type [6] = Y7083_pgtype6;
	Y7083_gen_type [7] = Y7083_pgtype7;
	Y7083_gen_type [8] = Y7083_pgtype8;
	Y7083_gen_type [9] = Y7083_pgtype9;
	Y7083_gen_type [10] = Y7083_pgtype10;
	Y7083_gen_type [11] = Y7083_pgtype11;
	Y7083_gen_type [170] = Y7083_pgtype12;
	Y7083_gen_type [171] = Y7083_pgtype13;
	Y7083_gen_type [172] = Y7083_pgtype14;
	Y7083_gen_type [173] = Y7083_pgtype15;
	Y7083_gen_type [174] = Y7083_pgtype16;
	Y7083_gen_type [175] = Y7083_pgtype17;
	Y7083_gen_type [176] = Y7083_pgtype18;
	Y7083_gen_type [177] = Y7083_pgtype19;
	Y7083_gen_type [178] = Y7083_pgtype20;
	Y7083_gen_type [179] = Y7083_pgtype21;
	Y7083_gen_type [180] = Y7083_pgtype22;
	Y7083_gen_type [181] = Y7083_pgtype23;
	Y7083_gen_type [182] = Y7083_pgtype24;
	Y7083_gen_type [183] = Y7083_pgtype25;
	Y7083_gen_type [184] = Y7083_pgtype26;
	Y7083_gen_type [185] = Y7083_pgtype27;
	Y7083_gen_type [186] = Y7083_pgtype28;
	Y7083_gen_type [187] = Y7083_pgtype29;
	Y7083_gen_type [188] = Y7083_pgtype30;
	Y7083_gen_type [189] = Y7083_pgtype31;
	Y7083_gen_type [190] = Y7083_pgtype32;
	Y7083_gen_type [191] = Y7083_pgtype33;
	Y7083_gen_type [192] = Y7083_pgtype34;
	Y7083_gen_type [193] = Y7083_pgtype35;
	Y7083_gen_type [194] = Y7083_pgtype36;
	Y7083_gen_type [195] = Y7083_pgtype37;
	Y7083_gen_type [196] = Y7083_pgtype38;
	Y7083_gen_type [197] = Y7083_pgtype39;
	Y7083_gen_type [198] = Y7083_pgtype40;
	Y7083_gen_type [199] = Y7083_pgtype41;
	Y7083_gen_type [200] = Y7083_pgtype42;
	Y7083_gen_type [201] = Y7083_pgtype43;
	Y7083_gen_type [202] = Y7083_pgtype44;
	Y7083_gen_type [203] = Y7083_pgtype45;
	Y7083_gen_type [204] = Y7083_pgtype46;
	Y7083_gen_type [205] = Y7083_pgtype47;
	Y7083_gen_type [206] = Y7083_pgtype48;
	Y7083_gen_type [207] = Y7083_pgtype49;
	Y7083_gen_type [208] = Y7083_pgtype50;
	Y7083_gen_type [209] = Y7083_pgtype51;
	Y7083_gen_type [210] = Y7083_pgtype52;
	Y7083_gen_type [211] = Y7083_pgtype53;
	Y7083_gen_type [212] = Y7083_pgtype54;
	Y7083_gen_type [213] = Y7083_pgtype55;
	Y7083_gen_type [214] = Y7083_pgtype56;
	Y7083_gen_type [215] = Y7083_pgtype57;
	Y7083_gen_type [216] = Y7083_pgtype58;
	Y7083_gen_type [217] = Y7083_pgtype59;
	Y7083_gen_type [218] = Y7083_pgtype60;
	Y7083_gen_type [219] = Y7083_pgtype61;
	Y7083_gen_type [220] = Y7083_pgtype62;
	Y7083_gen_type [221] = Y7083_pgtype63;
	Y7083_gen_type [222] = Y7083_pgtype64;
	Y7083_gen_type [223] = Y7083_pgtype65;
	Y7083_gen_type [224] = Y7083_pgtype66;
	Y7083_gen_type [225] = Y7083_pgtype67;
	Y7083_gen_type [226] = Y7083_pgtype68;
	Y7083_gen_type [227] = Y7083_pgtype69;
	Y7083_gen_type [228] = Y7083_pgtype70;
	Y7083_gen_type [229] = Y7083_pgtype71;
	Y7083_gen_type [230] = Y7083_pgtype72;
	Y7083_gen_type [231] = Y7083_pgtype73;
	Y7083_gen_type [232] = Y7083_pgtype74;
	Y7083_gen_type [233] = Y7083_pgtype75;
	Y7083_gen_type [234] = Y7083_pgtype76;
	Y7083_gen_type [235] = Y7083_pgtype77;
	Y7083_gen_type [236] = Y7083_pgtype78;
	Y7083_gen_type [237] = Y7083_pgtype79;
	Y7083_gen_type [238] = Y7083_pgtype80;
	Y7083_gen_type [239] = Y7083_pgtype81;
	{long i; for (i = 0; i < 12; i++) Y7083[i] = 345;};
	{long i; for (i = 170; i < 218; i++) Y7083[i] = 345;};
	Y7083[218] = 346;
	Y7083[219] = 347;
	Y7083[220] = 346;
	Y7083[221] = 347;
	Y7083[222] = 346;
	{long i; for (i = 223; i < 240; i++) Y7083[i] = 349;};
}

char *(*R7085[22])();
void R7085_init () {
	R7085[0] = (char *(*)()) F1054_8863;
	R7085[1] = (char *(*)()) F1055_8863;
	R7085[2] = (char *(*)()) F1054_8863;
	R7085[3] = (char *(*)()) F1055_8863;
	R7085[4] = (char *(*)()) F1054_8863;
	R7085[5] = (char *(*)()) F1059_8944;
	R7085[6] = (char *(*)()) F1060_8944;
	R7085[7] = (char *(*)()) F1061_8944;
	R7085[8] = (char *(*)()) F1062_8944;
	R7085[9] = (char *(*)()) F1063_8944;
	R7085[10] = (char *(*)()) F1064_8944;
	R7085[11] = (char *(*)()) F1065_8944;
	R7085[12] = (char *(*)()) F1066_8944;
	R7085[13] = (char *(*)()) F1067_8944;
	R7085[14] = (char *(*)()) F1068_8944;
	R7085[15] = (char *(*)()) F1069_8944;
	R7085[16] = (char *(*)()) F1070_8944;
	{long i; for (i = 17; i < 20; i++) R7085[i] = (char *(*)()) F1059_8944;}
	R7085[20] = (char *(*)()) F1062_8944;
	R7085[21] = (char *(*)()) F1059_8944;
}

char *(*R7111[2])();
void R7111_init () {
	R7111[0] = (char *(*)()) F868_8104;
	R7111[1] = (char *(*)()) F869_8123;
}

char *(*R7140[544])();
void R7140_init () {
	R7140[0] = (char *(*)()) F909_8152;
	{long i; for (i = 28; i < 30; i++) R7140[i] = (char *(*)()) F936_8222;}
	R7140[52] = (char *(*)()) F961_8576;
	R7140[53] = (char *(*)()) F962_8576;
	R7140[54] = (char *(*)()) F963_8576;
	R7140[55] = (char *(*)()) F964_8576;
	R7140[56] = (char *(*)()) F965_8576;
	R7140[57] = (char *(*)()) F966_8576;
	R7140[58] = (char *(*)()) F967_8576;
	R7140[59] = (char *(*)()) F968_8576;
	R7140[60] = (char *(*)()) F969_8576;
	{long i; for (i = 61; i < 63; i++) R7140[i] = (char *(*)()) F961_8576;}
	R7140[63] = (char *(*)()) F964_8576;
	R7140[64] = (char *(*)()) F968_8576;
	R7140[65] = (char *(*)()) F966_8576;
	R7140[66] = (char *(*)()) F969_8576;
	R7140[79] = (char *(*)()) F988_8701;
	R7140[80] = (char *(*)()) F989_8741;
	R7140[81] = (char *(*)()) F990_8741;
	R7140[82] = (char *(*)()) F991_8741;
	R7140[83] = (char *(*)()) F992_8741;
	R7140[84] = (char *(*)()) F993_8741;
	R7140[85] = (char *(*)()) F994_8741;
	R7140[86] = (char *(*)()) F995_8741;
	R7140[87] = (char *(*)()) F996_8741;
	R7140[88] = (char *(*)()) F997_8741;
	R7140[89] = (char *(*)()) F998_8741;
	R7140[90] = (char *(*)()) F999_8741;
	R7140[91] = (char *(*)()) F1000_8741;
	R7140[145] = (char *(*)()) F1054_8847;
	R7140[146] = (char *(*)()) F1055_8847;
	R7140[147] = (char *(*)()) F1054_8847;
	R7140[148] = (char *(*)()) F1055_8847;
	R7140[149] = (char *(*)()) F1054_8847;
	R7140[150] = (char *(*)()) F1059_8929;
	R7140[151] = (char *(*)()) F1060_8929;
	R7140[152] = (char *(*)()) F1061_8929;
	R7140[153] = (char *(*)()) F1062_8929;
	R7140[154] = (char *(*)()) F1063_8929;
	R7140[155] = (char *(*)()) F1064_8929;
	R7140[156] = (char *(*)()) F1065_8929;
	R7140[157] = (char *(*)()) F1066_8929;
	R7140[158] = (char *(*)()) F1067_8929;
	R7140[159] = (char *(*)()) F1068_8929;
	R7140[160] = (char *(*)()) F1069_8929;
	R7140[161] = (char *(*)()) F1070_8929;
	{long i; for (i = 162; i < 165; i++) R7140[i] = (char *(*)()) F1059_8929;}
	R7140[165] = (char *(*)()) F1062_8929;
	R7140[166] = (char *(*)()) F1059_8929;
	R7140[264] = (char *(*)()) F1171_10158;
	{long i; for (i = 267; i < 269; i++) R7140[i] = (char *(*)()) F1174_10326;}
	R7140[446] = (char *(*)()) F1355_12649;
	R7140[543] = (char *(*)()) F1452_15295;
}


#ifdef __cplusplus
}
#endif
