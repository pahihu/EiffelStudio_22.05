#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6252[792])();
void R6252_init () {
	R6252[0] = (char *(*)()) F564_7045;
	{long i; for (i = 5; i < 7; i++) R6252[i] = (char *(*)()) F565_7112;}
	{long i; for (i = 373; i < 375; i++) R6252[i] = (char *(*)()) F936_8301;}
	R6252[791] = (char *(*)()) F1355_12671;
}

char *(*R6254[419])();
void R6254_init () {
	{long i; for (i = 0; i < 2; i++) R6254[i] = (char *(*)()) F936_8304;}
	R6254[418] = (char *(*)()) F1355_12669;
}

char *(*R6282[419])();
void R6282_init () {
	{long i; for (i = 0; i < 2; i++) R6282[i] = (char *(*)()) F936_8334;}
	R6282[418] = (char *(*)()) F1355_12666;
}

char *(*R6284[419])();
void R6284_init () {
	R6284[0] = (char *(*)()) F937_8446;
	R6284[1] = (char *(*)()) F938_8505;
	R6284[418] = (char *(*)()) F937_8446;
}

char *(*R6290[792])();
void R6290_init () {
	R6290[0] = (char *(*)()) F564_7029;
	{long i; for (i = 5; i < 7; i++) R6290[i] = (char *(*)()) F565_7164;}
	R6290[373] = (char *(*)()) F937_8455;
	R6290[374] = (char *(*)()) F938_8511;
	R6290[791] = (char *(*)()) F937_8455;
}

char *(*R6295[419])();
void R6295_init () {
	{long i; for (i = 0; i < 2; i++) R6295[i] = (char *(*)()) F936_8341;}
	R6295[418] = (char *(*)()) F1355_12660;
}

char *(*R6297[419])();
void R6297_init () {
	{long i; for (i = 0; i < 2; i++) R6297[i] = (char *(*)()) F936_8343;}
	R6297[418] = (char *(*)()) F1355_12662;
}

char *(*R6298[419])();
void R6298_init () {
	{long i; for (i = 0; i < 2; i++) R6298[i] = (char *(*)()) F936_8338;}
	R6298[418] = (char *(*)()) F1355_12657;
}

char *(*R6504[12])();
void R6504_init () {
	R6504[0] = (char *(*)()) F578_7367;
	R6504[1] = (char *(*)()) F579_7371;
	R6504[2] = (char *(*)()) F580_7376;
	R6504[3] = (char *(*)()) F581_7384;
	R6504[4] = (char *(*)()) F582_7393;
	{long i; for (i = 6; i < 9; i++) R6504[i] = (char *(*)()) F582_7393;}
	R6504[10] = (char *(*)()) F588_7412;
	R6504[11] = (char *(*)()) F582_7393;
}

char *(*R6693[2])();
void R6693_init () {
	R6693[0] = (char *(*)()) F594_7555;
	R6693[1] = (char *(*)()) F595_7660;
}

char *(*R6699[2])();
void R6699_init () {
	R6699[0] = (char *(*)()) F594_7561;
	R6699[1] = (char *(*)()) F595_7661;
}

char *(*R6701[2])();
void R6701_init () {
	R6701[0] = (char *(*)()) F594_7563;
	R6701[1] = (char *(*)()) F595_7662;
}

char *(*R6794[2])();
void R6794_init () {
	R6794[0] = (char *(*)()) F594_7658;
	R6794[1] = (char *(*)()) F595_7687;
}

char *(*R6830[817])();
void R6830_init () {
	R6830[0] = (char *(*)()) F636_7851;
	R6830[1] = (char *(*)()) F637_7851;
	R6830[2] = (char *(*)()) F638_7851;
	R6830[3] = (char *(*)()) F639_7851;
	R6830[4] = (char *(*)()) F640_7851;
	R6830[5] = (char *(*)()) F641_7851;
	R6830[6] = (char *(*)()) F642_7851;
	R6830[7] = (char *(*)()) F643_7851;
	R6830[8] = (char *(*)()) F644_7851;
	R6830[9] = (char *(*)()) F645_7851;
	R6830[10] = (char *(*)()) F646_7851;
	R6830[11] = (char *(*)()) F647_7851;
	R6830[12] = (char *(*)()) F636_7851;
	R6830[13] = (char *(*)()) F638_7851;
	R6830[14] = (char *(*)()) F636_7851;
	R6830[15] = (char *(*)()) F637_7851;
	R6830[16] = (char *(*)()) F636_7851;
	R6830[17] = (char *(*)()) F642_7851;
	R6830[18] = (char *(*)()) F636_7851;
	{long i; for (i = 19; i < 21; i++) R6830[i] = (char *(*)()) F638_7851;}
	R6830[21] = (char *(*)()) F641_7851;
	R6830[22] = (char *(*)()) F645_7851;
	R6830[35] = (char *(*)()) F671_7901;
	R6830[36] = (char *(*)()) F672_7901;
	R6830[37] = (char *(*)()) F673_7901;
	R6830[38] = (char *(*)()) F674_7901;
	R6830[39] = (char *(*)()) F675_7901;
	R6830[40] = (char *(*)()) F676_7901;
	R6830[41] = (char *(*)()) F677_7901;
	R6830[42] = (char *(*)()) F678_7901;
	R6830[43] = (char *(*)()) F679_7901;
	R6830[44] = (char *(*)()) F680_7901;
	R6830[45] = (char *(*)()) F681_7901;
	R6830[46] = (char *(*)()) F682_7901;
	R6830[47] = (char *(*)()) F683_7907;
	R6830[48] = (char *(*)()) F684_7913;
	R6830[49] = (char *(*)()) F685_7919;
	R6830[50] = (char *(*)()) F686_7919;
	R6830[51] = (char *(*)()) F687_7919;
	R6830[52] = (char *(*)()) F688_7919;
	R6830[53] = (char *(*)()) F689_7919;
	R6830[54] = (char *(*)()) F690_7919;
	R6830[55] = (char *(*)()) F691_7919;
	R6830[56] = (char *(*)()) F692_7919;
	R6830[57] = (char *(*)()) F693_7919;
	R6830[58] = (char *(*)()) F694_7919;
	R6830[59] = (char *(*)()) F695_7919;
	R6830[60] = (char *(*)()) F696_7919;
	R6830[61] = (char *(*)()) F697_7925;
	R6830[62] = (char *(*)()) F698_7925;
	R6830[63] = (char *(*)()) F699_7925;
	R6830[64] = (char *(*)()) F700_7925;
	R6830[65] = (char *(*)()) F701_7925;
	R6830[66] = (char *(*)()) F702_7925;
	R6830[67] = (char *(*)()) F703_7925;
	R6830[68] = (char *(*)()) F704_7925;
	R6830[69] = (char *(*)()) F705_7925;
	R6830[70] = (char *(*)()) F706_7925;
	R6830[71] = (char *(*)()) F707_7925;
	R6830[72] = (char *(*)()) F708_7925;
	R6830[73] = (char *(*)()) F709_7931;
	{long i; for (i = 75; i < 77; i++) R6830[i] = (char *(*)()) F710_7954;}
	R6830[232] = (char *(*)()) F868_8109;
	R6830[233] = (char *(*)()) F869_8124;
	R6830[273] = (char *(*)()) F909_8150;
	{long i; for (i = 301; i < 303; i++) R6830[i] = (char *(*)()) F936_8288;}
	R6830[312] = (char *(*)()) F948_8544;
	R6830[325] = (char *(*)()) F961_8573;
	R6830[326] = (char *(*)()) F962_8573;
	R6830[327] = (char *(*)()) F963_8573;
	R6830[328] = (char *(*)()) F964_8573;
	R6830[329] = (char *(*)()) F965_8573;
	R6830[330] = (char *(*)()) F966_8573;
	R6830[331] = (char *(*)()) F967_8573;
	R6830[332] = (char *(*)()) F968_8573;
	R6830[333] = (char *(*)()) F969_8573;
	{long i; for (i = 334; i < 336; i++) R6830[i] = (char *(*)()) F961_8573;}
	R6830[336] = (char *(*)()) F964_8573;
	R6830[337] = (char *(*)()) F968_8573;
	R6830[338] = (char *(*)()) F966_8573;
	R6830[339] = (char *(*)()) F969_8573;
	R6830[352] = (char *(*)()) F951_8553;
	R6830[353] = (char *(*)()) F989_8738;
	R6830[354] = (char *(*)()) F990_8738;
	R6830[355] = (char *(*)()) F991_8738;
	R6830[356] = (char *(*)()) F992_8738;
	R6830[357] = (char *(*)()) F993_8738;
	R6830[358] = (char *(*)()) F994_8738;
	R6830[359] = (char *(*)()) F995_8738;
	R6830[360] = (char *(*)()) F996_8738;
	R6830[361] = (char *(*)()) F997_8738;
	R6830[362] = (char *(*)()) F998_8738;
	R6830[363] = (char *(*)()) F999_8738;
	R6830[364] = (char *(*)()) F1000_8738;
	R6830[418] = (char *(*)()) F1054_8845;
	R6830[419] = (char *(*)()) F1055_8845;
	R6830[420] = (char *(*)()) F1054_8845;
	R6830[421] = (char *(*)()) F1055_8845;
	R6830[422] = (char *(*)()) F1054_8845;
	R6830[423] = (char *(*)()) F1059_8922;
	R6830[424] = (char *(*)()) F1060_8922;
	R6830[425] = (char *(*)()) F1061_8922;
	R6830[426] = (char *(*)()) F1062_8922;
	R6830[427] = (char *(*)()) F1063_8922;
	R6830[428] = (char *(*)()) F1064_8922;
	R6830[429] = (char *(*)()) F1065_8922;
	R6830[430] = (char *(*)()) F1066_8922;
	R6830[431] = (char *(*)()) F1067_8922;
	R6830[432] = (char *(*)()) F1068_8922;
	R6830[433] = (char *(*)()) F1069_8922;
	R6830[434] = (char *(*)()) F1070_8922;
	{long i; for (i = 435; i < 438; i++) R6830[i] = (char *(*)()) F1059_8922;}
	R6830[438] = (char *(*)()) F1062_8922;
	R6830[439] = (char *(*)()) F1059_8922;
	R6830[440] = (char *(*)()) F1076_9020;
	R6830[478] = (char *(*)()) F949_8553;
	{long i; for (i = 536; i < 538; i++) R6830[i] = (char *(*)()) F1171_10156;}
	{long i; for (i = 539; i < 542; i++) R6830[i] = (char *(*)()) F1174_10324;}
	R6830[555] = (char *(*)()) F713_7963;
	R6830[559] = (char *(*)()) F713_7963;
	R6830[595] = (char *(*)()) F1231_11107;
	R6830[596] = (char *(*)()) F1232_11107;
	R6830[597] = (char *(*)()) F1233_11107;
	R6830[598] = (char *(*)()) F1234_11107;
	R6830[599] = (char *(*)()) F1235_11107;
	R6830[600] = (char *(*)()) F1236_11107;
	R6830[601] = (char *(*)()) F1237_11107;
	R6830[602] = (char *(*)()) F1238_11107;
	R6830[603] = (char *(*)()) F1239_11107;
	R6830[604] = (char *(*)()) F1240_11107;
	R6830[605] = (char *(*)()) F1241_11107;
	R6830[606] = (char *(*)()) F1242_11107;
	R6830[702] = (char *(*)()) F1338_12451;
	R6830[703] = (char *(*)()) F1339_12466;
	R6830[715] = (char *(*)()) F1351_12558;
	R6830[716] = (char *(*)()) F1352_12558;
	R6830[717] = (char *(*)()) F1353_12558;
	R6830[719] = (char *(*)()) F1355_12652;
	R6830[768] = (char *(*)()) F709_7931;
	R6830[816] = (char *(*)()) F1174_10324;
}

static EIF_TYPE_INDEX Y6831_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype12[] = {0xFF01,1175,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype13[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype14[] = {0xFF01,1173,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype86[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype87[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype112[] = {0xFF01,1171,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype114[] = {0xFF01,1242,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype115[] = {0xFF01,1244,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype116[] = {0xFF01,1192,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype271[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype272[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype339[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype340[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype341[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype351[] = {1170,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype373[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype391[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype474[] = {0xFF01,1406,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype478[] = {0xFF01,1074,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype479[] = {0xFF01,1173,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype480[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype481[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype482[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype483[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype484[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype485[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype486[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype487[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype488[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype489[] = {0xFF01,1192,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype490[] = {0xFF01,1192,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype503[] = {0xFF01,1301,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype504[] = {0xFF01,1301,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype508[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype509[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype510[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype511[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype512[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype513[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype514[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype515[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype516[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype517[] = {0xFF01,1171,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype518[] = {0xFF01,1171,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype519[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y6831_pgtype520[] = {1124,0xFFFF};
EIF_TYPE_INDEX *Y6831_gen_type [857];
EIF_TYPE_INDEX Y6831 [857];
void Y6831_init (void)
{
	egc_routines_types [6831] = Y6831;
	egc_routines_gen_types [6831] = Y6831_gen_type;
	egc_routines_offset [6831] = 596;
	Y6831_gen_type [0] = Y6831_pgtype0;
	Y6831_gen_type [1] = Y6831_pgtype1;
	Y6831_gen_type [2] = Y6831_pgtype2;
	Y6831_gen_type [3] = Y6831_pgtype3;
	Y6831_gen_type [4] = Y6831_pgtype4;
	Y6831_gen_type [5] = Y6831_pgtype5;
	Y6831_gen_type [6] = Y6831_pgtype6;
	Y6831_gen_type [7] = Y6831_pgtype7;
	Y6831_gen_type [8] = Y6831_pgtype8;
	Y6831_gen_type [9] = Y6831_pgtype9;
	Y6831_gen_type [10] = Y6831_pgtype10;
	Y6831_gen_type [11] = Y6831_pgtype11;
	Y6831_gen_type [12] = Y6831_pgtype12;
	Y6831_gen_type [13] = Y6831_pgtype13;
	Y6831_gen_type [14] = Y6831_pgtype14;
	Y6831_gen_type [15] = Y6831_pgtype15;
	Y6831_gen_type [16] = Y6831_pgtype16;
	Y6831_gen_type [17] = Y6831_pgtype17;
	Y6831_gen_type [18] = Y6831_pgtype18;
	Y6831_gen_type [19] = Y6831_pgtype19;
	Y6831_gen_type [20] = Y6831_pgtype20;
	Y6831_gen_type [21] = Y6831_pgtype21;
	Y6831_gen_type [22] = Y6831_pgtype22;
	Y6831_gen_type [23] = Y6831_pgtype23;
	Y6831_gen_type [24] = Y6831_pgtype24;
	Y6831_gen_type [25] = Y6831_pgtype25;
	Y6831_gen_type [26] = Y6831_pgtype26;
	Y6831_gen_type [27] = Y6831_pgtype27;
	Y6831_gen_type [28] = Y6831_pgtype28;
	Y6831_gen_type [29] = Y6831_pgtype29;
	Y6831_gen_type [30] = Y6831_pgtype30;
	Y6831_gen_type [31] = Y6831_pgtype31;
	Y6831_gen_type [32] = Y6831_pgtype32;
	Y6831_gen_type [33] = Y6831_pgtype33;
	Y6831_gen_type [34] = Y6831_pgtype34;
	Y6831_gen_type [35] = Y6831_pgtype35;
	Y6831_gen_type [36] = Y6831_pgtype36;
	Y6831_gen_type [37] = Y6831_pgtype37;
	Y6831_gen_type [38] = Y6831_pgtype38;
	Y6831_gen_type [39] = Y6831_pgtype39;
	Y6831_gen_type [40] = Y6831_pgtype40;
	Y6831_gen_type [41] = Y6831_pgtype41;
	Y6831_gen_type [42] = Y6831_pgtype42;
	Y6831_gen_type [43] = Y6831_pgtype43;
	Y6831_gen_type [44] = Y6831_pgtype44;
	Y6831_gen_type [45] = Y6831_pgtype45;
	Y6831_gen_type [46] = Y6831_pgtype46;
	Y6831_gen_type [47] = Y6831_pgtype47;
	Y6831_gen_type [48] = Y6831_pgtype48;
	Y6831_gen_type [49] = Y6831_pgtype49;
	Y6831_gen_type [50] = Y6831_pgtype50;
	Y6831_gen_type [51] = Y6831_pgtype51;
	Y6831_gen_type [52] = Y6831_pgtype52;
	Y6831_gen_type [53] = Y6831_pgtype53;
	Y6831_gen_type [54] = Y6831_pgtype54;
	Y6831_gen_type [55] = Y6831_pgtype55;
	Y6831_gen_type [56] = Y6831_pgtype56;
	Y6831_gen_type [57] = Y6831_pgtype57;
	Y6831_gen_type [58] = Y6831_pgtype58;
	Y6831_gen_type [59] = Y6831_pgtype59;
	Y6831_gen_type [60] = Y6831_pgtype60;
	Y6831_gen_type [61] = Y6831_pgtype61;
	Y6831_gen_type [62] = Y6831_pgtype62;
	Y6831_gen_type [63] = Y6831_pgtype63;
	Y6831_gen_type [64] = Y6831_pgtype64;
	Y6831_gen_type [65] = Y6831_pgtype65;
	Y6831_gen_type [66] = Y6831_pgtype66;
	Y6831_gen_type [67] = Y6831_pgtype67;
	Y6831_gen_type [68] = Y6831_pgtype68;
	Y6831_gen_type [69] = Y6831_pgtype69;
	Y6831_gen_type [70] = Y6831_pgtype70;
	Y6831_gen_type [71] = Y6831_pgtype71;
	Y6831_gen_type [72] = Y6831_pgtype72;
	Y6831_gen_type [73] = Y6831_pgtype73;
	Y6831_gen_type [74] = Y6831_pgtype74;
	Y6831_gen_type [75] = Y6831_pgtype75;
	Y6831_gen_type [76] = Y6831_pgtype76;
	Y6831_gen_type [77] = Y6831_pgtype77;
	Y6831_gen_type [78] = Y6831_pgtype78;
	Y6831_gen_type [79] = Y6831_pgtype79;
	Y6831_gen_type [80] = Y6831_pgtype80;
	Y6831_gen_type [81] = Y6831_pgtype81;
	Y6831_gen_type [82] = Y6831_pgtype82;
	Y6831_gen_type [83] = Y6831_pgtype83;
	Y6831_gen_type [84] = Y6831_pgtype84;
	Y6831_gen_type [85] = Y6831_pgtype85;
	Y6831_gen_type [86] = Y6831_pgtype86;
	Y6831_gen_type [87] = Y6831_pgtype87;
	Y6831_gen_type [88] = Y6831_pgtype88;
	Y6831_gen_type [89] = Y6831_pgtype89;
	Y6831_gen_type [90] = Y6831_pgtype90;
	Y6831_gen_type [91] = Y6831_pgtype91;
	Y6831_gen_type [92] = Y6831_pgtype92;
	Y6831_gen_type [93] = Y6831_pgtype93;
	Y6831_gen_type [94] = Y6831_pgtype94;
	Y6831_gen_type [95] = Y6831_pgtype95;
	Y6831_gen_type [96] = Y6831_pgtype96;
	Y6831_gen_type [97] = Y6831_pgtype97;
	Y6831_gen_type [98] = Y6831_pgtype98;
	Y6831_gen_type [99] = Y6831_pgtype99;
	Y6831_gen_type [100] = Y6831_pgtype100;
	Y6831_gen_type [101] = Y6831_pgtype101;
	Y6831_gen_type [102] = Y6831_pgtype102;
	Y6831_gen_type [103] = Y6831_pgtype103;
	Y6831_gen_type [104] = Y6831_pgtype104;
	Y6831_gen_type [105] = Y6831_pgtype105;
	Y6831_gen_type [106] = Y6831_pgtype106;
	Y6831_gen_type [107] = Y6831_pgtype107;
	Y6831_gen_type [108] = Y6831_pgtype108;
	Y6831_gen_type [109] = Y6831_pgtype109;
	Y6831_gen_type [110] = Y6831_pgtype110;
	Y6831_gen_type [111] = Y6831_pgtype111;
	Y6831_gen_type [112] = Y6831_pgtype112;
	Y6831_gen_type [113] = Y6831_pgtype113;
	Y6831_gen_type [114] = Y6831_pgtype114;
	Y6831_gen_type [115] = Y6831_pgtype115;
	Y6831_gen_type [116] = Y6831_pgtype116;
	Y6831_gen_type [117] = Y6831_pgtype117;
	Y6831_gen_type [118] = Y6831_pgtype118;
	Y6831_gen_type [119] = Y6831_pgtype119;
	Y6831_gen_type [120] = Y6831_pgtype120;
	Y6831_gen_type [121] = Y6831_pgtype121;
	Y6831_gen_type [122] = Y6831_pgtype122;
	Y6831_gen_type [123] = Y6831_pgtype123;
	Y6831_gen_type [124] = Y6831_pgtype124;
	Y6831_gen_type [125] = Y6831_pgtype125;
	Y6831_gen_type [126] = Y6831_pgtype126;
	Y6831_gen_type [127] = Y6831_pgtype127;
	Y6831_gen_type [128] = Y6831_pgtype128;
	Y6831_gen_type [129] = Y6831_pgtype129;
	Y6831_gen_type [130] = Y6831_pgtype130;
	Y6831_gen_type [131] = Y6831_pgtype131;
	Y6831_gen_type [132] = Y6831_pgtype132;
	Y6831_gen_type [133] = Y6831_pgtype133;
	Y6831_gen_type [134] = Y6831_pgtype134;
	Y6831_gen_type [135] = Y6831_pgtype135;
	Y6831_gen_type [136] = Y6831_pgtype136;
	Y6831_gen_type [137] = Y6831_pgtype137;
	Y6831_gen_type [138] = Y6831_pgtype138;
	Y6831_gen_type [139] = Y6831_pgtype139;
	Y6831_gen_type [140] = Y6831_pgtype140;
	Y6831_gen_type [141] = Y6831_pgtype141;
	Y6831_gen_type [142] = Y6831_pgtype142;
	Y6831_gen_type [143] = Y6831_pgtype143;
	Y6831_gen_type [144] = Y6831_pgtype144;
	Y6831_gen_type [145] = Y6831_pgtype145;
	Y6831_gen_type [146] = Y6831_pgtype146;
	Y6831_gen_type [147] = Y6831_pgtype147;
	Y6831_gen_type [148] = Y6831_pgtype148;
	Y6831_gen_type [149] = Y6831_pgtype149;
	Y6831_gen_type [150] = Y6831_pgtype150;
	Y6831_gen_type [151] = Y6831_pgtype151;
	Y6831_gen_type [152] = Y6831_pgtype152;
	Y6831_gen_type [153] = Y6831_pgtype153;
	Y6831_gen_type [154] = Y6831_pgtype154;
	Y6831_gen_type [155] = Y6831_pgtype155;
	Y6831_gen_type [156] = Y6831_pgtype156;
	Y6831_gen_type [157] = Y6831_pgtype157;
	Y6831_gen_type [158] = Y6831_pgtype158;
	Y6831_gen_type [159] = Y6831_pgtype159;
	Y6831_gen_type [160] = Y6831_pgtype160;
	Y6831_gen_type [161] = Y6831_pgtype161;
	Y6831_gen_type [162] = Y6831_pgtype162;
	Y6831_gen_type [163] = Y6831_pgtype163;
	Y6831_gen_type [164] = Y6831_pgtype164;
	Y6831_gen_type [165] = Y6831_pgtype165;
	Y6831_gen_type [166] = Y6831_pgtype166;
	Y6831_gen_type [167] = Y6831_pgtype167;
	Y6831_gen_type [168] = Y6831_pgtype168;
	Y6831_gen_type [169] = Y6831_pgtype169;
	Y6831_gen_type [170] = Y6831_pgtype170;
	Y6831_gen_type [171] = Y6831_pgtype171;
	Y6831_gen_type [172] = Y6831_pgtype172;
	Y6831_gen_type [173] = Y6831_pgtype173;
	Y6831_gen_type [174] = Y6831_pgtype174;
	Y6831_gen_type [175] = Y6831_pgtype175;
	Y6831_gen_type [176] = Y6831_pgtype176;
	Y6831_gen_type [177] = Y6831_pgtype177;
	Y6831_gen_type [178] = Y6831_pgtype178;
	Y6831_gen_type [179] = Y6831_pgtype179;
	Y6831_gen_type [180] = Y6831_pgtype180;
	Y6831_gen_type [181] = Y6831_pgtype181;
	Y6831_gen_type [182] = Y6831_pgtype182;
	Y6831_gen_type [183] = Y6831_pgtype183;
	Y6831_gen_type [184] = Y6831_pgtype184;
	Y6831_gen_type [185] = Y6831_pgtype185;
	Y6831_gen_type [186] = Y6831_pgtype186;
	Y6831_gen_type [187] = Y6831_pgtype187;
	Y6831_gen_type [188] = Y6831_pgtype188;
	Y6831_gen_type [189] = Y6831_pgtype189;
	Y6831_gen_type [190] = Y6831_pgtype190;
	Y6831_gen_type [191] = Y6831_pgtype191;
	Y6831_gen_type [192] = Y6831_pgtype192;
	Y6831_gen_type [193] = Y6831_pgtype193;
	Y6831_gen_type [194] = Y6831_pgtype194;
	Y6831_gen_type [195] = Y6831_pgtype195;
	Y6831_gen_type [196] = Y6831_pgtype196;
	Y6831_gen_type [197] = Y6831_pgtype197;
	Y6831_gen_type [198] = Y6831_pgtype198;
	Y6831_gen_type [199] = Y6831_pgtype199;
	Y6831_gen_type [200] = Y6831_pgtype200;
	Y6831_gen_type [201] = Y6831_pgtype201;
	Y6831_gen_type [202] = Y6831_pgtype202;
	Y6831_gen_type [203] = Y6831_pgtype203;
	Y6831_gen_type [204] = Y6831_pgtype204;
	Y6831_gen_type [205] = Y6831_pgtype205;
	Y6831_gen_type [206] = Y6831_pgtype206;
	Y6831_gen_type [207] = Y6831_pgtype207;
	Y6831_gen_type [208] = Y6831_pgtype208;
	Y6831_gen_type [209] = Y6831_pgtype209;
	Y6831_gen_type [210] = Y6831_pgtype210;
	Y6831_gen_type [211] = Y6831_pgtype211;
	Y6831_gen_type [212] = Y6831_pgtype212;
	Y6831_gen_type [213] = Y6831_pgtype213;
	Y6831_gen_type [214] = Y6831_pgtype214;
	Y6831_gen_type [215] = Y6831_pgtype215;
	Y6831_gen_type [216] = Y6831_pgtype216;
	Y6831_gen_type [217] = Y6831_pgtype217;
	Y6831_gen_type [218] = Y6831_pgtype218;
	Y6831_gen_type [219] = Y6831_pgtype219;
	Y6831_gen_type [220] = Y6831_pgtype220;
	Y6831_gen_type [221] = Y6831_pgtype221;
	Y6831_gen_type [222] = Y6831_pgtype222;
	Y6831_gen_type [223] = Y6831_pgtype223;
	Y6831_gen_type [224] = Y6831_pgtype224;
	Y6831_gen_type [225] = Y6831_pgtype225;
	Y6831_gen_type [226] = Y6831_pgtype226;
	Y6831_gen_type [227] = Y6831_pgtype227;
	Y6831_gen_type [228] = Y6831_pgtype228;
	Y6831_gen_type [229] = Y6831_pgtype229;
	Y6831_gen_type [230] = Y6831_pgtype230;
	Y6831_gen_type [231] = Y6831_pgtype231;
	Y6831_gen_type [232] = Y6831_pgtype232;
	Y6831_gen_type [233] = Y6831_pgtype233;
	Y6831_gen_type [234] = Y6831_pgtype234;
	Y6831_gen_type [235] = Y6831_pgtype235;
	Y6831_gen_type [236] = Y6831_pgtype236;
	Y6831_gen_type [237] = Y6831_pgtype237;
	Y6831_gen_type [238] = Y6831_pgtype238;
	Y6831_gen_type [239] = Y6831_pgtype239;
	Y6831_gen_type [240] = Y6831_pgtype240;
	Y6831_gen_type [241] = Y6831_pgtype241;
	Y6831_gen_type [242] = Y6831_pgtype242;
	Y6831_gen_type [243] = Y6831_pgtype243;
	Y6831_gen_type [244] = Y6831_pgtype244;
	Y6831_gen_type [245] = Y6831_pgtype245;
	Y6831_gen_type [246] = Y6831_pgtype246;
	Y6831_gen_type [247] = Y6831_pgtype247;
	Y6831_gen_type [248] = Y6831_pgtype248;
	Y6831_gen_type [249] = Y6831_pgtype249;
	Y6831_gen_type [250] = Y6831_pgtype250;
	Y6831_gen_type [251] = Y6831_pgtype251;
	Y6831_gen_type [252] = Y6831_pgtype252;
	Y6831_gen_type [253] = Y6831_pgtype253;
	Y6831_gen_type [254] = Y6831_pgtype254;
	Y6831_gen_type [255] = Y6831_pgtype255;
	Y6831_gen_type [256] = Y6831_pgtype256;
	Y6831_gen_type [257] = Y6831_pgtype257;
	Y6831_gen_type [258] = Y6831_pgtype258;
	Y6831_gen_type [259] = Y6831_pgtype259;
	Y6831_gen_type [260] = Y6831_pgtype260;
	Y6831_gen_type [261] = Y6831_pgtype261;
	Y6831_gen_type [262] = Y6831_pgtype262;
	Y6831_gen_type [263] = Y6831_pgtype263;
	Y6831_gen_type [264] = Y6831_pgtype264;
	Y6831_gen_type [265] = Y6831_pgtype265;
	Y6831_gen_type [266] = Y6831_pgtype266;
	Y6831_gen_type [267] = Y6831_pgtype267;
	Y6831_gen_type [268] = Y6831_pgtype268;
	Y6831_gen_type [269] = Y6831_pgtype269;
	Y6831_gen_type [270] = Y6831_pgtype270;
	Y6831_gen_type [271] = Y6831_pgtype271;
	Y6831_gen_type [272] = Y6831_pgtype272;
	Y6831_gen_type [273] = Y6831_pgtype273;
	Y6831_gen_type [274] = Y6831_pgtype274;
	Y6831_gen_type [275] = Y6831_pgtype275;
	Y6831_gen_type [276] = Y6831_pgtype276;
	Y6831_gen_type [277] = Y6831_pgtype277;
	Y6831_gen_type [278] = Y6831_pgtype278;
	Y6831_gen_type [279] = Y6831_pgtype279;
	Y6831_gen_type [280] = Y6831_pgtype280;
	Y6831_gen_type [281] = Y6831_pgtype281;
	Y6831_gen_type [282] = Y6831_pgtype282;
	Y6831_gen_type [283] = Y6831_pgtype283;
	Y6831_gen_type [284] = Y6831_pgtype284;
	Y6831_gen_type [285] = Y6831_pgtype285;
	Y6831_gen_type [286] = Y6831_pgtype286;
	Y6831_gen_type [287] = Y6831_pgtype287;
	Y6831_gen_type [288] = Y6831_pgtype288;
	Y6831_gen_type [289] = Y6831_pgtype289;
	Y6831_gen_type [290] = Y6831_pgtype290;
	Y6831_gen_type [291] = Y6831_pgtype291;
	Y6831_gen_type [292] = Y6831_pgtype292;
	Y6831_gen_type [293] = Y6831_pgtype293;
	Y6831_gen_type [294] = Y6831_pgtype294;
	Y6831_gen_type [295] = Y6831_pgtype295;
	Y6831_gen_type [296] = Y6831_pgtype296;
	Y6831_gen_type [297] = Y6831_pgtype297;
	Y6831_gen_type [298] = Y6831_pgtype298;
	Y6831_gen_type [299] = Y6831_pgtype299;
	Y6831_gen_type [300] = Y6831_pgtype300;
	Y6831_gen_type [301] = Y6831_pgtype301;
	Y6831_gen_type [302] = Y6831_pgtype302;
	Y6831_gen_type [303] = Y6831_pgtype303;
	Y6831_gen_type [304] = Y6831_pgtype304;
	Y6831_gen_type [305] = Y6831_pgtype305;
	Y6831_gen_type [306] = Y6831_pgtype306;
	Y6831_gen_type [307] = Y6831_pgtype307;
	Y6831_gen_type [308] = Y6831_pgtype308;
	Y6831_gen_type [309] = Y6831_pgtype309;
	Y6831_gen_type [310] = Y6831_pgtype310;
	Y6831_gen_type [311] = Y6831_pgtype311;
	Y6831_gen_type [312] = Y6831_pgtype312;
	Y6831_gen_type [313] = Y6831_pgtype313;
	Y6831_gen_type [314] = Y6831_pgtype314;
	Y6831_gen_type [315] = Y6831_pgtype315;
	Y6831_gen_type [316] = Y6831_pgtype316;
	Y6831_gen_type [317] = Y6831_pgtype317;
	Y6831_gen_type [318] = Y6831_pgtype318;
	Y6831_gen_type [319] = Y6831_pgtype319;
	Y6831_gen_type [320] = Y6831_pgtype320;
	Y6831_gen_type [321] = Y6831_pgtype321;
	Y6831_gen_type [322] = Y6831_pgtype322;
	Y6831_gen_type [323] = Y6831_pgtype323;
	Y6831_gen_type [324] = Y6831_pgtype324;
	Y6831_gen_type [325] = Y6831_pgtype325;
	Y6831_gen_type [326] = Y6831_pgtype326;
	Y6831_gen_type [327] = Y6831_pgtype327;
	Y6831_gen_type [328] = Y6831_pgtype328;
	Y6831_gen_type [329] = Y6831_pgtype329;
	Y6831_gen_type [330] = Y6831_pgtype330;
	Y6831_gen_type [331] = Y6831_pgtype331;
	Y6831_gen_type [332] = Y6831_pgtype332;
	Y6831_gen_type [333] = Y6831_pgtype333;
	Y6831_gen_type [334] = Y6831_pgtype334;
	Y6831_gen_type [335] = Y6831_pgtype335;
	Y6831_gen_type [336] = Y6831_pgtype336;
	Y6831_gen_type [337] = Y6831_pgtype337;
	Y6831_gen_type [338] = Y6831_pgtype338;
	Y6831_gen_type [339] = Y6831_pgtype339;
	Y6831_gen_type [340] = Y6831_pgtype340;
	Y6831_gen_type [341] = Y6831_pgtype341;
	Y6831_gen_type [342] = Y6831_pgtype342;
	Y6831_gen_type [343] = Y6831_pgtype343;
	Y6831_gen_type [344] = Y6831_pgtype344;
	Y6831_gen_type [345] = Y6831_pgtype345;
	Y6831_gen_type [346] = Y6831_pgtype346;
	Y6831_gen_type [347] = Y6831_pgtype347;
	Y6831_gen_type [348] = Y6831_pgtype348;
	Y6831_gen_type [349] = Y6831_pgtype349;
	Y6831_gen_type [350] = Y6831_pgtype350;
	Y6831_gen_type [351] = Y6831_pgtype351;
	Y6831_gen_type [352] = Y6831_pgtype352;
	Y6831_gen_type [353] = Y6831_pgtype353;
	Y6831_gen_type [354] = Y6831_pgtype354;
	Y6831_gen_type [355] = Y6831_pgtype355;
	Y6831_gen_type [356] = Y6831_pgtype356;
	Y6831_gen_type [357] = Y6831_pgtype357;
	Y6831_gen_type [358] = Y6831_pgtype358;
	Y6831_gen_type [359] = Y6831_pgtype359;
	Y6831_gen_type [360] = Y6831_pgtype360;
	Y6831_gen_type [361] = Y6831_pgtype361;
	Y6831_gen_type [362] = Y6831_pgtype362;
	Y6831_gen_type [363] = Y6831_pgtype363;
	Y6831_gen_type [364] = Y6831_pgtype364;
	Y6831_gen_type [365] = Y6831_pgtype365;
	Y6831_gen_type [366] = Y6831_pgtype366;
	Y6831_gen_type [367] = Y6831_pgtype367;
	Y6831_gen_type [368] = Y6831_pgtype368;
	Y6831_gen_type [369] = Y6831_pgtype369;
	Y6831_gen_type [370] = Y6831_pgtype370;
	Y6831_gen_type [371] = Y6831_pgtype371;
	Y6831_gen_type [372] = Y6831_pgtype372;
	Y6831_gen_type [373] = Y6831_pgtype373;
	Y6831_gen_type [374] = Y6831_pgtype374;
	Y6831_gen_type [375] = Y6831_pgtype375;
	Y6831_gen_type [376] = Y6831_pgtype376;
	Y6831_gen_type [377] = Y6831_pgtype377;
	Y6831_gen_type [378] = Y6831_pgtype378;
	Y6831_gen_type [379] = Y6831_pgtype379;
	Y6831_gen_type [380] = Y6831_pgtype380;
	Y6831_gen_type [381] = Y6831_pgtype381;
	Y6831_gen_type [382] = Y6831_pgtype382;
	Y6831_gen_type [383] = Y6831_pgtype383;
	Y6831_gen_type [384] = Y6831_pgtype384;
	Y6831_gen_type [385] = Y6831_pgtype385;
	Y6831_gen_type [386] = Y6831_pgtype386;
	Y6831_gen_type [387] = Y6831_pgtype387;
	Y6831_gen_type [388] = Y6831_pgtype388;
	Y6831_gen_type [389] = Y6831_pgtype389;
	Y6831_gen_type [390] = Y6831_pgtype390;
	Y6831_gen_type [391] = Y6831_pgtype391;
	Y6831_gen_type [392] = Y6831_pgtype392;
	Y6831_gen_type [393] = Y6831_pgtype393;
	Y6831_gen_type [394] = Y6831_pgtype394;
	Y6831_gen_type [395] = Y6831_pgtype395;
	Y6831_gen_type [396] = Y6831_pgtype396;
	Y6831_gen_type [397] = Y6831_pgtype397;
	Y6831_gen_type [398] = Y6831_pgtype398;
	Y6831_gen_type [399] = Y6831_pgtype399;
	Y6831_gen_type [400] = Y6831_pgtype400;
	Y6831_gen_type [401] = Y6831_pgtype401;
	Y6831_gen_type [402] = Y6831_pgtype402;
	Y6831_gen_type [403] = Y6831_pgtype403;
	Y6831_gen_type [404] = Y6831_pgtype404;
	Y6831_gen_type [405] = Y6831_pgtype405;
	Y6831_gen_type [406] = Y6831_pgtype406;
	Y6831_gen_type [407] = Y6831_pgtype407;
	Y6831_gen_type [408] = Y6831_pgtype408;
	Y6831_gen_type [409] = Y6831_pgtype409;
	Y6831_gen_type [410] = Y6831_pgtype410;
	Y6831_gen_type [411] = Y6831_pgtype411;
	Y6831_gen_type [412] = Y6831_pgtype412;
	Y6831_gen_type [413] = Y6831_pgtype413;
	Y6831_gen_type [414] = Y6831_pgtype414;
	Y6831_gen_type [415] = Y6831_pgtype415;
	Y6831_gen_type [416] = Y6831_pgtype416;
	Y6831_gen_type [417] = Y6831_pgtype417;
	Y6831_gen_type [418] = Y6831_pgtype418;
	Y6831_gen_type [419] = Y6831_pgtype419;
	Y6831_gen_type [420] = Y6831_pgtype420;
	Y6831_gen_type [421] = Y6831_pgtype421;
	Y6831_gen_type [422] = Y6831_pgtype422;
	Y6831_gen_type [423] = Y6831_pgtype423;
	Y6831_gen_type [424] = Y6831_pgtype424;
	Y6831_gen_type [425] = Y6831_pgtype425;
	Y6831_gen_type [426] = Y6831_pgtype426;
	Y6831_gen_type [427] = Y6831_pgtype427;
	Y6831_gen_type [428] = Y6831_pgtype428;
	Y6831_gen_type [429] = Y6831_pgtype429;
	Y6831_gen_type [430] = Y6831_pgtype430;
	Y6831_gen_type [431] = Y6831_pgtype431;
	Y6831_gen_type [432] = Y6831_pgtype432;
	Y6831_gen_type [433] = Y6831_pgtype433;
	Y6831_gen_type [434] = Y6831_pgtype434;
	Y6831_gen_type [435] = Y6831_pgtype435;
	Y6831_gen_type [436] = Y6831_pgtype436;
	Y6831_gen_type [437] = Y6831_pgtype437;
	Y6831_gen_type [438] = Y6831_pgtype438;
	Y6831_gen_type [439] = Y6831_pgtype439;
	Y6831_gen_type [440] = Y6831_pgtype440;
	Y6831_gen_type [441] = Y6831_pgtype441;
	Y6831_gen_type [442] = Y6831_pgtype442;
	Y6831_gen_type [443] = Y6831_pgtype443;
	Y6831_gen_type [444] = Y6831_pgtype444;
	Y6831_gen_type [445] = Y6831_pgtype445;
	Y6831_gen_type [446] = Y6831_pgtype446;
	Y6831_gen_type [447] = Y6831_pgtype447;
	Y6831_gen_type [448] = Y6831_pgtype448;
	Y6831_gen_type [449] = Y6831_pgtype449;
	Y6831_gen_type [450] = Y6831_pgtype450;
	Y6831_gen_type [451] = Y6831_pgtype451;
	Y6831_gen_type [452] = Y6831_pgtype452;
	Y6831_gen_type [453] = Y6831_pgtype453;
	Y6831_gen_type [454] = Y6831_pgtype454;
	Y6831_gen_type [455] = Y6831_pgtype455;
	Y6831_gen_type [456] = Y6831_pgtype456;
	Y6831_gen_type [457] = Y6831_pgtype457;
	Y6831_gen_type [458] = Y6831_pgtype458;
	Y6831_gen_type [459] = Y6831_pgtype459;
	Y6831_gen_type [460] = Y6831_pgtype460;
	Y6831_gen_type [461] = Y6831_pgtype461;
	Y6831_gen_type [462] = Y6831_pgtype462;
	Y6831_gen_type [463] = Y6831_pgtype463;
	Y6831_gen_type [464] = Y6831_pgtype464;
	Y6831_gen_type [465] = Y6831_pgtype465;
	Y6831_gen_type [466] = Y6831_pgtype466;
	Y6831_gen_type [467] = Y6831_pgtype467;
	Y6831_gen_type [468] = Y6831_pgtype468;
	Y6831_gen_type [469] = Y6831_pgtype469;
	Y6831_gen_type [470] = Y6831_pgtype470;
	Y6831_gen_type [471] = Y6831_pgtype471;
	Y6831_gen_type [472] = Y6831_pgtype472;
	Y6831_gen_type [473] = Y6831_pgtype473;
	Y6831_gen_type [474] = Y6831_pgtype474;
	Y6831_gen_type [475] = Y6831_pgtype475;
	Y6831_gen_type [476] = Y6831_pgtype476;
	Y6831_gen_type [477] = Y6831_pgtype477;
	Y6831_gen_type [478] = Y6831_pgtype478;
	Y6831_gen_type [479] = Y6831_pgtype479;
	Y6831_gen_type [517] = Y6831_pgtype480;
	Y6831_gen_type [574] = Y6831_pgtype481;
	Y6831_gen_type [575] = Y6831_pgtype482;
	Y6831_gen_type [576] = Y6831_pgtype483;
	Y6831_gen_type [577] = Y6831_pgtype484;
	Y6831_gen_type [578] = Y6831_pgtype485;
	Y6831_gen_type [579] = Y6831_pgtype486;
	Y6831_gen_type [580] = Y6831_pgtype487;
	Y6831_gen_type [581] = Y6831_pgtype488;
	Y6831_gen_type [594] = Y6831_pgtype489;
	Y6831_gen_type [598] = Y6831_pgtype490;
	Y6831_gen_type [634] = Y6831_pgtype491;
	Y6831_gen_type [635] = Y6831_pgtype492;
	Y6831_gen_type [636] = Y6831_pgtype493;
	Y6831_gen_type [637] = Y6831_pgtype494;
	Y6831_gen_type [638] = Y6831_pgtype495;
	Y6831_gen_type [639] = Y6831_pgtype496;
	Y6831_gen_type [640] = Y6831_pgtype497;
	Y6831_gen_type [641] = Y6831_pgtype498;
	Y6831_gen_type [642] = Y6831_pgtype499;
	Y6831_gen_type [643] = Y6831_pgtype500;
	Y6831_gen_type [644] = Y6831_pgtype501;
	Y6831_gen_type [645] = Y6831_pgtype502;
	Y6831_gen_type [741] = Y6831_pgtype503;
	Y6831_gen_type [742] = Y6831_pgtype504;
	Y6831_gen_type [754] = Y6831_pgtype505;
	Y6831_gen_type [755] = Y6831_pgtype506;
	Y6831_gen_type [756] = Y6831_pgtype507;
	Y6831_gen_type [758] = Y6831_pgtype508;
	Y6831_gen_type [793] = Y6831_pgtype509;
	Y6831_gen_type [794] = Y6831_pgtype510;
	Y6831_gen_type [795] = Y6831_pgtype511;
	Y6831_gen_type [797] = Y6831_pgtype512;
	Y6831_gen_type [798] = Y6831_pgtype513;
	Y6831_gen_type [799] = Y6831_pgtype514;
	Y6831_gen_type [800] = Y6831_pgtype515;
	Y6831_gen_type [801] = Y6831_pgtype516;
	Y6831_gen_type [806] = Y6831_pgtype517;
	Y6831_gen_type [807] = Y6831_pgtype518;
	Y6831_gen_type [855] = Y6831_pgtype519;
	Y6831_gen_type [856] = Y6831_pgtype520;
	Y6831[12] = 1175;
	Y6831[13] = 1121;
	Y6831[14] = 1173;
	Y6831[86] = 1121;
	Y6831[87] = 1124;
	Y6831[112] = 1171;
	Y6831[114] = 1242;
	Y6831[115] = 1244;
	Y6831[116] = 1192;
	{long i; for (i = 271; i < 273; i++) Y6831[i] = 1312;};
	{long i; for (i = 339; i < 342; i++) Y6831[i] = 1124;};
	Y6831[351] = 1170;
	Y6831[373] = 0;
	Y6831[391] = 1312;
	Y6831[474] = 1406;
	Y6831[478] = 1074;
	Y6831[479] = 1173;
	Y6831[517] = 0;
	{long i; for (i = 574; i < 577; i++) Y6831[i] = 1121;};
	{long i; for (i = 577; i < 582; i++) Y6831[i] = 1124;};
	Y6831[594] = 1192;
	Y6831[598] = 1192;
	{long i; for (i = 741; i < 743; i++) Y6831[i] = 1301;};
	Y6831[758] = 1124;
	{long i; for (i = 793; i < 796; i++) Y6831[i] = 1124;};
	{long i; for (i = 797; i < 802; i++) Y6831[i] = 1124;};
	{long i; for (i = 806; i < 808; i++) Y6831[i] = 1171;};
	{long i; for (i = 855; i < 857; i++) Y6831[i] = 1124;};
}

char *(*R6949[73])();
void R6949_init () {
	R6949[0] = (char *(*)()) F636_7847;
	R6949[1] = (char *(*)()) F637_7847;
	R6949[2] = (char *(*)()) F638_7847;
	R6949[3] = (char *(*)()) F639_7847;
	R6949[4] = (char *(*)()) F640_7847;
	R6949[5] = (char *(*)()) F641_7847;
	R6949[6] = (char *(*)()) F642_7847;
	R6949[7] = (char *(*)()) F643_7847;
	R6949[8] = (char *(*)()) F644_7847;
	R6949[9] = (char *(*)()) F645_7847;
	R6949[10] = (char *(*)()) F646_7847;
	R6949[11] = (char *(*)()) F647_7847;
	R6949[12] = (char *(*)()) F636_7847;
	R6949[13] = (char *(*)()) F638_7847;
	R6949[14] = (char *(*)()) F636_7847;
	R6949[15] = (char *(*)()) F637_7847;
	R6949[16] = (char *(*)()) F636_7847;
	R6949[17] = (char *(*)()) F642_7847;
	R6949[18] = (char *(*)()) F636_7847;
	{long i; for (i = 19; i < 21; i++) R6949[i] = (char *(*)()) F638_7847;}
	R6949[21] = (char *(*)()) F641_7847;
	R6949[22] = (char *(*)()) F645_7847;
	R6949[35] = (char *(*)()) F659_7881;
	R6949[36] = (char *(*)()) F660_7881;
	R6949[37] = (char *(*)()) F661_7881;
	R6949[38] = (char *(*)()) F662_7881;
	R6949[39] = (char *(*)()) F663_7881;
	R6949[40] = (char *(*)()) F664_7881;
	R6949[41] = (char *(*)()) F665_7881;
	R6949[42] = (char *(*)()) F666_7881;
	R6949[43] = (char *(*)()) F667_7881;
	R6949[44] = (char *(*)()) F668_7881;
	R6949[45] = (char *(*)()) F669_7881;
	R6949[46] = (char *(*)()) F670_7881;
	R6949[47] = (char *(*)()) F667_7881;
	R6949[48] = (char *(*)()) F663_7881;
	R6949[49] = (char *(*)()) F659_7881;
	R6949[50] = (char *(*)()) F660_7881;
	R6949[51] = (char *(*)()) F661_7881;
	R6949[52] = (char *(*)()) F662_7881;
	R6949[53] = (char *(*)()) F663_7881;
	R6949[54] = (char *(*)()) F664_7881;
	R6949[55] = (char *(*)()) F665_7881;
	R6949[56] = (char *(*)()) F666_7881;
	R6949[57] = (char *(*)()) F667_7881;
	R6949[58] = (char *(*)()) F668_7881;
	R6949[59] = (char *(*)()) F669_7881;
	R6949[60] = (char *(*)()) F670_7881;
	R6949[61] = (char *(*)()) F659_7881;
	R6949[62] = (char *(*)()) F660_7881;
	R6949[63] = (char *(*)()) F661_7881;
	R6949[64] = (char *(*)()) F662_7881;
	R6949[65] = (char *(*)()) F663_7881;
	R6949[66] = (char *(*)()) F664_7881;
	R6949[67] = (char *(*)()) F665_7881;
	R6949[68] = (char *(*)()) F666_7881;
	R6949[69] = (char *(*)()) F667_7881;
	R6949[70] = (char *(*)()) F668_7881;
	R6949[71] = (char *(*)()) F669_7881;
	R6949[72] = (char *(*)()) F670_7881;
}

char *(*R6950[73])();
void R6950_init () {
	R6950[0] = (char *(*)()) F636_7848;
	R6950[1] = (char *(*)()) F637_7848;
	R6950[2] = (char *(*)()) F638_7848;
	R6950[3] = (char *(*)()) F639_7848;
	R6950[4] = (char *(*)()) F640_7848;
	R6950[5] = (char *(*)()) F641_7848;
	R6950[6] = (char *(*)()) F642_7848;
	R6950[7] = (char *(*)()) F643_7848;
	R6950[8] = (char *(*)()) F644_7848;
	R6950[9] = (char *(*)()) F645_7848;
	R6950[10] = (char *(*)()) F646_7848;
	R6950[11] = (char *(*)()) F647_7848;
	R6950[12] = (char *(*)()) F636_7848;
	R6950[13] = (char *(*)()) F638_7848;
	R6950[14] = (char *(*)()) F636_7848;
	R6950[15] = (char *(*)()) F637_7848;
	R6950[16] = (char *(*)()) F636_7848;
	R6950[17] = (char *(*)()) F642_7848;
	R6950[18] = (char *(*)()) F636_7848;
	{long i; for (i = 19; i < 21; i++) R6950[i] = (char *(*)()) F638_7848;}
	R6950[21] = (char *(*)()) F641_7848;
	R6950[22] = (char *(*)()) F645_7848;
	R6950[35] = (char *(*)()) F671_7900;
	R6950[36] = (char *(*)()) F672_7900;
	R6950[37] = (char *(*)()) F673_7900;
	R6950[38] = (char *(*)()) F674_7900;
	R6950[39] = (char *(*)()) F675_7900;
	R6950[40] = (char *(*)()) F676_7900;
	R6950[41] = (char *(*)()) F677_7900;
	R6950[42] = (char *(*)()) F678_7900;
	R6950[43] = (char *(*)()) F679_7900;
	R6950[44] = (char *(*)()) F680_7900;
	R6950[45] = (char *(*)()) F681_7900;
	R6950[46] = (char *(*)()) F682_7900;
	R6950[47] = (char *(*)()) F683_7906;
	R6950[48] = (char *(*)()) F684_7912;
	R6950[49] = (char *(*)()) F685_7918;
	R6950[50] = (char *(*)()) F686_7918;
	R6950[51] = (char *(*)()) F687_7918;
	R6950[52] = (char *(*)()) F688_7918;
	R6950[53] = (char *(*)()) F689_7918;
	R6950[54] = (char *(*)()) F690_7918;
	R6950[55] = (char *(*)()) F691_7918;
	R6950[56] = (char *(*)()) F692_7918;
	R6950[57] = (char *(*)()) F693_7918;
	R6950[58] = (char *(*)()) F694_7918;
	R6950[59] = (char *(*)()) F695_7918;
	R6950[60] = (char *(*)()) F696_7918;
	R6950[61] = (char *(*)()) F697_7924;
	R6950[62] = (char *(*)()) F698_7924;
	R6950[63] = (char *(*)()) F699_7924;
	R6950[64] = (char *(*)()) F700_7924;
	R6950[65] = (char *(*)()) F701_7924;
	R6950[66] = (char *(*)()) F702_7924;
	R6950[67] = (char *(*)()) F703_7924;
	R6950[68] = (char *(*)()) F704_7924;
	R6950[69] = (char *(*)()) F705_7924;
	R6950[70] = (char *(*)()) F706_7924;
	R6950[71] = (char *(*)()) F707_7924;
	R6950[72] = (char *(*)()) F708_7924;
}

char *(*R6958[23])();
void R6958_init () {
	R6958[0] = (char *(*)()) F636_7859;
	R6958[1] = (char *(*)()) F637_7859;
	R6958[2] = (char *(*)()) F638_7859;
	R6958[3] = (char *(*)()) F639_7859;
	R6958[4] = (char *(*)()) F640_7859;
	R6958[5] = (char *(*)()) F641_7859;
	R6958[6] = (char *(*)()) F642_7859;
	R6958[7] = (char *(*)()) F643_7859;
	R6958[8] = (char *(*)()) F644_7859;
	R6958[9] = (char *(*)()) F645_7859;
	R6958[10] = (char *(*)()) F646_7859;
	R6958[11] = (char *(*)()) F647_7859;
	R6958[12] = (char *(*)()) F636_7859;
	R6958[13] = (char *(*)()) F638_7859;
	R6958[14] = (char *(*)()) F636_7859;
	R6958[15] = (char *(*)()) F637_7859;
	R6958[16] = (char *(*)()) F636_7859;
	R6958[17] = (char *(*)()) F642_7859;
	R6958[18] = (char *(*)()) F636_7859;
	{long i; for (i = 19; i < 21; i++) R6958[i] = (char *(*)()) F638_7859;}
	R6958[21] = (char *(*)()) F641_7859;
	R6958[22] = (char *(*)()) F645_7859;
}

char *(*R6960[73])();
void R6960_init () {
	R6960[0] = (char *(*)()) F636_7861;
	R6960[1] = (char *(*)()) F637_7861;
	R6960[2] = (char *(*)()) F638_7861;
	R6960[3] = (char *(*)()) F639_7861;
	R6960[4] = (char *(*)()) F640_7861;
	R6960[5] = (char *(*)()) F641_7861;
	R6960[6] = (char *(*)()) F642_7861;
	R6960[7] = (char *(*)()) F643_7861;
	R6960[8] = (char *(*)()) F644_7861;
	R6960[9] = (char *(*)()) F645_7861;
	R6960[10] = (char *(*)()) F646_7861;
	R6960[11] = (char *(*)()) F647_7861;
	R6960[12] = (char *(*)()) F636_7861;
	R6960[13] = (char *(*)()) F638_7861;
	R6960[14] = (char *(*)()) F636_7861;
	R6960[15] = (char *(*)()) F637_7861;
	R6960[16] = (char *(*)()) F636_7861;
	R6960[17] = (char *(*)()) F642_7861;
	R6960[18] = (char *(*)()) F636_7861;
	{long i; for (i = 19; i < 21; i++) R6960[i] = (char *(*)()) F638_7861;}
	R6960[21] = (char *(*)()) F641_7861;
	R6960[22] = (char *(*)()) F645_7861;
	R6960[35] = (char *(*)()) F659_7892;
	R6960[36] = (char *(*)()) F660_7892;
	R6960[37] = (char *(*)()) F661_7892;
	R6960[38] = (char *(*)()) F662_7892;
	R6960[39] = (char *(*)()) F663_7892;
	R6960[40] = (char *(*)()) F664_7892;
	R6960[41] = (char *(*)()) F665_7892;
	R6960[42] = (char *(*)()) F666_7892;
	R6960[43] = (char *(*)()) F667_7892;
	R6960[44] = (char *(*)()) F668_7892;
	R6960[45] = (char *(*)()) F669_7892;
	R6960[46] = (char *(*)()) F670_7892;
	R6960[47] = (char *(*)()) F667_7892;
	R6960[48] = (char *(*)()) F663_7892;
	R6960[49] = (char *(*)()) F659_7892;
	R6960[50] = (char *(*)()) F660_7892;
	R6960[51] = (char *(*)()) F661_7892;
	R6960[52] = (char *(*)()) F662_7892;
	R6960[53] = (char *(*)()) F663_7892;
	R6960[54] = (char *(*)()) F664_7892;
	R6960[55] = (char *(*)()) F665_7892;
	R6960[56] = (char *(*)()) F666_7892;
	R6960[57] = (char *(*)()) F667_7892;
	R6960[58] = (char *(*)()) F668_7892;
	R6960[59] = (char *(*)()) F669_7892;
	R6960[60] = (char *(*)()) F670_7892;
	R6960[61] = (char *(*)()) F659_7892;
	R6960[62] = (char *(*)()) F660_7892;
	R6960[63] = (char *(*)()) F661_7892;
	R6960[64] = (char *(*)()) F662_7892;
	R6960[65] = (char *(*)()) F663_7892;
	R6960[66] = (char *(*)()) F664_7892;
	R6960[67] = (char *(*)()) F665_7892;
	R6960[68] = (char *(*)()) F666_7892;
	R6960[69] = (char *(*)()) F667_7892;
	R6960[70] = (char *(*)()) F668_7892;
	R6960[71] = (char *(*)()) F669_7892;
	R6960[72] = (char *(*)()) F670_7892;
}

char *(*R6961[73])();
void R6961_init () {
	R6961[0] = (char *(*)()) F636_7864;
	R6961[1] = (char *(*)()) F637_7864;
	R6961[2] = (char *(*)()) F638_7864;
	R6961[3] = (char *(*)()) F639_7864;
	R6961[4] = (char *(*)()) F640_7864;
	R6961[5] = (char *(*)()) F641_7864;
	R6961[6] = (char *(*)()) F642_7864;
	R6961[7] = (char *(*)()) F643_7864;
	R6961[8] = (char *(*)()) F644_7864;
	R6961[9] = (char *(*)()) F645_7864;
	R6961[10] = (char *(*)()) F646_7864;
	R6961[11] = (char *(*)()) F647_7864;
	R6961[12] = (char *(*)()) F648_7869;
	R6961[13] = (char *(*)()) F649_7869;
	R6961[14] = (char *(*)()) F636_7864;
	R6961[15] = (char *(*)()) F637_7864;
	R6961[16] = (char *(*)()) F636_7864;
	R6961[17] = (char *(*)()) F642_7864;
	R6961[18] = (char *(*)()) F636_7864;
	{long i; for (i = 19; i < 21; i++) R6961[i] = (char *(*)()) F638_7864;}
	R6961[21] = (char *(*)()) F641_7864;
	R6961[22] = (char *(*)()) F645_7864;
	R6961[35] = (char *(*)()) F659_7893;
	R6961[36] = (char *(*)()) F660_7893;
	R6961[37] = (char *(*)()) F661_7893;
	R6961[38] = (char *(*)()) F662_7893;
	R6961[39] = (char *(*)()) F663_7893;
	R6961[40] = (char *(*)()) F664_7893;
	R6961[41] = (char *(*)()) F665_7893;
	R6961[42] = (char *(*)()) F666_7893;
	R6961[43] = (char *(*)()) F667_7893;
	R6961[44] = (char *(*)()) F668_7893;
	R6961[45] = (char *(*)()) F669_7893;
	R6961[46] = (char *(*)()) F670_7893;
	R6961[47] = (char *(*)()) F667_7893;
	R6961[48] = (char *(*)()) F663_7893;
	R6961[49] = (char *(*)()) F659_7893;
	R6961[50] = (char *(*)()) F660_7893;
	R6961[51] = (char *(*)()) F661_7893;
	R6961[52] = (char *(*)()) F662_7893;
	R6961[53] = (char *(*)()) F663_7893;
	R6961[54] = (char *(*)()) F664_7893;
	R6961[55] = (char *(*)()) F665_7893;
	R6961[56] = (char *(*)()) F666_7893;
	R6961[57] = (char *(*)()) F667_7893;
	R6961[58] = (char *(*)()) F668_7893;
	R6961[59] = (char *(*)()) F669_7893;
	R6961[60] = (char *(*)()) F670_7893;
	R6961[61] = (char *(*)()) F659_7893;
	R6961[62] = (char *(*)()) F660_7893;
	R6961[63] = (char *(*)()) F661_7893;
	R6961[64] = (char *(*)()) F662_7893;
	R6961[65] = (char *(*)()) F663_7893;
	R6961[66] = (char *(*)()) F664_7893;
	R6961[67] = (char *(*)()) F665_7893;
	R6961[68] = (char *(*)()) F666_7893;
	R6961[69] = (char *(*)()) F667_7893;
	R6961[70] = (char *(*)()) F668_7893;
	R6961[71] = (char *(*)()) F669_7893;
	R6961[72] = (char *(*)()) F670_7893;
}

char *(*R6962[73])();
void R6962_init () {
	R6962[0] = (char *(*)()) F636_7866;
	R6962[1] = (char *(*)()) F637_7866;
	R6962[2] = (char *(*)()) F638_7866;
	R6962[3] = (char *(*)()) F639_7866;
	R6962[4] = (char *(*)()) F640_7866;
	R6962[5] = (char *(*)()) F641_7866;
	R6962[6] = (char *(*)()) F642_7866;
	R6962[7] = (char *(*)()) F643_7866;
	R6962[8] = (char *(*)()) F644_7866;
	R6962[9] = (char *(*)()) F645_7866;
	R6962[10] = (char *(*)()) F646_7866;
	R6962[11] = (char *(*)()) F647_7866;
	R6962[12] = (char *(*)()) F648_7871;
	R6962[13] = (char *(*)()) F649_7871;
	R6962[14] = (char *(*)()) F650_7878;
	R6962[15] = (char *(*)()) F651_7878;
	R6962[16] = (char *(*)()) F652_7878;
	R6962[17] = (char *(*)()) F653_7878;
	R6962[18] = (char *(*)()) F654_7878;
	R6962[19] = (char *(*)()) F655_7878;
	R6962[20] = (char *(*)()) F656_7878;
	R6962[21] = (char *(*)()) F657_7878;
	R6962[22] = (char *(*)()) F658_7878;
	R6962[35] = (char *(*)()) F671_7903;
	R6962[36] = (char *(*)()) F672_7903;
	R6962[37] = (char *(*)()) F673_7903;
	R6962[38] = (char *(*)()) F674_7903;
	R6962[39] = (char *(*)()) F675_7903;
	R6962[40] = (char *(*)()) F676_7903;
	R6962[41] = (char *(*)()) F677_7903;
	R6962[42] = (char *(*)()) F678_7903;
	R6962[43] = (char *(*)()) F679_7903;
	R6962[44] = (char *(*)()) F680_7903;
	R6962[45] = (char *(*)()) F681_7903;
	R6962[46] = (char *(*)()) F682_7903;
	R6962[47] = (char *(*)()) F683_7909;
	R6962[48] = (char *(*)()) F684_7915;
	R6962[49] = (char *(*)()) F685_7921;
	R6962[50] = (char *(*)()) F686_7921;
	R6962[51] = (char *(*)()) F687_7921;
	R6962[52] = (char *(*)()) F688_7921;
	R6962[53] = (char *(*)()) F689_7921;
	R6962[54] = (char *(*)()) F690_7921;
	R6962[55] = (char *(*)()) F691_7921;
	R6962[56] = (char *(*)()) F692_7921;
	R6962[57] = (char *(*)()) F693_7921;
	R6962[58] = (char *(*)()) F694_7921;
	R6962[59] = (char *(*)()) F695_7921;
	R6962[60] = (char *(*)()) F696_7921;
	R6962[61] = (char *(*)()) F659_7895;
	R6962[62] = (char *(*)()) F660_7895;
	R6962[63] = (char *(*)()) F661_7895;
	R6962[64] = (char *(*)()) F662_7895;
	R6962[65] = (char *(*)()) F663_7895;
	R6962[66] = (char *(*)()) F664_7895;
	R6962[67] = (char *(*)()) F665_7895;
	R6962[68] = (char *(*)()) F666_7895;
	R6962[69] = (char *(*)()) F667_7895;
	R6962[70] = (char *(*)()) F668_7895;
	R6962[71] = (char *(*)()) F669_7895;
	R6962[72] = (char *(*)()) F670_7895;
}

char *(*R6964[23])();
void R6964_init () {
	R6964[0] = (char *(*)()) F636_7845;
	R6964[1] = (char *(*)()) F637_7845;
	R6964[2] = (char *(*)()) F638_7845;
	R6964[3] = (char *(*)()) F639_7845;
	R6964[4] = (char *(*)()) F640_7845;
	R6964[5] = (char *(*)()) F641_7845;
	R6964[6] = (char *(*)()) F642_7845;
	R6964[7] = (char *(*)()) F643_7845;
	R6964[8] = (char *(*)()) F644_7845;
	R6964[9] = (char *(*)()) F645_7845;
	R6964[10] = (char *(*)()) F646_7845;
	R6964[11] = (char *(*)()) F647_7845;
	R6964[12] = (char *(*)()) F636_7845;
	R6964[13] = (char *(*)()) F638_7845;
	R6964[14] = (char *(*)()) F636_7845;
	R6964[15] = (char *(*)()) F637_7845;
	R6964[16] = (char *(*)()) F636_7845;
	R6964[17] = (char *(*)()) F642_7845;
	R6964[18] = (char *(*)()) F636_7845;
	{long i; for (i = 19; i < 21; i++) R6964[i] = (char *(*)()) F638_7845;}
	R6964[21] = (char *(*)()) F641_7845;
	R6964[22] = (char *(*)()) F645_7845;
}

char *(*R6977[38])();
void R6977_init () {
	R6977[0] = (char *(*)()) F671_7904;
	R6977[1] = (char *(*)()) F672_7904;
	R6977[2] = (char *(*)()) F673_7904;
	R6977[3] = (char *(*)()) F674_7904;
	R6977[4] = (char *(*)()) F675_7904;
	R6977[5] = (char *(*)()) F676_7904;
	R6977[6] = (char *(*)()) F677_7904;
	R6977[7] = (char *(*)()) F678_7904;
	R6977[8] = (char *(*)()) F679_7904;
	R6977[9] = (char *(*)()) F680_7904;
	R6977[10] = (char *(*)()) F681_7904;
	R6977[11] = (char *(*)()) F682_7904;
	R6977[12] = (char *(*)()) F683_7910;
	R6977[13] = (char *(*)()) F684_7916;
	R6977[14] = (char *(*)()) F685_7922;
	R6977[15] = (char *(*)()) F686_7922;
	R6977[16] = (char *(*)()) F687_7922;
	R6977[17] = (char *(*)()) F688_7922;
	R6977[18] = (char *(*)()) F689_7922;
	R6977[19] = (char *(*)()) F690_7922;
	R6977[20] = (char *(*)()) F691_7922;
	R6977[21] = (char *(*)()) F692_7922;
	R6977[22] = (char *(*)()) F693_7922;
	R6977[23] = (char *(*)()) F694_7922;
	R6977[24] = (char *(*)()) F695_7922;
	R6977[25] = (char *(*)()) F696_7922;
	R6977[26] = (char *(*)()) F697_7926;
	R6977[27] = (char *(*)()) F698_7926;
	R6977[28] = (char *(*)()) F699_7926;
	R6977[29] = (char *(*)()) F700_7926;
	R6977[30] = (char *(*)()) F701_7926;
	R6977[31] = (char *(*)()) F702_7926;
	R6977[32] = (char *(*)()) F703_7926;
	R6977[33] = (char *(*)()) F704_7926;
	R6977[34] = (char *(*)()) F705_7926;
	R6977[35] = (char *(*)()) F706_7926;
	R6977[36] = (char *(*)()) F707_7926;
	R6977[37] = (char *(*)()) F708_7926;
}

char *(*R6979[12])();
void R6979_init () {
	R6979[0] = (char *(*)()) F671_7899;
	R6979[1] = (char *(*)()) F672_7899;
	R6979[2] = (char *(*)()) F673_7899;
	R6979[3] = (char *(*)()) F674_7899;
	R6979[4] = (char *(*)()) F675_7899;
	R6979[5] = (char *(*)()) F676_7899;
	R6979[6] = (char *(*)()) F677_7899;
	R6979[7] = (char *(*)()) F678_7899;
	R6979[8] = (char *(*)()) F679_7899;
	R6979[9] = (char *(*)()) F680_7899;
	R6979[10] = (char *(*)()) F681_7899;
	R6979[11] = (char *(*)()) F682_7899;
}

char *(*R6987[12])();
void R6987_init () {
	R6987[0] = (char *(*)()) F685_7917;
	R6987[1] = (char *(*)()) F686_7917;
	R6987[2] = (char *(*)()) F687_7917;
	R6987[3] = (char *(*)()) F688_7917;
	R6987[4] = (char *(*)()) F689_7917;
	R6987[5] = (char *(*)()) F690_7917;
	R6987[6] = (char *(*)()) F691_7917;
	R6987[7] = (char *(*)()) F692_7917;
	R6987[8] = (char *(*)()) F693_7917;
	R6987[9] = (char *(*)()) F694_7917;
	R6987[10] = (char *(*)()) F695_7917;
	R6987[11] = (char *(*)()) F696_7917;
}

char *(*R6990[12])();
void R6990_init () {
	R6990[0] = (char *(*)()) F697_7923;
	R6990[1] = (char *(*)()) F698_7923;
	R6990[2] = (char *(*)()) F699_7923;
	R6990[3] = (char *(*)()) F700_7923;
	R6990[4] = (char *(*)()) F701_7923;
	R6990[5] = (char *(*)()) F702_7923;
	R6990[6] = (char *(*)()) F703_7923;
	R6990[7] = (char *(*)()) F704_7923;
	R6990[8] = (char *(*)()) F705_7923;
	R6990[9] = (char *(*)()) F706_7923;
	R6990[10] = (char *(*)()) F707_7923;
	R6990[11] = (char *(*)()) F708_7923;
}

char *(*R7020[5])();
void R7020_init () {
	R7020[0] = (char *(*)()) F1191_10787;
	R7020[4] = (char *(*)()) F1195_11053;
}

char *(*R7021[5])();
void R7021_init () {
	R7021[0] = (char *(*)()) F1191_10790;
	R7021[4] = (char *(*)()) F1195_11057;
}

char *(*R7024[5])();
void R7024_init () {
	R7024[0] = (char *(*)()) F1191_10789;
	R7024[4] = (char *(*)()) F1195_11054;
}

char *(*R7029[5])();
void R7029_init () {
	R7029[0] = (char *(*)()) F1191_10792;
	R7029[4] = (char *(*)()) F1195_11059;
}

char *(*R7030[5])();
void R7030_init () {
	R7030[0] = (char *(*)()) F1191_10795;
	R7030[4] = (char *(*)()) F1195_11061;
}

char *(*R7031[5])();
void R7031_init () {
	R7031[0] = (char *(*)()) F1191_10796;
	R7031[4] = (char *(*)()) F1195_11062;
}

char *(*R7033[585])();
void R7033_init () {
	R7033[0] = (char *(*)()) F868_8103_7033_2;
	R7033[1] = (char *(*)()) F869_8122_7033_2;
	{long i; for (i = 69; i < 71; i++) R7033[i] = (char *(*)()) F742_7988_7033_2;}
	R7033[121] = (char *(*)()) F989_8737;
	R7033[122] = (char *(*)()) F990_8737_7033_2;
	R7033[123] = (char *(*)()) F991_8737_7033_2;
	R7033[124] = (char *(*)()) F992_8737_7033_2;
	R7033[125] = (char *(*)()) F993_8737_7033_2;
	R7033[126] = (char *(*)()) F994_8737_7033_2;
	R7033[127] = (char *(*)()) F995_8737_7033_2;
	R7033[128] = (char *(*)()) F996_8737_7033_2;
	R7033[129] = (char *(*)()) F997_8737_7033_2;
	R7033[130] = (char *(*)()) F998_8737_7033_2;
	R7033[131] = (char *(*)()) F999_8737_7033_2;
	R7033[132] = (char *(*)()) F1000_8737_7033_2;
	R7033[186] = (char *(*)()) F1006_8790;
	R7033[187] = (char *(*)()) F1009_8790_7033_2;
	R7033[188] = (char *(*)()) F1006_8790;
	R7033[189] = (char *(*)()) F1009_8790_7033_2;
	R7033[190] = (char *(*)()) F1006_8790;
	R7033[191] = (char *(*)()) F1059_8920;
	R7033[192] = (char *(*)()) F1060_8920_7033_2;
	R7033[193] = (char *(*)()) F1061_8920_7033_2;
	R7033[194] = (char *(*)()) F1062_8920_7033_2;
	R7033[195] = (char *(*)()) F1063_8920_7033_2;
	R7033[196] = (char *(*)()) F1064_8920_7033_2;
	R7033[197] = (char *(*)()) F1065_8920_7033_2;
	R7033[198] = (char *(*)()) F1066_8920_7033_2;
	R7033[199] = (char *(*)()) F1067_8920_7033_2;
	R7033[200] = (char *(*)()) F1068_8920_7033_2;
	R7033[201] = (char *(*)()) F1069_8920_7033_2;
	R7033[202] = (char *(*)()) F1070_8920_7033_2;
	{long i; for (i = 203; i < 206; i++) R7033[i] = (char *(*)()) F1059_8920;}
	R7033[206] = (char *(*)()) F1062_8920_7033_2;
	R7033[207] = (char *(*)()) F1059_8920;
	R7033[305] = (char *(*)()) F1171_10171_7033_2;
	{long i; for (i = 308; i < 310; i++) R7033[i] = (char *(*)()) F1174_10339_7033_2;}
	R7033[487] = (char *(*)()) F742_7988_7033_2;
	R7033[584] = (char *(*)()) F1452_15300_7033_2;
}
static EIF_BOOLEAN F868_8103_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F868_8103(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F869_8122_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F869_8122(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F742_7988_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F742_7988(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F990_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F990_8737(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F991_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F991_8737(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F992_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F992_8737(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F993_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F993_8737(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F994_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F994_8737(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F995_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F995_8737(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F996_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F996_8737(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F997_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F997_8737(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F998_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F998_8737(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F999_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F999_8737(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1000_8737_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1000_8737(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1009_8790_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1009_8790(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1060_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1060_8920(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F1061_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1061_8920(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1062_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1062_8920(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1063_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1063_8920(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1064_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1064_8920(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F1065_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1065_8920(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1066_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1066_8920(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1067_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1067_8920(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1068_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1068_8920(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1069_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1069_8920(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1070_8920_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1070_8920(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1171_10171_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1171_10171(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1174_10339_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1174_10339(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1452_15300_7033_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1452_15300(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7034[585])();
void R7034_init () {
	{long i; for (i = 0; i < 2; i++) R7034[i] = (char *(*)()) F865_8074;}
	R7034[41] = (char *(*)()) F909_8156;
	{long i; for (i = 69; i < 71; i++) R7034[i] = (char *(*)()) F874_8129;}
	R7034[93] = (char *(*)()) F870_8129;
	R7034[94] = (char *(*)()) F871_8129;
	R7034[95] = (char *(*)()) F870_8129;
	R7034[96] = (char *(*)()) F876_8129;
	R7034[97] = (char *(*)()) F870_8129;
	{long i; for (i = 98; i < 100; i++) R7034[i] = (char *(*)()) F872_8129;}
	R7034[100] = (char *(*)()) F875_8129;
	R7034[101] = (char *(*)()) F879_8129;
	{long i; for (i = 102; i < 104; i++) R7034[i] = (char *(*)()) F870_8129;}
	R7034[104] = (char *(*)()) F876_8129;
	R7034[105] = (char *(*)()) F875_8129;
	R7034[106] = (char *(*)()) F872_8129;
	R7034[107] = (char *(*)()) F879_8129;
	R7034[120] = (char *(*)()) F872_8129;
	R7034[121] = (char *(*)()) F870_8129;
	R7034[122] = (char *(*)()) F871_8129;
	R7034[123] = (char *(*)()) F873_8129;
	R7034[124] = (char *(*)()) F872_8129;
	R7034[125] = (char *(*)()) F874_8129;
	R7034[126] = (char *(*)()) F875_8129;
	R7034[127] = (char *(*)()) F876_8129;
	R7034[128] = (char *(*)()) F877_8129;
	R7034[129] = (char *(*)()) F878_8129;
	R7034[130] = (char *(*)()) F879_8129;
	R7034[131] = (char *(*)()) F880_8129;
	R7034[132] = (char *(*)()) F881_8129;
	R7034[186] = (char *(*)()) F870_8129;
	R7034[187] = (char *(*)()) F872_8129;
	R7034[188] = (char *(*)()) F870_8129;
	R7034[189] = (char *(*)()) F872_8129;
	{long i; for (i = 190; i < 192; i++) R7034[i] = (char *(*)()) F870_8129;}
	R7034[192] = (char *(*)()) F871_8129;
	R7034[193] = (char *(*)()) F873_8129;
	R7034[194] = (char *(*)()) F872_8129;
	R7034[195] = (char *(*)()) F874_8129;
	R7034[196] = (char *(*)()) F875_8129;
	R7034[197] = (char *(*)()) F876_8129;
	R7034[198] = (char *(*)()) F877_8129;
	R7034[199] = (char *(*)()) F878_8129;
	R7034[200] = (char *(*)()) F879_8129;
	R7034[201] = (char *(*)()) F880_8129;
	R7034[202] = (char *(*)()) F881_8129;
	{long i; for (i = 203; i < 206; i++) R7034[i] = (char *(*)()) F870_8129;}
	R7034[206] = (char *(*)()) F872_8129;
	R7034[207] = (char *(*)()) F870_8129;
	R7034[305] = (char *(*)()) F878_8129;
	{long i; for (i = 308; i < 310; i++) R7034[i] = (char *(*)()) F874_8129;}
	R7034[487] = (char *(*)()) F1355_12681;
	R7034[584] = (char *(*)()) F874_8129;
}

char *(*R7038[585])();
void R7038_init () {
	{long i; for (i = 0; i < 2; i++) R7038[i] = (char *(*)()) F716_7977;}
	R7038[41] = (char *(*)()) F714_7977;
	{long i; for (i = 69; i < 71; i++) R7038[i] = (char *(*)()) F718_7977;}
	R7038[93] = (char *(*)()) F714_7977;
	R7038[94] = (char *(*)()) F715_7977;
	R7038[95] = (char *(*)()) F714_7977;
	R7038[96] = (char *(*)()) F720_7977;
	R7038[97] = (char *(*)()) F714_7977;
	{long i; for (i = 98; i < 100; i++) R7038[i] = (char *(*)()) F716_7977;}
	R7038[100] = (char *(*)()) F719_7977;
	R7038[101] = (char *(*)()) F723_7977;
	{long i; for (i = 102; i < 104; i++) R7038[i] = (char *(*)()) F714_7977;}
	R7038[104] = (char *(*)()) F720_7977;
	R7038[105] = (char *(*)()) F719_7977;
	R7038[106] = (char *(*)()) F716_7977;
	R7038[107] = (char *(*)()) F723_7977;
	R7038[120] = (char *(*)()) F716_7977;
	R7038[121] = (char *(*)()) F714_7977;
	R7038[122] = (char *(*)()) F715_7977;
	R7038[123] = (char *(*)()) F717_7977;
	R7038[124] = (char *(*)()) F716_7977;
	R7038[125] = (char *(*)()) F718_7977;
	R7038[126] = (char *(*)()) F719_7977;
	R7038[127] = (char *(*)()) F720_7977;
	R7038[128] = (char *(*)()) F721_7977;
	R7038[129] = (char *(*)()) F722_7977;
	R7038[130] = (char *(*)()) F723_7977;
	R7038[131] = (char *(*)()) F724_7977;
	R7038[132] = (char *(*)()) F725_7977;
	R7038[186] = (char *(*)()) F714_7977;
	R7038[187] = (char *(*)()) F716_7977;
	R7038[188] = (char *(*)()) F714_7977;
	R7038[189] = (char *(*)()) F716_7977;
	{long i; for (i = 190; i < 192; i++) R7038[i] = (char *(*)()) F714_7977;}
	R7038[192] = (char *(*)()) F715_7977;
	R7038[193] = (char *(*)()) F717_7977;
	R7038[194] = (char *(*)()) F716_7977;
	R7038[195] = (char *(*)()) F718_7977;
	R7038[196] = (char *(*)()) F719_7977;
	R7038[197] = (char *(*)()) F720_7977;
	R7038[198] = (char *(*)()) F721_7977;
	R7038[199] = (char *(*)()) F722_7977;
	R7038[200] = (char *(*)()) F723_7977;
	R7038[201] = (char *(*)()) F724_7977;
	R7038[202] = (char *(*)()) F725_7977;
	{long i; for (i = 203; i < 206; i++) R7038[i] = (char *(*)()) F714_7977;}
	R7038[206] = (char *(*)()) F716_7977;
	R7038[207] = (char *(*)()) F714_7977;
	R7038[305] = (char *(*)()) F722_7977;
	{long i; for (i = 308; i < 310; i++) R7038[i] = (char *(*)()) F718_7977;}
	R7038[487] = (char *(*)()) F718_7977;
	R7038[584] = (char *(*)()) F718_7977;
}

char *(*R7040[585])();
void R7040_init () {
	{long i; for (i = 0; i < 2; i++) R7040[i] = (char *(*)()) F867_8089;}
	R7040[41] = (char *(*)()) F909_8170;
	{long i; for (i = 69; i < 71; i++) R7040[i] = (char *(*)()) F742_8003;}
	R7040[93] = (char *(*)()) F961_8614;
	R7040[94] = (char *(*)()) F962_8614;
	R7040[95] = (char *(*)()) F963_8614;
	R7040[96] = (char *(*)()) F964_8614;
	R7040[97] = (char *(*)()) F965_8614;
	R7040[98] = (char *(*)()) F966_8614;
	R7040[99] = (char *(*)()) F967_8614;
	R7040[100] = (char *(*)()) F968_8614;
	R7040[101] = (char *(*)()) F969_8614;
	{long i; for (i = 102; i < 104; i++) R7040[i] = (char *(*)()) F961_8614;}
	R7040[104] = (char *(*)()) F964_8614;
	R7040[105] = (char *(*)()) F968_8614;
	R7040[106] = (char *(*)()) F966_8614;
	R7040[107] = (char *(*)()) F969_8614;
	R7040[120] = (char *(*)()) F988_8716;
	R7040[121] = (char *(*)()) F989_8781;
	R7040[122] = (char *(*)()) F990_8781;
	R7040[123] = (char *(*)()) F991_8781;
	R7040[124] = (char *(*)()) F992_8781;
	R7040[125] = (char *(*)()) F993_8781;
	R7040[126] = (char *(*)()) F994_8781;
	R7040[127] = (char *(*)()) F995_8781;
	R7040[128] = (char *(*)()) F996_8781;
	R7040[129] = (char *(*)()) F997_8781;
	R7040[130] = (char *(*)()) F998_8781;
	R7040[131] = (char *(*)()) F999_8781;
	R7040[132] = (char *(*)()) F1000_8781;
	R7040[186] = (char *(*)()) F738_8003;
	R7040[187] = (char *(*)()) F740_8003;
	R7040[188] = (char *(*)()) F1056_8890;
	R7040[189] = (char *(*)()) F1057_8890;
	{long i; for (i = 190; i < 192; i++) R7040[i] = (char *(*)()) F738_8003;}
	R7040[192] = (char *(*)()) F739_8003;
	R7040[193] = (char *(*)()) F741_8003;
	R7040[194] = (char *(*)()) F740_8003;
	R7040[195] = (char *(*)()) F742_8003;
	R7040[196] = (char *(*)()) F743_8003;
	R7040[197] = (char *(*)()) F744_8003;
	R7040[198] = (char *(*)()) F745_8003;
	R7040[199] = (char *(*)()) F746_8003;
	R7040[200] = (char *(*)()) F747_8003;
	R7040[201] = (char *(*)()) F748_8003;
	R7040[202] = (char *(*)()) F749_8003;
	{long i; for (i = 203; i < 205; i++) R7040[i] = (char *(*)()) F738_8003;}
	R7040[205] = (char *(*)()) F1073_8991;
	R7040[206] = (char *(*)()) F1074_8991;
	R7040[207] = (char *(*)()) F738_8003;
	R7040[305] = (char *(*)()) F1173_10295;
	{long i; for (i = 308; i < 310; i++) R7040[i] = (char *(*)()) F1176_10460;}
	R7040[487] = (char *(*)()) F742_8003;
	R7040[584] = (char *(*)()) F1176_10460;
}

char *(*R7041[585])();
void R7041_init () {
	{long i; for (i = 0; i < 2; i++) R7041[i] = (char *(*)()) F716_7980;}
	R7041[41] = (char *(*)()) F714_7980;
	{long i; for (i = 69; i < 71; i++) R7041[i] = (char *(*)()) F718_7980;}
	R7041[93] = (char *(*)()) F714_7980;
	R7041[94] = (char *(*)()) F715_7980;
	R7041[95] = (char *(*)()) F714_7980;
	R7041[96] = (char *(*)()) F720_7980;
	R7041[97] = (char *(*)()) F714_7980;
	{long i; for (i = 98; i < 100; i++) R7041[i] = (char *(*)()) F716_7980;}
	R7041[100] = (char *(*)()) F719_7980;
	R7041[101] = (char *(*)()) F723_7980;
	{long i; for (i = 102; i < 104; i++) R7041[i] = (char *(*)()) F714_7980;}
	R7041[104] = (char *(*)()) F720_7980;
	R7041[105] = (char *(*)()) F719_7980;
	R7041[106] = (char *(*)()) F716_7980;
	R7041[107] = (char *(*)()) F723_7980;
	R7041[120] = (char *(*)()) F716_7980;
	R7041[121] = (char *(*)()) F714_7980;
	R7041[122] = (char *(*)()) F715_7980;
	R7041[123] = (char *(*)()) F717_7980;
	R7041[124] = (char *(*)()) F716_7980;
	R7041[125] = (char *(*)()) F718_7980;
	R7041[126] = (char *(*)()) F719_7980;
	R7041[127] = (char *(*)()) F720_7980;
	R7041[128] = (char *(*)()) F721_7980;
	R7041[129] = (char *(*)()) F722_7980;
	R7041[130] = (char *(*)()) F723_7980;
	R7041[131] = (char *(*)()) F724_7980;
	R7041[132] = (char *(*)()) F725_7980;
	R7041[186] = (char *(*)()) F714_7980;
	R7041[187] = (char *(*)()) F716_7980;
	R7041[188] = (char *(*)()) F714_7980;
	R7041[189] = (char *(*)()) F716_7980;
	{long i; for (i = 190; i < 192; i++) R7041[i] = (char *(*)()) F714_7980;}
	R7041[192] = (char *(*)()) F715_7980;
	R7041[193] = (char *(*)()) F717_7980;
	R7041[194] = (char *(*)()) F716_7980;
	R7041[195] = (char *(*)()) F718_7980;
	R7041[196] = (char *(*)()) F719_7980;
	R7041[197] = (char *(*)()) F720_7980;
	R7041[198] = (char *(*)()) F721_7980;
	R7041[199] = (char *(*)()) F722_7980;
	R7041[200] = (char *(*)()) F723_7980;
	R7041[201] = (char *(*)()) F724_7980;
	R7041[202] = (char *(*)()) F725_7980;
	{long i; for (i = 203; i < 206; i++) R7041[i] = (char *(*)()) F714_7980;}
	R7041[206] = (char *(*)()) F716_7980;
	R7041[207] = (char *(*)()) F714_7980;
	R7041[305] = (char *(*)()) F722_7980;
	{long i; for (i = 308; i < 310; i++) R7041[i] = (char *(*)()) F718_7980;}
	R7041[487] = (char *(*)()) F718_7980;
	R7041[584] = (char *(*)()) F718_7980;
}

char *(*R7042[488])();
void R7042_init () {
	{long i; for (i = 0; i < 2; i++) R7042[i] = (char *(*)()) F867_8078_7042_1;}
	{long i; for (i = 69; i < 71; i++) R7042[i] = (char *(*)()) F936_8204_7042_1;}
	R7042[186] = (char *(*)()) F1054_8840;
	R7042[187] = (char *(*)()) F1055_8840_7042_1;
	R7042[188] = (char *(*)()) F1054_8840;
	R7042[189] = (char *(*)()) F1055_8840_7042_1;
	R7042[190] = (char *(*)()) F1054_8840;
	R7042[191] = (char *(*)()) F1059_8913;
	R7042[192] = (char *(*)()) F1060_8913_7042_1;
	R7042[193] = (char *(*)()) F1061_8913_7042_1;
	R7042[194] = (char *(*)()) F1062_8913_7042_1;
	R7042[195] = (char *(*)()) F1063_8913_7042_1;
	R7042[196] = (char *(*)()) F1064_8913_7042_1;
	R7042[197] = (char *(*)()) F1065_8913_7042_1;
	R7042[198] = (char *(*)()) F1066_8913_7042_1;
	R7042[199] = (char *(*)()) F1067_8913_7042_1;
	R7042[200] = (char *(*)()) F1068_8913_7042_1;
	R7042[201] = (char *(*)()) F1069_8913_7042_1;
	R7042[202] = (char *(*)()) F1070_8913_7042_1;
	{long i; for (i = 203; i < 206; i++) R7042[i] = (char *(*)()) F1059_8913;}
	R7042[206] = (char *(*)()) F1062_8913_7042_1;
	R7042[207] = (char *(*)()) F1059_8913;
	R7042[487] = (char *(*)()) F936_8204_7042_1;
}
static EIF_REFERENCE F867_8078_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F867_8078(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F936_8204_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F936_8204(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1055_8840_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1055_8840(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8913_7042_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R7043[488])();
void R7043_init () {
	{long i; for (i = 0; i < 2; i++) R7043[i] = (char *(*)()) F740_7996;}
	{long i; for (i = 69; i < 71; i++) R7043[i] = (char *(*)()) F936_8225;}
	R7043[186] = (char *(*)()) F1054_8851;
	R7043[187] = (char *(*)()) F1055_8851;
	R7043[188] = (char *(*)()) F1054_8851;
	R7043[189] = (char *(*)()) F1055_8851;
	R7043[190] = (char *(*)()) F1054_8851;
	R7043[191] = (char *(*)()) F1006_8803;
	R7043[192] = (char *(*)()) F1007_8803;
	R7043[193] = (char *(*)()) F1008_8803;
	R7043[194] = (char *(*)()) F1009_8803;
	R7043[195] = (char *(*)()) F1010_8803;
	R7043[196] = (char *(*)()) F1011_8803;
	R7043[197] = (char *(*)()) F1012_8803;
	R7043[198] = (char *(*)()) F1013_8803;
	R7043[199] = (char *(*)()) F1014_8803;
	R7043[200] = (char *(*)()) F1015_8803;
	R7043[201] = (char *(*)()) F1016_8803;
	R7043[202] = (char *(*)()) F1017_8803;
	{long i; for (i = 203; i < 206; i++) R7043[i] = (char *(*)()) F1006_8803;}
	R7043[206] = (char *(*)()) F1009_8803;
	R7043[207] = (char *(*)()) F1006_8803;
	R7043[487] = (char *(*)()) F936_8225;
}


#ifdef __cplusplus
}
#endif
