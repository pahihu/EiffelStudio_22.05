#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O6222[836];
void O6222_init () {
	O6222[0] = + _CHROFF_1_0_;
	O6222[1] = + _CHROFF_2_0_;
	O6222[2] = + _CHROFF_6_0_;
	O6222[3] = + _CHROFF_7_0_;
	O6222[4] = + _CHROFF_6_0_;
	{long i; for (i = 5; i < 8; i++) O6222[i] = + _CHROFF_7_0_;}
	O6222[373] = + _CHROFF_3_0_;
	O6222[374] = + _CHROFF_5_0_;
	O6222[375] = + _CHROFF_4_0_;
	O6222[792] = + _CHROFF_5_0_;
	{long i; for (i = 827; i < 830; i++) O6222[i] = + _CHROFF_5_0_;}
	O6222[831] = + _CHROFF_7_1_;
	{long i; for (i = 832; i < 836; i++) O6222[i] = + _CHROFF_6_1_;}
}

long O6224[836];
void O6224_init () {
	O6224[0] = + _LNGOFF_1_3_2_1_;
	O6224[1] = + _LNGOFF_2_7_2_3_;
	O6224[2] = + _LNGOFF_6_8_2_1_;
	O6224[3] = + _LNGOFF_7_8_2_1_;
	O6224[4] = + _LNGOFF_6_12_2_1_;
	{long i; for (i = 5; i < 8; i++) O6224[i] = + _LNGOFF_7_12_2_1_;}
	O6224[373] = + _LNGOFF_3_6_2_1_;
	O6224[374] = + _LNGOFF_5_7_2_1_;
	O6224[375] = + _LNGOFF_4_6_2_1_;
	O6224[792] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 827; i < 830; i++) O6224[i] = + _LNGOFF_5_6_2_1_;}
	O6224[831] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 832; i < 836; i++) O6224[i] = + _LNGOFF_6_7_2_1_;}
}

long O6233[836];
void O6233_init () {
	O6233[0] = + _CHROFF_1_1_;
	O6233[1] = + _CHROFF_2_5_;
	O6233[2] = + _CHROFF_6_6_;
	O6233[3] = + _CHROFF_7_6_;
	O6233[4] = + _CHROFF_6_10_;
	{long i; for (i = 5; i < 8; i++) O6233[i] = + _CHROFF_7_10_;}
	O6233[373] = + _CHROFF_3_4_;
	O6233[374] = + _CHROFF_5_5_;
	O6233[375] = + _CHROFF_4_4_;
	O6233[792] = + _CHROFF_5_5_;
	{long i; for (i = 827; i < 830; i++) O6233[i] = + _CHROFF_5_4_;}
	O6233[831] = + _CHROFF_7_6_;
	{long i; for (i = 832; i < 836; i++) O6233[i] = + _CHROFF_6_5_;}
}

long O6234[836];
void O6234_init () {
	O6234[0] = + _R32OFF_1_3_2_3_0_;
	O6234[1] = + _R32OFF_2_7_2_5_0_;
	O6234[2] = + _R32OFF_6_8_2_6_0_;
	O6234[3] = + _R32OFF_7_8_2_6_0_;
	O6234[4] = + _R32OFF_6_12_2_11_0_;
	O6234[5] = + _R32OFF_7_12_2_13_0_;
	{long i; for (i = 6; i < 8; i++) O6234[i] = + _R32OFF_7_12_2_14_0_;}
	O6234[373] = + _R32OFF_3_6_2_4_0_;
	O6234[374] = + _R32OFF_5_7_2_4_0_;
	O6234[375] = + _R32OFF_4_6_2_4_0_;
	O6234[792] = + _R32OFF_5_7_2_4_0_;
	{long i; for (i = 827; i < 830; i++) O6234[i] = + _R32OFF_5_6_2_4_0_;}
	O6234[831] = + _R32OFF_7_8_2_4_0_;
	{long i; for (i = 832; i < 836; i++) O6234[i] = + _R32OFF_6_7_2_4_0_;}
}

long O6236[836];
void O6236_init () {
	O6236[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O6236[1] = + _R64OFF_2_7_2_5_1_0_2_0_;
	O6236[2] = + _R64OFF_6_8_2_6_1_0_2_0_;
	O6236[3] = + _R64OFF_7_8_2_6_1_0_2_0_;
	O6236[4] = + _R64OFF_6_12_2_11_1_0_3_0_;
	O6236[5] = + _R64OFF_7_12_2_13_1_0_3_0_;
	{long i; for (i = 6; i < 8; i++) O6236[i] = + _R64OFF_7_12_2_14_1_0_3_0_;}
	O6236[373] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O6236[374] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O6236[375] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O6236[792] = + _R64OFF_5_7_2_4_1_1_2_0_;
	{long i; for (i = 827; i < 830; i++) O6236[i] = + _R64OFF_5_6_2_4_1_1_2_0_;}
	O6236[831] = + _R64OFF_7_8_2_4_1_1_2_0_;
	{long i; for (i = 832; i < 836; i++) O6236[i] = + _R64OFF_6_7_2_4_1_1_2_0_;}
}

long O6238[836];
void O6238_init () {
	O6238[0] = + _LNGOFF_1_3_2_2_;
	O6238[1] = + _LNGOFF_2_7_2_4_;
	O6238[2] = + _LNGOFF_6_8_2_2_;
	O6238[3] = + _LNGOFF_7_8_2_2_;
	O6238[4] = + _LNGOFF_6_12_2_2_;
	{long i; for (i = 5; i < 8; i++) O6238[i] = + _LNGOFF_7_12_2_2_;}
	O6238[373] = + _LNGOFF_3_6_2_2_;
	O6238[374] = + _LNGOFF_5_7_2_2_;
	O6238[375] = + _LNGOFF_4_6_2_2_;
	O6238[792] = + _LNGOFF_5_7_2_2_;
	{long i; for (i = 827; i < 830; i++) O6238[i] = + _LNGOFF_5_6_2_2_;}
	O6238[831] = + _LNGOFF_7_8_2_2_;
	{long i; for (i = 832; i < 836; i++) O6238[i] = + _LNGOFF_6_7_2_2_;}
}

static EIF_TYPE_INDEX Y6336_pgtype0[] = {0xFF02,109,0xFFFF};
static EIF_TYPE_INDEX Y6336_pgtype1[] = {0xFF02,109,0xFFFF};
static EIF_TYPE_INDEX Y6336_pgtype2[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6336_pgtype3[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6336_pgtype4[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6336_pgtype5[] = {0xFF02,318,0xFFFF};
EIF_TYPE_INDEX *Y6336_gen_type [6];
EIF_TYPE_INDEX Y6336 [6];
void Y6336_init (void)
{
	egc_routines_types [6336] = Y6336;
	egc_routines_gen_types [6336] = Y6336_gen_type;
	egc_routines_offset [6336] = 564;
	Y6336_gen_type [0] = Y6336_pgtype0;
	Y6336_gen_type [1] = Y6336_pgtype1;
	Y6336_gen_type [2] = Y6336_pgtype2;
	Y6336_gen_type [3] = Y6336_pgtype3;
	Y6336_gen_type [4] = Y6336_pgtype4;
	Y6336_gen_type [5] = Y6336_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y6336[i] = 109;};
	{long i; for (i = 2; i < 6; i++) Y6336[i] = 318;};
}

static EIF_TYPE_INDEX Y6337_pgtype0[] = {0xFF02,109,0xFFFF};
static EIF_TYPE_INDEX Y6337_pgtype1[] = {0xFF02,109,0xFFFF};
static EIF_TYPE_INDEX Y6337_pgtype2[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6337_pgtype3[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6337_pgtype4[] = {0xFF02,318,0xFFFF};
static EIF_TYPE_INDEX Y6337_pgtype5[] = {0xFF02,318,0xFFFF};
EIF_TYPE_INDEX *Y6337_gen_type [6];
EIF_TYPE_INDEX Y6337 [6];
void Y6337_init (void)
{
	egc_routines_types [6337] = Y6337;
	egc_routines_gen_types [6337] = Y6337_gen_type;
	egc_routines_offset [6337] = 564;
	Y6337_gen_type [0] = Y6337_pgtype0;
	Y6337_gen_type [1] = Y6337_pgtype1;
	Y6337_gen_type [2] = Y6337_pgtype2;
	Y6337_gen_type [3] = Y6337_pgtype3;
	Y6337_gen_type [4] = Y6337_pgtype4;
	Y6337_gen_type [5] = Y6337_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y6337[i] = 109;};
	{long i; for (i = 2; i < 6; i++) Y6337[i] = 318;};
}

long O6542[8];
void O6542_init () {
	O6542[0] = + _LNGOFF_2_0_0_0_;
	O6542[1] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 2; i < 5; i++) O6542[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6542[i] = + _LNGOFF_3_0_0_0_;}
	O6542[7] = + _LNGOFF_2_0_0_0_;
}

long O6543[8];
void O6543_init () {
	O6543[0] = + _LNGOFF_2_0_0_1_;
	O6543[1] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 2; i < 5; i++) O6543[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6543[i] = + _LNGOFF_3_0_0_1_;}
	O6543[7] = + _LNGOFF_2_0_0_1_;
}

long O6544[8];
void O6544_init () {
	O6544[0] = + _LNGOFF_2_0_0_2_;
	O6544[1] = + _LNGOFF_3_0_0_2_;
	{long i; for (i = 2; i < 5; i++) O6544[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 5; i < 7; i++) O6544[i] = + _LNGOFF_3_0_0_2_;}
	O6544[7] = + _LNGOFF_2_0_0_2_;
}

long O6704[2];
void O6704_init () {
	O6704[0] = + _CHROFF_12_0_;
	O6704[1] = + _CHROFF_18_0_;
}

long O6705[2];
void O6705_init () {
	O6705[0] = + _CHROFF_12_1_;
	O6705[1] = + _CHROFF_18_1_;
}

long O6706[2];
void O6706_init () {
	O6706[0] = + _CHROFF_12_2_;
	O6706[1] = + _CHROFF_18_2_;
}

long O6707[2];
void O6707_init () {
	O6707[0] = + _CHROFF_12_3_;
	O6707[1] = + _CHROFF_18_3_;
}

long O6708[2];
void O6708_init () {
	O6708[0] = + _CHROFF_12_4_;
	O6708[1] = + _CHROFF_18_4_;
}

long O6709[2];
void O6709_init () {
	O6709[0] = + _CHROFF_12_5_;
	O6709[1] = + _CHROFF_18_5_;
}

long O6710[2];
void O6710_init () {
	O6710[0] = + _CHROFF_12_6_;
	O6710[1] = + _CHROFF_18_6_;
}

long O6711[2];
void O6711_init () {
	O6711[0] = + _CHROFF_12_7_;
	O6711[1] = + _CHROFF_18_7_;
}

long O6712[2];
void O6712_init () {
	O6712[0] = + _CHROFF_12_8_;
	O6712[1] = + _CHROFF_18_8_;
}

long O6727[2];
void O6727_init () {
	O6727[0] = + _CHROFF_12_9_;
	O6727[1] = + _CHROFF_18_9_;
}

long O6728[2];
void O6728_init () {
	O6728[0] = + _CHROFF_12_10_;
	O6728[1] = + _CHROFF_18_10_;
}

long O6729[2];
void O6729_init () {
	O6729[0] = + _CHROFF_12_11_;
	O6729[1] = + _CHROFF_18_11_;
}

long O6730[2];
void O6730_init () {
	O6730[0] = + _CHROFF_12_12_;
	O6730[1] = + _CHROFF_18_12_;
}

long O6731[2];
void O6731_init () {
	O6731[0] = + _CHROFF_12_13_;
	O6731[1] = + _CHROFF_18_13_;
}

long O6732[2];
void O6732_init () {
	O6732[0] = + _CHROFF_12_14_;
	O6732[1] = + _CHROFF_18_14_;
}

long O6733[2];
void O6733_init () {
	O6733[0] = + _CHROFF_12_15_;
	O6733[1] = + _CHROFF_18_15_;
}

long O6734[2];
void O6734_init () {
	O6734[0] = + _CHROFF_12_16_;
	O6734[1] = + _CHROFF_18_16_;
}

long O6735[2];
void O6735_init () {
	O6735[0] = + _CHROFF_12_17_;
	O6735[1] = + _CHROFF_18_17_;
}

long O6965[23];
void O6965_init () {
	{long i; for (i = 0; i < 12; i++) O6965[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 14; i++) O6965[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 14; i < 23; i++) O6965[i] = + _LNGOFF_1_1_0_0_;}
}

long O6969[23];
void O6969_init () {
	{long i; for (i = 0; i < 12; i++) O6969[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 14; i++) O6969[i] = + _CHROFF_2_0_;}
	{long i; for (i = 14; i < 23; i++) O6969[i] = + _CHROFF_1_0_;}
}

long O6970[23];
void O6970_init () {
	{long i; for (i = 0; i < 12; i++) O6970[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 14; i++) O6970[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 14; i < 23; i++) O6970[i] = + _LNGOFF_1_1_0_1_;}
}

long O6971[23];
void O6971_init () {
	{long i; for (i = 0; i < 12; i++) O6971[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 14; i++) O6971[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 14; i < 23; i++) O6971[i] = + _LNGOFF_1_1_0_2_;}
}

long O6972[23];
void O6972_init () {
	{long i; for (i = 0; i < 12; i++) O6972[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 14; i++) O6972[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 14; i < 23; i++) O6972[i] = + _LNGOFF_1_1_0_3_;}
}

long O6973[23];
void O6973_init () {
	{long i; for (i = 0; i < 12; i++) O6973[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 14; i++) O6973[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 14; i < 23; i++) O6973[i] = + _LNGOFF_1_1_0_4_;}
}

long O6976[50];
void O6976_init () {
	{long i; for (i = 0; i < 12; i++) O6976[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O6976[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O6976[i] = + _LNGOFF_1_0_0_0_;}
}

long O6978[50];
void O6978_init () {
	{long i; for (i = 0; i < 12; i++) O6978[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O6978[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O6978[i] = + _LNGOFF_1_0_0_1_;}
}

static EIF_TYPE_INDEX Y7017_pgtype0[] = {0xFF01,1058,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7017_pgtype1[] = {0xFF01,1058,0xFF01,1242,0xFFFF};
static EIF_TYPE_INDEX Y7017_pgtype2[] = {0xFF01,1058,0xFF01,1244,0xFFFF};
EIF_TYPE_INDEX *Y7017_gen_type [3];
EIF_TYPE_INDEX Y7017 [3];
void Y7017_init (void)
{
	egc_routines_types [7017] = Y7017;
	egc_routines_gen_types [7017] = Y7017_gen_type;
	egc_routines_offset [7017] = 709;
	Y7017_gen_type [0] = Y7017_pgtype0;
	Y7017_gen_type [1] = Y7017_pgtype1;
	Y7017_gen_type [2] = Y7017_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7017[i] = 1058;};
}

static EIF_TYPE_INDEX Y7022_pgtype0[] = {0xFF01,596,0xFF01,1192,0xFFFF};
static EIF_TYPE_INDEX Y7022_pgtype1[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
static EIF_TYPE_INDEX Y7022_pgtype2[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
EIF_TYPE_INDEX *Y7022_gen_type [483];
EIF_TYPE_INDEX Y7022 [483];
void Y7022_init (void)
{
	egc_routines_types [7022] = Y7022;
	egc_routines_gen_types [7022] = Y7022_gen_type;
	egc_routines_offset [7022] = 712;
	Y7022_gen_type [0] = Y7022_pgtype0;
	Y7022_gen_type [478] = Y7022_pgtype1;
	Y7022_gen_type [482] = Y7022_pgtype2;
	Y7022[0] = 596;
	Y7022[478] = 1058;
	Y7022[482] = 1058;
}

long O7036[740];
void O7036_init () {
	{long i; for (i = 0; i < 195; i++) O7036[i] = + _CHROFF_0_0_;}
	O7036[195] = + _CHROFF_1_0_;
	{long i; for (i = 196; i < 222; i++) O7036[i] = + _CHROFF_0_0_;}
	O7036[222] = + _CHROFF_3_2_;
	O7036[223] = + _CHROFF_5_2_;
	O7036[224] = + _CHROFF_4_2_;
	O7036[247] = + _CHROFF_7_0_;
	O7036[248] = + _CHROFF_5_0_;
	O7036[249] = + _CHROFF_6_0_;
	O7036[250] = + _CHROFF_5_0_;
	O7036[251] = + _CHROFF_6_0_;
	O7036[252] = + _CHROFF_5_0_;
	O7036[253] = + _CHROFF_4_0_;
	{long i; for (i = 254; i < 256; i++) O7036[i] = + _CHROFF_5_0_;}
	O7036[256] = + _CHROFF_9_0_;
	O7036[257] = + _CHROFF_7_0_;
	{long i; for (i = 258; i < 262; i++) O7036[i] = + _CHROFF_5_0_;}
	{long i; for (i = 262; i < 275; i++) O7036[i] = + _CHROFF_0_0_;}
	{long i; for (i = 275; i < 292; i++) O7036[i] = + _CHROFF_1_0_;}
	{long i; for (i = 292; i < 340; i++) O7036[i] = + _CHROFF_0_0_;}
	{long i; for (i = 340; i < 345; i++) O7036[i] = + _CHROFF_2_0_;}
	{long i; for (i = 345; i < 361; i++) O7036[i] = + _CHROFF_1_0_;}
	O7036[361] = + _CHROFF_5_0_;
	O7036[459] = + _CHROFF_1_0_;
	{long i; for (i = 462; i < 465; i++) O7036[i] = + _CHROFF_1_0_;}
	O7036[641] = + _CHROFF_5_2_;
	{long i; for (i = 676; i < 679; i++) O7036[i] = + _CHROFF_5_2_;}
	O7036[680] = + _CHROFF_7_2_;
	{long i; for (i = 681; i < 685; i++) O7036[i] = + _CHROFF_6_2_;}
	{long i; for (i = 738; i < 740; i++) O7036[i] = + _CHROFF_1_0_;}
}

EIF_TYPE_INDEX *Y7160_gen_type [1];
EIF_TYPE_INDEX Y7160 [1];
void Y7160_init (void)
{
	egc_routines_types [7160] = Y7160;
	egc_routines_gen_types [7160] = Y7160_gen_type;
	egc_routines_offset [7160] = 908;
	Y7160[0] = 1312;
}

long O7177[463];
void O7177_init () {
	O7177[0] = + _PTROFF_3_6_2_4_1_0_;
	O7177[1] = + _PTROFF_5_7_2_4_1_0_;
	O7177[2] = + _PTROFF_4_6_2_4_1_0_;
	O7177[419] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 454; i < 457; i++) O7177[i] = + _PTROFF_5_6_2_4_1_0_;}
	O7177[458] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 459; i < 463; i++) O7177[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O7316[463];
void O7316_init () {
	O7316[0] = + _LNGOFF_3_6_2_3_;
	O7316[1] = + _LNGOFF_5_7_2_3_;
	O7316[2] = + _LNGOFF_4_6_2_3_;
	O7316[419] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 454; i < 457; i++) O7316[i] = + _LNGOFF_5_6_2_3_;}
	O7316[458] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 459; i < 463; i++) O7316[i] = + _LNGOFF_6_7_2_3_;}
}

long O7325[463];
void O7325_init () {
	O7325[0] = + _CHROFF_3_3_;
	O7325[1] = + _CHROFF_5_3_;
	O7325[2] = + _CHROFF_4_3_;
	O7325[419] = + _CHROFF_5_3_;
	{long i; for (i = 454; i < 457; i++) O7325[i] = + _CHROFF_5_3_;}
	O7325[458] = + _CHROFF_7_3_;
	{long i; for (i = 459; i < 463; i++) O7325[i] = + _CHROFF_6_3_;}
}

long O7383[15];
void O7383_init () {
	O7383[0] = 0;
	O7383[1] = + _PTROFF_5_3_0_7_0_0_;
	O7383[2] = 0;
	O7383[3] = + _CHROFF_5_3_;
	O7383[4] = 0;
	O7383[5] = + _LNGOFF_5_3_0_0_;
	O7383[6] = + _LNGOFF_4_3_0_0_;
	O7383[7] = + _CHROFF_5_1_;
	O7383[8] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 9; i < 11; i++) O7383[i] = 0;}
	O7383[11] = + _CHROFF_5_4_;
	O7383[12] = + _CHROFF_5_1_;
	{long i; for (i = 13; i < 15; i++) O7383[i] = + _LNGOFF_5_4_0_0_;}
}

long O7392[15];
void O7392_init () {
	O7392[0] = + _LNGOFF_7_3_0_0_;
	O7392[1] = + _LNGOFF_5_3_0_0_;
	O7392[2] = + _LNGOFF_6_3_0_0_;
	O7392[3] = + _LNGOFF_5_5_0_0_;
	O7392[4] = + _LNGOFF_6_3_0_0_;
	O7392[5] = + _LNGOFF_5_3_0_1_;
	O7392[6] = + _LNGOFF_4_3_0_1_;
	O7392[7] = + _LNGOFF_5_5_0_0_;
	O7392[8] = + _LNGOFF_5_3_0_2_;
	O7392[9] = + _LNGOFF_9_3_0_0_;
	O7392[10] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 11; i < 13; i++) O7392[i] = + _LNGOFF_5_6_0_0_;}
	O7392[13] = + _LNGOFF_5_4_0_1_;
	O7392[14] = + _LNGOFF_5_4_0_2_;
}

long O7419[15];
void O7419_init () {
	O7419[0] =  + _REFACS_1_;
	O7419[1] = 0;
	O7419[2] =  + _REFACS_1_;
	O7419[3] = 0;
	O7419[4] =  + _REFACS_1_;
	{long i; for (i = 5; i < 9; i++) O7419[i] = 0;}
	{long i; for (i = 9; i < 11; i++) O7419[i] =  + _REFACS_1_;}
	{long i; for (i = 11; i < 15; i++) O7419[i] = 0;}
}

static EIF_TYPE_INDEX Y7419_pgtype0[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype1[] = {0xFF01,1231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype2[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype3[] = {0xFF01,1236,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype4[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype5[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype6[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype7[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype8[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype9[] = {0xFF01,1230,0,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype10[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype11[] = {0xFF01,1236,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype12[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype13[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7419_pgtype14[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7419_gen_type [15];
EIF_TYPE_INDEX Y7419 [15];
void Y7419_init (void)
{
	egc_routines_types [7419] = Y7419;
	egc_routines_gen_types [7419] = Y7419_gen_type;
	egc_routines_offset [7419] = 960;
	Y7419_gen_type [0] = Y7419_pgtype0;
	Y7419_gen_type [1] = Y7419_pgtype1;
	Y7419_gen_type [2] = Y7419_pgtype2;
	Y7419_gen_type [3] = Y7419_pgtype3;
	Y7419_gen_type [4] = Y7419_pgtype4;
	Y7419_gen_type [5] = Y7419_pgtype5;
	Y7419_gen_type [6] = Y7419_pgtype6;
	Y7419_gen_type [7] = Y7419_pgtype7;
	Y7419_gen_type [8] = Y7419_pgtype8;
	Y7419_gen_type [9] = Y7419_pgtype9;
	Y7419_gen_type [10] = Y7419_pgtype10;
	Y7419_gen_type [11] = Y7419_pgtype11;
	Y7419_gen_type [12] = Y7419_pgtype12;
	Y7419_gen_type [13] = Y7419_pgtype13;
	Y7419_gen_type [14] = Y7419_pgtype14;
	Y7419[0] = 1230;
	Y7419[1] = 1231;
	Y7419[2] = 1230;
	Y7419[3] = 1236;
	Y7419[4] = 1230;
	{long i; for (i = 5; i < 7; i++) Y7419[i] = 1233;};
	Y7419[7] = 1235;
	Y7419[8] = 1239;
	{long i; for (i = 9; i < 11; i++) Y7419[i] = 1230;};
	Y7419[11] = 1236;
	Y7419[12] = 1235;
	Y7419[13] = 1233;
	Y7419[14] = 1239;
}

long O7420[15];
void O7420_init () {
	O7420[0] =  + _REFACS_2_;
	O7420[1] =  + _REFACS_1_;
	O7420[2] =  + _REFACS_2_;
	O7420[3] =  + _REFACS_1_;
	O7420[4] =  + _REFACS_2_;
	{long i; for (i = 5; i < 9; i++) O7420[i] =  + _REFACS_1_;}
	{long i; for (i = 9; i < 11; i++) O7420[i] =  + _REFACS_2_;}
	{long i; for (i = 11; i < 15; i++) O7420[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y7420_pgtype0[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype1[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype2[] = {0xFF01,1233,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype3[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype4[] = {0xFF01,1231,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype5[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype6[] = {0xFF01,1233,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype7[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype8[] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype9[] = {0xFF01,1230,0xFF01,1175,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype10[] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype11[] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype12[] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype13[] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static EIF_TYPE_INDEX Y7420_pgtype14[] = {0xFF01,1230,0xFF01,1167,0xFFFF};
EIF_TYPE_INDEX *Y7420_gen_type [15];
EIF_TYPE_INDEX Y7420 [15];
void Y7420_init (void)
{
	egc_routines_types [7420] = Y7420;
	egc_routines_gen_types [7420] = Y7420_gen_type;
	egc_routines_offset [7420] = 960;
	Y7420_gen_type [0] = Y7420_pgtype0;
	Y7420_gen_type [1] = Y7420_pgtype1;
	Y7420_gen_type [2] = Y7420_pgtype2;
	Y7420_gen_type [3] = Y7420_pgtype3;
	Y7420_gen_type [4] = Y7420_pgtype4;
	Y7420_gen_type [5] = Y7420_pgtype5;
	Y7420_gen_type [6] = Y7420_pgtype6;
	Y7420_gen_type [7] = Y7420_pgtype7;
	Y7420_gen_type [8] = Y7420_pgtype8;
	Y7420_gen_type [9] = Y7420_pgtype9;
	Y7420_gen_type [10] = Y7420_pgtype10;
	Y7420_gen_type [11] = Y7420_pgtype11;
	Y7420_gen_type [12] = Y7420_pgtype12;
	Y7420_gen_type [13] = Y7420_pgtype13;
	Y7420_gen_type [14] = Y7420_pgtype14;
	{long i; for (i = 0; i < 2; i++) Y7420[i] = 1230;};
	Y7420[2] = 1233;
	Y7420[3] = 1230;
	Y7420[4] = 1231;
	Y7420[5] = 1230;
	Y7420[6] = 1233;
	{long i; for (i = 7; i < 15; i++) Y7420[i] = 1230;};
}

long O7421[15];
void O7421_init () {
	O7421[0] =  + _REFACS_3_;
	O7421[1] =  + _REFACS_2_;
	O7421[2] =  + _REFACS_3_;
	O7421[3] =  + _REFACS_2_;
	O7421[4] =  + _REFACS_3_;
	{long i; for (i = 5; i < 9; i++) O7421[i] =  + _REFACS_2_;}
	{long i; for (i = 9; i < 11; i++) O7421[i] =  + _REFACS_3_;}
	{long i; for (i = 11; i < 15; i++) O7421[i] =  + _REFACS_2_;}
}

long O7422[15];
void O7422_init () {
	O7422[0] =  + _REFACS_4_;
	O7422[1] =  + _REFACS_3_;
	O7422[2] =  + _REFACS_4_;
	O7422[3] =  + _REFACS_3_;
	O7422[4] =  + _REFACS_4_;
	{long i; for (i = 5; i < 9; i++) O7422[i] =  + _REFACS_3_;}
	{long i; for (i = 9; i < 11; i++) O7422[i] =  + _REFACS_4_;}
	{long i; for (i = 11; i < 15; i++) O7422[i] =  + _REFACS_3_;}
}

long O7423[15];
void O7423_init () {
	O7423[0] = + _LNGOFF_7_3_0_1_;
	O7423[1] = + _LNGOFF_5_3_0_1_;
	O7423[2] = + _LNGOFF_6_3_0_1_;
	O7423[3] = + _LNGOFF_5_5_0_1_;
	O7423[4] = + _LNGOFF_6_3_0_1_;
	O7423[5] = + _LNGOFF_5_3_0_2_;
	O7423[6] = + _LNGOFF_4_3_0_2_;
	O7423[7] = + _LNGOFF_5_5_0_1_;
	O7423[8] = + _LNGOFF_5_3_0_3_;
	O7423[9] = + _LNGOFF_9_3_0_1_;
	O7423[10] = + _LNGOFF_7_4_0_1_;
	{long i; for (i = 11; i < 13; i++) O7423[i] = + _LNGOFF_5_6_0_1_;}
	O7423[13] = + _LNGOFF_5_4_0_2_;
	O7423[14] = + _LNGOFF_5_4_0_3_;
}

long O7424[15];
void O7424_init () {
	O7424[0] = + _CHROFF_7_2_;
	O7424[1] = + _CHROFF_5_2_;
	O7424[2] = + _CHROFF_6_2_;
	O7424[3] = + _CHROFF_5_2_;
	O7424[4] = + _CHROFF_6_2_;
	O7424[5] = + _CHROFF_5_2_;
	O7424[6] = + _CHROFF_4_2_;
	O7424[7] = + _CHROFF_5_3_;
	O7424[8] = + _CHROFF_5_2_;
	O7424[9] = + _CHROFF_9_2_;
	O7424[10] = + _CHROFF_7_2_;
	O7424[11] = + _CHROFF_5_2_;
	O7424[12] = + _CHROFF_5_3_;
	{long i; for (i = 13; i < 15; i++) O7424[i] = + _CHROFF_5_2_;}
}

long O7425[15];
void O7425_init () {
	O7425[0] = + _LNGOFF_7_3_0_2_;
	O7425[1] = + _LNGOFF_5_3_0_2_;
	O7425[2] = + _LNGOFF_6_3_0_2_;
	O7425[3] = + _LNGOFF_5_5_0_2_;
	O7425[4] = + _LNGOFF_6_3_0_2_;
	O7425[5] = + _LNGOFF_5_3_0_3_;
	O7425[6] = + _LNGOFF_4_3_0_3_;
	O7425[7] = + _LNGOFF_5_5_0_2_;
	O7425[8] = + _LNGOFF_5_3_0_4_;
	O7425[9] = + _LNGOFF_9_3_0_2_;
	O7425[10] = + _LNGOFF_7_4_0_2_;
	{long i; for (i = 11; i < 13; i++) O7425[i] = + _LNGOFF_5_6_0_2_;}
	O7425[13] = + _LNGOFF_5_4_0_3_;
	O7425[14] = + _LNGOFF_5_4_0_4_;
}

long O7428[15];
void O7428_init () {
	O7428[0] = + _LNGOFF_7_3_0_3_;
	O7428[1] = + _LNGOFF_5_3_0_3_;
	O7428[2] = + _LNGOFF_6_3_0_3_;
	O7428[3] = + _LNGOFF_5_5_0_3_;
	O7428[4] = + _LNGOFF_6_3_0_3_;
	O7428[5] = + _LNGOFF_5_3_0_4_;
	O7428[6] = + _LNGOFF_4_3_0_4_;
	O7428[7] = + _LNGOFF_5_5_0_3_;
	O7428[8] = + _LNGOFF_5_3_0_5_;
	O7428[9] = + _LNGOFF_9_3_0_3_;
	O7428[10] = + _LNGOFF_7_4_0_3_;
	{long i; for (i = 11; i < 13; i++) O7428[i] = + _LNGOFF_5_6_0_3_;}
	O7428[13] = + _LNGOFF_5_4_0_4_;
	O7428[14] = + _LNGOFF_5_4_0_5_;
}

long O7429[15];
void O7429_init () {
	O7429[0] = + _LNGOFF_7_3_0_4_;
	O7429[1] = + _LNGOFF_5_3_0_4_;
	O7429[2] = + _LNGOFF_6_3_0_4_;
	O7429[3] = + _LNGOFF_5_5_0_4_;
	O7429[4] = + _LNGOFF_6_3_0_4_;
	O7429[5] = + _LNGOFF_5_3_0_5_;
	O7429[6] = + _LNGOFF_4_3_0_5_;
	O7429[7] = + _LNGOFF_5_5_0_4_;
	O7429[8] = + _LNGOFF_5_3_0_6_;
	O7429[9] = + _LNGOFF_9_3_0_4_;
	O7429[10] = + _LNGOFF_7_4_0_4_;
	{long i; for (i = 11; i < 13; i++) O7429[i] = + _LNGOFF_5_6_0_4_;}
	O7429[13] = + _LNGOFF_5_4_0_5_;
	O7429[14] = + _LNGOFF_5_4_0_6_;
}

long O7433[15];
void O7433_init () {
	O7433[0] = + _LNGOFF_7_3_0_5_;
	O7433[1] = + _LNGOFF_5_3_0_5_;
	O7433[2] = + _LNGOFF_6_3_0_5_;
	O7433[3] = + _LNGOFF_5_5_0_5_;
	O7433[4] = + _LNGOFF_6_3_0_5_;
	O7433[5] = + _LNGOFF_5_3_0_6_;
	O7433[6] = + _LNGOFF_4_3_0_6_;
	O7433[7] = + _LNGOFF_5_5_0_5_;
	O7433[8] = + _LNGOFF_5_3_0_7_;
	O7433[9] = + _LNGOFF_9_3_0_5_;
	O7433[10] = + _LNGOFF_7_4_0_5_;
	{long i; for (i = 11; i < 13; i++) O7433[i] = + _LNGOFF_5_6_0_5_;}
	O7433[13] = + _LNGOFF_5_4_0_6_;
	O7433[14] = + _LNGOFF_5_4_0_7_;
}

long O7434[15];
void O7434_init () {
	O7434[0] =  + _REFACS_5_;
	O7434[1] = + _PTROFF_5_3_0_7_0_1_;
	O7434[2] =  + _REFACS_5_;
	O7434[3] = + _CHROFF_5_4_;
	O7434[4] =  + _REFACS_5_;
	O7434[5] = + _LNGOFF_5_3_0_7_;
	O7434[6] = + _LNGOFF_4_3_0_7_;
	O7434[7] = + _CHROFF_5_4_;
	O7434[8] = + _LNGOFF_5_3_0_1_;
	{long i; for (i = 9; i < 11; i++) O7434[i] =  + _REFACS_5_;}
	O7434[11] = + _CHROFF_5_5_;
	O7434[12] = + _CHROFF_5_4_;
	O7434[13] = + _LNGOFF_5_4_0_7_;
	O7434[14] = + _LNGOFF_5_4_0_1_;
}

long O7435[15];
void O7435_init () {
	O7435[0] =  + _REFACS_6_;
	O7435[1] =  + _REFACS_4_;
	O7435[2] = + _LNGOFF_6_3_0_6_;
	O7435[3] =  + _REFACS_4_;
	O7435[4] = + _PTROFF_6_3_0_7_0_0_;
	O7435[5] =  + _REFACS_4_;
	O7435[6] = + _LNGOFF_4_3_0_8_;
	{long i; for (i = 7; i < 9; i++) O7435[i] =  + _REFACS_4_;}
	{long i; for (i = 9; i < 11; i++) O7435[i] =  + _REFACS_6_;}
	{long i; for (i = 11; i < 15; i++) O7435[i] =  + _REFACS_4_;}
}

long O7469[15];
void O7469_init () {
	O7469[0] = + _LNGOFF_7_3_0_6_;
	O7469[1] = + _LNGOFF_5_3_0_6_;
	O7469[2] = + _LNGOFF_6_3_0_7_;
	O7469[3] = + _LNGOFF_5_5_0_6_;
	O7469[4] = + _LNGOFF_6_3_0_6_;
	O7469[5] = + _LNGOFF_5_3_0_8_;
	O7469[6] = + _LNGOFF_4_3_0_9_;
	O7469[7] = + _LNGOFF_5_5_0_6_;
	O7469[8] = + _LNGOFF_5_3_0_8_;
	O7469[9] = + _LNGOFF_9_3_0_6_;
	O7469[10] = + _LNGOFF_7_4_0_6_;
	{long i; for (i = 11; i < 13; i++) O7469[i] = + _LNGOFF_5_6_0_6_;}
	{long i; for (i = 13; i < 15; i++) O7469[i] = + _LNGOFF_5_4_0_8_;}
}

long O7482[5];
void O7482_init () {
	O7482[0] = + _CHROFF_7_3_;
	O7482[1] = + _CHROFF_5_3_;
	O7482[2] = + _CHROFF_5_5_;
	{long i; for (i = 3; i < 5; i++) O7482[i] = + _CHROFF_5_3_;}
}

long O7592[17];
void O7592_init () {
	{long i; for (i = 0; i < 16; i++) O7592[i] = + _LNGOFF_1_1_0_0_;}
	O7592[16] = + _LNGOFF_5_1_0_0_;
}

long O8287[2];
void O8287_init () {
	O8287[0] = + _LNGOFF_3_4_0_0_;
	O8287[1] = + _LNGOFF_5_5_0_0_;
}

long O8289[2];
void O8289_init () {
	O8289[0] = + _CHROFF_3_0_;
	O8289[1] = + _CHROFF_5_0_;
}

long O8290[2];
void O8290_init () {
	O8290[0] = + _CHROFF_3_1_;
	O8290[1] = + _CHROFF_5_1_;
}

long O8291[2];
void O8291_init () {
	O8291[0] = + _CHROFF_3_2_;
	O8291[1] = + _CHROFF_5_2_;
}

long O8292[2];
void O8292_init () {
	O8292[0] = + _CHROFF_3_3_;
	O8292[1] = + _CHROFF_5_3_;
}

long O8431[6];
void O8431_init () {
	{long i; for (i = 0; i < 2; i++) O8431[i] = + _CHROFF_4_0_;}
	O8431[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O8431[i] = + _CHROFF_4_0_;}
}

long O8432[6];
void O8432_init () {
	{long i; for (i = 0; i < 2; i++) O8432[i] = + _LNGOFF_4_2_0_0_;}
	O8432[2] = + _LNGOFF_5_2_0_0_;
	O8432[3] = + _LNGOFF_4_3_0_0_;
	O8432[4] = + _LNGOFF_4_2_0_0_;
	O8432[5] = + _LNGOFF_4_3_0_0_;
}

long O8440[6];
void O8440_init () {
	{long i; for (i = 0; i < 2; i++) O8440[i] = + _PTROFF_4_2_0_3_0_0_;}
	O8440[2] = + _PTROFF_5_2_0_3_0_0_;
	O8440[3] = + _PTROFF_4_3_0_3_0_0_;
	O8440[4] = + _PTROFF_4_2_0_4_0_0_;
	O8440[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O8441[6];
void O8441_init () {
	{long i; for (i = 0; i < 2; i++) O8441[i] = + _PTROFF_4_2_0_3_0_1_;}
	O8441[2] = + _PTROFF_5_2_0_3_0_1_;
	O8441[3] = + _PTROFF_4_3_0_3_0_1_;
	O8441[4] = + _PTROFF_4_2_0_4_0_1_;
	O8441[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O8443[6];
void O8443_init () {
	{long i; for (i = 0; i < 2; i++) O8443[i] = + _PTROFF_4_2_0_3_0_2_;}
	O8443[2] = + _PTROFF_5_2_0_3_0_2_;
	O8443[3] = + _PTROFF_4_3_0_3_0_2_;
	O8443[4] = + _PTROFF_4_2_0_4_0_2_;
	O8443[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O8444[6];
void O8444_init () {
	{long i; for (i = 0; i < 2; i++) O8444[i] = + _LNGOFF_4_2_0_1_;}
	O8444[2] = + _LNGOFF_5_2_0_1_;
	O8444[3] = + _LNGOFF_4_3_0_1_;
	O8444[4] = + _LNGOFF_4_2_0_1_;
	O8444[5] = + _LNGOFF_4_3_0_1_;
}

long O8445[6];
void O8445_init () {
	{long i; for (i = 0; i < 2; i++) O8445[i] = + _CHROFF_4_1_;}
	O8445[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O8445[i] = + _CHROFF_4_1_;}
}

long O8446[6];
void O8446_init () {
	{long i; for (i = 0; i < 2; i++) O8446[i] = + _LNGOFF_4_2_0_2_;}
	O8446[2] = + _LNGOFF_5_2_0_2_;
	O8446[3] = + _LNGOFF_4_3_0_2_;
	O8446[4] = + _LNGOFF_4_2_0_2_;
	O8446[5] = + _LNGOFF_4_3_0_2_;
}

long O8459[4];
void O8459_init () {
	O8459[0] =  + _REFACS_4_;
	O8459[1] = + _CHROFF_4_2_;
	O8459[2] = + _LNGOFF_4_2_0_3_;
	O8459[3] = + _CHROFF_4_2_;
}

long O8558[286];
void O8558_init () {
	{long i; for (i = 0; i < 3; i++) O8558[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O8558[i] = + _LNGOFF_1_0_0_0_;}
	O8558[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O8558[i] = + _LNGOFF_1_0_0_0_;}
	O8558[8] = + _LNGOFF_1_1_0_0_;
	O8558[9] = + _LNGOFF_1_1_0_1_;
	O8558[10] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 284; i < 286; i++) O8558[i] = + _LNGOFF_1_1_0_0_;}
}

long O8559[286];
void O8559_init () {
	{long i; for (i = 0; i < 3; i++) O8559[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O8559[i] = + _LNGOFF_1_0_0_1_;}
	O8559[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O8559[i] = + _LNGOFF_1_0_0_1_;}
	O8559[8] = + _LNGOFF_1_1_0_1_;
	O8559[9] = + _LNGOFF_1_1_0_2_;
	O8559[10] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 284; i < 286; i++) O8559[i] = + _LNGOFF_1_1_0_1_;}
}

long O8624[3];
void O8624_init () {
	{long i; for (i = 0; i < 2; i++) O8624[i] = + _LNGOFF_1_0_0_2_;}
	O8624[2] = + _LNGOFF_1_1_0_2_;
}

long O8704[280];
void O8704_init () {
	{long i; for (i = 0; i < 2; i++) O8704[i] = + _LNGOFF_1_0_0_2_;}
	O8704[2] = + _LNGOFF_1_1_0_2_;
	O8704[3] = + _LNGOFF_1_1_0_3_;
	O8704[4] = + _LNGOFF_1_1_0_2_;
	{long i; for (i = 278; i < 280; i++) O8704[i] = + _LNGOFF_1_1_0_2_;}
}

long O9378[10];
void O9378_init () {
	{long i; for (i = 0; i < 2; i++) O9378[i] = + _CHROFF_16_0_;}
	O9378[2] = + _CHROFF_18_0_;
	O9378[3] = + _CHROFF_27_0_;
	O9378[4] = + _CHROFF_29_0_;
	O9378[5] = + _CHROFF_27_0_;
	O9378[6] = + _CHROFF_18_0_;
	O9378[7] = + _CHROFF_23_0_;
	O9378[8] = + _CHROFF_21_0_;
	O9378[9] = + _CHROFF_22_0_;
}

long O9389[10];
void O9389_init () {
	{long i; for (i = 0; i < 3; i++) O9389[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O9389[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O9389[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O9389[i] =  + _REFACS_5_;}
}

static EIF_TYPE_INDEX Y9389_pgtype0[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype1[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype2[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype3[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype4[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype5[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype6[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype7[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype8[] = {0xFF01,1170,0xFFFF};
static EIF_TYPE_INDEX Y9389_pgtype9[] = {0xFF01,1170,0xFFFF};
EIF_TYPE_INDEX *Y9389_gen_type [10];
EIF_TYPE_INDEX Y9389 [10];
void Y9389_init (void)
{
	egc_routines_types [9389] = Y9389;
	egc_routines_gen_types [9389] = Y9389_gen_type;
	egc_routines_offset [9389] = 1245;
	Y9389_gen_type [0] = Y9389_pgtype0;
	Y9389_gen_type [1] = Y9389_pgtype1;
	Y9389_gen_type [2] = Y9389_pgtype2;
	Y9389_gen_type [3] = Y9389_pgtype3;
	Y9389_gen_type [4] = Y9389_pgtype4;
	Y9389_gen_type [5] = Y9389_pgtype5;
	Y9389_gen_type [6] = Y9389_pgtype6;
	Y9389_gen_type [7] = Y9389_pgtype7;
	Y9389_gen_type [8] = Y9389_pgtype8;
	Y9389_gen_type [9] = Y9389_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y9389[i] = 1170;};
}

long O9390[10];
void O9390_init () {
	{long i; for (i = 0; i < 3; i++) O9390[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O9390[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O9390[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O9390[i] =  + _REFACS_6_;}
}

long O9391[10];
void O9391_init () {
	{long i; for (i = 0; i < 3; i++) O9391[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O9391[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O9391[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O9391[i] =  + _REFACS_7_;}
}

static EIF_TYPE_INDEX Y9391_pgtype0[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype1[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype2[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype3[] = {0xFF01,1399,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype4[] = {0xFF01,1399,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype5[] = {0xFF01,1399,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype6[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype7[] = {0xFF01,1400,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype8[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y9391_pgtype9[] = {0xFF01,1398,0xFFFF};
EIF_TYPE_INDEX *Y9391_gen_type [10];
EIF_TYPE_INDEX Y9391 [10];
void Y9391_init (void)
{
	egc_routines_types [9391] = Y9391;
	egc_routines_gen_types [9391] = Y9391_gen_type;
	egc_routines_offset [9391] = 1245;
	Y9391_gen_type [0] = Y9391_pgtype0;
	Y9391_gen_type [1] = Y9391_pgtype1;
	Y9391_gen_type [2] = Y9391_pgtype2;
	Y9391_gen_type [3] = Y9391_pgtype3;
	Y9391_gen_type [4] = Y9391_pgtype4;
	Y9391_gen_type [5] = Y9391_pgtype5;
	Y9391_gen_type [6] = Y9391_pgtype6;
	Y9391_gen_type [7] = Y9391_pgtype7;
	Y9391_gen_type [8] = Y9391_pgtype8;
	Y9391_gen_type [9] = Y9391_pgtype9;
	{long i; for (i = 0; i < 3; i++) Y9391[i] = 1398;};
	{long i; for (i = 3; i < 6; i++) Y9391[i] = 1399;};
	Y9391[6] = 1398;
	Y9391[7] = 1400;
	{long i; for (i = 8; i < 10; i++) Y9391[i] = 1398;};
}

long O9393[10];
void O9393_init () {
	{long i; for (i = 0; i < 3; i++) O9393[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O9393[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O9393[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O9393[i] =  + _REFACS_8_;}
}

long O9395[10];
void O9395_init () {
	{long i; for (i = 0; i < 3; i++) O9395[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O9395[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O9395[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O9395[i] =  + _REFACS_10_;}
}

long O9426[10];
void O9426_init () {
	{long i; for (i = 0; i < 2; i++) O9426[i] = + _CHROFF_16_1_;}
	O9426[2] = + _CHROFF_18_1_;
	O9426[3] = + _CHROFF_27_1_;
	O9426[4] = + _CHROFF_29_1_;
	O9426[5] = + _CHROFF_27_1_;
	O9426[6] = + _CHROFF_18_1_;
	O9426[7] = + _CHROFF_23_1_;
	O9426[8] = + _CHROFF_21_1_;
	O9426[9] = + _CHROFF_22_1_;
}

long O9427[10];
void O9427_init () {
	{long i; for (i = 0; i < 3; i++) O9427[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O9427[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O9427[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O9427[i] =  + _REFACS_11_;}
}

long O9429[10];
void O9429_init () {
	{long i; for (i = 0; i < 3; i++) O9429[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O9429[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O9429[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O9429[i] =  + _REFACS_13_;}
}

long O9437[10];
void O9437_init () {
	{long i; for (i = 0; i < 2; i++) O9437[i] = + _LNGOFF_16_3_0_0_;}
	O9437[2] = + _LNGOFF_18_3_0_0_;
	O9437[3] = + _LNGOFF_27_5_0_0_;
	O9437[4] = + _LNGOFF_29_5_0_0_;
	O9437[5] = + _LNGOFF_27_5_0_0_;
	O9437[6] = + _LNGOFF_18_3_0_0_;
	O9437[7] = + _LNGOFF_23_4_0_0_;
	O9437[8] = + _LNGOFF_21_4_0_0_;
	O9437[9] = + _LNGOFF_22_4_0_0_;
}

long O9438[10];
void O9438_init () {
	{long i; for (i = 0; i < 3; i++) O9438[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O9438[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O9438[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O9438[i] =  + _REFACS_16_;}
}

long O9440[10];
void O9440_init () {
	{long i; for (i = 0; i < 2; i++) O9440[i] = + _CHROFF_16_2_;}
	O9440[2] = + _CHROFF_18_2_;
	O9440[3] = + _CHROFF_27_2_;
	O9440[4] = + _CHROFF_29_2_;
	O9440[5] = + _CHROFF_27_2_;
	O9440[6] = + _CHROFF_18_2_;
	O9440[7] = + _CHROFF_23_2_;
	O9440[8] = + _CHROFF_21_2_;
	O9440[9] = + _CHROFF_22_2_;
}

long O9445[3];
void O9445_init () {
	O9445[0] = + _CHROFF_27_3_;
	O9445[1] = + _CHROFF_29_3_;
	O9445[2] = + _CHROFF_27_3_;
}

long O9446[3];
void O9446_init () {
	O9446[0] = + _CHROFF_27_4_;
	O9446[1] = + _CHROFF_29_4_;
	O9446[2] = + _CHROFF_27_4_;
}

static EIF_TYPE_INDEX Y9448_pgtype0[] = {1058,0xFF01,1248,0xFFFF};
static EIF_TYPE_INDEX Y9448_pgtype1[] = {1058,0xFF01,1249,0xFFFF};
static EIF_TYPE_INDEX Y9448_pgtype2[] = {1058,0xFF01,1250,0xFFFF};
EIF_TYPE_INDEX *Y9448_gen_type [3];
EIF_TYPE_INDEX Y9448 [3];
void Y9448_init (void)
{
	egc_routines_types [9448] = Y9448;
	egc_routines_gen_types [9448] = Y9448_gen_type;
	egc_routines_offset [9448] = 1248;
	Y9448_gen_type [0] = Y9448_pgtype0;
	Y9448_gen_type [1] = Y9448_pgtype1;
	Y9448_gen_type [2] = Y9448_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y9448[i] = 1058;};
}

long O9480[4];
void O9480_init () {
	{long i; for (i = 0; i < 2; i++) O9480[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O9480[i] =  + _REFACS_18_;}
}

long O9481[4];
void O9481_init () {
	{long i; for (i = 0; i < 2; i++) O9481[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O9481[i] =  + _REFACS_19_;}
}

long O9497[2];
void O9497_init () {
	O9497[0] = + _CHROFF_21_3_;
	O9497[1] = + _CHROFF_22_3_;
}

long O10227[3];
void O10227_init () {
	O10227[0] = 0;
	{long i; for (i = 1; i < 3; i++) O10227[i] = + _LNGOFF_3_1_0_0_;}
}

long O10229[3];
void O10229_init () {
	O10229[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O10229[i] = 0;}
}

long O10241[3];
void O10241_init () {
	O10241[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O10241[i] = + _LNGOFF_3_1_0_1_;}
}

long O10244[3];
void O10244_init () {
	O10244[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O10244[i] = + _LNGOFF_3_1_0_2_;}
}

long O10251[3];
void O10251_init () {
	O10251[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O10251[i] = + _LNGOFF_3_1_0_3_;}
}

long O10258[3];
void O10258_init () {
	O10258[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O10258[i] = + _CHROFF_3_0_;}
}

long O10259[3];
void O10259_init () {
	O10259[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O10259[i] = + _LNGOFF_3_1_0_4_;}
}

long O10260[3];
void O10260_init () {
	O10260[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O10260[i] =  + _REFACS_1_;}
}

long O10261[3];
void O10261_init () {
	O10261[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O10261[i] =  + _REFACS_2_;}
}

long O10270[3];
void O10270_init () {
	O10270[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O10270[i] = + _LNGOFF_3_1_0_5_;}
}

long O10815[3];
void O10815_init () {
	O10815[0] = + _CHROFF_2_0_;
	O10815[1] = + _CHROFF_5_0_;
	O10815[2] = + _CHROFF_16_0_;
}

long O10817[3];
void O10817_init () {
	O10817[0] = + _CHROFF_2_1_;
	O10817[1] = + _CHROFF_5_1_;
	O10817[2] = + _CHROFF_16_1_;
}

long O10819[3];
void O10819_init () {
	{long i; for (i = 0; i < 2; i++) O10819[i] = 0;}
	O10819[2] =  + _REFACS_1_;
}

long O10820[3];
void O10820_init () {
	{long i; for (i = 0; i < 2; i++) O10820[i] =  + _REFACS_1_;}
	O10820[2] =  + _REFACS_2_;
}

long O10822[3];
void O10822_init () {
	O10822[0] = + _LNGOFF_2_2_0_0_;
	O10822[1] = + _LNGOFF_5_2_0_0_;
	O10822[2] = + _LNGOFF_16_4_0_1_;
}

long O10889[3];
void O10889_init () {
	O10889[0] = + _LNGOFF_11_3_0_2_;
	O10889[1] = + _LNGOFF_13_3_0_2_;
	O10889[2] = + _LNGOFF_12_3_0_2_;
}

long O10909[3];
void O10909_init () {
	O10909[0] = + _CHROFF_11_0_;
	O10909[1] = + _CHROFF_13_0_;
	O10909[2] = + _CHROFF_12_0_;
}

long O10911[3];
void O10911_init () {
	O10911[0] = + _LNGOFF_11_3_0_3_;
	O10911[1] = + _LNGOFF_13_3_0_3_;
	O10911[2] = + _LNGOFF_12_3_0_3_;
}

long O10912[3];
void O10912_init () {
	O10912[0] = + _LNGOFF_11_3_0_4_;
	O10912[1] = + _LNGOFF_13_3_0_4_;
	O10912[2] = + _LNGOFF_12_3_0_4_;
}

long O10913[3];
void O10913_init () {
	O10913[0] = + _LNGOFF_11_3_0_5_;
	O10913[1] = + _LNGOFF_13_3_0_5_;
	O10913[2] = + _LNGOFF_12_3_0_5_;
}

long O10915[3];
void O10915_init () {
	O10915[0] = + _LNGOFF_11_3_0_0_;
	O10915[1] = + _LNGOFF_13_3_0_0_;
	O10915[2] = + _LNGOFF_12_3_0_0_;
}

long O10916[3];
void O10916_init () {
	O10916[0] = + _LNGOFF_11_3_0_1_;
	O10916[1] = + _LNGOFF_13_3_0_1_;
	O10916[2] = + _LNGOFF_12_3_0_1_;
}

long O10918[3];
void O10918_init () {
	O10918[0] = + _CHROFF_11_2_;
	O10918[1] = + _CHROFF_13_2_;
	O10918[2] = + _CHROFF_12_2_;
}

long O10925[3];
void O10925_init () {
	O10925[0] = + _LNGOFF_11_3_0_6_;
	O10925[1] = + _LNGOFF_13_3_0_6_;
	O10925[2] = + _LNGOFF_12_3_0_6_;
}

long O12155[3];
void O12155_init () {
	{long i; for (i = 0; i < 2; i++) O12155[i] = + _CHROFF_6_0_;}
	O12155[2] = + _CHROFF_7_0_;
}

long O12156[3];
void O12156_init () {
	{long i; for (i = 0; i < 2; i++) O12156[i] = + _CHROFF_6_1_;}
	O12156[2] = + _CHROFF_7_1_;
}

long O12166[3];
void O12166_init () {
	{long i; for (i = 0; i < 2; i++) O12166[i] = + _LNGOFF_6_2_0_0_;}
	O12166[2] = + _LNGOFF_7_3_0_0_;
}


#ifdef __cplusplus
}
#endif
