#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4338[265])();
void R4338_init () {
	R4338[0] = (char *(*)()) F328_4621;
	{long i; for (i = 7; i < 9; i++) R4338[i] = (char *(*)()) F330_4636;}
	R4338[264] = (char *(*)()) F424_5534;
}

char *(*R4339[265])();
void R4339_init () {
	R4339[0] = (char *(*)()) F328_4622;
	{long i; for (i = 7; i < 9; i++) R4339[i] = (char *(*)()) F330_4637;}
	R4339[264] = (char *(*)()) F328_4622;
}

char *(*R4340[265])();
void R4340_init () {
	R4340[0] = (char *(*)()) F328_4623;
	{long i; for (i = 7; i < 9; i++) R4340[i] = (char *(*)()) F330_4638;}
	R4340[264] = (char *(*)()) F328_4623;
}

char *(*R4341[265])();
void R4341_init () {
	R4341[0] = (char *(*)()) F328_4624;
	R4341[7] = (char *(*)()) F335_4769;
	R4341[8] = (char *(*)()) F336_4790;
	R4341[264] = (char *(*)()) F592_7441;
}

char *(*R4342[265])();
void R4342_init () {
	R4342[0] = (char *(*)()) F328_4625;
	R4342[7] = (char *(*)()) F330_4640;
	R4342[8] = (char *(*)()) F336_4791;
	R4342[264] = (char *(*)()) F592_7442;
}

char *(*R4343[265])();
void R4343_init () {
	R4343[0] = (char *(*)()) F328_4626;
	R4343[7] = (char *(*)()) F330_4641;
	R4343[8] = (char *(*)()) F336_4792;
	R4343[264] = (char *(*)()) F592_7443;
}

char *(*R4344[265])();
void R4344_init () {
	R4344[0] = (char *(*)()) F328_4627;
	R4344[7] = (char *(*)()) F335_4770;
	R4344[8] = (char *(*)()) F336_4793;
	R4344[264] = (char *(*)()) F592_7444;
}

char *(*R4345[265])();
void R4345_init () {
	R4345[0] = (char *(*)()) F328_4628;
	R4345[7] = (char *(*)()) F335_4771;
	R4345[8] = (char *(*)()) F330_4643;
	R4345[264] = (char *(*)()) F592_7445;
}

char *(*R4502[844])();
void R4502_init () {
	R4502[0] = (char *(*)()) F339_4845;
	R4502[842] = (char *(*)()) F1182_10529;
	R4502[843] = (char *(*)()) F1183_10557;
}

char *(*R4503[844])();
void R4503_init () {
	R4503[0] = (char *(*)()) F339_4846;
	R4503[842] = (char *(*)()) F1182_10533;
	R4503[843] = (char *(*)()) F1183_10559;
}

char *(*R4505[844])();
void R4505_init () {
	R4505[0] = (char *(*)()) F339_4848;
	R4505[842] = (char *(*)()) F1182_10535;
	R4505[843] = (char *(*)()) F1183_10561;
}

char *(*R4506[844])();
void R4506_init () {
	R4506[0] = (char *(*)()) F339_4849;
	R4506[842] = (char *(*)()) F1182_10536;
	R4506[843] = (char *(*)()) F1183_10562;
}

char *(*R4507[844])();
void R4507_init () {
	R4507[0] = (char *(*)()) F339_4850;
	R4507[842] = (char *(*)()) F1182_10537;
	R4507[843] = (char *(*)()) F1183_10563;
}

char *(*R4508[844])();
void R4508_init () {
	R4508[0] = (char *(*)()) F340_4854;
	{long i; for (i = 842; i < 844; i++) R4508[i] = (char *(*)()) F341_4857;}
}

char *(*R4509[844])();
void R4509_init () {
	R4509[0] = (char *(*)()) F340_4855;
	{long i; for (i = 842; i < 844; i++) R4509[i] = (char *(*)()) F341_4859;}
}

char *(*R4527[2])();
void R4527_init () {
	R4527[0] = (char *(*)()) F1182_10538;
	R4527[1] = (char *(*)()) F1183_10564;
}

char *(*R4528[2])();
void R4528_init () {
	R4528[0] = (char *(*)()) F1182_10544;
	R4528[1] = (char *(*)()) F1183_10566;
}

char *(*R4699[2])();
void R4699_init () {
	R4699[0] = (char *(*)()) F347_5031;
	R4699[1] = (char *(*)()) F348_5031;
}

char *(*R4708[3])();
void R4708_init () {
	R4708[0] = (char *(*)()) F352_5043;
	R4708[1] = (char *(*)()) F353_5044;
	R4708[2] = (char *(*)()) F354_5045;
}

char *(*R4746[42])();
void R4746_init () {
	R4746[0] = (char *(*)()) F357_5080;
	R4746[3] = (char *(*)()) F360_5104;
	R4746[5] = (char *(*)()) F362_5106;
	R4746[6] = (char *(*)()) F363_5110;
	R4746[7] = (char *(*)()) F364_5116;
	R4746[9] = (char *(*)()) F366_5133;
	R4746[10] = (char *(*)()) F367_5135;
	R4746[11] = (char *(*)()) F368_5137;
	R4746[13] = (char *(*)()) F370_5139;
	R4746[14] = (char *(*)()) F371_5141;
	R4746[17] = (char *(*)()) F374_5145;
	R4746[18] = (char *(*)()) F375_5149;
	R4746[20] = (char *(*)()) F377_5151;
	R4746[21] = (char *(*)()) F378_5153;
	R4746[22] = (char *(*)()) F379_5155;
	R4746[24] = (char *(*)()) F381_5161;
	R4746[25] = (char *(*)()) F382_5165;
	R4746[26] = (char *(*)()) F383_5169;
	R4746[27] = (char *(*)()) F384_5171;
	R4746[29] = (char *(*)()) F386_5173;
	R4746[30] = (char *(*)()) F387_5175;
	{long i; for (i = 31; i < 35; i++) R4746[i] = (char *(*)()) F388_5177;}
	R4746[36] = (char *(*)()) F393_5184;
	R4746[37] = (char *(*)()) F394_5186;
	R4746[38] = (char *(*)()) F395_5188;
	R4746[39] = (char *(*)()) F396_5190;
	R4746[40] = (char *(*)()) F397_5194;
	R4746[41] = (char *(*)()) F398_5196;
}

char *(*R4817[191])();
void R4817_init () {
	R4817[0] = (char *(*)()) F1192_10921;
	R4817[57] = (char *(*)()) F1249_11287;
	R4817[58] = (char *(*)()) F1250_11303;
	R4817[59] = (char *(*)()) F1251_11306;
	R4817[61] = (char *(*)()) F1253_11339;
	R4817[62] = (char *(*)()) F1254_11355;
	R4817[63] = (char *(*)()) F1255_11362;
	R4817[189] = (char *(*)()) F1381_13307;
	R4817[190] = (char *(*)()) F1382_13354;
}

char *(*R4818[1040])();
void R4818_init () {
	R4818[0] = (char *(*)()) F413_5361;
	{long i; for (i = 708; i < 710; i++) R4818[i] = (char *(*)()) F1120_9818;}
	{long i; for (i = 711; i < 713; i++) R4818[i] = (char *(*)()) F1123_9858;}
	{long i; for (i = 759; i < 761; i++) R4818[i] = (char *(*)()) F1171_10166;}
	{long i; for (i = 762; i < 765; i++) R4818[i] = (char *(*)()) F1174_10334;}
	R4818[774] = (char *(*)()) F1187_10660;
	R4818[781] = (char *(*)()) F1194_11023;
	{long i; for (i = 836; i < 839; i++) R4818[i] = (char *(*)()) F1246_11212;}
	{long i; for (i = 840; i < 843; i++) R4818[i] = (char *(*)()) F1246_11212;}
	R4818[896] = (char *(*)()) F1309_11586_4818_2;
	R4818[897] = (char *(*)()) F1310_11586_4818_2;
	R4818[899] = (char *(*)()) F1312_11685_4818_2;
	R4818[900] = (char *(*)()) F1313_11685_4818_2;
	R4818[902] = (char *(*)()) F1315_11784_4818_2;
	R4818[903] = (char *(*)()) F1316_11784_4818_2;
	R4818[905] = (char *(*)()) F1318_11883_4818_2;
	R4818[906] = (char *(*)()) F1319_11883_4818_2;
	R4818[908] = (char *(*)()) F1321_11978_4818_2;
	R4818[909] = (char *(*)()) F1322_11978_4818_2;
	R4818[911] = (char *(*)()) F1324_12072_4818_2;
	R4818[912] = (char *(*)()) F1325_12072_4818_2;
	R4818[914] = (char *(*)()) F1327_12167_4818_2;
	R4818[915] = (char *(*)()) F1328_12167_4818_2;
	R4818[917] = (char *(*)()) F1330_12262_4818_2;
	R4818[918] = (char *(*)()) F1331_12262_4818_2;
	R4818[920] = (char *(*)()) F1333_12331_4818_2;
	R4818[921] = (char *(*)()) F1334_12331_4818_2;
	R4818[923] = (char *(*)()) F1336_12397_4818_2;
	R4818[924] = (char *(*)()) F1337_12397_4818_2;
	R4818[941] = (char *(*)()) F1354_12639;
	R4818[1010] = (char *(*)()) F1423_14714;
	R4818[1012] = (char *(*)()) F1425_14756;
	R4818[1015] = (char *(*)()) F1428_14827;
	R4818[1039] = (char *(*)()) F1452_15306;
}
static EIF_BOOLEAN F1309_11586_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1309_11586(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1310_11586_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1310_11586(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1312_11685_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1312_11685(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1313_11685_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1313_11685(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1315_11784_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1315_11784(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1316_11784_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1316_11784(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1318_11883_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1318_11883(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1319_11883_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1319_11883(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1321_11978_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1321_11978(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1322_11978_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1322_11978(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1324_12072_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1324_12072(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1325_12072_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1325_12072(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1327_12167_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1327_12167(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1328_12167_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1328_12167(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1330_12262_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1330_12262(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1331_12262_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1331_12262(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1333_12331_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1333_12331(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1334_12331_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1334_12331(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1336_12397_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1336_12397(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1337_12397_4818_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1337_12397(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5213[7])();
void R5213_init () {
	{long i; for (i = 0; i < 6; i++) R5213[i] = (char *(*)()) F432_5687;}
	R5213[6] = (char *(*)()) F439_5708;
}

char *(*R5478[648])();
void R5478_init () {
	R5478[0] = (char *(*)()) F449_5988;
	R5478[647] = (char *(*)()) F1096_9255;
}

char *(*R5592[977])();
void R5592_init () {
	R5592[0] = (char *(*)()) F469_6100;
	R5592[513] = (char *(*)()) F463_6100;
	R5592[514] = (char *(*)()) F464_6100;
	R5592[515] = (char *(*)()) F465_6100;
	R5592[516] = (char *(*)()) F466_6100;
	R5592[517] = (char *(*)()) F467_6100;
	R5592[518] = (char *(*)()) F468_6100;
	R5592[519] = (char *(*)()) F469_6100;
	R5592[520] = (char *(*)()) F470_6100;
	R5592[521] = (char *(*)()) F471_6100;
	R5592[522] = (char *(*)()) F472_6100;
	R5592[523] = (char *(*)()) F473_6100;
	R5592[524] = (char *(*)()) F474_6100;
	R5592[583] = (char *(*)()) F463_6100;
	R5592[584] = (char *(*)()) F464_6100;
	R5592[585] = (char *(*)()) F465_6100;
	R5592[586] = (char *(*)()) F466_6100;
	R5592[587] = (char *(*)()) F467_6100;
	R5592[588] = (char *(*)()) F468_6100;
	R5592[589] = (char *(*)()) F469_6100;
	R5592[590] = (char *(*)()) F470_6100;
	R5592[591] = (char *(*)()) F471_6100;
	R5592[592] = (char *(*)()) F472_6100;
	R5592[593] = (char *(*)()) F473_6100;
	R5592[594] = (char *(*)()) F474_6100;
	{long i; for (i = 595; i < 598; i++) R5592[i] = (char *(*)()) F463_6100;}
	R5592[598] = (char *(*)()) F466_6100;
	R5592[599] = (char *(*)()) F463_6100;
	R5592[697] = (char *(*)()) F471_6100;
	{long i; for (i = 700; i < 702; i++) R5592[i] = (char *(*)()) F467_6100;}
	R5592[976] = (char *(*)()) F467_6100;
}


#ifdef __cplusplus
}
#endif
