#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7141[544])();
void R7141_init () {
	R7141[0] = (char *(*)()) F909_8153;
	R7141[79] = (char *(*)()) F988_8700;
	R7141[80] = (char *(*)()) F989_8742;
	R7141[81] = (char *(*)()) F990_8742;
	R7141[82] = (char *(*)()) F991_8742;
	R7141[83] = (char *(*)()) F992_8742;
	R7141[84] = (char *(*)()) F993_8742;
	R7141[85] = (char *(*)()) F994_8742;
	R7141[86] = (char *(*)()) F995_8742;
	R7141[87] = (char *(*)()) F996_8742;
	R7141[88] = (char *(*)()) F997_8742;
	R7141[89] = (char *(*)()) F998_8742;
	R7141[90] = (char *(*)()) F999_8742;
	R7141[91] = (char *(*)()) F1000_8742;
	R7141[150] = (char *(*)()) F1059_8930;
	R7141[151] = (char *(*)()) F1060_8930;
	R7141[152] = (char *(*)()) F1061_8930;
	R7141[153] = (char *(*)()) F1062_8930;
	R7141[154] = (char *(*)()) F1063_8930;
	R7141[155] = (char *(*)()) F1064_8930;
	R7141[156] = (char *(*)()) F1065_8930;
	R7141[157] = (char *(*)()) F1066_8930;
	R7141[158] = (char *(*)()) F1067_8930;
	R7141[159] = (char *(*)()) F1068_8930;
	R7141[160] = (char *(*)()) F1069_8930;
	R7141[161] = (char *(*)()) F1070_8930;
	{long i; for (i = 162; i < 165; i++) R7141[i] = (char *(*)()) F1059_8930;}
	R7141[165] = (char *(*)()) F1062_8930;
	R7141[166] = (char *(*)()) F1059_8930;
	R7141[264] = (char *(*)()) F1171_10157;
	{long i; for (i = 267; i < 269; i++) R7141[i] = (char *(*)()) F1174_10325;}
	R7141[543] = (char *(*)()) F1452_15297;
}

char *(*R7145[544])();
void R7145_init () {
	R7145[0] = (char *(*)()) F894_8135;
	R7145[79] = (char *(*)()) F897_8135;
	R7145[80] = (char *(*)()) F894_8135;
	R7145[81] = (char *(*)()) F895_8135;
	R7145[82] = (char *(*)()) F896_8135;
	R7145[83] = (char *(*)()) F897_8135;
	R7145[84] = (char *(*)()) F898_8135;
	R7145[85] = (char *(*)()) F899_8135;
	R7145[86] = (char *(*)()) F900_8135;
	R7145[87] = (char *(*)()) F901_8135;
	R7145[88] = (char *(*)()) F902_8135;
	R7145[89] = (char *(*)()) F903_8135;
	R7145[90] = (char *(*)()) F904_8135;
	R7145[91] = (char *(*)()) F905_8135;
	R7145[150] = (char *(*)()) F894_8135;
	R7145[151] = (char *(*)()) F895_8135;
	R7145[152] = (char *(*)()) F896_8135;
	R7145[153] = (char *(*)()) F897_8135;
	R7145[154] = (char *(*)()) F898_8135;
	R7145[155] = (char *(*)()) F899_8135;
	R7145[156] = (char *(*)()) F900_8135;
	R7145[157] = (char *(*)()) F901_8135;
	R7145[158] = (char *(*)()) F902_8135;
	R7145[159] = (char *(*)()) F903_8135;
	R7145[160] = (char *(*)()) F904_8135;
	R7145[161] = (char *(*)()) F905_8135;
	{long i; for (i = 162; i < 165; i++) R7145[i] = (char *(*)()) F894_8135;}
	R7145[165] = (char *(*)()) F897_8135;
	R7145[166] = (char *(*)()) F894_8135;
	R7145[264] = (char *(*)()) F902_8135;
	{long i; for (i = 267; i < 269; i++) R7145[i] = (char *(*)()) F898_8135;}
	R7145[543] = (char *(*)()) F898_8135;
}

char *(*R7147[544])();
void R7147_init () {
	R7147[0] = (char *(*)()) F909_8175;
	R7147[79] = (char *(*)()) F988_8711;
	R7147[80] = (char *(*)()) F989_8772;
	R7147[81] = (char *(*)()) F990_8772;
	R7147[82] = (char *(*)()) F991_8772;
	R7147[83] = (char *(*)()) F992_8772;
	R7147[84] = (char *(*)()) F993_8772;
	R7147[85] = (char *(*)()) F994_8772;
	R7147[86] = (char *(*)()) F995_8772;
	R7147[87] = (char *(*)()) F996_8772;
	R7147[88] = (char *(*)()) F997_8772;
	R7147[89] = (char *(*)()) F998_8772;
	R7147[90] = (char *(*)()) F999_8772;
	R7147[91] = (char *(*)()) F1000_8772;
	R7147[150] = (char *(*)()) F1059_8956;
	R7147[151] = (char *(*)()) F1060_8956;
	R7147[152] = (char *(*)()) F1061_8956;
	R7147[153] = (char *(*)()) F1062_8956;
	R7147[154] = (char *(*)()) F1063_8956;
	R7147[155] = (char *(*)()) F1064_8956;
	R7147[156] = (char *(*)()) F1065_8956;
	R7147[157] = (char *(*)()) F1066_8956;
	R7147[158] = (char *(*)()) F1067_8956;
	R7147[159] = (char *(*)()) F1068_8956;
	R7147[160] = (char *(*)()) F1069_8956;
	R7147[161] = (char *(*)()) F1070_8956;
	{long i; for (i = 162; i < 165; i++) R7147[i] = (char *(*)()) F1059_8956;}
	R7147[165] = (char *(*)()) F1062_8956;
	R7147[166] = (char *(*)()) F1059_8956;
	R7147[264] = (char *(*)()) F1173_10285;
	{long i; for (i = 267; i < 269; i++) R7147[i] = (char *(*)()) F1176_10450;}
	R7147[543] = (char *(*)()) F1176_10450;
}

char *(*R7161[419])();
void R7161_init () {
	{long i; for (i = 0; i < 2; i++) R7161[i] = (char *(*)()) F916_8186_7161_4;}
	R7161[117] = (char *(*)()) F912_8186;
	R7161[118] = (char *(*)()) F915_8186_7161_4;
	R7161[119] = (char *(*)()) F1056_8886;
	R7161[120] = (char *(*)()) F1057_8886_7161_4;
	R7161[121] = (char *(*)()) F912_8186;
	R7161[122] = (char *(*)()) F1059_8948;
	R7161[123] = (char *(*)()) F1060_8948_7161_4;
	R7161[124] = (char *(*)()) F1061_8948_7161_4;
	R7161[125] = (char *(*)()) F1062_8948_7161_4;
	R7161[126] = (char *(*)()) F1063_8948_7161_4;
	R7161[127] = (char *(*)()) F1064_8948_7161_4;
	R7161[128] = (char *(*)()) F1065_8948_7161_4;
	R7161[129] = (char *(*)()) F1066_8948_7161_4;
	R7161[130] = (char *(*)()) F1067_8948_7161_4;
	R7161[131] = (char *(*)()) F1068_8948_7161_4;
	R7161[132] = (char *(*)()) F1069_8948_7161_4;
	R7161[133] = (char *(*)()) F1070_8948_7161_4;
	{long i; for (i = 134; i < 137; i++) R7161[i] = (char *(*)()) F1059_8948;}
	R7161[137] = (char *(*)()) F1062_8948_7161_4;
	R7161[138] = (char *(*)()) F1059_8948;
	R7161[418] = (char *(*)()) F916_8186_7161_4;
}
static void F916_8186_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F916_8186(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F915_8186_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F915_8186(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1057_8886_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1057_8886(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1060_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1060_8948(Current, *(EIF_POINTER *)arg1);
}
static void F1061_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1061_8948(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1062_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8948(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1063_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1063_8948(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1064_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1064_8948(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1065_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1065_8948(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1066_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1066_8948(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1067_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1067_8948(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1068_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1068_8948(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1069_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1069_8948(Current, *(EIF_REAL_32 *)arg1);
}
static void F1070_8948_7161_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1070_8948(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7162[22])();
void R7162_init () {
	R7162[0] = (char *(*)()) F1006_8807;
	R7162[1] = (char *(*)()) F1009_8807;
	R7162[2] = (char *(*)()) F906_8142;
	R7162[3] = (char *(*)()) F907_8142;
	R7162[4] = (char *(*)()) F1006_8807;
	R7162[5] = (char *(*)()) F1059_8955;
	R7162[6] = (char *(*)()) F1060_8955;
	R7162[7] = (char *(*)()) F1061_8955;
	R7162[8] = (char *(*)()) F1062_8955;
	R7162[9] = (char *(*)()) F1063_8955;
	R7162[10] = (char *(*)()) F1064_8955;
	R7162[11] = (char *(*)()) F1065_8955;
	R7162[12] = (char *(*)()) F1066_8955;
	R7162[13] = (char *(*)()) F1067_8955;
	R7162[14] = (char *(*)()) F1068_8955;
	R7162[15] = (char *(*)()) F1069_8955;
	R7162[16] = (char *(*)()) F1070_8955;
	{long i; for (i = 17; i < 19; i++) R7162[i] = (char *(*)()) F1059_8955;}
	R7162[19] = (char *(*)()) F906_8142;
	R7162[20] = (char *(*)()) F907_8142;
	R7162[21] = (char *(*)()) F1059_8955;
}

char *(*R7164[419])();
void R7164_init () {
	R7164[0] = (char *(*)()) F937_8420;
	R7164[1] = (char *(*)()) F936_8192;
	R7164[418] = (char *(*)()) F937_8420;
}

char *(*R7189[419])();
void R7189_init () {
	{long i; for (i = 0; i < 2; i++) R7189[i] = (char *(*)()) F936_8226;}
	R7189[418] = (char *(*)()) F1355_12647;
}

char *(*R7258[419])();
void R7258_init () {
	R7258[0] = (char *(*)()) F936_8350;
	R7258[1] = (char *(*)()) F938_8531;
	R7258[418] = (char *(*)()) F936_8350;
}

char *(*R7259[419])();
void R7259_init () {
	{long i; for (i = 0; i < 2; i++) R7259[i] = (char *(*)()) F936_8351;}
	R7259[418] = (char *(*)()) F1355_12703;
}

char *(*R7274[419])();
void R7274_init () {
	R7274[0] = (char *(*)()) F936_8366;
	R7274[1] = (char *(*)()) F938_8532;
	R7274[418] = (char *(*)()) F936_8366;
}

char *(*R7331[419])();
void R7331_init () {
	R7331[0] = (char *(*)()) F937_8466;
	R7331[418] = (char *(*)()) F1355_12645;
}

char *(*R7337[419])();
void R7337_init () {
	R7337[0] = (char *(*)()) F937_8472;
	R7337[418] = (char *(*)()) F1355_12683;
}

char *(*R7341[419])();
void R7341_init () {
	R7341[0] = (char *(*)()) F937_8476;
	R7341[418] = (char *(*)()) F1355_12684;
}

char *(*R7374[492])();
void R7374_init () {
	R7374[0] = (char *(*)()) F961_8574;
	R7374[1] = (char *(*)()) F962_8574_7374_12;
	R7374[2] = (char *(*)()) F963_8574;
	R7374[3] = (char *(*)()) F964_8574_7374_12;
	R7374[4] = (char *(*)()) F965_8574;
	R7374[5] = (char *(*)()) F966_8574_7374_12;
	R7374[6] = (char *(*)()) F967_8574_7374_12;
	R7374[7] = (char *(*)()) F968_8574_7374_12;
	R7374[8] = (char *(*)()) F969_8574_7374_12;
	{long i; for (i = 9; i < 11; i++) R7374[i] = (char *(*)()) F961_8574;}
	R7374[11] = (char *(*)()) F964_8574_7374_12;
	R7374[12] = (char *(*)()) F968_8574_7374_12;
	R7374[13] = (char *(*)()) F966_8574_7374_12;
	R7374[14] = (char *(*)()) F969_8574_7374_12;
	R7374[27] = (char *(*)()) F988_8695_7374_12;
	R7374[28] = (char *(*)()) F989_8734;
	R7374[29] = (char *(*)()) F990_8734_7374_12;
	R7374[30] = (char *(*)()) F991_8734_7374_12;
	R7374[31] = (char *(*)()) F992_8734_7374_12;
	R7374[32] = (char *(*)()) F993_8734_7374_12;
	R7374[33] = (char *(*)()) F994_8734_7374_12;
	R7374[34] = (char *(*)()) F995_8734_7374_12;
	R7374[35] = (char *(*)()) F996_8734_7374_12;
	R7374[36] = (char *(*)()) F997_8734_7374_12;
	R7374[37] = (char *(*)()) F998_8734_7374_12;
	R7374[38] = (char *(*)()) F999_8734_7374_12;
	R7374[39] = (char *(*)()) F1000_8734_7374_12;
	R7374[93] = (char *(*)()) F1006_8792;
	R7374[94] = (char *(*)()) F1009_8792_7374_12;
	R7374[95] = (char *(*)()) F1006_8792;
	R7374[96] = (char *(*)()) F1009_8792_7374_12;
	R7374[97] = (char *(*)()) F1006_8792;
	R7374[98] = (char *(*)()) F1059_8914;
	R7374[99] = (char *(*)()) F1060_8914_7374_12;
	R7374[100] = (char *(*)()) F1061_8914_7374_12;
	R7374[101] = (char *(*)()) F1062_8914_7374_12;
	R7374[102] = (char *(*)()) F1063_8914_7374_12;
	R7374[103] = (char *(*)()) F1064_8914_7374_12;
	R7374[104] = (char *(*)()) F1065_8914_7374_12;
	R7374[105] = (char *(*)()) F1066_8914_7374_12;
	R7374[106] = (char *(*)()) F1067_8914_7374_12;
	R7374[107] = (char *(*)()) F1068_8914_7374_12;
	R7374[108] = (char *(*)()) F1069_8914_7374_12;
	R7374[109] = (char *(*)()) F1070_8914_7374_12;
	{long i; for (i = 110; i < 113; i++) R7374[i] = (char *(*)()) F1059_8914;}
	R7374[113] = (char *(*)()) F1062_8914_7374_12;
	R7374[114] = (char *(*)()) F1059_8914;
	R7374[153] = (char *(*)()) F1114_9609;
	R7374[211] = (char *(*)()) F1172_10196_7374_12;
	R7374[212] = (char *(*)()) F1173_10219_7374_12;
	R7374[214] = (char *(*)()) F1175_10361_7374_12;
	{long i; for (i = 215; i < 217; i++) R7374[i] = (char *(*)()) F1176_10383_7374_12;}
	R7374[270] = (char *(*)()) F1231_11100;
	R7374[271] = (char *(*)()) F1232_11100_7374_12;
	R7374[272] = (char *(*)()) F1233_11100_7374_12;
	R7374[273] = (char *(*)()) F1234_11100_7374_12;
	R7374[274] = (char *(*)()) F1235_11100_7374_12;
	R7374[275] = (char *(*)()) F1236_11100_7374_12;
	R7374[276] = (char *(*)()) F1237_11100_7374_12;
	R7374[277] = (char *(*)()) F1238_11100_7374_12;
	R7374[278] = (char *(*)()) F1239_11100_7374_12;
	R7374[279] = (char *(*)()) F1240_11100_7374_12;
	R7374[280] = (char *(*)()) F1241_11100_7374_12;
	R7374[281] = (char *(*)()) F1242_11100_7374_12;
	R7374[491] = (char *(*)()) F1452_15279_7374_12;
}
static EIF_REFERENCE F962_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F962_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F964_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F966_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F968_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F968_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F969_8574_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F969_8574(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8695_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F988_8695(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F990_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F990_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F991_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F991_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F992_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F992_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F993_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F993_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F994_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F994_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F995_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F995_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F996_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F996_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F997_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F997_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F998_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F998_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F999_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F999_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1000_8734_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1000_8734(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1009_8792_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1009_8792(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8914_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8914(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1172_10196_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1172_10196(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1173_10219_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1173_10219(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1175_10361_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1175_10361(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1176_10383_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1176_10383(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1232_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1232_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1233_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1233_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1234_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1234_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1235_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1235_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1236_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1236_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1237_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1237_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1238_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1238_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1239_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1239_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1240_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1240_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1241_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1241_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1242_11100_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1242_11100(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1452_15279_7374_12 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1452_15279(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R7375[492])();
void R7375_init () {
	R7375[0] = (char *(*)()) F961_8579;
	R7375[1] = (char *(*)()) F962_8579;
	R7375[2] = (char *(*)()) F963_8579;
	R7375[3] = (char *(*)()) F964_8579;
	R7375[4] = (char *(*)()) F965_8579;
	R7375[5] = (char *(*)()) F966_8579;
	R7375[6] = (char *(*)()) F967_8579;
	R7375[7] = (char *(*)()) F968_8579;
	R7375[8] = (char *(*)()) F969_8579;
	{long i; for (i = 9; i < 11; i++) R7375[i] = (char *(*)()) F961_8579;}
	R7375[11] = (char *(*)()) F964_8579;
	R7375[12] = (char *(*)()) F968_8579;
	R7375[13] = (char *(*)()) F966_8579;
	R7375[14] = (char *(*)()) F969_8579;
	R7375[27] = (char *(*)()) F988_8692;
	R7375[28] = (char *(*)()) F989_8739;
	R7375[29] = (char *(*)()) F990_8739;
	R7375[30] = (char *(*)()) F991_8739;
	R7375[31] = (char *(*)()) F992_8739;
	R7375[32] = (char *(*)()) F993_8739;
	R7375[33] = (char *(*)()) F994_8739;
	R7375[34] = (char *(*)()) F995_8739;
	R7375[35] = (char *(*)()) F996_8739;
	R7375[36] = (char *(*)()) F997_8739;
	R7375[37] = (char *(*)()) F998_8739;
	R7375[38] = (char *(*)()) F999_8739;
	R7375[39] = (char *(*)()) F1000_8739;
	R7375[93] = (char *(*)()) F1006_8795;
	R7375[94] = (char *(*)()) F1009_8795;
	R7375[95] = (char *(*)()) F1006_8795;
	R7375[96] = (char *(*)()) F1009_8795;
	{long i; for (i = 97; i < 99; i++) R7375[i] = (char *(*)()) F1006_8795;}
	R7375[99] = (char *(*)()) F1007_8795;
	R7375[100] = (char *(*)()) F1008_8795;
	R7375[101] = (char *(*)()) F1009_8795;
	R7375[102] = (char *(*)()) F1010_8795;
	R7375[103] = (char *(*)()) F1011_8795;
	R7375[104] = (char *(*)()) F1012_8795;
	R7375[105] = (char *(*)()) F1013_8795;
	R7375[106] = (char *(*)()) F1014_8795;
	R7375[107] = (char *(*)()) F1015_8795;
	R7375[108] = (char *(*)()) F1016_8795;
	R7375[109] = (char *(*)()) F1017_8795;
	{long i; for (i = 110; i < 113; i++) R7375[i] = (char *(*)()) F1006_8795;}
	R7375[113] = (char *(*)()) F1009_8795;
	R7375[114] = (char *(*)()) F1006_8795;
	R7375[153] = (char *(*)()) F1114_9639;
	{long i; for (i = 211; i < 213; i++) R7375[i] = (char *(*)()) F1171_10160;}
	{long i; for (i = 214; i < 217; i++) R7375[i] = (char *(*)()) F1174_10328;}
	R7375[270] = (char *(*)()) F1231_11108;
	R7375[271] = (char *(*)()) F1232_11108;
	R7375[272] = (char *(*)()) F1233_11108;
	R7375[273] = (char *(*)()) F1234_11108;
	R7375[274] = (char *(*)()) F1235_11108;
	R7375[275] = (char *(*)()) F1236_11108;
	R7375[276] = (char *(*)()) F1237_11108;
	R7375[277] = (char *(*)()) F1238_11108;
	R7375[278] = (char *(*)()) F1239_11108;
	R7375[279] = (char *(*)()) F1240_11108;
	R7375[280] = (char *(*)()) F1241_11108;
	R7375[281] = (char *(*)()) F1242_11108;
	R7375[491] = (char *(*)()) F1174_10328;
}

EIF_TYPE_INDEX *Y7375_gen_type [505];
EIF_TYPE_INDEX Y7375 [505];
void Y7375_init (void)
{
	egc_routines_types [7375] = Y7375;
	egc_routines_gen_types [7375] = Y7375_gen_type;
	egc_routines_offset [7375] = 948;
	{long i; for (i = 0; i < 127; i++) Y7375[i] = 1312;};
	Y7375[165] = 1312;
	{long i; for (i = 222; i < 230; i++) Y7375[i] = 1312;};
	{long i; for (i = 282; i < 294; i++) Y7375[i] = 1312;};
	{long i; for (i = 503; i < 505; i++) Y7375[i] = 1312;};
}

char *(*R7376[492])();
void R7376_init () {
	R7376[0] = (char *(*)()) F961_8580;
	R7376[1] = (char *(*)()) F962_8580;
	R7376[2] = (char *(*)()) F963_8580;
	R7376[3] = (char *(*)()) F964_8580;
	R7376[4] = (char *(*)()) F965_8580;
	R7376[5] = (char *(*)()) F966_8580;
	R7376[6] = (char *(*)()) F967_8580;
	R7376[7] = (char *(*)()) F968_8580;
	R7376[8] = (char *(*)()) F969_8580;
	{long i; for (i = 9; i < 11; i++) R7376[i] = (char *(*)()) F961_8580;}
	R7376[11] = (char *(*)()) F964_8580;
	R7376[12] = (char *(*)()) F968_8580;
	R7376[13] = (char *(*)()) F966_8580;
	R7376[14] = (char *(*)()) F969_8580;
	R7376[27] = (char *(*)()) F988_8694;
	R7376[28] = (char *(*)()) F989_8740;
	R7376[29] = (char *(*)()) F990_8740;
	R7376[30] = (char *(*)()) F991_8740;
	R7376[31] = (char *(*)()) F992_8740;
	R7376[32] = (char *(*)()) F993_8740;
	R7376[33] = (char *(*)()) F994_8740;
	R7376[34] = (char *(*)()) F995_8740;
	R7376[35] = (char *(*)()) F996_8740;
	R7376[36] = (char *(*)()) F997_8740;
	R7376[37] = (char *(*)()) F998_8740;
	R7376[38] = (char *(*)()) F999_8740;
	R7376[39] = (char *(*)()) F1000_8740;
	R7376[93] = (char *(*)()) F1054_8847;
	R7376[94] = (char *(*)()) F1055_8847;
	R7376[95] = (char *(*)()) F1054_8847;
	R7376[96] = (char *(*)()) F1055_8847;
	R7376[97] = (char *(*)()) F1054_8847;
	R7376[98] = (char *(*)()) F1059_8929;
	R7376[99] = (char *(*)()) F1060_8929;
	R7376[100] = (char *(*)()) F1061_8929;
	R7376[101] = (char *(*)()) F1062_8929;
	R7376[102] = (char *(*)()) F1063_8929;
	R7376[103] = (char *(*)()) F1064_8929;
	R7376[104] = (char *(*)()) F1065_8929;
	R7376[105] = (char *(*)()) F1066_8929;
	R7376[106] = (char *(*)()) F1067_8929;
	R7376[107] = (char *(*)()) F1068_8929;
	R7376[108] = (char *(*)()) F1069_8929;
	R7376[109] = (char *(*)()) F1070_8929;
	{long i; for (i = 110; i < 113; i++) R7376[i] = (char *(*)()) F1059_8929;}
	R7376[113] = (char *(*)()) F1062_8929;
	R7376[114] = (char *(*)()) F1059_8929;
	R7376[153] = (char *(*)()) F1114_9638;
	{long i; for (i = 211; i < 213; i++) R7376[i] = (char *(*)()) F1171_10158;}
	{long i; for (i = 214; i < 217; i++) R7376[i] = (char *(*)()) F1174_10326;}
	R7376[270] = (char *(*)()) F1231_11109;
	R7376[271] = (char *(*)()) F1232_11109;
	R7376[272] = (char *(*)()) F1233_11109;
	R7376[273] = (char *(*)()) F1234_11109;
	R7376[274] = (char *(*)()) F1235_11109;
	R7376[275] = (char *(*)()) F1236_11109;
	R7376[276] = (char *(*)()) F1237_11109;
	R7376[277] = (char *(*)()) F1238_11109;
	R7376[278] = (char *(*)()) F1239_11109;
	R7376[279] = (char *(*)()) F1240_11109;
	R7376[280] = (char *(*)()) F1241_11109;
	R7376[281] = (char *(*)()) F1242_11109;
	R7376[491] = (char *(*)()) F1452_15295;
}

char *(*R7378[492])();
void R7378_init () {
	R7378[0] = (char *(*)()) F961_8596;
	R7378[1] = (char *(*)()) F962_8596;
	R7378[2] = (char *(*)()) F963_8596;
	R7378[3] = (char *(*)()) F964_8596;
	R7378[4] = (char *(*)()) F965_8596;
	R7378[5] = (char *(*)()) F966_8596;
	R7378[6] = (char *(*)()) F967_8596;
	R7378[7] = (char *(*)()) F968_8596;
	R7378[8] = (char *(*)()) F969_8596;
	{long i; for (i = 9; i < 11; i++) R7378[i] = (char *(*)()) F961_8596;}
	R7378[11] = (char *(*)()) F964_8596;
	R7378[12] = (char *(*)()) F968_8596;
	R7378[13] = (char *(*)()) F966_8596;
	R7378[14] = (char *(*)()) F969_8596;
	R7378[27] = (char *(*)()) F988_8698;
	R7378[28] = (char *(*)()) F989_8749;
	R7378[29] = (char *(*)()) F990_8749;
	R7378[30] = (char *(*)()) F991_8749;
	R7378[31] = (char *(*)()) F992_8749;
	R7378[32] = (char *(*)()) F993_8749;
	R7378[33] = (char *(*)()) F994_8749;
	R7378[34] = (char *(*)()) F995_8749;
	R7378[35] = (char *(*)()) F996_8749;
	R7378[36] = (char *(*)()) F997_8749;
	R7378[37] = (char *(*)()) F998_8749;
	R7378[38] = (char *(*)()) F999_8749;
	R7378[39] = (char *(*)()) F1000_8749;
	R7378[93] = (char *(*)()) F1006_8800;
	R7378[94] = (char *(*)()) F1009_8800;
	R7378[95] = (char *(*)()) F1006_8800;
	R7378[96] = (char *(*)()) F1009_8800;
	R7378[97] = (char *(*)()) F1006_8800;
	R7378[98] = (char *(*)()) F1059_8935;
	R7378[99] = (char *(*)()) F1060_8935;
	R7378[100] = (char *(*)()) F1061_8935;
	R7378[101] = (char *(*)()) F1062_8935;
	R7378[102] = (char *(*)()) F1063_8935;
	R7378[103] = (char *(*)()) F1064_8935;
	R7378[104] = (char *(*)()) F1065_8935;
	R7378[105] = (char *(*)()) F1066_8935;
	R7378[106] = (char *(*)()) F1067_8935;
	R7378[107] = (char *(*)()) F1068_8935;
	R7378[108] = (char *(*)()) F1069_8935;
	R7378[109] = (char *(*)()) F1070_8935;
	{long i; for (i = 110; i < 113; i++) R7378[i] = (char *(*)()) F1059_8935;}
	R7378[113] = (char *(*)()) F1062_8935;
	R7378[114] = (char *(*)()) F1059_8935;
	R7378[153] = (char *(*)()) F1114_9636;
	{long i; for (i = 211; i < 213; i++) R7378[i] = (char *(*)()) F1168_10019;}
	{long i; for (i = 214; i < 217; i++) R7378[i] = (char *(*)()) F1168_10019;}
	R7378[270] = (char *(*)()) F1231_11114;
	R7378[271] = (char *(*)()) F1232_11114;
	R7378[272] = (char *(*)()) F1233_11114;
	R7378[273] = (char *(*)()) F1234_11114;
	R7378[274] = (char *(*)()) F1235_11114;
	R7378[275] = (char *(*)()) F1236_11114;
	R7378[276] = (char *(*)()) F1237_11114;
	R7378[277] = (char *(*)()) F1238_11114;
	R7378[278] = (char *(*)()) F1239_11114;
	R7378[279] = (char *(*)()) F1240_11114;
	R7378[280] = (char *(*)()) F1241_11114;
	R7378[281] = (char *(*)()) F1242_11114;
	R7378[491] = (char *(*)()) F1168_10019;
}

char *(*R7379[15])();
void R7379_init () {
	R7379[0] = (char *(*)()) F961_8558;
	R7379[1] = (char *(*)()) F962_8558;
	R7379[2] = (char *(*)()) F963_8558;
	R7379[3] = (char *(*)()) F964_8558;
	R7379[4] = (char *(*)()) F965_8558;
	R7379[5] = (char *(*)()) F966_8558;
	R7379[6] = (char *(*)()) F967_8558;
	R7379[7] = (char *(*)()) F968_8558;
	R7379[8] = (char *(*)()) F969_8558;
	{long i; for (i = 9; i < 11; i++) R7379[i] = (char *(*)()) F961_8558;}
	R7379[11] = (char *(*)()) F964_8558;
	R7379[12] = (char *(*)()) F968_8558;
	R7379[13] = (char *(*)()) F966_8558;
	R7379[14] = (char *(*)()) F969_8558;
}

char *(*R7380[15])();
void R7380_init () {
	R7380[0] = (char *(*)()) F961_8559;
	R7380[1] = (char *(*)()) F962_8559;
	R7380[2] = (char *(*)()) F963_8559;
	R7380[3] = (char *(*)()) F964_8559;
	R7380[4] = (char *(*)()) F965_8559;
	R7380[5] = (char *(*)()) F966_8559;
	R7380[6] = (char *(*)()) F967_8559;
	R7380[7] = (char *(*)()) F968_8559;
	R7380[8] = (char *(*)()) F969_8559;
	{long i; for (i = 9; i < 11; i++) R7380[i] = (char *(*)()) F961_8559;}
	R7380[11] = (char *(*)()) F964_8559;
	R7380[12] = (char *(*)()) F968_8559;
	R7380[13] = (char *(*)()) F966_8559;
	R7380[14] = (char *(*)()) F969_8559;
}

char *(*R7382[15])();
void R7382_init () {
	R7382[0] = (char *(*)()) F961_8561;
	R7382[1] = (char *(*)()) F962_8561;
	R7382[2] = (char *(*)()) F963_8561;
	R7382[3] = (char *(*)()) F964_8561;
	R7382[4] = (char *(*)()) F965_8561;
	R7382[5] = (char *(*)()) F966_8561;
	R7382[6] = (char *(*)()) F967_8561;
	R7382[7] = (char *(*)()) F968_8561;
	R7382[8] = (char *(*)()) F969_8561;
	{long i; for (i = 9; i < 11; i++) R7382[i] = (char *(*)()) F961_8561;}
	R7382[11] = (char *(*)()) F964_8561;
	R7382[12] = (char *(*)()) F968_8561;
	R7382[13] = (char *(*)()) F966_8561;
	R7382[14] = (char *(*)()) F969_8561;
}

char *(*R7383[15])();
void R7383_init () {
	R7383[0] = (char *(*)()) F961_8562;
	R7383[1] = (char *(*)()) F962_8562_7383_1;
	R7383[2] = (char *(*)()) F963_8562;
	R7383[3] = (char *(*)()) F964_8562_7383_1;
	R7383[4] = (char *(*)()) F965_8562;
	R7383[5] = (char *(*)()) F966_8562_7383_1;
	R7383[6] = (char *(*)()) F967_8562_7383_1;
	R7383[7] = (char *(*)()) F968_8562_7383_1;
	R7383[8] = (char *(*)()) F969_8562_7383_1;
	{long i; for (i = 9; i < 11; i++) R7383[i] = (char *(*)()) F961_8562;}
	R7383[11] = (char *(*)()) F964_8562_7383_1;
	R7383[12] = (char *(*)()) F968_8562_7383_1;
	R7383[13] = (char *(*)()) F966_8562_7383_1;
	R7383[14] = (char *(*)()) F969_8562_7383_1;
}
static EIF_REFERENCE F962_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F962_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F964_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F966_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F968_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F968_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F969_8562_7383_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F969_8562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7384_pgtype0[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype1[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype2[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype3[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype4[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype5[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype6[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype7[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype8[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype9[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype10[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype11[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype12[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7384_pgtype13[] = {0xFF02,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7384_gen_type [15];
EIF_TYPE_INDEX Y7384 [15];
void Y7384_init (void)
{
	egc_routines_types [7384] = Y7384;
	egc_routines_gen_types [7384] = Y7384_gen_type;
	egc_routines_offset [7384] = 960;
	Y7384_gen_type [0] = Y7384_pgtype0;
	Y7384_gen_type [1] = Y7384_pgtype1;
	Y7384_gen_type [2] = Y7384_pgtype2;
	Y7384_gen_type [3] = Y7384_pgtype3;
	Y7384_gen_type [4] = Y7384_pgtype4;
	Y7384_gen_type [5] = Y7384_pgtype5;
	Y7384_gen_type [6] = Y7384_pgtype6;
	Y7384_gen_type [7] = Y7384_pgtype7;
	Y7384_gen_type [8] = Y7384_pgtype8;
	Y7384_gen_type [10] = Y7384_pgtype9;
	Y7384_gen_type [11] = Y7384_pgtype10;
	Y7384_gen_type [12] = Y7384_pgtype11;
	Y7384_gen_type [13] = Y7384_pgtype12;
	Y7384_gen_type [14] = Y7384_pgtype13;
	Y7384[9] = 0;
}

char *(*R7388[15])();
void R7388_init () {
	R7388[0] = (char *(*)()) F961_8570;
	R7388[1] = (char *(*)()) F962_8570_7388_1;
	R7388[2] = (char *(*)()) F963_8570;
	R7388[3] = (char *(*)()) F964_8570_7388_1;
	R7388[4] = (char *(*)()) F965_8570;
	R7388[5] = (char *(*)()) F966_8570_7388_1;
	R7388[6] = (char *(*)()) F967_8570_7388_1;
	R7388[7] = (char *(*)()) F968_8570_7388_1;
	R7388[8] = (char *(*)()) F969_8570_7388_1;
	{long i; for (i = 9; i < 11; i++) R7388[i] = (char *(*)()) F961_8570;}
	R7388[11] = (char *(*)()) F964_8570_7388_1;
	R7388[12] = (char *(*)()) F968_8570_7388_1;
	R7388[13] = (char *(*)()) F966_8570_7388_1;
	R7388[14] = (char *(*)()) F969_8570_7388_1;
}
static EIF_REFERENCE F962_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F962_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F964_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F966_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F968_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F968_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F969_8570_7388_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F969_8570(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7388_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7388_pgtype13[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7388_gen_type [15];
EIF_TYPE_INDEX Y7388 [15];
void Y7388_init (void)
{
	egc_routines_types [7388] = Y7388;
	egc_routines_gen_types [7388] = Y7388_gen_type;
	egc_routines_offset [7388] = 960;
	Y7388_gen_type [0] = Y7388_pgtype0;
	Y7388_gen_type [1] = Y7388_pgtype1;
	Y7388_gen_type [2] = Y7388_pgtype2;
	Y7388_gen_type [3] = Y7388_pgtype3;
	Y7388_gen_type [4] = Y7388_pgtype4;
	Y7388_gen_type [5] = Y7388_pgtype5;
	Y7388_gen_type [6] = Y7388_pgtype6;
	Y7388_gen_type [7] = Y7388_pgtype7;
	Y7388_gen_type [8] = Y7388_pgtype8;
	Y7388_gen_type [10] = Y7388_pgtype9;
	Y7388_gen_type [11] = Y7388_pgtype10;
	Y7388_gen_type [12] = Y7388_pgtype11;
	Y7388_gen_type [13] = Y7388_pgtype12;
	Y7388_gen_type [14] = Y7388_pgtype13;
	Y7388[9] = 0;
}

char *(*R7389[15])();
void R7389_init () {
	R7389[0] = (char *(*)()) F961_8571;
	R7389[1] = (char *(*)()) F962_8571;
	R7389[2] = (char *(*)()) F963_8571_7389_1;
	R7389[3] = (char *(*)()) F964_8571;
	R7389[4] = (char *(*)()) F965_8571_7389_1;
	R7389[5] = (char *(*)()) F966_8571;
	R7389[6] = (char *(*)()) F967_8571_7389_1;
	R7389[7] = (char *(*)()) F968_8571;
	R7389[8] = (char *(*)()) F969_8571;
	{long i; for (i = 9; i < 11; i++) R7389[i] = (char *(*)()) F961_8571;}
	R7389[11] = (char *(*)()) F964_8571;
	R7389[12] = (char *(*)()) F968_8571;
	R7389[13] = (char *(*)()) F966_8571;
	R7389[14] = (char *(*)()) F969_8571;
}
static EIF_REFERENCE F963_8571_7389_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F963_8571(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_8571_7389_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F965_8571(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8571_7389_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8571(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7391[15])();
void R7391_init () {
	R7391[0] = (char *(*)()) F961_8575;
	R7391[1] = (char *(*)()) F962_8575;
	R7391[2] = (char *(*)()) F963_8575_7391_42;
	R7391[3] = (char *(*)()) F964_8575;
	R7391[4] = (char *(*)()) F965_8575_7391_42;
	R7391[5] = (char *(*)()) F966_8575;
	R7391[6] = (char *(*)()) F967_8575_7391_42;
	R7391[7] = (char *(*)()) F968_8575;
	R7391[8] = (char *(*)()) F969_8575;
	R7391[9] = (char *(*)()) F961_8575;
	R7391[10] = (char *(*)()) F971_8684;
	R7391[11] = (char *(*)()) F972_8684;
	R7391[12] = (char *(*)()) F973_8684;
	R7391[13] = (char *(*)()) F974_8684;
	R7391[14] = (char *(*)()) F975_8684;
}
static EIF_INTEGER_32 F963_8575_7391_42 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F963_8575(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F965_8575_7391_42 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F965_8575(Current, *(EIF_POINTER *)arg1);
}
static EIF_INTEGER_32 F967_8575_7391_42 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F967_8575(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7393[15])();
void R7393_init () {
	R7393[0] = (char *(*)()) F961_8582;
	R7393[1] = (char *(*)()) F962_8582;
	R7393[2] = (char *(*)()) F963_8582_7393_3;
	R7393[3] = (char *(*)()) F964_8582;
	R7393[4] = (char *(*)()) F965_8582_7393_3;
	R7393[5] = (char *(*)()) F966_8582;
	R7393[6] = (char *(*)()) F967_8582_7393_3;
	R7393[7] = (char *(*)()) F968_8582;
	R7393[8] = (char *(*)()) F969_8582;
	R7393[9] = (char *(*)()) F961_8582;
	R7393[10] = (char *(*)()) F971_8686;
	R7393[11] = (char *(*)()) F972_8686;
	R7393[12] = (char *(*)()) F973_8686;
	R7393[13] = (char *(*)()) F974_8686;
	R7393[14] = (char *(*)()) F975_8686;
}
static EIF_BOOLEAN F963_8582_7393_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F963_8582(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F965_8582_7393_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F965_8582(Current, *(EIF_POINTER *)arg1, *(EIF_POINTER *)arg2);
}
static EIF_BOOLEAN F967_8582_7393_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F967_8582(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R7399[15])();
void R7399_init () {
	R7399[0] = (char *(*)()) F961_8590;
	R7399[1] = (char *(*)()) F962_8590;
	R7399[2] = (char *(*)()) F963_8590;
	R7399[3] = (char *(*)()) F964_8590;
	R7399[4] = (char *(*)()) F965_8590;
	R7399[5] = (char *(*)()) F966_8590;
	R7399[6] = (char *(*)()) F967_8590;
	R7399[7] = (char *(*)()) F968_8590;
	R7399[8] = (char *(*)()) F969_8590;
	{long i; for (i = 9; i < 11; i++) R7399[i] = (char *(*)()) F961_8590;}
	R7399[11] = (char *(*)()) F964_8590;
	R7399[12] = (char *(*)()) F968_8590;
	R7399[13] = (char *(*)()) F966_8590;
	R7399[14] = (char *(*)()) F969_8590;
}

char *(*R7400[15])();
void R7400_init () {
	R7400[0] = (char *(*)()) F961_8591;
	R7400[1] = (char *(*)()) F962_8591;
	R7400[2] = (char *(*)()) F963_8591;
	R7400[3] = (char *(*)()) F964_8591;
	R7400[4] = (char *(*)()) F965_8591;
	R7400[5] = (char *(*)()) F966_8591;
	R7400[6] = (char *(*)()) F967_8591;
	R7400[7] = (char *(*)()) F968_8591;
	R7400[8] = (char *(*)()) F969_8591;
	{long i; for (i = 9; i < 11; i++) R7400[i] = (char *(*)()) F961_8591;}
	R7400[11] = (char *(*)()) F964_8591;
	R7400[12] = (char *(*)()) F968_8591;
	R7400[13] = (char *(*)()) F966_8591;
	R7400[14] = (char *(*)()) F969_8591;
}

char *(*R7402[15])();
void R7402_init () {
	R7402[0] = (char *(*)()) F961_8593;
	R7402[1] = (char *(*)()) F962_8593;
	R7402[2] = (char *(*)()) F963_8593;
	R7402[3] = (char *(*)()) F964_8593;
	R7402[4] = (char *(*)()) F965_8593;
	R7402[5] = (char *(*)()) F966_8593;
	R7402[6] = (char *(*)()) F967_8593;
	R7402[7] = (char *(*)()) F968_8593;
	R7402[8] = (char *(*)()) F969_8593;
	{long i; for (i = 9; i < 11; i++) R7402[i] = (char *(*)()) F961_8593;}
	R7402[11] = (char *(*)()) F964_8593;
	R7402[12] = (char *(*)()) F968_8593;
	R7402[13] = (char *(*)()) F966_8593;
	R7402[14] = (char *(*)()) F969_8593;
}

char *(*R7405[15])();
void R7405_init () {
	R7405[0] = (char *(*)()) F961_8597;
	R7405[1] = (char *(*)()) F962_8597;
	R7405[2] = (char *(*)()) F963_8597;
	R7405[3] = (char *(*)()) F964_8597;
	R7405[4] = (char *(*)()) F965_8597;
	R7405[5] = (char *(*)()) F966_8597;
	R7405[6] = (char *(*)()) F967_8597;
	R7405[7] = (char *(*)()) F968_8597;
	R7405[8] = (char *(*)()) F969_8597;
	{long i; for (i = 9; i < 11; i++) R7405[i] = (char *(*)()) F961_8597;}
	R7405[11] = (char *(*)()) F964_8597;
	R7405[12] = (char *(*)()) F968_8597;
	R7405[13] = (char *(*)()) F966_8597;
	R7405[14] = (char *(*)()) F969_8597;
}

char *(*R7406[15])();
void R7406_init () {
	R7406[0] = (char *(*)()) F961_8598;
	R7406[1] = (char *(*)()) F962_8598;
	R7406[2] = (char *(*)()) F963_8598;
	R7406[3] = (char *(*)()) F964_8598;
	R7406[4] = (char *(*)()) F965_8598;
	R7406[5] = (char *(*)()) F966_8598;
	R7406[6] = (char *(*)()) F967_8598;
	R7406[7] = (char *(*)()) F968_8598;
	R7406[8] = (char *(*)()) F969_8598;
	{long i; for (i = 9; i < 11; i++) R7406[i] = (char *(*)()) F961_8598;}
	R7406[11] = (char *(*)()) F964_8598;
	R7406[12] = (char *(*)()) F968_8598;
	R7406[13] = (char *(*)()) F966_8598;
	R7406[14] = (char *(*)()) F969_8598;
}

char *(*R7408[15])();
void R7408_init () {
	R7408[0] = (char *(*)()) F961_8600;
	R7408[1] = (char *(*)()) F962_8600;
	R7408[2] = (char *(*)()) F963_8600_7408_4;
	R7408[3] = (char *(*)()) F964_8600;
	R7408[4] = (char *(*)()) F965_8600_7408_4;
	R7408[5] = (char *(*)()) F966_8600;
	R7408[6] = (char *(*)()) F967_8600_7408_4;
	R7408[7] = (char *(*)()) F968_8600;
	R7408[8] = (char *(*)()) F969_8600;
	{long i; for (i = 9; i < 11; i++) R7408[i] = (char *(*)()) F961_8600;}
	R7408[11] = (char *(*)()) F964_8600;
	R7408[12] = (char *(*)()) F968_8600;
	R7408[13] = (char *(*)()) F966_8600;
	R7408[14] = (char *(*)()) F969_8600;
}
static void F963_8600_7408_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F963_8600(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F965_8600_7408_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F965_8600(Current, *(EIF_POINTER *)arg1);
}
static void F967_8600_7408_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F967_8600(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7410[15])();
void R7410_init () {
	R7410[0] = (char *(*)()) F961_8602;
	R7410[1] = (char *(*)()) F962_8602;
	R7410[2] = (char *(*)()) F963_8602;
	R7410[3] = (char *(*)()) F964_8602;
	R7410[4] = (char *(*)()) F965_8602;
	R7410[5] = (char *(*)()) F966_8602;
	R7410[6] = (char *(*)()) F967_8602;
	R7410[7] = (char *(*)()) F968_8602;
	R7410[8] = (char *(*)()) F969_8602;
	{long i; for (i = 9; i < 11; i++) R7410[i] = (char *(*)()) F961_8602;}
	R7410[11] = (char *(*)()) F964_8602;
	R7410[12] = (char *(*)()) F968_8602;
	R7410[13] = (char *(*)()) F966_8602;
	R7410[14] = (char *(*)()) F969_8602;
}

char *(*R7411[15])();
void R7411_init () {
	R7411[0] = (char *(*)()) F961_8603;
	R7411[1] = (char *(*)()) F962_8603;
	R7411[2] = (char *(*)()) F963_8603;
	R7411[3] = (char *(*)()) F964_8603;
	R7411[4] = (char *(*)()) F965_8603;
	R7411[5] = (char *(*)()) F966_8603;
	R7411[6] = (char *(*)()) F967_8603;
	R7411[7] = (char *(*)()) F968_8603;
	R7411[8] = (char *(*)()) F969_8603;
	{long i; for (i = 9; i < 11; i++) R7411[i] = (char *(*)()) F961_8603;}
	R7411[11] = (char *(*)()) F964_8603;
	R7411[12] = (char *(*)()) F968_8603;
	R7411[13] = (char *(*)()) F966_8603;
	R7411[14] = (char *(*)()) F969_8603;
}

char *(*R7417[15])();
void R7417_init () {
	R7417[0] = (char *(*)()) F961_8616;
	R7417[1] = (char *(*)()) F962_8616;
	R7417[2] = (char *(*)()) F963_8616;
	R7417[3] = (char *(*)()) F964_8616;
	R7417[4] = (char *(*)()) F965_8616;
	R7417[5] = (char *(*)()) F966_8616;
	R7417[6] = (char *(*)()) F967_8616;
	R7417[7] = (char *(*)()) F968_8616;
	R7417[8] = (char *(*)()) F969_8616;
	R7417[9] = (char *(*)()) F961_8616;
	R7417[10] = (char *(*)()) F971_8688;
	R7417[11] = (char *(*)()) F972_8688;
	R7417[12] = (char *(*)()) F973_8688;
	R7417[13] = (char *(*)()) F974_8688;
	R7417[14] = (char *(*)()) F975_8688;
}

char *(*R7426[15])();
void R7426_init () {
	R7426[0] = (char *(*)()) F961_8626;
	R7426[1] = (char *(*)()) F962_8626;
	R7426[2] = (char *(*)()) F963_8626;
	R7426[3] = (char *(*)()) F964_8626;
	R7426[4] = (char *(*)()) F965_8626;
	R7426[5] = (char *(*)()) F966_8626;
	R7426[6] = (char *(*)()) F967_8626;
	R7426[7] = (char *(*)()) F968_8626;
	R7426[8] = (char *(*)()) F969_8626;
	{long i; for (i = 9; i < 11; i++) R7426[i] = (char *(*)()) F961_8626;}
	R7426[11] = (char *(*)()) F964_8626;
	R7426[12] = (char *(*)()) F968_8626;
	R7426[13] = (char *(*)()) F966_8626;
	R7426[14] = (char *(*)()) F969_8626;
}

char *(*R7427[15])();
void R7427_init () {
	R7427[0] = (char *(*)()) F961_8627;
	R7427[1] = (char *(*)()) F962_8627;
	R7427[2] = (char *(*)()) F963_8627;
	R7427[3] = (char *(*)()) F964_8627;
	R7427[4] = (char *(*)()) F965_8627;
	R7427[5] = (char *(*)()) F966_8627;
	R7427[6] = (char *(*)()) F967_8627;
	R7427[7] = (char *(*)()) F968_8627;
	R7427[8] = (char *(*)()) F969_8627;
	{long i; for (i = 9; i < 11; i++) R7427[i] = (char *(*)()) F961_8627;}
	R7427[11] = (char *(*)()) F964_8627;
	R7427[12] = (char *(*)()) F968_8627;
	R7427[13] = (char *(*)()) F966_8627;
	R7427[14] = (char *(*)()) F969_8627;
}

char *(*R7434[15])();
void R7434_init () {
	R7434[0] = (char *(*)()) F961_8634;
	R7434[1] = (char *(*)()) F962_8634_7434_1;
	R7434[2] = (char *(*)()) F963_8634;
	R7434[3] = (char *(*)()) F964_8634_7434_1;
	R7434[4] = (char *(*)()) F965_8634;
	R7434[5] = (char *(*)()) F966_8634_7434_1;
	R7434[6] = (char *(*)()) F967_8634_7434_1;
	R7434[7] = (char *(*)()) F968_8634_7434_1;
	R7434[8] = (char *(*)()) F969_8634_7434_1;
	{long i; for (i = 9; i < 11; i++) R7434[i] = (char *(*)()) F961_8634;}
	R7434[11] = (char *(*)()) F964_8634_7434_1;
	R7434[12] = (char *(*)()) F968_8634_7434_1;
	R7434[13] = (char *(*)()) F966_8634_7434_1;
	R7434[14] = (char *(*)()) F969_8634_7434_1;
}
static EIF_REFERENCE F962_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F962_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F964_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F966_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F968_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F968_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F969_8634_7434_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F969_8634(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R7435[15])();
void R7435_init () {
	R7435[0] = (char *(*)()) F961_8635;
	R7435[1] = (char *(*)()) F962_8635;
	R7435[2] = (char *(*)()) F963_8635_7435_1;
	R7435[3] = (char *(*)()) F964_8635;
	R7435[4] = (char *(*)()) F965_8635_7435_1;
	R7435[5] = (char *(*)()) F966_8635;
	R7435[6] = (char *(*)()) F967_8635_7435_1;
	R7435[7] = (char *(*)()) F968_8635;
	R7435[8] = (char *(*)()) F969_8635;
	{long i; for (i = 9; i < 11; i++) R7435[i] = (char *(*)()) F961_8635;}
	R7435[11] = (char *(*)()) F964_8635;
	R7435[12] = (char *(*)()) F968_8635;
	R7435[13] = (char *(*)()) F966_8635;
	R7435[14] = (char *(*)()) F969_8635;
}
static EIF_REFERENCE F963_8635_7435_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F963_8635(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_8635_7435_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F965_8635(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_8635_7435_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F967_8635(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7436[15])();
void R7436_init () {
	R7436[0] = (char *(*)()) F961_8636;
	R7436[1] = (char *(*)()) F962_8636;
	R7436[2] = (char *(*)()) F963_8636;
	R7436[3] = (char *(*)()) F964_8636;
	R7436[4] = (char *(*)()) F965_8636;
	R7436[5] = (char *(*)()) F966_8636;
	R7436[6] = (char *(*)()) F967_8636;
	R7436[7] = (char *(*)()) F968_8636;
	R7436[8] = (char *(*)()) F969_8636;
	{long i; for (i = 9; i < 11; i++) R7436[i] = (char *(*)()) F961_8636;}
	R7436[11] = (char *(*)()) F964_8636;
	R7436[12] = (char *(*)()) F968_8636;
	R7436[13] = (char *(*)()) F966_8636;
	R7436[14] = (char *(*)()) F969_8636;
}

char *(*R7437[15])();
void R7437_init () {
	R7437[0] = (char *(*)()) F961_8637;
	R7437[1] = (char *(*)()) F962_8637;
	R7437[2] = (char *(*)()) F963_8637;
	R7437[3] = (char *(*)()) F964_8637;
	R7437[4] = (char *(*)()) F965_8637;
	R7437[5] = (char *(*)()) F966_8637;
	R7437[6] = (char *(*)()) F967_8637;
	R7437[7] = (char *(*)()) F968_8637;
	R7437[8] = (char *(*)()) F969_8637;
	{long i; for (i = 9; i < 11; i++) R7437[i] = (char *(*)()) F961_8637;}
	R7437[11] = (char *(*)()) F964_8637;
	R7437[12] = (char *(*)()) F968_8637;
	R7437[13] = (char *(*)()) F966_8637;
	R7437[14] = (char *(*)()) F969_8637;
}

char *(*R7438[15])();
void R7438_init () {
	R7438[0] = (char *(*)()) F961_8638;
	R7438[1] = (char *(*)()) F962_8638;
	R7438[2] = (char *(*)()) F963_8638;
	R7438[3] = (char *(*)()) F964_8638;
	R7438[4] = (char *(*)()) F965_8638;
	R7438[5] = (char *(*)()) F966_8638;
	R7438[6] = (char *(*)()) F967_8638;
	R7438[7] = (char *(*)()) F968_8638;
	R7438[8] = (char *(*)()) F969_8638;
	{long i; for (i = 9; i < 11; i++) R7438[i] = (char *(*)()) F961_8638;}
	R7438[11] = (char *(*)()) F964_8638;
	R7438[12] = (char *(*)()) F968_8638;
	R7438[13] = (char *(*)()) F966_8638;
	R7438[14] = (char *(*)()) F969_8638;
}

char *(*R7439[15])();
void R7439_init () {
	R7439[0] = (char *(*)()) F961_8639;
	R7439[1] = (char *(*)()) F962_8639;
	R7439[2] = (char *(*)()) F963_8639;
	R7439[3] = (char *(*)()) F964_8639;
	R7439[4] = (char *(*)()) F965_8639;
	R7439[5] = (char *(*)()) F966_8639;
	R7439[6] = (char *(*)()) F967_8639;
	R7439[7] = (char *(*)()) F968_8639;
	R7439[8] = (char *(*)()) F969_8639;
	{long i; for (i = 9; i < 11; i++) R7439[i] = (char *(*)()) F961_8639;}
	R7439[11] = (char *(*)()) F964_8639;
	R7439[12] = (char *(*)()) F968_8639;
	R7439[13] = (char *(*)()) F966_8639;
	R7439[14] = (char *(*)()) F969_8639;
}

char *(*R7440[15])();
void R7440_init () {
	R7440[0] = (char *(*)()) F961_8640;
	R7440[1] = (char *(*)()) F962_8640;
	R7440[2] = (char *(*)()) F963_8640;
	R7440[3] = (char *(*)()) F964_8640;
	R7440[4] = (char *(*)()) F965_8640;
	R7440[5] = (char *(*)()) F966_8640;
	R7440[6] = (char *(*)()) F967_8640;
	R7440[7] = (char *(*)()) F968_8640;
	R7440[8] = (char *(*)()) F969_8640;
	{long i; for (i = 9; i < 11; i++) R7440[i] = (char *(*)()) F961_8640;}
	R7440[11] = (char *(*)()) F964_8640;
	R7440[12] = (char *(*)()) F968_8640;
	R7440[13] = (char *(*)()) F966_8640;
	R7440[14] = (char *(*)()) F969_8640;
}

char *(*R7442[15])();
void R7442_init () {
	R7442[0] = (char *(*)()) F961_8642;
	R7442[1] = (char *(*)()) F962_8642;
	R7442[2] = (char *(*)()) F963_8642;
	R7442[3] = (char *(*)()) F964_8642;
	R7442[4] = (char *(*)()) F965_8642;
	R7442[5] = (char *(*)()) F966_8642;
	R7442[6] = (char *(*)()) F967_8642;
	R7442[7] = (char *(*)()) F968_8642;
	R7442[8] = (char *(*)()) F969_8642;
	{long i; for (i = 9; i < 11; i++) R7442[i] = (char *(*)()) F961_8642;}
	R7442[11] = (char *(*)()) F964_8642;
	R7442[12] = (char *(*)()) F968_8642;
	R7442[13] = (char *(*)()) F966_8642;
	R7442[14] = (char *(*)()) F969_8642;
}

char *(*R7443[15])();
void R7443_init () {
	R7443[0] = (char *(*)()) F961_8643;
	R7443[1] = (char *(*)()) F962_8643;
	R7443[2] = (char *(*)()) F963_8643;
	R7443[3] = (char *(*)()) F964_8643;
	R7443[4] = (char *(*)()) F965_8643;
	R7443[5] = (char *(*)()) F966_8643;
	R7443[6] = (char *(*)()) F967_8643;
	R7443[7] = (char *(*)()) F968_8643;
	R7443[8] = (char *(*)()) F969_8643;
	{long i; for (i = 9; i < 11; i++) R7443[i] = (char *(*)()) F961_8643;}
	R7443[11] = (char *(*)()) F964_8643;
	R7443[12] = (char *(*)()) F968_8643;
	R7443[13] = (char *(*)()) F966_8643;
	R7443[14] = (char *(*)()) F969_8643;
}

char *(*R7444[15])();
void R7444_init () {
	R7444[0] = (char *(*)()) F961_8644;
	R7444[1] = (char *(*)()) F962_8644;
	R7444[2] = (char *(*)()) F963_8644;
	R7444[3] = (char *(*)()) F964_8644;
	R7444[4] = (char *(*)()) F965_8644;
	R7444[5] = (char *(*)()) F966_8644;
	R7444[6] = (char *(*)()) F967_8644;
	R7444[7] = (char *(*)()) F968_8644;
	R7444[8] = (char *(*)()) F969_8644;
	{long i; for (i = 9; i < 11; i++) R7444[i] = (char *(*)()) F961_8644;}
	R7444[11] = (char *(*)()) F964_8644;
	R7444[12] = (char *(*)()) F968_8644;
	R7444[13] = (char *(*)()) F966_8644;
	R7444[14] = (char *(*)()) F969_8644;
}

char *(*R7448[15])();
void R7448_init () {
	R7448[0] = (char *(*)()) F961_8648;
	R7448[1] = (char *(*)()) F962_8648;
	R7448[2] = (char *(*)()) F963_8648_7448_4;
	R7448[3] = (char *(*)()) F964_8648;
	R7448[4] = (char *(*)()) F965_8648_7448_4;
	R7448[5] = (char *(*)()) F966_8648;
	R7448[6] = (char *(*)()) F967_8648_7448_4;
	R7448[7] = (char *(*)()) F968_8648;
	R7448[8] = (char *(*)()) F969_8648;
	{long i; for (i = 9; i < 11; i++) R7448[i] = (char *(*)()) F961_8648;}
	R7448[11] = (char *(*)()) F964_8648;
	R7448[12] = (char *(*)()) F968_8648;
	R7448[13] = (char *(*)()) F966_8648;
	R7448[14] = (char *(*)()) F969_8648;
}
static void F963_8648_7448_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F963_8648(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F965_8648_7448_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F965_8648(Current, *(EIF_POINTER *)arg1);
}
static void F967_8648_7448_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F967_8648(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7449[15])();
void R7449_init () {
	R7449[0] = (char *(*)()) F961_8649;
	R7449[1] = (char *(*)()) F962_8649;
	R7449[2] = (char *(*)()) F963_8649_7449_4;
	R7449[3] = (char *(*)()) F964_8649;
	R7449[4] = (char *(*)()) F965_8649_7449_4;
	R7449[5] = (char *(*)()) F966_8649;
	R7449[6] = (char *(*)()) F967_8649_7449_4;
	R7449[7] = (char *(*)()) F968_8649;
	R7449[8] = (char *(*)()) F969_8649;
	{long i; for (i = 9; i < 11; i++) R7449[i] = (char *(*)()) F961_8649;}
	R7449[11] = (char *(*)()) F964_8649;
	R7449[12] = (char *(*)()) F968_8649;
	R7449[13] = (char *(*)()) F966_8649;
	R7449[14] = (char *(*)()) F969_8649;
}
static void F963_8649_7449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F963_8649(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F965_8649_7449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F965_8649(Current, *(EIF_POINTER *)arg1);
}
static void F967_8649_7449_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F967_8649(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7454[15])();
void R7454_init () {
	R7454[0] = (char *(*)()) F961_8654;
	R7454[1] = (char *(*)()) F962_8654;
	R7454[2] = (char *(*)()) F963_8654;
	R7454[3] = (char *(*)()) F964_8654;
	R7454[4] = (char *(*)()) F965_8654;
	R7454[5] = (char *(*)()) F966_8654;
	R7454[6] = (char *(*)()) F967_8654;
	R7454[7] = (char *(*)()) F968_8654;
	R7454[8] = (char *(*)()) F969_8654;
	{long i; for (i = 9; i < 11; i++) R7454[i] = (char *(*)()) F961_8654;}
	R7454[11] = (char *(*)()) F964_8654;
	R7454[12] = (char *(*)()) F968_8654;
	R7454[13] = (char *(*)()) F966_8654;
	R7454[14] = (char *(*)()) F969_8654;
}

char *(*R7467[15])();
void R7467_init () {
	R7467[0] = (char *(*)()) F961_8667;
	R7467[1] = (char *(*)()) F962_8667;
	R7467[2] = (char *(*)()) F963_8667;
	R7467[3] = (char *(*)()) F964_8667;
	R7467[4] = (char *(*)()) F965_8667;
	R7467[5] = (char *(*)()) F966_8667;
	R7467[6] = (char *(*)()) F967_8667;
	R7467[7] = (char *(*)()) F968_8667;
	R7467[8] = (char *(*)()) F969_8667;
	{long i; for (i = 9; i < 11; i++) R7467[i] = (char *(*)()) F961_8667;}
	R7467[11] = (char *(*)()) F964_8667;
	R7467[12] = (char *(*)()) F968_8667;
	R7467[13] = (char *(*)()) F966_8667;
	R7467[14] = (char *(*)()) F969_8667;
}

char *(*R7480[5])();
void R7480_init () {
	R7480[0] = (char *(*)()) F971_8682;
	R7480[1] = (char *(*)()) F972_8682;
	R7480[2] = (char *(*)()) F973_8682;
	R7480[3] = (char *(*)()) F974_8682;
	R7480[4] = (char *(*)()) F975_8682;
}

char *(*R7502[12])();
void R7502_init () {
	R7502[0] = (char *(*)()) F989_8728;
	R7502[1] = (char *(*)()) F990_8728;
	R7502[2] = (char *(*)()) F991_8728;
	R7502[3] = (char *(*)()) F992_8728;
	R7502[4] = (char *(*)()) F993_8728;
	R7502[5] = (char *(*)()) F994_8728;
	R7502[6] = (char *(*)()) F995_8728;
	R7502[7] = (char *(*)()) F996_8728;
	R7502[8] = (char *(*)()) F997_8728;
	R7502[9] = (char *(*)()) F998_8728;
	R7502[10] = (char *(*)()) F999_8728;
	R7502[11] = (char *(*)()) F1000_8728;
}

char *(*R7503[12])();
void R7503_init () {
	R7503[0] = (char *(*)()) F989_8729;
	R7503[1] = (char *(*)()) F990_8729_7503_22;
	R7503[2] = (char *(*)()) F991_8729_7503_22;
	R7503[3] = (char *(*)()) F992_8729_7503_22;
	R7503[4] = (char *(*)()) F993_8729_7503_22;
	R7503[5] = (char *(*)()) F994_8729_7503_22;
	R7503[6] = (char *(*)()) F995_8729_7503_22;
	R7503[7] = (char *(*)()) F996_8729_7503_22;
	R7503[8] = (char *(*)()) F997_8729_7503_22;
	R7503[9] = (char *(*)()) F998_8729_7503_22;
	R7503[10] = (char *(*)()) F999_8729_7503_22;
	R7503[11] = (char *(*)()) F1000_8729_7503_22;
}
static void F990_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F990_8729(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F991_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F991_8729(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F992_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F992_8729(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F993_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F993_8729(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F994_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F994_8729(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F995_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F995_8729(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F996_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F996_8729(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F997_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F997_8729(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F998_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F998_8729(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F999_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F999_8729(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1000_8729_7503_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1000_8729(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R7506[12])();
void R7506_init () {
	R7506[0] = (char *(*)()) F989_8732;
	R7506[1] = (char *(*)()) F990_8732;
	R7506[2] = (char *(*)()) F991_8732;
	R7506[3] = (char *(*)()) F992_8732;
	R7506[4] = (char *(*)()) F993_8732;
	R7506[5] = (char *(*)()) F994_8732;
	R7506[6] = (char *(*)()) F995_8732;
	R7506[7] = (char *(*)()) F996_8732;
	R7506[8] = (char *(*)()) F997_8732;
	R7506[9] = (char *(*)()) F998_8732;
	R7506[10] = (char *(*)()) F999_8732;
	R7506[11] = (char *(*)()) F1000_8732;
}

char *(*R7530[12])();
void R7530_init () {
	R7530[0] = (char *(*)()) F989_8774;
	R7530[1] = (char *(*)()) F990_8774_7530_22;
	R7530[2] = (char *(*)()) F991_8774_7530_22;
	R7530[3] = (char *(*)()) F992_8774_7530_22;
	R7530[4] = (char *(*)()) F993_8774_7530_22;
	R7530[5] = (char *(*)()) F994_8774_7530_22;
	R7530[6] = (char *(*)()) F995_8774_7530_22;
	R7530[7] = (char *(*)()) F996_8774_7530_22;
	R7530[8] = (char *(*)()) F997_8774_7530_22;
	R7530[9] = (char *(*)()) F998_8774_7530_22;
	R7530[10] = (char *(*)()) F999_8774_7530_22;
	R7530[11] = (char *(*)()) F1000_8774_7530_22;
}
static void F990_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F990_8774(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F991_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F991_8774(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F992_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F992_8774(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F993_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F993_8774(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F994_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F994_8774(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F995_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F995_8774(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F996_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F996_8774(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F997_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F997_8774(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F998_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F998_8774(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F999_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F999_8774(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1000_8774_7530_22 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1000_8774(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R7537[12])();
void R7537_init () {
	R7537[0] = (char *(*)()) F989_8786;
	R7537[1] = (char *(*)()) F990_8786;
	R7537[2] = (char *(*)()) F991_8786;
	R7537[3] = (char *(*)()) F992_8786;
	R7537[4] = (char *(*)()) F993_8786;
	R7537[5] = (char *(*)()) F994_8786;
	R7537[6] = (char *(*)()) F995_8786;
	R7537[7] = (char *(*)()) F996_8786;
	R7537[8] = (char *(*)()) F997_8786;
	R7537[9] = (char *(*)()) F998_8786;
	R7537[10] = (char *(*)()) F999_8786;
	R7537[11] = (char *(*)()) F1000_8786;
}

char *(*R7541[22])();
void R7541_init () {
	R7541[0] = (char *(*)()) F1054_8841;
	R7541[1] = (char *(*)()) F1055_8841_7541_1;
	R7541[2] = (char *(*)()) F1054_8841;
	R7541[3] = (char *(*)()) F1055_8841_7541_1;
	R7541[4] = (char *(*)()) F1054_8841;
	R7541[5] = (char *(*)()) F1059_8916;
	R7541[6] = (char *(*)()) F1060_8916_7541_1;
	R7541[7] = (char *(*)()) F1061_8916_7541_1;
	R7541[8] = (char *(*)()) F1062_8916_7541_1;
	R7541[9] = (char *(*)()) F1063_8916_7541_1;
	R7541[10] = (char *(*)()) F1064_8916_7541_1;
	R7541[11] = (char *(*)()) F1065_8916_7541_1;
	R7541[12] = (char *(*)()) F1066_8916_7541_1;
	R7541[13] = (char *(*)()) F1067_8916_7541_1;
	R7541[14] = (char *(*)()) F1068_8916_7541_1;
	R7541[15] = (char *(*)()) F1069_8916_7541_1;
	R7541[16] = (char *(*)()) F1070_8916_7541_1;
	{long i; for (i = 17; i < 20; i++) R7541[i] = (char *(*)()) F1059_8916;}
	R7541[20] = (char *(*)()) F1062_8916_7541_1;
	R7541[21] = (char *(*)()) F1059_8916;
}
static EIF_REFERENCE F1055_8841_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1055_8841(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8916_7541_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R7542[22])();
void R7542_init () {
	R7542[0] = (char *(*)()) F1054_8842;
	R7542[1] = (char *(*)()) F1055_8842_7542_1;
	R7542[2] = (char *(*)()) F1054_8842;
	R7542[3] = (char *(*)()) F1055_8842_7542_1;
	R7542[4] = (char *(*)()) F1054_8842;
	R7542[5] = (char *(*)()) F1059_8917;
	R7542[6] = (char *(*)()) F1060_8917_7542_1;
	R7542[7] = (char *(*)()) F1061_8917_7542_1;
	R7542[8] = (char *(*)()) F1062_8917_7542_1;
	R7542[9] = (char *(*)()) F1063_8917_7542_1;
	R7542[10] = (char *(*)()) F1064_8917_7542_1;
	R7542[11] = (char *(*)()) F1065_8917_7542_1;
	R7542[12] = (char *(*)()) F1066_8917_7542_1;
	R7542[13] = (char *(*)()) F1067_8917_7542_1;
	R7542[14] = (char *(*)()) F1068_8917_7542_1;
	R7542[15] = (char *(*)()) F1069_8917_7542_1;
	R7542[16] = (char *(*)()) F1070_8917_7542_1;
	{long i; for (i = 17; i < 20; i++) R7542[i] = (char *(*)()) F1059_8917;}
	R7542[20] = (char *(*)()) F1062_8917_7542_1;
	R7542[21] = (char *(*)()) F1059_8917;
}
static EIF_REFERENCE F1055_8842_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1055_8842(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1060_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1061_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1061_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1062_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1062_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1064_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1064_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1065_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1065_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1066_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1066_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1067_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1067_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1068_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1068_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1069_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1069_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1070_8917_7542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1070_8917(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R7543[5])();
void R7543_init () {
	R7543[0] = (char *(*)()) F1054_8861;
	R7543[1] = (char *(*)()) F1055_8861;
	R7543[2] = (char *(*)()) F1054_8861;
	R7543[3] = (char *(*)()) F1055_8861;
	R7543[4] = (char *(*)()) F1054_8861;
}

char *(*R7544[22])();
void R7544_init () {
	R7544[0] = (char *(*)()) F1054_8862;
	R7544[1] = (char *(*)()) F1055_8862;
	R7544[2] = (char *(*)()) F1054_8862;
	R7544[3] = (char *(*)()) F1055_8862;
	R7544[4] = (char *(*)()) F1054_8862;
	R7544[5] = (char *(*)()) F1059_8943;
	R7544[6] = (char *(*)()) F1060_8943;
	R7544[7] = (char *(*)()) F1061_8943;
	R7544[8] = (char *(*)()) F1062_8943;
	R7544[9] = (char *(*)()) F1063_8943;
	R7544[10] = (char *(*)()) F1064_8943;
	R7544[11] = (char *(*)()) F1065_8943;
	R7544[12] = (char *(*)()) F1066_8943;
	R7544[13] = (char *(*)()) F1067_8943;
	R7544[14] = (char *(*)()) F1068_8943;
	R7544[15] = (char *(*)()) F1069_8943;
	R7544[16] = (char *(*)()) F1070_8943;
	{long i; for (i = 17; i < 20; i++) R7544[i] = (char *(*)()) F1059_8943;}
	R7544[20] = (char *(*)()) F1062_8943;
	R7544[21] = (char *(*)()) F1059_8943;
}

char *(*R7545[22])();
void R7545_init () {
	R7545[0] = (char *(*)()) F1054_8852;
	R7545[1] = (char *(*)()) F1055_8852;
	R7545[2] = (char *(*)()) F1054_8852;
	R7545[3] = (char *(*)()) F1055_8852;
	R7545[4] = (char *(*)()) F1054_8852;
	R7545[5] = (char *(*)()) F1006_8801;
	R7545[6] = (char *(*)()) F1007_8801;
	R7545[7] = (char *(*)()) F1008_8801;
	R7545[8] = (char *(*)()) F1009_8801;
	R7545[9] = (char *(*)()) F1010_8801;
	R7545[10] = (char *(*)()) F1011_8801;
	R7545[11] = (char *(*)()) F1012_8801;
	R7545[12] = (char *(*)()) F1013_8801;
	R7545[13] = (char *(*)()) F1014_8801;
	R7545[14] = (char *(*)()) F1015_8801;
	R7545[15] = (char *(*)()) F1016_8801;
	R7545[16] = (char *(*)()) F1017_8801;
	{long i; for (i = 17; i < 20; i++) R7545[i] = (char *(*)()) F1006_8801;}
	R7545[20] = (char *(*)()) F1009_8801;
	R7545[21] = (char *(*)()) F1006_8801;
}

char *(*R7546[22])();
void R7546_init () {
	R7546[0] = (char *(*)()) F1054_8853;
	R7546[1] = (char *(*)()) F1055_8853;
	R7546[2] = (char *(*)()) F1054_8853;
	R7546[3] = (char *(*)()) F1055_8853;
	R7546[4] = (char *(*)()) F1054_8853;
	R7546[5] = (char *(*)()) F1006_8802;
	R7546[6] = (char *(*)()) F1007_8802;
	R7546[7] = (char *(*)()) F1008_8802;
	R7546[8] = (char *(*)()) F1009_8802;
	R7546[9] = (char *(*)()) F1010_8802;
	R7546[10] = (char *(*)()) F1011_8802;
	R7546[11] = (char *(*)()) F1012_8802;
	R7546[12] = (char *(*)()) F1013_8802;
	R7546[13] = (char *(*)()) F1014_8802;
	R7546[14] = (char *(*)()) F1015_8802;
	R7546[15] = (char *(*)()) F1016_8802;
	R7546[16] = (char *(*)()) F1017_8802;
	{long i; for (i = 17; i < 20; i++) R7546[i] = (char *(*)()) F1006_8802;}
	R7546[20] = (char *(*)()) F1009_8802;
	R7546[21] = (char *(*)()) F1006_8802;
}

char *(*R7551[5])();
void R7551_init () {
	R7551[0] = (char *(*)()) F1054_8864;
	R7551[1] = (char *(*)()) F1055_8864_7551_4;
	R7551[2] = (char *(*)()) F1054_8864;
	R7551[3] = (char *(*)()) F1055_8864_7551_4;
	R7551[4] = (char *(*)()) F1054_8864;
}
static void F1055_8864_7551_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1055_8864(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7562[5])();
void R7562_init () {
	R7562[0] = (char *(*)()) F1054_8877;
	R7562[1] = (char *(*)()) F1055_8877_7562_5;
	R7562[2] = (char *(*)()) F1054_8877;
	R7562[3] = (char *(*)()) F1055_8877_7562_5;
	R7562[4] = (char *(*)()) F1054_8877;
}
static EIF_REFERENCE F1055_8877_7562_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1055_8877(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7563[5])();
void R7563_init () {
	R7563[0] = (char *(*)()) F1054_8878;
	R7563[1] = (char *(*)()) F1055_8878;
	R7563[2] = (char *(*)()) F1054_8878;
	R7563[3] = (char *(*)()) F1055_8878;
	R7563[4] = (char *(*)()) F1054_8878;
}

char *(*R7566[5])();
void R7566_init () {
	R7566[0] = (char *(*)()) F1054_8881;
	R7566[1] = (char *(*)()) F1055_8881;
	R7566[2] = (char *(*)()) F1054_8881;
	R7566[3] = (char *(*)()) F1055_8881;
	R7566[4] = (char *(*)()) F1054_8881;
}

char *(*R7567[5])();
void R7567_init () {
	R7567[0] = (char *(*)()) F1054_8882;
	R7567[1] = (char *(*)()) F1055_8882;
	R7567[2] = (char *(*)()) F1054_8882;
	R7567[3] = (char *(*)()) F1055_8882;
	R7567[4] = (char *(*)()) F1054_8882;
}

char *(*R7568[5])();
void R7568_init () {
	R7568[0] = (char *(*)()) F1054_8883;
	R7568[1] = (char *(*)()) F1055_8883;
	R7568[2] = (char *(*)()) F1054_8883;
	R7568[3] = (char *(*)()) F1055_8883;
	R7568[4] = (char *(*)()) F1054_8883;
}

char *(*R7573[2])();
void R7573_init () {
	R7573[0] = (char *(*)()) F1054_8840;
	R7573[1] = (char *(*)()) F1055_8840_7573_1;
}
static EIF_REFERENCE F1055_8840_7573_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1055_8840(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7574[2])();
void R7574_init () {
	R7574[0] = (char *(*)()) F1054_8871;
	R7574[1] = (char *(*)()) F1055_8871;
}

char *(*R7578[17])();
void R7578_init () {
	R7578[0] = (char *(*)()) F1059_8908;
	R7578[1] = (char *(*)()) F1060_8908;
	R7578[2] = (char *(*)()) F1061_8908;
	R7578[3] = (char *(*)()) F1062_8908;
	R7578[4] = (char *(*)()) F1063_8908;
	R7578[5] = (char *(*)()) F1064_8908;
	R7578[6] = (char *(*)()) F1065_8908;
	R7578[7] = (char *(*)()) F1066_8908;
	R7578[8] = (char *(*)()) F1067_8908;
	R7578[9] = (char *(*)()) F1068_8908;
	R7578[10] = (char *(*)()) F1069_8908;
	R7578[11] = (char *(*)()) F1070_8908;
	R7578[12] = (char *(*)()) F1071_8974;
	{long i; for (i = 13; i < 15; i++) R7578[i] = (char *(*)()) F1059_8908;}
	R7578[15] = (char *(*)()) F1062_8908;
	R7578[16] = (char *(*)()) F1075_8999;
}

char *(*R7582[17])();
void R7582_init () {
	R7582[0] = (char *(*)()) F1059_8912;
	R7582[1] = (char *(*)()) F1060_8912;
	R7582[2] = (char *(*)()) F1061_8912;
	R7582[3] = (char *(*)()) F1062_8912;
	R7582[4] = (char *(*)()) F1063_8912;
	R7582[5] = (char *(*)()) F1064_8912;
	R7582[6] = (char *(*)()) F1065_8912;
	R7582[7] = (char *(*)()) F1066_8912;
	R7582[8] = (char *(*)()) F1067_8912;
	R7582[9] = (char *(*)()) F1068_8912;
	R7582[10] = (char *(*)()) F1069_8912;
	R7582[11] = (char *(*)()) F1070_8912;
	{long i; for (i = 12; i < 15; i++) R7582[i] = (char *(*)()) F1059_8912;}
	R7582[15] = (char *(*)()) F1062_8912;
	R7582[16] = (char *(*)()) F1059_8912;
}

char *(*R7586[17])();
void R7586_init () {
	R7586[0] = (char *(*)()) F1059_8931;
	R7586[1] = (char *(*)()) F1060_8931;
	R7586[2] = (char *(*)()) F1061_8931;
	R7586[3] = (char *(*)()) F1062_8931;
	R7586[4] = (char *(*)()) F1063_8931;
	R7586[5] = (char *(*)()) F1064_8931;
	R7586[6] = (char *(*)()) F1065_8931;
	R7586[7] = (char *(*)()) F1066_8931;
	R7586[8] = (char *(*)()) F1067_8931;
	R7586[9] = (char *(*)()) F1068_8931;
	R7586[10] = (char *(*)()) F1069_8931;
	R7586[11] = (char *(*)()) F1070_8931;
	{long i; for (i = 12; i < 15; i++) R7586[i] = (char *(*)()) F1059_8931;}
	R7586[15] = (char *(*)()) F1062_8931;
	R7586[16] = (char *(*)()) F1059_8931;
}

char *(*R7590[17])();
void R7590_init () {
	R7590[0] = (char *(*)()) F1059_8972;
	R7590[1] = (char *(*)()) F1060_8972_7590_67;
	R7590[2] = (char *(*)()) F1061_8972_7590_67;
	R7590[3] = (char *(*)()) F1062_8972_7590_67;
	R7590[4] = (char *(*)()) F1063_8972_7590_67;
	R7590[5] = (char *(*)()) F1064_8972_7590_67;
	R7590[6] = (char *(*)()) F1065_8972_7590_67;
	R7590[7] = (char *(*)()) F1066_8972_7590_67;
	R7590[8] = (char *(*)()) F1067_8972_7590_67;
	R7590[9] = (char *(*)()) F1068_8972_7590_67;
	R7590[10] = (char *(*)()) F1069_8972_7590_67;
	R7590[11] = (char *(*)()) F1070_8972_7590_67;
	{long i; for (i = 12; i < 15; i++) R7590[i] = (char *(*)()) F1059_8972;}
	R7590[15] = (char *(*)()) F1062_8972_7590_67;
	R7590[16] = (char *(*)()) F1059_8972;
}
static void F1060_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1060_8972(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1061_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1061_8972(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1062_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1062_8972(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1063_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1063_8972(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1064_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1064_8972(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1065_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1065_8972(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1066_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1066_8972(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1067_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1067_8972(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1068_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1068_8972(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1069_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1069_8972(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1070_8972_7590_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1070_8972(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7598[2])();
void R7598_init () {
	R7598[0] = (char *(*)()) F1059_8949;
	R7598[1] = (char *(*)()) F1062_8949_7598_4;
}
static void F1062_8949_7598_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1062_8949(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7599[2])();
void R7599_init () {
	R7599[0] = (char *(*)()) F1059_8962;
	R7599[1] = (char *(*)()) F1062_8962;
}

char *(*R7910[2])();
void R7910_init () {
	R7910[0] = (char *(*)()) F1103_9354;
	R7910[1] = (char *(*)()) F1104_9378;
}

char *(*R8059[2])();
void R8059_init () {
	R8059[0] = (char *(*)()) F1110_9539;
	R8059[1] = (char *(*)()) F1111_9560;
}

char *(*R8117[339])();
void R8117_init () {
	R8117[0] = (char *(*)()) F1114_9635;
	R8117[3] = (char *(*)()) F1116_9769;
	{long i; for (i = 4; i < 6; i++) R8117[i] = (char *(*)()) F1118_9790;}
	{long i; for (i = 7; i < 9; i++) R8117[i] = (char *(*)()) F1120_9813;}
	{long i; for (i = 10; i < 12; i++) R8117[i] = (char *(*)()) F1123_9854;}
	{long i; for (i = 13; i < 15; i++) R8117[i] = (char *(*)()) F1126_9902;}
	{long i; for (i = 16; i < 46; i++) R8117[i] = (char *(*)()) F1129_9923;}
	R8117[46] = (char *(*)()) F1160_9949;
	R8117[47] = (char *(*)()) F1161_9949;
	{long i; for (i = 49; i < 54; i++) R8117[i] = (char *(*)()) F1162_9957;}
	{long i; for (i = 58; i < 60; i++) R8117[i] = (char *(*)()) F1168_10016;}
	{long i; for (i = 61; i < 64; i++) R8117[i] = (char *(*)()) F1168_10016;}
	R8117[73] = (char *(*)()) F1187_10657;
	R8117[78] = (char *(*)()) F1192_10920;
	R8117[80] = (char *(*)()) F1194_11013;
	R8117[82] = (char *(*)()) F1196_11067;
	R8117[83] = (char *(*)()) F1197_11067;
	R8117[84] = (char *(*)()) F1198_11067;
	R8117[85] = (char *(*)()) F1199_11067;
	R8117[86] = (char *(*)()) F1200_11067;
	R8117[87] = (char *(*)()) F1201_11067;
	R8117[88] = (char *(*)()) F1202_11067;
	R8117[89] = (char *(*)()) F1203_11067;
	R8117[90] = (char *(*)()) F1204_11067;
	R8117[91] = (char *(*)()) F1205_11067;
	R8117[92] = (char *(*)()) F1206_11067;
	R8117[93] = (char *(*)()) F1207_11067;
	R8117[94] = (char *(*)()) F1208_11067;
	R8117[95] = (char *(*)()) F1209_11067;
	R8117[96] = (char *(*)()) F1210_11067;
	R8117[97] = (char *(*)()) F1211_11067;
	R8117[98] = (char *(*)()) F1212_11067;
	R8117[99] = (char *(*)()) F1213_11067;
	R8117[100] = (char *(*)()) F1214_11067;
	R8117[101] = (char *(*)()) F1215_11067;
	R8117[102] = (char *(*)()) F1216_11067;
	R8117[103] = (char *(*)()) F1217_11067;
	R8117[104] = (char *(*)()) F1218_11067;
	R8117[105] = (char *(*)()) F1219_11067;
	R8117[106] = (char *(*)()) F1220_11067;
	R8117[107] = (char *(*)()) F1221_11067;
	R8117[108] = (char *(*)()) F1222_11067;
	R8117[109] = (char *(*)()) F1223_11067;
	R8117[110] = (char *(*)()) F1224_11067;
	R8117[111] = (char *(*)()) F1225_11067;
	R8117[112] = (char *(*)()) F1226_11067;
	R8117[113] = (char *(*)()) F1227_11067;
	R8117[114] = (char *(*)()) F1228_11067;
	R8117[115] = (char *(*)()) F1229_11067;
	{long i; for (i = 135; i < 138; i++) R8117[i] = (char *(*)()) F1246_11196;}
	{long i; for (i = 139; i < 142; i++) R8117[i] = (char *(*)()) F1246_11196;}
	R8117[189] = (char *(*)()) F1303_11440;
	R8117[190] = (char *(*)()) F1304_11445;
	R8117[191] = (char *(*)()) F1305_11459;
	R8117[192] = (char *(*)()) F1306_11500;
	{long i; for (i = 195; i < 197; i++) R8117[i] = (char *(*)()) F1308_11517;}
	{long i; for (i = 198; i < 200; i++) R8117[i] = (char *(*)()) F1311_11615;}
	{long i; for (i = 201; i < 203; i++) R8117[i] = (char *(*)()) F1314_11714;}
	{long i; for (i = 204; i < 206; i++) R8117[i] = (char *(*)()) F1317_11813;}
	{long i; for (i = 207; i < 209; i++) R8117[i] = (char *(*)()) F1320_11912;}
	{long i; for (i = 210; i < 212; i++) R8117[i] = (char *(*)()) F1323_12006;}
	{long i; for (i = 213; i < 215; i++) R8117[i] = (char *(*)()) F1326_12100;}
	{long i; for (i = 216; i < 218; i++) R8117[i] = (char *(*)()) F1329_12195;}
	{long i; for (i = 219; i < 221; i++) R8117[i] = (char *(*)()) F1332_12290;}
	{long i; for (i = 222; i < 224; i++) R8117[i] = (char *(*)()) F1335_12356;}
	R8117[224] = (char *(*)()) F1338_12455;
	R8117[225] = (char *(*)()) F1339_12475;
	R8117[231] = (char *(*)()) F1345_12484;
	R8117[235] = (char *(*)()) F1349_12533;
	R8117[338] = (char *(*)()) F1452_15290;
}

char *(*R8311[2])();
void R8311_init () {
	R8311[0] = (char *(*)()) F1121_9849;
	R8311[1] = (char *(*)()) F1122_9849;
}

char *(*R8435[5])();
void R8435_init () {
	R8435[0] = (char *(*)()) F1163_9994;
	R8435[1] = (char *(*)()) F1164_9997;
	R8435[2] = (char *(*)()) F1165_9997;
	R8435[3] = (char *(*)()) F1166_9997;
	R8435[4] = (char *(*)()) F1165_9997;
}

char *(*R8459[4])();
void R8459_init () {
	R8459[0] = (char *(*)()) F1164_9996;
	R8459[1] = (char *(*)()) F1165_9996_8459_1;
	R8459[2] = (char *(*)()) F1166_9996_8459_1;
	R8459[3] = (char *(*)()) F1165_9996_8459_1;
}
static EIF_REFERENCE F1165_9996_8459_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1165_9996(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1166_9996_8459_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1166_9996(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R8460[4])();
void R8460_init () {
	R8460[0] = (char *(*)()) F1164_9998;
	R8460[1] = (char *(*)()) F1165_9998_8460_5;
	R8460[2] = (char *(*)()) F1166_9998_8460_5;
	R8460[3] = (char *(*)()) F1165_9998_8460_5;
}
static EIF_REFERENCE F1165_9998_8460_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1165_9998(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1166_9998_8460_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1166_9998(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R8464[4])();
void R8464_init () {
	R8464[0] = (char *(*)()) F1164_10005;
	R8464[1] = (char *(*)()) F1165_10005_8464_424;
	R8464[2] = (char *(*)()) F1166_10005_8464_424;
	R8464[3] = (char *(*)()) F1165_10005_8464_424;
}
static EIF_REFERENCE F1165_10005_8464_424 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1165_10005(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1166_10005_8464_424 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1166_10005(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y8465_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8465_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8465_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y8465_pgtype3[] = {1127,0xFFFF};
EIF_TYPE_INDEX *Y8465_gen_type [4];
EIF_TYPE_INDEX Y8465 [4];
void Y8465_init (void)
{
	egc_routines_types [8465] = Y8465;
	egc_routines_gen_types [8465] = Y8465_gen_type;
	egc_routines_offset [8465] = 1163;
	Y8465_gen_type [0] = Y8465_pgtype0;
	Y8465_gen_type [1] = Y8465_pgtype1;
	Y8465_gen_type [2] = Y8465_pgtype2;
	Y8465_gen_type [3] = Y8465_pgtype3;
	Y8465[3] = 1127;
}

char *(*R8466[281])();
void R8466_init () {
	{long i; for (i = 0; i < 2; i++) R8466[i] = (char *(*)()) F1171_10137;}
	{long i; for (i = 3; i < 6; i++) R8466[i] = (char *(*)()) F1174_10304;}
	R8466[280] = (char *(*)()) F1452_15264;
}

char *(*R8468[281])();
void R8468_init () {
	R8468[0] = (char *(*)()) F1172_10198;
	R8468[1] = (char *(*)()) F1173_10221;
	R8468[3] = (char *(*)()) F1175_10364;
	{long i; for (i = 4; i < 6; i++) R8468[i] = (char *(*)()) F1176_10386;}
	R8468[280] = (char *(*)()) F1452_15392;
}

char *(*R8469[281])();
void R8469_init () {
	R8469[0] = (char *(*)()) F1172_10196;
	R8469[1] = (char *(*)()) F1173_10219;
	R8469[3] = (char *(*)()) F1175_10363;
	{long i; for (i = 4; i < 6; i++) R8469[i] = (char *(*)()) F1176_10385;}
	R8469[280] = (char *(*)()) F1176_10385;
}

char *(*R8470[281])();
void R8470_init () {
	{long i; for (i = 0; i < 2; i++) R8470[i] = (char *(*)()) F1171_10149;}
	{long i; for (i = 3; i < 6; i++) R8470[i] = (char *(*)()) F1168_10010;}
	R8470[280] = (char *(*)()) F1168_10010;
}


#ifdef __cplusplus
}
#endif
