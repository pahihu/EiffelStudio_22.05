#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5593[977])();
void R5593_init () {
	R5593[0] = (char *(*)()) F469_6101_5593_67;
	R5593[513] = (char *(*)()) F463_6101;
	R5593[514] = (char *(*)()) F464_6101_5593_67;
	R5593[515] = (char *(*)()) F465_6101_5593_67;
	R5593[516] = (char *(*)()) F466_6101_5593_67;
	R5593[517] = (char *(*)()) F467_6101_5593_67;
	R5593[518] = (char *(*)()) F468_6101_5593_67;
	R5593[519] = (char *(*)()) F469_6101_5593_67;
	R5593[520] = (char *(*)()) F470_6101_5593_67;
	R5593[521] = (char *(*)()) F471_6101_5593_67;
	R5593[522] = (char *(*)()) F472_6101_5593_67;
	R5593[523] = (char *(*)()) F473_6101_5593_67;
	R5593[524] = (char *(*)()) F474_6101_5593_67;
	R5593[583] = (char *(*)()) F463_6101;
	R5593[584] = (char *(*)()) F464_6101_5593_67;
	R5593[585] = (char *(*)()) F465_6101_5593_67;
	R5593[586] = (char *(*)()) F466_6101_5593_67;
	R5593[587] = (char *(*)()) F467_6101_5593_67;
	R5593[588] = (char *(*)()) F468_6101_5593_67;
	R5593[589] = (char *(*)()) F469_6101_5593_67;
	R5593[590] = (char *(*)()) F470_6101_5593_67;
	R5593[591] = (char *(*)()) F471_6101_5593_67;
	R5593[592] = (char *(*)()) F472_6101_5593_67;
	R5593[593] = (char *(*)()) F473_6101_5593_67;
	R5593[594] = (char *(*)()) F474_6101_5593_67;
	{long i; for (i = 595; i < 598; i++) R5593[i] = (char *(*)()) F463_6101;}
	R5593[598] = (char *(*)()) F466_6101_5593_67;
	R5593[599] = (char *(*)()) F463_6101;
	R5593[697] = (char *(*)()) F471_6101_5593_67;
	{long i; for (i = 700; i < 702; i++) R5593[i] = (char *(*)()) F467_6101_5593_67;}
	R5593[976] = (char *(*)()) F467_6101_5593_67;
}
static void F469_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F469_6101(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F464_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F464_6101(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F465_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F465_6101(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F466_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F466_6101(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F467_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F467_6101(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F468_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F468_6101(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F470_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F470_6101(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F471_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F471_6101(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F472_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F472_6101(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F473_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F473_6101(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F474_6101_5593_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F474_6101(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5599[977])();
void R5599_init () {
	R5599[0] = (char *(*)()) F469_6107;
	R5599[513] = (char *(*)()) F463_6107;
	R5599[514] = (char *(*)()) F464_6107;
	R5599[515] = (char *(*)()) F465_6107;
	R5599[516] = (char *(*)()) F466_6107;
	R5599[517] = (char *(*)()) F467_6107;
	R5599[518] = (char *(*)()) F468_6107;
	R5599[519] = (char *(*)()) F469_6107;
	R5599[520] = (char *(*)()) F470_6107;
	R5599[521] = (char *(*)()) F471_6107;
	R5599[522] = (char *(*)()) F472_6107;
	R5599[523] = (char *(*)()) F473_6107;
	R5599[524] = (char *(*)()) F474_6107;
	R5599[583] = (char *(*)()) F463_6107;
	R5599[584] = (char *(*)()) F464_6107;
	R5599[585] = (char *(*)()) F465_6107;
	R5599[586] = (char *(*)()) F466_6107;
	R5599[587] = (char *(*)()) F467_6107;
	R5599[588] = (char *(*)()) F468_6107;
	R5599[589] = (char *(*)()) F469_6107;
	R5599[590] = (char *(*)()) F470_6107;
	R5599[591] = (char *(*)()) F471_6107;
	R5599[592] = (char *(*)()) F472_6107;
	R5599[593] = (char *(*)()) F473_6107;
	R5599[594] = (char *(*)()) F474_6107;
	{long i; for (i = 595; i < 598; i++) R5599[i] = (char *(*)()) F463_6107;}
	R5599[598] = (char *(*)()) F466_6107;
	R5599[599] = (char *(*)()) F463_6107;
	R5599[697] = (char *(*)()) F471_6107;
	{long i; for (i = 700; i < 702; i++) R5599[i] = (char *(*)()) F467_6107;}
	R5599[976] = (char *(*)()) F467_6107;
}

static EIF_TYPE_INDEX Y5600_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype12[] = {1127,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype13[] = {1330,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype14[] = {1330,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype44[] = {0xFF01,1406,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype48[] = {0xFF01,1074,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype49[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype50[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype51[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype52[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype53[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5600_pgtype54[] = {1124,0xFFFF};
EIF_TYPE_INDEX *Y5600_gen_type [991];
EIF_TYPE_INDEX Y5600 [991];
void Y5600_init (void)
{
	egc_routines_types [5600] = Y5600;
	egc_routines_gen_types [5600] = Y5600_gen_type;
	egc_routines_offset [5600] = 462;
	Y5600_gen_type [0] = Y5600_pgtype0;
	Y5600_gen_type [1] = Y5600_pgtype1;
	Y5600_gen_type [2] = Y5600_pgtype2;
	Y5600_gen_type [3] = Y5600_pgtype3;
	Y5600_gen_type [4] = Y5600_pgtype4;
	Y5600_gen_type [5] = Y5600_pgtype5;
	Y5600_gen_type [6] = Y5600_pgtype6;
	Y5600_gen_type [7] = Y5600_pgtype7;
	Y5600_gen_type [8] = Y5600_pgtype8;
	Y5600_gen_type [9] = Y5600_pgtype9;
	Y5600_gen_type [10] = Y5600_pgtype10;
	Y5600_gen_type [11] = Y5600_pgtype11;
	Y5600_gen_type [12] = Y5600_pgtype12;
	Y5600_gen_type [13] = Y5600_pgtype13;
	Y5600_gen_type [14] = Y5600_pgtype14;
	Y5600_gen_type [526] = Y5600_pgtype15;
	Y5600_gen_type [527] = Y5600_pgtype16;
	Y5600_gen_type [528] = Y5600_pgtype17;
	Y5600_gen_type [529] = Y5600_pgtype18;
	Y5600_gen_type [530] = Y5600_pgtype19;
	Y5600_gen_type [531] = Y5600_pgtype20;
	Y5600_gen_type [532] = Y5600_pgtype21;
	Y5600_gen_type [533] = Y5600_pgtype22;
	Y5600_gen_type [534] = Y5600_pgtype23;
	Y5600_gen_type [535] = Y5600_pgtype24;
	Y5600_gen_type [536] = Y5600_pgtype25;
	Y5600_gen_type [537] = Y5600_pgtype26;
	Y5600_gen_type [538] = Y5600_pgtype27;
	Y5600_gen_type [539] = Y5600_pgtype28;
	Y5600_gen_type [540] = Y5600_pgtype29;
	Y5600_gen_type [541] = Y5600_pgtype30;
	Y5600_gen_type [542] = Y5600_pgtype31;
	Y5600_gen_type [596] = Y5600_pgtype32;
	Y5600_gen_type [597] = Y5600_pgtype33;
	Y5600_gen_type [598] = Y5600_pgtype34;
	Y5600_gen_type [599] = Y5600_pgtype35;
	Y5600_gen_type [600] = Y5600_pgtype36;
	Y5600_gen_type [601] = Y5600_pgtype37;
	Y5600_gen_type [602] = Y5600_pgtype38;
	Y5600_gen_type [603] = Y5600_pgtype39;
	Y5600_gen_type [604] = Y5600_pgtype40;
	Y5600_gen_type [605] = Y5600_pgtype41;
	Y5600_gen_type [606] = Y5600_pgtype42;
	Y5600_gen_type [607] = Y5600_pgtype43;
	Y5600_gen_type [608] = Y5600_pgtype44;
	Y5600_gen_type [609] = Y5600_pgtype45;
	Y5600_gen_type [610] = Y5600_pgtype46;
	Y5600_gen_type [611] = Y5600_pgtype47;
	Y5600_gen_type [612] = Y5600_pgtype48;
	Y5600_gen_type [710] = Y5600_pgtype49;
	Y5600_gen_type [713] = Y5600_pgtype50;
	Y5600_gen_type [714] = Y5600_pgtype51;
	Y5600_gen_type [715] = Y5600_pgtype52;
	Y5600_gen_type [989] = Y5600_pgtype53;
	Y5600_gen_type [990] = Y5600_pgtype54;
	Y5600[12] = 1127;
	{long i; for (i = 13; i < 15; i++) Y5600[i] = 1330;};
	Y5600[608] = 1406;
	Y5600[612] = 1074;
	Y5600[710] = 1121;
	{long i; for (i = 713; i < 716; i++) Y5600[i] = 1124;};
	{long i; for (i = 989; i < 991; i++) Y5600[i] = 1124;};
}

char *(*R5820[354])();
void R5820_init () {
	R5820[0] = (char *(*)()) F516_6436;
	R5820[1] = (char *(*)()) F517_6443;
	R5820[2] = (char *(*)()) F518_6443_5820_1;
	R5820[3] = (char *(*)()) F519_6443_5820_1;
	R5820[30] = (char *(*)()) F546_6546_5820_1;
	R5820[120] = (char *(*)()) F624_7839;
	R5820[121] = (char *(*)()) F625_7839_5820_1;
	R5820[122] = (char *(*)()) F626_7839_5820_1;
	R5820[123] = (char *(*)()) F627_7839_5820_1;
	R5820[124] = (char *(*)()) F628_7839_5820_1;
	R5820[125] = (char *(*)()) F629_7839_5820_1;
	R5820[126] = (char *(*)()) F630_7839_5820_1;
	R5820[127] = (char *(*)()) F631_7839_5820_1;
	R5820[128] = (char *(*)()) F632_7839_5820_1;
	R5820[129] = (char *(*)()) F633_7839_5820_1;
	R5820[130] = (char *(*)()) F634_7839_5820_1;
	R5820[131] = (char *(*)()) F635_7839_5820_1;
	R5820[132] = (char *(*)()) F648_7867;
	R5820[133] = (char *(*)()) F649_7867_5820_1;
	R5820[134] = (char *(*)()) F650_7873;
	R5820[135] = (char *(*)()) F651_7873_5820_1;
	R5820[136] = (char *(*)()) F652_7873;
	R5820[137] = (char *(*)()) F653_7873_5820_1;
	R5820[138] = (char *(*)()) F654_7873;
	R5820[139] = (char *(*)()) F655_7873_5820_1;
	R5820[140] = (char *(*)()) F656_7873_5820_1;
	R5820[141] = (char *(*)()) F657_7873_5820_1;
	R5820[142] = (char *(*)()) F658_7873_5820_1;
	R5820[155] = (char *(*)()) F659_7879;
	R5820[156] = (char *(*)()) F660_7879_5820_1;
	R5820[157] = (char *(*)()) F661_7879_5820_1;
	R5820[158] = (char *(*)()) F662_7879_5820_1;
	R5820[159] = (char *(*)()) F663_7879_5820_1;
	R5820[160] = (char *(*)()) F664_7879_5820_1;
	R5820[161] = (char *(*)()) F665_7879_5820_1;
	R5820[162] = (char *(*)()) F666_7879_5820_1;
	R5820[163] = (char *(*)()) F667_7879_5820_1;
	R5820[164] = (char *(*)()) F668_7879_5820_1;
	R5820[165] = (char *(*)()) F669_7879_5820_1;
	R5820[166] = (char *(*)()) F670_7879_5820_1;
	R5820[167] = (char *(*)()) F667_7879_5820_1;
	R5820[168] = (char *(*)()) F663_7879_5820_1;
	R5820[169] = (char *(*)()) F659_7879;
	R5820[170] = (char *(*)()) F660_7879_5820_1;
	R5820[171] = (char *(*)()) F661_7879_5820_1;
	R5820[172] = (char *(*)()) F662_7879_5820_1;
	R5820[173] = (char *(*)()) F663_7879_5820_1;
	R5820[174] = (char *(*)()) F664_7879_5820_1;
	R5820[175] = (char *(*)()) F665_7879_5820_1;
	R5820[176] = (char *(*)()) F666_7879_5820_1;
	R5820[177] = (char *(*)()) F667_7879_5820_1;
	R5820[178] = (char *(*)()) F668_7879_5820_1;
	R5820[179] = (char *(*)()) F669_7879_5820_1;
	R5820[180] = (char *(*)()) F670_7879_5820_1;
	R5820[181] = (char *(*)()) F659_7879;
	R5820[182] = (char *(*)()) F660_7879_5820_1;
	R5820[183] = (char *(*)()) F661_7879_5820_1;
	R5820[184] = (char *(*)()) F662_7879_5820_1;
	R5820[185] = (char *(*)()) F663_7879_5820_1;
	R5820[186] = (char *(*)()) F664_7879_5820_1;
	R5820[187] = (char *(*)()) F665_7879_5820_1;
	R5820[188] = (char *(*)()) F666_7879_5820_1;
	R5820[189] = (char *(*)()) F667_7879_5820_1;
	R5820[190] = (char *(*)()) F668_7879_5820_1;
	R5820[191] = (char *(*)()) F669_7879_5820_1;
	R5820[192] = (char *(*)()) F670_7879_5820_1;
	{long i; for (i = 352; i < 354; i++) R5820[i] = (char *(*)()) F867_8078_5820_1;}
}
static EIF_REFERENCE F518_6443_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F518_6443(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F519_6443_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F519_6443(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F546_6546_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F546_6546(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F625_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F625_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F626_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F626_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F627_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F627_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F628_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F628_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F629_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F629_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F630_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F630_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F631_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F631_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F632_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F632_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F633_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F633_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F634_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F634_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F635_7839_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F635_7839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_7867_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_7867(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F651_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F653_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F655_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F655_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F656_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F656_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F657_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_7873_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F658_7873(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F660_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F661_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1321, 0x00).id, 1321, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F662_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F663_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F664_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F665_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1330, 0x00).id, 1330, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1327, 0x00).id, 1327, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F667_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F668_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1324, 0x00).id, 1324, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F669_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1333, 0x00).id, 1333, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_7879_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F670_7879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F867_8078_5820_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F867_8078(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5821[354])();
void R5821_init () {
	R5821[0] = (char *(*)()) F516_6437;
	R5821[1] = (char *(*)()) F517_6444;
	R5821[2] = (char *(*)()) F518_6444;
	R5821[3] = (char *(*)()) F519_6444;
	R5821[30] = (char *(*)()) F546_6548;
	R5821[120] = (char *(*)()) F636_7857;
	R5821[121] = (char *(*)()) F637_7857;
	R5821[122] = (char *(*)()) F638_7857;
	R5821[123] = (char *(*)()) F639_7857;
	R5821[124] = (char *(*)()) F640_7857;
	R5821[125] = (char *(*)()) F641_7857;
	R5821[126] = (char *(*)()) F642_7857;
	R5821[127] = (char *(*)()) F643_7857;
	R5821[128] = (char *(*)()) F644_7857;
	R5821[129] = (char *(*)()) F645_7857;
	R5821[130] = (char *(*)()) F646_7857;
	R5821[131] = (char *(*)()) F647_7857;
	R5821[132] = (char *(*)()) F648_7868;
	R5821[133] = (char *(*)()) F649_7868;
	R5821[134] = (char *(*)()) F650_7876;
	R5821[135] = (char *(*)()) F651_7876;
	R5821[136] = (char *(*)()) F652_7876;
	R5821[137] = (char *(*)()) F653_7876;
	R5821[138] = (char *(*)()) F654_7876;
	R5821[139] = (char *(*)()) F655_7876;
	R5821[140] = (char *(*)()) F656_7876;
	R5821[141] = (char *(*)()) F657_7876;
	R5821[142] = (char *(*)()) F658_7876;
	R5821[155] = (char *(*)()) F659_7888;
	R5821[156] = (char *(*)()) F660_7888;
	R5821[157] = (char *(*)()) F661_7888;
	R5821[158] = (char *(*)()) F662_7888;
	R5821[159] = (char *(*)()) F663_7888;
	R5821[160] = (char *(*)()) F664_7888;
	R5821[161] = (char *(*)()) F665_7888;
	R5821[162] = (char *(*)()) F666_7888;
	R5821[163] = (char *(*)()) F667_7888;
	R5821[164] = (char *(*)()) F668_7888;
	R5821[165] = (char *(*)()) F669_7888;
	R5821[166] = (char *(*)()) F670_7888;
	R5821[167] = (char *(*)()) F667_7888;
	R5821[168] = (char *(*)()) F663_7888;
	R5821[169] = (char *(*)()) F659_7888;
	R5821[170] = (char *(*)()) F660_7888;
	R5821[171] = (char *(*)()) F661_7888;
	R5821[172] = (char *(*)()) F662_7888;
	R5821[173] = (char *(*)()) F663_7888;
	R5821[174] = (char *(*)()) F664_7888;
	R5821[175] = (char *(*)()) F665_7888;
	R5821[176] = (char *(*)()) F666_7888;
	R5821[177] = (char *(*)()) F667_7888;
	R5821[178] = (char *(*)()) F668_7888;
	R5821[179] = (char *(*)()) F669_7888;
	R5821[180] = (char *(*)()) F670_7888;
	R5821[181] = (char *(*)()) F659_7888;
	R5821[182] = (char *(*)()) F660_7888;
	R5821[183] = (char *(*)()) F661_7888;
	R5821[184] = (char *(*)()) F662_7888;
	R5821[185] = (char *(*)()) F663_7888;
	R5821[186] = (char *(*)()) F664_7888;
	R5821[187] = (char *(*)()) F665_7888;
	R5821[188] = (char *(*)()) F666_7888;
	R5821[189] = (char *(*)()) F667_7888;
	R5821[190] = (char *(*)()) F668_7888;
	R5821[191] = (char *(*)()) F669_7888;
	R5821[192] = (char *(*)()) F670_7888;
	{long i; for (i = 352; i < 354; i++) R5821[i] = (char *(*)()) F867_8079;}
}

char *(*R5822[354])();
void R5822_init () {
	R5822[0] = (char *(*)()) F516_6438;
	R5822[1] = (char *(*)()) F517_6445;
	R5822[2] = (char *(*)()) F518_6445;
	R5822[3] = (char *(*)()) F519_6445;
	R5822[30] = (char *(*)()) F546_6549;
	R5822[120] = (char *(*)()) F636_7865;
	R5822[121] = (char *(*)()) F637_7865;
	R5822[122] = (char *(*)()) F638_7865;
	R5822[123] = (char *(*)()) F639_7865;
	R5822[124] = (char *(*)()) F640_7865;
	R5822[125] = (char *(*)()) F641_7865;
	R5822[126] = (char *(*)()) F642_7865;
	R5822[127] = (char *(*)()) F643_7865;
	R5822[128] = (char *(*)()) F644_7865;
	R5822[129] = (char *(*)()) F645_7865;
	R5822[130] = (char *(*)()) F646_7865;
	R5822[131] = (char *(*)()) F647_7865;
	R5822[132] = (char *(*)()) F648_7870;
	R5822[133] = (char *(*)()) F649_7870;
	R5822[134] = (char *(*)()) F650_7877;
	R5822[135] = (char *(*)()) F651_7877;
	R5822[136] = (char *(*)()) F652_7877;
	R5822[137] = (char *(*)()) F653_7877;
	R5822[138] = (char *(*)()) F654_7877;
	R5822[139] = (char *(*)()) F655_7877;
	R5822[140] = (char *(*)()) F656_7877;
	R5822[141] = (char *(*)()) F657_7877;
	R5822[142] = (char *(*)()) F658_7877;
	R5822[155] = (char *(*)()) F659_7894;
	R5822[156] = (char *(*)()) F660_7894;
	R5822[157] = (char *(*)()) F661_7894;
	R5822[158] = (char *(*)()) F662_7894;
	R5822[159] = (char *(*)()) F663_7894;
	R5822[160] = (char *(*)()) F664_7894;
	R5822[161] = (char *(*)()) F665_7894;
	R5822[162] = (char *(*)()) F666_7894;
	R5822[163] = (char *(*)()) F667_7894;
	R5822[164] = (char *(*)()) F668_7894;
	R5822[165] = (char *(*)()) F669_7894;
	R5822[166] = (char *(*)()) F670_7894;
	R5822[167] = (char *(*)()) F667_7894;
	R5822[168] = (char *(*)()) F663_7894;
	R5822[169] = (char *(*)()) F659_7894;
	R5822[170] = (char *(*)()) F660_7894;
	R5822[171] = (char *(*)()) F661_7894;
	R5822[172] = (char *(*)()) F662_7894;
	R5822[173] = (char *(*)()) F663_7894;
	R5822[174] = (char *(*)()) F664_7894;
	R5822[175] = (char *(*)()) F665_7894;
	R5822[176] = (char *(*)()) F666_7894;
	R5822[177] = (char *(*)()) F667_7894;
	R5822[178] = (char *(*)()) F668_7894;
	R5822[179] = (char *(*)()) F669_7894;
	R5822[180] = (char *(*)()) F670_7894;
	R5822[181] = (char *(*)()) F659_7894;
	R5822[182] = (char *(*)()) F660_7894;
	R5822[183] = (char *(*)()) F661_7894;
	R5822[184] = (char *(*)()) F662_7894;
	R5822[185] = (char *(*)()) F663_7894;
	R5822[186] = (char *(*)()) F664_7894;
	R5822[187] = (char *(*)()) F665_7894;
	R5822[188] = (char *(*)()) F666_7894;
	R5822[189] = (char *(*)()) F667_7894;
	R5822[190] = (char *(*)()) F668_7894;
	R5822[191] = (char *(*)()) F669_7894;
	R5822[192] = (char *(*)()) F670_7894;
	{long i; for (i = 352; i < 354; i++) R5822[i] = (char *(*)()) F867_8085;}
}

static EIF_TYPE_INDEX Y5823_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype25[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype26[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype98[] = {1121,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype99[] = {1124,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype124[] = {1312,0xFFFF};
static EIF_TYPE_INDEX Y5823_pgtype125[] = {1312,0xFFFF};
EIF_TYPE_INDEX *Y5823_gen_type [366];
EIF_TYPE_INDEX Y5823 [366];
void Y5823_init (void)
{
	egc_routines_types [5823] = Y5823;
	egc_routines_gen_types [5823] = Y5823_gen_type;
	egc_routines_offset [5823] = 503;
	Y5823_gen_type [0] = Y5823_pgtype0;
	Y5823_gen_type [1] = Y5823_pgtype1;
	Y5823_gen_type [2] = Y5823_pgtype2;
	Y5823_gen_type [3] = Y5823_pgtype3;
	Y5823_gen_type [4] = Y5823_pgtype4;
	Y5823_gen_type [5] = Y5823_pgtype5;
	Y5823_gen_type [6] = Y5823_pgtype6;
	Y5823_gen_type [7] = Y5823_pgtype7;
	Y5823_gen_type [8] = Y5823_pgtype8;
	Y5823_gen_type [9] = Y5823_pgtype9;
	Y5823_gen_type [10] = Y5823_pgtype10;
	Y5823_gen_type [11] = Y5823_pgtype11;
	Y5823_gen_type [12] = Y5823_pgtype12;
	Y5823_gen_type [13] = Y5823_pgtype13;
	Y5823_gen_type [14] = Y5823_pgtype14;
	Y5823_gen_type [15] = Y5823_pgtype15;
	Y5823_gen_type [16] = Y5823_pgtype16;
	Y5823_gen_type [17] = Y5823_pgtype17;
	Y5823_gen_type [18] = Y5823_pgtype18;
	Y5823_gen_type [19] = Y5823_pgtype19;
	Y5823_gen_type [20] = Y5823_pgtype20;
	Y5823_gen_type [21] = Y5823_pgtype21;
	Y5823_gen_type [22] = Y5823_pgtype22;
	Y5823_gen_type [23] = Y5823_pgtype23;
	Y5823_gen_type [24] = Y5823_pgtype24;
	Y5823_gen_type [42] = Y5823_pgtype25;
	Y5823_gen_type [106] = Y5823_pgtype26;
	Y5823_gen_type [108] = Y5823_pgtype27;
	Y5823_gen_type [109] = Y5823_pgtype28;
	Y5823_gen_type [110] = Y5823_pgtype29;
	Y5823_gen_type [111] = Y5823_pgtype30;
	Y5823_gen_type [112] = Y5823_pgtype31;
	Y5823_gen_type [113] = Y5823_pgtype32;
	Y5823_gen_type [114] = Y5823_pgtype33;
	Y5823_gen_type [115] = Y5823_pgtype34;
	Y5823_gen_type [116] = Y5823_pgtype35;
	Y5823_gen_type [117] = Y5823_pgtype36;
	Y5823_gen_type [118] = Y5823_pgtype37;
	Y5823_gen_type [119] = Y5823_pgtype38;
	Y5823_gen_type [120] = Y5823_pgtype39;
	Y5823_gen_type [121] = Y5823_pgtype40;
	Y5823_gen_type [122] = Y5823_pgtype41;
	Y5823_gen_type [123] = Y5823_pgtype42;
	Y5823_gen_type [124] = Y5823_pgtype43;
	Y5823_gen_type [125] = Y5823_pgtype44;
	Y5823_gen_type [126] = Y5823_pgtype45;
	Y5823_gen_type [127] = Y5823_pgtype46;
	Y5823_gen_type [128] = Y5823_pgtype47;
	Y5823_gen_type [129] = Y5823_pgtype48;
	Y5823_gen_type [130] = Y5823_pgtype49;
	Y5823_gen_type [131] = Y5823_pgtype50;
	Y5823_gen_type [132] = Y5823_pgtype51;
	Y5823_gen_type [133] = Y5823_pgtype52;
	Y5823_gen_type [134] = Y5823_pgtype53;
	Y5823_gen_type [135] = Y5823_pgtype54;
	Y5823_gen_type [136] = Y5823_pgtype55;
	Y5823_gen_type [137] = Y5823_pgtype56;
	Y5823_gen_type [138] = Y5823_pgtype57;
	Y5823_gen_type [139] = Y5823_pgtype58;
	Y5823_gen_type [140] = Y5823_pgtype59;
	Y5823_gen_type [141] = Y5823_pgtype60;
	Y5823_gen_type [142] = Y5823_pgtype61;
	Y5823_gen_type [143] = Y5823_pgtype62;
	Y5823_gen_type [144] = Y5823_pgtype63;
	Y5823_gen_type [145] = Y5823_pgtype64;
	Y5823_gen_type [146] = Y5823_pgtype65;
	Y5823_gen_type [147] = Y5823_pgtype66;
	Y5823_gen_type [148] = Y5823_pgtype67;
	Y5823_gen_type [149] = Y5823_pgtype68;
	Y5823_gen_type [150] = Y5823_pgtype69;
	Y5823_gen_type [151] = Y5823_pgtype70;
	Y5823_gen_type [152] = Y5823_pgtype71;
	Y5823_gen_type [153] = Y5823_pgtype72;
	Y5823_gen_type [154] = Y5823_pgtype73;
	Y5823_gen_type [155] = Y5823_pgtype74;
	Y5823_gen_type [156] = Y5823_pgtype75;
	Y5823_gen_type [157] = Y5823_pgtype76;
	Y5823_gen_type [158] = Y5823_pgtype77;
	Y5823_gen_type [159] = Y5823_pgtype78;
	Y5823_gen_type [160] = Y5823_pgtype79;
	Y5823_gen_type [161] = Y5823_pgtype80;
	Y5823_gen_type [162] = Y5823_pgtype81;
	Y5823_gen_type [163] = Y5823_pgtype82;
	Y5823_gen_type [164] = Y5823_pgtype83;
	Y5823_gen_type [165] = Y5823_pgtype84;
	Y5823_gen_type [166] = Y5823_pgtype85;
	Y5823_gen_type [167] = Y5823_pgtype86;
	Y5823_gen_type [168] = Y5823_pgtype87;
	Y5823_gen_type [169] = Y5823_pgtype88;
	Y5823_gen_type [170] = Y5823_pgtype89;
	Y5823_gen_type [171] = Y5823_pgtype90;
	Y5823_gen_type [172] = Y5823_pgtype91;
	Y5823_gen_type [173] = Y5823_pgtype92;
	Y5823_gen_type [174] = Y5823_pgtype93;
	Y5823_gen_type [175] = Y5823_pgtype94;
	Y5823_gen_type [176] = Y5823_pgtype95;
	Y5823_gen_type [177] = Y5823_pgtype96;
	Y5823_gen_type [178] = Y5823_pgtype97;
	Y5823_gen_type [179] = Y5823_pgtype98;
	Y5823_gen_type [180] = Y5823_pgtype99;
	Y5823_gen_type [181] = Y5823_pgtype100;
	Y5823_gen_type [182] = Y5823_pgtype101;
	Y5823_gen_type [183] = Y5823_pgtype102;
	Y5823_gen_type [184] = Y5823_pgtype103;
	Y5823_gen_type [185] = Y5823_pgtype104;
	Y5823_gen_type [186] = Y5823_pgtype105;
	Y5823_gen_type [187] = Y5823_pgtype106;
	Y5823_gen_type [188] = Y5823_pgtype107;
	Y5823_gen_type [189] = Y5823_pgtype108;
	Y5823_gen_type [190] = Y5823_pgtype109;
	Y5823_gen_type [191] = Y5823_pgtype110;
	Y5823_gen_type [192] = Y5823_pgtype111;
	Y5823_gen_type [193] = Y5823_pgtype112;
	Y5823_gen_type [194] = Y5823_pgtype113;
	Y5823_gen_type [195] = Y5823_pgtype114;
	Y5823_gen_type [196] = Y5823_pgtype115;
	Y5823_gen_type [197] = Y5823_pgtype116;
	Y5823_gen_type [198] = Y5823_pgtype117;
	Y5823_gen_type [199] = Y5823_pgtype118;
	Y5823_gen_type [200] = Y5823_pgtype119;
	Y5823_gen_type [201] = Y5823_pgtype120;
	Y5823_gen_type [202] = Y5823_pgtype121;
	Y5823_gen_type [203] = Y5823_pgtype122;
	Y5823_gen_type [204] = Y5823_pgtype123;
	Y5823_gen_type [364] = Y5823_pgtype124;
	Y5823_gen_type [365] = Y5823_pgtype125;
	Y5823[42] = 1124;
	Y5823[106] = 1121;
	Y5823[179] = 1121;
	Y5823[180] = 1124;
	{long i; for (i = 364; i < 366; i++) Y5823[i] = 1312;};
}

char *(*R5828[3])();
void R5828_init () {
	R5828[0] = (char *(*)()) F517_6442;
	R5828[1] = (char *(*)()) F518_6442;
	R5828[2] = (char *(*)()) F519_6442;
}

char *(*R5831[9])();
void R5831_init () {
	R5831[0] = (char *(*)()) F650_7874;
	R5831[1] = (char *(*)()) F651_7874;
	R5831[2] = (char *(*)()) F652_7874_5831_1;
	R5831[3] = (char *(*)()) F653_7874;
	R5831[4] = (char *(*)()) F654_7874_5831_1;
	R5831[5] = (char *(*)()) F655_7874;
	R5831[6] = (char *(*)()) F656_7874_5831_1;
	R5831[7] = (char *(*)()) F657_7874;
	R5831[8] = (char *(*)()) F658_7874;
}
static EIF_REFERENCE F652_7874_5831_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_7874(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F654_7874_5831_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F654_7874(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1160, 0x00).id, 1160, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F656_7874_5831_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F656_7874(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5834[923])();
void R5834_init () {
	R5834[0] = (char *(*)()) F530_6450;
	R5834[379] = (char *(*)()) F909_8171;
	R5834[431] = (char *(*)()) F961_8617;
	R5834[432] = (char *(*)()) F962_8617;
	R5834[433] = (char *(*)()) F963_8617;
	R5834[434] = (char *(*)()) F964_8617;
	R5834[435] = (char *(*)()) F965_8617;
	R5834[436] = (char *(*)()) F966_8617;
	R5834[437] = (char *(*)()) F967_8617;
	R5834[438] = (char *(*)()) F968_8617;
	R5834[439] = (char *(*)()) F969_8617;
	{long i; for (i = 440; i < 442; i++) R5834[i] = (char *(*)()) F961_8617;}
	R5834[442] = (char *(*)()) F964_8617;
	R5834[443] = (char *(*)()) F968_8617;
	R5834[444] = (char *(*)()) F966_8617;
	R5834[445] = (char *(*)()) F969_8617;
	R5834[529] = (char *(*)()) F1059_8969;
	R5834[530] = (char *(*)()) F1060_8969;
	R5834[531] = (char *(*)()) F1061_8969;
	R5834[532] = (char *(*)()) F1062_8969;
	R5834[533] = (char *(*)()) F1063_8969;
	R5834[534] = (char *(*)()) F1064_8969;
	R5834[535] = (char *(*)()) F1065_8969;
	R5834[536] = (char *(*)()) F1066_8969;
	R5834[537] = (char *(*)()) F1067_8969;
	R5834[538] = (char *(*)()) F1068_8969;
	R5834[539] = (char *(*)()) F1069_8969;
	R5834[540] = (char *(*)()) F1070_8969;
	{long i; for (i = 541; i < 544; i++) R5834[i] = (char *(*)()) F1059_8969;}
	R5834[544] = (char *(*)()) F1062_8969;
	R5834[545] = (char *(*)()) F1059_8969;
	R5834[584] = (char *(*)()) F1114_9717;
	{long i; for (i = 633; i < 638; i++) R5834[i] = (char *(*)()) F1162_9973;}
	R5834[642] = (char *(*)()) F1172_10212;
	R5834[643] = (char *(*)()) F1173_10303;
	{long i; for (i = 646; i < 648; i++) R5834[i] = (char *(*)()) F1176_10467;}
	R5834[893] = (char *(*)()) F531_6461;
	R5834[898] = (char *(*)()) F531_6461;
	R5834[922] = (char *(*)()) F1176_10467;
}

char *(*R6121[2])();
void R6121_init () {
	R6121[0] = (char *(*)()) F555_6799;
	R6121[1] = (char *(*)()) F556_6800;
}

char *(*R6136[3])();
void R6136_init () {
	R6136[0] = (char *(*)()) F558_6819;
	R6136[1] = (char *(*)()) F559_6823;
	R6136[2] = (char *(*)()) F560_6830;
}

char *(*R6137[3])();
void R6137_init () {
	{long i; for (i = 0; i < 2; i++) R6137[i] = (char *(*)()) F558_6820;}
	R6137[2] = (char *(*)()) F560_6831;
}

char *(*R6138[3])();
void R6138_init () {
	R6138[0] = (char *(*)()) F558_6821;
	{long i; for (i = 1; i < 3; i++) R6138[i] = (char *(*)()) F559_6824;}
}

char *(*R6146[3])();
void R6146_init () {
	R6146[0] = (char *(*)()) F558_6822;
	{long i; for (i = 1; i < 3; i++) R6146[i] = (char *(*)()) F559_6825;}
}

char *(*R6221[792])();
void R6221_init () {
	R6221[0] = (char *(*)()) F563_6906;
	{long i; for (i = 5; i < 7; i++) R6221[i] = (char *(*)()) F563_6906;}
	R6221[373] = (char *(*)()) F937_8422;
	R6221[374] = (char *(*)()) F563_6906;
	R6221[791] = (char *(*)()) F937_8422;
}

char *(*R6239[787])();
void R6239_init () {
	{long i; for (i = 0; i < 2; i++) R6239[i] = (char *(*)()) F567_7230;}
	{long i; for (i = 368; i < 370; i++) R6239[i] = (char *(*)()) F936_8227;}
	R6239[786] = (char *(*)()) F1355_12648;
}

char *(*R6245[792])();
void R6245_init () {
	R6245[0] = (char *(*)()) F564_7005;
	{long i; for (i = 5; i < 7; i++) R6245[i] = (char *(*)()) F565_7145;}
	{long i; for (i = 373; i < 375; i++) R6245[i] = (char *(*)()) F916_8184;}
	R6245[791] = (char *(*)()) F916_8184;
}

char *(*R6247[792])();
void R6247_init () {
	R6247[0] = (char *(*)()) F564_7000;
	{long i; for (i = 5; i < 7; i++) R6247[i] = (char *(*)()) F567_7236;}
	{long i; for (i = 373; i < 375; i++) R6247[i] = (char *(*)()) F936_8251;}
	R6247[791] = (char *(*)()) F936_8251;
}

char *(*R6249[792])();
void R6249_init () {
	R6249[0] = (char *(*)()) F564_6999;
	{long i; for (i = 5; i < 7; i++) R6249[i] = (char *(*)()) F565_7097;}
	{long i; for (i = 373; i < 375; i++) R6249[i] = (char *(*)()) F936_8279;}
	R6249[791] = (char *(*)()) F936_8279;
}

char *(*R6250[419])();
void R6250_init () {
	{long i; for (i = 0; i < 2; i++) R6250[i] = (char *(*)()) F936_8306;}
	R6250[418] = (char *(*)()) F1355_12679;
}

char *(*R6251[419])();
void R6251_init () {
	{long i; for (i = 0; i < 2; i++) R6251[i] = (char *(*)()) F936_8307;}
	R6251[418] = (char *(*)()) F1355_12680;
}


#ifdef __cplusplus
}
#endif
