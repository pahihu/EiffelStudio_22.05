#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1913_gen_type [2];
EIF_TYPE_INDEX Y1913 [2];
void Y1913_init (void)
{
	egc_routines_types [1913] = Y1913;
	egc_routines_gen_types [1913] = Y1913_gen_type;
	egc_routines_offset [1913] = 106;
	Y1913[0] = 215;
	Y1913[1] = 216;
}

long O2259[2];
void O2259_init () {
	O2259[0] = 0;
	O2259[1] =  + _REFACS_22_;
}

long O2260[2];
void O2260_init () {
	O2260[0] = + _LNGOFF_12_0_0_0_;
	O2260[1] = + _LNGOFF_35_0_0_1_;
}

long O2264[2];
void O2264_init () {
	O2264[0] =  + _REFACS_1_;
	O2264[1] =  + _REFACS_23_;
}

long O2265[2];
void O2265_init () {
	O2265[0] = + _LNGOFF_12_0_0_1_;
	O2265[1] = + _LNGOFF_35_0_0_2_;
}

long O2266[2];
void O2266_init () {
	O2266[0] =  + _REFACS_2_;
	O2266[1] =  + _REFACS_24_;
}

long O2267[2];
void O2267_init () {
	O2267[0] =  + _REFACS_3_;
	O2267[1] =  + _REFACS_25_;
}

long O2268[2];
void O2268_init () {
	O2268[0] =  + _REFACS_4_;
	O2268[1] =  + _REFACS_26_;
}

long O2269[2];
void O2269_init () {
	O2269[0] =  + _REFACS_5_;
	O2269[1] =  + _REFACS_27_;
}

long O2270[2];
void O2270_init () {
	O2270[0] =  + _REFACS_6_;
	O2270[1] =  + _REFACS_28_;
}

long O2271[2];
void O2271_init () {
	O2271[0] =  + _REFACS_7_;
	O2271[1] =  + _REFACS_29_;
}

long O2272[2];
void O2272_init () {
	O2272[0] = + _LNGOFF_12_0_0_2_;
	O2272[1] = + _LNGOFF_35_0_0_3_;
}

long O2276[2];
void O2276_init () {
	O2276[0] =  + _REFACS_8_;
	O2276[1] =  + _REFACS_30_;
}

long O2277[2];
void O2277_init () {
	O2277[0] = + _LNGOFF_12_0_0_3_;
	O2277[1] = + _LNGOFF_35_0_0_4_;
}

long O2278[2];
void O2278_init () {
	O2278[0] =  + _REFACS_9_;
	O2278[1] =  + _REFACS_31_;
}

long O2279[2];
void O2279_init () {
	O2279[0] =  + _REFACS_10_;
	O2279[1] =  + _REFACS_32_;
}

long O2280[2];
void O2280_init () {
	O2280[0] =  + _REFACS_11_;
	O2280[1] =  + _REFACS_33_;
}

long O3052[7];
void O3052_init () {
	O3052[0] = 0;
	O3052[1] = + _LNGOFF_0_0_0_0_;
	O3052[2] = + _CHROFF_0_0_;
	O3052[3] = + _LNGOFF_0_0_0_0_;
	O3052[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O3052[5] = 0;
	O3052[6] = + _LNGOFF_1_0_0_0_;
}

long O3056[2];
void O3056_init () {
	O3056[0] =  + _REFACS_1_;
	O3056[1] = 0;
}

long O3107[3];
void O3107_init () {
	O3107[0] = + _LNGOFF_1_0_0_0_;
	O3107[1] = + _LNGOFF_2_0_0_0_;
	O3107[2] = + _LNGOFF_1_0_0_0_;
}

long O3111[3];
void O3111_init () {
	O3111[0] = + _LNGOFF_1_0_0_1_;
	O3111[1] = + _LNGOFF_2_0_0_1_;
	O3111[2] = + _LNGOFF_1_0_0_1_;
}

long O3214[1200];
void O3214_init () {
	O3214[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 1195; i < 1197; i++) O3214[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O3214[1197] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O3214[1198] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O3214[1199] = + _R64OFF_2_0_0_2_0_0_0_0_;
}

long O3215[1200];
void O3215_init () {
	O3215[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1195; i < 1198; i++) O3215[i] = + _LNGOFF_0_0_0_0_;}
	O3215[1198] = + _LNGOFF_5_1_0_0_;
	O3215[1199] = + _LNGOFF_2_0_0_0_;
}

static EIF_TYPE_INDEX Y3255_pgtype0[] = {0xFF01,228,0xFFFF};
static EIF_TYPE_INDEX Y3255_pgtype1[] = {0xFF01,1424,0xFFFF};
EIF_TYPE_INDEX *Y3255_gen_type [1196];
EIF_TYPE_INDEX Y3255 [1196];
void Y3255_init (void)
{
	egc_routines_types [3255] = Y3255;
	egc_routines_gen_types [3255] = Y3255_gen_type;
	egc_routines_offset [3255] = 232;
	Y3255_gen_type [0] = Y3255_pgtype0;
	Y3255_gen_type [1195] = Y3255_pgtype1;
	Y3255[0] = 228;
	Y3255[1195] = 1424;
}

static EIF_TYPE_INDEX Y3256_pgtype0[] = {0xFF01,530,0xFFFF};
static EIF_TYPE_INDEX Y3256_pgtype1[] = {0xFF01,1422,0xFFFF};
EIF_TYPE_INDEX *Y3256_gen_type [1196];
EIF_TYPE_INDEX Y3256 [1196];
void Y3256_init (void)
{
	egc_routines_types [3256] = Y3256;
	egc_routines_gen_types [3256] = Y3256_gen_type;
	egc_routines_offset [3256] = 232;
	Y3256_gen_type [0] = Y3256_pgtype0;
	Y3256_gen_type [1195] = Y3256_pgtype1;
	Y3256[0] = 530;
	Y3256[1195] = 1422;
}

long O3321[217];
void O3321_init () {
	O3321[0] = + _PTROFF_1_1_0_0_0_0_;
	O3321[1] = + _PTROFF_3_2_0_1_0_0_;
	{long i; for (i = 213; i < 216; i++) O3321[i] = + _PTROFF_3_2_0_2_0_0_;}
	O3321[216] = + _PTROFF_3_3_0_2_0_0_;
}

long O3322[217];
void O3322_init () {
	O3322[0] = + _CHROFF_1_0_;
	O3322[1] = + _CHROFF_3_0_;
	{long i; for (i = 213; i < 216; i++) O3322[i] = + _CHROFF_3_0_;}
	O3322[216] = + _CHROFF_3_1_;
}

long O3337[217];
void O3337_init () {
	{long i; for (i = 0; i < 2; i++) O3337[i] = 0;}
	{long i; for (i = 213; i < 216; i++) O3337[i] = 0;}
	O3337[216] =  + _REFACS_1_;
}

long O3781[3];
void O3781_init () {
	O3781[0] = + _CHROFF_3_0_;
	O3781[1] = + _CHROFF_4_0_;
	O3781[2] = + _CHROFF_5_0_;
}

long O3799[3];
void O3799_init () {
	O3799[0] = + _CHROFF_3_1_;
	O3799[1] = + _CHROFF_4_1_;
	O3799[2] = + _CHROFF_5_1_;
}

long O3839[4];
void O3839_init () {
	O3839[0] = + _CHROFF_2_0_;
	O3839[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3839[i] = + _CHROFF_2_0_;}
}

long O3840[4];
void O3840_init () {
	O3840[0] = + _CHROFF_2_1_;
	O3840[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3840[i] = + _CHROFF_2_1_;}
}

long O5058[950];
void O5058_init () {
	O5058[0] = 0;
	{long i; for (i = 1; i < 3; i++) O5058[i] =  + _REFACS_1_;}
	O5058[169] =  + _REFACS_1_;
	O5058[949] = 0;
}

long O5180[827];
void O5180_init () {
	{long i; for (i = 0; i < 11; i++) O5180[i] = 0;}
	{long i; for (i = 817; i < 827; i++) O5180[i] =  + _REFACS_1_;}
}

long O5560[654];
void O5560_init () {
	O5560[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1; i < 4; i++) O5560[i] = + _LNGOFF_3_2_0_1_;}
	O5560[4] = + _LNGOFF_3_3_0_1_;
	{long i; for (i = 5; i < 8; i++) O5560[i] = + _LNGOFF_0_0_0_0_;}
	O5560[98] = + _LNGOFF_15_11_0_0_;
	O5560[651] = + _LNGOFF_13_16_0_0_;
	O5560[653] = + _LNGOFF_21_18_0_0_;
}

static EIF_TYPE_INDEX Y5594_pgtype0[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype1[] = {0xFF01,1231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype2[] = {0xFF01,1232,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype3[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype4[] = {0xFF01,1234,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype5[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype6[] = {0xFF01,1236,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype7[] = {0xFF01,1237,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype8[] = {0xFF01,1238,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype9[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype10[] = {0xFF01,1240,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype11[] = {0xFF01,1241,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype12[] = {0xFF01,1235,1127,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype13[] = {0xFF01,1236,1330,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype14[] = {0xFF01,1236,1330,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype15[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype16[] = {0xFF01,1231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype17[] = {0xFF01,1232,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype18[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype19[] = {0xFF01,1234,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype20[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype21[] = {0xFF01,1236,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype22[] = {0xFF01,1237,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype23[] = {0xFF01,1238,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype24[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype25[] = {0xFF01,1240,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype26[] = {0xFF01,1241,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype27[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype28[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype29[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype30[] = {0xFF01,1234,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype31[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype32[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype33[] = {0xFF01,1231,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype34[] = {0xFF01,1232,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype35[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype36[] = {0xFF01,1234,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype37[] = {0xFF01,1235,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype38[] = {0xFF01,1236,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype39[] = {0xFF01,1237,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype40[] = {0xFF01,1238,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype41[] = {0xFF01,1239,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype42[] = {0xFF01,1240,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype43[] = {0xFF01,1241,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype44[] = {0xFF01,1230,0xFF01,1406,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype45[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype46[] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype47[] = {0xFF01,1233,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype48[] = {0xFF01,1230,0xFF01,1074,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype49[] = {0xFF01,1238,1121,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype50[] = {0xFF01,1234,1124,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype51[] = {0xFF01,1234,1124,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype52[] = {0xFF01,1234,1124,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype53[] = {0xFF01,1234,1124,0xFFFF};
static EIF_TYPE_INDEX Y5594_pgtype54[] = {0xFF01,1234,1124,0xFFFF};
EIF_TYPE_INDEX *Y5594_gen_type [991];
EIF_TYPE_INDEX Y5594 [991];
void Y5594_init (void)
{
	egc_routines_types [5594] = Y5594;
	egc_routines_gen_types [5594] = Y5594_gen_type;
	egc_routines_offset [5594] = 462;
	Y5594_gen_type [0] = Y5594_pgtype0;
	Y5594_gen_type [1] = Y5594_pgtype1;
	Y5594_gen_type [2] = Y5594_pgtype2;
	Y5594_gen_type [3] = Y5594_pgtype3;
	Y5594_gen_type [4] = Y5594_pgtype4;
	Y5594_gen_type [5] = Y5594_pgtype5;
	Y5594_gen_type [6] = Y5594_pgtype6;
	Y5594_gen_type [7] = Y5594_pgtype7;
	Y5594_gen_type [8] = Y5594_pgtype8;
	Y5594_gen_type [9] = Y5594_pgtype9;
	Y5594_gen_type [10] = Y5594_pgtype10;
	Y5594_gen_type [11] = Y5594_pgtype11;
	Y5594_gen_type [12] = Y5594_pgtype12;
	Y5594_gen_type [13] = Y5594_pgtype13;
	Y5594_gen_type [14] = Y5594_pgtype14;
	Y5594_gen_type [526] = Y5594_pgtype15;
	Y5594_gen_type [527] = Y5594_pgtype16;
	Y5594_gen_type [528] = Y5594_pgtype17;
	Y5594_gen_type [529] = Y5594_pgtype18;
	Y5594_gen_type [530] = Y5594_pgtype19;
	Y5594_gen_type [531] = Y5594_pgtype20;
	Y5594_gen_type [532] = Y5594_pgtype21;
	Y5594_gen_type [533] = Y5594_pgtype22;
	Y5594_gen_type [534] = Y5594_pgtype23;
	Y5594_gen_type [535] = Y5594_pgtype24;
	Y5594_gen_type [536] = Y5594_pgtype25;
	Y5594_gen_type [537] = Y5594_pgtype26;
	Y5594_gen_type [538] = Y5594_pgtype27;
	Y5594_gen_type [539] = Y5594_pgtype28;
	Y5594_gen_type [540] = Y5594_pgtype29;
	Y5594_gen_type [541] = Y5594_pgtype30;
	Y5594_gen_type [542] = Y5594_pgtype31;
	Y5594_gen_type [596] = Y5594_pgtype32;
	Y5594_gen_type [597] = Y5594_pgtype33;
	Y5594_gen_type [598] = Y5594_pgtype34;
	Y5594_gen_type [599] = Y5594_pgtype35;
	Y5594_gen_type [600] = Y5594_pgtype36;
	Y5594_gen_type [601] = Y5594_pgtype37;
	Y5594_gen_type [602] = Y5594_pgtype38;
	Y5594_gen_type [603] = Y5594_pgtype39;
	Y5594_gen_type [604] = Y5594_pgtype40;
	Y5594_gen_type [605] = Y5594_pgtype41;
	Y5594_gen_type [606] = Y5594_pgtype42;
	Y5594_gen_type [607] = Y5594_pgtype43;
	Y5594_gen_type [608] = Y5594_pgtype44;
	Y5594_gen_type [609] = Y5594_pgtype45;
	Y5594_gen_type [610] = Y5594_pgtype46;
	Y5594_gen_type [611] = Y5594_pgtype47;
	Y5594_gen_type [612] = Y5594_pgtype48;
	Y5594_gen_type [710] = Y5594_pgtype49;
	Y5594_gen_type [713] = Y5594_pgtype50;
	Y5594_gen_type [714] = Y5594_pgtype51;
	Y5594_gen_type [715] = Y5594_pgtype52;
	Y5594_gen_type [989] = Y5594_pgtype53;
	Y5594_gen_type [990] = Y5594_pgtype54;
	Y5594[0] = 1230;
	Y5594[1] = 1231;
	Y5594[2] = 1232;
	Y5594[3] = 1233;
	Y5594[4] = 1234;
	Y5594[5] = 1235;
	Y5594[6] = 1236;
	Y5594[7] = 1237;
	Y5594[8] = 1238;
	Y5594[9] = 1239;
	Y5594[10] = 1240;
	Y5594[11] = 1241;
	Y5594[12] = 1235;
	{long i; for (i = 13; i < 15; i++) Y5594[i] = 1236;};
	Y5594[526] = 1230;
	Y5594[527] = 1231;
	Y5594[528] = 1232;
	Y5594[529] = 1233;
	Y5594[530] = 1234;
	Y5594[531] = 1235;
	Y5594[532] = 1236;
	Y5594[533] = 1237;
	Y5594[534] = 1238;
	Y5594[535] = 1239;
	Y5594[536] = 1240;
	Y5594[537] = 1241;
	Y5594[538] = 1230;
	Y5594[539] = 1233;
	Y5594[540] = 1235;
	Y5594[541] = 1234;
	Y5594[542] = 1239;
	Y5594[596] = 1230;
	Y5594[597] = 1231;
	Y5594[598] = 1232;
	Y5594[599] = 1233;
	Y5594[600] = 1234;
	Y5594[601] = 1235;
	Y5594[602] = 1236;
	Y5594[603] = 1237;
	Y5594[604] = 1238;
	Y5594[605] = 1239;
	Y5594[606] = 1240;
	Y5594[607] = 1241;
	{long i; for (i = 608; i < 611; i++) Y5594[i] = 1230;};
	Y5594[611] = 1233;
	Y5594[612] = 1230;
	Y5594[710] = 1238;
	{long i; for (i = 713; i < 716; i++) Y5594[i] = 1234;};
	{long i; for (i = 989; i < 991; i++) Y5594[i] = 1234;};
}

long O5836[898];
void O5836_init () {
	O5836[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 891; i < 893; i++) O5836[i] = + _LNGOFF_0_0_0_0_;}
	O5836[895] = + _LNGOFF_0_0_0_1_;
	O5836[896] = + _LNGOFF_5_1_0_1_;
	O5836[897] = + _LNGOFF_2_0_0_1_;
}

long O6155[617];
void O6155_init () {
	O6155[0] = + _LNGOFF_0_0_0_0_;
	O6155[616] = + _LNGOFF_1_1_0_0_;
}


#ifdef __cplusplus
}
#endif
