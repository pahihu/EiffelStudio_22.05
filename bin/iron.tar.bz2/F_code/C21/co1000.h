
#ifndef _C21_co1000_
#define _C21_co1000_

#ifdef __cplusplus
extern "C" {
#endif

extern void F766_8013(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1000(void);
extern char *(*R7040[])();
extern char *(*R7042[])();
extern char *(*R7043[])();
extern char *(*R7044[])();
extern char *(*R7057[])();
extern char *(*R7060[])();
extern char *(*R7064[])();

#ifdef __cplusplus
}
#endif

#endif
