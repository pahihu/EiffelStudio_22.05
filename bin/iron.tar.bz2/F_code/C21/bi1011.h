
#ifndef _C21_bi1011_
#define _C21_bi1011_

#ifdef __cplusplus
extern "C" {
#endif

extern void F754_8007(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1011(void);
extern void F742_7990(EIF_REFERENCE, EIF_CHARACTER_8);
extern char *(*R7034[])();
extern char *(*R7057[])();
extern char *(*R7058[])();

#ifdef __cplusplus
}
#endif

#endif
