
#ifndef _C21_to1007_
#define _C21_to1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F467_6100(EIF_REFERENCE, EIF_INTEGER_32);
extern void F467_6101(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F467_6107(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern void F1235_11098(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5594[];
extern EIF_TYPE_INDEX *Y5594_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
