
#ifndef _C21_dy1013_
#define _C21_dy1013_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1022_8812(EIF_REFERENCE);
extern void F1022_8818(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1013(void);
extern EIF_BOOLEAN F742_7994(EIF_REFERENCE);
extern void F1063_8962(EIF_REFERENCE);
extern void F1063_8945(EIF_REFERENCE, EIF_CHARACTER_8);

#ifdef __cplusplus
}
#endif

#endif
