
#ifndef _C21_re1046_
#define _C21_re1046_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F899_8135(EIF_REFERENCE);
extern void F899_8137(EIF_REFERENCE);
extern void EIF_Minit1046(void);
extern char *(*R7147[])();
extern char *(*R7141[])();

#ifdef __cplusplus
}
#endif

#endif
