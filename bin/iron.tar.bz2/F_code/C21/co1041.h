
#ifndef _C21_co1041_
#define _C21_co1041_

#ifdef __cplusplus
extern "C" {
#endif

extern void F767_8013(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern EIF_BOOLEAN F1064_8913(EIF_REFERENCE);
extern EIF_BOOLEAN F1011_8803(EIF_REFERENCE);
extern void F1064_8939(EIF_REFERENCE);
extern void F1064_8941(EIF_REFERENCE);
extern char *(*R7040[])();
extern char *(*R7060[])();
extern char *(*R7064[])();

#ifdef __cplusplus
}
#endif

#endif
