
#ifndef _C21_sp1036_
#define _C21_sp1036_

#ifdef __cplusplus
extern "C" {
#endif

extern void F702_7923(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F702_7924(EIF_REFERENCE);
extern EIF_REFERENCE F702_7925(EIF_REFERENCE);
extern EIF_INTEGER_32 F702_7926(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern EIF_INTEGER_32 F1236_11109(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
