
#ifndef _C21_fi1002_
#define _C21_fi1002_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F874_8129(EIF_REFERENCE);
extern void EIF_Minit1002(void);
extern char *(*R7140[])();

#ifdef __cplusplus
}
#endif

#endif
