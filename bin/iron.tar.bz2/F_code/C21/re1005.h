
#ifndef _C21_re1005_
#define _C21_re1005_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F898_8135(EIF_REFERENCE);
extern void F898_8137(EIF_REFERENCE);
extern void EIF_Minit1005(void);
extern char *(*R7147[])();
extern char *(*R7141[])();

#ifdef __cplusplus
}
#endif

#endif
