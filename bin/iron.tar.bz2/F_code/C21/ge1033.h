
#ifndef _C21_ge1033_
#define _C21_ge1033_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F664_7879(EIF_REFERENCE);
extern EIF_INTEGER_32 F664_7881(EIF_REFERENCE);
extern EIF_BOOLEAN F664_7888(EIF_REFERENCE);
extern EIF_BOOLEAN F664_7891(EIF_REFERENCE);
extern EIF_BOOLEAN F664_7892(EIF_REFERENCE);
extern void F664_7893(EIF_REFERENCE);
extern void F664_7894(EIF_REFERENCE);
extern EIF_REFERENCE F664_7895(EIF_REFERENCE);
extern void EIF_Minit1033(void);
extern char *(*R6977[])();
extern char *(*R6950[])();
extern long O6976[];
extern long O6978[];

#ifdef __cplusplus
}
#endif

#endif
