
#ifndef _C21_ty1032_
#define _C21_ty1032_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F629_7839(EIF_REFERENCE);
extern void EIF_Minit1032(void);
extern char *(*R6962[])();
extern char *(*R6949[])();
extern char *(*R7374[])();

#ifdef __cplusplus
}
#endif

#endif
