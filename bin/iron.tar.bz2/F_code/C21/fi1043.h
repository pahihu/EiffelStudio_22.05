
#ifndef _C21_fi1043_
#define _C21_fi1043_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F875_8129(EIF_REFERENCE);
extern void EIF_Minit1043(void);
extern char *(*R7140[])();

#ifdef __cplusplus
}
#endif

#endif
