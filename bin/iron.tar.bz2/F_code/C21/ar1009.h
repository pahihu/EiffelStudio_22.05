
#ifndef _C21_ar1009_
#define _C21_ar1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F675_7899(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F675_7900(EIF_REFERENCE);
extern EIF_REFERENCE F675_7901(EIF_REFERENCE);
extern EIF_REFERENCE F675_7903(EIF_REFERENCE);
extern EIF_INTEGER_32 F675_7904(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern EIF_REFERENCE F1063_8912(EIF_REFERENCE);
extern EIF_INTEGER_32 F1063_8931(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
