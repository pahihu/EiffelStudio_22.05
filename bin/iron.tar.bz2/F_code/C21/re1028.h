
#ifndef _C21_re1028_
#define _C21_re1028_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F954_8553(EIF_REFERENCE);
extern void EIF_Minit1028(void);
extern void F641_7845(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6961[])();
extern EIF_TYPE_INDEX Y6831[];
extern EIF_TYPE_INDEX *Y6831_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
