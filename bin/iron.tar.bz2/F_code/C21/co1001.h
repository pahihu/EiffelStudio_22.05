
#ifndef _C21_co1001_
#define _C21_co1001_

#ifdef __cplusplus
extern "C" {
#endif

extern void F718_7977(EIF_REFERENCE);
extern EIF_INTEGER_32 F718_7980(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern char *(*R7375[])();
extern char *(*R7376[])();
extern char *(*R7140[])();
extern long O7036[];
extern EIF_TYPE_INDEX Y6831[];
extern EIF_TYPE_INDEX *Y6831_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
