
#ifndef _C21_to1048_
#define _C21_to1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F468_6100(EIF_REFERENCE, EIF_INTEGER_32);
extern void F468_6101(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F468_6107(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern void F1236_11098(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5594[];
extern EIF_TYPE_INDEX *Y5594_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
