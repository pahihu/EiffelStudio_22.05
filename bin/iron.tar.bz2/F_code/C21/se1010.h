
#ifndef _C21_se1010_
#define _C21_se1010_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F916_8184(EIF_REFERENCE);
extern void F916_8186(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1010(void);
extern char *(*R7043[])();
extern char *(*R7064[])();

#ifdef __cplusplus
}
#endif

#endif
