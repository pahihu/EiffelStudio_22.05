
#ifndef _C21_ar1026_
#define _C21_ar1026_

#ifdef __cplusplus
extern "C" {
#endif

extern void F690_7917(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F690_7918(EIF_REFERENCE);
extern EIF_REFERENCE F690_7919(EIF_REFERENCE);
extern EIF_REFERENCE F690_7921(EIF_REFERENCE);
extern EIF_INTEGER_32 F690_7922(EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
