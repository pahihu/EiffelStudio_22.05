
#ifndef _C10_me465_
#define _C10_me465_

#ifdef __cplusplus
extern "C" {
#endif

extern void F552_6695(EIF_REFERENCE);
extern void F552_6706(EIF_REFERENCE);
extern void EIF_Minit465(void);

#ifdef __cplusplus
}
#endif

#endif
