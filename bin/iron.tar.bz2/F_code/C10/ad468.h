
#ifndef _C10_ad468_
#define _C10_ad468_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F555_6784(EIF_REFERENCE);extern EIF_INTEGER_32 en_addrinfo_ai_family(EIF_POINTER);

extern EIF_POINTER F555_6789(EIF_REFERENCE);extern EIF_POINTER en_addrinfo_ai_addr(EIF_POINTER);

extern EIF_REFERENCE F555_6790(EIF_REFERENCE);extern EIF_POINTER en_addrinfo_ai_next(EIF_POINTER);

extern EIF_INTEGER_32 F555_6792(EIF_REFERENCE, EIF_POINTER);extern EIF_INTEGER_32 en_addrinfo_ai_family(EIF_POINTER);

extern EIF_POINTER F555_6797(EIF_REFERENCE, EIF_POINTER);extern EIF_POINTER en_addrinfo_ai_addr(EIF_POINTER);

extern EIF_POINTER F555_6798(EIF_REFERENCE, EIF_POINTER);extern EIF_POINTER en_addrinfo_ai_next(EIF_POINTER);

extern void F555_6799(EIF_REFERENCE, EIF_POINTER);extern void en_free_addrinfo(EIF_POINTER);

extern void EIF_Minit468(void);
extern void F554_6779(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
