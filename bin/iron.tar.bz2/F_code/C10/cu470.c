/*
 * Code for class CURL_FUNCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu470.h"
#include <eiffel_curl.h>
#include "../C10/cu471.h"
#include "eiffel_curl.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F557_6803
static void inline_F557_6803 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
		(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
								((CURL *) arg2,
								(CURLoption)CURLOPT_DEBUGFUNCTION,
								curl_debug_function);
	#else
			/* Using proper calling convention for dynamic module */
		(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
								((CURL *) arg2,
								(CURLoption)CURLOPT_DEBUGFUNCTION,
								curl_debug_function);
	#endif
	;
}
#define INLINE_F557_6803
#endif
#ifndef INLINE_F557_6804
static void inline_F557_6804 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_WRITEFUNCTION,
							curl_write_function);
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_WRITEFUNCTION,
							curl_write_function);
#endif
	;
}
#define INLINE_F557_6804
#endif
#ifndef INLINE_F557_6805
static void inline_F557_6805 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_READFUNCTION,
							curl_read_function);
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_READFUNCTION,
							curl_read_function);				
#endif
	;
}
#define INLINE_F557_6805
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_FUNCTION}.set_object_and_function_address */
void F557_6801 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	c_set_object((EIF_REFERENCE) Current);
	c_set_progress_function_address((EIF_POINTER) F558_6818);
	c_set_write_function_address((EIF_POINTER) A470_39);
	c_set_read_function_address((EIF_POINTER) A470_40);
	c_set_debug_function_address((EIF_POINTER) A470_41);
	RTLE;
}

/* {CURL_FUNCTION}.c_set_debug_function */
void F557_6803 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F557_6803 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_FUNCTION}.c_set_write_function */
void F557_6804 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F557_6804 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_FUNCTION}.c_set_read_function */
void F557_6805 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F557_6805 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_FUNCTION}.c_set_object */
void F557_6810 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	c_set_object((EIF_REFERENCE) arg1);
	
}

/* {CURL_FUNCTION}.c_release_object */
void F557_6811 (EIF_REFERENCE Current)
{
	GTCX
	
	c_release_object();
	
}

/* {CURL_FUNCTION}.c_set_progress_function_address */
void F557_6812 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	c_set_progress_function_address(arg1);
	
}

/* {CURL_FUNCTION}.c_set_write_function_address */
void F557_6813 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	c_set_write_function_address(arg1);
	
}

/* {CURL_FUNCTION}.c_set_read_function_address */
void F557_6814 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	c_set_read_function_address(arg1);
	
}

/* {CURL_FUNCTION}.c_set_debug_function_address */
void F557_6815 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	c_set_debug_function_address(arg1);
	
}

/* {CURL_FUNCTION}.dispose */
void F557_6816 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	c_release_object();
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	c_set_object((EIF_REFERENCE) tp2);
	RTLE;
}

void EIF_Minit470 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
