/*
 * Code for class CONF_ERROR_PARSE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co495.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ERROR_PARSE}.text */
EIF_REFERENCE F582_7393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS32_EX_H("P\000\000\000a\000\000\000r\000\000\000s\000\000\000e\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",11,62499698);
	F1171_10139(RTCW(Result), tr1);
	switch (*(EIF_INTEGER_32 *)(Current + O6544[dtype-581])) {
		case 1L:
			tr1 = RTMS32_EX_H(" \000\000\000(\000\000\000X\000\000\000M\000\000\000L\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000)\000\000\000 \000\000\000",14,1829568544);
			F1173_10252(RTCW(Result), tr1);
			break;
		case 2L:
			tr1 = RTMS32_EX_H(" \000\000\000(\000\000\000A\000\000\000C\000\000\000E\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000)\000\000\000 \000\000\000",14,1394758688);
			F1173_10252(RTCW(Result), tr1);
			break;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS32_EX_H(" \000\000\000i\000\000\000n\000\000\000 \000\000\000",4,543780384);
		tr1 = F1173_10271(tr1, loc1);
		tr2 = RTMS32_EX_H(" \000\000\000(\000\000\000l\000\000\000i\000\000\000n\000\000\000e\000\000\000 \000\000\000",7,774604064);
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F1173_10252(RTCW(Result), tr1);
		F1173_10255(RTCW(Result), *(EIF_INTEGER_32 *)(Current + O6542[dtype-581]));
		tr1 = RTMS32_EX_H(",\000\000\000 \000\000\000c\000\000\000o\000\000\000l\000\000\000u\000\000\000m\000\000\000n\000\000\000 \000\000\000",9,933104928);
		F1173_10252(RTCW(Result), tr1);
		F1173_10255(RTCW(Result), *(EIF_INTEGER_32 *)(Current + O6543[dtype-581]));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		F1173_10265(RTCW(Result), tw1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = RTMS32_EX_H(":\000\000\000 \000\000\000",2,14880);
		F1173_10252(RTCW(Result), tr1);
		F1173_10251(RTCW(Result), loc2);
	}
	RTLE;
	return Result;
}

/* {CONF_ERROR_PARSE}.set_xml_parse_mode */
void F582_7395 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O6544[Dtype(Current)-581]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {CONF_ERROR_PARSE}.set_position */
void F582_7397 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current + O6542[dtype-581]) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current + O6543[dtype-581]) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {CONF_ERROR_PARSE}.set_message */
void F582_7398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit495 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
