
#ifndef _C10_co498_
#define _C10_co498_

#ifdef __cplusplus
extern "C" {
#endif

extern void F585_7406(EIF_REFERENCE);
extern void EIF_Minit498(void);

#ifdef __cplusplus
}
#endif

#endif
