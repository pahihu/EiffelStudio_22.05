/*
 * Code for class LIBCURL_CUSTOM_FUNCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li473.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBCURL_CUSTOM_FUNCTION}.set_write_procedure */
void F560_6828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {LIBCURL_CUSTOM_FUNCTION}.set_file_to_read */
void F560_6829 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {LIBCURL_CUSTOM_FUNCTION}.write_function */
EIF_INTEGER_32 F560_6830 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 * arg3);
		loc1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F503_6403(RTCW(loc1), arg1, Result);
		loc2 = F503_6410(RTCW(loc1), ((EIF_INTEGER_32) 1L), Result);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(loc3 + _REFACS_1_), loc2);
	} else {
		Result = F559_6823(Current, arg1, arg2, arg3, arg4);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {LIBCURL_CUSTOM_FUNCTION}.read_function */
EIF_INTEGER_32 F560_6831 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb1 = F936_8223(loc4);
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 * arg3);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc4)-908])(loc4);
			ti4_2 = F936_8205(loc4);
			if ((EIF_BOOLEAN) (loc2 > (EIF_INTEGER_32) (ti4_1 - ti4_2))) {
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc4)-908])(loc4);
				ti4_1 = F936_8205(loc4);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
			}
			loc1 = RTLNS(eif_new_type(546, 0x01).id, 546, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F547_6555(RTCW(loc1), arg1, loc2);
			for (;;) {
				tb1 = '\01';
				tb2 = F936_8223(loc4);
				if (!tb2) {
					tb1 = (EIF_BOOLEAN) (loc3 >= loc2);
				}
				if (tb1) break;
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6282[Dtype(loc4)-936])(loc4);
				tc1 = *(EIF_CHARACTER_8 *)(loc4 + O6222[Dtype(loc4)-562]);
				F547_6593(RTCW(loc1), tc1, loc3);
				loc3++;
			}
			RTLE;
			return (EIF_INTEGER_32) loc2;
		} else {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	} else {
		{
			/* INLINED CODE (CURL_DEFAULT_FUNCTION.read_function) */
			ti4_1 = (EIF_INTEGER_32)  0;
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
