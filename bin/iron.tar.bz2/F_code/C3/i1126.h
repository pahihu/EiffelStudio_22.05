
#ifndef _C3_i1126_
#define _C3_i1126_

#ifdef __cplusplus
extern "C" {
#endif

extern void F150_2434(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
