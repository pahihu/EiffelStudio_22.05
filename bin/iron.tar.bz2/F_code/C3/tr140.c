/*
 * Code for class TRANSFER_COMMAND_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "tr140.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TRANSFER_COMMAND_CONSTANTS}.http_host_header */

EIF_REFERENCE F164_2671 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (615,RTMS_EX_H("Host",4,1215263604));
}

/* {TRANSFER_COMMAND_CONSTANTS}.http_end_of_header_line */

EIF_REFERENCE F164_2673 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (614,RTMS_EX_H("\015\012",2,3338));
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
