/*
 * Code for class CURL_EXTERNALS_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu138.h"
#include <curl/curl.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_123
static EIF_NATURAL_64 inline_F17_123 (void)
{
	return CURL_GLOBAL_ALL;
	;
}
#define INLINE_F17_123
#endif
#ifndef INLINE_F162_2617
static void inline_F162_2617 (EIF_POINTER arg1, EIF_NATURAL_64 arg2)
{
	#ifdef CURL_STATICLIB	
	(FUNCTION_CAST(void, (long)) arg1)((long) arg2);
#else
		/* Using the proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (long)) arg1)((long) arg2);
#endif
	;
}
#define INLINE_F162_2617
#endif
#ifndef INLINE_F162_2618
static void inline_F162_2618 (EIF_POINTER arg1)
{
	#ifdef CURL_STATICLIB	
	(FUNCTION_CAST(void, ()) arg1)();
#else
		/* Using the proper calling convention for dynamic module */
	(FUNCTION_CAST(void, ()) arg1)();
#endif
	;
}
#define INLINE_F162_2618
#endif
#ifndef INLINE_F162_2619
static EIF_POINTER inline_F162_2619 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	#ifdef CURL_STATICLIB	
	return (FUNCTION_CAST(void *, (struct curl_slist *, const char *)) arg1)
							((struct curl_slist *)arg2, 
							(const char *)arg3);
#else
		/* Using the proper calling convention for dynamic module */
	return (FUNCTION_CAST(void *, (struct curl_slist *, const char *)) arg1)
							((struct curl_slist *)arg2, 
							(const char *)arg3);
#endif
	;
}
#define INLINE_F162_2619
#endif
#ifndef INLINE_F162_2620
static void inline_F162_2620 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB	
	(FUNCTION_CAST(void *, (struct curl_slist *)) arg1)
						((struct curl_slist *)arg2);
#else
		/* Using the proper calling convention for dynamic module */
	(FUNCTION_CAST(void *, (struct curl_slist *)) arg1)
						((struct curl_slist *)arg2);
#endif
	;
}
#define INLINE_F162_2620
#endif
#ifndef INLINE_F162_2621
static EIF_POINTER inline_F162_2621 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	#ifdef CURL_STATICLIB	
	return (FUNCTION_CAST(void *, (long)) arg1)
							((long) arg2);
#else
		/* Using the proper calling convention for dynamic module */
	return (FUNCTION_CAST(void *, (long)) arg1)
							((long) arg2);
#endif
	;
}
#define INLINE_F162_2621
#endif
#ifndef INLINE_F162_2616
static void inline_F162_2616 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (struct curl_httppost *)) arg1)
							((struct curl_httppost *) arg2);
#else
		/* Using the proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (struct curl_httppost *)) arg1)
							((struct curl_httppost *) arg2);
#endif
	;
}
#define INLINE_F162_2616
#endif
#ifndef INLINE_F162_2615
static void inline_F162_2615 (EIF_POINTER arg1, EIF_POINTER* arg2, EIF_POINTER* arg3, EIF_INTEGER_32 arg4, EIF_POINTER arg5, EIF_INTEGER_32 arg6, EIF_POINTER arg7, EIF_INTEGER_32 arg8)
{
	#ifdef CURL_STATICLIB
		(FUNCTION_CAST(void, (struct curl_httppost **, struct curl_httppost **, int, char *, int, char *, int)) arg1)
								((struct curl_httppost **)arg2,
								(struct curl_httppost **)arg3,
								(int)arg4,
								(char *)arg5,
								(int)arg6,
								(char *)arg7,
								(int)arg8);
	#else
			/* Using the proper calling convention for dynamic module */
		(FUNCTION_CAST(void, (struct curl_httppost **, struct curl_httppost **, int, char *, int, char *, int)) arg1)
											((struct curl_httppost **)arg2,
											(struct curl_httppost **)arg3,
											(int)arg4,
											(char *)arg5,
											(int)arg6,
											(char *)arg7,
											(int)arg8);
 	#endif
	;
}
#define INLINE_F162_2615
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_EXTERNALS_I}.global_init */
void F162_2599 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_64 tu8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F253_3527(Current);
	tu8_1 = inline_F17_123();
	inline_F162_2617(tp1, tu8_1);
	RTLE;
}

/* {CURL_EXTERNALS_I}.global_cleanup */
void F162_2600 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F253_3528(Current);
	inline_F162_2618(tp1);
	RTLE;
}

/* {CURL_EXTERNALS_I}.formadd_string_string */
void F162_2601 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4, EIF_INTEGER_32 arg5, EIF_REFERENCE arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg4);
	RTLR(3,arg6);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_0_0_0_0_0_);
	loc2 = *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_0_0_0_0_0_0_);
	F162_2614(Current, (EIF_POINTER *) &(loc1), (EIF_POINTER *) &(loc2), arg3, arg4, arg5, arg6, arg7);
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_0_0_0_0_0_);
	if ((EIF_BOOLEAN)(tp1 != loc1)) {
		F545_6542(RTCW(arg1), loc1);
	}
	tp1 = *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_0_0_0_0_0_0_);
	if ((EIF_BOOLEAN)(tp1 != loc2)) {
		F545_6542(RTCW(arg2), loc2);
	}
	RTLE;
}

/* {CURL_EXTERNALS_I}.slist_append */
EIF_POINTER F162_2602 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F503_6398(RTCW(loc1), arg2);
	tp1 = F253_3529(Current);
	tp2 = F503_6420(RTCW(loc1));
	Result = inline_F162_2619(tp1, arg1, tp2);
	RTLE;
	return Result;
}

/* {CURL_EXTERNALS_I}.slist_free_all */
void F162_2603 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F253_3530(Current);
	inline_F162_2620(tp1, arg1);
	RTLE;
}

/* {CURL_EXTERNALS_I}.error_message */
EIF_REFERENCE F162_2604 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F1168_10066(RTMS_EX_H("Unknown Error",13,1947005554));
	F1171_10139(RTCW(Result), tr1);
	tp1 = F253_3531(Current);
	loc2 = inline_F162_2621(tp1, arg1);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F503_6400(RTCW(loc1), loc2);
		Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = F503_6412(RTCW(loc1));
		tr1 = F1168_10066(RTCW(tr1));
		F1171_10139(RTCW(Result), tr1);
	}
	RTLE;
	return Result;
}

/* {CURL_EXTERNALS_I}.formfree */
void F162_2613 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F253_3532(Current);
	inline_F162_2616(tp1, arg1);
	RTLE;
}

/* {CURL_EXTERNALS_I}.internal_formadd_string_string */
void F162_2614 (EIF_REFERENCE Current, EIF_POINTER* arg1, EIF_POINTER* arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4, EIF_INTEGER_32 arg5, EIF_REFERENCE arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg4);
	RTLR(2,loc2);
	RTLR(3,arg6);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F503_6398(RTCW(loc1), arg4);
	loc2 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F503_6398(RTCW(loc2), arg6);
	tp1 = F253_3533(Current);
	tp2 = F503_6420(RTCW(loc1));
	tp3 = F503_6420(RTCW(loc2));
	inline_F162_2615(tp1, arg1, arg2, arg3, tp2, arg5, tp3, arg7);
	RTLE;
}

/* {CURL_EXTERNALS_I}.c_formadd_string_string */
void F162_2615 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2, EIF_POINTER* arg3, EIF_INTEGER_32 arg4, EIF_POINTER arg5, EIF_INTEGER_32 arg6, EIF_POINTER arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	
	
	inline_F162_2615 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2, (EIF_POINTER*) arg3, (EIF_INTEGER_32) arg4, (EIF_POINTER) arg5, (EIF_INTEGER_32) arg6, (EIF_POINTER) arg7, (EIF_INTEGER_32) arg8);
}

/* {CURL_EXTERNALS_I}.c_formfree */
void F162_2616 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F162_2616 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_EXTERNALS_I}.c_curl_global_init */
void F162_2617 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_NATURAL_64 arg2)
{
	GTCX
	
	
	inline_F162_2617 ((EIF_POINTER) arg1, (EIF_NATURAL_64) arg2);
}

/* {CURL_EXTERNALS_I}.c_curl_global_cleanup */
void F162_2618 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F162_2618 ((EIF_POINTER) arg1);
}

/* {CURL_EXTERNALS_I}.c_slist_append */
EIF_POINTER F162_2619 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F162_2619 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3);
	return Result;
}

/* {CURL_EXTERNALS_I}.c_slist_free_all */
void F162_2620 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F162_2620 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_EXTERNALS_I}.c_curl_easy_strerror */
EIF_POINTER F162_2621 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F162_2621 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
