
#ifndef _C3_sh122_
#define _C3_sh122_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F146_2409_body(EIF_REFERENCE);
extern EIF_REFERENCE F146_2409(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
