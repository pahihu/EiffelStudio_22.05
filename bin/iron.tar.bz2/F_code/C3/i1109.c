/*
 * Code for class I18N_DATE_TIME_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1109.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_TIME_INFO}.make */
void F127_2214 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(754,F127_2241, (Current));
	F127_2232(Current, tr1);
	tr1 = RTOUCR(755,F127_2244, (Current));
	F127_2233(Current, tr1);
	tr1 = RTOUCR(756,F127_2243, (Current));
	F127_2234(Current, tr1);
	tr1 = RTOUCR(755,F127_2244, (Current));
	F127_2235(Current, tr1);
	tr1 = RTOUCR(757,F127_2245, (Current));
	F127_2236(Current, tr1);
	tr1 = RTOUCR(758,F127_2246, (Current));
	F127_2237(Current, tr1);
	tr1 = RTOUCR(759,F127_2247, (Current));
	F127_2238(Current, tr1);
	tr1 = RTOUCR(760,F127_2253, (Current));
	F127_2239(Current, tr1);
	tr1 = RTOUCR(761,F127_2252, (Current));
	F127_2240(Current, tr1);
	tr1 = RTOUCR(762,F127_2248, (Current));
	F127_2228(Current, tr1);
	tr1 = RTOUCR(763,F127_2249, (Current));
	F127_2230(Current, tr1);
	tr1 = RTOUCR(764,F127_2250, (Current));
	F127_2229(Current, tr1);
	tr1 = RTOUCR(765,F127_2251, (Current));
	F127_2231(Current, tr1);
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_day_names */
void F127_2228 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_day_names */
void F127_2229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_month_names */
void F127_2230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_month_names */
void F127_2231 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_date_time_format */
void F127_2232 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_long_date_format */
void F127_2233 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_short_date_format */
void F127_2234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_long_time_format */
void F127_2235 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_short_time_format */
void F127_2236 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_am_suffix */
void F127_2237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_pm_suffix */
void F127_2238 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_time_separator */
void F127_2239 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_date_separator */
void F127_2240 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.default_date_time_format */
static EIF_REFERENCE F127_2241_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(754)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(766,F127_2242, (Current));
	F1173_10252(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'T';
	F1173_10266(RTCW(Result), tw1);
	tr1 = RTOUCR(755,F127_2244, (Current));
	F1173_10252(RTCW(Result), tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2241 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(754,F127_2241_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_date_format */
static EIF_REFERENCE F127_2242_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(766)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'e';
	F1173_10266(RTCW(Result), tw1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2242 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(766,F127_2242_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_date_format */
static EIF_REFERENCE F127_2243_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(756)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1173_10266(RTCW(Result), tw1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2243 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(756,F127_2243_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_time_format */
static EIF_REFERENCE F127_2244_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(755)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(757,F127_2245, (Current));
	F1173_10252(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '5';
	F1173_10266(RTCW(Result), tw1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2244 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(755,F127_2244_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_time_format */
static EIF_REFERENCE F127_2245_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(757)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'k';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1173_10266(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'M';
	F1173_10266(RTCW(Result), tw1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2245 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(757,F127_2245_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_am_suffix */
static EIF_REFERENCE F127_2246_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(758)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("a\000\000\000m\000\000\000",2,24941);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2246 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(758,F127_2246_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_pm_suffix */
static EIF_REFERENCE F127_2247_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(759)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("p\000\000\000m\000\000\000",2,28781);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2247 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(759,F127_2247_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_day_names */
static EIF_REFERENCE F127_2248_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(762)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10067(RTMS_EX_H("Monday",6,2004312953));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Tuesday",7,1495753593));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Wednesday",9,1804915065));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Thursday",8,844137593));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Friday",6,1906687353));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Saturday",8,1596931193));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Sunday",6,2016155513));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2248 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(762,F127_2248_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_month_names */
static EIF_REFERENCE F127_2249_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(763)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10067(RTMS_EX_H("January",7,751658105));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("February",8,1474449017));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("March",5,1635477864));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("April",5,1887045484));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("June",4,1249209957));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("July",4,1249209465));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("August",6,1864444276));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("September",9,1077346930));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("October",7,1024137842));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("November",8,2119563634));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("December",8,1341698930));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2249 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(763,F127_2249_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_day_names */
static EIF_REFERENCE F127_2250_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(764)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10067(RTMS_EX_H("Mon",3,5074798));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Tue",3,5535077));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Wed",3,5727588));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Thu",3,5531765));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Fri",3,4616809));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Sat",3,5464436));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Sun",3,5469550));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2250 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(764,F127_2250_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_month_names */
static EIF_REFERENCE F127_2251_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(765)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1168_10067(RTMS_EX_H("Jan",3,4874606));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Feb",3,4613474));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Mar",3,5071218));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Apr",3,4288626));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Jun",3,4879726));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Jul",3,4879724));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Aug",3,4289895));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Sep",3,5465456));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Oct",3,5202804));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Nov",3,5140342));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1168_10067(RTMS_EX_H("Dec",3,4482403));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1231_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2251 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(765,F127_2251_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_date_separator */
static EIF_REFERENCE F127_2252_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(761)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("/\000\000\000",1,47);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2252 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(761,F127_2252_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_time_separator */
static EIF_REFERENCE F127_2253_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(760)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(":\000\000\000",1,58);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_2253 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(760,F127_2253_body,(Current));
}

void EIF_Minit109 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
