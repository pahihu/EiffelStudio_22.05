
#ifndef _C3_i1127_
#define _C3_i1127_

#ifdef __cplusplus
extern "C" {
#endif

extern void F151_2449(EIF_REFERENCE, EIF_REFERENCE);
extern void F151_2450(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit127(void);
extern long O2264[];
extern long O2265[];
extern long O2266[];
extern long O2268[];
extern long O2269[];
extern long O2270[];

#ifdef __cplusplus
}
#endif

#endif
