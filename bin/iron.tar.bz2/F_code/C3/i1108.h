
#ifndef _C3_i1108_
#define _C3_i1108_

#ifdef __cplusplus
extern "C" {
#endif

extern void F126_2206(EIF_REFERENCE);
extern void F126_2211(EIF_REFERENCE, EIF_REFERENCE);
extern void F126_2212(EIF_REFERENCE, EIF_REFERENCE);
extern void F126_2213(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit108(void);
extern EIF_REFERENCE F1168_10060(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
