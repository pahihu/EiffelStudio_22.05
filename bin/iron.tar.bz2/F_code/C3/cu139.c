/*
 * Code for class CURL_EASY_EXTERNALS_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu139.h"
#include <eiffel_curl.h>
#include "eif_built_in.h"
#include <curl/curl.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F163_2655
static EIF_POINTER inline_F163_2655 (EIF_POINTER arg1)
{
	#ifdef CURL_STATICLIB
	return (FUNCTION_CAST(CURL *, ()) arg1)();
#else
		/* Using the proper calling convention for dynamic module */
	return (FUNCTION_CAST(CURL *, ()) arg1)();
#endif
	;
}
#define INLINE_F163_2655
#endif
#ifndef INLINE_F163_2659
static void inline_F163_2659 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
#endif
										((CURL *) arg2,
										(CURLoption)arg3,
										arg4);
	;
}
#define INLINE_F163_2659
#endif
#ifndef INLINE_F163_2658
static void inline_F163_2658 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
#endif
							((CURL *) arg2,
							(CURLoption)arg3,
							arg4);
	;
}
#define INLINE_F163_2658
#endif
#ifndef INLINE_F163_2657
static EIF_INTEGER_32 inline_F163_2657 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	return (FUNCTION_CAST(CURLcode, (CURL *)) arg1)
#else
		/* Using proper calling convention for dynamic module */
	return (FUNCTION_CAST(CURLcode, (CURL *)) arg1)
#endif
							((CURL *) arg2);
	;
}
#define INLINE_F163_2657
#endif
#ifndef INLINE_F163_2656
static void inline_F163_2656 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *)) arg1)((CURL *)arg2);
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *)) arg1)((CURL *)arg2);
#endif
	;
}
#define INLINE_F163_2656
#endif
#ifndef INLINE_F163_2660
static EIF_INTEGER_32 inline_F163_2660 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	#ifdef CURL_STATICLIB
	return (FUNCTION_CAST(CURLcode, (CURL *, CURLINFO info, ...)) arg1)
#else
		/* Using proper calling convention for dynamic module */
	return (FUNCTION_CAST(CURLcode, (CURL *, CURLINFO info, ...)) arg1)
#endif
							((CURL *) arg2,
							(CURLINFO)arg3,
							arg4);
	;
}
#define INLINE_F163_2660
#endif
#ifndef INLINE_F557_6804
static void inline_F557_6804 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_WRITEFUNCTION,
							curl_write_function);
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_WRITEFUNCTION,
							curl_write_function);
#endif
	;
}
#define INLINE_F557_6804
#endif
#ifndef INLINE_F557_6805
static void inline_F557_6805 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_READFUNCTION,
							curl_read_function);
#else
		/* Using proper calling convention for dynamic module */
	(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
							((CURL *) arg2,
							(CURLoption)CURLOPT_READFUNCTION,
							curl_read_function);				
#endif
	;
}
#define INLINE_F557_6805
#endif
#ifndef INLINE_F557_6803
static void inline_F557_6803 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	#ifdef CURL_STATICLIB
		(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
								((CURL *) arg2,
								(CURLoption)CURLOPT_DEBUGFUNCTION,
								curl_debug_function);
	#else
			/* Using proper calling convention for dynamic module */
		(FUNCTION_CAST(void, (CURL *, CURLoption, ...)) arg1)
								((CURL *) arg2,
								(CURLoption)CURLOPT_DEBUGFUNCTION,
								curl_debug_function);
	#endif
	;
}
#define INLINE_F557_6803
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_EASY_EXTERNALS_I}.init */
EIF_POINTER F163_2636 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_3542(Current);
	Result = inline_F163_2655(tp1);
	RTLE;
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.setopt_string */
void F163_2637 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F503_6398(RTCW(loc1), arg3);
	tp1 = F254_3543(Current);
	tp2 = F503_6420(RTCW(loc1));
	inline_F163_2659(tp1, arg1, arg2, tp2);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.setopt_form */
void F163_2638 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg3)+ _PTROFF_0_0_0_0_0_0_);
	F163_2654(Current, arg1, arg2, tp1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.setopt_slist */
void F163_2639 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	GTCX
	
	
	F163_2654(Current, arg1, arg2, arg3);
}

/* {CURL_EASY_EXTERNALS_I}.setopt_curl_string */
void F163_2640 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLIU(2);
	
	RTGC;
	tp1 = F254_3543(Current);
	ti4_1 = F561_6832(RTCW(arg3));
	inline_F163_2658(tp1, arg1, arg2, ti4_1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.setopt_integer */
void F163_2641 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_3543(Current);
	inline_F163_2658(tp1, arg1, arg2, arg3);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.perform */
EIF_INTEGER_32 F163_2644 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_3546(Current);
	Result = inline_F163_2657(tp1, arg1);
	RTLE;
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.cleanup */
void F163_2645 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_3545(Current);
	inline_F163_2656(tp1, arg1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.getinfo */
EIF_INTEGER_32 F163_2646 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REAL_64 loc5 = (EIF_REAL_64) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3054[Dtype(RTCW(arg3))-206])(arg3, NULL);
	loc1 = F254_3544(Current);
	ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 2097152L));
	if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
		loc2 = RTLNS(eif_new_type(546, 0x01).id, 546, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F547_6552(RTCW(loc2), ((EIF_INTEGER_32) 4L));
	} else {
		ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 1048576L));
		if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
			loc2 = RTLNS(eif_new_type(546, 0x01).id, 546, _OBJSIZ_0_1_0_1_0_1_1_0_);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_PLATFORM_pointer_bytes__i4;
			F547_6552(RTCW(loc2), ti4_1);
		} else {
			ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 3145728L));
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
				loc2 = RTLNS(eif_new_type(546, 0x01).id, 546, _OBJSIZ_0_1_0_1_0_1_1_0_);
				F547_6552(RTCW(loc2), ((EIF_INTEGER_32) 8L));
			}
		}
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		Result = inline_F163_2660(loc1, arg1, arg2, tp1);
		if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 2097152L));
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
				loc3 = F547_6569(RTCW(loc2), ((EIF_INTEGER_32) 0L));
				tr1 = RTLNS(eif_new_type(1312, 0x00).id, 1312, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_INTEGER_32 *)tr1 = loc3;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3053[Dtype(RTCW(arg3))-206])(arg3, tr1);
			} else {
				ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 1048576L));
				if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
					loc4 = RTLNS(eif_new_type(502, 0x01).id, 502, _OBJSIZ_1_0_0_1_0_0_0_0_);
					tp1 = F547_6571(RTCW(loc2), ((EIF_INTEGER_32) 0L));
					F503_6402(RTCW(loc4), tp1);
					tr1 = F503_6412(RTCW(loc4));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3053[Dtype(RTCW(arg3))-206])(arg3, tr1);
				} else {
					ti4_1 = eif_bit_and(arg2,((EIF_INTEGER_32) 3145728L));
					if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
						loc5 = F547_6577(RTCW(loc2), ((EIF_INTEGER_32) 0L));
						tr1 = RTLNS(eif_new_type(1336, 0x00).id, 1336, _OBJSIZ_0_0_0_0_0_0_0_1_);
						*(EIF_REAL_64 *)tr1 = loc5;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3053[Dtype(RTCW(arg3))-206])(arg3, tr1);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.set_curl_function */
void F163_2647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {CURL_EASY_EXTERNALS_I}.curl_function */
EIF_REFERENCE F163_2648 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTLNS(eif_new_type(557, 0x01).id, 557, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F558_6817(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.set_write_function */
void F163_2649 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F163_2648(Current);
	tp1 = F254_3543(Current);
	inline_F557_6804(tp1, arg1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.set_read_function */
void F163_2650 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F163_2648(Current);
	tp1 = F254_3543(Current);
	inline_F557_6805(tp1, arg1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.set_debug_function */
void F163_2652 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F163_2648(Current);
	tp1 = F254_3543(Current);
	inline_F557_6803(tp1, arg1);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.setopt_void_star */
void F163_2654 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_3543(Current);
	inline_F163_2659(tp1, arg1, arg2, arg3);
	RTLE;
}

/* {CURL_EASY_EXTERNALS_I}.c_init */
EIF_POINTER F163_2655 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F163_2655 ((EIF_POINTER) arg1);
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.c_cleanup */
void F163_2656 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F163_2656 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {CURL_EASY_EXTERNALS_I}.c_perform */
EIF_INTEGER_32 F163_2657 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F163_2657 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	return Result;
}

/* {CURL_EASY_EXTERNALS_I}.c_setopt_int */
void F163_2658 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	inline_F163_2658 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
}

/* {CURL_EASY_EXTERNALS_I}.c_setopt */
void F163_2659 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	inline_F163_2659 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4);
}

/* {CURL_EASY_EXTERNALS_I}.c_getinfo */
EIF_INTEGER_32 F163_2660 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F163_2660 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER) arg4);
	return Result;
}

void EIF_Minit139 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
