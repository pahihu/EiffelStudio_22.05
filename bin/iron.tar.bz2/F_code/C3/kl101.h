
#ifndef _C3_kl101_
#define _C3_kl101_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F119_2061_body(EIF_REFERENCE);
extern EIF_REFERENCE F119_2061(EIF_REFERENCE);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
