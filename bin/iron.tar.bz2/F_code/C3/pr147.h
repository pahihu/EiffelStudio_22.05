
#ifndef _C3_pr147_
#define _C3_pr147_

#ifdef __cplusplus
extern "C" {
#endif

extern void F173_2741(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit147(void);

#ifdef __cplusplus
}
#endif

#endif
