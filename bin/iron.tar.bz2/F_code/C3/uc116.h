
#ifndef _C3_uc116_
#define _C3_uc116_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F138_2344_body(EIF_REFERENCE);
extern EIF_REFERENCE F138_2344(EIF_REFERENCE);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
