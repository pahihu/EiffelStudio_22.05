/*
 * Code for class I18N_POSIX_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1107.h"
#include "eif_langinfo.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F125_2161
static EIF_INTEGER_32 inline_F125_2161 (void)
{
	return ABDAY_1;
	;
}
#define INLINE_F125_2161
#endif
#ifndef INLINE_F125_2168
static EIF_INTEGER_32 inline_F125_2168 (void)
{
	return DAY_1;
	;
}
#define INLINE_F125_2168
#endif
#ifndef INLINE_F125_2175
static EIF_INTEGER_32 inline_F125_2175 (void)
{
	return ABMON_1;
	;
}
#define INLINE_F125_2175
#endif
#ifndef INLINE_F125_2187
static EIF_INTEGER_32 inline_F125_2187 (void)
{
	return MON_1;
	;
}
#define INLINE_F125_2187
#endif
#ifndef INLINE_F125_2199
static EIF_INTEGER_32 inline_F125_2199 (void)
{
	return AM_STR;
	;
}
#define INLINE_F125_2199
#endif
#ifndef INLINE_F125_2200
static EIF_INTEGER_32 inline_F125_2200 (void)
{
	return PM_STR;
	;
}
#define INLINE_F125_2200
#endif
#ifndef INLINE_F125_2201
static EIF_INTEGER_32 inline_F125_2201 (void)
{
	return D_T_FMT;
	;
}
#define INLINE_F125_2201
#endif
#ifndef INLINE_F125_2202
static EIF_INTEGER_32 inline_F125_2202 (void)
{
	return D_FMT;
	;
}
#define INLINE_F125_2202
#endif
#ifndef INLINE_F125_2203
static EIF_INTEGER_32 inline_F125_2203 (void)
{
	return T_FMT;
	;
}
#define INLINE_F125_2203
#endif
#ifndef INLINE_F125_2205
static EIF_INTEGER_32 inline_F125_2205 (void)
{
	return CRNCYSTR;
	;
}
#define INLINE_F125_2205
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_POSIX_CONSTANTS}.abday_1 */
EIF_INTEGER_32 F125_2161 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2161 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.day_1 */
EIF_INTEGER_32 F125_2168 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2168 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.abmon_1 */
EIF_INTEGER_32 F125_2175 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2175 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.mon_1 */
EIF_INTEGER_32 F125_2187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2187 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.am_str */
EIF_INTEGER_32 F125_2199 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2199 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.pm_str */
EIF_INTEGER_32 F125_2200 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2200 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_t_fmt */
EIF_INTEGER_32 F125_2201 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2201 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_fmt */
EIF_INTEGER_32 F125_2202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2202 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.t_fmt */
EIF_INTEGER_32 F125_2203 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2203 ();
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.crncystr */
EIF_INTEGER_32 F125_2205 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F125_2205 ();
	return Result;
}

void EIF_Minit107 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
