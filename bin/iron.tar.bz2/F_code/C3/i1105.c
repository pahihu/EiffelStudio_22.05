/*
 * Code for class I18N_LOCALE_CONV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1105.h"
#include <locale.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_CONV}.localeconv */
EIF_POINTER F123_2132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) localeconv();
	
	return Result;
}

/* {I18N_LOCALE_CONV}.decimal_point */
EIF_POINTER F123_2134 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->decimal_point);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.thousands_sep */
EIF_POINTER F123_2135 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->thousands_sep);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.grouping */
EIF_POINTER F123_2136 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->grouping);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.int_curr_symbol */
EIF_POINTER F123_2137 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->int_curr_symbol);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_decimal_point */
EIF_POINTER F123_2139 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_decimal_point);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_thousands_sep */
EIF_POINTER F123_2140 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_thousands_sep);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_grouping */
EIF_POINTER F123_2141 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_grouping);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.positive_sign */
EIF_POINTER F123_2142 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->positive_sign);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.negative_sign */
EIF_POINTER F123_2143 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((struct lconv *)arg1)->negative_sign);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.int_frac_digits */
EIF_CHARACTER_8 F123_2144 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->int_frac_digits);
	
	return Result;
}

/* {I18N_LOCALE_CONV}.frac_digits */
EIF_CHARACTER_8 F123_2145 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->frac_digits);
	
	return Result;
}

void EIF_Minit105 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
