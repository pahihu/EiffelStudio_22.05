
#ifndef _C3_id130_
#define _C3_id130_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F154_2462(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F154_2463(EIF_REFERENCE, EIF_REFERENCE);
extern void F154_2466(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit130(void);

#ifdef __cplusplus
}
#endif

#endif
