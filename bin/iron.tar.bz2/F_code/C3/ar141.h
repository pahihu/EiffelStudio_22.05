
#ifndef _C3_ar141_
#define _C3_ar141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F165_2675(EIF_REFERENCE);
extern void F165_2679(EIF_REFERENCE, EIF_REFERENCE);
extern void F165_2681(EIF_REFERENCE);
extern void EIF_Minit141(void);
extern void F1168_10007(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
