
#ifndef _C3_i1124_
#define _C3_i1124_

#ifdef __cplusplus
extern "C" {
#endif

extern void F148_2416(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F148_2420(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F148_2421(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit124(void);
extern EIF_REFERENCE F149_2425(EIF_REFERENCE);
extern void F1173_10213(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F149_2426(EIF_REFERENCE);
extern char *(*R7033[])();

#ifdef __cplusplus
}
#endif

#endif
