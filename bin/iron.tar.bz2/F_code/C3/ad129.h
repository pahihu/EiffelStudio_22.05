
#ifndef _C3_ad129_
#define _C3_ad129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F153_2452(EIF_REFERENCE);extern EIF_INTEGER_32 en_addrinfo_af_inet();

extern EIF_INTEGER_32 F153_2453(EIF_REFERENCE);extern EIF_INTEGER_32 en_addrinfo_af_inet6();

extern void EIF_Minit129(void);

#ifdef __cplusplus
}
#endif

#endif
