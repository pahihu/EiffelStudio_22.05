/*
 * Code for class OPTION_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "op135.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OPTION_ROUTINES}.is_option_caseless */
EIF_BOOLEAN F159_2551 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_multiline */
EIF_BOOLEAN F159_2552 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_dotall */
EIF_BOOLEAN F159_2553 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_undef */
EIF_BOOLEAN F159_2556 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 32L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.set_option_caseless */
EIF_INTEGER_32 F159_2558 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_caseless */
EIF_INTEGER_32 F159_2559 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_multiline */
EIF_INTEGER_32 F159_2560 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_multiline */
EIF_INTEGER_32 F159_2561 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_dotall */
EIF_INTEGER_32 F159_2562 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 4L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_dotall */
EIF_INTEGER_32 F159_2563 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 4L));
	} else {
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.to_option_ims */
EIF_INTEGER_32 F159_2570 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		Result += ((EIF_INTEGER_32) 1L);
	}
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		Result += ((EIF_INTEGER_32) 2L);
	}
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 4L));
	}
	return Result;
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
