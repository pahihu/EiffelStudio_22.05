
#ifndef _C3_i1112_
#define _C3_i1112_

#ifdef __cplusplus
extern "C" {
#endif

extern void F130_2324(EIF_REFERENCE);
extern void F130_2326(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit112(void);
extern void F1349_12526(EIF_REFERENCE, EIF_REFERENCE);
extern void F127_2214(EIF_REFERENCE);
extern void F129_2276(EIF_REFERENCE);
extern void F128_2254(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
