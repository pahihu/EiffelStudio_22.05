/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F129_2276 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(741,F129_2299, (Current));
	F129_2308(Current, tr1);
	F129_2309(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOUCR(742,F129_2300, (Current));
	F129_2310(Current, tr1);
	F129_2311(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOUCR(743,F129_2303, (Current));
	F129_2312(Current, tr1);
	tr1 = RTOUCR(744,F129_2304, (Current));
	F129_2313(Current, tr1);
	tr1 = RTOUCR(745,F129_2305, (Current));
	F129_2314(Current, tr1);
	tr1 = RTOUCR(746,F129_2306, (Current));
	F129_2315(Current, tr1);
	tr1 = RTOUCR(747,F129_2307, (Current));
	F129_2316(Current, tr1);
	tr1 = RTOUCR(741,F129_2299, (Current));
	F129_2317(Current, tr1);
	F129_2318(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOUCR(742,F129_2300, (Current));
	F129_2319(Current, tr1);
	F129_2320(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOUCR(743,F129_2303, (Current));
	F129_2321(Current, tr1);
	tr1 = RTOUCR(744,F129_2304, (Current));
	F129_2322(Current, tr1);
	tr1 = RTOUCR(747,F129_2307, (Current));
	F129_2323(Current, tr1);
	RTLE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F129_2299_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(741)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2299 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(741,F129_2299_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F129_2300_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(742)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2300 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(742,F129_2300_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F129_2303_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(743)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2303 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(743,F129_2303_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F129_2304_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(744)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2304 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(744,F129_2304_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F129_2305_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(745)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2305 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(745,F129_2305_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F129_2306_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(746)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2306 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(746,F129_2306_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F129_2307_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(747)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1233,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1234_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_2307 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(747,F129_2307_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F129_2308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2259[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F129_2309 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2260[Dtype(Current)-128]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F129_2310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2264[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F129_2311 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2265[Dtype(Current)-128]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F129_2312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2266[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F129_2313 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2267[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F129_2314 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2268[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F129_2315 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2269[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F129_2316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2270[Dtype(Current)-128]) = (EIF_REFERENCE) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F129_2317 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2271[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F129_2318 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2272[Dtype(Current)-128]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F129_2319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2276[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F129_2320 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2277[Dtype(Current)-128]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F129_2321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2278[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F129_2322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10067(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O2279[Dtype(Current)-128]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F129_2323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2280[Dtype(Current)-128]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
