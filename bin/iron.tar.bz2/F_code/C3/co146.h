
#ifndef _C3_co146_
#define _C3_co146_

#ifdef __cplusplus
extern "C" {
#endif

extern void F172_2737(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit146(void);

#ifdef __cplusplus
}
#endif

#endif
