/*
 * Code for class CONF_LOCATION_IRON_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_IRON_MAPPING}.make */
void F171_2726 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {CONF_LOCATION_IRON_MAPPING}.mapped_location */
EIF_REFERENCE F171_2729 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tr1 = F1168_10066(RTMS_EX_H("iron:",5,1920711738));
	tb3 = F1171_10172(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = F1168_10066(RTMS_EX_H("http:",5,1954586682));
		tb3 = F1171_10172(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = F1168_10066(RTMS_EX_H("https:",6,11409978));
		tb2 = F1171_10172(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1171_10139(RTCW(loc1), arg1);
		F171_2734(Current, loc1);
		tr1 = F171_2732(Current);
		tr1 = F1111_9591(RTCW(tr1), loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1194_11030(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_LOCATION_IRON_MAPPING}.refresh */
void F171_2731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1111_9566(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
}

/* {CONF_LOCATION_IRON_MAPPING}.iron_api */
EIF_REFERENCE F171_2732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F1111_9566(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = (EIF_REFERENCE) NULL;
	}
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc2 = RTLNS(eif_new_type(26, 0x01).id, 26, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc1 = F27_283(RTCW(loc2), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_IRON_MAPPING}.update_location_to_uri */
void F171_2734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1173_10229(RTCW(arg1), tr1, tr2);
	RTLE;
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
