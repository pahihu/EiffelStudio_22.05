/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1110.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F128_2254 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(748,F128_2262, (Current));
	F128_2269(Current, tr1);
	F128_2270(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOUCR(749,F128_2264, (Current));
	F128_2271(Current, tr1);
	tr1 = RTOUCR(750,F128_2265, (Current));
	F128_2272(Current, tr1);
	tr1 = RTOUCR(751,F128_2268, (Current));
	F128_2275(Current, tr1);
	tr1 = RTOUCR(752,F128_2266, (Current));
	F128_2273(Current, tr1);
	tr1 = RTOUCR(753,F128_2267, (Current));
	F128_2274(Current, tr1);
	RTLE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F128_2262_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(748)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2262 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(748,F128_2262_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F128_2264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(749)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(749,F128_2264_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F128_2265_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(750)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2265 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(750,F128_2265_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F128_2266_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(752)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2266 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(752,F128_2266_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F128_2267_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(753)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2267 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(753,F128_2267_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F128_2268_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(751)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {1233,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1234_11106)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F128_2268 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(751,F128_2268_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F128_2269 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F128_2270 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F128_2271 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F128_2272 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F128_2273 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F128_2274 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1168_10066(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F128_2275 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
