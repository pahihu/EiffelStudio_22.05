
#ifndef _C3_tr140_
#define _C3_tr140_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F164_2671(EIF_REFERENCE);
extern EIF_REFERENCE F164_2673(EIF_REFERENCE);
extern void EIF_Minit140(void);

#ifdef __cplusplus
}
#endif

#endif
