
#ifndef _C3_rt113_
#define _C3_rt113_

#ifdef __cplusplus
extern "C" {
#endif

extern void F131_2328(EIF_REFERENCE);
extern void F131_2329(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F131_2330(EIF_REFERENCE);
extern void EIF_Minit113(void);

#ifdef __cplusplus
}
#endif

#endif
