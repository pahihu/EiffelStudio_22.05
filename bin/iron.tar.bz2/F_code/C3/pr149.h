
#ifndef _C3_pr149_
#define _C3_pr149_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F175_2752(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit149(void);
extern void F1106_9471(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
