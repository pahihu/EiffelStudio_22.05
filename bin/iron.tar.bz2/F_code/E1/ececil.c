#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A7_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A7_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A7_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A7_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A7_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A7_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A7_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A7_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A7_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A7_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A7_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A7_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A7_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A7_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A7_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A7_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A7_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A7_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A35_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A35_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* THREAD thr_get_terminated */
EIF_BOOLEAN A208_51 (EIF_REFERENCE Current)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F243_3426)(Current);
}

	/* THREAD thr_main */
void A208_50 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F243_3425)(Current, arg1);
}

	/* THREAD thr_set_terminated */
void A208_52 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F243_3427)(Current, arg1);
}

	/* ARGUMENT_BASE_PARSER fake inline-agent#15461#488#35# of command_option_configurations */
EIF_BOOLEAN _A273_132_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F320_15461)(closed [1].it_r, open [1].it_r);
}

	/* ARGUMENT_BASE_PARSER fake inline-agent#15461#488#35# of command_option_configurations */
EIF_BOOLEAN __A273_132_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F320_15461)(closed [1].it_r, op_2);
}

	/* LIBCURL_HTTP_CLIENT_REQUEST inline-agent#1 of new_write_content_data_to_file_agent */
void _A399_65_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F449_15486)(closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* LIBCURL_HTTP_CLIENT_REQUEST inline-agent#1 of new_write_content_data_to_file_agent */
void __A399_65_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F449_15486)(closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* LIBCURL_HTTP_CLIENT_REQUEST inline-agent#1 of new_write_data_to_file_agent */
void _A399_66_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F449_15487)(closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* LIBCURL_HTTP_CLIENT_REQUEST inline-agent#1 of new_write_data_to_file_agent */
void __A399_66_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F449_15487)(closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* CURL_FUNCTION progress_function */
EIF_INTEGER_32 A470_38 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	return (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_POINTER, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64)) F558_6818)(Current, arg1, arg2, arg3, arg4, arg5);
}

	/* CURL_FUNCTION write_function */
EIF_INTEGER_32 A470_39 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	return (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER)) R6136[Dtype(Current) - 557])(Current, arg1, arg2, arg3, arg4);
}

	/* CURL_FUNCTION read_function */
EIF_INTEGER_32 A470_40 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	return (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER)) R6137[Dtype(Current) - 557])(Current, arg1, arg2, arg3, arg4);
}

	/* CURL_FUNCTION debug_function */
EIF_INTEGER_32 A470_41 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_POINTER arg5)
{
	return (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER)) R6138[Dtype(Current) - 557])(Current, arg1, arg2, arg3, arg4, arg5);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void _A505_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void __A505_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void _A505_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void __A505_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15507#302#406# of on_start_tag_finish */
EIF_REFERENCE _A505_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15507)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15507#302#406# of on_start_tag_finish */
EIF_REFERENCE __A505_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15507)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15508#302#407# of on_start_tag_finish */
EIF_REFERENCE _A505_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15508)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15508#302#407# of on_start_tag_finish */
EIF_REFERENCE __A505_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15508)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15509#302#405# of on_start_tag_finish */
EIF_REFERENCE _A505_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15509)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#15509#302#405# of on_start_tag_finish */
EIF_REFERENCE __A505_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F592_15509)(closed [1].it_r, op_2);
}

	/* MISMATCH_INFORMATION wipe_out */
void A525_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F961_8612)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A525_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F970_8678)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A525_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F970_8679)(Current, arg1, arg2);
}

	/* IRON_FS_CATALOG inline-agent#1 of setup_package_installation */
void _A547_71_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1099_15542)(closed [1].it_r, open [1].it_r);
}

	/* IRON_FS_CATALOG inline-agent#1 of setup_package_installation */
void __A547_71_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1099_15542)(closed [1].it_r, op_2);
}

	/* IRON_FS_CATALOG inline-agent#2 of setup_package_installation */
void _A547_72_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1099_15543)(closed [1].it_r, open [1].it_r);
}

	/* IRON_FS_CATALOG inline-agent#2 of setup_package_installation */
void __A547_72_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1099_15543)(closed [1].it_r, op_2);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE _A405_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE __A405_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_platform_name */
EIF_REFERENCE _A685_329_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_platform_name */
EIF_REFERENCE __A685_329_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_build_name */
EIF_REFERENCE _A685_330_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_build_name */
EIF_REFERENCE __A685_330_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_concurrency_name */
EIF_REFERENCE _A685_331_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_concurrency_name */
EIF_REFERENCE __A685_331_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_void_safety_name */
EIF_REFERENCE _A685_332_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_void_safety_name */
EIF_REFERENCE __A685_332_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#1 of tasks */
EIF_REFERENCE _A716_76_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15602)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#1 of tasks */
EIF_REFERENCE __A716_76_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15602)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#2 of tasks */
EIF_REFERENCE _A716_77_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15603)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#2 of tasks */
EIF_REFERENCE __A716_77_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15603)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#3 of tasks */
EIF_REFERENCE _A716_78_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15604)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#3 of tasks */
EIF_REFERENCE __A716_78_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15604)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#4 of tasks */
EIF_REFERENCE _A716_79_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15605)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#4 of tasks */
EIF_REFERENCE __A716_79_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15605)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#5 of tasks */
EIF_REFERENCE _A716_80_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15606)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#5 of tasks */
EIF_REFERENCE __A716_80_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15606)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#6 of tasks */
EIF_REFERENCE _A716_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15607)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#6 of tasks */
EIF_REFERENCE __A716_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15607)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#7 of tasks */
EIF_REFERENCE _A716_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15608)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#7 of tasks */
EIF_REFERENCE __A716_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15608)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#8 of tasks */
EIF_REFERENCE _A716_83_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15609)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#8 of tasks */
EIF_REFERENCE __A716_83_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15609)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#9 of tasks */
EIF_REFERENCE _A716_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15610)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#9 of tasks */
EIF_REFERENCE __A716_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15610)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#10 of tasks */
EIF_REFERENCE _A716_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15611)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#10 of tasks */
EIF_REFERENCE __A716_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15611)(closed [1].it_r, op_2);
}

	/* IRON_CLIENT inline-agent#11 of tasks */
EIF_REFERENCE _A716_86_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15612)(closed [1].it_r, open [1].it_r);
}

	/* IRON_CLIENT inline-agent#11 of tasks */
EIF_REFERENCE __A716_86_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1403_15612)(closed [1].it_r, op_2);
}

	/* ES_IRON_CLIENT inline-agent#1 of tasks */
EIF_REFERENCE _A717_140_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15613)(closed [1].it_r, open [1].it_r);
}

	/* ES_IRON_CLIENT inline-agent#1 of tasks */
EIF_REFERENCE __A717_140_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15613)(closed [1].it_r, op_2);
}

	/* ES_IRON_CLIENT inline-agent#2 of tasks */
EIF_REFERENCE _A717_141_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15614)(closed [1].it_r, open [1].it_r);
}

	/* ES_IRON_CLIENT inline-agent#2 of tasks */
EIF_REFERENCE __A717_141_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15614)(closed [1].it_r, op_2);
}

	/* ES_IRON_CLIENT inline-agent#3 of tasks */
EIF_REFERENCE _A717_142_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15615)(closed [1].it_r, open [1].it_r);
}

	/* ES_IRON_CLIENT inline-agent#3 of tasks */
EIF_REFERENCE __A717_142_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15615)(closed [1].it_r, op_2);
}

	/* ES_IRON_CLIENT inline-agent#4 of tasks */
EIF_REFERENCE _A717_143_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15616)(closed [1].it_r, open [1].it_r);
}

	/* ES_IRON_CLIENT inline-agent#4 of tasks */
EIF_REFERENCE __A717_143_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1404_15616)(closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A722_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A722_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A722_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A722_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A722_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A722_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A722_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A722_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A722_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A722_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A722_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A722_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A722_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A722_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A722_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A722_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A722_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A722_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A722_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A722_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A722_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A722_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A722_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A722_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A722_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A722_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A722_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A722_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A722_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A722_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A722_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A722_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A722_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A722_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A722_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A722_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A722_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A722_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A722_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A722_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A722_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A722_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A722_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A722_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A722_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A722_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A722_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A722_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A722_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A722_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A722_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A722_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A722_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A722_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A722_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A722_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A722_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A722_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A722_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A722_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* IRON_SHARE_TASK execute */
void _A746_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_SHARE_TASK execute */
void __A746_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_REPOSITORY_TASK execute */
void _A747_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_REPOSITORY_TASK execute */
void __A747_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_REMOVE_TASK execute */
void _A748_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_REMOVE_TASK execute */
void __A748_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_PATH_TASK execute */
void _A749_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_PATH_TASK execute */
void __A749_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_INFO_TASK execute */
void _A750_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_INFO_TASK execute */
void __A750_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_SEARCH_TASK execute */
void _A751_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_SEARCH_TASK execute */
void __A751_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_LIST_TASK execute */
void _A752_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_LIST_TASK execute */
void __A752_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_UPDATE_TASK execute */
void _A753_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_UPDATE_TASK execute */
void __A753_89 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_INSTALL_TASK execute */
void _A758_93 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* IRON_INSTALL_TASK execute */
void __A758_93 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A761_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A761_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A588_162_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F874_8129)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A588_162_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F874_8129)(op_1);
}


#ifdef __cplusplus
}
#endif
