#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_29 {union overhead overhead; char data [1];};
struct eif_ex_60 {union overhead overhead; char data [1];};
struct eif_ex_70 {union overhead overhead; char data [1];};
struct eif_ex_79 {union overhead overhead; char data [1];};
struct eif_ex_568 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_571 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_574 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_768 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_976 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1305 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1309 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1313 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1317 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1321 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1325 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1329 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1333 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1337 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1341 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1352 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1356 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1361 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_577 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_629 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_632 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_635 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_638 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_641 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_644 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_647 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_650 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_653 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,1,0,0,0)];};
struct eif_ex_656 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,0,1)];};

#ifdef __cplusplus
}
#endif
#endif
