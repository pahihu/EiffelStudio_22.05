#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names10[];
static const uint32 types10 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags10 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype10_0 [] = {1348,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_1 [] = {1344,0xFFFF};

static const EIF_TYPE_INDEX *gtypes10 [] = {
g_atype10_0,
g_atype10_1,
};

static const long offsets10 [] =
{
0,
 + @REFACS(1),
};

extern const char *names11[];
static const uint32 types11 [] =
{
SK_REF,
};

static const uint16 attr_flags11 [] =
{0,};

static const EIF_TYPE_INDEX g_atype11_0 [] = {0xFF01,546,0xFFFF};

static const EIF_TYPE_INDEX *gtypes11 [] = {
g_atype11_0,
};

static const long offsets11 [] =
{
0,
};

extern const char *names14[];
static const uint32 types14 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags14 [] =
{0,};

static const EIF_TYPE_INDEX g_atype14_0 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes14 [] = {
g_atype14_0,
};

static const long offsets14 [] =
{
+ @CHROFF(0,0),
};

extern const char *names15[];
static const uint32 types15 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags15 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype15_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype15_1 [] = {0xFF01,150,0xFFFF};
static const EIF_TYPE_INDEX g_atype15_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes15 [] = {
g_atype15_0,
g_atype15_1,
g_atype15_2,
};

static const long offsets15 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names16[];
static const uint32 types16 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags16 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype16_0 [] = {0xFF01,402,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_1 [] = {0xFF01,402,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_2 [] = {0xFF01,402,0xFFFF};

static const EIF_TYPE_INDEX *gtypes16 [] = {
g_atype16_0,
g_atype16_1,
g_atype16_2,
};

static const long offsets16 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names22[];
static const uint32 types22 [] =
{
SK_REF,
};

static const uint16 attr_flags22 [] =
{0,};

static const EIF_TYPE_INDEX g_atype22_0 [] = {0xFF01,1235,1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes22 [] = {
g_atype22_0,
};

static const long offsets22 [] =
{
0,
};

extern const char *names25[];
static const uint32 types25 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags25 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype25_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype25_1 [] = {0xFF01,1233,1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes25 [] = {
g_atype25_0,
g_atype25_1,
};

static const long offsets25 [] =
{
0,
 + @REFACS(1),
};

extern const char *names26[];
static const uint32 types26 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags26 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype26_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_1 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes26 [] = {
g_atype26_0,
g_atype26_1,
g_atype26_2,
g_atype26_3,
g_atype26_4,
g_atype26_5,
};

static const long offsets26 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags28 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {0xFF01,129,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_1 [] = {0xFF01,15,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_2 [] = {0xFF01,149,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_3 [] = {0xFF01,14,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_4 [] = {0xFF01,13,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_5 [] = {0xFF01,217,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
g_atype28_1,
g_atype28_2,
g_atype28_3,
g_atype28_4,
g_atype28_5,
};

static const long offsets28 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags34 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {0xFF01,1117,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
};

static const long offsets34 [] =
{
0,
 + @REFACS(1),
};

extern const char *names38[];
static const uint32 types38 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags38 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype38_0 [] = {0xFF01,169,0xFFFF};
static const EIF_TYPE_INDEX g_atype38_1 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype38_2 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype38_3 [] = {0xFF01,970,0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes38 [] = {
g_atype38_0,
g_atype38_1,
g_atype38_2,
g_atype38_3,
};

static const long offsets38 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names40[];
static const uint32 types40 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags40 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype40_0 [] = {0xFF01,961,1160,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_1 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes40 [] = {
g_atype40_0,
g_atype40_1,
};

static const long offsets40 [] =
{
0,
 + @REFACS(1),
};

extern const char *names41[];
static const uint32 types41 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags41 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype41_0 [] = {0xFF01,568,0xFFFF};
static const EIF_TYPE_INDEX g_atype41_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype41_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes41 [] = {
g_atype41_0,
g_atype41_1,
g_atype41_2,
};

static const long offsets41 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags44 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {0xFF01,1071,0xFF01,1117,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
g_atype44_1,
g_atype44_2,
};

static const long offsets44 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags46 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {189,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
g_atype46_1,
g_atype46_2,
g_atype46_3,
g_atype46_4,
};

static const long offsets46 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names47[];
static const uint32 types47 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags47 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype47_0 [] = {0xFF01,546,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes47 [] = {
g_atype47_0,
g_atype47_1,
g_atype47_2,
};

static const long offsets47 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names48[];
static const uint32 types48 [] =
{
SK_REF,
};

static const uint16 attr_flags48 [] =
{0,};

static const EIF_TYPE_INDEX g_atype48_0 [] = {0xFF01,1058,0xFF01,169,0xFFFF};

static const EIF_TYPE_INDEX *gtypes48 [] = {
g_atype48_0,
};

static const long offsets48 [] =
{
0,
};

extern const char *names51[];
static const uint32 types51 [] =
{
SK_REF,
};

static const uint16 attr_flags51 [] =
{0,};

static const EIF_TYPE_INDEX g_atype51_0 [] = {0xFF01,1053,0xFF01,960,0xFF01,1170,0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes51 [] = {
g_atype51_0,
};

static const long offsets51 [] =
{
0,
};

extern const char *names52[];
static const uint32 types52 [] =
{
SK_BOOL,
SK_UINT8,
};

static const uint16 attr_flags52 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype52_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype52_1 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes52 [] = {
g_atype52_0,
g_atype52_1,
};

static const long offsets52 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names53[];
static const uint32 types53 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags53 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype53_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype53_1 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype53_2 [] = {1428,0xFFFF};
static const EIF_TYPE_INDEX g_atype53_3 [] = {1192,0xFFFF};

static const EIF_TYPE_INDEX *gtypes53 [] = {
g_atype53_0,
g_atype53_1,
g_atype53_2,
g_atype53_3,
};

static const long offsets53 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names55[];
static const uint32 types55 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags55 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype55_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_2 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_3 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes55 [] = {
g_atype55_0,
g_atype55_1,
g_atype55_2,
g_atype55_3,
g_atype55_4,
g_atype55_5,
g_atype55_6,
};

static const long offsets55 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names56[];
static const uint32 types56 [] =
{
SK_UINT32,
};

static const uint16 attr_flags56 [] =
{0,};

static const EIF_TYPE_INDEX g_atype56_0 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes56 [] = {
g_atype56_0,
};

static const long offsets56 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_UINT32,
};

static const uint16 attr_flags57 [] =
{1,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
};

static const long offsets57 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names59[];
static const uint32 types59 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags59 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype59_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_1 [] = {1427,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_2 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes59 [] = {
g_atype59_0,
g_atype59_1,
g_atype59_2,
g_atype59_3,
};

static const long offsets59 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names60[];
static const uint32 types60 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags60 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype60_0 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_2 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_4 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_5 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_6 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_7 [] = {1058,0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes60 [] = {
g_atype60_0,
g_atype60_1,
g_atype60_2,
g_atype60_3,
g_atype60_4,
g_atype60_5,
g_atype60_6,
g_atype60_7,
};

static const long offsets60 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
};

extern const char *names61[];
static const uint32 types61 [] =
{
SK_INT32,
};

static const uint16 attr_flags61 [] =
{0,};

static const EIF_TYPE_INDEX g_atype61_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes61 [] = {
g_atype61_0,
};

static const long offsets61 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags62 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_2 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_3 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
g_atype62_2,
g_atype62_3,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names64[];
static const uint32 types64 [] =
{
SK_REF,
};

static const uint16 attr_flags64 [] =
{0,};

static const EIF_TYPE_INDEX g_atype64_0 [] = {0xFF01,1058,0xFF01,1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes64 [] = {
g_atype64_0,
};

static const long offsets64 [] =
{
0,
};

extern const char *names68[];
static const uint32 types68 [] =
{
SK_REF,
};

static const uint16 attr_flags68 [] =
{0,};

static const EIF_TYPE_INDEX g_atype68_0 [] = {0xFF01,1102,0xFFFF};

static const EIF_TYPE_INDEX *gtypes68 [] = {
g_atype68_0,
};

static const long offsets68 [] =
{
0,
};

extern const char *names69[];
static const uint32 types69 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags69 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype69_0 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype69_1 [] = {0xFF01,1375,0xFFFF};

static const EIF_TYPE_INDEX *gtypes69 [] = {
g_atype69_0,
g_atype69_1,
};

static const long offsets69 [] =
{
0,
 + @REFACS(1),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags70 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {0xFFF9,2,1113,0xFF01,1173,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_2 [] = {0xFF01,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_3 [] = {0xFF01,710,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_4 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_5 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_6 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_7 [] = {935,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_8 [] = {935,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_9 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_10 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
g_atype70_2,
g_atype70_3,
g_atype70_4,
g_atype70_5,
g_atype70_6,
g_atype70_7,
g_atype70_8,
g_atype70_9,
g_atype70_10,
};

static const long offsets70 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags71 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_1 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_2 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_3 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_4 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_5 [] = {1058,0xFF01,0xFFF9,3,1113,1173,0xFF01,1173,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_6 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_7 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1173,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
g_atype71_1,
g_atype71_2,
g_atype71_3,
g_atype71_4,
g_atype71_5,
g_atype71_6,
g_atype71_7,
g_atype71_8,
g_atype71_9,
};

static const long offsets71 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names84[];
static const uint32 types84 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags84 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype84_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes84 [] = {
g_atype84_0,
g_atype84_1,
g_atype84_2,
g_atype84_3,
};

static const long offsets84 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
};

static const uint16 attr_flags100 [] =
{0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
};

static const long offsets100 [] =
{
0,
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags101 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {0xFF01,1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_1 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_2 [] = {0xFF01,1110,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_3 [] = {0xFF01,1109,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
g_atype101_1,
g_atype101_2,
g_atype101_3,
};

static const long offsets101 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags107 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {106,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_1 [] = {215,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
g_atype107_1,
g_atype107_2,
};

static const long offsets107 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names108[];
static const uint32 types108 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags108 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype108_0 [] = {106,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_1 [] = {216,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes108 [] = {
g_atype108_0,
g_atype108_1,
g_atype108_2,
};

static const long offsets108 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_REF,
};

static const uint16 attr_flags110 [] =
{0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {0xFF01,546,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
};

static const long offsets110 [] =
{
0,
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags126 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_2 [] = {1175,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
g_atype126_1,
g_atype126_2,
};

static const long offsets126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags127 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_5 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_6 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_7 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_8 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_9 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_10 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_11 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_12 [] = {0xFF01,988,0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
g_atype127_2,
g_atype127_3,
g_atype127_4,
g_atype127_5,
g_atype127_6,
g_atype127_7,
g_atype127_8,
g_atype127_9,
g_atype127_10,
g_atype127_11,
g_atype127_12,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_5 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
g_atype128_2,
g_atype128_3,
g_atype128_4,
g_atype128_5,
g_atype128_6,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags129 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_5 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_6 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_7 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_8 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_9 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_10 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_11 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_15 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
g_atype129_2,
g_atype129_3,
g_atype129_4,
g_atype129_5,
g_atype129_6,
g_atype129_7,
g_atype129_8,
g_atype129_9,
g_atype129_10,
g_atype129_11,
g_atype129_12,
g_atype129_13,
g_atype129_14,
g_atype129_15,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @LNGOFF(12,0,0,0),
+ @LNGOFF(12,0,0,1),
+ @LNGOFF(12,0,0,2),
+ @LNGOFF(12,0,0,3),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags130 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_5 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_6 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_7 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_8 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_9 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_10 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_11 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_12 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_13 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_14 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_15 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_16 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_17 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_18 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_19 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_20 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_21 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_22 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_23 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_24 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_25 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_26 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_27 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_28 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_29 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_30 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_31 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_32 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_33 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_34 [] = {0xFF01,1348,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_35 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_36 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_37 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_38 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_39 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
g_atype130_3,
g_atype130_4,
g_atype130_5,
g_atype130_6,
g_atype130_7,
g_atype130_8,
g_atype130_9,
g_atype130_10,
g_atype130_11,
g_atype130_12,
g_atype130_13,
g_atype130_14,
g_atype130_15,
g_atype130_16,
g_atype130_17,
g_atype130_18,
g_atype130_19,
g_atype130_20,
g_atype130_21,
g_atype130_22,
g_atype130_23,
g_atype130_24,
g_atype130_25,
g_atype130_26,
g_atype130_27,
g_atype130_28,
g_atype130_29,
g_atype130_30,
g_atype130_31,
g_atype130_32,
g_atype130_33,
g_atype130_34,
g_atype130_35,
g_atype130_36,
g_atype130_37,
g_atype130_38,
g_atype130_39,
};

static const long offsets130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
+ @LNGOFF(35,0,0,0),
+ @LNGOFF(35,0,0,1),
+ @LNGOFF(35,0,0,2),
+ @LNGOFF(35,0,0,3),
+ @LNGOFF(35,0,0,4),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
};

static const uint16 attr_flags134 [] =
{0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
};

static const long offsets134 [] =
{
0,
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
};

static const long offsets135 [] =
{
+ @CHROFF(0,0),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags136 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {135,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags137 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
};

static const long offsets137 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {1061,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
g_atype141_6,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags142 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_2 [] = {1061,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_4 [] = {0xFF01,1053,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_5 [] = {1061,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_8 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_9 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_12 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
g_atype142_2,
g_atype142_3,
g_atype142_4,
g_atype142_5,
g_atype142_6,
g_atype142_7,
g_atype142_8,
g_atype142_9,
g_atype142_10,
g_atype142_11,
g_atype142_12,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @LNGOFF(6,2,0,1),
+ @LNGOFF(6,2,0,2),
+ @LNGOFF(6,2,0,3),
+ @LNGOFF(6,2,0,4),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
};

static const uint16 attr_flags148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
};

static const long offsets148 [] =
{
0,
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags149 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_1 [] = {0xFF01,960,0xFF01,1167,0xFF01,1348,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_2 [] = {0xFF01,1058,0xFF01,1348,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_3 [] = {0xFF01,960,0xFF01,1167,0xFF01,1344,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_4 [] = {0xFF01,1058,0xFF01,1344,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_5 [] = {0xFF01,561,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_6 [] = {0xFF01,106,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
g_atype149_1,
g_atype149_2,
g_atype149_3,
g_atype149_4,
g_atype149_5,
g_atype149_6,
};

static const long offsets149 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags150 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_4 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
g_atype150_1,
g_atype150_2,
g_atype150_3,
g_atype150_4,
g_atype150_5,
};

static const long offsets150 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags151 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_4 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
g_atype151_2,
g_atype151_3,
g_atype151_4,
g_atype151_5,
};

static const long offsets151 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
g_atype155_5,
g_atype155_6,
g_atype155_7,
};

static const long offsets155 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @LNGOFF(1,4,0,0),
+ @LNGOFF(1,4,0,1),
+ @LNGOFF(1,4,0,2),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
};

static const uint16 attr_flags163 [] =
{0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {556,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
};

static const long offsets163 [] =
{
0,
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags165 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
};

static const long offsets165 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags166 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
};

static const long offsets166 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
};

static const uint16 attr_flags167 [] =
{0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFF01,254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
};

static const long offsets167 [] =
{
0,
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
};

static const uint16 attr_flags168 [] =
{0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFF01,254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
};

static const long offsets168 [] =
{
0,
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
};

static const uint16 attr_flags169 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_3 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
g_atype169_3,
};

static const long offsets169 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags171 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {0xFF01,1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {1110,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
};

static const long offsets171 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_BOOL,
};

static const uint16 attr_flags172 [] =
{0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
};

static const long offsets172 [] =
{
+ @CHROFF(0,0),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {1106,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
};

static const long offsets173 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags177 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
};

static const long offsets177 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_BOOL,
};

static const uint16 attr_flags180 [] =
{0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
};

static const long offsets180 [] =
{
+ @CHROFF(0,0),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,440,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {1162,0xFF01,0xFFF9,2,1113,0xFF01,440,0xFF01,440,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {1058,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {966,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_11 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
g_atype181_6,
g_atype181_7,
g_atype181_8,
g_atype181_9,
g_atype181_10,
g_atype181_11,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,440,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {1162,0xFF01,0xFFF9,2,1113,0xFF01,440,0xFF01,440,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {1058,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {966,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_11 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
g_atype182_6,
g_atype182_7,
g_atype182_8,
g_atype182_9,
g_atype182_10,
g_atype182_11,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFF01,1029,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags187 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {0xFF01,1029,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
};

static const long offsets187 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
};

static const uint16 attr_flags188 [] =
{0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {0xFF01,1058,0xFF01,1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
};

static const long offsets188 [] =
{
0,
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags189 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {0xFF01,1058,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
g_atype189_1,
g_atype189_2,
};

static const long offsets189 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
};

static const uint16 attr_flags207 [] =
{0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
};

static const long offsets207 [] =
{
0,
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_INT32,
};

static const uint16 attr_flags208 [] =
{0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
};

static const long offsets208 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_BOOL,
};

static const uint16 attr_flags209 [] =
{0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
};

static const long offsets209 [] =
{
+ @CHROFF(0,0),
};

extern const char *names210[];
static const uint32 types210 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags210 [] =
{0,};

static const EIF_TYPE_INDEX g_atype210_0 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes210 [] = {
g_atype210_0,
};

static const long offsets210 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names211[];
static const uint32 types211 [] =
{
SK_UINT64,
};

static const uint16 attr_flags211 [] =
{0,};

static const EIF_TYPE_INDEX g_atype211_0 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes211 [] = {
g_atype211_0,
};

static const long offsets211 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags212 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {211,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
};

static const long offsets213 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {0xFF01,935,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
g_atype216_3,
};

static const long offsets216 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags217 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {0xFF01,935,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_1 [] = {0xFF01,0xFFF9,2,1113,1312,0xFF01,1029,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_2 [] = {0xFF01,0xFFF9,2,1113,1312,0xFF01,1029,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_14 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
g_atype217_1,
g_atype217_2,
g_atype217_3,
g_atype217_4,
g_atype217_5,
g_atype217_6,
g_atype217_7,
g_atype217_8,
g_atype217_9,
g_atype217_10,
g_atype217_11,
g_atype217_12,
g_atype217_13,
g_atype217_14,
};

static const long offsets217 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @LNGOFF(3,5,0,0),
+ @LNGOFF(3,5,0,1),
+ @LNGOFF(3,5,0,2),
+ @LNGOFF(3,5,0,3),
+ @LNGOFF(3,5,0,4),
+ @LNGOFF(3,5,0,5),
+ @LNGOFF(3,5,0,6),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags218 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
};

static const long offsets218 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags219 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {0xFF01,988,0xFF01,412,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
g_atype219_3,
g_atype219_4,
};

static const long offsets219 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags220 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
};

static const long offsets220 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags225 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
};

static const long offsets225 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names229[];
static const uint32 types229 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags229 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype229_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_1 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes229 [] = {
g_atype229_0,
g_atype229_1,
};

static const long offsets229 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags233 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {0xFF01,228,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_1 [] = {0xFF01,530,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
g_atype233_1,
};

static const long offsets233 [] =
{
0,
 + @REFACS(1),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags243 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
};

static const long offsets243 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags244 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {0xFF01,1107,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_6 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
g_atype244_3,
g_atype244_4,
g_atype244_5,
g_atype244_6,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @PTROFF(3,2,0,1,0,0),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags249 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
};

static const long offsets249 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {0xFF01,994,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags251 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
g_atype251_1,
g_atype251_2,
};

static const long offsets251 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names254[];
static const uint32 types254 [] =
{
SK_REF,
};

static const uint16 attr_flags254 [] =
{0,};

static const EIF_TYPE_INDEX g_atype254_0 [] = {556,0xFFFF};

static const EIF_TYPE_INDEX *gtypes254 [] = {
g_atype254_0,
};

static const long offsets254 [] =
{
0,
};

extern const char *names256[];
static const uint32 types256 [] =
{
SK_REF,
};

static const uint16 attr_flags256 [] =
{0,};

static const EIF_TYPE_INDEX g_atype256_0 [] = {0xFF01,254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes256 [] = {
g_atype256_0,
};

static const long offsets256 [] =
{
0,
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags258 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
g_atype258_2,
g_atype258_3,
};

static const long offsets258 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_BOOL,
};

static const uint16 attr_flags266 [] =
{0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
};

static const long offsets266 [] =
{
+ @CHROFF(0,0),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_BOOL,
};

static const uint16 attr_flags270 [] =
{0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
};

static const long offsets270 [] =
{
+ @CHROFF(0,0),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_BOOL,
};

static const uint16 attr_flags273 [] =
{0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
};

static const long offsets273 [] =
{
+ @CHROFF(0,0),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_UINT64,
};

static const uint16 attr_flags277 [] =
{0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
};

static const long offsets277 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags278 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_4 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_5 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_7 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
g_atype278_3,
g_atype278_4,
g_atype278_5,
g_atype278_6,
g_atype278_7,
};

static const long offsets278 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @I64OFF(2,0,0,5,0,0,0),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags279 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_4 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_5 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_6 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_7 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_8 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_9 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_10 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_11 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_13 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
g_atype279_3,
g_atype279_4,
g_atype279_5,
g_atype279_6,
g_atype279_7,
g_atype279_8,
g_atype279_9,
g_atype279_10,
g_atype279_11,
g_atype279_12,
g_atype279_13,
};

static const long offsets279 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
+ @LNGOFF(2,0,0,9),
+ @LNGOFF(2,0,0,10),
+ @I64OFF(2,0,0,11,0,0,0),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags281 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {570,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
};

static const long offsets281 [] =
{
0,
 + @REFACS(1),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags282 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
};

static const long offsets282 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
};

static const long offsets288 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags289 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
};

static const long offsets289 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_6 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
g_atype290_6,
};

static const long offsets290 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {0xFF01,1232,1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
};

static const long offsets292 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
g_atype293_6,
};

static const long offsets293 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags294 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_9 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_10 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
g_atype294_4,
g_atype294_5,
g_atype294_6,
g_atype294_7,
g_atype294_8,
g_atype294_9,
g_atype294_10,
};

static const long offsets294 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_8 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_9 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
g_atype295_6,
g_atype295_7,
g_atype295_8,
g_atype295_9,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_12 [] = {1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_13 [] = {1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_14 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
g_atype296_5,
g_atype296_6,
g_atype296_7,
g_atype296_8,
g_atype296_9,
g_atype296_10,
g_atype296_11,
g_atype296_12,
g_atype296_13,
g_atype296_14,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags297 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {1230,0xFF01,1233,1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags298 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {1230,0xFF01,1233,1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags299 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {1230,0xFF01,1233,1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
};

static const uint16 attr_flags302 [] =
{0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
};

static const long offsets302 [] =
{
0,
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
};

static const uint16 attr_flags304 [] =
{0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFF01,1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
};

static const long offsets304 [] =
{
0,
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
g_atype308_4,
g_atype308_5,
g_atype308_6,
g_atype308_7,
g_atype308_8,
g_atype308_9,
};

static const long offsets308 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {0xFF01,500,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
g_atype309_4,
g_atype309_5,
g_atype309_6,
g_atype309_7,
g_atype309_8,
g_atype309_9,
};

static const long offsets309 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
g_atype310_4,
g_atype310_5,
g_atype310_6,
g_atype310_7,
g_atype310_8,
g_atype310_9,
};

static const long offsets310 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {0xFF01,1087,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_11 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
g_atype311_5,
g_atype311_6,
g_atype311_7,
g_atype311_8,
g_atype311_9,
g_atype311_10,
g_atype311_11,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {0xFF01,1087,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_13 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
g_atype312_5,
g_atype312_6,
g_atype312_7,
g_atype312_8,
g_atype312_9,
g_atype312_10,
g_atype312_11,
g_atype312_12,
g_atype312_13,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {0xFF01,500,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,1087,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_14 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
g_atype313_4,
g_atype313_5,
g_atype313_6,
g_atype313_7,
g_atype313_8,
g_atype313_9,
g_atype313_10,
g_atype313_11,
g_atype313_12,
g_atype313_13,
g_atype313_14,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags314 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
};

static const long offsets314 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
};

static const uint16 attr_flags319 [] =
{0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFF01,546,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
};

static const long offsets319 [] =
{
0,
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_15 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
g_atype320_5,
g_atype320_6,
g_atype320_7,
g_atype320_8,
g_atype320_9,
g_atype320_10,
g_atype320_11,
g_atype320_12,
g_atype320_13,
g_atype320_14,
g_atype320_15,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_15 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
g_atype321_5,
g_atype321_6,
g_atype321_7,
g_atype321_8,
g_atype321_9,
g_atype321_10,
g_atype321_11,
g_atype321_12,
g_atype321_13,
g_atype321_14,
g_atype321_15,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_15 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
g_atype322_5,
g_atype322_6,
g_atype322_7,
g_atype322_8,
g_atype322_9,
g_atype322_10,
g_atype322_11,
g_atype322_12,
g_atype322_13,
g_atype322_14,
g_atype322_15,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
};

static const uint16 attr_flags323 [] =
{0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {0xFF01,1431,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
};

static const long offsets323 [] =
{
0,
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
g_atype324_5,
g_atype324_6,
g_atype324_7,
g_atype324_8,
g_atype324_9,
g_atype324_10,
g_atype324_11,
g_atype324_12,
g_atype324_13,
g_atype324_14,
g_atype324_15,
g_atype324_16,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
g_atype325_5,
g_atype325_6,
g_atype325_7,
g_atype325_8,
g_atype325_9,
g_atype325_10,
g_atype325_11,
g_atype325_12,
g_atype325_13,
g_atype325_14,
g_atype325_15,
g_atype325_16,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
g_atype326_5,
g_atype326_6,
g_atype326_7,
g_atype326_8,
g_atype326_9,
g_atype326_10,
g_atype326_11,
g_atype326_12,
g_atype326_13,
g_atype326_14,
g_atype326_15,
g_atype326_16,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
};

static const uint16 attr_flags327 [] =
{0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
};

static const long offsets327 [] =
{
0,
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
};

static const uint16 attr_flags328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
};

static const long offsets328 [] =
{
0,
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags330 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {0xFF01,326,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
};

static const uint16 attr_flags332 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {0xFF01,326,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {0xFF01,336,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_8 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_9 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
g_atype332_5,
g_atype332_6,
g_atype332_7,
g_atype332_8,
g_atype332_9,
};

static const long offsets332 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {0xFF01,326,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {0xFF01,336,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_4 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_10 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_11 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_14 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
g_atype333_3,
g_atype333_4,
g_atype333_5,
g_atype333_6,
g_atype333_7,
g_atype333_8,
g_atype333_9,
g_atype333_10,
g_atype333_11,
g_atype333_12,
g_atype333_13,
g_atype333_14,
};

static const long offsets333 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags334 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {0xFF01,326,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
};

static const long offsets334 [] =
{
0,
 + @REFACS(1),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags335 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {0xFF01,326,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {0xFF01,1072,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {0xFF01,1072,0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
};

static const long offsets335 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags336 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {0xFF01,326,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {0xFF01,50,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_5 [] = {0xFF01,908,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_6 [] = {0xFF01,908,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_7 [] = {0xFF01,908,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_8 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
g_atype336_4,
g_atype336_5,
g_atype336_6,
g_atype336_7,
g_atype336_8,
};

static const long offsets336 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags338 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
g_atype338_3,
g_atype338_4,
g_atype338_5,
g_atype338_6,
};

static const long offsets338 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
};

static const uint16 attr_flags339 [] =
{0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {0xFF01,340,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
};

static const long offsets339 [] =
{
0,
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_UINT32,
};

static const uint16 attr_flags340 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {0xFF01,340,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
};

static const long offsets340 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
};

static const uint16 attr_flags343 [] =
{0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {1074,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
};

static const long offsets343 [] =
{
0,
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags347 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
};

static const long offsets347 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags348 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
};

static const long offsets348 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_INT32,
};

static const uint16 attr_flags349 [] =
{0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
};

static const long offsets349 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_INT32,
};

static const uint16 attr_flags350 [] =
{0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
};

static const long offsets350 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags357 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
g_atype357_1,
g_atype357_2,
g_atype357_3,
g_atype357_4,
g_atype357_5,
g_atype357_6,
};

static const long offsets357 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags358 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
g_atype358_1,
g_atype358_2,
g_atype358_3,
g_atype358_4,
g_atype358_5,
g_atype358_6,
};

static const long offsets358 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags359 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
g_atype359_1,
g_atype359_2,
g_atype359_3,
g_atype359_4,
g_atype359_5,
g_atype359_6,
};

static const long offsets359 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags360 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
g_atype360_1,
g_atype360_2,
g_atype360_3,
g_atype360_4,
g_atype360_5,
g_atype360_6,
};

static const long offsets360 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags361 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
g_atype361_1,
g_atype361_2,
g_atype361_3,
g_atype361_4,
g_atype361_5,
g_atype361_6,
};

static const long offsets361 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags362 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
g_atype362_1,
g_atype362_2,
g_atype362_3,
g_atype362_4,
g_atype362_5,
g_atype362_6,
g_atype362_7,
};

static const long offsets362 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags363 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
g_atype363_1,
g_atype363_2,
g_atype363_3,
g_atype363_4,
g_atype363_5,
g_atype363_6,
g_atype363_7,
};

static const long offsets363 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags364 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_5 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
g_atype364_1,
g_atype364_2,
g_atype364_3,
g_atype364_4,
g_atype364_5,
g_atype364_6,
g_atype364_7,
g_atype364_8,
g_atype364_9,
};

static const long offsets364 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags365 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
g_atype365_1,
g_atype365_2,
g_atype365_3,
g_atype365_4,
g_atype365_5,
g_atype365_6,
};

static const long offsets365 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags366 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
g_atype366_1,
g_atype366_2,
g_atype366_3,
g_atype366_4,
g_atype366_5,
g_atype366_6,
};

static const long offsets366 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags367 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
g_atype367_1,
g_atype367_2,
g_atype367_3,
g_atype367_4,
g_atype367_5,
g_atype367_6,
};

static const long offsets367 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags368 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
g_atype368_1,
g_atype368_2,
g_atype368_3,
g_atype368_4,
g_atype368_5,
g_atype368_6,
};

static const long offsets368 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags369 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
g_atype369_5,
g_atype369_6,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags370 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
g_atype370_5,
g_atype370_6,
};

static const long offsets370 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags371 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
g_atype371_1,
g_atype371_2,
g_atype371_3,
g_atype371_4,
g_atype371_5,
g_atype371_6,
g_atype371_7,
};

static const long offsets371 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags372 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
g_atype372_1,
g_atype372_2,
g_atype372_3,
g_atype372_4,
g_atype372_5,
g_atype372_6,
};

static const long offsets372 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags373 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
g_atype373_1,
g_atype373_2,
g_atype373_3,
g_atype373_4,
g_atype373_5,
g_atype373_6,
};

static const long offsets373 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags374 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
g_atype374_1,
g_atype374_2,
g_atype374_3,
g_atype374_4,
g_atype374_5,
g_atype374_6,
g_atype374_7,
};

static const long offsets374 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags375 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
g_atype375_1,
g_atype375_2,
g_atype375_3,
g_atype375_4,
g_atype375_5,
g_atype375_6,
};

static const long offsets375 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags376 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
g_atype376_1,
g_atype376_2,
g_atype376_3,
g_atype376_4,
g_atype376_5,
g_atype376_6,
};

static const long offsets376 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags377 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
g_atype377_1,
g_atype377_2,
g_atype377_3,
g_atype377_4,
g_atype377_5,
g_atype377_6,
};

static const long offsets377 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags378 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
g_atype378_1,
g_atype378_2,
g_atype378_3,
g_atype378_4,
g_atype378_5,
g_atype378_6,
};

static const long offsets378 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags379 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
g_atype379_1,
g_atype379_2,
g_atype379_3,
g_atype379_4,
g_atype379_5,
g_atype379_6,
g_atype379_7,
g_atype379_8,
};

static const long offsets379 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags380 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
g_atype380_1,
g_atype380_2,
g_atype380_3,
g_atype380_4,
g_atype380_5,
g_atype380_6,
};

static const long offsets380 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags381 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
g_atype381_1,
g_atype381_2,
g_atype381_3,
g_atype381_4,
g_atype381_5,
g_atype381_6,
};

static const long offsets381 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags382 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_5 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_6 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
g_atype382_1,
g_atype382_2,
g_atype382_3,
g_atype382_4,
g_atype382_5,
g_atype382_6,
g_atype382_7,
g_atype382_8,
};

static const long offsets382 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags383 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
g_atype383_1,
g_atype383_2,
g_atype383_3,
g_atype383_4,
g_atype383_5,
g_atype383_6,
};

static const long offsets383 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags384 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
g_atype384_1,
g_atype384_2,
g_atype384_3,
g_atype384_4,
g_atype384_5,
g_atype384_6,
};

static const long offsets384 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags385 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
g_atype385_1,
g_atype385_2,
g_atype385_3,
g_atype385_4,
g_atype385_5,
g_atype385_6,
};

static const long offsets385 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags386 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
g_atype386_1,
g_atype386_2,
g_atype386_3,
g_atype386_4,
g_atype386_5,
g_atype386_6,
};

static const long offsets386 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags387 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
g_atype387_1,
g_atype387_2,
g_atype387_3,
g_atype387_4,
g_atype387_5,
g_atype387_6,
};

static const long offsets387 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags388 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
g_atype388_1,
g_atype388_2,
g_atype388_3,
g_atype388_4,
g_atype388_5,
g_atype388_6,
};

static const long offsets388 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags389 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_5 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
g_atype389_1,
g_atype389_2,
g_atype389_3,
g_atype389_4,
g_atype389_5,
g_atype389_6,
g_atype389_7,
};

static const long offsets389 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags390 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
g_atype390_1,
g_atype390_2,
g_atype390_3,
g_atype390_4,
g_atype390_5,
g_atype390_6,
};

static const long offsets390 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags391 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
g_atype391_1,
g_atype391_2,
g_atype391_3,
g_atype391_4,
g_atype391_5,
g_atype391_6,
};

static const long offsets391 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags392 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
g_atype392_1,
g_atype392_2,
g_atype392_3,
g_atype392_4,
g_atype392_5,
g_atype392_6,
};

static const long offsets392 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags393 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
g_atype393_1,
g_atype393_2,
g_atype393_3,
g_atype393_4,
g_atype393_5,
g_atype393_6,
};

static const long offsets393 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags394 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
g_atype394_1,
g_atype394_2,
g_atype394_3,
g_atype394_4,
g_atype394_5,
g_atype394_6,
};

static const long offsets394 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags395 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
g_atype395_1,
g_atype395_2,
g_atype395_3,
g_atype395_4,
g_atype395_5,
g_atype395_6,
};

static const long offsets395 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags396 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
g_atype396_1,
g_atype396_2,
g_atype396_3,
g_atype396_4,
g_atype396_5,
g_atype396_6,
g_atype396_7,
};

static const long offsets396 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags397 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
g_atype397_1,
g_atype397_2,
g_atype397_3,
g_atype397_4,
g_atype397_5,
g_atype397_6,
};

static const long offsets397 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags398 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_2 [] = {356,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_3 [] = {502,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
g_atype398_1,
g_atype398_2,
g_atype398_3,
g_atype398_4,
g_atype398_5,
g_atype398_6,
};

static const long offsets398 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_REF,
};

static const uint16 attr_flags400 [] =
{0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
};

static const long offsets400 [] =
{
0,
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
};

static const uint16 attr_flags401 [] =
{0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
};

static const long offsets401 [] =
{
0,
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_REF,
};

static const uint16 attr_flags402 [] =
{0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
};

static const long offsets402 [] =
{
0,
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
};

static const uint16 attr_flags403 [] =
{0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {0xFF01,1053,0xFF01,398,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
};

static const long offsets403 [] =
{
0,
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags407 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_1 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
g_atype407_1,
};

static const long offsets407 [] =
{
0,
 + @REFACS(1),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags409 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {1422,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
g_atype409_2,
g_atype409_3,
};

static const long offsets409 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags410 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_2 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
g_atype410_2,
};

static const long offsets410 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags411 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {1427,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {0xFF01,409,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {0xFF01,408,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
};

static const long offsets411 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags413 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_3 [] = {0xFF01,988,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_4 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_5 [] = {1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
g_atype413_1,
g_atype413_2,
g_atype413_3,
g_atype413_4,
g_atype413_5,
};

static const long offsets413 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_BOOL,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
+ @CHROFF(0,0),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_BOOL,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
+ @CHROFF(0,0),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_REF,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
0,
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags424 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {581,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_3 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_6 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
g_atype424_3,
g_atype424_4,
g_atype424_5,
g_atype424_6,
};

static const long offsets424 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags425 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_2 [] = {581,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_3 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_5 [] = {1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_6 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_11 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
g_atype425_2,
g_atype425_3,
g_atype425_4,
g_atype425_5,
g_atype425_6,
g_atype425_7,
g_atype425_8,
g_atype425_9,
g_atype425_10,
g_atype425_11,
};

static const long offsets425 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,970,0xFF01,1353,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
g_atype427_2,
g_atype427_3,
g_atype427_4,
g_atype427_5,
g_atype427_6,
g_atype427_7,
};

static const long offsets427 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags428 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {594,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {594,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_2 [] = {0xFF01,970,0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
g_atype428_2,
};

static const long offsets428 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_REF,
};

static const uint16 attr_flags429 [] =
{0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
};

static const long offsets429 [] =
{
0,
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags430 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_1 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_2 [] = {1399,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
g_atype430_1,
g_atype430_2,
g_atype430_3,
g_atype430_4,
};

static const long offsets430 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags431 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_1 [] = {1350,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_2 [] = {1350,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_3 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_4 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_5 [] = {1420,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_6 [] = {1420,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
g_atype431_1,
g_atype431_2,
g_atype431_3,
g_atype431_4,
g_atype431_5,
g_atype431_6,
};

static const long offsets431 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags432 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
g_atype432_2,
g_atype432_3,
};

static const long offsets432 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags433 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
g_atype433_3,
};

static const long offsets433 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags434 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
g_atype434_3,
};

static const long offsets434 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags435 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
g_atype435_1,
g_atype435_2,
g_atype435_3,
};

static const long offsets435 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags436 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
g_atype436_3,
};

static const long offsets436 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags437 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
g_atype437_1,
g_atype437_2,
g_atype437_3,
};

static const long offsets437 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags438 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
g_atype438_1,
g_atype438_2,
g_atype438_3,
};

static const long offsets438 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags439 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_2 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_3 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
g_atype439_1,
g_atype439_2,
g_atype439_3,
};

static const long offsets439 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_INT32,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags445 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {0xFF01,440,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
g_atype445_1,
g_atype445_2,
g_atype445_3,
};

static const long offsets445 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags446 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
g_atype446_1,
g_atype446_2,
};

static const long offsets446 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags448 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {0xFF01,1382,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_1 [] = {69,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_2 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
g_atype448_1,
g_atype448_2,
g_atype448_3,
g_atype448_4,
};

static const long offsets448 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags449 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {0xFF01,1383,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_1 [] = {69,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_2 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
g_atype449_1,
g_atype449_2,
g_atype449_3,
g_atype449_4,
};

static const long offsets449 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {0xFF01,546,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
};

static const long offsets454 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_INT32,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags456 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_1 [] = {0xFF01,1107,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_2 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_7 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
g_atype456_1,
g_atype456_2,
g_atype456_3,
g_atype456_4,
g_atype456_5,
g_atype456_6,
g_atype456_7,
};

static const long offsets456 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags457 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_1 [] = {0xFF01,1107,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_2 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_7 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
g_atype457_1,
g_atype457_2,
g_atype457_3,
g_atype457_4,
g_atype457_5,
g_atype457_6,
g_atype457_7,
};

static const long offsets457 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags458 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_1 [] = {0xFF01,1107,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_2 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_7 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
g_atype458_1,
g_atype458_2,
g_atype458_3,
g_atype458_4,
g_atype458_5,
g_atype458_6,
g_atype458_7,
};

static const long offsets458 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags459 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {1106,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_1 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_2 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_8 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
g_atype459_1,
g_atype459_2,
g_atype459_3,
g_atype459_4,
g_atype459_5,
g_atype459_6,
g_atype459_7,
g_atype459_8,
};

static const long offsets459 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
+ @LNGOFF(3,3,0,1),
+ @PTROFF(3,3,0,2,0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_INT32,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_INT32,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_INT32,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_REF,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
0,
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_REF,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {0xFF01,1231,1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
0,
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_REF,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {0xFF01,1232,1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
0,
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_REF,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {0xFF01,1233,1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
0,
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_REF,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {0xFF01,1234,1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
0,
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_REF,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {0xFF01,1235,1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
0,
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_REF,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {0xFF01,1236,1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
0,
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_REF,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {0xFF01,1237,1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
0,
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_REF,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {0xFF01,1238,1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
0,
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_REF,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {0xFF01,1239,1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
0,
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_REF,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {0xFF01,1240,1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
0,
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_REF,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {0xFF01,1241,1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
0,
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_REF,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {0xFF01,1235,1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
0,
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_1 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
g_atype476_1,
g_atype476_2,
g_atype476_3,
g_atype476_4,
};

static const long offsets476 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_1 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
g_atype477_1,
g_atype477_2,
g_atype477_3,
g_atype477_4,
};

static const long offsets477 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags479 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_1 [] = {0xFF01,1058,0xFF01,712,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
g_atype479_1,
};

static const long offsets479 [] =
{
0,
 + @REFACS(1),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
g_atype483_1,
g_atype483_2,
g_atype483_3,
g_atype483_4,
g_atype483_5,
g_atype483_6,
g_atype483_7,
g_atype483_8,
g_atype483_9,
g_atype483_10,
g_atype483_11,
g_atype483_12,
g_atype483_13,
g_atype483_14,
g_atype483_15,
g_atype483_16,
};

static const long offsets483 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
g_atype485_1,
g_atype485_2,
g_atype485_3,
g_atype485_4,
g_atype485_5,
g_atype485_6,
g_atype485_7,
g_atype485_8,
g_atype485_9,
g_atype485_10,
g_atype485_11,
g_atype485_12,
g_atype485_13,
g_atype485_14,
g_atype485_15,
g_atype485_16,
};

static const long offsets485 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
g_atype487_1,
g_atype487_2,
g_atype487_3,
g_atype487_4,
g_atype487_5,
g_atype487_6,
g_atype487_7,
g_atype487_8,
g_atype487_9,
g_atype487_10,
g_atype487_11,
g_atype487_12,
g_atype487_13,
g_atype487_14,
g_atype487_15,
g_atype487_16,
};

static const long offsets487 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
g_atype489_1,
g_atype489_2,
g_atype489_3,
g_atype489_4,
g_atype489_5,
g_atype489_6,
g_atype489_7,
g_atype489_8,
g_atype489_9,
g_atype489_10,
g_atype489_11,
g_atype489_12,
g_atype489_13,
g_atype489_14,
g_atype489_15,
g_atype489_16,
};

static const long offsets489 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
g_atype491_1,
g_atype491_2,
g_atype491_3,
g_atype491_4,
g_atype491_5,
g_atype491_6,
g_atype491_7,
g_atype491_8,
g_atype491_9,
g_atype491_10,
g_atype491_11,
g_atype491_12,
g_atype491_13,
g_atype491_14,
g_atype491_15,
g_atype491_16,
};

static const long offsets491 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
g_atype493_1,
g_atype493_2,
g_atype493_3,
g_atype493_4,
g_atype493_5,
g_atype493_6,
g_atype493_7,
g_atype493_8,
g_atype493_9,
g_atype493_10,
g_atype493_11,
g_atype493_12,
g_atype493_13,
g_atype493_14,
g_atype493_15,
g_atype493_16,
};

static const long offsets493 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
g_atype495_1,
g_atype495_2,
g_atype495_3,
g_atype495_4,
g_atype495_5,
g_atype495_6,
g_atype495_7,
g_atype495_8,
g_atype495_9,
g_atype495_10,
g_atype495_11,
g_atype495_12,
g_atype495_13,
g_atype495_14,
g_atype495_15,
g_atype495_16,
};

static const long offsets495 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
g_atype498_1,
g_atype498_2,
g_atype498_3,
g_atype498_4,
g_atype498_5,
g_atype498_6,
g_atype498_7,
g_atype498_8,
g_atype498_9,
g_atype498_10,
g_atype498_11,
g_atype498_12,
g_atype498_13,
g_atype498_14,
g_atype498_15,
g_atype498_16,
};

static const long offsets498 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {0xFF01,164,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_1 [] = {0xFF01,1058,0xFF01,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_2 [] = {0xFF01,1058,0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_3 [] = {299,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_4 [] = {0xFF01,1431,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_16 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
g_atype499_1,
g_atype499_2,
g_atype499_3,
g_atype499_4,
g_atype499_5,
g_atype499_6,
g_atype499_7,
g_atype499_8,
g_atype499_9,
g_atype499_10,
g_atype499_11,
g_atype499_12,
g_atype499_13,
g_atype499_14,
g_atype499_15,
g_atype499_16,
};

static const long offsets499 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @CHROFF(5,7),
+ @CHROFF(5,8),
+ @CHROFF(5,9),
+ @CHROFF(5,10),
+ @CHROFF(5,11),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags501 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_2 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_3 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_4 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
g_atype501_1,
g_atype501_2,
g_atype501_3,
g_atype501_4,
};

static const long offsets501 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags502 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_1 [] = {0xFF01,1234,1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
g_atype502_1,
};

static const long offsets502 [] =
{
0,
 + @REFACS(1),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags503 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {0xFF01,546,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
g_atype503_1,
};

static const long offsets503 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags516 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_1 [] = {0xFFF5,1,0xFF01,1230,0xFFF8,1,7375,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_2 [] = {0xFFF5,1,0xFF01,908,0xFFF8,1,7160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
g_atype516_1,
g_atype516_2,
};

static const long offsets516 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags517 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {0xFF01,1350,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
g_atype517_1,
};

static const long offsets517 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags518 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {0xFF01,1351,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
g_atype518_1,
};

static const long offsets518 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags519 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {0xFF01,1352,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
g_atype519_1,
};

static const long offsets519 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_INT32,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_REF,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {0xFF01,1175,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
0,
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags544 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_1 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
g_atype544_1,
};

static const long offsets544 [] =
{
+ @PTROFF(0,0,0,0,0,0),
+ @PTROFF(0,0,0,0,0,1),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_POINTER,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags546 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_1 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
g_atype546_1,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags547 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_2 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_3 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
g_atype547_1,
g_atype547_2,
g_atype547_3,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_POINTER,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_POINTER,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_REF,
SK_REF,
SK_POINTER,
};

static const uint16 attr_flags550 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_1 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_2 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
g_atype550_1,
g_atype550_2,
};

static const long offsets550 [] =
{
0,
 + @REFACS(1),
+ @PTROFF(2,0,0,0,0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags551 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
g_atype551_1,
};

static const long offsets551 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags553 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_1 [] = {988,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_2 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_4 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_5 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_6 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_7 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_8 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_9 [] = {937,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_10 [] = {937,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_11 [] = {937,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_12 [] = {563,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_13 [] = {563,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_14 [] = {563,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_28 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
g_atype553_1,
g_atype553_2,
g_atype553_3,
g_atype553_4,
g_atype553_5,
g_atype553_6,
g_atype553_7,
g_atype553_8,
g_atype553_9,
g_atype553_10,
g_atype553_11,
g_atype553_12,
g_atype553_13,
g_atype553_14,
g_atype553_15,
g_atype553_16,
g_atype553_17,
g_atype553_18,
g_atype553_19,
g_atype553_20,
g_atype553_21,
g_atype553_22,
g_atype553_23,
g_atype553_24,
g_atype553_25,
g_atype553_26,
g_atype553_27,
g_atype553_28,
};

static const long offsets553 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
+ @CHROFF(15,3),
+ @CHROFF(15,4),
+ @CHROFF(15,5),
+ @CHROFF(15,6),
+ @CHROFF(15,7),
+ @CHROFF(15,8),
+ @CHROFF(15,9),
+ @CHROFF(15,10),
+ @LNGOFF(15,11,0,0),
+ @LNGOFF(15,11,0,1),
+ @LNGOFF(15,11,0,2),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_POINTER,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_POINTER,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_POINTER,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags560 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype560_1 [] = {935,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
g_atype560_1,
};

static const long offsets560 [] =
{
0,
 + @REFACS(1),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_INT32,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags562 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_4 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_5 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
g_atype562_1,
g_atype562_2,
g_atype562_3,
g_atype562_4,
g_atype562_5,
};

static const long offsets562 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags563 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_1 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_2 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_3 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_4 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_5 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_6 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_9 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_10 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_11 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_12 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
g_atype563_1,
g_atype563_2,
g_atype563_3,
g_atype563_4,
g_atype563_5,
g_atype563_6,
g_atype563_7,
g_atype563_8,
g_atype563_9,
g_atype563_10,
g_atype563_11,
g_atype563_12,
};

static const long offsets563 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags564 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_1 [] = {0xFF01,546,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_7 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_8 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_9 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_10 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_11 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_16 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_17 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_18 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_19 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
g_atype564_1,
g_atype564_2,
g_atype564_3,
g_atype564_4,
g_atype564_5,
g_atype564_6,
g_atype564_7,
g_atype564_8,
g_atype564_9,
g_atype564_10,
g_atype564_11,
g_atype564_12,
g_atype564_13,
g_atype564_14,
g_atype564_15,
g_atype564_16,
g_atype564_17,
g_atype564_18,
g_atype564_19,
};

static const long offsets564 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @CHROFF(2,6),
+ @I16OFF(2,7,0),
+ @I16OFF(2,7,1),
+ @LNGOFF(2,7,2,0),
+ @LNGOFF(2,7,2,1),
+ @LNGOFF(2,7,2,2),
+ @LNGOFF(2,7,2,3),
+ @LNGOFF(2,7,2,4),
+ @R32OFF(2,7,2,5,0),
+ @I64OFF(2,7,2,5,1,0,0),
+ @I64OFF(2,7,2,5,1,0,1),
+ @R64OFF(2,7,2,5,1,0,2,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags565 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_1 [] = {109,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_2 [] = {109,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_12 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_13 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_14 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_15 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_16 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_22 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_23 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_24 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_25 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
g_atype565_1,
g_atype565_2,
g_atype565_3,
g_atype565_4,
g_atype565_5,
g_atype565_6,
g_atype565_7,
g_atype565_8,
g_atype565_9,
g_atype565_10,
g_atype565_11,
g_atype565_12,
g_atype565_13,
g_atype565_14,
g_atype565_15,
g_atype565_16,
g_atype565_17,
g_atype565_18,
g_atype565_19,
g_atype565_20,
g_atype565_21,
g_atype565_22,
g_atype565_23,
g_atype565_24,
g_atype565_25,
};

static const long offsets565 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @CHROFF(6,7),
+ @I16OFF(6,8,0),
+ @I16OFF(6,8,1),
+ @LNGOFF(6,8,2,0),
+ @LNGOFF(6,8,2,1),
+ @LNGOFF(6,8,2,2),
+ @LNGOFF(6,8,2,3),
+ @LNGOFF(6,8,2,4),
+ @LNGOFF(6,8,2,5),
+ @R32OFF(6,8,2,6,0),
+ @I64OFF(6,8,2,6,1,0,0),
+ @I64OFF(6,8,2,6,1,0,1),
+ @R64OFF(6,8,2,6,1,0,2,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags566 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_1 [] = {109,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_2 [] = {109,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_6 [] = {565,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_13 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_14 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_15 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_16 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_17 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_23 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_24 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_25 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_26 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
g_atype566_1,
g_atype566_2,
g_atype566_3,
g_atype566_4,
g_atype566_5,
g_atype566_6,
g_atype566_7,
g_atype566_8,
g_atype566_9,
g_atype566_10,
g_atype566_11,
g_atype566_12,
g_atype566_13,
g_atype566_14,
g_atype566_15,
g_atype566_16,
g_atype566_17,
g_atype566_18,
g_atype566_19,
g_atype566_20,
g_atype566_21,
g_atype566_22,
g_atype566_23,
g_atype566_24,
g_atype566_25,
g_atype566_26,
};

static const long offsets566 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @LNGOFF(7,8,2,4),
+ @LNGOFF(7,8,2,5),
+ @R32OFF(7,8,2,6,0),
+ @I64OFF(7,8,2,6,1,0,0),
+ @I64OFF(7,8,2,6,1,0,1),
+ @R64OFF(7,8,2,6,1,0,2,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags567 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_1 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_2 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_16 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_17 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_18 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_19 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_20 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_31 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_32 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_33 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_34 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_35 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
g_atype567_1,
g_atype567_2,
g_atype567_3,
g_atype567_4,
g_atype567_5,
g_atype567_6,
g_atype567_7,
g_atype567_8,
g_atype567_9,
g_atype567_10,
g_atype567_11,
g_atype567_12,
g_atype567_13,
g_atype567_14,
g_atype567_15,
g_atype567_16,
g_atype567_17,
g_atype567_18,
g_atype567_19,
g_atype567_20,
g_atype567_21,
g_atype567_22,
g_atype567_23,
g_atype567_24,
g_atype567_25,
g_atype567_26,
g_atype567_27,
g_atype567_28,
g_atype567_29,
g_atype567_30,
g_atype567_31,
g_atype567_32,
g_atype567_33,
g_atype567_34,
g_atype567_35,
};

static const long offsets567 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @CHROFF(6,7),
+ @CHROFF(6,8),
+ @CHROFF(6,9),
+ @CHROFF(6,10),
+ @CHROFF(6,11),
+ @I16OFF(6,12,0),
+ @I16OFF(6,12,1),
+ @LNGOFF(6,12,2,0),
+ @LNGOFF(6,12,2,1),
+ @LNGOFF(6,12,2,2),
+ @LNGOFF(6,12,2,3),
+ @LNGOFF(6,12,2,4),
+ @LNGOFF(6,12,2,5),
+ @LNGOFF(6,12,2,6),
+ @LNGOFF(6,12,2,7),
+ @LNGOFF(6,12,2,8),
+ @LNGOFF(6,12,2,9),
+ @LNGOFF(6,12,2,10),
+ @R32OFF(6,12,2,11,0),
+ @I64OFF(6,12,2,11,1,0,0),
+ @I64OFF(6,12,2,11,1,0,1),
+ @I64OFF(6,12,2,11,1,0,2),
+ @R64OFF(6,12,2,11,1,0,3,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags568 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_1 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_2 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_6 [] = {567,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_17 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_18 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_19 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_20 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_21 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_34 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_35 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_36 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_37 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_38 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
g_atype568_1,
g_atype568_2,
g_atype568_3,
g_atype568_4,
g_atype568_5,
g_atype568_6,
g_atype568_7,
g_atype568_8,
g_atype568_9,
g_atype568_10,
g_atype568_11,
g_atype568_12,
g_atype568_13,
g_atype568_14,
g_atype568_15,
g_atype568_16,
g_atype568_17,
g_atype568_18,
g_atype568_19,
g_atype568_20,
g_atype568_21,
g_atype568_22,
g_atype568_23,
g_atype568_24,
g_atype568_25,
g_atype568_26,
g_atype568_27,
g_atype568_28,
g_atype568_29,
g_atype568_30,
g_atype568_31,
g_atype568_32,
g_atype568_33,
g_atype568_34,
g_atype568_35,
g_atype568_36,
g_atype568_37,
g_atype568_38,
};

static const long offsets568 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @I16OFF(7,12,0),
+ @I16OFF(7,12,1),
+ @LNGOFF(7,12,2,0),
+ @LNGOFF(7,12,2,1),
+ @LNGOFF(7,12,2,2),
+ @LNGOFF(7,12,2,3),
+ @LNGOFF(7,12,2,4),
+ @LNGOFF(7,12,2,5),
+ @LNGOFF(7,12,2,6),
+ @LNGOFF(7,12,2,7),
+ @LNGOFF(7,12,2,8),
+ @LNGOFF(7,12,2,9),
+ @LNGOFF(7,12,2,10),
+ @LNGOFF(7,12,2,11),
+ @LNGOFF(7,12,2,12),
+ @R32OFF(7,12,2,13,0),
+ @I64OFF(7,12,2,13,1,0,0),
+ @I64OFF(7,12,2,13,1,0,1),
+ @I64OFF(7,12,2,13,1,0,2),
+ @R64OFF(7,12,2,13,1,0,3,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags569 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_1 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_2 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_6 [] = {568,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_17 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_18 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_19 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_20 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_21 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_35 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_36 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_37 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_38 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_39 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
g_atype569_1,
g_atype569_2,
g_atype569_3,
g_atype569_4,
g_atype569_5,
g_atype569_6,
g_atype569_7,
g_atype569_8,
g_atype569_9,
g_atype569_10,
g_atype569_11,
g_atype569_12,
g_atype569_13,
g_atype569_14,
g_atype569_15,
g_atype569_16,
g_atype569_17,
g_atype569_18,
g_atype569_19,
g_atype569_20,
g_atype569_21,
g_atype569_22,
g_atype569_23,
g_atype569_24,
g_atype569_25,
g_atype569_26,
g_atype569_27,
g_atype569_28,
g_atype569_29,
g_atype569_30,
g_atype569_31,
g_atype569_32,
g_atype569_33,
g_atype569_34,
g_atype569_35,
g_atype569_36,
g_atype569_37,
g_atype569_38,
g_atype569_39,
};

static const long offsets569 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @I16OFF(7,12,0),
+ @I16OFF(7,12,1),
+ @LNGOFF(7,12,2,0),
+ @LNGOFF(7,12,2,1),
+ @LNGOFF(7,12,2,2),
+ @LNGOFF(7,12,2,3),
+ @LNGOFF(7,12,2,4),
+ @LNGOFF(7,12,2,5),
+ @LNGOFF(7,12,2,6),
+ @LNGOFF(7,12,2,7),
+ @LNGOFF(7,12,2,8),
+ @LNGOFF(7,12,2,9),
+ @LNGOFF(7,12,2,10),
+ @LNGOFF(7,12,2,11),
+ @LNGOFF(7,12,2,12),
+ @LNGOFF(7,12,2,13),
+ @R32OFF(7,12,2,14,0),
+ @I64OFF(7,12,2,14,1,0,0),
+ @I64OFF(7,12,2,14,1,0,1),
+ @I64OFF(7,12,2,14,1,0,2),
+ @R64OFF(7,12,2,14,1,0,3,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags570 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_1 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_2 [] = {318,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_4 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_5 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_6 [] = {569,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_17 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_18 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_19 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_20 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_21 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_35 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_36 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_37 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_38 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_39 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
g_atype570_1,
g_atype570_2,
g_atype570_3,
g_atype570_4,
g_atype570_5,
g_atype570_6,
g_atype570_7,
g_atype570_8,
g_atype570_9,
g_atype570_10,
g_atype570_11,
g_atype570_12,
g_atype570_13,
g_atype570_14,
g_atype570_15,
g_atype570_16,
g_atype570_17,
g_atype570_18,
g_atype570_19,
g_atype570_20,
g_atype570_21,
g_atype570_22,
g_atype570_23,
g_atype570_24,
g_atype570_25,
g_atype570_26,
g_atype570_27,
g_atype570_28,
g_atype570_29,
g_atype570_30,
g_atype570_31,
g_atype570_32,
g_atype570_33,
g_atype570_34,
g_atype570_35,
g_atype570_36,
g_atype570_37,
g_atype570_38,
g_atype570_39,
};

static const long offsets570 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @I16OFF(7,12,0),
+ @I16OFF(7,12,1),
+ @LNGOFF(7,12,2,0),
+ @LNGOFF(7,12,2,1),
+ @LNGOFF(7,12,2,2),
+ @LNGOFF(7,12,2,3),
+ @LNGOFF(7,12,2,4),
+ @LNGOFF(7,12,2,5),
+ @LNGOFF(7,12,2,6),
+ @LNGOFF(7,12,2,7),
+ @LNGOFF(7,12,2,8),
+ @LNGOFF(7,12,2,9),
+ @LNGOFF(7,12,2,10),
+ @LNGOFF(7,12,2,11),
+ @LNGOFF(7,12,2,12),
+ @LNGOFF(7,12,2,13),
+ @R32OFF(7,12,2,14,0),
+ @I64OFF(7,12,2,14,1,0,0),
+ @I64OFF(7,12,2,14,1,0,1),
+ @I64OFF(7,12,2,14,1,0,2),
+ @R64OFF(7,12,2,14,1,0,3,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags572 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_1 [] = {0xFF01,1029,0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
g_atype572_1,
};

static const long offsets572 [] =
{
0,
 + @REFACS(1),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_REF,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
0,
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_REF,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
0,
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_REF,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
0,
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_REF,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
0,
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_REF,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
0,
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags578 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_1 [] = {0xFF01,1058,0xFF01,1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
g_atype578_1,
};

static const long offsets578 [] =
{
0,
 + @REFACS(1),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags579 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_2 [] = {0xFF01,1167,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
g_atype579_1,
g_atype579_2,
};

static const long offsets579 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags580 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_2 [] = {1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_3 [] = {1186,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
g_atype580_1,
g_atype580_2,
g_atype580_3,
};

static const long offsets580 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags581 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_2 [] = {1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
g_atype581_1,
g_atype581_2,
};

static const long offsets581 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags582 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
g_atype582_1,
g_atype582_2,
g_atype582_3,
g_atype582_4,
};

static const long offsets582 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags583 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_2 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
g_atype583_1,
g_atype583_2,
g_atype583_3,
g_atype583_4,
g_atype583_5,
};

static const long offsets583 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags584 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
g_atype584_1,
g_atype584_2,
g_atype584_3,
g_atype584_4,
};

static const long offsets584 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags585 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
g_atype585_1,
g_atype585_2,
g_atype585_3,
g_atype585_4,
};

static const long offsets585 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags586 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
g_atype586_1,
g_atype586_2,
g_atype586_3,
g_atype586_4,
};

static const long offsets586 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags587 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_2 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
g_atype587_1,
g_atype587_2,
g_atype587_3,
g_atype587_4,
g_atype587_5,
};

static const long offsets587 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags588 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_2 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
g_atype588_1,
g_atype588_2,
g_atype588_3,
g_atype588_4,
g_atype588_5,
g_atype588_6,
};

static const long offsets588 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags589 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
g_atype589_1,
g_atype589_2,
g_atype589_3,
g_atype589_4,
};

static const long offsets589 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {0xFF01,421,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_1 [] = {49,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_3 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_4 [] = {0xFF01,1058,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_5 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
g_atype591_1,
g_atype591_2,
g_atype591_3,
g_atype591_4,
g_atype591_5,
};

static const long offsets591 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags592 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {330,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_2 [] = {581,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_3 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_5 [] = {1381,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_6 [] = {1380,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_7 [] = {0xFF01,421,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_8 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_9 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_10 [] = {1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_11 [] = {1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_12 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_13 [] = {1252,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_14 [] = {1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_15 [] = {430,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_16 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_17 [] = {431,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_18 [] = {429,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_19 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_20 [] = {1406,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_21 [] = {0xFF01,1056,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_22 [] = {0xFF01,962,0xFF01,1172,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_23 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_24 [] = {0xFF01,1055,0xFF01,1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_25 [] = {965,1312,0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_29 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
g_atype592_1,
g_atype592_2,
g_atype592_3,
g_atype592_4,
g_atype592_5,
g_atype592_6,
g_atype592_7,
g_atype592_8,
g_atype592_9,
g_atype592_10,
g_atype592_11,
g_atype592_12,
g_atype592_13,
g_atype592_14,
g_atype592_15,
g_atype592_16,
g_atype592_17,
g_atype592_18,
g_atype592_19,
g_atype592_20,
g_atype592_21,
g_atype592_22,
g_atype592_23,
g_atype592_24,
g_atype592_25,
g_atype592_26,
g_atype592_27,
g_atype592_28,
g_atype592_29,
};

static const long offsets592 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
+ @CHROFF(26,0),
+ @CHROFF(26,1),
+ @CHROFF(26,2),
+ @LNGOFF(26,3,0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_1 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_2 [] = {1381,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_3 [] = {1380,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_4 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_5 [] = {1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_6 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_7 [] = {0xFF01,421,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_11 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
g_atype593_1,
g_atype593_2,
g_atype593_3,
g_atype593_4,
g_atype593_5,
g_atype593_6,
g_atype593_7,
g_atype593_8,
g_atype593_9,
g_atype593_10,
g_atype593_11,
};

static const long offsets593 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {60,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_2 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_4 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_5 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_6 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_7 [] = {972,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_8 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_9 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_10 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_11 [] = {972,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_29 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
g_atype594_1,
g_atype594_2,
g_atype594_3,
g_atype594_4,
g_atype594_5,
g_atype594_6,
g_atype594_7,
g_atype594_8,
g_atype594_9,
g_atype594_10,
g_atype594_11,
g_atype594_12,
g_atype594_13,
g_atype594_14,
g_atype594_15,
g_atype594_16,
g_atype594_17,
g_atype594_18,
g_atype594_19,
g_atype594_20,
g_atype594_21,
g_atype594_22,
g_atype594_23,
g_atype594_24,
g_atype594_25,
g_atype594_26,
g_atype594_27,
g_atype594_28,
g_atype594_29,
};

static const long offsets594 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @CHROFF(12,16),
+ @CHROFF(12,17),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {60,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_1 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_2 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_4 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_5 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_6 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_7 [] = {972,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_8 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_9 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_10 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_11 [] = {972,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_12 [] = {0xFF01,1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_13 [] = {0xFF01,1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_14 [] = {0xFF01,1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_15 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_16 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_17 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_31 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_32 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_33 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_34 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_35 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
g_atype595_1,
g_atype595_2,
g_atype595_3,
g_atype595_4,
g_atype595_5,
g_atype595_6,
g_atype595_7,
g_atype595_8,
g_atype595_9,
g_atype595_10,
g_atype595_11,
g_atype595_12,
g_atype595_13,
g_atype595_14,
g_atype595_15,
g_atype595_16,
g_atype595_17,
g_atype595_18,
g_atype595_19,
g_atype595_20,
g_atype595_21,
g_atype595_22,
g_atype595_23,
g_atype595_24,
g_atype595_25,
g_atype595_26,
g_atype595_27,
g_atype595_28,
g_atype595_29,
g_atype595_30,
g_atype595_31,
g_atype595_32,
g_atype595_33,
g_atype595_34,
g_atype595_35,
};

static const long offsets595 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @CHROFF(18,4),
+ @CHROFF(18,5),
+ @CHROFF(18,6),
+ @CHROFF(18,7),
+ @CHROFF(18,8),
+ @CHROFF(18,9),
+ @CHROFF(18,10),
+ @CHROFF(18,11),
+ @CHROFF(18,12),
+ @CHROFF(18,13),
+ @CHROFF(18,14),
+ @CHROFF(18,15),
+ @CHROFF(18,16),
+ @CHROFF(18,17),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags596 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_1 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
g_atype596_1,
};

static const long offsets596 [] =
{
0,
 + @REFACS(1),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags610 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype610_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype610_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype610_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
g_atype610_1,
g_atype610_2,
g_atype610_3,
};

static const long offsets610 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags636 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {0xFF01,948,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
g_atype636_1,
g_atype636_2,
g_atype636_3,
g_atype636_4,
g_atype636_5,
g_atype636_6,
};

static const long offsets636 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags637 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {0xFF01,949,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
g_atype637_1,
g_atype637_2,
g_atype637_3,
g_atype637_4,
g_atype637_5,
g_atype637_6,
};

static const long offsets637 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags638 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {0xFF01,950,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
g_atype638_1,
g_atype638_2,
g_atype638_3,
g_atype638_4,
g_atype638_5,
g_atype638_6,
};

static const long offsets638 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags639 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {0xFF01,951,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
g_atype639_1,
g_atype639_2,
g_atype639_3,
g_atype639_4,
g_atype639_5,
g_atype639_6,
};

static const long offsets639 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags640 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {0xFF01,952,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
g_atype640_1,
g_atype640_2,
g_atype640_3,
g_atype640_4,
g_atype640_5,
g_atype640_6,
};

static const long offsets640 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags641 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {0xFF01,953,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
g_atype641_1,
g_atype641_2,
g_atype641_3,
g_atype641_4,
g_atype641_5,
g_atype641_6,
};

static const long offsets641 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags642 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {0xFF01,954,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
g_atype642_1,
g_atype642_2,
g_atype642_3,
g_atype642_4,
g_atype642_5,
g_atype642_6,
};

static const long offsets642 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags643 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {0xFF01,955,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
g_atype643_1,
g_atype643_2,
g_atype643_3,
g_atype643_4,
g_atype643_5,
g_atype643_6,
};

static const long offsets643 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags644 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {0xFF01,956,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
g_atype644_1,
g_atype644_2,
g_atype644_3,
g_atype644_4,
g_atype644_5,
g_atype644_6,
};

static const long offsets644 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags645 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {0xFF01,957,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
g_atype645_1,
g_atype645_2,
g_atype645_3,
g_atype645_4,
g_atype645_5,
g_atype645_6,
};

static const long offsets645 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags646 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {0xFF01,958,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
g_atype646_1,
g_atype646_2,
g_atype646_3,
g_atype646_4,
g_atype646_5,
g_atype646_6,
};

static const long offsets646 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags647 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {0xFF01,959,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
g_atype647_1,
g_atype647_2,
g_atype647_3,
g_atype647_4,
g_atype647_5,
g_atype647_6,
};

static const long offsets647 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags648 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {0xFF01,1053,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_1 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
g_atype648_1,
g_atype648_2,
g_atype648_3,
g_atype648_4,
g_atype648_5,
g_atype648_6,
g_atype648_7,
};

static const long offsets648 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags649 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {0xFF01,1054,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_1 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
g_atype649_1,
g_atype649_2,
g_atype649_3,
g_atype649_4,
g_atype649_5,
g_atype649_6,
g_atype649_7,
};

static const long offsets649 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags650 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {0xFF01,960,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
g_atype650_1,
g_atype650_2,
g_atype650_3,
g_atype650_4,
g_atype650_5,
g_atype650_6,
};

static const long offsets650 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags651 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {0xFF01,961,1160,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
g_atype651_1,
g_atype651_2,
g_atype651_3,
g_atype651_4,
g_atype651_5,
g_atype651_6,
};

static const long offsets651 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags652 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {0xFF01,962,0xFFF8,1,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
g_atype652_1,
g_atype652_2,
g_atype652_3,
g_atype652_4,
g_atype652_5,
g_atype652_6,
};

static const long offsets652 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags653 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {0xFF01,963,1330,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
g_atype653_1,
g_atype653_2,
g_atype653_3,
g_atype653_4,
g_atype653_5,
g_atype653_6,
};

static const long offsets653 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags654 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {0xFF01,964,0xFFF8,1,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
g_atype654_1,
g_atype654_2,
g_atype654_3,
g_atype654_4,
g_atype654_5,
g_atype654_6,
};

static const long offsets654 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags655 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {0xFF01,965,1312,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
g_atype655_1,
g_atype655_2,
g_atype655_3,
g_atype655_4,
g_atype655_5,
g_atype655_6,
};

static const long offsets655 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags656 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {0xFF01,966,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
g_atype656_1,
g_atype656_2,
g_atype656_3,
g_atype656_4,
g_atype656_5,
g_atype656_6,
};

static const long offsets656 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags657 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {0xFF01,967,1127,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
g_atype657_1,
g_atype657_2,
g_atype657_3,
g_atype657_4,
g_atype657_5,
g_atype657_6,
};

static const long offsets657 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags658 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {0xFF01,968,1324,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
g_atype658_1,
g_atype658_2,
g_atype658_3,
g_atype658_4,
g_atype658_5,
g_atype658_6,
};

static const long offsets658 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags659 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
g_atype659_1,
g_atype659_2,
};

static const long offsets659 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags660 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
g_atype660_1,
g_atype660_2,
};

static const long offsets660 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags661 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
g_atype661_1,
g_atype661_2,
};

static const long offsets661 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags662 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
g_atype662_1,
g_atype662_2,
};

static const long offsets662 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags663 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
g_atype663_1,
g_atype663_2,
};

static const long offsets663 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags664 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
g_atype664_1,
g_atype664_2,
};

static const long offsets664 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags665 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
g_atype665_1,
g_atype665_2,
};

static const long offsets665 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags666 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
g_atype666_1,
g_atype666_2,
};

static const long offsets666 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags667 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
g_atype667_1,
g_atype667_2,
};

static const long offsets667 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags668 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
g_atype668_1,
g_atype668_2,
};

static const long offsets668 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags669 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
g_atype669_1,
g_atype669_2,
};

static const long offsets669 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags670 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
g_atype670_1,
g_atype670_2,
};

static const long offsets670 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags671 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_1 [] = {0xFF01,1058,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
g_atype671_1,
g_atype671_2,
g_atype671_3,
};

static const long offsets671 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags672 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_1 [] = {0xFF01,1059,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
g_atype672_1,
g_atype672_2,
g_atype672_3,
};

static const long offsets672 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags673 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_1 [] = {0xFF01,1060,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
g_atype673_1,
g_atype673_2,
g_atype673_3,
};

static const long offsets673 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags674 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_1 [] = {0xFF01,1061,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
g_atype674_1,
g_atype674_2,
g_atype674_3,
};

static const long offsets674 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags675 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_1 [] = {0xFF01,1062,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
g_atype675_1,
g_atype675_2,
g_atype675_3,
};

static const long offsets675 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags676 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_1 [] = {0xFF01,1063,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
g_atype676_1,
g_atype676_2,
g_atype676_3,
};

static const long offsets676 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags677 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_1 [] = {0xFF01,1064,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
g_atype677_1,
g_atype677_2,
g_atype677_3,
};

static const long offsets677 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags678 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_1 [] = {0xFF01,1065,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
g_atype678_1,
g_atype678_2,
g_atype678_3,
};

static const long offsets678 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags679 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_1 [] = {0xFF01,1066,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
g_atype679_1,
g_atype679_2,
g_atype679_3,
};

static const long offsets679 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags680 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_1 [] = {0xFF01,1067,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
g_atype680_1,
g_atype680_2,
g_atype680_3,
};

static const long offsets680 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags681 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_1 [] = {0xFF01,1068,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
g_atype681_1,
g_atype681_2,
g_atype681_3,
};

static const long offsets681 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags682 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_1 [] = {0xFF01,1069,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
g_atype682_1,
g_atype682_2,
g_atype682_3,
};

static const long offsets682 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags683 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_1 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
g_atype683_1,
g_atype683_2,
g_atype683_3,
g_atype683_4,
};

static const long offsets683 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags684 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_1 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
g_atype684_1,
g_atype684_2,
g_atype684_3,
g_atype684_4,
};

static const long offsets684 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags685 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_1 [] = {0xFF01,988,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
g_atype685_1,
g_atype685_2,
g_atype685_3,
g_atype685_4,
};

static const long offsets685 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags686 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_1 [] = {0xFF01,989,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
g_atype686_1,
g_atype686_2,
g_atype686_3,
g_atype686_4,
};

static const long offsets686 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags687 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_1 [] = {0xFF01,990,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
g_atype687_1,
g_atype687_2,
g_atype687_3,
g_atype687_4,
};

static const long offsets687 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags688 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_1 [] = {0xFF01,991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
g_atype688_1,
g_atype688_2,
g_atype688_3,
g_atype688_4,
};

static const long offsets688 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags689 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_1 [] = {0xFF01,992,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
g_atype689_1,
g_atype689_2,
g_atype689_3,
g_atype689_4,
};

static const long offsets689 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags690 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_1 [] = {0xFF01,993,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
g_atype690_1,
g_atype690_2,
g_atype690_3,
g_atype690_4,
};

static const long offsets690 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags691 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_1 [] = {0xFF01,994,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
g_atype691_1,
g_atype691_2,
g_atype691_3,
g_atype691_4,
};

static const long offsets691 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags692 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_1 [] = {0xFF01,995,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
g_atype692_1,
g_atype692_2,
g_atype692_3,
g_atype692_4,
};

static const long offsets692 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags693 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_1 [] = {0xFF01,996,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
g_atype693_1,
g_atype693_2,
g_atype693_3,
g_atype693_4,
};

static const long offsets693 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags694 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_1 [] = {0xFF01,997,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
g_atype694_1,
g_atype694_2,
g_atype694_3,
g_atype694_4,
};

static const long offsets694 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags695 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_1 [] = {0xFF01,998,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
g_atype695_1,
g_atype695_2,
g_atype695_3,
g_atype695_4,
};

static const long offsets695 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags696 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_1 [] = {0xFF01,999,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
g_atype696_1,
g_atype696_2,
g_atype696_3,
g_atype696_4,
};

static const long offsets696 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags697 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
g_atype697_1,
g_atype697_2,
};

static const long offsets697 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags698 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
g_atype698_2,
};

static const long offsets698 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags699 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
g_atype699_1,
g_atype699_2,
};

static const long offsets699 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags700 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
g_atype700_1,
g_atype700_2,
};

static const long offsets700 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags701 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
g_atype701_1,
g_atype701_2,
};

static const long offsets701 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags702 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
g_atype702_1,
g_atype702_2,
};

static const long offsets702 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags703 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
g_atype703_2,
};

static const long offsets703 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags704 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
g_atype704_2,
};

static const long offsets704 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags705 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
g_atype705_2,
};

static const long offsets705 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags706 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
g_atype706_2,
};

static const long offsets706 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags707 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
g_atype707_2,
};

static const long offsets707 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags708 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
g_atype708_2,
};

static const long offsets708 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {0xFF01,1058,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
0,
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {0xFF01,1058,0xFF01,1242,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
0,
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {0xFF01,1058,0xFF01,1244,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
0,
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {0xFF01,596,0xFF01,1192,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
0,
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_BOOL,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @CHROFF(0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_BOOL,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @CHROFF(0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_BOOL,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @CHROFF(0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_BOOL,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @CHROFF(0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_BOOL,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @CHROFF(0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_BOOL,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @CHROFF(0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_BOOL,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @CHROFF(0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_BOOL,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @CHROFF(0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_BOOL,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @CHROFF(0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_BOOL,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @CHROFF(0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @CHROFF(0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_BOOL,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @CHROFF(0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_BOOL,
};

static const uint16 attr_flags772 [] =
{0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
};

static const long offsets772 [] =
{
+ @CHROFF(0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_BOOL,
};

static const uint16 attr_flags773 [] =
{0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
};

static const long offsets773 [] =
{
+ @CHROFF(0,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_BOOL,
};

static const uint16 attr_flags774 [] =
{0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
};

static const long offsets774 [] =
{
+ @CHROFF(0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_BOOL,
};

static const uint16 attr_flags775 [] =
{0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
};

static const long offsets775 [] =
{
+ @CHROFF(0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_BOOL,
};

static const uint16 attr_flags776 [] =
{0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
};

static const long offsets776 [] =
{
+ @CHROFF(0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_BOOL,
};

static const uint16 attr_flags777 [] =
{0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
};

static const long offsets777 [] =
{
+ @CHROFF(0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_BOOL,
};

static const uint16 attr_flags778 [] =
{0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
};

static const long offsets778 [] =
{
+ @CHROFF(0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_BOOL,
};

static const uint16 attr_flags779 [] =
{0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
};

static const long offsets779 [] =
{
+ @CHROFF(0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_BOOL,
};

static const uint16 attr_flags780 [] =
{0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
};

static const long offsets780 [] =
{
+ @CHROFF(0,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_BOOL,
};

static const uint16 attr_flags781 [] =
{0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
};

static const long offsets781 [] =
{
+ @CHROFF(0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_BOOL,
};

static const uint16 attr_flags782 [] =
{0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
};

static const long offsets782 [] =
{
+ @CHROFF(0,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_BOOL,
};

static const uint16 attr_flags783 [] =
{0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
};

static const long offsets783 [] =
{
+ @CHROFF(0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_BOOL,
};

static const uint16 attr_flags784 [] =
{0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
};

static const long offsets784 [] =
{
+ @CHROFF(0,0),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_BOOL,
};

static const uint16 attr_flags785 [] =
{0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
};

static const long offsets785 [] =
{
+ @CHROFF(0,0),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_BOOL,
};

static const uint16 attr_flags786 [] =
{0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
};

static const long offsets786 [] =
{
+ @CHROFF(0,0),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_BOOL,
};

static const uint16 attr_flags787 [] =
{0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
};

static const long offsets787 [] =
{
+ @CHROFF(0,0),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_BOOL,
};

static const uint16 attr_flags788 [] =
{0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
};

static const long offsets788 [] =
{
+ @CHROFF(0,0),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_BOOL,
};

static const uint16 attr_flags789 [] =
{0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
};

static const long offsets789 [] =
{
+ @CHROFF(0,0),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_BOOL,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @CHROFF(0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_BOOL,
};

static const uint16 attr_flags791 [] =
{0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
};

static const long offsets791 [] =
{
+ @CHROFF(0,0),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_BOOL,
};

static const uint16 attr_flags792 [] =
{0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
};

static const long offsets792 [] =
{
+ @CHROFF(0,0),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_BOOL,
};

static const uint16 attr_flags793 [] =
{0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
};

static const long offsets793 [] =
{
+ @CHROFF(0,0),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_BOOL,
};

static const uint16 attr_flags794 [] =
{0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
};

static const long offsets794 [] =
{
+ @CHROFF(0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_BOOL,
};

static const uint16 attr_flags795 [] =
{0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
};

static const long offsets795 [] =
{
+ @CHROFF(0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_BOOL,
};

static const uint16 attr_flags796 [] =
{0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
};

static const long offsets796 [] =
{
+ @CHROFF(0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_BOOL,
};

static const uint16 attr_flags797 [] =
{0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
};

static const long offsets797 [] =
{
+ @CHROFF(0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_BOOL,
};

static const uint16 attr_flags798 [] =
{0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
};

static const long offsets798 [] =
{
+ @CHROFF(0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_BOOL,
};

static const uint16 attr_flags799 [] =
{0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
};

static const long offsets799 [] =
{
+ @CHROFF(0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_BOOL,
};

static const uint16 attr_flags800 [] =
{0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
};

static const long offsets800 [] =
{
+ @CHROFF(0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_BOOL,
};

static const uint16 attr_flags801 [] =
{0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
};

static const long offsets801 [] =
{
+ @CHROFF(0,0),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_BOOL,
};

static const uint16 attr_flags802 [] =
{0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
};

static const long offsets802 [] =
{
+ @CHROFF(0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_BOOL,
};

static const uint16 attr_flags803 [] =
{0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
};

static const long offsets803 [] =
{
+ @CHROFF(0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_BOOL,
};

static const uint16 attr_flags804 [] =
{0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
};

static const long offsets804 [] =
{
+ @CHROFF(0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_BOOL,
};

static const uint16 attr_flags805 [] =
{0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
};

static const long offsets805 [] =
{
+ @CHROFF(0,0),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_BOOL,
};

static const uint16 attr_flags806 [] =
{0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
};

static const long offsets806 [] =
{
+ @CHROFF(0,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_BOOL,
};

static const uint16 attr_flags807 [] =
{0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
};

static const long offsets807 [] =
{
+ @CHROFF(0,0),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_BOOL,
};

static const uint16 attr_flags808 [] =
{0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
};

static const long offsets808 [] =
{
+ @CHROFF(0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_BOOL,
};

static const uint16 attr_flags809 [] =
{0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
};

static const long offsets809 [] =
{
+ @CHROFF(0,0),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_BOOL,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @CHROFF(0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_BOOL,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @CHROFF(0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_BOOL,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @CHROFF(0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_BOOL,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @CHROFF(0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_BOOL,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @CHROFF(0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_BOOL,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @CHROFF(0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_BOOL,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @CHROFF(0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_BOOL,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @CHROFF(0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_BOOL,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @CHROFF(0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_BOOL,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_BOOL,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_BOOL,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_BOOL,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @CHROFF(0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_BOOL,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @CHROFF(0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_BOOL,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @CHROFF(0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_BOOL,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @CHROFF(0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_BOOL,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @CHROFF(0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_BOOL,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @CHROFF(0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_BOOL,
};

static const uint16 attr_flags828 [] =
{0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
};

static const long offsets828 [] =
{
+ @CHROFF(0,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_BOOL,
};

static const uint16 attr_flags829 [] =
{0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
};

static const long offsets829 [] =
{
+ @CHROFF(0,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_BOOL,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @CHROFF(0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_BOOL,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @CHROFF(0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_BOOL,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @CHROFF(0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_BOOL,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @CHROFF(0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_BOOL,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @CHROFF(0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_BOOL,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @CHROFF(0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_BOOL,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @CHROFF(0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_BOOL,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @CHROFF(0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_BOOL,
};

static const uint16 attr_flags838 [] =
{0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
};

static const long offsets838 [] =
{
+ @CHROFF(0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_BOOL,
};

static const uint16 attr_flags839 [] =
{0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
};

static const long offsets839 [] =
{
+ @CHROFF(0,0),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_BOOL,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @CHROFF(0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_BOOL,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @CHROFF(0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_BOOL,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @CHROFF(0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_BOOL,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @CHROFF(0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_BOOL,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @CHROFF(0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_BOOL,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @CHROFF(0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_BOOL,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @CHROFF(0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_BOOL,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @CHROFF(0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_BOOL,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @CHROFF(0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_BOOL,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @CHROFF(0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_BOOL,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @CHROFF(0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_BOOL,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @CHROFF(0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_BOOL,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @CHROFF(0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_BOOL,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @CHROFF(0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_BOOL,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @CHROFF(0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_BOOL,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @CHROFF(0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_BOOL,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @CHROFF(0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_BOOL,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @CHROFF(0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_BOOL,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @CHROFF(0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_BOOL,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @CHROFF(0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_BOOL,
};

static const uint16 attr_flags860 [] =
{0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
};

static const long offsets860 [] =
{
+ @CHROFF(0,0),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_BOOL,
};

static const uint16 attr_flags861 [] =
{0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
};

static const long offsets861 [] =
{
+ @CHROFF(0,0),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_BOOL,
};

static const uint16 attr_flags862 [] =
{0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
};

static const long offsets862 [] =
{
+ @CHROFF(0,0),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_BOOL,
};

static const uint16 attr_flags863 [] =
{0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
};

static const long offsets863 [] =
{
+ @CHROFF(0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_BOOL,
};

static const uint16 attr_flags864 [] =
{0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
};

static const long offsets864 [] =
{
+ @CHROFF(0,0),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_BOOL,
};

static const uint16 attr_flags865 [] =
{0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
};

static const long offsets865 [] =
{
+ @CHROFF(0,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_BOOL,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @CHROFF(0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags867 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
g_atype867_1,
};

static const long offsets867 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags868 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
g_atype868_1,
g_atype868_2,
g_atype868_3,
g_atype868_4,
};

static const long offsets868 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
+ @LNGOFF(0,1,0,2),
+ @LNGOFF(0,1,0,3),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags869 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
g_atype869_1,
};

static const long offsets869 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_BOOL,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @CHROFF(0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_BOOL,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @CHROFF(0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_BOOL,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @CHROFF(0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_BOOL,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @CHROFF(0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_BOOL,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @CHROFF(0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_BOOL,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @CHROFF(0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_BOOL,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @CHROFF(0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_BOOL,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @CHROFF(0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_BOOL,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @CHROFF(0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_BOOL,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @CHROFF(0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_BOOL,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @CHROFF(0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_BOOL,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @CHROFF(0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_BOOL,
};

static const uint16 attr_flags882 [] =
{0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
};

static const long offsets882 [] =
{
+ @CHROFF(0,0),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_BOOL,
};

static const uint16 attr_flags883 [] =
{0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
};

static const long offsets883 [] =
{
+ @CHROFF(0,0),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_BOOL,
};

static const uint16 attr_flags884 [] =
{0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
};

static const long offsets884 [] =
{
+ @CHROFF(0,0),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_BOOL,
};

static const uint16 attr_flags885 [] =
{0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
};

static const long offsets885 [] =
{
+ @CHROFF(0,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_BOOL,
};

static const uint16 attr_flags886 [] =
{0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
};

static const long offsets886 [] =
{
+ @CHROFF(0,0),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_BOOL,
};

static const uint16 attr_flags887 [] =
{0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
};

static const long offsets887 [] =
{
+ @CHROFF(0,0),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_BOOL,
};

static const uint16 attr_flags888 [] =
{0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
};

static const long offsets888 [] =
{
+ @CHROFF(0,0),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_BOOL,
};

static const uint16 attr_flags889 [] =
{0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
};

static const long offsets889 [] =
{
+ @CHROFF(0,0),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_BOOL,
};

static const uint16 attr_flags890 [] =
{0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
};

static const long offsets890 [] =
{
+ @CHROFF(0,0),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_BOOL,
};

static const uint16 attr_flags891 [] =
{0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
};

static const long offsets891 [] =
{
+ @CHROFF(0,0),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_BOOL,
};

static const uint16 attr_flags892 [] =
{0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
};

static const long offsets892 [] =
{
+ @CHROFF(0,0),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_BOOL,
};

static const uint16 attr_flags893 [] =
{0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
};

static const long offsets893 [] =
{
+ @CHROFF(0,0),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_BOOL,
};

static const uint16 attr_flags894 [] =
{0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
};

static const long offsets894 [] =
{
+ @CHROFF(0,0),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_BOOL,
};

static const uint16 attr_flags895 [] =
{0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
};

static const long offsets895 [] =
{
+ @CHROFF(0,0),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_BOOL,
};

static const uint16 attr_flags896 [] =
{0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
};

static const long offsets896 [] =
{
+ @CHROFF(0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_BOOL,
};

static const uint16 attr_flags897 [] =
{0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
};

static const long offsets897 [] =
{
+ @CHROFF(0,0),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_BOOL,
};

static const uint16 attr_flags898 [] =
{0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
};

static const long offsets898 [] =
{
+ @CHROFF(0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_BOOL,
};

static const uint16 attr_flags899 [] =
{0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
};

static const long offsets899 [] =
{
+ @CHROFF(0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_BOOL,
};

static const uint16 attr_flags900 [] =
{0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
};

static const long offsets900 [] =
{
+ @CHROFF(0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_BOOL,
};

static const uint16 attr_flags901 [] =
{0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
};

static const long offsets901 [] =
{
+ @CHROFF(0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_BOOL,
};

static const uint16 attr_flags902 [] =
{0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
};

static const long offsets902 [] =
{
+ @CHROFF(0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_BOOL,
};

static const uint16 attr_flags903 [] =
{0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
};

static const long offsets903 [] =
{
+ @CHROFF(0,0),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_BOOL,
};

static const uint16 attr_flags904 [] =
{0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
};

static const long offsets904 [] =
{
+ @CHROFF(0,0),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_BOOL,
};

static const uint16 attr_flags905 [] =
{0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
};

static const long offsets905 [] =
{
+ @CHROFF(0,0),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_BOOL,
};

static const uint16 attr_flags906 [] =
{0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
};

static const long offsets906 [] =
{
+ @CHROFF(0,0),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_BOOL,
};

static const uint16 attr_flags907 [] =
{0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
};

static const long offsets907 [] =
{
+ @CHROFF(0,0),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_BOOL,
};

static const uint16 attr_flags908 [] =
{0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
};

static const long offsets908 [] =
{
+ @CHROFF(0,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags909 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
g_atype909_1,
g_atype909_2,
g_atype909_3,
};

static const long offsets909 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_BOOL,
};

static const uint16 attr_flags910 [] =
{0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
};

static const long offsets910 [] =
{
+ @CHROFF(0,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_BOOL,
};

static const uint16 attr_flags911 [] =
{0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
};

static const long offsets911 [] =
{
+ @CHROFF(0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_BOOL,
};

static const uint16 attr_flags912 [] =
{0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
};

static const long offsets912 [] =
{
+ @CHROFF(0,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_BOOL,
};

static const uint16 attr_flags913 [] =
{0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
};

static const long offsets913 [] =
{
+ @CHROFF(0,0),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_BOOL,
};

static const uint16 attr_flags914 [] =
{0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
};

static const long offsets914 [] =
{
+ @CHROFF(0,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_BOOL,
};

static const uint16 attr_flags915 [] =
{0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
};

static const long offsets915 [] =
{
+ @CHROFF(0,0),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_BOOL,
};

static const uint16 attr_flags916 [] =
{0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
};

static const long offsets916 [] =
{
+ @CHROFF(0,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_BOOL,
};

static const uint16 attr_flags917 [] =
{0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
};

static const long offsets917 [] =
{
+ @CHROFF(0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_BOOL,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @CHROFF(0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_BOOL,
};

static const uint16 attr_flags919 [] =
{0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
};

static const long offsets919 [] =
{
+ @CHROFF(0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_BOOL,
};

static const uint16 attr_flags920 [] =
{0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
};

static const long offsets920 [] =
{
+ @CHROFF(0,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_BOOL,
};

static const uint16 attr_flags921 [] =
{0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
};

static const long offsets921 [] =
{
+ @CHROFF(0,0),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_BOOL,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
+ @CHROFF(0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_BOOL,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
+ @CHROFF(0,0),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_BOOL,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
+ @CHROFF(0,0),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_BOOL,
};

static const uint16 attr_flags925 [] =
{0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
};

static const long offsets925 [] =
{
+ @CHROFF(0,0),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_BOOL,
};

static const uint16 attr_flags926 [] =
{0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
};

static const long offsets926 [] =
{
+ @CHROFF(0,0),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_BOOL,
};

static const uint16 attr_flags927 [] =
{0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
};

static const long offsets927 [] =
{
+ @CHROFF(0,0),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_BOOL,
};

static const uint16 attr_flags928 [] =
{0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
};

static const long offsets928 [] =
{
+ @CHROFF(0,0),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_BOOL,
};

static const uint16 attr_flags929 [] =
{0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
};

static const long offsets929 [] =
{
+ @CHROFF(0,0),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_BOOL,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
+ @CHROFF(0,0),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_BOOL,
};

static const uint16 attr_flags931 [] =
{0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
};

static const long offsets931 [] =
{
+ @CHROFF(0,0),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_BOOL,
};

static const uint16 attr_flags932 [] =
{0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
};

static const long offsets932 [] =
{
+ @CHROFF(0,0),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_BOOL,
};

static const uint16 attr_flags933 [] =
{0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
};

static const long offsets933 [] =
{
+ @CHROFF(0,0),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_BOOL,
};

static const uint16 attr_flags934 [] =
{0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
};

static const long offsets934 [] =
{
+ @CHROFF(0,0),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_BOOL,
};

static const uint16 attr_flags935 [] =
{0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
};

static const long offsets935 [] =
{
+ @CHROFF(0,0),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags936 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_3 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_4 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_7 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_8 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_9 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_10 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_11 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_15 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_16 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_17 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_18 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_19 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
g_atype936_1,
g_atype936_2,
g_atype936_3,
g_atype936_4,
g_atype936_5,
g_atype936_6,
g_atype936_7,
g_atype936_8,
g_atype936_9,
g_atype936_10,
g_atype936_11,
g_atype936_12,
g_atype936_13,
g_atype936_14,
g_atype936_15,
g_atype936_16,
g_atype936_17,
g_atype936_18,
g_atype936_19,
};

static const long offsets936 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names937[];
static const uint32 types937 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags937 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype937_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_4 [] = {68,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_10 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_11 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_12 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_13 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_14 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_18 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_19 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_20 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_21 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_22 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes937 [] = {
g_atype937_0,
g_atype937_1,
g_atype937_2,
g_atype937_3,
g_atype937_4,
g_atype937_5,
g_atype937_6,
g_atype937_7,
g_atype937_8,
g_atype937_9,
g_atype937_10,
g_atype937_11,
g_atype937_12,
g_atype937_13,
g_atype937_14,
g_atype937_15,
g_atype937_16,
g_atype937_17,
g_atype937_18,
g_atype937_19,
g_atype937_20,
g_atype937_21,
g_atype937_22,
};

static const long offsets937 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags938 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_3 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_4 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_8 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_9 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_10 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_11 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_12 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_16 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_17 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_18 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_19 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_20 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
g_atype938_1,
g_atype938_2,
g_atype938_3,
g_atype938_4,
g_atype938_5,
g_atype938_6,
g_atype938_7,
g_atype938_8,
g_atype938_9,
g_atype938_10,
g_atype938_11,
g_atype938_12,
g_atype938_13,
g_atype938_14,
g_atype938_15,
g_atype938_16,
g_atype938_17,
g_atype938_18,
g_atype938_19,
g_atype938_20,
};

static const long offsets938 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags948 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {0xFF01,970,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_1 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
g_atype948_1,
};

static const long offsets948 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags961 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_1 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_2 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_4 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
g_atype961_1,
g_atype961_2,
g_atype961_3,
g_atype961_4,
g_atype961_5,
g_atype961_6,
g_atype961_7,
g_atype961_8,
g_atype961_9,
g_atype961_10,
g_atype961_11,
g_atype961_12,
g_atype961_13,
g_atype961_14,
g_atype961_15,
g_atype961_16,
};

static const long offsets961 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags962 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_1 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_15 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_16 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
g_atype962_1,
g_atype962_2,
g_atype962_3,
g_atype962_4,
g_atype962_5,
g_atype962_6,
g_atype962_7,
g_atype962_8,
g_atype962_9,
g_atype962_10,
g_atype962_11,
g_atype962_12,
g_atype962_13,
g_atype962_14,
g_atype962_15,
g_atype962_16,
};

static const long offsets962 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags963 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_1 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_4 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
g_atype963_1,
g_atype963_2,
g_atype963_3,
g_atype963_4,
g_atype963_5,
g_atype963_6,
g_atype963_7,
g_atype963_8,
g_atype963_9,
g_atype963_10,
g_atype963_11,
g_atype963_12,
g_atype963_13,
g_atype963_14,
g_atype963_15,
g_atype963_16,
};

static const long offsets963 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags964 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_1 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_8 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_9 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
g_atype964_1,
g_atype964_2,
g_atype964_3,
g_atype964_4,
g_atype964_5,
g_atype964_6,
g_atype964_7,
g_atype964_8,
g_atype964_9,
g_atype964_10,
g_atype964_11,
g_atype964_12,
g_atype964_13,
g_atype964_14,
g_atype964_15,
g_atype964_16,
};

static const long offsets964 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags965 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_1 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_2 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_4 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_16 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
g_atype965_1,
g_atype965_2,
g_atype965_3,
g_atype965_4,
g_atype965_5,
g_atype965_6,
g_atype965_7,
g_atype965_8,
g_atype965_9,
g_atype965_10,
g_atype965_11,
g_atype965_12,
g_atype965_13,
g_atype965_14,
g_atype965_15,
g_atype965_16,
};

static const long offsets965 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @PTROFF(6,3,0,7,0,0),
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags966 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_1 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
g_atype966_1,
g_atype966_2,
g_atype966_3,
g_atype966_4,
g_atype966_5,
g_atype966_6,
g_atype966_7,
g_atype966_8,
g_atype966_9,
g_atype966_10,
g_atype966_11,
g_atype966_12,
g_atype966_13,
g_atype966_14,
g_atype966_15,
g_atype966_16,
};

static const long offsets966 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags967 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_1 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
g_atype967_1,
g_atype967_2,
g_atype967_3,
g_atype967_4,
g_atype967_5,
g_atype967_6,
g_atype967_7,
g_atype967_8,
g_atype967_9,
g_atype967_10,
g_atype967_11,
g_atype967_12,
g_atype967_13,
g_atype967_14,
g_atype967_15,
g_atype967_16,
};

static const long offsets967 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags968 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_1 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
g_atype968_1,
g_atype968_2,
g_atype968_3,
g_atype968_4,
g_atype968_5,
g_atype968_6,
g_atype968_7,
g_atype968_8,
g_atype968_9,
g_atype968_10,
g_atype968_11,
g_atype968_12,
g_atype968_13,
g_atype968_14,
g_atype968_15,
g_atype968_16,
};

static const long offsets968 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags969 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_1 [] = {0xFF01,1230,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_8 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_9 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_16 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
g_atype969_1,
g_atype969_2,
g_atype969_3,
g_atype969_4,
g_atype969_5,
g_atype969_6,
g_atype969_7,
g_atype969_8,
g_atype969_9,
g_atype969_10,
g_atype969_11,
g_atype969_12,
g_atype969_13,
g_atype969_14,
g_atype969_15,
g_atype969_16,
};

static const long offsets969 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags970 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_1 [] = {0xFF01,1230,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_2 [] = {0xFF01,1230,0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_4 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_6 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_7 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_8 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_18 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
g_atype970_1,
g_atype970_2,
g_atype970_3,
g_atype970_4,
g_atype970_5,
g_atype970_6,
g_atype970_7,
g_atype970_8,
g_atype970_9,
g_atype970_10,
g_atype970_11,
g_atype970_12,
g_atype970_13,
g_atype970_14,
g_atype970_15,
g_atype970_16,
g_atype970_17,
g_atype970_18,
};

static const long offsets970 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags971 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_1 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_2 [] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_3 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_4 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_6 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_17 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
g_atype971_1,
g_atype971_2,
g_atype971_3,
g_atype971_4,
g_atype971_5,
g_atype971_6,
g_atype971_7,
g_atype971_8,
g_atype971_9,
g_atype971_10,
g_atype971_11,
g_atype971_12,
g_atype971_13,
g_atype971_14,
g_atype971_15,
g_atype971_16,
g_atype971_17,
};

static const long offsets971 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags972 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_1 [] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_4 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_9 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_10 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_17 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
g_atype972_1,
g_atype972_2,
g_atype972_3,
g_atype972_4,
g_atype972_5,
g_atype972_6,
g_atype972_7,
g_atype972_8,
g_atype972_9,
g_atype972_10,
g_atype972_11,
g_atype972_12,
g_atype972_13,
g_atype972_14,
g_atype972_15,
g_atype972_16,
g_atype972_17,
};

static const long offsets972 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags973 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_1 [] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_4 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_17 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
g_atype973_1,
g_atype973_2,
g_atype973_3,
g_atype973_4,
g_atype973_5,
g_atype973_6,
g_atype973_7,
g_atype973_8,
g_atype973_9,
g_atype973_10,
g_atype973_11,
g_atype973_12,
g_atype973_13,
g_atype973_14,
g_atype973_15,
g_atype973_16,
g_atype973_17,
};

static const long offsets973 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags974 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_1 [] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_4 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_17 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
g_atype974_1,
g_atype974_2,
g_atype974_3,
g_atype974_4,
g_atype974_5,
g_atype974_6,
g_atype974_7,
g_atype974_8,
g_atype974_9,
g_atype974_10,
g_atype974_11,
g_atype974_12,
g_atype974_13,
g_atype974_14,
g_atype974_15,
g_atype974_16,
g_atype974_17,
};

static const long offsets974 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags975 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_1 [] = {0xFF01,1230,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_3 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_4 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_9 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_10 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_17 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
g_atype975_1,
g_atype975_2,
g_atype975_3,
g_atype975_4,
g_atype975_5,
g_atype975_6,
g_atype975_7,
g_atype975_8,
g_atype975_9,
g_atype975_10,
g_atype975_11,
g_atype975_12,
g_atype975_13,
g_atype975_14,
g_atype975_15,
g_atype975_16,
g_atype975_17,
};

static const long offsets975 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_BOOL,
};

static const uint16 attr_flags976 [] =
{0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
};

static const long offsets976 [] =
{
+ @CHROFF(0,0),
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_BOOL,
};

static const uint16 attr_flags977 [] =
{0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
};

static const long offsets977 [] =
{
+ @CHROFF(0,0),
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_BOOL,
};

static const uint16 attr_flags978 [] =
{0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
};

static const long offsets978 [] =
{
+ @CHROFF(0,0),
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_BOOL,
};

static const uint16 attr_flags979 [] =
{0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
};

static const long offsets979 [] =
{
+ @CHROFF(0,0),
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_BOOL,
};

static const uint16 attr_flags980 [] =
{0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
};

static const long offsets980 [] =
{
+ @CHROFF(0,0),
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_BOOL,
};

static const uint16 attr_flags981 [] =
{0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
};

static const long offsets981 [] =
{
+ @CHROFF(0,0),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_BOOL,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
+ @CHROFF(0,0),
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_BOOL,
};

static const uint16 attr_flags983 [] =
{0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
};

static const long offsets983 [] =
{
+ @CHROFF(0,0),
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_BOOL,
};

static const uint16 attr_flags984 [] =
{0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
};

static const long offsets984 [] =
{
+ @CHROFF(0,0),
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_BOOL,
};

static const uint16 attr_flags985 [] =
{0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
};

static const long offsets985 [] =
{
+ @CHROFF(0,0),
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_BOOL,
};

static const uint16 attr_flags986 [] =
{0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
};

static const long offsets986 [] =
{
+ @CHROFF(0,0),
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_BOOL,
};

static const uint16 attr_flags987 [] =
{0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
};

static const long offsets987 [] =
{
+ @CHROFF(0,0),
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags988 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
g_atype988_1,
g_atype988_2,
};

static const long offsets988 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names989[];
static const uint32 types989 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags989 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype989_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes989 [] = {
g_atype989_0,
g_atype989_1,
g_atype989_2,
g_atype989_3,
};

static const long offsets989 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names990[];
static const uint32 types990 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags990 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype990_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype990_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype990_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype990_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes990 [] = {
g_atype990_0,
g_atype990_1,
g_atype990_2,
g_atype990_3,
};

static const long offsets990 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names991[];
static const uint32 types991 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags991 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype991_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes991 [] = {
g_atype991_0,
g_atype991_1,
g_atype991_2,
g_atype991_3,
};

static const long offsets991 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names992[];
static const uint32 types992 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags992 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype992_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes992 [] = {
g_atype992_0,
g_atype992_1,
g_atype992_2,
g_atype992_3,
};

static const long offsets992 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names993[];
static const uint32 types993 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags993 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype993_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype993_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype993_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype993_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes993 [] = {
g_atype993_0,
g_atype993_1,
g_atype993_2,
g_atype993_3,
};

static const long offsets993 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names994[];
static const uint32 types994 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags994 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype994_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype994_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype994_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype994_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes994 [] = {
g_atype994_0,
g_atype994_1,
g_atype994_2,
g_atype994_3,
};

static const long offsets994 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names995[];
static const uint32 types995 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags995 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype995_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype995_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype995_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype995_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes995 [] = {
g_atype995_0,
g_atype995_1,
g_atype995_2,
g_atype995_3,
};

static const long offsets995 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names996[];
static const uint32 types996 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags996 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype996_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype996_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype996_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype996_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes996 [] = {
g_atype996_0,
g_atype996_1,
g_atype996_2,
g_atype996_3,
};

static const long offsets996 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names997[];
static const uint32 types997 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags997 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype997_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes997 [] = {
g_atype997_0,
g_atype997_1,
g_atype997_2,
g_atype997_3,
};

static const long offsets997 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags998 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
g_atype998_1,
g_atype998_2,
g_atype998_3,
};

static const long offsets998 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names999[];
static const uint32 types999 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags999 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype999_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes999 [] = {
g_atype999_0,
g_atype999_1,
g_atype999_2,
g_atype999_3,
};

static const long offsets999 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1000[];
static const uint32 types1000 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1000 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1000_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1000_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1000_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1000_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1000 [] = {
g_atype1000_0,
g_atype1000_1,
g_atype1000_2,
g_atype1000_3,
};

static const long offsets1000 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1001 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1001_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1001_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1001_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
g_atype1001_1,
g_atype1001_2,
g_atype1001_3,
};

static const long offsets1001 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1002[];
static const uint32 types1002 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1002 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1002_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1002_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1002_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1002_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1002 [] = {
g_atype1002_0,
g_atype1002_1,
g_atype1002_2,
g_atype1002_3,
};

static const long offsets1002 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1003 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1003_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1003_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1003_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
g_atype1003_1,
g_atype1003_2,
g_atype1003_3,
};

static const long offsets1003 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1004 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
g_atype1004_1,
g_atype1004_2,
g_atype1004_3,
};

static const long offsets1004 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1005 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
g_atype1005_1,
g_atype1005_2,
g_atype1005_3,
};

static const long offsets1005 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1006 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
};

static const long offsets1006 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1007 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
};

static const long offsets1007 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1008 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
};

static const long offsets1008 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1009 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
};

static const long offsets1009 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1010 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
};

static const long offsets1010 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1011 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
};

static const long offsets1011 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1012 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
};

static const long offsets1012 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1013 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
};

static const long offsets1013 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1014 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
};

static const long offsets1014 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1015 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
};

static const long offsets1015 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1016 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
};

static const long offsets1016 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1017 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
};

static const long offsets1017 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1018 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
};

static const long offsets1018 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1019 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
};

static const long offsets1019 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1020 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
};

static const long offsets1020 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1021 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
};

static const long offsets1021 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1022 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
};

static const long offsets1022 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1023 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
};

static const long offsets1023 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1024 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
};

static const long offsets1024 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1025 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
};

static const long offsets1025 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1026 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
};

static const long offsets1026 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1027 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
};

static const long offsets1027 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1028 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
};

static const long offsets1028 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1029 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
};

static const long offsets1029 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1030 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
};

static const long offsets1030 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1031 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
};

static const long offsets1031 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1032[];
static const uint32 types1032 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1032 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1032_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1032 [] = {
g_atype1032_0,
};

static const long offsets1032 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1033[];
static const uint32 types1033 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1033 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1033_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1033 [] = {
g_atype1033_0,
};

static const long offsets1033 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1034 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
};

static const long offsets1034 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1035 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
};

static const long offsets1035 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1036 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
};

static const long offsets1036 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1037 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
};

static const long offsets1037 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1038 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
};

static const long offsets1038 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1039 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
};

static const long offsets1039 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1040 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
};

static const long offsets1040 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1041 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
};

static const long offsets1041 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1042 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
};

static const long offsets1042 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1043 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
};

static const long offsets1043 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1044 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
};

static const long offsets1044 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1045 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
};

static const long offsets1045 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1046 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
};

static const long offsets1046 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1047 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
};

static const long offsets1047 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1048 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
};

static const long offsets1048 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1049 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
};

static const long offsets1049 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1050 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
};

static const long offsets1050 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1051 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
};

static const long offsets1051 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1052 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
};

static const long offsets1052 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1053 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
};

static const long offsets1053 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1054 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_1 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
g_atype1054_1,
g_atype1054_2,
g_atype1054_3,
g_atype1054_4,
g_atype1054_5,
};

static const long offsets1054 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1055 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_1 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
g_atype1055_1,
g_atype1055_2,
g_atype1055_3,
g_atype1055_4,
g_atype1055_5,
};

static const long offsets1055 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1056 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_1 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
g_atype1056_1,
g_atype1056_2,
g_atype1056_3,
g_atype1056_4,
g_atype1056_5,
};

static const long offsets1056 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1057 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_1 [] = {212,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
g_atype1057_1,
g_atype1057_2,
g_atype1057_3,
g_atype1057_4,
g_atype1057_5,
};

static const long offsets1057 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1058 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_1 [] = {211,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
g_atype1058_1,
g_atype1058_2,
g_atype1058_3,
g_atype1058_4,
g_atype1058_5,
};

static const long offsets1058 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1059 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
g_atype1059_1,
g_atype1059_2,
};

static const long offsets1059 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1060 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {0xFF01,1231,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
g_atype1060_1,
g_atype1060_2,
};

static const long offsets1060 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1061 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {0xFF01,1232,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
g_atype1061_1,
g_atype1061_2,
};

static const long offsets1061 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1062 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
g_atype1062_1,
g_atype1062_2,
};

static const long offsets1062 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1063 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
g_atype1063_1,
g_atype1063_2,
};

static const long offsets1063 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1064 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
g_atype1064_1,
g_atype1064_2,
};

static const long offsets1064 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1065 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {0xFF01,1236,1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
g_atype1065_1,
g_atype1065_2,
};

static const long offsets1065 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1066 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {0xFF01,1237,1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
g_atype1066_1,
g_atype1066_2,
};

static const long offsets1066 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1067 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
g_atype1067_1,
g_atype1067_2,
};

static const long offsets1067 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1068[];
static const uint32 types1068 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1068 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1068_0 [] = {0xFF01,1239,1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1068 [] = {
g_atype1068_0,
g_atype1068_1,
g_atype1068_2,
};

static const long offsets1068 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1069 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {0xFF01,1240,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
g_atype1069_1,
g_atype1069_2,
};

static const long offsets1069 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1070 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {0xFF01,1241,1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
g_atype1070_1,
g_atype1070_2,
};

static const long offsets1070 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1071 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {0xFF01,1230,0xFF01,1406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
g_atype1071_1,
g_atype1071_2,
};

static const long offsets1071 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1072 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
g_atype1072_1,
g_atype1072_2,
};

static const long offsets1072 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1073 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {0xFF01,1230,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
g_atype1073_1,
g_atype1073_2,
};

static const long offsets1073 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1074 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
g_atype1074_1,
g_atype1074_2,
};

static const long offsets1074 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1075 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {0xFF01,1230,0xFF01,1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_2 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_4 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
g_atype1075_2,
g_atype1075_3,
g_atype1075_4,
g_atype1075_5,
g_atype1075_6,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
};

static const uint16 attr_flags1076 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {0xFF01,1058,0xFF01,1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
};

static const long offsets1076 [] =
{
0,
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1090 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_3 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
g_atype1090_1,
g_atype1090_2,
g_atype1090_3,
};

static const long offsets1090 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1091 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
g_atype1091_2,
g_atype1091_3,
g_atype1091_4,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1096 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {0xFF01,1384,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {69,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_2 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
g_atype1096_2,
g_atype1096_3,
g_atype1096_4,
};

static const long offsets1096 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1098 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_1 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_2 [] = {0xFF01,1194,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_3 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
g_atype1098_1,
g_atype1098_2,
g_atype1098_3,
g_atype1098_4,
};

static const long offsets1098 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1099 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {0xFF01,1110,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_2 [] = {0xFF01,1029,0xFF01,712,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_3 [] = {0xFF01,1102,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
g_atype1099_2,
g_atype1099_3,
};

static const long offsets1099 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
};

static const uint16 attr_flags1101 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {1058,0xFF01,1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
};

static const long offsets1101 [] =
{
0,
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
};

static const uint16 attr_flags1102 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {1058,0xFF01,1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
};

static const long offsets1102 [] =
{
0,
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1103 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {0xFF01,1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
};

static const long offsets1103 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1104 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_1 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_2 [] = {0xFF01,1447,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
g_atype1104_1,
g_atype1104_2,
};

static const long offsets1104 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1105 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_1 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_2 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_4 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_5 [] = {960,0xFF01,1167,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_6 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_7 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_8 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_9 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_10 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_11 [] = {1029,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_31 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
g_atype1105_1,
g_atype1105_2,
g_atype1105_3,
g_atype1105_4,
g_atype1105_5,
g_atype1105_6,
g_atype1105_7,
g_atype1105_8,
g_atype1105_9,
g_atype1105_10,
g_atype1105_11,
g_atype1105_12,
g_atype1105_13,
g_atype1105_14,
g_atype1105_15,
g_atype1105_16,
g_atype1105_17,
g_atype1105_18,
g_atype1105_19,
g_atype1105_20,
g_atype1105_21,
g_atype1105_22,
g_atype1105_23,
g_atype1105_24,
g_atype1105_25,
g_atype1105_26,
g_atype1105_27,
g_atype1105_28,
g_atype1105_29,
g_atype1105_30,
g_atype1105_31,
};

static const long offsets1105 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1106 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_2 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_4 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_5 [] = {960,0xFF01,1167,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_6 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_7 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_8 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_9 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_10 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_11 [] = {1029,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_12 [] = {0xFF01,552,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_33 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
g_atype1106_2,
g_atype1106_3,
g_atype1106_4,
g_atype1106_5,
g_atype1106_6,
g_atype1106_7,
g_atype1106_8,
g_atype1106_9,
g_atype1106_10,
g_atype1106_11,
g_atype1106_12,
g_atype1106_13,
g_atype1106_14,
g_atype1106_15,
g_atype1106_16,
g_atype1106_17,
g_atype1106_18,
g_atype1106_19,
g_atype1106_20,
g_atype1106_21,
g_atype1106_22,
g_atype1106_23,
g_atype1106_24,
g_atype1106_25,
g_atype1106_26,
g_atype1106_27,
g_atype1106_28,
g_atype1106_29,
g_atype1106_30,
g_atype1106_31,
g_atype1106_32,
g_atype1106_33,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
+ @CHROFF(13,2),
+ @CHROFF(13,3),
+ @CHROFF(13,4),
+ @CHROFF(13,5),
+ @CHROFF(13,6),
+ @CHROFF(13,7),
+ @CHROFF(13,8),
+ @CHROFF(13,9),
+ @CHROFF(13,10),
+ @CHROFF(13,11),
+ @CHROFF(13,12),
+ @CHROFF(13,13),
+ @CHROFF(13,14),
+ @CHROFF(13,15),
+ @LNGOFF(13,16,0,0),
+ @LNGOFF(13,16,0,1),
+ @LNGOFF(13,16,0,2),
+ @LNGOFF(13,16,0,3),
+ @LNGOFF(13,16,0,4),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1107 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_2 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_4 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_5 [] = {960,0xFF01,1167,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_6 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_7 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_8 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_9 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_10 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_11 [] = {1029,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_12 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_13 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_14 [] = {0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_35 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
g_atype1107_2,
g_atype1107_3,
g_atype1107_4,
g_atype1107_5,
g_atype1107_6,
g_atype1107_7,
g_atype1107_8,
g_atype1107_9,
g_atype1107_10,
g_atype1107_11,
g_atype1107_12,
g_atype1107_13,
g_atype1107_14,
g_atype1107_15,
g_atype1107_16,
g_atype1107_17,
g_atype1107_18,
g_atype1107_19,
g_atype1107_20,
g_atype1107_21,
g_atype1107_22,
g_atype1107_23,
g_atype1107_24,
g_atype1107_25,
g_atype1107_26,
g_atype1107_27,
g_atype1107_28,
g_atype1107_29,
g_atype1107_30,
g_atype1107_31,
g_atype1107_32,
g_atype1107_33,
g_atype1107_34,
g_atype1107_35,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
+ @CHROFF(15,3),
+ @CHROFF(15,4),
+ @CHROFF(15,5),
+ @CHROFF(15,6),
+ @CHROFF(15,7),
+ @CHROFF(15,8),
+ @CHROFF(15,9),
+ @CHROFF(15,10),
+ @CHROFF(15,11),
+ @CHROFF(15,12),
+ @CHROFF(15,13),
+ @CHROFF(15,14),
+ @CHROFF(15,15),
+ @LNGOFF(15,16,0,0),
+ @LNGOFF(15,16,0,1),
+ @LNGOFF(15,16,0,2),
+ @LNGOFF(15,16,0,3),
+ @LNGOFF(15,16,0,4),
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1108 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_1 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_2 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_4 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_5 [] = {960,0xFF01,1167,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_6 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_7 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_8 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_9 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_10 [] = {1161,0xFF01,0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_11 [] = {1029,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_12 [] = {0xFF01,552,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_13 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_14 [] = {1162,0xFF01,0xFFF9,1,1113,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_15 [] = {0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_16 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_17 [] = {457,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_18 [] = {455,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_19 [] = {456,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_20 [] = {0xFF01,543,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_31 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_32 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_33 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_34 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_35 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_36 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_37 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_38 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_39 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_40 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_41 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_42 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_43 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_44 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_45 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_46 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_47 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
g_atype1108_1,
g_atype1108_2,
g_atype1108_3,
g_atype1108_4,
g_atype1108_5,
g_atype1108_6,
g_atype1108_7,
g_atype1108_8,
g_atype1108_9,
g_atype1108_10,
g_atype1108_11,
g_atype1108_12,
g_atype1108_13,
g_atype1108_14,
g_atype1108_15,
g_atype1108_16,
g_atype1108_17,
g_atype1108_18,
g_atype1108_19,
g_atype1108_20,
g_atype1108_21,
g_atype1108_22,
g_atype1108_23,
g_atype1108_24,
g_atype1108_25,
g_atype1108_26,
g_atype1108_27,
g_atype1108_28,
g_atype1108_29,
g_atype1108_30,
g_atype1108_31,
g_atype1108_32,
g_atype1108_33,
g_atype1108_34,
g_atype1108_35,
g_atype1108_36,
g_atype1108_37,
g_atype1108_38,
g_atype1108_39,
g_atype1108_40,
g_atype1108_41,
g_atype1108_42,
g_atype1108_43,
g_atype1108_44,
g_atype1108_45,
g_atype1108_46,
g_atype1108_47,
};

static const long offsets1108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @CHROFF(21,4),
+ @CHROFF(21,5),
+ @CHROFF(21,6),
+ @CHROFF(21,7),
+ @CHROFF(21,8),
+ @CHROFF(21,9),
+ @CHROFF(21,10),
+ @CHROFF(21,11),
+ @CHROFF(21,12),
+ @CHROFF(21,13),
+ @CHROFF(21,14),
+ @CHROFF(21,15),
+ @CHROFF(21,16),
+ @CHROFF(21,17),
+ @LNGOFF(21,18,0,0),
+ @LNGOFF(21,18,0,1),
+ @LNGOFF(21,18,0,2),
+ @LNGOFF(21,18,0,3),
+ @LNGOFF(21,18,0,4),
+ @LNGOFF(21,18,0,5),
+ @LNGOFF(21,18,0,6),
+ @LNGOFF(21,18,0,7),
+ @LNGOFF(21,18,0,8),
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1109 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {0xFF01,1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_1 [] = {0xFF01,78,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
g_atype1109_1,
};

static const long offsets1109 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1110 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {0xFF01,1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_1 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_2 [] = {0xFF01,199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
g_atype1110_1,
g_atype1110_2,
};

static const long offsets1110 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1111[];
static const uint32 types1111 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1111 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1111_0 [] = {0xFF01,1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_1 [] = {0xFF01,78,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_2 [] = {0xFF01,67,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_3 [] = {1029,0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_4 [] = {1029,0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1111 [] = {
g_atype1111_0,
g_atype1111_1,
g_atype1111_2,
g_atype1111_3,
g_atype1111_4,
g_atype1111_5,
};

static const long offsets1111 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_INT32,
};

static const uint16 attr_flags1113 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
};

static const long offsets1113 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1115 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_1 [] = {224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
g_atype1115_1,
g_atype1115_2,
};

static const long offsets1115 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1116[];
static const uint32 types1116 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1116 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1116_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_1 [] = {224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_2 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1116 [] = {
g_atype1116_0,
g_atype1116_1,
g_atype1116_2,
g_atype1116_3,
g_atype1116_4,
g_atype1116_5,
g_atype1116_6,
};

static const long offsets1116 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1117[];
static const uint32 types1117 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1117 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1117_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_1 [] = {224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_2 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1117 [] = {
g_atype1117_0,
g_atype1117_1,
g_atype1117_2,
g_atype1117_3,
g_atype1117_4,
g_atype1117_5,
g_atype1117_6,
};

static const long offsets1117 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1118[];
static const uint32 types1118 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags1118 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1118_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_1 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_2 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_7 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1118 [] = {
g_atype1118_0,
g_atype1118_1,
g_atype1118_2,
g_atype1118_3,
g_atype1118_4,
g_atype1118_5,
g_atype1118_6,
g_atype1118_7,
};

static const long offsets1118 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @LNGOFF(3,4,0,0),
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags1119 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_1 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_2 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_3 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_4 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_10 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
g_atype1119_1,
g_atype1119_2,
g_atype1119_3,
g_atype1119_4,
g_atype1119_5,
g_atype1119_6,
g_atype1119_7,
g_atype1119_8,
g_atype1119_9,
g_atype1119_10,
};

static const long offsets1119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1120 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
};

static const long offsets1120 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1121 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
};

static const long offsets1121 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1122 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {1121,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
};

static const long offsets1122 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1123 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
};

static const long offsets1123 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1124 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
};

static const long offsets1124 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1125 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {1124,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
};

static const long offsets1125 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1126 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
};

static const long offsets1126 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1127 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
};

static const long offsets1127 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1128 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
};

static const long offsets1128 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1129 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
};

static const long offsets1129 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
};

static const long offsets1130 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1131 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
};

static const long offsets1131 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
};

static const long offsets1132 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
};

static const long offsets1133 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1134 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
};

static const long offsets1134 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
};

static const long offsets1135 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1136 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
};

static const long offsets1136 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1137 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
};

static const long offsets1137 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
};

static const long offsets1138 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1139 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
};

static const long offsets1139 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
};

static const long offsets1140 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1141 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
};

static const long offsets1141 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1142 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
};

static const long offsets1142 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1143 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
};

static const long offsets1143 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1144 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
};

static const long offsets1144 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1145 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
};

static const long offsets1145 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1146 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
};

static const long offsets1146 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1147 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
};

static const long offsets1147 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
};

static const long offsets1148 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
};

static const long offsets1149 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
};

static const long offsets1150 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
};

static const long offsets1151 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1152 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
};

static const long offsets1152 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1153 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
};

static const long offsets1153 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1154 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
};

static const long offsets1154 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1155 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
};

static const long offsets1155 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1156 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
};

static const long offsets1156 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1157 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
};

static const long offsets1157 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1158 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
};

static const long offsets1158 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1159 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
};

static const long offsets1159 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1160 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
};

static const long offsets1160 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1161 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
};

static const long offsets1161 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1162 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_9 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_11 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
g_atype1162_1,
g_atype1162_2,
g_atype1162_3,
g_atype1162_4,
g_atype1162_5,
g_atype1162_6,
g_atype1162_7,
g_atype1162_8,
g_atype1162_9,
g_atype1162_10,
g_atype1162_11,
};

static const long offsets1162 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1163 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_9 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_11 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
g_atype1163_3,
g_atype1163_4,
g_atype1163_5,
g_atype1163_6,
g_atype1163_7,
g_atype1163_8,
g_atype1163_9,
g_atype1163_10,
g_atype1163_11,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1164 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_11 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_12 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
g_atype1164_1,
g_atype1164_2,
g_atype1164_3,
g_atype1164_4,
g_atype1164_5,
g_atype1164_6,
g_atype1164_7,
g_atype1164_8,
g_atype1164_9,
g_atype1164_10,
g_atype1164_11,
g_atype1164_12,
};

static const long offsets1164 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1165 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_11 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_12 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
g_atype1165_3,
g_atype1165_4,
g_atype1165_5,
g_atype1165_6,
g_atype1165_7,
g_atype1165_8,
g_atype1165_9,
g_atype1165_10,
g_atype1165_11,
g_atype1165_12,
};

static const long offsets1165 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1166 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_11 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_12 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
g_atype1166_3,
g_atype1166_4,
g_atype1166_5,
g_atype1166_6,
g_atype1166_7,
g_atype1166_8,
g_atype1166_9,
g_atype1166_10,
g_atype1166_11,
g_atype1166_12,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @LNGOFF(4,2,0,3),
+ @PTROFF(4,2,0,4,0,0),
+ @PTROFF(4,2,0,4,0,1),
+ @PTROFF(4,2,0,4,0,2),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {0xFFF9,0,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {991,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_10 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_11 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_12 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
g_atype1167_5,
g_atype1167_6,
g_atype1167_7,
g_atype1167_8,
g_atype1167_9,
g_atype1167_10,
g_atype1167_11,
g_atype1167_12,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1168 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
};

static const long offsets1168 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1169 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
g_atype1169_1,
};

static const long offsets1169 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
};

static const long offsets1170 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1171 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
g_atype1171_1,
g_atype1171_2,
g_atype1171_3,
};

static const long offsets1171 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
};

static const long offsets1172 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
};

static const long offsets1173 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
};

static const long offsets1174 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
g_atype1175_4,
};

static const long offsets1175 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
};

static const long offsets1176 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
g_atype1177_3,
g_atype1177_4,
g_atype1177_5,
};

static const long offsets1177 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1178 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
g_atype1178_1,
g_atype1178_2,
g_atype1178_3,
g_atype1178_4,
};

static const long offsets1178 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
g_atype1180_2,
g_atype1180_3,
g_atype1180_4,
g_atype1180_5,
g_atype1180_6,
g_atype1180_7,
g_atype1180_8,
};

static const long offsets1180 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1181 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_1 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_2 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_3 [] = {1171,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
g_atype1181_1,
g_atype1181_2,
g_atype1181_3,
};

static const long offsets1181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1182 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_1 [] = {0xFF01,935,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_2 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_3 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_12 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
g_atype1182_1,
g_atype1182_2,
g_atype1182_3,
g_atype1182_4,
g_atype1182_5,
g_atype1182_6,
g_atype1182_7,
g_atype1182_8,
g_atype1182_9,
g_atype1182_10,
g_atype1182_11,
g_atype1182_12,
};

static const long offsets1182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
+ @LNGOFF(3,3,0,1),
+ @LNGOFF(3,3,0,2),
+ @LNGOFF(3,3,0,3),
+ @LNGOFF(3,3,0,4),
+ @LNGOFF(3,3,0,5),
+ @LNGOFF(3,3,0,6),
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1183 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
g_atype1183_1,
g_atype1183_2,
g_atype1183_3,
g_atype1183_4,
g_atype1183_5,
g_atype1183_6,
g_atype1183_7,
};

static const long offsets1183 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT64,
};

static const uint16 attr_flags1184 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {0xFF01,1427,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_3 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
g_atype1184_1,
g_atype1184_2,
g_atype1184_3,
};

static const long offsets1184 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @I64OFF(2,1,0,0,0,0,0),
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_REF,
SK_UINT8,
};

static const uint16 attr_flags1185 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_1 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
g_atype1185_1,
};

static const long offsets1185 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
};

static const uint16 attr_flags1186 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {0xFF01,988,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_2 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_3 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
g_atype1186_2,
g_atype1186_3,
};

static const long offsets1186 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_UINT64,
};

static const uint16 attr_flags1187 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_1 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_2 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_4 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
g_atype1187_1,
g_atype1187_2,
g_atype1187_3,
g_atype1187_4,
};

static const long offsets1187 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @I64OFF(0,0,3,1,0,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
g_atype1188_1,
g_atype1188_2,
g_atype1188_3,
};

static const long offsets1188 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1189[];
static const uint32 types1189 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1189 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1189_0 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_1 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_2 [] = {0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_3 [] = {0xFF01,1246,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_5 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_6 [] = {1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_7 [] = {1058,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_8 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_9 [] = {0xFF01,421,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_10 [] = {1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_18 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1189 [] = {
g_atype1189_0,
g_atype1189_1,
g_atype1189_2,
g_atype1189_3,
g_atype1189_4,
g_atype1189_5,
g_atype1189_6,
g_atype1189_7,
g_atype1189_8,
g_atype1189_9,
g_atype1189_10,
g_atype1189_11,
g_atype1189_12,
g_atype1189_13,
g_atype1189_14,
g_atype1189_15,
g_atype1189_16,
g_atype1189_17,
g_atype1189_18,
};

static const long offsets1189 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @LNGOFF(11,6,0,0),
+ @LNGOFF(11,6,0,1),
};

extern const char *names1190[];
static const uint32 types1190 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1190 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1190_0 [] = {0xFF01,1413,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_2 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_3 [] = {1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_4 [] = {0xFF01,1063,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_5 [] = {1058,1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_6 [] = {1058,0xFF01,1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_7 [] = {0xFF01,0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_14 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1190 [] = {
g_atype1190_0,
g_atype1190_1,
g_atype1190_2,
g_atype1190_3,
g_atype1190_4,
g_atype1190_5,
g_atype1190_6,
g_atype1190_7,
g_atype1190_8,
g_atype1190_9,
g_atype1190_10,
g_atype1190_11,
g_atype1190_12,
g_atype1190_13,
g_atype1190_14,
};

static const long offsets1190 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names1191[];
static const uint32 types1191 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1191 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1191_0 [] = {0xFF01,1058,0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_1 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_2 [] = {0xFF01,1428,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1191 [] = {
g_atype1191_0,
g_atype1191_1,
g_atype1191_2,
};

static const long offsets1191 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1192 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_1 [] = {594,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_2 [] = {594,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_3 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_4 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_5 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_6 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_7 [] = {279,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_8 [] = {0xFF01,1381,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_9 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_10 [] = {61,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_11 [] = {1353,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_12 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_13 [] = {0xFF01,970,0xFF01,1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_14 [] = {0xFF01,970,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_15 [] = {0xFF01,970,0xFF01,1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_16 [] = {0xFF01,970,0xFF01,1252,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_17 [] = {0xFF01,1058,0xFF01,430,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_18 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_19 [] = {0xFF01,1058,0xFF01,438,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_20 [] = {0xFF01,1058,0xFF01,437,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_21 [] = {0xFF01,1058,0xFF01,436,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_22 [] = {0xFF01,1058,0xFF01,435,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_23 [] = {0xFF01,1058,0xFF01,434,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_24 [] = {0xFF01,1058,0xFF01,433,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_25 [] = {0xFF01,1058,0xFF01,432,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_26 [] = {0xFF01,1058,0xFF01,429,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_27 [] = {0xFF01,1058,0xFF01,429,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_28 [] = {0xFF01,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_29 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
g_atype1192_1,
g_atype1192_2,
g_atype1192_3,
g_atype1192_4,
g_atype1192_5,
g_atype1192_6,
g_atype1192_7,
g_atype1192_8,
g_atype1192_9,
g_atype1192_10,
g_atype1192_11,
g_atype1192_12,
g_atype1192_13,
g_atype1192_14,
g_atype1192_15,
g_atype1192_16,
g_atype1192_17,
g_atype1192_18,
g_atype1192_19,
g_atype1192_20,
g_atype1192_21,
g_atype1192_22,
g_atype1192_23,
g_atype1192_24,
g_atype1192_25,
g_atype1192_26,
g_atype1192_27,
g_atype1192_28,
g_atype1192_29,
};

static const long offsets1192 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1193 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {0xFF01,712,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_1 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_2 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_3 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_5 [] = {0xFF01,1058,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_6 [] = {0xFF01,1058,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_7 [] = {1428,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_8 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_9 [] = {970,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_10 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_11 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
g_atype1193_1,
g_atype1193_2,
g_atype1193_3,
g_atype1193_4,
g_atype1193_5,
g_atype1193_6,
g_atype1193_7,
g_atype1193_8,
g_atype1193_9,
g_atype1193_10,
g_atype1193_11,
};

static const long offsets1193 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1194 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_1 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
g_atype1194_1,
g_atype1194_2,
};

static const long offsets1194 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1195 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {0xFF01,1058,0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_1 [] = {0xFF01,1428,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_2 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_3 [] = {0xFF01,1428,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
g_atype1195_1,
g_atype1195_2,
g_atype1195_3,
};

static const long offsets1195 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1196[];
static const uint32 types1196 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1196 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1196_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1196 [] = {
g_atype1196_0,
g_atype1196_1,
};

static const long offsets1196 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1197[];
static const uint32 types1197 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1197 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1197_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1197 [] = {
g_atype1197_0,
g_atype1197_1,
};

static const long offsets1197 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1198 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
g_atype1198_1,
};

static const long offsets1198 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1199 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
g_atype1199_1,
};

static const long offsets1199 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1200 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
g_atype1200_1,
};

static const long offsets1200 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1201 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
g_atype1201_1,
};

static const long offsets1201 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1202[];
static const uint32 types1202 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1202 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1202_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1202 [] = {
g_atype1202_0,
g_atype1202_1,
};

static const long offsets1202 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1203[];
static const uint32 types1203 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1203 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1203_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1203 [] = {
g_atype1203_0,
g_atype1203_1,
};

static const long offsets1203 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1204[];
static const uint32 types1204 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1204 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1204_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1204 [] = {
g_atype1204_0,
g_atype1204_1,
};

static const long offsets1204 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1205[];
static const uint32 types1205 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1205 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1205_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1205 [] = {
g_atype1205_0,
g_atype1205_1,
};

static const long offsets1205 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1206 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
g_atype1206_1,
};

static const long offsets1206 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1207 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
g_atype1207_1,
};

static const long offsets1207 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1208 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
g_atype1208_1,
};

static const long offsets1208 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1209[];
static const uint32 types1209 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1209 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1209_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1209 [] = {
g_atype1209_0,
g_atype1209_1,
};

static const long offsets1209 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1210 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
g_atype1210_1,
};

static const long offsets1210 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1211[];
static const uint32 types1211 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1211 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1211_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1211 [] = {
g_atype1211_0,
g_atype1211_1,
};

static const long offsets1211 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1212 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
g_atype1212_1,
};

static const long offsets1212 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1213 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
g_atype1213_1,
};

static const long offsets1213 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1214 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
g_atype1214_1,
};

static const long offsets1214 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1215 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
g_atype1215_1,
};

static const long offsets1215 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1216 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
g_atype1216_1,
};

static const long offsets1216 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1217 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
g_atype1217_1,
};

static const long offsets1217 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1218 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
g_atype1218_1,
};

static const long offsets1218 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1219 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
g_atype1219_1,
};

static const long offsets1219 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1220 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
g_atype1220_1,
};

static const long offsets1220 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1221 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
g_atype1221_1,
};

static const long offsets1221 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1222 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
g_atype1222_1,
};

static const long offsets1222 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1223 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
g_atype1223_1,
};

static const long offsets1223 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1224 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
g_atype1224_1,
};

static const long offsets1224 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1225 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
g_atype1225_1,
};

static const long offsets1225 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1226 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
g_atype1226_1,
};

static const long offsets1226 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1227 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
g_atype1227_1,
};

static const long offsets1227 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1228 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
g_atype1228_1,
};

static const long offsets1228 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1229 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_1 [] = {1174,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
g_atype1229_1,
};

static const long offsets1229 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1243 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_1 [] = {1173,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
g_atype1243_1,
};

static const long offsets1243 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1244 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_1 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_2 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_3 [] = {1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
g_atype1244_1,
g_atype1244_2,
g_atype1244_3,
};

static const long offsets1244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1245 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_1 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_2 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
g_atype1245_1,
g_atype1245_2,
};

static const long offsets1245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1246 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_5 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_6 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_7 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_8 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_9 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_10 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_11 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_12 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_13 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_14 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_15 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_19 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
g_atype1246_1,
g_atype1246_2,
g_atype1246_3,
g_atype1246_4,
g_atype1246_5,
g_atype1246_6,
g_atype1246_7,
g_atype1246_8,
g_atype1246_9,
g_atype1246_10,
g_atype1246_11,
g_atype1246_12,
g_atype1246_13,
g_atype1246_14,
g_atype1246_15,
g_atype1246_16,
g_atype1246_17,
g_atype1246_18,
g_atype1246_19,
};

static const long offsets1246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1247 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_5 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_6 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_7 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_8 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_9 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_10 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_11 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_12 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_13 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_14 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_15 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_19 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
g_atype1247_5,
g_atype1247_6,
g_atype1247_7,
g_atype1247_8,
g_atype1247_9,
g_atype1247_10,
g_atype1247_11,
g_atype1247_12,
g_atype1247_13,
g_atype1247_14,
g_atype1247_15,
g_atype1247_16,
g_atype1247_17,
g_atype1247_18,
g_atype1247_19,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1248[];
static const uint32 types1248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1248 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1248_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_5 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_6 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_7 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_8 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_9 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_10 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_11 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_12 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_13 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_14 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_15 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_16 [] = {0xFF01,1058,0xFF01,1252,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_17 [] = {962,0xFF01,1247,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_21 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1248 [] = {
g_atype1248_0,
g_atype1248_1,
g_atype1248_2,
g_atype1248_3,
g_atype1248_4,
g_atype1248_5,
g_atype1248_6,
g_atype1248_7,
g_atype1248_8,
g_atype1248_9,
g_atype1248_10,
g_atype1248_11,
g_atype1248_12,
g_atype1248_13,
g_atype1248_14,
g_atype1248_15,
g_atype1248_16,
g_atype1248_17,
g_atype1248_18,
g_atype1248_19,
g_atype1248_20,
g_atype1248_21,
};

static const long offsets1248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1249 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_5 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_6 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_7 [] = {0xFF01,1399,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_8 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_9 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_10 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_11 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_12 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_13 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_14 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_15 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_16 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_17 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_18 [] = {1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_19 [] = {1058,1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_20 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_21 [] = {1058,0xFFF5,1,0xFF01,1245,9389,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_22 [] = {0xFF01,1058,0xFF01,430,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_23 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_24 [] = {0xFF01,970,0xFF01,1057,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_25 [] = {0xFF01,960,0xFF01,1057,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_26 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_31 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_32 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
g_atype1249_5,
g_atype1249_6,
g_atype1249_7,
g_atype1249_8,
g_atype1249_9,
g_atype1249_10,
g_atype1249_11,
g_atype1249_12,
g_atype1249_13,
g_atype1249_14,
g_atype1249_15,
g_atype1249_16,
g_atype1249_17,
g_atype1249_18,
g_atype1249_19,
g_atype1249_20,
g_atype1249_21,
g_atype1249_22,
g_atype1249_23,
g_atype1249_24,
g_atype1249_25,
g_atype1249_26,
g_atype1249_27,
g_atype1249_28,
g_atype1249_29,
g_atype1249_30,
g_atype1249_31,
g_atype1249_32,
};

static const long offsets1249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1250[];
static const uint32 types1250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1250 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1250_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_2 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_3 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_4 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_5 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_6 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_7 [] = {0xFF01,1399,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_8 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_9 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_10 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_11 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_12 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_13 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_14 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_15 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_16 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_17 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_18 [] = {1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_19 [] = {1058,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_20 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_21 [] = {1058,0xFFF5,1,0xFF01,1245,9389,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_22 [] = {0xFF01,1058,0xFF01,430,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_23 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_24 [] = {0xFF01,970,0xFF01,1057,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_25 [] = {0xFF01,960,0xFF01,1057,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_26 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_27 [] = {1058,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_28 [] = {1058,0xFFF5,1,0xFF01,1245,9389,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_31 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_32 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_33 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_34 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1250 [] = {
g_atype1250_0,
g_atype1250_1,
g_atype1250_2,
g_atype1250_3,
g_atype1250_4,
g_atype1250_5,
g_atype1250_6,
g_atype1250_7,
g_atype1250_8,
g_atype1250_9,
g_atype1250_10,
g_atype1250_11,
g_atype1250_12,
g_atype1250_13,
g_atype1250_14,
g_atype1250_15,
g_atype1250_16,
g_atype1250_17,
g_atype1250_18,
g_atype1250_19,
g_atype1250_20,
g_atype1250_21,
g_atype1250_22,
g_atype1250_23,
g_atype1250_24,
g_atype1250_25,
g_atype1250_26,
g_atype1250_27,
g_atype1250_28,
g_atype1250_29,
g_atype1250_30,
g_atype1250_31,
g_atype1250_32,
g_atype1250_33,
g_atype1250_34,
};

static const long offsets1250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
+ @CHROFF(29,1),
+ @CHROFF(29,2),
+ @CHROFF(29,3),
+ @CHROFF(29,4),
+ @LNGOFF(29,5,0,0),
};

extern const char *names1251[];
static const uint32 types1251 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1251 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1251_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_2 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_3 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_4 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_5 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_6 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_7 [] = {0xFF01,1399,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_8 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_9 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_10 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_11 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_12 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_13 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_14 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_15 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_16 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_17 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_18 [] = {1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_19 [] = {1058,1250,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_20 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_21 [] = {1058,0xFFF5,1,0xFF01,1245,9389,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_22 [] = {0xFF01,1058,0xFF01,430,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_23 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_24 [] = {0xFF01,970,0xFF01,1057,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_25 [] = {0xFF01,960,0xFF01,1057,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_26 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_27 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_28 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_29 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_30 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_31 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_32 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1251 [] = {
g_atype1251_0,
g_atype1251_1,
g_atype1251_2,
g_atype1251_3,
g_atype1251_4,
g_atype1251_5,
g_atype1251_6,
g_atype1251_7,
g_atype1251_8,
g_atype1251_9,
g_atype1251_10,
g_atype1251_11,
g_atype1251_12,
g_atype1251_13,
g_atype1251_14,
g_atype1251_15,
g_atype1251_16,
g_atype1251_17,
g_atype1251_18,
g_atype1251_19,
g_atype1251_20,
g_atype1251_21,
g_atype1251_22,
g_atype1251_23,
g_atype1251_24,
g_atype1251_25,
g_atype1251_26,
g_atype1251_27,
g_atype1251_28,
g_atype1251_29,
g_atype1251_30,
g_atype1251_31,
g_atype1251_32,
};

static const long offsets1251 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1252 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_5 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_6 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_7 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_8 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_9 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_10 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_11 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_12 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_13 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_14 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_15 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_16 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_17 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_21 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
g_atype1252_1,
g_atype1252_2,
g_atype1252_3,
g_atype1252_4,
g_atype1252_5,
g_atype1252_6,
g_atype1252_7,
g_atype1252_8,
g_atype1252_9,
g_atype1252_10,
g_atype1252_11,
g_atype1252_12,
g_atype1252_13,
g_atype1252_14,
g_atype1252_15,
g_atype1252_16,
g_atype1252_17,
g_atype1252_18,
g_atype1252_19,
g_atype1252_20,
g_atype1252_21,
};

static const long offsets1252 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1253[];
static const uint32 types1253 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1253 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1253_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_2 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_5 [] = {0xFF01,1400,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_6 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_7 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_8 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_9 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_10 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_11 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_12 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_13 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_14 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_15 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_16 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_17 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_18 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_19 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_20 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_21 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_22 [] = {1247,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_27 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1253 [] = {
g_atype1253_0,
g_atype1253_1,
g_atype1253_2,
g_atype1253_3,
g_atype1253_4,
g_atype1253_5,
g_atype1253_6,
g_atype1253_7,
g_atype1253_8,
g_atype1253_9,
g_atype1253_10,
g_atype1253_11,
g_atype1253_12,
g_atype1253_13,
g_atype1253_14,
g_atype1253_15,
g_atype1253_16,
g_atype1253_17,
g_atype1253_18,
g_atype1253_19,
g_atype1253_20,
g_atype1253_21,
g_atype1253_22,
g_atype1253_23,
g_atype1253_24,
g_atype1253_25,
g_atype1253_26,
g_atype1253_27,
};

static const long offsets1253 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @CHROFF(23,3),
+ @LNGOFF(23,4,0,0),
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1254 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_2 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_3 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_4 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_5 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_6 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_7 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_8 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_9 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_10 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_11 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_12 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_13 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_14 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_15 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_16 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_17 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_18 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_19 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_20 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_25 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
g_atype1254_1,
g_atype1254_2,
g_atype1254_3,
g_atype1254_4,
g_atype1254_5,
g_atype1254_6,
g_atype1254_7,
g_atype1254_8,
g_atype1254_9,
g_atype1254_10,
g_atype1254_11,
g_atype1254_12,
g_atype1254_13,
g_atype1254_14,
g_atype1254_15,
g_atype1254_16,
g_atype1254_17,
g_atype1254_18,
g_atype1254_19,
g_atype1254_20,
g_atype1254_21,
g_atype1254_22,
g_atype1254_23,
g_atype1254_24,
g_atype1254_25,
};

static const long offsets1254 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @LNGOFF(21,4,0,0),
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1255 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_1 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_2 [] = {1053,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_3 [] = {970,0xFF01,0xFFF9,2,1113,0xFF01,1170,970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_4 [] = {570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_5 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_6 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_7 [] = {0xFF01,1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_8 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_9 [] = {1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_10 [] = {970,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_11 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_12 [] = {593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_13 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_14 [] = {970,0xFF01,593,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_15 [] = {960,0xFF01,1188,0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_16 [] = {960,0xFF01,1167,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_17 [] = {1350,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_18 [] = {970,0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_19 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_20 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_21 [] = {1399,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_26 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
g_atype1255_1,
g_atype1255_2,
g_atype1255_3,
g_atype1255_4,
g_atype1255_5,
g_atype1255_6,
g_atype1255_7,
g_atype1255_8,
g_atype1255_9,
g_atype1255_10,
g_atype1255_11,
g_atype1255_12,
g_atype1255_13,
g_atype1255_14,
g_atype1255_15,
g_atype1255_16,
g_atype1255_17,
g_atype1255_18,
g_atype1255_19,
g_atype1255_20,
g_atype1255_21,
g_atype1255_22,
g_atype1255_23,
g_atype1255_24,
g_atype1255_25,
g_atype1255_26,
};

static const long offsets1255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
+ @CHROFF(22,0),
+ @CHROFF(22,1),
+ @CHROFF(22,2),
+ @CHROFF(22,3),
+ @LNGOFF(22,4,0,0),
};

extern const char *names1256[];
static const uint32 types1256 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1256 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1256_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_2 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1256 [] = {
g_atype1256_0,
g_atype1256_1,
g_atype1256_2,
};

static const long offsets1256 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1257[];
static const uint32 types1257 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1257 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1257_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1257 [] = {
g_atype1257_0,
g_atype1257_1,
g_atype1257_2,
g_atype1257_3,
g_atype1257_4,
g_atype1257_5,
};

static const long offsets1257 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1258[];
static const uint32 types1258 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1258 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1258_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_5 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1258 [] = {
g_atype1258_0,
g_atype1258_1,
g_atype1258_2,
g_atype1258_3,
g_atype1258_4,
g_atype1258_5,
};

static const long offsets1258 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1259[];
static const uint32 types1259 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1259 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1259_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_1 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1259 [] = {
g_atype1259_0,
g_atype1259_1,
g_atype1259_2,
g_atype1259_3,
g_atype1259_4,
g_atype1259_5,
};

static const long offsets1259 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1260 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_1 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
g_atype1260_1,
g_atype1260_2,
g_atype1260_3,
g_atype1260_4,
g_atype1260_5,
};

static const long offsets1260 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1261[];
static const uint32 types1261 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1261 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1261_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1261 [] = {
g_atype1261_0,
g_atype1261_1,
g_atype1261_2,
g_atype1261_3,
g_atype1261_4,
g_atype1261_5,
};

static const long offsets1261 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1262 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
g_atype1262_3,
g_atype1262_4,
g_atype1262_5,
};

static const long offsets1262 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1263[];
static const uint32 types1263 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1263 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1263_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1263 [] = {
g_atype1263_0,
g_atype1263_1,
g_atype1263_2,
g_atype1263_3,
g_atype1263_4,
g_atype1263_5,
};

static const long offsets1263 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1264[];
static const uint32 types1264 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1264 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1264_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_5 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1264 [] = {
g_atype1264_0,
g_atype1264_1,
g_atype1264_2,
g_atype1264_3,
g_atype1264_4,
g_atype1264_5,
};

static const long offsets1264 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names1265[];
static const uint32 types1265 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1265 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1265_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_1 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1265 [] = {
g_atype1265_0,
g_atype1265_1,
g_atype1265_2,
g_atype1265_3,
g_atype1265_4,
g_atype1265_5,
};

static const long offsets1265 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1266[];
static const uint32 types1266 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1266 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1266_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_5 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1266 [] = {
g_atype1266_0,
g_atype1266_1,
g_atype1266_2,
g_atype1266_3,
g_atype1266_4,
g_atype1266_5,
};

static const long offsets1266 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names1267[];
static const uint32 types1267 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1267 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1267_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_5 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1267 [] = {
g_atype1267_0,
g_atype1267_1,
g_atype1267_2,
g_atype1267_3,
g_atype1267_4,
g_atype1267_5,
};

static const long offsets1267 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1268[];
static const uint32 types1268 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1268 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1268_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_1 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1268 [] = {
g_atype1268_0,
g_atype1268_1,
g_atype1268_2,
g_atype1268_3,
g_atype1268_4,
g_atype1268_5,
};

static const long offsets1268 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1269[];
static const uint32 types1269 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1269 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1269_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_1 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1269 [] = {
g_atype1269_0,
g_atype1269_1,
g_atype1269_2,
g_atype1269_3,
g_atype1269_4,
g_atype1269_5,
};

static const long offsets1269 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1270[];
static const uint32 types1270 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1270 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1270_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1270 [] = {
g_atype1270_0,
g_atype1270_1,
g_atype1270_2,
g_atype1270_3,
g_atype1270_4,
g_atype1270_5,
};

static const long offsets1270 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1271[];
static const uint32 types1271 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1271 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1271_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_1 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_5 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1271 [] = {
g_atype1271_0,
g_atype1271_1,
g_atype1271_2,
g_atype1271_3,
g_atype1271_4,
g_atype1271_5,
};

static const long offsets1271 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names1272[];
static const uint32 types1272 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1272 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1272_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1272 [] = {
g_atype1272_0,
g_atype1272_1,
g_atype1272_2,
g_atype1272_3,
g_atype1272_4,
g_atype1272_5,
};

static const long offsets1272 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1273[];
static const uint32 types1273 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1273 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1273_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1273 [] = {
g_atype1273_0,
g_atype1273_1,
g_atype1273_2,
g_atype1273_3,
g_atype1273_4,
g_atype1273_5,
};

static const long offsets1273 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1274 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_5 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
g_atype1274_3,
g_atype1274_4,
g_atype1274_5,
};

static const long offsets1274 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1275 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
g_atype1275_4,
g_atype1275_5,
};

static const long offsets1275 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1276[];
static const uint32 types1276 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1276 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1276_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_2 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1276 [] = {
g_atype1276_0,
g_atype1276_1,
g_atype1276_2,
g_atype1276_3,
g_atype1276_4,
g_atype1276_5,
};

static const long offsets1276 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1277[];
static const uint32 types1277 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1277 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1277_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_5 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1277 [] = {
g_atype1277_0,
g_atype1277_1,
g_atype1277_2,
g_atype1277_3,
g_atype1277_4,
g_atype1277_5,
};

static const long offsets1277 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names1278[];
static const uint32 types1278 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1278 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1278_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_2 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1278 [] = {
g_atype1278_0,
g_atype1278_1,
g_atype1278_2,
g_atype1278_3,
g_atype1278_4,
g_atype1278_5,
};

static const long offsets1278 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1279 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_5 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
g_atype1279_1,
g_atype1279_2,
g_atype1279_3,
g_atype1279_4,
g_atype1279_5,
};

static const long offsets1279 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1280 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
g_atype1280_2,
g_atype1280_3,
g_atype1280_4,
g_atype1280_5,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1281[];
static const uint32 types1281 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1281 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1281_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_2 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1281 [] = {
g_atype1281_0,
g_atype1281_1,
g_atype1281_2,
g_atype1281_3,
g_atype1281_4,
g_atype1281_5,
};

static const long offsets1281 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1282 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_2 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
g_atype1282_1,
g_atype1282_2,
g_atype1282_3,
g_atype1282_4,
g_atype1282_5,
};

static const long offsets1282 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1283 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_5 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
g_atype1283_3,
g_atype1283_4,
g_atype1283_5,
};

static const long offsets1283 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1284[];
static const uint32 types1284 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1284 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1284_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_5 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1284 [] = {
g_atype1284_0,
g_atype1284_1,
g_atype1284_2,
g_atype1284_3,
g_atype1284_4,
g_atype1284_5,
};

static const long offsets1284 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names1285[];
static const uint32 types1285 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1285 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1285_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_2 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1285 [] = {
g_atype1285_0,
g_atype1285_1,
g_atype1285_2,
g_atype1285_3,
g_atype1285_4,
g_atype1285_5,
};

static const long offsets1285 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1286[];
static const uint32 types1286 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1286 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1286_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_3 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1286 [] = {
g_atype1286_0,
g_atype1286_1,
g_atype1286_2,
g_atype1286_3,
g_atype1286_4,
g_atype1286_5,
};

static const long offsets1286 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1287[];
static const uint32 types1287 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1287 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1287_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1287 [] = {
g_atype1287_0,
g_atype1287_1,
g_atype1287_2,
g_atype1287_3,
g_atype1287_4,
};

static const long offsets1287 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1288[];
static const uint32 types1288 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1288 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1288_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_2 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1288 [] = {
g_atype1288_0,
g_atype1288_1,
g_atype1288_2,
g_atype1288_3,
g_atype1288_4,
};

static const long offsets1288 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
g_atype1289_4,
};

static const long offsets1289 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1290 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
g_atype1290_2,
g_atype1290_3,
g_atype1290_4,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1291 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_2 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
g_atype1291_2,
g_atype1291_3,
g_atype1291_4,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1292[];
static const uint32 types1292 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1292 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1292_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_4 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1292 [] = {
g_atype1292_0,
g_atype1292_1,
g_atype1292_2,
g_atype1292_3,
g_atype1292_4,
};

static const long offsets1292 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1293 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_4 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
g_atype1293_2,
g_atype1293_3,
g_atype1293_4,
};

static const long offsets1293 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1294 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_2 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
g_atype1294_1,
g_atype1294_2,
g_atype1294_3,
g_atype1294_4,
};

static const long offsets1294 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1295 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_2 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
g_atype1295_1,
g_atype1295_2,
g_atype1295_3,
g_atype1295_4,
};

static const long offsets1295 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1296[];
static const uint32 types1296 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1296 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1296_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_2 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1296 [] = {
g_atype1296_0,
g_atype1296_1,
g_atype1296_2,
g_atype1296_3,
g_atype1296_4,
};

static const long offsets1296 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1297 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1298[];
static const uint32 types1298 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1298 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1298_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_2 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1298 [] = {
g_atype1298_0,
g_atype1298_1,
g_atype1298_2,
g_atype1298_3,
g_atype1298_4,
};

static const long offsets1298 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1299[];
static const uint32 types1299 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1299 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1299_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_4 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1299 [] = {
g_atype1299_0,
g_atype1299_1,
g_atype1299_2,
g_atype1299_3,
g_atype1299_4,
};

static const long offsets1299 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1300 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_4 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
g_atype1300_1,
g_atype1300_2,
g_atype1300_3,
g_atype1300_4,
};

static const long offsets1300 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {0xFFF9,2,1113,1312,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1303 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
};

static const long offsets1303 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1305[];
static const uint32 types1305 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1305 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1305_0 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_1 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1305 [] = {
g_atype1305_0,
g_atype1305_1,
};

static const long offsets1305 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
};

static const uint16 attr_flags1306 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {0xFF01,1175,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
};

static const long offsets1306 [] =
{
0,
};

extern const char *names1308[];
static const uint32 types1308 [] =
{
SK_INT64,
};

static const uint16 attr_flags1308 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1308_0 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1308 [] = {
g_atype1308_0,
};

static const long offsets1308 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_INT64,
};

static const uint16 attr_flags1309 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
};

static const long offsets1309 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_INT64,
};

static const uint16 attr_flags1310 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {1309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
};

static const long offsets1310 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1311[];
static const uint32 types1311 [] =
{
SK_INT32,
};

static const uint16 attr_flags1311 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1311_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1311 [] = {
g_atype1311_0,
};

static const long offsets1311 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1312[];
static const uint32 types1312 [] =
{
SK_INT32,
};

static const uint16 attr_flags1312 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1312_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1312 [] = {
g_atype1312_0,
};

static const long offsets1312 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1313[];
static const uint32 types1313 [] =
{
SK_INT32,
};

static const uint16 attr_flags1313 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1313_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1313 [] = {
g_atype1313_0,
};

static const long offsets1313 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1314[];
static const uint32 types1314 [] =
{
SK_INT16,
};

static const uint16 attr_flags1314 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1314_0 [] = {1315,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1314 [] = {
g_atype1314_0,
};

static const long offsets1314 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1315[];
static const uint32 types1315 [] =
{
SK_INT16,
};

static const uint16 attr_flags1315 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1315_0 [] = {1315,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1315 [] = {
g_atype1315_0,
};

static const long offsets1315 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1316[];
static const uint32 types1316 [] =
{
SK_INT16,
};

static const uint16 attr_flags1316 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1316_0 [] = {1315,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1316 [] = {
g_atype1316_0,
};

static const long offsets1316 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1317[];
static const uint32 types1317 [] =
{
SK_INT8,
};

static const uint16 attr_flags1317 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1317_0 [] = {1318,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1317 [] = {
g_atype1317_0,
};

static const long offsets1317 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1318[];
static const uint32 types1318 [] =
{
SK_INT8,
};

static const uint16 attr_flags1318 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1318_0 [] = {1318,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1318 [] = {
g_atype1318_0,
};

static const long offsets1318 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1319[];
static const uint32 types1319 [] =
{
SK_INT8,
};

static const uint16 attr_flags1319 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1319_0 [] = {1318,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1319 [] = {
g_atype1319_0,
};

static const long offsets1319 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1320[];
static const uint32 types1320 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1320 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1320_0 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1320 [] = {
g_atype1320_0,
};

static const long offsets1320 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1321[];
static const uint32 types1321 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1321 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1321_0 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1321 [] = {
g_atype1321_0,
};

static const long offsets1321 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1322[];
static const uint32 types1322 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1322 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1322_0 [] = {1321,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1322 [] = {
g_atype1322_0,
};

static const long offsets1322 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1323[];
static const uint32 types1323 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1323 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1323_0 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1323 [] = {
g_atype1323_0,
};

static const long offsets1323 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1324[];
static const uint32 types1324 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1324 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1324_0 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1324 [] = {
g_atype1324_0,
};

static const long offsets1324 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1325[];
static const uint32 types1325 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1325 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1325_0 [] = {1324,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1325 [] = {
g_atype1325_0,
};

static const long offsets1325 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1326[];
static const uint32 types1326 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1326 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1326_0 [] = {1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1326 [] = {
g_atype1326_0,
};

static const long offsets1326 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1327[];
static const uint32 types1327 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1327 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1327_0 [] = {1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1327 [] = {
g_atype1327_0,
};

static const long offsets1327 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1328[];
static const uint32 types1328 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1328_0 [] = {1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1328 [] = {
g_atype1328_0,
};

static const long offsets1328 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1329[];
static const uint32 types1329 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1329 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1329_0 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1329 [] = {
g_atype1329_0,
};

static const long offsets1329 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1330[];
static const uint32 types1330 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1330 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1330_0 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1330 [] = {
g_atype1330_0,
};

static const long offsets1330 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1331[];
static const uint32 types1331 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1331 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1331_0 [] = {1330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1331 [] = {
g_atype1331_0,
};

static const long offsets1331 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1332[];
static const uint32 types1332 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1332 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1332_0 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1332 [] = {
g_atype1332_0,
};

static const long offsets1332 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1333[];
static const uint32 types1333 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1333 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1333_0 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1333 [] = {
g_atype1333_0,
};

static const long offsets1333 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1334[];
static const uint32 types1334 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1334 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1334_0 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1334 [] = {
g_atype1334_0,
};

static const long offsets1334 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1335[];
static const uint32 types1335 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1335 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1335_0 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1335 [] = {
g_atype1335_0,
};

static const long offsets1335 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1336[];
static const uint32 types1336 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1336 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1336_0 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1336 [] = {
g_atype1336_0,
};

static const long offsets1336 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1337[];
static const uint32 types1337 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1337 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1337_0 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1337 [] = {
g_atype1337_0,
};

static const long offsets1337 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1338[];
static const uint32 types1338 [] =
{
SK_REF,
};

static const uint16 attr_flags1338 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1338_0 [] = {0xFF01,960,0xFF01,1301,0xFF01,1305,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1338 [] = {
g_atype1338_0,
};

static const long offsets1338 [] =
{
0,
};

extern const char *names1339[];
static const uint32 types1339 [] =
{
SK_REF,
};

static const uint16 attr_flags1339 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1339_0 [] = {0xFF01,1058,0xFF01,1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1339 [] = {
g_atype1339_0,
};

static const long offsets1339 [] =
{
0,
};

extern const char *names1345[];
static const uint32 types1345 [] =
{
SK_REF,
};

static const uint16 attr_flags1345 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1345_0 [] = {0xFF01,1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1345 [] = {
g_atype1345_0,
};

static const long offsets1345 [] =
{
0,
};

extern const char *names1346[];
static const uint32 types1346 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags1346 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1346_0 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_2 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1346 [] = {
g_atype1346_0,
g_atype1346_1,
g_atype1346_2,
};

static const long offsets1346 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names1348[];
static const uint32 types1348 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1348 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1348_0 [] = {0xFF01,147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_1 [] = {0xFF01,146,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1348 [] = {
g_atype1348_0,
g_atype1348_1,
};

static const long offsets1348 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1349[];
static const uint32 types1349 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1349 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1349_0 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1349_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1349_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1349_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1349_4 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1349_5 [] = {1172,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1349 [] = {
g_atype1349_0,
g_atype1349_1,
g_atype1349_2,
g_atype1349_3,
g_atype1349_4,
g_atype1349_5,
};

static const long offsets1349 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1350[];
static const uint32 types1350 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1350 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1350_0 [] = {0xFF01,47,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_3 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1350 [] = {
g_atype1350_0,
g_atype1350_1,
g_atype1350_2,
g_atype1350_3,
};

static const long offsets1350 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1351[];
static const uint32 types1351 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1351 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1351_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_1 [] = {266,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_2 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_3 [] = {0xFF01,1230,0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1351 [] = {
g_atype1351_0,
g_atype1351_1,
g_atype1351_2,
g_atype1351_3,
g_atype1351_4,
g_atype1351_5,
g_atype1351_6,
g_atype1351_7,
g_atype1351_8,
g_atype1351_9,
};

static const long offsets1351 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
+ @LNGOFF(4,1,0,4),
};

extern const char *names1352[];
static const uint32 types1352 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1352 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1352_0 [] = {267,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_1 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_2 [] = {0xFF01,1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_4 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1352 [] = {
g_atype1352_0,
g_atype1352_1,
g_atype1352_2,
g_atype1352_3,
g_atype1352_4,
g_atype1352_5,
g_atype1352_6,
g_atype1352_7,
g_atype1352_8,
g_atype1352_9,
};

static const long offsets1352 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1353[];
static const uint32 types1353 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1353 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1353_0 [] = {268,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_1 [] = {0xFF01,1235,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_2 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_9 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1353 [] = {
g_atype1353_0,
g_atype1353_1,
g_atype1353_2,
g_atype1353_3,
g_atype1353_4,
g_atype1353_5,
g_atype1353_6,
g_atype1353_7,
g_atype1353_8,
g_atype1353_9,
};

static const long offsets1353 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1354[];
static const uint32 types1354 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT16,
};

static const uint16 attr_flags1354 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1354_0 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_1 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_2 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_3 [] = {1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_5 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_6 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_7 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_8 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_9 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_10 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_11 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_12 [] = {1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1354 [] = {
g_atype1354_0,
g_atype1354_1,
g_atype1354_2,
g_atype1354_3,
g_atype1354_4,
g_atype1354_5,
g_atype1354_6,
g_atype1354_7,
g_atype1354_8,
g_atype1354_9,
g_atype1354_10,
g_atype1354_11,
g_atype1354_12,
};

static const long offsets1354 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @I16OFF(4,5,0),
+ @I16OFF(4,5,1),
+ @I16OFF(4,5,2),
+ @I16OFF(4,5,3),
};

extern const char *names1355[];
static const uint32 types1355 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1355 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1355_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_3 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_4 [] = {68,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_10 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_11 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_12 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_13 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_14 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_18 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_19 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_20 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_21 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_22 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1355 [] = {
g_atype1355_0,
g_atype1355_1,
g_atype1355_2,
g_atype1355_3,
g_atype1355_4,
g_atype1355_5,
g_atype1355_6,
g_atype1355_7,
g_atype1355_8,
g_atype1355_9,
g_atype1355_10,
g_atype1355_11,
g_atype1355_12,
g_atype1355_13,
g_atype1355_14,
g_atype1355_15,
g_atype1355_16,
g_atype1355_17,
g_atype1355_18,
g_atype1355_19,
g_atype1355_20,
g_atype1355_21,
g_atype1355_22,
};

static const long offsets1355 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1362[];
static const uint32 types1362 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1362 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1362_0 [] = {0xFF01,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_1 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_2 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1362 [] = {
g_atype1362_0,
g_atype1362_1,
g_atype1362_2,
g_atype1362_3,
};

static const long offsets1362 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1363[];
static const uint32 types1363 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1363 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1363_0 [] = {0xFF01,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_1 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_2 [] = {1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_3 [] = {1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_4 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_7 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_21 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1363 [] = {
g_atype1363_0,
g_atype1363_1,
g_atype1363_2,
g_atype1363_3,
g_atype1363_4,
g_atype1363_5,
g_atype1363_6,
g_atype1363_7,
g_atype1363_8,
g_atype1363_9,
g_atype1363_10,
g_atype1363_11,
g_atype1363_12,
g_atype1363_13,
g_atype1363_14,
g_atype1363_15,
g_atype1363_16,
g_atype1363_17,
g_atype1363_18,
g_atype1363_19,
g_atype1363_20,
g_atype1363_21,
};

static const long offsets1363 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1364[];
static const uint32 types1364 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1364 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1364_0 [] = {0xFF01,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_1 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_2 [] = {1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_3 [] = {1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_4 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_5 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_6 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_7 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_8 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_9 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_10 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_11 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_12 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_13 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_14 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_17 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_35 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_36 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_37 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1364 [] = {
g_atype1364_0,
g_atype1364_1,
g_atype1364_2,
g_atype1364_3,
g_atype1364_4,
g_atype1364_5,
g_atype1364_6,
g_atype1364_7,
g_atype1364_8,
g_atype1364_9,
g_atype1364_10,
g_atype1364_11,
g_atype1364_12,
g_atype1364_13,
g_atype1364_14,
g_atype1364_15,
g_atype1364_16,
g_atype1364_17,
g_atype1364_18,
g_atype1364_19,
g_atype1364_20,
g_atype1364_21,
g_atype1364_22,
g_atype1364_23,
g_atype1364_24,
g_atype1364_25,
g_atype1364_26,
g_atype1364_27,
g_atype1364_28,
g_atype1364_29,
g_atype1364_30,
g_atype1364_31,
g_atype1364_32,
g_atype1364_33,
g_atype1364_34,
g_atype1364_35,
g_atype1364_36,
g_atype1364_37,
};

static const long offsets1364 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1365[];
static const uint32 types1365 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1365 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1365_0 [] = {0xFF01,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_1 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_2 [] = {1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_3 [] = {1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_4 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_5 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_6 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_7 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_8 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_9 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_10 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_11 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_12 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_13 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_14 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_15 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_16 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_20 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_35 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_36 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_37 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_38 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_39 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_40 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_41 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1365 [] = {
g_atype1365_0,
g_atype1365_1,
g_atype1365_2,
g_atype1365_3,
g_atype1365_4,
g_atype1365_5,
g_atype1365_6,
g_atype1365_7,
g_atype1365_8,
g_atype1365_9,
g_atype1365_10,
g_atype1365_11,
g_atype1365_12,
g_atype1365_13,
g_atype1365_14,
g_atype1365_15,
g_atype1365_16,
g_atype1365_17,
g_atype1365_18,
g_atype1365_19,
g_atype1365_20,
g_atype1365_21,
g_atype1365_22,
g_atype1365_23,
g_atype1365_24,
g_atype1365_25,
g_atype1365_26,
g_atype1365_27,
g_atype1365_28,
g_atype1365_29,
g_atype1365_30,
g_atype1365_31,
g_atype1365_32,
g_atype1365_33,
g_atype1365_34,
g_atype1365_35,
g_atype1365_36,
g_atype1365_37,
g_atype1365_38,
g_atype1365_39,
g_atype1365_40,
g_atype1365_41,
};

static const long offsets1365 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1366[];
static const uint32 types1366 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1366 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1366_0 [] = {0xFF01,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_1 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_2 [] = {1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_3 [] = {1238,1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_4 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_5 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_6 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_7 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_8 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_9 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_10 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_11 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_12 [] = {1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_13 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_14 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_15 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_16 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_20 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_30 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_31 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_32 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_33 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_34 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_35 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_36 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_37 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_38 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_39 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_40 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_41 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1366 [] = {
g_atype1366_0,
g_atype1366_1,
g_atype1366_2,
g_atype1366_3,
g_atype1366_4,
g_atype1366_5,
g_atype1366_6,
g_atype1366_7,
g_atype1366_8,
g_atype1366_9,
g_atype1366_10,
g_atype1366_11,
g_atype1366_12,
g_atype1366_13,
g_atype1366_14,
g_atype1366_15,
g_atype1366_16,
g_atype1366_17,
g_atype1366_18,
g_atype1366_19,
g_atype1366_20,
g_atype1366_21,
g_atype1366_22,
g_atype1366_23,
g_atype1366_24,
g_atype1366_25,
g_atype1366_26,
g_atype1366_27,
g_atype1366_28,
g_atype1366_29,
g_atype1366_30,
g_atype1366_31,
g_atype1366_32,
g_atype1366_33,
g_atype1366_34,
g_atype1366_35,
g_atype1366_36,
g_atype1366_37,
g_atype1366_38,
g_atype1366_39,
g_atype1366_40,
g_atype1366_41,
};

static const long offsets1366 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1367[];
static const uint32 types1367 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1367 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1367_0 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1367 [] = {
g_atype1367_0,
};

static const long offsets1367 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1368[];
static const uint32 types1368 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1368 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1368_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_1 [] = {68,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_3 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1368 [] = {
g_atype1368_0,
g_atype1368_1,
g_atype1368_2,
g_atype1368_3,
};

static const long offsets1368 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1370[];
static const uint32 types1370 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1370 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1370_0 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_1 [] = {1058,0xFF01,570,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1370 [] = {
g_atype1370_0,
g_atype1370_1,
};

static const long offsets1370 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1371[];
static const uint32 types1371 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1371 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1371_0 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_1 [] = {1058,0xFF01,570,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1371 [] = {
g_atype1371_0,
g_atype1371_1,
};

static const long offsets1371 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1372[];
static const uint32 types1372 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1372 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1372_0 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_1 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_2 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_4 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_5 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1372 [] = {
g_atype1372_0,
g_atype1372_1,
g_atype1372_2,
g_atype1372_3,
g_atype1372_4,
g_atype1372_5,
g_atype1372_6,
g_atype1372_7,
g_atype1372_8,
};

static const long offsets1372 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
};

extern const char *names1373[];
static const uint32 types1373 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1373 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1373_0 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_1 [] = {1058,0xFF01,570,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_2 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_3 [] = {1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_4 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_5 [] = {0xFF01,1058,0xFF01,1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_6 [] = {0xFF01,1058,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_7 [] = {0xFF01,970,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_8 [] = {49,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_9 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1373 [] = {
g_atype1373_0,
g_atype1373_1,
g_atype1373_2,
g_atype1373_3,
g_atype1373_4,
g_atype1373_5,
g_atype1373_6,
g_atype1373_7,
g_atype1373_8,
g_atype1373_9,
};

static const long offsets1373 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
};

extern const char *names1375[];
static const uint32 types1375 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1375 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1375_0 [] = {0xFF01,962,0xFF01,1179,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_1 [] = {0xFF01,988,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_2 [] = {0xFF01,988,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_3 [] = {1426,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_6 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1375 [] = {
g_atype1375_0,
g_atype1375_1,
g_atype1375_2,
g_atype1375_3,
g_atype1375_4,
g_atype1375_5,
g_atype1375_6,
};

static const long offsets1375 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names1376[];
static const uint32 types1376 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1376 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1376_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1376_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1376_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1376 [] = {
g_atype1376_0,
g_atype1376_1,
g_atype1376_2,
};

static const long offsets1376 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1377[];
static const uint32 types1377 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1377 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1377_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1377_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1377_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1377 [] = {
g_atype1377_0,
g_atype1377_1,
g_atype1377_2,
};

static const long offsets1377 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1378[];
static const uint32 types1378 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1378 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1378_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1378_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1378_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1378 [] = {
g_atype1378_0,
g_atype1378_1,
g_atype1378_2,
};

static const long offsets1378 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1379[];
static const uint32 types1379 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1379 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1379_0 [] = {1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1379_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1379_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1379 [] = {
g_atype1379_0,
g_atype1379_1,
g_atype1379_2,
};

static const long offsets1379 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1380[];
static const uint32 types1380 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1380 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1380_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_4 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1380 [] = {
g_atype1380_0,
g_atype1380_1,
g_atype1380_2,
g_atype1380_3,
g_atype1380_4,
};

static const long offsets1380 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1381[];
static const uint32 types1381 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1381 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1381_0 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_1 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_2 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_3 [] = {1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1381 [] = {
g_atype1381_0,
g_atype1381_1,
g_atype1381_2,
g_atype1381_3,
g_atype1381_4,
g_atype1381_5,
g_atype1381_6,
g_atype1381_7,
};

static const long offsets1381 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names1382[];
static const uint32 types1382 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1382 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1382_0 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_1 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_3 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_4 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_5 [] = {0xFF01,1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_6 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_7 [] = {0xFF01,970,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_8 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_9 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_10 [] = {0xFF01,960,0xFF01,1191,0xFF01,1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_11 [] = {970,0xFF01,1247,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_12 [] = {1058,0xFF01,1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_13 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_14 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_15 [] = {0xFF01,1058,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_20 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_21 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1382 [] = {
g_atype1382_0,
g_atype1382_1,
g_atype1382_2,
g_atype1382_3,
g_atype1382_4,
g_atype1382_5,
g_atype1382_6,
g_atype1382_7,
g_atype1382_8,
g_atype1382_9,
g_atype1382_10,
g_atype1382_11,
g_atype1382_12,
g_atype1382_13,
g_atype1382_14,
g_atype1382_15,
g_atype1382_16,
g_atype1382_17,
g_atype1382_18,
g_atype1382_19,
g_atype1382_20,
g_atype1382_21,
};

static const long offsets1382 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
};

extern const char *names1383[];
static const uint32 types1383 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1383 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1383_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_1 [] = {0xFFF9,2,1113,0xFF01,1173,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_2 [] = {54,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_5 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_6 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_7 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_8 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_9 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_10 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_14 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_20 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1383 [] = {
g_atype1383_0,
g_atype1383_1,
g_atype1383_2,
g_atype1383_3,
g_atype1383_4,
g_atype1383_5,
g_atype1383_6,
g_atype1383_7,
g_atype1383_8,
g_atype1383_9,
g_atype1383_10,
g_atype1383_11,
g_atype1383_12,
g_atype1383_13,
g_atype1383_14,
g_atype1383_15,
g_atype1383_16,
g_atype1383_17,
g_atype1383_18,
g_atype1383_19,
g_atype1383_20,
};

static const long offsets1383 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @LNGOFF(11,3,0,0),
+ @LNGOFF(11,3,0,1),
+ @LNGOFF(11,3,0,2),
+ @LNGOFF(11,3,0,3),
+ @LNGOFF(11,3,0,4),
+ @LNGOFF(11,3,0,5),
+ @LNGOFF(11,3,0,6),
};

extern const char *names1384[];
static const uint32 types1384 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1384 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1384_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_1 [] = {0xFFF9,2,1113,0xFF01,1173,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_2 [] = {54,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_5 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_6 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_7 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_8 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_9 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_10 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_11 [] = {0xFF01,252,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_12 [] = {0xFF01,253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_16 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_17 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_21 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_22 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1384 [] = {
g_atype1384_0,
g_atype1384_1,
g_atype1384_2,
g_atype1384_3,
g_atype1384_4,
g_atype1384_5,
g_atype1384_6,
g_atype1384_7,
g_atype1384_8,
g_atype1384_9,
g_atype1384_10,
g_atype1384_11,
g_atype1384_12,
g_atype1384_13,
g_atype1384_14,
g_atype1384_15,
g_atype1384_16,
g_atype1384_17,
g_atype1384_18,
g_atype1384_19,
g_atype1384_20,
g_atype1384_21,
g_atype1384_22,
};

static const long offsets1384 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
+ @CHROFF(13,2),
+ @LNGOFF(13,3,0,0),
+ @LNGOFF(13,3,0,1),
+ @LNGOFF(13,3,0,2),
+ @LNGOFF(13,3,0,3),
+ @LNGOFF(13,3,0,4),
+ @LNGOFF(13,3,0,5),
+ @LNGOFF(13,3,0,6),
};

extern const char *names1385[];
static const uint32 types1385 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1385 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1385_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_1 [] = {0xFFF9,2,1113,0xFF01,1173,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_2 [] = {54,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_3 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_4 [] = {0xFF01,960,0xFF01,1173,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_5 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_6 [] = {0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_7 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_8 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_9 [] = {1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_10 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_11 [] = {40,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_16 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_21 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1385 [] = {
g_atype1385_0,
g_atype1385_1,
g_atype1385_2,
g_atype1385_3,
g_atype1385_4,
g_atype1385_5,
g_atype1385_6,
g_atype1385_7,
g_atype1385_8,
g_atype1385_9,
g_atype1385_10,
g_atype1385_11,
g_atype1385_12,
g_atype1385_13,
g_atype1385_14,
g_atype1385_15,
g_atype1385_16,
g_atype1385_17,
g_atype1385_18,
g_atype1385_19,
g_atype1385_20,
g_atype1385_21,
};

static const long offsets1385 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @LNGOFF(12,3,0,0),
+ @LNGOFF(12,3,0,1),
+ @LNGOFF(12,3,0,2),
+ @LNGOFF(12,3,0,3),
+ @LNGOFF(12,3,0,4),
+ @LNGOFF(12,3,0,5),
+ @LNGOFF(12,3,0,6),
};

extern const char *names1387[];
static const uint32 types1387 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1387 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1387_0 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_3 [] = {135,0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_9 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_10 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1387 [] = {
g_atype1387_0,
g_atype1387_1,
g_atype1387_2,
g_atype1387_3,
g_atype1387_4,
g_atype1387_5,
g_atype1387_6,
g_atype1387_7,
g_atype1387_8,
g_atype1387_9,
g_atype1387_10,
};

static const long offsets1387 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1388[];
static const uint32 types1388 [] =
{
SK_REF,
};

static const uint16 attr_flags1388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1388_0 [] = {0xFF01,1175,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1388 [] = {
g_atype1388_0,
};

static const long offsets1388 [] =
{
0,
};

extern const char *names1389[];
static const uint32 types1389 [] =
{
SK_REF,
};

static const uint16 attr_flags1389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1389_0 [] = {0xFF01,1175,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1389 [] = {
g_atype1389_0,
};

static const long offsets1389 [] =
{
0,
};

extern const char *names1390[];
static const uint32 types1390 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1390 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1390_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_3 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_9 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_10 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_11 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_12 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_13 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_17 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_18 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_19 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_20 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_21 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1390 [] = {
g_atype1390_0,
g_atype1390_1,
g_atype1390_2,
g_atype1390_3,
g_atype1390_4,
g_atype1390_5,
g_atype1390_6,
g_atype1390_7,
g_atype1390_8,
g_atype1390_9,
g_atype1390_10,
g_atype1390_11,
g_atype1390_12,
g_atype1390_13,
g_atype1390_14,
g_atype1390_15,
g_atype1390_16,
g_atype1390_17,
g_atype1390_18,
g_atype1390_19,
g_atype1390_20,
g_atype1390_21,
};

static const long offsets1390 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1391[];
static const uint32 types1391 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1391 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1391_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_3 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_9 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_10 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_11 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_12 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_13 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_17 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_18 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_19 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_20 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_21 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1391 [] = {
g_atype1391_0,
g_atype1391_1,
g_atype1391_2,
g_atype1391_3,
g_atype1391_4,
g_atype1391_5,
g_atype1391_6,
g_atype1391_7,
g_atype1391_8,
g_atype1391_9,
g_atype1391_10,
g_atype1391_11,
g_atype1391_12,
g_atype1391_13,
g_atype1391_14,
g_atype1391_15,
g_atype1391_16,
g_atype1391_17,
g_atype1391_18,
g_atype1391_19,
g_atype1391_20,
g_atype1391_21,
};

static const long offsets1391 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1392[];
static const uint32 types1392 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1392 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1392_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_1 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_3 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_5 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_9 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_10 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_11 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_12 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_13 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_14 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_15 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_17 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_18 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_19 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_20 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_21 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1392 [] = {
g_atype1392_0,
g_atype1392_1,
g_atype1392_2,
g_atype1392_3,
g_atype1392_4,
g_atype1392_5,
g_atype1392_6,
g_atype1392_7,
g_atype1392_8,
g_atype1392_9,
g_atype1392_10,
g_atype1392_11,
g_atype1392_12,
g_atype1392_13,
g_atype1392_14,
g_atype1392_15,
g_atype1392_16,
g_atype1392_17,
g_atype1392_18,
g_atype1392_19,
g_atype1392_20,
g_atype1392_21,
};

static const long offsets1392 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1393[];
static const uint32 types1393 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1393 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1393_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_1 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_2 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_3 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1393 [] = {
g_atype1393_0,
g_atype1393_1,
g_atype1393_2,
g_atype1393_3,
g_atype1393_4,
};

static const long offsets1393 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1394[];
static const uint32 types1394 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1394 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1394_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_1 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_2 [] = {0xFF01,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_3 [] = {68,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_5 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_6 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_8 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_13 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_14 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_15 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_16 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_17 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_19 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_20 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_21 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_22 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_23 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_24 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_25 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1394 [] = {
g_atype1394_0,
g_atype1394_1,
g_atype1394_2,
g_atype1394_3,
g_atype1394_4,
g_atype1394_5,
g_atype1394_6,
g_atype1394_7,
g_atype1394_8,
g_atype1394_9,
g_atype1394_10,
g_atype1394_11,
g_atype1394_12,
g_atype1394_13,
g_atype1394_14,
g_atype1394_15,
g_atype1394_16,
g_atype1394_17,
g_atype1394_18,
g_atype1394_19,
g_atype1394_20,
g_atype1394_21,
g_atype1394_22,
g_atype1394_23,
g_atype1394_24,
g_atype1394_25,
};

static const long offsets1394 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1395[];
static const uint32 types1395 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1395 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1395_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_1 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_4 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_11 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_12 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_13 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_14 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_19 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_20 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_21 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_22 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_23 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1395 [] = {
g_atype1395_0,
g_atype1395_1,
g_atype1395_2,
g_atype1395_3,
g_atype1395_4,
g_atype1395_5,
g_atype1395_6,
g_atype1395_7,
g_atype1395_8,
g_atype1395_9,
g_atype1395_10,
g_atype1395_11,
g_atype1395_12,
g_atype1395_13,
g_atype1395_14,
g_atype1395_15,
g_atype1395_16,
g_atype1395_17,
g_atype1395_18,
g_atype1395_19,
g_atype1395_20,
g_atype1395_21,
g_atype1395_22,
g_atype1395_23,
};

static const long offsets1395 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1396[];
static const uint32 types1396 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1396 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1396_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_1 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_4 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_11 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_12 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_13 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_14 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_19 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_20 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_21 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_22 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_23 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1396 [] = {
g_atype1396_0,
g_atype1396_1,
g_atype1396_2,
g_atype1396_3,
g_atype1396_4,
g_atype1396_5,
g_atype1396_6,
g_atype1396_7,
g_atype1396_8,
g_atype1396_9,
g_atype1396_10,
g_atype1396_11,
g_atype1396_12,
g_atype1396_13,
g_atype1396_14,
g_atype1396_15,
g_atype1396_16,
g_atype1396_17,
g_atype1396_18,
g_atype1396_19,
g_atype1396_20,
g_atype1396_21,
g_atype1396_22,
g_atype1396_23,
};

static const long offsets1396 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1397[];
static const uint32 types1397 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1397 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1397_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_1 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_4 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_11 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_12 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_13 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_14 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_19 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_20 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_21 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_22 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_23 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1397 [] = {
g_atype1397_0,
g_atype1397_1,
g_atype1397_2,
g_atype1397_3,
g_atype1397_4,
g_atype1397_5,
g_atype1397_6,
g_atype1397_7,
g_atype1397_8,
g_atype1397_9,
g_atype1397_10,
g_atype1397_11,
g_atype1397_12,
g_atype1397_13,
g_atype1397_14,
g_atype1397_15,
g_atype1397_16,
g_atype1397_17,
g_atype1397_18,
g_atype1397_19,
g_atype1397_20,
g_atype1397_21,
g_atype1397_22,
g_atype1397_23,
};

static const long offsets1397 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1398[];
static const uint32 types1398 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1398 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1398_0 [] = {0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_1 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_2 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_4 [] = {136,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_6 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_7 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_11 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_12 [] = {1318,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_13 [] = {1327,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_14 [] = {1315,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_15 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_16 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_17 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_18 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_19 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_20 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_21 [] = {1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_22 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_23 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1398 [] = {
g_atype1398_0,
g_atype1398_1,
g_atype1398_2,
g_atype1398_3,
g_atype1398_4,
g_atype1398_5,
g_atype1398_6,
g_atype1398_7,
g_atype1398_8,
g_atype1398_9,
g_atype1398_10,
g_atype1398_11,
g_atype1398_12,
g_atype1398_13,
g_atype1398_14,
g_atype1398_15,
g_atype1398_16,
g_atype1398_17,
g_atype1398_18,
g_atype1398_19,
g_atype1398_20,
g_atype1398_21,
g_atype1398_22,
g_atype1398_23,
};

static const long offsets1398 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1399[];
static const uint32 types1399 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1399 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1399_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_1 [] = {1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_2 [] = {0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1399 [] = {
g_atype1399_0,
g_atype1399_1,
g_atype1399_2,
};

static const long offsets1399 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1400[];
static const uint32 types1400 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1400 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1400_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_1 [] = {1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_2 [] = {0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1400 [] = {
g_atype1400_0,
g_atype1400_1,
g_atype1400_2,
};

static const long offsets1400 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1401[];
static const uint32 types1401 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1401 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1401_0 [] = {0xFF01,1170,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_1 [] = {1398,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_2 [] = {0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1401 [] = {
g_atype1401_0,
g_atype1401_1,
g_atype1401_2,
};

static const long offsets1401 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1407[];
static const uint32 types1407 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1407 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1407_0 [] = {0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_1 [] = {0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_2 [] = {0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_3 [] = {0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_4 [] = {208,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_5 [] = {208,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_6 [] = {0xFF01,970,0xFF01,0xFFF9,2,1113,1353,1353,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_7 [] = {0xFF01,970,0xFF01,970,0xFF01,51,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_8 [] = {1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1407 [] = {
g_atype1407_0,
g_atype1407_1,
g_atype1407_2,
g_atype1407_3,
g_atype1407_4,
g_atype1407_5,
g_atype1407_6,
g_atype1407_7,
g_atype1407_8,
};

static const long offsets1407 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
};

extern const char *names1408[];
static const uint32 types1408 [] =
{
SK_REF,
};

static const uint16 attr_flags1408 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1408_0 [] = {0xFF01,1170,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1408 [] = {
g_atype1408_0,
};

static const long offsets1408 [] =
{
0,
};

extern const char *names1409[];
static const uint32 types1409 [] =
{
SK_REF,
};

static const uint16 attr_flags1409 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1409_0 [] = {0xFF01,129,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1409 [] = {
g_atype1409_0,
};

static const long offsets1409 [] =
{
0,
};

extern const char *names1410[];
static const uint32 types1410 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1410 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1410_0 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_3 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1410 [] = {
g_atype1410_0,
g_atype1410_1,
g_atype1410_2,
g_atype1410_3,
};

static const long offsets1410 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1411[];
static const uint32 types1411 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1411 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1411_0 [] = {546,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_3 [] = {1160,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1411 [] = {
g_atype1411_0,
g_atype1411_1,
g_atype1411_2,
g_atype1411_3,
};

static const long offsets1411 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1412[];
static const uint32 types1412 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1412 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1412_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_1 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_2 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_3 [] = {1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_12 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1412 [] = {
g_atype1412_0,
g_atype1412_1,
g_atype1412_2,
g_atype1412_3,
g_atype1412_4,
g_atype1412_5,
g_atype1412_6,
g_atype1412_7,
g_atype1412_8,
g_atype1412_9,
g_atype1412_10,
g_atype1412_11,
g_atype1412_12,
};

static const long offsets1412 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @CHROFF(1,6),
+ @CHROFF(1,7),
+ @LNGOFF(1,8,0,0),
+ @LNGOFF(1,8,0,1),
+ @LNGOFF(1,8,0,2),
+ @LNGOFF(1,8,0,3),
};

extern const char *names1413[];
static const uint32 types1413 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1413 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1413_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_1 [] = {0xFF01,1053,0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_2 [] = {1301,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_3 [] = {0xFF01,1302,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_4 [] = {0xFF01,1302,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_5 [] = {0xFF01,1303,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_6 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_7 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_8 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_13 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1413 [] = {
g_atype1413_0,
g_atype1413_1,
g_atype1413_2,
g_atype1413_3,
g_atype1413_4,
g_atype1413_5,
g_atype1413_6,
g_atype1413_7,
g_atype1413_8,
g_atype1413_9,
g_atype1413_10,
g_atype1413_11,
g_atype1413_12,
g_atype1413_13,
};

static const long offsets1413 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
+ @LNGOFF(9,2,0,2),
};

extern const char *names1414[];
static const uint32 types1414 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1414 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1414_0 [] = {1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_1 [] = {1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_2 [] = {1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_3 [] = {1053,0xFF01,0xFFF9,2,1113,0xFF01,1189,1058,0xFF01,0xFFF9,2,1113,0xFF01,1255,0xFF01,1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_10 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1414 [] = {
g_atype1414_0,
g_atype1414_1,
g_atype1414_2,
g_atype1414_3,
g_atype1414_4,
g_atype1414_5,
g_atype1414_6,
g_atype1414_7,
g_atype1414_8,
g_atype1414_9,
g_atype1414_10,
};

static const long offsets1414 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1420[];
static const uint32 types1420 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1420 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1420_0 [] = {0xFF01,25,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_1 [] = {0xFF01,24,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_2 [] = {0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_3 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_5 [] = {0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_6 [] = {21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_10 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_20 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_21 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_22 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_23 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_24 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_25 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_26 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_27 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_28 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_29 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_30 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1420 [] = {
g_atype1420_0,
g_atype1420_1,
g_atype1420_2,
g_atype1420_3,
g_atype1420_4,
g_atype1420_5,
g_atype1420_6,
g_atype1420_7,
g_atype1420_8,
g_atype1420_9,
g_atype1420_10,
g_atype1420_11,
g_atype1420_12,
g_atype1420_13,
g_atype1420_14,
g_atype1420_15,
g_atype1420_16,
g_atype1420_17,
g_atype1420_18,
g_atype1420_19,
g_atype1420_20,
g_atype1420_21,
g_atype1420_22,
g_atype1420_23,
g_atype1420_24,
g_atype1420_25,
g_atype1420_26,
g_atype1420_27,
g_atype1420_28,
g_atype1420_29,
g_atype1420_30,
};

static const long offsets1420 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @CHROFF(7,12),
+ @LNGOFF(7,13,0,0),
+ @LNGOFF(7,13,0,1),
+ @LNGOFF(7,13,0,2),
+ @LNGOFF(7,13,0,3),
+ @LNGOFF(7,13,0,4),
+ @LNGOFF(7,13,0,5),
+ @LNGOFF(7,13,0,6),
+ @LNGOFF(7,13,0,7),
+ @LNGOFF(7,13,0,8),
+ @LNGOFF(7,13,0,9),
+ @LNGOFF(7,13,0,10),
};

extern const char *names1421[];
static const uint32 types1421 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1421 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1421_0 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_1 [] = {0xFF01,25,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_2 [] = {0xFF01,24,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_3 [] = {0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_4 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_5 [] = {0xFF01,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_6 [] = {0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_7 [] = {21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_8 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_9 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_10 [] = {0xFF01,1233,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_11 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_12 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_14 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_15 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_16 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_17 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_18 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_19 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_20 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_21 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_22 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_23 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_24 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_25 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_26 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_27 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_28 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_29 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_30 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_31 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_32 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_33 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_34 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_35 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_36 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_37 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_38 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_39 [] = {1324,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_40 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_41 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_42 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_43 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_44 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_45 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_46 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_47 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_48 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_49 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_50 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_51 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1421 [] = {
g_atype1421_0,
g_atype1421_1,
g_atype1421_2,
g_atype1421_3,
g_atype1421_4,
g_atype1421_5,
g_atype1421_6,
g_atype1421_7,
g_atype1421_8,
g_atype1421_9,
g_atype1421_10,
g_atype1421_11,
g_atype1421_12,
g_atype1421_13,
g_atype1421_14,
g_atype1421_15,
g_atype1421_16,
g_atype1421_17,
g_atype1421_18,
g_atype1421_19,
g_atype1421_20,
g_atype1421_21,
g_atype1421_22,
g_atype1421_23,
g_atype1421_24,
g_atype1421_25,
g_atype1421_26,
g_atype1421_27,
g_atype1421_28,
g_atype1421_29,
g_atype1421_30,
g_atype1421_31,
g_atype1421_32,
g_atype1421_33,
g_atype1421_34,
g_atype1421_35,
g_atype1421_36,
g_atype1421_37,
g_atype1421_38,
g_atype1421_39,
g_atype1421_40,
g_atype1421_41,
g_atype1421_42,
g_atype1421_43,
g_atype1421_44,
g_atype1421_45,
g_atype1421_46,
g_atype1421_47,
g_atype1421_48,
g_atype1421_49,
g_atype1421_50,
g_atype1421_51,
};

static const long offsets1421 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @CHROFF(11,12),
+ @CHROFF(11,13),
+ @CHROFF(11,14),
+ @CHROFF(11,15),
+ @LNGOFF(11,16,0,0),
+ @LNGOFF(11,16,0,1),
+ @LNGOFF(11,16,0,2),
+ @LNGOFF(11,16,0,3),
+ @LNGOFF(11,16,0,4),
+ @LNGOFF(11,16,0,5),
+ @LNGOFF(11,16,0,6),
+ @LNGOFF(11,16,0,7),
+ @LNGOFF(11,16,0,8),
+ @LNGOFF(11,16,0,9),
+ @LNGOFF(11,16,0,10),
+ @LNGOFF(11,16,0,11),
+ @LNGOFF(11,16,0,12),
+ @LNGOFF(11,16,0,13),
+ @LNGOFF(11,16,0,14),
+ @LNGOFF(11,16,0,15),
+ @LNGOFF(11,16,0,16),
+ @LNGOFF(11,16,0,17),
+ @LNGOFF(11,16,0,18),
+ @LNGOFF(11,16,0,19),
+ @LNGOFF(11,16,0,20),
+ @LNGOFF(11,16,0,21),
+ @LNGOFF(11,16,0,22),
+ @LNGOFF(11,16,0,23),
+ @LNGOFF(11,16,0,24),
};

extern const char *names1422[];
static const uint32 types1422 [] =
{
SK_INT32,
};

static const uint16 attr_flags1422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1422_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1422 [] = {
g_atype1422_0,
};

static const long offsets1422 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1423[];
static const uint32 types1423 [] =
{
SK_INT32,
};

static const uint16 attr_flags1423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1423_0 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1423 [] = {
g_atype1423_0,
};

static const long offsets1423 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1424[];
static const uint32 types1424 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1424 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1424_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_1 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1424 [] = {
g_atype1424_0,
g_atype1424_1,
};

static const long offsets1424 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1425[];
static const uint32 types1425 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1425 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1425_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1425_1 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1425 [] = {
g_atype1425_0,
g_atype1425_1,
};

static const long offsets1425 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1426[];
static const uint32 types1426 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1426 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1426_0 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1426_1 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1426_2 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1426 [] = {
g_atype1426_0,
g_atype1426_1,
g_atype1426_2,
};

static const long offsets1426 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names1427[];
static const uint32 types1427 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags1427 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1427_0 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_1 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_2 [] = {0xFF01,962,0xFF01,1179,1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_3 [] = {988,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_4 [] = {988,0xFF01,1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_7 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_8 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_9 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_10 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_11 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_12 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_13 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_14 [] = {1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_15 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1427 [] = {
g_atype1427_0,
g_atype1427_1,
g_atype1427_2,
g_atype1427_3,
g_atype1427_4,
g_atype1427_5,
g_atype1427_6,
g_atype1427_7,
g_atype1427_8,
g_atype1427_9,
g_atype1427_10,
g_atype1427_11,
g_atype1427_12,
g_atype1427_13,
g_atype1427_14,
g_atype1427_15,
};

static const long offsets1427 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
+ @R64OFF(5,1,0,8,0,0,0,0),
+ @R64OFF(5,1,0,8,0,0,0,1),
};

extern const char *names1428[];
static const uint32 types1428 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1428 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1428_0 [] = {0xFF01,1424,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_1 [] = {0xFF01,1422,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_4 [] = {1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1428 [] = {
g_atype1428_0,
g_atype1428_1,
g_atype1428_2,
g_atype1428_3,
g_atype1428_4,
};

static const long offsets1428 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1429[];
static const uint32 types1429 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1429 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1429_0 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_1 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_2 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_3 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_4 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_5 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1429 [] = {
g_atype1429_0,
g_atype1429_1,
g_atype1429_2,
g_atype1429_3,
g_atype1429_4,
g_atype1429_5,
g_atype1429_6,
g_atype1429_7,
g_atype1429_8,
};

static const long offsets1429 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1430[];
static const uint32 types1430 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1430 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1430_0 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_1 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_2 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_3 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_4 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_5 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_6 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_8 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1430 [] = {
g_atype1430_0,
g_atype1430_1,
g_atype1430_2,
g_atype1430_3,
g_atype1430_4,
g_atype1430_5,
g_atype1430_6,
g_atype1430_7,
g_atype1430_8,
};

static const long offsets1430 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1431[];
static const uint32 types1431 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1431 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1431_0 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_1 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_2 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_3 [] = {0xFF01,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_4 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_5 [] = {1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_6 [] = {0xFF01,1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_7 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_8 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_9 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1431_10 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1431 [] = {
g_atype1431_0,
g_atype1431_1,
g_atype1431_2,
g_atype1431_3,
g_atype1431_4,
g_atype1431_5,
g_atype1431_6,
g_atype1431_7,
g_atype1431_8,
g_atype1431_9,
g_atype1431_10,
};

static const long offsets1431 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
};

extern const char *names1432[];
static const uint32 types1432 [] =
{
SK_REF,
};

static const uint16 attr_flags1432 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1432_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1432 [] = {
g_atype1432_0,
};

static const long offsets1432 [] =
{
0,
};

extern const char *names1433[];
static const uint32 types1433 [] =
{
SK_REF,
};

static const uint16 attr_flags1433 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1433_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1433 [] = {
g_atype1433_0,
};

static const long offsets1433 [] =
{
0,
};

extern const char *names1434[];
static const uint32 types1434 [] =
{
SK_REF,
};

static const uint16 attr_flags1434 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1434_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1434 [] = {
g_atype1434_0,
};

static const long offsets1434 [] =
{
0,
};

extern const char *names1435[];
static const uint32 types1435 [] =
{
SK_REF,
};

static const uint16 attr_flags1435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1435_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1435 [] = {
g_atype1435_0,
};

static const long offsets1435 [] =
{
0,
};

extern const char *names1436[];
static const uint32 types1436 [] =
{
SK_REF,
};

static const uint16 attr_flags1436 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1436_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1436 [] = {
g_atype1436_0,
};

static const long offsets1436 [] =
{
0,
};

extern const char *names1437[];
static const uint32 types1437 [] =
{
SK_REF,
};

static const uint16 attr_flags1437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1437_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1437 [] = {
g_atype1437_0,
};

static const long offsets1437 [] =
{
0,
};

extern const char *names1438[];
static const uint32 types1438 [] =
{
SK_REF,
};

static const uint16 attr_flags1438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1438_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1438 [] = {
g_atype1438_0,
};

static const long offsets1438 [] =
{
0,
};

extern const char *names1439[];
static const uint32 types1439 [] =
{
SK_REF,
};

static const uint16 attr_flags1439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1439_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1439 [] = {
g_atype1439_0,
};

static const long offsets1439 [] =
{
0,
};

extern const char *names1440[];
static const uint32 types1440 [] =
{
SK_REF,
};

static const uint16 attr_flags1440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1440_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1440 [] = {
g_atype1440_0,
};

static const long offsets1440 [] =
{
0,
};

extern const char *names1441[];
static const uint32 types1441 [] =
{
SK_REF,
};

static const uint16 attr_flags1441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1441_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1441 [] = {
g_atype1441_0,
};

static const long offsets1441 [] =
{
0,
};

extern const char *names1442[];
static const uint32 types1442 [] =
{
SK_REF,
};

static const uint16 attr_flags1442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1442_0 [] = {0xFF01,299,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1442 [] = {
g_atype1442_0,
};

static const long offsets1442 [] =
{
0,
};

extern const char *names1443[];
static const uint32 types1443 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1443 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1443_0 [] = {0xFF01,299,0xFFFF};
static const EIF_TYPE_INDEX g_atype1443_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1443_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1443_3 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1443 [] = {
g_atype1443_0,
g_atype1443_1,
g_atype1443_2,
g_atype1443_3,
};

static const long offsets1443 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1444[];
static const uint32 types1444 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1444 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1444_0 [] = {0xFF01,299,0xFFFF};
static const EIF_TYPE_INDEX g_atype1444_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1444_2 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1444_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1444_4 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1444 [] = {
g_atype1444_0,
g_atype1444_1,
g_atype1444_2,
g_atype1444_3,
g_atype1444_4,
};

static const long offsets1444 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
};

extern const char *names1445[];
static const uint32 types1445 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1445 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1445_0 [] = {0xFF01,299,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_1 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_2 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1445_6 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1445 [] = {
g_atype1445_0,
g_atype1445_1,
g_atype1445_2,
g_atype1445_3,
g_atype1445_4,
g_atype1445_5,
g_atype1445_6,
};

static const long offsets1445 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
};

extern const char *names1446[];
static const uint32 types1446 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1446 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1446_0 [] = {0xFF01,299,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_1 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_2 [] = {1058,0xFF01,1167,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_3 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_5 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1446_6 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1446 [] = {
g_atype1446_0,
g_atype1446_1,
g_atype1446_2,
g_atype1446_3,
g_atype1446_4,
g_atype1446_5,
g_atype1446_6,
};

static const long offsets1446 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
};

extern const char *names1448[];
static const uint32 types1448 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1448 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1448_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1448_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1448_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1448 [] = {
g_atype1448_0,
g_atype1448_1,
g_atype1448_2,
};

static const long offsets1448 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1449[];
static const uint32 types1449 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1449 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1449_0 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1449_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1449_2 [] = {1127,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1449 [] = {
g_atype1449_0,
g_atype1449_1,
g_atype1449_2,
};

static const long offsets1449 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1451[];
static const uint32 types1451 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1451 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1451_0 [] = {0xFF01,988,1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1451_1 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1451_2 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1451_3 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1451_4 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1451_5 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1451 [] = {
g_atype1451_0,
g_atype1451_1,
g_atype1451_2,
g_atype1451_3,
g_atype1451_4,
g_atype1451_5,
};

static const long offsets1451 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1452[];
static const uint32 types1452 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1452 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1452_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1452_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1452 [] = {
g_atype1452_0,
g_atype1452_1,
g_atype1452_2,
g_atype1452_3,
g_atype1452_4,
g_atype1452_5,
g_atype1452_6,
g_atype1452_7,
};

static const long offsets1452 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1453[];
static const uint32 types1453 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1453 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1453_0 [] = {0xFF01,1234,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_1 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_2 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_3 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_4 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_5 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_6 [] = {1312,0xFFFF};
static const EIF_TYPE_INDEX g_atype1453_7 [] = {1312,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1453 [] = {
g_atype1453_0,
g_atype1453_1,
g_atype1453_2,
g_atype1453_3,
g_atype1453_4,
g_atype1453_5,
g_atype1453_6,
g_atype1453_7,
};

static const long offsets1453 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_FILE_SCOPE_INFORMATION",
	names10,
	types10,
	attr_flags10,
	gtypes10,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets10,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PACKET",
	names11,
	types11,
	attr_flags11,
	gtypes11,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets11,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_STRING_FORMATTER",
	names14,
	types14,
	attr_flags14,
	gtypes14,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets14,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CURRENCY_FORMATTER",
	names15,
	types15,
	attr_flags15,
	gtypes15,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets15,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DATE_FORMATTER",
	names16,
	types16,
	attr_flags16,
	gtypes16,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets16,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_GLOBAL_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_MIME_TYPES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PCRE_CHARACTER_SET",
	names22,
	types22,
	attr_flags22,
	gtypes22,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets22,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CASE_MAPPING",
	names25,
	types25,
	attr_flags25,
	gtypes25,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets25,
	NULL
},
{
	(long) 6,
	(long) 6,
	"PCRE_BYTE_CODE",
	names26,
	types26,
	attr_flags26,
	gtypes26,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets26,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_IRON_INSTALLATION_API_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_INFO_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_OPT_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_FORM_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_INFO_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ARGUMENT_OPTION",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASCII",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_LOCATION_MAPPER_ACTION",
	names38,
	types38,
	attr_flags38,
	gtypes38,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets38,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names40,
	types40,
	attr_flags40,
	gtypes40,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets40,
	NULL
},
{
	(long) 3,
	(long) 3,
	"NET_HTTP_CLIENT_CONNECTION",
	names41,
	types41,
	attr_flags41,
	gtypes41,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets41,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_STATUS_CODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_HEADER_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_GROUP",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_INFO_FILE_PARSER",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names47,
	types47,
	attr_flags47,
	gtypes47,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets47,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOCATION_MAPPER",
	names48,
	types48,
	attr_flags48,
	gtypes48,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets48,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_ERROR_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR_OBSERVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_NAMESPACE_RESOLVER_CONTEXT",
	names51,
	types51,
	attr_flags51,
	gtypes51,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets51,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_CONDITION_CUSTOM_ATTRIBUTES",
	names52,
	types52,
	attr_flags52,
	gtypes52,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets52,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_PACKAGE_INSTALLATION_INFO",
	names53,
	types53,
	attr_flags53,
	gtypes53,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets53,
	NULL
},
{
	(long) 0,
	(long) 0,
	"URI_PERCENT_ENCODER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HTTP_CLIENT_SECURE_CONFIG",
	names55,
	types55,
	attr_flags55,
	gtypes55,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets55,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COMPILER_PROFILE",
	names56,
	types56,
	attr_flags56,
	gtypes56,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets56,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_ARCHIVE",
	names59,
	types59,
	attr_flags59,
	gtypes59,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets59,
	NULL
},
{
	(long) 8,
	(long) 8,
	"IRON_SHARE_TASK_DATA",
	names60,
	types60,
	attr_flags60,
	gtypes60,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets60,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ASSERTIONS",
	names61,
	types61,
	attr_flags61,
	gtypes61,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets61,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ROOT",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UUID_GENERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOAD_CONTEXT",
	names64,
	types64,
	attr_flags64,
	gtypes64,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets64,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSER_CONTROLLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_CLIENT_DB",
	names68,
	types68,
	attr_flags68,
	gtypes68,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets68,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names69,
	types69,
	attr_flags69,
	gtypes69,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets69,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HTTP_CLIENT_REQUEST_CONTEXT",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 10,
	(long) 10,
	"HTTP_CLIENT_RESPONSE",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PRODUCT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_FILE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_REPOSITORY_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_API_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_URL_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PUNYCODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names84,
	types84,
	attr_flags84,
	gtypes84,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets84,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IMPORTED_UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DYNAMIC_API_LOADER_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DYNAMIC_API_LOADER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_FILE_HANDLER",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_MO_HANDLER",
	names108,
	types108,
	attr_flags108,
	gtypes108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets108,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_DYNAMIC_API_LOADER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SOCKET_ADDRESS",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_LANGUAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SOCKET_TIMEOUT_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_LOCALE_CONV",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_UNIX_C_FUNCTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_POSIX_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CODE_PAGE_INFO",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 13,
	(long) 13,
	"I18N_DATE_TIME_INFO",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_NUMERIC_INFO",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 16,
	(long) 16,
	"I18N_CURRENCY_INFO",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 40,
	(long) 40,
	"I18N_LOCALE_INFO",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DEBUGGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GROUP_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MATCHER",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 7,
	(long) 7,
	"KMP_MATCHER",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 13,
	(long) 13,
	"KMP_WILD",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_HOST_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATASOURCE_MANAGER",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_FILE_MANAGER",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_VALUE_FORMATTER",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_CURRENCY_VALUE_FORMATTER",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BOM_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ADDRINFO",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IDENTIFIED_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"FORMAT_INTEGER",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_REDIRECTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_REDIRECTION_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_EXTERNALS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURL_EASY_EXTERNALS_I",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TRANSFER_COMMAND_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_VALUE_VALIDATOR",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_DEFAULT_VALIDATOR",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SORTER",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUICK_SORTER",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PATTERN_MATCHER",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOCATION_MAPPING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION_IRON_MAPPING",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_VALUE",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PROCESS_TIMER",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_PROCESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_READER",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_SECURE_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PERCENT_ENCODER",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_ITERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_PACKAGE_FILE_SCANNER",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_CLIB_SCANNER",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_ECF_SCANNER",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_XMLNS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_MARKUP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CLASSNAME_FINDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_CLIENT_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_CATALOG",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_COMPILER_PROFILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"URI_PERCENT_ENCODER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names210,
	types210,
	attr_flags210,
	gtypes210,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets210,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names211,
	types211,
	attr_flags211,
	gtypes211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets211,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_DICTIONARY_ID_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"I18N_FILE",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 15,
	(long) 15,
	"I18N_MO_FILE",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DICTIONARY",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 5,
	(long) 5,
	"I18N_BINARY_SEARCH_ARRAY_DICTIONARY",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DUMMY_DICTIONARY",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_SIGNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_UNIX_OS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_PIPE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HOST_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PROXY_INFORMATION",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALUE",
	names229,
	types229,
	attr_flags229,
	gtypes229,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets229,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DATE_TIME_VALUE",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"THREAD_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"THREAD_CONTROL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"THREAD",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PROCESS_IO_LISTENER_THREAD",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INET_PROPERTIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INET_ADDRESS_IMPL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INET_ADDRESS_IMPL_V4",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INET_ADDRESS_IMPL_V6",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INET_ADDRESS",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 6,
	(long) 6,
	"INET6_ADDRESS",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INET4_ADDRESS",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_DYNAMIC_EXTERNALS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURL_EASY_EXTERNALS",
	names254,
	types254,
	attr_flags254,
	gtypes254,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets254,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REVERSE_PART_COMPARATOR",
	names256,
	types256,
	attr_flags256,
	gtypes256,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets256,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYNTAX_STRINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CLASS_TYPE_NAME_SYNTAX_CHECKER",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_SYNTAX_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_GENERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BASE64",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_EQUALITY_TESTER",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_COMPARATOR",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOAD_PARSE_CALLBACKS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_DATE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"MESSAGE_DIGEST",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 8,
	(long) 8,
	"MD5",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 14,
	(long) 14,
	"SHA1",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_TARGET_REFERENCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_LOCAL_TARGET_REFERENCE",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_REMOTE_TARGET_REFERENCE",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CONF_SETTING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_FILE",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_PACKAGE_INI_FILE",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 7,
	(long) 7,
	"IRON_PACKAGE_INFO_FILE",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_TERMINAL_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARGUMENT_STRING_SOURCE",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IL_ENVIRONMENT",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEM_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 3,
	(long) 3,
	"MEMORY_STRUCTURE",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SOCKET_RESOURCES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INET_ADDRESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NETWORK_SOCKET_ADDRESS",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_BASE_PARSER",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_MULTI_PARSER",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_SINGLE_PARSER",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_ARGUMENT_PARSER_I",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_ARGUMENT_BASE_PARSER",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_ARGUMENT_SINGLE_PARSER",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_ARGUMENT_MULTI_PARSER",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS_NULL",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_FORWARD_CALLBACKS",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"XML_STANDARD_PARSER",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 15,
	(long) 15,
	"XML_STOPPABLE_PARSER",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CALLBACKS_FILTER",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_END_TAG_CHECKER",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 9,
	(long) 9,
	"XML_NAMESPACE_RESOLVER",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"XML_STRING_32_INPUT_STREAM",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CHARACTER_8_INPUT_STREAM_FILTER",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CHARACTER_8_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NOTABLE",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LIBCURL_HTTP_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NET_HTTP_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEFAULT_HTTP_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 8,
	(long) 8,
	"DYNAMIC_API_UNAVAILABLE_EXCEPTION",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_EXCEPTION",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATE_ELEMENT",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_TIME_ELEMENT",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_USERSTRING_ELEMENT",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VISITABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERVAL",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DATE_DURATION",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TIME_DURATION",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_DURATION",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_DICTIONARY_ENTRY",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSOLUTE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"URL_ENCODER",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"X_WWW_FORM_URL_ENCODER",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NAMESPACE_TESTER",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_LOAD_CALLBACKS",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD_UUID_CALLBACKS",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VALIDITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_STATE",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_TARGET_SETTINGS",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_CONDITIONED",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ACTION",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_FILE_RULE",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_MAKE",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LINKER_FLAG",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_RESOURCE",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LIBRARY",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_OBJECT",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_CFLAG",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_INCLUDE",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"HTTP_CLIENT_REQUEST",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 5,
	(long) 5,
	"LIBCURL_HTTP_CLIENT_REQUEST",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_LAYOUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_OUTPUT_LISTENER_THREAD",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_ERROR_LISTENER_THREAD",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_INPUT_LISTENER_THREAD",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PROCESS_THREAD_TIMER",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ACCESS",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO_IMP",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_SET",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_EXPORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_REPOSITORY_CONFIGURATION_FILE",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TO_IRON_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_SHARE_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_SHARE_ARGUMENT_PARSER",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_REPOSITORY_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_REPOSITORY_ARGUMENT_PARSER",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_REMOVE_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_REMOVE_ARGUMENT_PARSER",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PATH_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_PATH_ARGUMENT_PARSER",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_LIST_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_LIST_ARGUMENT_PARSER",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_UPDATE_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_UPDATE_ARGUMENT_PARSER",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_INSTALL_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_INSTALL_ARGUMENT_PARSER",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_SEARCH_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_INFO_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_SEARCH_ARGUMENT_PARSER",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 17,
	(long) 17,
	"IRON_INFO_ARGUMENT_PARSER",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALUE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"MUTEX",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURL_FORM",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_API_BASE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_API",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DYNAMIC_MODULE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PROCESS_UNIX_PIPE",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEMORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 29,
	(long) 29,
	"PROCESS_UNIX_PROCESS_MANAGER",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXTERNAL_OBJECT",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ADDRINFO_1",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ADDRINFO_2",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURL_DEFAULT_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LIBCURL_DEFAULT_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LIBCURL_CUSTOM_FUNCTION",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IDENTIFIED",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 20,
	(long) 20,
	"UNIX_UNNAMED_PIPE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 26,
	(long) 26,
	"SOCKET",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 27,
	(long) 27,
	"STREAM_SOCKET",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 36,
	(long) 36,
	"NETWORK_SOCKET",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 39,
	(long) 39,
	"NETWORK_STREAM_SOCKET",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 40,
	(long) 40,
	"HTTP_STREAM_SOCKET",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 40,
	(long) 40,
	"HTTP_STREAM_SECURE_SOCKET",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_PARENTS",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_MULOVER",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL01",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL02",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL03",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_REDIRECTION",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_MESSAGE_IN_REDIRECTION",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ERROR_UUID_MISMATCH_IN_REDIRECTION",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_FILE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_PARSE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_GRUNDEF",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_VERSION",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBOVER",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBTAR",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_OVERRIDE",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_ERROR_REGEXP",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_UUID",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ACCESS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_PARENT_TARGET_CHECKER",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_LOAD_PARSE_CALLBACKS",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_OPTION",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 36,
	(long) 36,
	"CONF_TARGET_OPTION",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISIBLE",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HTTP_HEADER_MODIFIER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HTTP_CLIENT_REQUEST_PARAMETERS",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HTTP_CLIENT_REQUEST_FORM_PARAMETERS",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HTTP_CLIENT_REQUEST_QUERY_PARAMETERS",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_REPOSITORY",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SUBSET",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE_SUBSET",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR_SUBSET",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RANDOM",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names937,
	types937,
	attr_flags937,
	gtypes937,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets937,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets938,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_FILE",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names989,
	types989,
	attr_flags989,
	gtypes989,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets989,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names990,
	types990,
	attr_flags990,
	gtypes990,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets990,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names991,
	types991,
	attr_flags991,
	gtypes991,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets991,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names992,
	types992,
	attr_flags992,
	gtypes992,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets992,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names993,
	types993,
	attr_flags993,
	gtypes993,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets993,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names994,
	types994,
	attr_flags994,
	gtypes994,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets994,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names995,
	types995,
	attr_flags995,
	gtypes995,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets995,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names996,
	types996,
	attr_flags996,
	gtypes996,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets996,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names997,
	types997,
	attr_flags997,
	gtypes997,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets997,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names999,
	types999,
	attr_flags999,
	gtypes999,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets999,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names1000,
	types1000,
	attr_flags1000,
	gtypes1000,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1000,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1001,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names1002,
	types1002,
	attr_flags1002,
	gtypes1002,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1002,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1003,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1006,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1007,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1008,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1011,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1013,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1015,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1020,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1021,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1022,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1023,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1024,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1030,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1032,
	types1032,
	attr_flags1032,
	gtypes1032,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1032,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1033,
	types1033,
	attr_flags1033,
	gtypes1033,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1033,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1039,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_SET",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1068,
	types1068,
	attr_flags1068,
	gtypes1068,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1068,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_CONDITION_LIST",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_SET",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_NOTE_ELEMENT",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HTTP_HEADER",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1090,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1091,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"NET_HTTP_CLIENT_REQUEST",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1096,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_REMOTE_NODE",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1098,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_FS_CATALOG",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1099,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_ENVIRONMENT_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ARGUMENTS",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ES_ARGUMENTS",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_LAYOUT",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ES_IRON_LAYOUT",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 32,
	(long) 32,
	"BASE_PROCESS",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 34,
	(long) 34,
	"BASE_PROCESS_IMP",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 36,
	(long) 36,
	"PROCESS",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 48,
	(long) 48,
	"PROCESS_IMP",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_API",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_CATALOG_API",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_INSTALLATION_API",
	names1111,
	types1111,
	attr_flags1111,
	gtypes1111,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1111,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"URL",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 7,
	(long) 7,
	"NETWORK_RESOURCE_URL",
	names1116,
	types1116,
	attr_flags1116,
	gtypes1116,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1116,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HTTP_URL",
	names1117,
	types1117,
	attr_flags1117,
	gtypes1117,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1117,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ARGUMENT_SWITCH",
	names1118,
	types1118,
	attr_flags1118,
	gtypes1118,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1118,
	NULL
},
{
	(long) 11,
	(long) 11,
	"ARGUMENT_VALUE_SWITCH",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1141,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1142,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1143,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1144,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1155,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1162,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CURL_STRING",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1177,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DATE_TIME_CODE",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 4,
	(long) 4,
	"HTTP_AUTHORIZATION",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 13,
	(long) 13,
	"XML_FILE_INPUT_STREAM",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1182,
	NULL
},
{
	(long) 8,
	(long) 8,
	"XML_STRING_INPUT_STREAM",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 4,
	(long) 4,
	"HTTP_DATE",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ORDERED_CAPABILITY",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_VALUE_CHOICE",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UUID",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_POSITION",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 19,
	(long) 19,
	"CONF_CLASS",
	names1189,
	types1189,
	attr_flags1189,
	gtypes1189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1189,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names1190,
	types1190,
	attr_flags1190,
	gtypes1190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1190,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_WORKING_COPY_REPOSITORY",
	names1191,
	types1191,
	attr_flags1191,
	gtypes1191,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1191,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_TARGET",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 12,
	(long) 12,
	"IRON_PACKAGE",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_WEB_REPOSITORY",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1196,
	types1196,
	attr_flags1196,
	gtypes1196,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1196,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1197,
	types1197,
	attr_flags1197,
	gtypes1197,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1197,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1202,
	types1202,
	attr_flags1202,
	gtypes1202,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1202,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1203,
	types1203,
	attr_flags1203,
	gtypes1203,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1203,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1204,
	types1204,
	attr_flags1204,
	gtypes1204,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1204,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1205,
	types1205,
	attr_flags1205,
	gtypes1205,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1205,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1206,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1207,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1208,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1209,
	types1209,
	attr_flags1209,
	gtypes1209,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1209,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1210,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1211,
	types1211,
	attr_flags1211,
	gtypes1211,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1211,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1214,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1216,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1217,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1218,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1219,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1220,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1221,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"HTTP_CLIENT_REQUEST_PARAMETER",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 4,
	(long) 4,
	"HTTP_CLIENT_REQUEST_FILE_PARAMETER",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 3,
	(long) 3,
	"HTTP_CLIENT_REQUEST_STRING_PARAMETER",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_GROUP",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_PHYSICAL_GROUP",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_PHYSICAL_ASSEMBLY_INTERFACE",
	names1248,
	types1248,
	attr_flags1248,
	gtypes1248,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1248,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_CLUSTER",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1249,
	NULL
},
{
	(long) 35,
	(long) 35,
	"CONF_OVERRIDE",
	names1250,
	types1250,
	attr_flags1250,
	gtypes1250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1250,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_TEST_CLUSTER",
	names1251,
	types1251,
	attr_flags1251,
	gtypes1251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1251,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_VIRTUAL_GROUP",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 28,
	(long) 28,
	"CONF_ASSEMBLY",
	names1253,
	types1253,
	attr_flags1253,
	gtypes1253,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1253,
	NULL
},
{
	(long) 26,
	(long) 26,
	"CONF_LIBRARY",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 27,
	(long) 27,
	"CONF_PRECOMPILE",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names1256,
	types1256,
	attr_flags1256,
	gtypes1256,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1256,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1257,
	types1257,
	attr_flags1257,
	gtypes1257,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1257,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1258,
	types1258,
	attr_flags1258,
	gtypes1258,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1258,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1259,
	types1259,
	attr_flags1259,
	gtypes1259,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1259,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1261,
	types1261,
	attr_flags1261,
	gtypes1261,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1261,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1263,
	types1263,
	attr_flags1263,
	gtypes1263,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1263,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1264,
	types1264,
	attr_flags1264,
	gtypes1264,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1264,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1265,
	types1265,
	attr_flags1265,
	gtypes1265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1265,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1266,
	types1266,
	attr_flags1266,
	gtypes1266,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1266,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1267,
	types1267,
	attr_flags1267,
	gtypes1267,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1267,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1268,
	types1268,
	attr_flags1268,
	gtypes1268,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1268,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1269,
	types1269,
	attr_flags1269,
	gtypes1269,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1269,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1270,
	types1270,
	attr_flags1270,
	gtypes1270,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1270,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1271,
	types1271,
	attr_flags1271,
	gtypes1271,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1271,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1272,
	types1272,
	attr_flags1272,
	gtypes1272,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1272,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1273,
	types1273,
	attr_flags1273,
	gtypes1273,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1273,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1274,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1275,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1276,
	types1276,
	attr_flags1276,
	gtypes1276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1276,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1277,
	types1277,
	attr_flags1277,
	gtypes1277,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1277,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1278,
	types1278,
	attr_flags1278,
	gtypes1278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1278,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1279,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1280,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1281,
	types1281,
	attr_flags1281,
	gtypes1281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1281,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1282,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1283,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1284,
	types1284,
	attr_flags1284,
	gtypes1284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1284,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1285,
	types1285,
	attr_flags1285,
	gtypes1285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1285,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1286,
	types1286,
	attr_flags1286,
	gtypes1286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1286,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1287,
	types1287,
	attr_flags1287,
	gtypes1287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1287,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1288,
	types1288,
	attr_flags1288,
	gtypes1288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1288,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1289,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1290,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1291,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1292,
	types1292,
	attr_flags1292,
	gtypes1292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1292,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1296,
	types1296,
	attr_flags1296,
	gtypes1296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1296,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1298,
	types1298,
	attr_flags1298,
	gtypes1298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1298,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1299,
	types1299,
	attr_flags1299,
	gtypes1299,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1299,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_BOOLEAN",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_NUMBER",
	names1305,
	types1305,
	attr_flags1305,
	gtypes1305,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1305,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_STRING",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names1308,
	types1308,
	attr_flags1308,
	gtypes1308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1308,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names1311,
	types1311,
	attr_flags1311,
	gtypes1311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1311,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1312,
	types1312,
	attr_flags1312,
	gtypes1312,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1312,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1313,
	types1313,
	attr_flags1313,
	gtypes1313,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets1313,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names1314,
	types1314,
	attr_flags1314,
	gtypes1314,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1314,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1315,
	types1315,
	attr_flags1315,
	gtypes1315,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1315,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1316,
	types1316,
	attr_flags1316,
	gtypes1316,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets1316,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names1317,
	types1317,
	attr_flags1317,
	gtypes1317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1317,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1318,
	types1318,
	attr_flags1318,
	gtypes1318,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1318,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1319,
	types1319,
	attr_flags1319,
	gtypes1319,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets1319,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names1320,
	types1320,
	attr_flags1320,
	gtypes1320,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1320,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1321,
	types1321,
	attr_flags1321,
	gtypes1321,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1321,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1322,
	types1322,
	attr_flags1322,
	gtypes1322,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets1322,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names1323,
	types1323,
	attr_flags1323,
	gtypes1323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1323,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1324,
	types1324,
	attr_flags1324,
	gtypes1324,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1324,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1325,
	types1325,
	attr_flags1325,
	gtypes1325,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets1325,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names1326,
	types1326,
	attr_flags1326,
	gtypes1326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1326,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1327,
	types1327,
	attr_flags1327,
	gtypes1327,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1327,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1328,
	types1328,
	attr_flags1328,
	gtypes1328,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets1328,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names1329,
	types1329,
	attr_flags1329,
	gtypes1329,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1329,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1330,
	types1330,
	attr_flags1330,
	gtypes1330,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1330,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1331,
	types1331,
	attr_flags1331,
	gtypes1331,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets1331,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names1332,
	types1332,
	attr_flags1332,
	gtypes1332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1332,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1333,
	types1333,
	attr_flags1333,
	gtypes1333,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1333,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1334,
	types1334,
	attr_flags1334,
	gtypes1334,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets1334,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names1335,
	types1335,
	attr_flags1335,
	gtypes1335,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1335,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1336,
	types1336,
	attr_flags1336,
	gtypes1336,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1336,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1337,
	types1337,
	attr_flags1337,
	gtypes1337,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets1337,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_OBJECT",
	names1338,
	types1338,
	attr_flags1338,
	gtypes1338,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1338,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_ARRAY",
	names1339,
	types1339,
	attr_flags1339,
	gtypes1339,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1339,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_LANGUAGE_ID",
	names1345,
	types1345,
	attr_flags1345,
	gtypes1345,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1345,
	NULL
},
{
	(long) 3,
	(long) 3,
	"THREAD_ATTRIBUTES",
	names1346,
	types1346,
	attr_flags1346,
	gtypes1346,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1346,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_LOCALE_MANAGER",
	names1348,
	types1348,
	attr_flags1348,
	gtypes1348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1348,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE_ID",
	names1349,
	types1349,
	attr_flags1349,
	gtypes1349,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1349,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_SETTING",
	names1350,
	types1350,
	attr_flags1350,
	gtypes1350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1350,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1351,
	types1351,
	attr_flags1351,
	gtypes1351,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1351,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1352,
	types1352,
	attr_flags1352,
	gtypes1352,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1352,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1353,
	types1353,
	attr_flags1353,
	gtypes1353,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1353,
	NULL
},
{
	(long) 13,
	(long) 13,
	"CONF_VERSION",
	names1354,
	types1354,
	attr_flags1354,
	gtypes1354,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1354,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1355,
	types1355,
	attr_flags1355,
	gtypes1355,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1355,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ACTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1362,
	types1362,
	attr_flags1362,
	gtypes1362,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1362,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1363,
	types1363,
	attr_flags1363,
	gtypes1363,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1363,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1364,
	types1364,
	attr_flags1364,
	gtypes1364,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1364,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER_SKELETON",
	names1365,
	types1365,
	attr_flags1365,
	gtypes1365,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1365,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER",
	names1366,
	types1366,
	attr_flags1366,
	gtypes1366,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1366,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENCODING_DETECTOR",
	names1367,
	types1367,
	attr_flags1367,
	gtypes1367,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1367,
	NULL
},
{
	(long) 4,
	(long) 4,
	"BOM_ENCODING_DETECTOR",
	names1368,
	types1368,
	attr_flags1368,
	gtypes1368,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1368,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISITOR",
	names1370,
	types1370,
	attr_flags1370,
	gtypes1370,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1370,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ITERATOR",
	names1371,
	types1371,
	attr_flags1371,
	gtypes1371,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1371,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_PRINT_VISITOR",
	names1372,
	types1372,
	attr_flags1372,
	gtypes1372,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1372,
	NULL
},
{
	(long) 10,
	(long) 10,
	"CONF_GROUPS_TARGET_CHECKER",
	names1373,
	types1373,
	attr_flags1373,
	gtypes1373,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1373,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FIND_SEPARATOR_FACILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATE_TIME_CODE_STRING",
	names1375,
	types1375,
	attr_flags1375,
	gtypes1375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1375,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1376,
	types1376,
	attr_flags1376,
	gtypes1376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1376,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1377,
	types1377,
	attr_flags1377,
	gtypes1377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1377,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1378,
	types1378,
	attr_flags1378,
	gtypes1378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1378,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_HOST_LOCALE_IMP",
	names1379,
	types1379,
	attr_flags1379,
	gtypes1379,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1379,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_FILE",
	names1380,
	types1380,
	attr_flags1380,
	gtypes1380,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1380,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_REDIRECTION",
	names1381,
	types1381,
	attr_flags1381,
	gtypes1381,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1381,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_SYSTEM",
	names1382,
	types1382,
	attr_flags1382,
	gtypes1382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1382,
	NULL
},
{
	(long) 21,
	(long) 21,
	"HTTP_CLIENT_SESSION",
	names1383,
	types1383,
	attr_flags1383,
	gtypes1383,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1383,
	NULL
},
{
	(long) 23,
	(long) 23,
	"LIBCURL_HTTP_CLIENT_SESSION",
	names1384,
	types1384,
	attr_flags1384,
	gtypes1384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1384,
	NULL
},
{
	(long) 22,
	(long) 22,
	"NET_HTTP_CLIENT_SESSION",
	names1385,
	types1385,
	attr_flags1385,
	gtypes1385,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1385,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1387,
	types1387,
	attr_flags1387,
	gtypes1387,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1388,
	types1388,
	attr_flags1388,
	gtypes1388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1389,
	types1389,
	attr_flags1389,
	gtypes1389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1389,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1390,
	types1390,
	attr_flags1390,
	gtypes1390,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1390,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1391,
	types1391,
	attr_flags1391,
	gtypes1391,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1391,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1392,
	types1392,
	attr_flags1392,
	gtypes1392,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1392,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1393,
	types1393,
	attr_flags1393,
	gtypes1393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1393,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1394,
	types1394,
	attr_flags1394,
	gtypes1394,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1394,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1395,
	types1395,
	attr_flags1395,
	gtypes1395,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1395,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1396,
	types1396,
	attr_flags1396,
	gtypes1396,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1396,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1397,
	types1397,
	attr_flags1397,
	gtypes1397,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1397,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE_32",
	names1398,
	types1398,
	attr_flags1398,
	gtypes1398,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1398,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION",
	names1399,
	types1399,
	attr_flags1399,
	gtypes1399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1399,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_DIRECTORY_LOCATION",
	names1400,
	types1400,
	attr_flags1400,
	gtypes1400,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1400,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_FILE_LOCATION",
	names1401,
	types1401,
	attr_flags1401,
	gtypes1401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1401,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LOCALIZED_PRINTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ES_IRON_CLIENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_CONDITION",
	names1407,
	types1407,
	attr_flags1407,
	gtypes1407,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1407,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_CLASSN",
	names1408,
	types1408,
	attr_flags1408,
	gtypes1408,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1408,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING_PARSER",
	names1409,
	types1409,
	attr_flags1409,
	gtypes1409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1409,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MEM_INFO",
	names1410,
	types1410,
	attr_flags1410,
	gtypes1410,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1410,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GC_INFO",
	names1411,
	types1411,
	attr_flags1411,
	gtypes1411,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1411,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FORMAT_DOUBLE",
	names1412,
	types1412,
	attr_flags1412,
	gtypes1412,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1412,
	NULL
},
{
	(long) 14,
	(long) 14,
	"JSON_PARSER",
	names1413,
	types1413,
	attr_flags1413,
	gtypes1413,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1413,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1414,
	types1414,
	attr_flags1414,
	gtypes1414,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1414,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 31,
	(long) 31,
	"COMPILER",
	names1420,
	types1420,
	attr_flags1420,
	gtypes1420,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1420,
	NULL
},
{
	(long) 52,
	(long) 52,
	"REGULAR_EXPRESSION",
	names1421,
	types1421,
	attr_flags1421,
	gtypes1421,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALIDITY_CHECKER",
	names1422,
	types1422,
	attr_flags1422,
	gtypes1422,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE",
	names1423,
	types1423,
	attr_flags1423,
	gtypes1423,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1423,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALIDITY_CHECKER",
	names1424,
	types1424,
	attr_flags1424,
	gtypes1424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1424,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME",
	names1425,
	types1425,
	attr_flags1425,
	gtypes1425,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1425,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_VALIDITY_CHECKER",
	names1426,
	types1426,
	attr_flags1426,
	gtypes1426,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1426,
	NULL
},
{
	(long) 16,
	(long) 16,
	"DATE_TIME_PARSER",
	names1427,
	types1427,
	attr_flags1427,
	gtypes1427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1427,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DATE_TIME",
	names1428,
	types1428,
	attr_flags1428,
	gtypes1428,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1428,
	NULL
},
{
	(long) 9,
	(long) 9,
	"URI",
	names1429,
	types1429,
	attr_flags1429,
	gtypes1429,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1429,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IRI",
	names1430,
	types1430,
	attr_flags1430,
	gtypes1430,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1430,
	NULL
},
{
	(long) 11,
	(long) 11,
	"PATH_URI",
	names1431,
	types1431,
	attr_flags1431,
	gtypes1431,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1431,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_TASK",
	names1432,
	types1432,
	attr_flags1432,
	gtypes1432,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1432,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_SHARE_TASK",
	names1433,
	types1433,
	attr_flags1433,
	gtypes1433,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1433,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_REPOSITORY_TASK",
	names1434,
	types1434,
	attr_flags1434,
	gtypes1434,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_REMOVE_TASK",
	names1435,
	types1435,
	attr_flags1435,
	gtypes1435,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1435,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_PATH_TASK",
	names1436,
	types1436,
	attr_flags1436,
	gtypes1436,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_INFO_TASK",
	names1437,
	types1437,
	attr_flags1437,
	gtypes1437,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_SEARCH_TASK",
	names1438,
	types1438,
	attr_flags1438,
	gtypes1438,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_LIST_TASK",
	names1439,
	types1439,
	attr_flags1439,
	gtypes1439,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_UPDATE_TASK",
	names1440,
	types1440,
	attr_flags1440,
	gtypes1440,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_COMMAND_TASK",
	names1441,
	types1441,
	attr_flags1441,
	gtypes1441,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_TESTING_TASK",
	names1442,
	types1442,
	attr_flags1442,
	gtypes1442,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1442,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_UPDATE_ECF_TASK",
	names1443,
	types1443,
	attr_flags1443,
	gtypes1443,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1443,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_UPDATE_PACKAGE_FILE_TASK",
	names1444,
	types1444,
	attr_flags1444,
	gtypes1444,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1444,
	NULL
},
{
	(long) 7,
	(long) 7,
	"IRON_INSTALL_TASK",
	names1445,
	types1445,
	attr_flags1445,
	gtypes1445,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1445,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ES_IRON_INSTALL_TASK",
	names1446,
	types1446,
	attr_flags1446,
	gtypes1446,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1446,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EIFFEL_ENV",
	names1448,
	types1448,
	attr_flags1448,
	gtypes1448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1448,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EC_EIFFEL_LAYOUT",
	names1449,
	types1449,
	attr_flags1449,
	gtypes1449,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1449,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1451,
	types1451,
	attr_flags1451,
	gtypes1451,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1451,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1452,
	types1452,
	attr_flags1452,
	gtypes1452,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1452,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1453,
	types1453,
	attr_flags1453,
	gtypes1453,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1453,
	NULL
},};


#ifdef __cplusplus
}
#endif
