/*
 * Code for class CURL_OPT_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu25.h"
#include <curl/curl.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F30_338
static EIF_INTEGER_32 inline_F30_338 (void)
{
	return CURLOPT_VERBOSE;
	;
}
#define INLINE_F30_338
#endif
#ifndef INLINE_F30_339
static EIF_INTEGER_32 inline_F30_339 (void)
{
	return CURLOPT_HEADER;
	;
}
#define INLINE_F30_339
#endif
#ifndef INLINE_F30_342
static EIF_INTEGER_32 inline_F30_342 (void)
{
	return CURLOPT_WRITEDATA;
	;
}
#define INLINE_F30_342
#endif
#ifndef INLINE_F30_349
static EIF_INTEGER_32 inline_F30_349 (void)
{
	return CURLOPT_URL;
	;
}
#define INLINE_F30_349
#endif
#ifndef INLINE_F30_350
static EIF_INTEGER_32 inline_F30_350 (void)
{
	return CURLOPT_PROXY;
	;
}
#define INLINE_F30_350
#endif
#ifndef INLINE_F30_351
static EIF_INTEGER_32 inline_F30_351 (void)
{
	return CURLOPT_PROXYPORT;
	;
}
#define INLINE_F30_351
#endif
#ifndef INLINE_F30_361
static EIF_INTEGER_32 inline_F30_361 (void)
{
	return CURLOPT_USERPWD;
	;
}
#define INLINE_F30_361
#endif
#ifndef INLINE_F30_363
static EIF_INTEGER_32 inline_F30_363 (void)
{
	return CURLOPT_HTTPAUTH;
	;
}
#define INLINE_F30_363
#endif
#ifndef INLINE_F30_364
static EIF_INTEGER_32 inline_F30_364 (void)
{
	return CURLAUTH_NONE;
	;
}
#define INLINE_F30_364
#endif
#ifndef INLINE_F30_365
static EIF_INTEGER_32 inline_F30_365 (void)
{
	return CURLAUTH_BASIC;
	;
}
#define INLINE_F30_365
#endif
#ifndef INLINE_F30_366
static EIF_INTEGER_32 inline_F30_366 (void)
{
	return CURLAUTH_DIGEST;
	;
}
#define INLINE_F30_366
#endif
#ifndef INLINE_F30_367
static EIF_INTEGER_32 inline_F30_367 (void)
{
	return CURLAUTH_ANY;
	;
}
#define INLINE_F30_367
#endif
#ifndef INLINE_F30_368
static EIF_INTEGER_32 inline_F30_368 (void)
{
	return CURLAUTH_ANYSAFE;
	;
}
#define INLINE_F30_368
#endif
#ifndef INLINE_F30_373
static EIF_INTEGER_32 inline_F30_373 (void)
{
	return CURLOPT_FOLLOWLOCATION;
	;
}
#define INLINE_F30_373
#endif
#ifndef INLINE_F30_375
static EIF_INTEGER_32 inline_F30_375 (void)
{
	return CURLOPT_MAXREDIRS;
	;
}
#define INLINE_F30_375
#endif
#ifndef INLINE_F30_376
static EIF_INTEGER_32 inline_F30_376 (void)
{
	return CURLOPT_PUT;
	;
}
#define INLINE_F30_376
#endif
#ifndef INLINE_F30_377
static EIF_INTEGER_32 inline_F30_377 (void)
{
	return CURLOPT_POST;
	;
}
#define INLINE_F30_377
#endif
#ifndef INLINE_F30_378
static EIF_INTEGER_32 inline_F30_378 (void)
{
	return CURLOPT_POSTFIELDS;
	;
}
#define INLINE_F30_378
#endif
#ifndef INLINE_F30_379
static EIF_INTEGER_32 inline_F30_379 (void)
{
	return CURLOPT_POSTFIELDSIZE;
	;
}
#define INLINE_F30_379
#endif
#ifndef INLINE_F30_381
static EIF_INTEGER_32 inline_F30_381 (void)
{
	return CURLOPT_HTTPPOST;
	;
}
#define INLINE_F30_381
#endif
#ifndef INLINE_F30_384
static EIF_INTEGER_32 inline_F30_384 (void)
{
	return CURLOPT_HTTPHEADER;
	;
}
#define INLINE_F30_384
#endif
#ifndef INLINE_F30_390
static EIF_INTEGER_32 inline_F30_390 (void)
{
	return CURLOPT_HTTPGET;
	;
}
#define INLINE_F30_390
#endif
#ifndef INLINE_F30_391
static EIF_INTEGER_32 inline_F30_391 (void)
{
	return CURLOPT_HTTP_VERSION;
	;
}
#define INLINE_F30_391
#endif
#ifndef INLINE_F30_392
static EIF_INTEGER_32 inline_F30_392 (void)
{
	return CURL_HTTP_VERSION_NONE
	;
}
#define INLINE_F30_392
#endif
#ifndef INLINE_F30_393
static EIF_INTEGER_32 inline_F30_393 (void)
{
	return CURL_HTTP_VERSION_1_0
	;
}
#define INLINE_F30_393
#endif
#ifndef INLINE_F30_401
static EIF_INTEGER_32 inline_F30_401 (void)
{
	return CURLOPT_CUSTOMREQUEST
	;
}
#define INLINE_F30_401
#endif
#ifndef INLINE_F30_403
static EIF_INTEGER_32 inline_F30_403 (void)
{
	return CURLOPT_NOBODY;
	;
}
#define INLINE_F30_403
#endif
#ifndef INLINE_F30_404
static EIF_INTEGER_32 inline_F30_404 (void)
{
	return CURLOPT_INFILESIZE;
	;
}
#define INLINE_F30_404
#endif
#ifndef INLINE_F30_406
static EIF_INTEGER_32 inline_F30_406 (void)
{
	return CURLOPT_UPLOAD;
	;
}
#define INLINE_F30_406
#endif
#ifndef INLINE_F30_413
static EIF_INTEGER_32 inline_F30_413 (void)
{
	return CURLOPT_TIMEOUT
	;
}
#define INLINE_F30_413
#endif
#ifndef INLINE_F30_423
static EIF_INTEGER_32 inline_F30_423 (void)
{
	return CURLOPT_CONNECTTIMEOUT
	;
}
#define INLINE_F30_423
#endif
#ifndef INLINE_F30_434
static EIF_INTEGER_32 inline_F30_434 (void)
{
	return CURLOPT_SSLCERT;
	;
}
#define INLINE_F30_434
#endif
#ifndef INLINE_F30_435
static EIF_INTEGER_32 inline_F30_435 (void)
{
	return CURLOPT_SSLCERTTYPE;
	;
}
#define INLINE_F30_435
#endif
#ifndef INLINE_F30_438
static EIF_INTEGER_32 inline_F30_438 (void)
{
	return CURLOPT_KEYPASSWD;
	;
}
#define INLINE_F30_438
#endif
#ifndef INLINE_F30_441
static EIF_INTEGER_32 inline_F30_441 (void)
{
	return CURLOPT_SSLVERSION;
	;
}
#define INLINE_F30_441
#endif
#ifndef INLINE_F30_444
static EIF_INTEGER_32 inline_F30_444 (void)
{
	return CURL_SSLVERSION_MAX_TLSv1_2;
	;
}
#define INLINE_F30_444
#endif
#ifndef INLINE_F30_445
static EIF_INTEGER_32 inline_F30_445 (void)
{
	return CURL_SSLVERSION_TLSv1_3;
	;
}
#define INLINE_F30_445
#endif
#ifndef INLINE_F30_448
static EIF_INTEGER_32 inline_F30_448 (void)
{
	return CURLOPT_SSL_VERIFYPEER;
	;
}
#define INLINE_F30_448
#endif
#ifndef INLINE_F30_449
static EIF_INTEGER_32 inline_F30_449 (void)
{
	return CURLOPT_CAINFO;
	;
}
#define INLINE_F30_449
#endif
#ifndef INLINE_F30_451
static EIF_INTEGER_32 inline_F30_451 (void)
{
	return CURLOPT_SSL_VERIFYHOST;
	;
}
#define INLINE_F30_451
#endif
#ifndef INLINE_F30_454
static EIF_INTEGER_32 inline_F30_454 (void)
{
	return CURLOPT_SSL_CIPHER_LIST;
	;
}
#define INLINE_F30_454
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_OPT_CONSTANTS}.curlopt_verbose */
EIF_INTEGER_32 F30_338 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_338 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_header */
EIF_INTEGER_32 F30_339 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_339 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_writedata */
EIF_INTEGER_32 F30_342 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_342 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_url */
EIF_INTEGER_32 F30_349 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_349 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_proxy */
EIF_INTEGER_32 F30_350 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_350 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_proxyport */
EIF_INTEGER_32 F30_351 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_351 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_userpwd */
EIF_INTEGER_32 F30_361 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_361 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_httpauth */
EIF_INTEGER_32 F30_363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_363 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlauth_none */
EIF_INTEGER_32 F30_364 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_364 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlauth_basic */
EIF_INTEGER_32 F30_365 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_365 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlauth_digest */
EIF_INTEGER_32 F30_366 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_366 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlauth_any */
EIF_INTEGER_32 F30_367 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_367 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlauth_anysafe */
EIF_INTEGER_32 F30_368 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_368 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_followlocation */
EIF_INTEGER_32 F30_373 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_373 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_maxredirs */
EIF_INTEGER_32 F30_375 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_375 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_put */
EIF_INTEGER_32 F30_376 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_376 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_post */
EIF_INTEGER_32 F30_377 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_377 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_postfields */
EIF_INTEGER_32 F30_378 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_378 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_postfieldsize */
EIF_INTEGER_32 F30_379 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_379 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_httppost */
EIF_INTEGER_32 F30_381 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_381 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_httpheader */
EIF_INTEGER_32 F30_384 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_384 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_httpget */
EIF_INTEGER_32 F30_390 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_390 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_http_version */
EIF_INTEGER_32 F30_391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_391 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curl_http_version_none */
EIF_INTEGER_32 F30_392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_392 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curl_http_version_1_0 */
EIF_INTEGER_32 F30_393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_393 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_customrequest */
EIF_INTEGER_32 F30_401 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_401 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_nobody */
EIF_INTEGER_32 F30_403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_403 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_infilesize */
EIF_INTEGER_32 F30_404 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_404 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_upload */
EIF_INTEGER_32 F30_406 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_406 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_timeout */
EIF_INTEGER_32 F30_413 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_413 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_connecttimeout */
EIF_INTEGER_32 F30_423 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_423 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_sslcert */
EIF_INTEGER_32 F30_434 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_434 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_sslcerttype */
EIF_INTEGER_32 F30_435 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_435 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_keypasswd */
EIF_INTEGER_32 F30_438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_438 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_sslversion */
EIF_INTEGER_32 F30_441 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_441 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curl_sslversion_tlsv1_2 */
EIF_INTEGER_32 F30_444 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_444 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curl_sslversion_tlsv1_3 */
EIF_INTEGER_32 F30_445 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_445 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_ssl_verifypeer */
EIF_INTEGER_32 F30_448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_448 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_cainfo */
EIF_INTEGER_32 F30_449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_449 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_ssl_verifyhost */
EIF_INTEGER_32 F30_451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_451 ();
	return Result;
}

/* {CURL_OPT_CONSTANTS}.curlopt_ssl_cipher_list */
EIF_INTEGER_32 F30_454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F30_454 ();
	return Result;
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
