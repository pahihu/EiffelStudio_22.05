
#ifndef _C1_ca20_
#define _C1_ca20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_248(EIF_REFERENCE);
extern void F25_249(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F25_252(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_253(EIF_REFERENCE);
extern void F25_254(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit20(void);
extern void F1234_11098(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R7374[])();
extern long O8704[];

#ifdef __cplusplus
}
#endif

#endif
