/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er18.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F23_197 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (629,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F23_198 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (662,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F23_199 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (663,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F23_200 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (664,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F23_201 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (658,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F23_202 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (657,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F23_203 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (647,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F23_204 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (653,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F23_205 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (654,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F23_206 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (655,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F23_208 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (656,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F23_209 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (640,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F23_210 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (641,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F23_211 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (643,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F23_212 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (632,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F23_215 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (635,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F23_219 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (631,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F23_221 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (639,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F23_222 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (634,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F23_223 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (636,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F23_224 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (642,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F23_225 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (638,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F23_227 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (649,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F23_228 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (648,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F23_232 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (637,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F23_234 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (630,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
