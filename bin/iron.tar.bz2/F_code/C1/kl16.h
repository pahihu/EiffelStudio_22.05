
#ifndef _C1_kl16_
#define _C1_kl16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F21_183(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
