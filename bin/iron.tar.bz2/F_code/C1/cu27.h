
#ifndef _C1_cu27_
#define _C1_cu27_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F32_546(EIF_REFERENCE);
extern EIF_INTEGER_32 F32_547(EIF_REFERENCE);
extern EIF_INTEGER_32 F32_548(EIF_REFERENCE);
extern EIF_INTEGER_32 F32_549(EIF_REFERENCE);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
