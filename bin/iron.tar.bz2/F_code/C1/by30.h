
#ifndef _C1_by30_
#define _C1_by30_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F36_638(EIF_REFERENCE);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
