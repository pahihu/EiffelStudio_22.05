/*
 * Code for class I18N_PLURAL_TOOLS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i17.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_PLURAL_TOOLS}.mo_header_to_plural_form */
EIF_INTEGER_32 F12_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 2L:
			tr1 = RTMS_EX_H("n != 1;",7,619025723);
			tb1 = F1168_10052(RTCW(arg2), tr1);
			if (tb1) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
			break;
		case 3L:
			tb1 = '\0';
			tb2 = '\0';
			tr1 = RTMS_EX_H("!=",2,8509);
			tb3 = F1168_10051(RTCW(arg2), tr1);
			if (tb3) {
				tr1 = RTMS_EX_H("4",1,52);
				tb3 = F1168_10051(RTCW(arg2), tr1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTMS_EX_H("20",2,12848);
				tb2 = F1168_10051(RTCW(arg2), tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				tb1 = '\0';
				tr1 = RTMS_EX_H("!=",2,8509);
				tb2 = F1168_10051(RTCW(arg2), tr1);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTMS_EX_H("4",1,52);
					tb2 = F1168_10051(RTCW(arg2), tr1);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					tb1 = '\0';
					tr1 = RTMS_EX_H("20",2,12848);
					tb2 = F1168_10051(RTCW(arg2), tr1);
					if (tb2) {
						tr1 = RTMS_EX_H("4",1,52);
						tb2 = F1168_10051(RTCW(arg2), tr1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						tr1 = RTMS_EX_H("!=",2,8509);
						tb1 = F1168_10051(RTCW(arg2), tr1);
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
						}
					}
				}
			}
			break;
		case 4L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		default:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	RTLE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_reduction_agent */
EIF_REFERENCE F12_89 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	switch (arg1) {
		case 1L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_50_2, (EIF_POINTER) _A7_50_2, (EIF_POINTER)(F12_91),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 2L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_51_2, (EIF_POINTER) _A7_51_2, (EIF_POINTER)(F12_92),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 0L:
		case 3L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_52_2, (EIF_POINTER) _A7_52_2, (EIF_POINTER)(F12_93),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 4L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_53_2, (EIF_POINTER) _A7_53_2, (EIF_POINTER)(F12_94),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 5L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_54_2, (EIF_POINTER) _A7_54_2, (EIF_POINTER)(F12_95),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 6L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_55_2, (EIF_POINTER) _A7_55_2, (EIF_POINTER)(F12_96),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 7L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_56_2, (EIF_POINTER) _A7_56_2, (EIF_POINTER)(F12_97),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 8L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_57_2, (EIF_POINTER) _A7_57_2, (EIF_POINTER)(F12_98),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 9L:
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1165,0xFF01,0xFFF9,1,1113,1312,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A7_58_2, (EIF_POINTER) _A7_58_2, (EIF_POINTER)(F12_99),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_nplural */
EIF_INTEGER_32 F12_90 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 3L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1L))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 8L))) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	return Result;
}

/* {I18N_PLURAL_TOOLS}.reduce_one_plural_form */
EIF_INTEGER_32 F12_91 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 F12_92 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 F12_93 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 F12_94 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 F12_95 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 F12_96 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 F12_97 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 F12_98 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 F12_99 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 2L))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 3L))) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
		}
	}
	return Result;
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
