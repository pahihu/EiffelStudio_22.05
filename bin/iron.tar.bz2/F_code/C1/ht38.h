
#ifndef _C1_ht38_
#define _C1_ht38_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F43_920(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
