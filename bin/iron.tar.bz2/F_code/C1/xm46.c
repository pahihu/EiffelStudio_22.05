/*
 * Code for class XML_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.make */
void F51_1058 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1053,0xFF01,960,0xFF01,1170,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1054_8838(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.reset */
void F51_1059 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1054_8874(RTCW(tr1));
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F51_1060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(594,F51_1072, (Current));
	F51_1061(Current, arg1, tr1);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add */
void F51_1061 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1054_8841(RTCW(tr1));
	tr2 = F51_1069(Current, arg2);
	F961_8605(RTCW(tr1), arg1, tr2);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F51_1063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1054_8841(RTCW(tr1));
		tr2 = F51_1069(Current, arg1);
		tb1 = F961_8566(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F51_1064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F51_1069(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F1054_8845(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F648_7868(loc2);
		if (tb2) break;
		tr1 = F648_7867(loc2);
		tb3 = F961_8566(RTCW(tr1), loc1);
		tb1 = tb3;
		F648_7870(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F51_1065 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(594,F51_1072, (Current));
	Result = F51_1066(Current, tr1);
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F51_1066 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	Result = RTOUCR(595,F51_1073, (Current));
	loc3 = F51_1069(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = F1054_8845(RTCW(tr1));
	for (;;) {
		tb1 = F648_7868(loc4);
		if (tb1) break;
		if (loc2) break;
		loc1 = F648_7867(loc4);
		tb2 = '\0';
		tb3 = F961_8566(RTCW(loc1), loc3);
		if (tb3) {
			tr1 = F961_8564(RTCW(loc1), loc3);
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			Result = (EIF_REFERENCE) loc5;
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		F648_7870(loc4);
	}
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.push */
void F51_1067 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F51_1071(Current);
	F1054_8864(RTCW(tr1), tr2);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F51_1068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F1054_8857(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7082[Dtype(RTCW(tr1))-908])(tr1);
	}
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.to_context_key */
EIF_REFERENCE F51_1069 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = F1168_10067(RTCW(arg1));
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.new_string_string_table */
EIF_REFERENCE F51_1071 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,960,0xFF01,1170,0xFF01,1172,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 960, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F961_8558(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */

EIF_REFERENCE F51_1072 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (594,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */

EIF_REFERENCE F51_1073 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (595,RTMS32_EX_H("",0,0));
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
