
#ifndef _C1_ar15_
#define _C1_ar15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F20_182(EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
