
#ifndef _C1_i15_
#define _C1_i15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F10_56(EIF_REFERENCE, EIF_REFERENCE);
extern void F10_57(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit5(void);

#ifdef __cplusplus
}
#endif

#endif
