
#ifndef _C1_co22_
#define _C1_co22_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F27_283(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F1109_9534(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
