
#ifndef _C1_ar39_
#define _C1_ar39_

#ifdef __cplusplus
extern "C" {
#endif

extern void F44_970(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F44_971(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit39(void);
extern void F1059_8908(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1072_8978(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5820[])();
extern char *(*R5821[])();
extern char *(*R5822[])();
extern char *(*R6830[])();

#ifdef __cplusplus
}
#endif

#endif
