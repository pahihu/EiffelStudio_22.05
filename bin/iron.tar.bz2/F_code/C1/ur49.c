/*
 * Code for class URI_PERCENT_ENCODER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ur49.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {URI_PERCENT_ENCODER}.append_query_name_encoded_string_to */
void F54_1104 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		F54_1109(Current, tu4_1, arg2);
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_query_value_encoded_string_to */
void F54_1105 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		F54_1110(Current, tu4_1, arg2);
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_encoded_character_code_to */
void F54_1108 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 48L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 90L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 97L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 122L))))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, arg1);
	} else {
		switch (arg1) {
			case 45U:
			case 46U:
			case 95U:
			case 126U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, arg1);
				break;
			case 33U:
			case 36U:
			case 37U:
			case 38U:
			case 39U:
			case 40U:
			case 41U:
			case 42U:
			case 43U:
			case 44U:
			case 58U:
			case 59U:
			case 61U:
			case 64U:
				F54_1112(Current, arg1, arg2);
				break;
			default:
				F54_1112(Current, arg1, arg2);
				break;
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_query_name_encoded_character_code_to */
void F54_1109 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 61U:
			F54_1112(Current, arg1, arg2);
			break;
		default:
			F54_1110(Current, arg1, arg2);
			break;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_query_value_encoded_character_code_to */
void F54_1110 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 32U:
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 43L));
			break;
		case 33U:
		case 36U:
		case 39U:
		case 40U:
		case 41U:
		case 42U:
		case 44U:
		case 58U:
		case 59U:
		case 61U:
		case 64U:
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, arg1);
			break;
		case 47U:
		case 63U:
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, arg1);
			break;
		default:
			F54_1108(Current, arg1, arg2);
			break;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_character_code_to */
void F54_1112 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		F54_1114(Current, arg1, arg2);
	} else {
		if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			F54_1114(Current, arg1, arg2);
		} else {
			F54_1113(Current, arg1, arg2);
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_ascii_character_code_to */
void F54_1113 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		F54_1114(Current, arg1, arg2);
	} else {
		loc1 = (EIF_INTEGER_32) arg1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L));
		tr1 = RTOUCR(558,F54_1126, (Current));
		ti4_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 4L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, tu4_1);
		tr1 = RTOUCR(558,F54_1126, (Current));
		ti4_1 = eif_bit_and(loc1,((EIF_INTEGER_32) 15L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, tu4_1);
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_unicode_character_code_to */
void F54_1114 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
		F54_1113(Current, arg1, arg2);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2047L))) {
			tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 192L));
			F54_1113(Current, tu4_1, arg2);
			tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
			F54_1113(Current, tu4_1, arg2);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 224L));
				F54_1113(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F54_1113(Current, tu4_1, arg2);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F54_1113(Current, tu4_1, arg2);
			} else {
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 18L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 240L));
				F54_1113(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F54_1113(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F54_1113(Current, tu4_1, arg2);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F54_1113(Current, tu4_1, arg2);
			}
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.hex_digit */
static EIF_REFERENCE F54_1126_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(558)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1239,1324,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 16L),sizeof(EIF_NATURAL_32), EIF_TRUE);
	}
	F1240_11098(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 16L));
	Result = (EIF_REFERENCE) tr1;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = ((EIF_NATURAL_32) 48U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 1L))) = ((EIF_NATURAL_32) 49U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 2L))) = ((EIF_NATURAL_32) 50U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 3L))) = ((EIF_NATURAL_32) 51U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 4L))) = ((EIF_NATURAL_32) 52U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 5L))) = ((EIF_NATURAL_32) 53U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 6L))) = ((EIF_NATURAL_32) 54U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 7L))) = ((EIF_NATURAL_32) 55U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 8L))) = ((EIF_NATURAL_32) 56U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 9L))) = ((EIF_NATURAL_32) 57U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 10L))) = ((EIF_NATURAL_32) 65U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 11L))) = ((EIF_NATURAL_32) 66U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 12L))) = ((EIF_NATURAL_32) 67U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 13L))) = ((EIF_NATURAL_32) 68U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 14L))) = ((EIF_NATURAL_32) 69U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 15L))) = ((EIF_NATURAL_32) 70U);
	/* END INLINED CODE */
	;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F54_1126 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(558,F54_1126_body,(Current));
}

void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
