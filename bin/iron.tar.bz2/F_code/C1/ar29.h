
#ifndef _C1_ar29_
#define _C1_ar29_

#ifdef __cplusplus
extern "C" {
#endif

extern void F34_559(EIF_REFERENCE, EIF_REFERENCE);
extern void F34_560(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F34_562(EIF_REFERENCE);
extern void F34_563(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F34_564(EIF_REFERENCE);
extern void EIF_Minit29(void);
extern EIF_BOOLEAN F1172_10208(EIF_REFERENCE);
extern void F1172_10190(EIF_REFERENCE, EIF_REFERENCE);
extern void F1168_10007(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
