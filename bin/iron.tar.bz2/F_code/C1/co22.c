/*
 * Code for class CONF_IRON_INSTALLATION_API_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co22.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_IRON_INSTALLATION_API_FACTORY}.iron_installation_api */
EIF_REFERENCE F27_283 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_5_0_0_1_0_0_0_0_);
	F1109_9534(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
