
#ifndef _C1_i18_
#define _C1_i18_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F13_100(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);
extern void F149_2423(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
