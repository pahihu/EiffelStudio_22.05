/*
 * Code for class CURL_FORM_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu27.h"
#include <curl/curl.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F32_546
static EIF_INTEGER_32 inline_F32_546 (void)
{
	return (EIF_INTEGER_32) (CURLFORM_COPYNAME)
	;
}
#define INLINE_F32_546
#endif
#ifndef INLINE_F32_547
static EIF_INTEGER_32 inline_F32_547 (void)
{
	return (EIF_INTEGER_32) (CURLFORM_COPYCONTENTS)
	;
}
#define INLINE_F32_547
#endif
#ifndef INLINE_F32_548
static EIF_INTEGER_32 inline_F32_548 (void)
{
	return (EIF_INTEGER_32) (CURLFORM_END)
	;
}
#define INLINE_F32_548
#endif
#ifndef INLINE_F32_549
static EIF_INTEGER_32 inline_F32_549 (void)
{
	return (EIF_INTEGER_32) (CURLFORM_FILE)
	;
}
#define INLINE_F32_549
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_FORM_CONSTANTS}.curlform_copyname */
EIF_INTEGER_32 F32_546 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F32_546 ();
	return Result;
}

/* {CURL_FORM_CONSTANTS}.curlform_copycontents */
EIF_INTEGER_32 F32_547 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F32_547 ();
	return Result;
}

/* {CURL_FORM_CONSTANTS}.curlform_end */
EIF_INTEGER_32 F32_548 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F32_548 ();
	return Result;
}

/* {CURL_FORM_CONSTANTS}.curlform_file */
EIF_INTEGER_32 F32_549 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F32_549 ();
	return Result;
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
