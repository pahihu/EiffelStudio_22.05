
#ifndef _C1_i111_
#define _C1_i111_

#ifdef __cplusplus
extern "C" {
#endif

extern void F16_114(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit11(void);
extern void F403_5208(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
