
#ifndef _C1_ut2_
#define _C1_ut2_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2_35(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2(void);
extern EIF_REFERENCE F86_1648(EIF_REFERENCE, EIF_REFERENCE);
extern void F1168_10007(EIF_REFERENCE);
extern char *(*R6295[])();

#ifdef __cplusplus
}
#endif

#endif
