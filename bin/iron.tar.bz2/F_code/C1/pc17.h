
#ifndef _C1_pc17_
#define _C1_pc17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_187(EIF_REFERENCE);
extern void F22_188(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F22_190(EIF_REFERENCE, EIF_INTEGER_32);
extern void F22_191(EIF_REFERENCE, EIF_REFERENCE);
extern void F22_192(EIF_REFERENCE, EIF_INTEGER_32);
extern void F22_193(EIF_REFERENCE, EIF_REFERENCE);
extern void F22_194(EIF_REFERENCE, EIF_REFERENCE);
extern void F22_195(EIF_REFERENCE);
extern void EIF_Minit17(void);
extern void F1236_11098(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R8680[])();
extern long O8704[];

#ifdef __cplusplus
}
#endif

#endif
