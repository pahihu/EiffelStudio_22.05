/*
 * Code for class HTTP_HEADER_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ht38.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HTTP_HEADER_NAMES}.header_if_modified_since */

EIF_REFERENCE F43_920 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (539,RTMS_EX_H("If-Modified-Since",17,856684389));
}

void EIF_Minit38 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
