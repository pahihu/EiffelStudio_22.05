
#ifndef _C1_cu12_
#define _C1_cu12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F17_123(EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
