/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir41.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F46_981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1172, 1).id);
	F1168_10007(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F46_984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F46_985 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (604,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F46_986 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (605,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F46_987 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (606,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F46_988 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (607,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F46_989 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (608,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F46_990 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(936, 0x01).id, 936, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F937_8421(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6239[Dtype(RTCW(loc1))-568])(loc1);
	if (tb2) {
		tb2 = F936_8230(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F936_8262(RTCW(loc1));
		F46_991(Current, loc1);
		F936_8279(RTCW(loc1));
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F46_991 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	loc1 = F742_7994(RTCW(arg1));
	for (;;) {
		if (loc1) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6295[Dtype(RTCW(arg1))-936])(arg1, ((EIF_INTEGER_32) 2046L));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8730[Dtype(RTCW(loc2))-1175])(loc2, tr1);
		loc1 = '\01';
		tb1 = F742_7994(RTCW(arg1));
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8704[Dtype(tr1)-1173]);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	F46_992(Current, loc2);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F46_992 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1173_10281(RTCW(tr1));
	F86_1651(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F46_993(Current);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F46_993 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F878_8129(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		loc1 = F46_1006(Current);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				loc1 = F46_1003(Current);
				F46_994(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				loc1 = F46_1003(Current);
				loc2 = F46_1009(Current);
				tr1 = F1168_10066(RTCV(RTOUCR(604,F46_985, (Current))));
				tb1 = F1171_10162(RTCW(loc2), tr1);
				if (tb1) {
					F46_995(Current);
				} else {
					tr1 = F1168_10066(RTCV(RTOUCR(606,F46_987, (Current))));
					tb1 = F1171_10162(RTCW(loc2), tr1);
					if (tb1) {
						F46_998(Current);
					} else {
						tr1 = F1168_10066(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F46_1002(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				loc1 = F46_1003(Current);
				loc2 = F46_1009(Current);
				tr1 = RTOUCR(605,F46_986, (Current));
				tb1 = F1168_10049(RTCW(loc2), tr1);
				if (tb1) {
					F46_996(Current);
				} else {
					tr1 = F1168_10066(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F46_1002(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				loc1 = F46_1003(Current);
				loc2 = F46_1009(Current);
				tr1 = RTOUCR(607,F46_988, (Current));
				tb1 = F1168_10049(RTCW(loc2), tr1);
				if (tb1) {
					F46_1000(Current);
				} else {
					tr1 = F1168_10066(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F46_1002(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				loc1 = F46_1003(Current);
				loc2 = F46_1009(Current);
				tr1 = F1168_10066(RTCV(RTOUCR(608,F46_989, (Current))));
				tb1 = F1171_10162(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = F1168_10066(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F46_1002(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					tr1 = F1168_10066(RTMS_EX_H("Unexpected null character.",26,830567726));
					F46_1002(Current, tr1);
				}
				break;
			default:
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F46_1015(Current, loc1);
				tr1 = F1173_10271(tr1, tr2);
				tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
				tr1 = F1173_10271(RTCW(tr1), tr2);
				F46_1002(Current, tr1);
				break;
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F46_994 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F46_1004(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			loc1 = F46_1004(Current);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2 = F46_1008(Current);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F46_1015(Current, loc1);
				tr1 = F1173_10271(tr1, tr2);
				tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
				tr1 = F1173_10271(RTCW(tr1), tr2);
				F46_1002(Current, tr1);
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F46_1015(Current, loc1);
		tr1 = F1173_10271(tr1, tr2);
		tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F46_1002(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F46_995 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	loc2 = F46_1006(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F46_1003(Current);
		loc1 = F46_1011(Current);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(loc1))-1171])(loc1);
		if (tb1) {
			tr1 = F1168_10066(RTMS_EX_H("Invalid package name",20,1534212709));
			F46_1002(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				F290_3989(loc3, loc1);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F46_996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F46_1006(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F46_1003(Current);
		loc1 = F46_1013(Current);
		loc5 = F46_1003(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(loc1))-1171])(loc1);
			if (tb1) {
				loc5 = F46_1004(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F46_1003(Current);
					F46_994(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F46_1006(Current);
						loc5 = F46_1003(Current);
						loc1 = F46_1013(Current);
						loc5 = F46_1003(Current);
					}
				} else {
					tr1 = F1168_10066(RTMS_EX_H("Invalid setup name",18,1945739621));
					F46_1002(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1168_10066(RTCV(RTOUCR(606,F46_987, (Current))));
				tb1 = F1171_10162(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1168_10066(RTCV(RTOUCR(607,F46_988, (Current))));
					tb1 = F1171_10162(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1168_10066(RTCV(RTOUCR(608,F46_989, (Current))));
						tb1 = F1171_10162(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F46_997(Current, loc1);
							loc5 = F46_1003(Current);
							loc5 = F46_1006(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F46_1003(Current);
								F46_994(Current);
								loc5 = F46_1006(Current);
							}
							loc5 = F46_1003(Current);
							loc1 = F46_1013(Current);
							loc5 = F46_1003(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F46_1000(Current);
		} else {
			if (loc3) {
				F46_998(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F46_997 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc4 = F46_1006(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F46_1007(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F1168_10066(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F46_1002(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F46_1004(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F46_1008(Current);
					tb1 = F1168_10025(RTCW(loc1));
					if (tb1) {
						loc2 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1168_10007(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F46_1008(Current);
							F1173_10237(RTCW(loc1));
							tr1 = F1168_10066(RTMS_EX_H("]\"",2,23842));
							tb1 = F1171_10173(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1171_10170(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F1173_10252(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1173_10265(RTCW(loc2), tw1);
								}
							} else {
								F1173_10252(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1173_10265(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F46_1016(Current, loc2);
						}
					} else {
						F1173_10243(RTCW(loc1), loc4);
						F1173_10237(RTCW(loc1));
						tr1 = F1168_10066(RTMS_EX_H("\"",1,34));
						tb1 = F1171_10173(RTCW(loc1), tr1);
						if (tb1) {
							F1173_10276(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1173_10243(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1168_10007(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1173_10265(RTCW(loc1), tw1);
					F1173_10265(RTCW(loc1), loc4);
					tr1 = F46_1008(Current);
					F1173_10252(RTCW(loc1), tr1);
					F1173_10236(RTCW(loc1));
					F1173_10237(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1173_10219(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1173_10219(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						F1173_10274(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						F1173_10276(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F46_1006(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1168_10007(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F46_1003(Current);
					loc1 = F46_1008(Current);
					F1173_10236(RTCW(loc1));
					F1173_10237(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F1168_10066(RTMS_EX_H("",0,0));
			}
			F290_3990(loc5, arg1, loc2);
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F46_1015(Current, loc4);
		tr1 = F1173_10271(tr1, tr2);
		tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F46_1002(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F46_998 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F46_1006(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F46_1003(Current);
		loc1 = F46_1013(Current);
		loc5 = F46_1003(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(loc1))-1171])(loc1);
			if (tb1) {
				loc5 = F46_1004(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F46_1003(Current);
					F46_994(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F46_1006(Current);
						loc5 = F46_1003(Current);
						loc1 = F46_1013(Current);
						loc5 = F46_1003(Current);
					}
				} else {
					tr1 = F1168_10066(RTMS_EX_H("Invalid project name",20,415510117));
					F46_1002(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1168_10066(RTCV(RTOUCR(605,F46_986, (Current))));
				tb1 = F1171_10162(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1168_10066(RTCV(RTOUCR(607,F46_988, (Current))));
					tb1 = F1171_10162(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1168_10066(RTCV(RTOUCR(608,F46_989, (Current))));
						tb1 = F1171_10162(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F46_999(Current, loc1);
							loc5 = F46_1003(Current);
							loc5 = F46_1006(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F46_1003(Current);
								F46_994(Current);
								loc5 = F46_1006(Current);
							}
							loc5 = F46_1003(Current);
							loc1 = F46_1013(Current);
							loc5 = F46_1003(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F46_1000(Current);
		} else {
			if (loc3) {
				F46_996(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F46_999 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc2 = F46_1006(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		loc2 = F46_1006(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			tr1 = F1168_10066(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F46_1002(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1168_10007(RTCW(loc1));
				loc2 = F46_1004(Current);
				for (;;) {
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					F1173_10265(RTCW(loc1), loc2);
					loc2 = F46_1004(Current);
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						F290_3991(loc3, arg1, loc1);
					}
					loc2 = F46_1006(Current);
				}
			} else {
				loc1 = F46_1008(Current);
				F1173_10236(RTCW(loc1));
				F1173_10237(RTCW(loc1));
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					F290_3991(loc4, arg1, loc1);
				}
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F46_1015(Current, loc2);
		tr1 = F1173_10271(tr1, tr2);
		tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F46_1002(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F46_1000 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F46_1006(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F46_1003(Current);
		loc1 = F46_1014(Current);
		loc2 = F46_1003(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(loc1))-1171])(loc1);
			if (tb1) {
				loc2 = F46_1004(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					loc2 = F46_1003(Current);
					F46_994(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc2 = F46_1006(Current);
						loc2 = F46_1003(Current);
						loc1 = F46_1014(Current);
						loc2 = F46_1003(Current);
					}
				} else {
					tr1 = F1168_10066(RTMS_EX_H("Invalid note name",17,17618021));
					F46_1002(Current, tr1);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1168_10066(RTCV(RTOUCR(604,F46_985, (Current))));
				tb1 = F1171_10162(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1168_10066(RTCV(RTOUCR(605,F46_986, (Current))));
					tb1 = F1171_10162(RTCW(loc1), tr1);
					if (tb1) {
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1168_10066(RTCV(RTOUCR(608,F46_989, (Current))));
						tb1 = F1171_10162(RTCW(loc1), tr1);
						if (tb1) {
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F46_1001(Current, loc1);
							loc2 = F46_1003(Current);
							loc2 = F46_1006(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								loc2 = F46_1003(Current);
								F46_994(Current);
								loc2 = F46_1006(Current);
							}
							loc2 = F46_1003(Current);
							loc1 = F46_1014(Current);
							loc2 = F46_1003(Current);
						}
					}
				}
			}
		}
		if (loc3) {
			tr1 = F1168_10066(RTCV(RTOUCR(604,F46_985, (Current))));
			tb1 = F1171_10162(RTCW(loc1), tr1);
			if (tb1) {
				F46_995(Current);
			} else {
				tr1 = F1168_10066(RTCV(RTOUCR(605,F46_986, (Current))));
				tb1 = F1171_10162(RTCW(loc1), tr1);
				if (tb1) {
					F46_996(Current);
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F46_1001 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc4 = F46_1006(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F46_1007(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F1168_10066(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F46_1002(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F46_1004(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F46_1008(Current);
					tb1 = F1168_10025(RTCW(loc1));
					if (tb1) {
						loc2 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1168_10007(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F46_1008(Current);
							F1173_10237(RTCW(loc1));
							tr1 = F1168_10066(RTMS_EX_H("]\"",2,23842));
							tb1 = F1171_10173(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1171_10170(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F1173_10252(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1173_10265(RTCW(loc2), tw1);
								}
							} else {
								F1173_10252(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1173_10265(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F46_1016(Current, loc2);
						}
					} else {
						F1173_10243(RTCW(loc1), loc4);
						F1173_10237(RTCW(loc1));
						tr1 = F1168_10066(RTMS_EX_H("\"",1,34));
						tb1 = F1171_10173(RTCW(loc1), tr1);
						if (tb1) {
							F1173_10276(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1173_10243(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1168_10007(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1173_10265(RTCW(loc1), tw1);
					F1173_10265(RTCW(loc1), loc4);
					tr1 = F46_1008(Current);
					F1173_10252(RTCW(loc1), tr1);
					F1173_10236(RTCW(loc1));
					F1173_10237(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1173_10219(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1173_10219(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F1171_10149(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						F1173_10274(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						F1173_10276(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F46_1006(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1168_10007(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F46_1003(Current);
					loc1 = F46_1008(Current);
					F1173_10236(RTCW(loc1));
					F1173_10237(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F1168_10066(RTMS_EX_H("",0,0));
			}
			F290_3992(loc5, arg1, loc2);
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F46_1015(Current, loc4);
		tr1 = F1173_10271(tr1, tr2);
		tr2 = F1168_10066(RTMS_EX_H("].",2,23854));
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F46_1002(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F46_1002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F46_1003 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1173_10219(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		} else {
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		F46_1005(Current);
	} else {
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		tr1 = F1168_10066(RTMS_EX_H("out of input",12,330662516));
		F46_1002(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F46_1004 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1168_10066(RTMS_EX_H("out of input",12,330662516));
		F46_1002(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1173_10219(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		F46_1005(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F46_1005 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F46_1006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1168_10066(RTMS_EX_H("out of input",12,330662516));
		F46_1002(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F46_1004(Current);
		for (;;) {
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F1120_9843(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			Result = F46_1004(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F46_1007 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1168_10066(RTMS_EX_H("out of input",12,330662516));
		F46_1002(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F46_1004(Current);
		for (;;) {
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F1120_9843(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			Result = F46_1004(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F46_1008 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	loc1 = F46_1004(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		F1173_10265(RTCW(Result), loc1);
		loc1 = F46_1004(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F46_1009 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	loc1 = F46_1004(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F1120_9837(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1173_10265(RTCW(Result), loc1);
		loc1 = F46_1004(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F46_1011 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	loc1 = F46_1004(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1120_9845(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1173_10265(RTCW(Result), loc1);
		loc1 = F46_1004(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F46_1013 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	loc1 = F46_1004(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F1120_9845(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1173_10265(RTCW(Result), loc1);
		loc1 = F46_1004(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F46_1014 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	loc1 = F46_1004(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1120_9845(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1173_10265(RTCW(Result), loc1);
		loc1 = F46_1004(Current);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				loc2--;
			}
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2++;
			}
		}
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		tr1 = F1173_10271(tr1, Result);
		tr2 = F1168_10066(RTMS_EX_H("\"",1,34));
		tr1 = F1173_10271(RTCW(tr1), tr2);
		F46_1002(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F46_1015 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1171_10137(RTCW(Result), ((EIF_INTEGER_32) 1L));
	F1173_10265(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F46_1016 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) loc1;
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F1171_10149(RTCW(arg1), tw1, loc1);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc3 = (EIF_INTEGER_32) loc5;
		}
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					tw1 = F1173_10219(RTCW(arg1), loc2);
					tr1 = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F1120_9843(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					loc2++;
				}
				loc6 = F1173_10299(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				loc2 = (EIF_INTEGER_32) loc1;
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						tw1 = F1173_10219(RTCW(loc6), loc4);
						tw2 = F1173_10219(RTCW(arg1), loc2);
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					loc4++;
					loc2++;
				}
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					tw1 = F1173_10219(RTCW(loc6), loc4);
					tw2 = F1173_10219(RTCW(arg1), loc2);
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					F1173_10234(RTCW(loc6), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				}
			}
		}
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		tb3 = F1171_10172(RTCW(arg1), loc6);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			F1173_10274(RTCW(arg1), ti4_1);
		}
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		tr1 = F1173_10271(tr1, loc6);
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F1173_10229(RTCW(arg1), tr1, tr2);
	}
	RTLE;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
