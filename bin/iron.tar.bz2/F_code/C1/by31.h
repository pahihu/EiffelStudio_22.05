
#ifndef _C1_by31_
#define _C1_by31_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F35_638(EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
