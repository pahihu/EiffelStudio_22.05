
#ifndef _C1_ne36_
#define _C1_ne36_

#ifdef __cplusplus
extern "C" {
#endif

extern void F41_844(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F41_848(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit36(void);
extern char *(*R8511[])();

#ifdef __cplusplus
}
#endif

#endif
