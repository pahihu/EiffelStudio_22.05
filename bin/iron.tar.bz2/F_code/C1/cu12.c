/*
 * Code for class CURL_GLOBAL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu12.h"
#include <curl/curl.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_123
static EIF_NATURAL_64 inline_F17_123 (void)
{
	return CURL_GLOBAL_ALL;
	;
}
#define INLINE_F17_123
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_GLOBAL_CONSTANTS}.curl_global_all */
EIF_NATURAL_64 F17_123 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	
	
	Result = inline_F17_123 ();
	return Result;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
