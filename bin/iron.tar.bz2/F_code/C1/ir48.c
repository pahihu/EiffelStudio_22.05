/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir48.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_package */
void F53_1090 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7024[Dtype(RTCW(tr1))-1190])(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F53_1091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F53_1097(Current);
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F53_1097 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_70 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(76, 0x00).id);
	RTLI(21);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,loc13);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc14);
	RTLR(11,loc5);
	RTLR(12,loc15);
	RTLR(13,loc6);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc8);
	RTLR(17,loc9);
	RTLR(18,loc7);
	RTLR(19,loc4);
	RTLR(20,loc18);
	RTLIU(21);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1193, 1).id);
	F1194_10989(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F53_1102(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		loc1 = RTLNS(eif_new_type(1412, 0x01).id, 1412, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F1413_14330(RTCW(loc1), loc10);
		F1413_14350(RTCW(loc1));
		tb1 = '\0';
		tb2 = F1413_14334(RTCW(loc1));
		if (tb2) {
			tr1 = F1413_14346(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F1306_11476(RTCW(tr1), tr2);
			tr1 = F1338_12441(loc11, tr1);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(1337, 0x01),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F1306_11476(RTCW(tr1), tr2);
				tr1 = F1338_12441(loc12, tr1);
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(1305, 0x01),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				loc2 = RTLNS(eif_new_type(74, 0x01).id, 74, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F1168_10066(RTCW(tr1));
				loc3 = F75_1422(RTCW(loc2), tr1);
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7024[Dtype(RTCW(loc3))-1190])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F1306_11476(RTCW(tr1), tr2);
				tr1 = F1338_12441(loc11, tr1);
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(1305, 0x01),loc14);
				if (EIF_TEST(loc14)) {
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F1168_10066(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F1306_11476(RTCW(tr1), tr2);
				tr1 = F1338_12441(loc11, tr1);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1305, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F1168_10066(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F1306_11476(RTCW(tr1), tr2);
				tr1 = F1338_12441(loc11, tr1);
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(1305, 0x01),loc16);
				if (EIF_TEST(loc16)) {
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1190, 0x01),loc17);
					if (EIF_TEST(loc17)) {
						tr1 = RTLNSMART(eif_new_type(1193, 1).id);
						tr2 = F1306_11489(loc16);
						F1194_10991(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							loc8 = RTLNS(eif_new_type(73, 0x01).id, 73, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F1194_11018(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F1194_11021(RTCW(tr1), tr2);
							tb1 = F77_1439(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F1194_11018(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F1194_11021(RTCW(tr1), tr2);
							}
							tb1 = F77_1439(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								loc9 = F53_1100(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F77_1439(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								loc4 = F74_1420(RTCW(loc8), loc9);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R3790[Dtype(RTCW(loc4))-288])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						tr1 = RTLNSMART(eif_new_type(1193, 1).id);
						tr2 = F1306_11489(loc16);
						F1194_10991(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F1306_11476(RTCW(tr1), tr2);
						tr1 = F1338_12441(loc11, tr1);
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(1337, 0x01),loc18);
						if (EIF_TEST(loc18)) {
							tr1 = F53_1099(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					tr1 = RTLNSMART(eif_new_type(1193, 1).id);
					F1194_10989(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.save */
void F53_1098 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLR(9,loc9);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(loc1), ((EIF_INTEGER_32) 512L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) '{');
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = RTMS_EX_H("\"local-path\": ",14,1095608864);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	loc2 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1194_11030(RTCW(tr1));
	F1306_11477(RTCW(loc2), tr1);
	tr1 = F1306_11490(RTCW(loc2));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_2_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = RTMS_EX_H(", \"package-name\": ",18,1498648352);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
			loc2 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
			F1306_11477(RTCW(loc2), loc6);
			tr1 = F1306_11490(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
			loc7 = tr1;
			if ((EIF_TRUE)) {
				tr1 = RTMS_EX_H(", \"package-id\": ",16,216143648);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
				loc2 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F1306_11476(RTCW(loc2), loc7);
				tr1 = F1306_11490(RTCW(loc2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tr1 = RTMS_EX_H(",",1,44);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		tr1 = RTMS_EX_H("\"repository\": {",15,1526921339);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		tr1 = RTMS_EX_H("\"uri\":",6,1987237946);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		loc2 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = F1429_14879(loc8);
		F1306_11476(RTCW(loc2), tr1);
		tr1 = F1306_11490(RTCW(loc2));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) '}');
	}
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		tr1 = F1193_10974(RTCW(loc5));
		loc9 = tr1;
		tb2 = EIF_TEST(loc9);
	}
	if (tb2) {
		tb2 = F1171_10169(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) ',');
		tr1 = RTMS_EX_H("\"package\":",10,555686458);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
		tr1 = F1168_10060(loc9);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, tr1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) '}');
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1194_11006(RTCW(tr1));
	F53_1101(Current, tr1);
	loc4 = RTLNS(eif_new_type(936, 0x01).id, 936, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F937_8421(RTCW(loc4), *(EIF_REFERENCE *)(Current));
	F936_8266(RTCW(loc4));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(RTCW(loc4))-563])(loc4, loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6250[Dtype(RTCW(loc4))-936])(loc4);
	F936_8279(RTCW(loc4));
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F53_1099 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc1);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLR(20,loc16);
	RTLR(21,loc17);
	RTLR(22,loc18);
	RTLR(23,tr3);
	RTLR(24,loc19);
	RTLR(25,loc20);
	RTLR(26,loc21);
	RTLIU(27);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F1306_11476(RTCW(tr1), tr2);
	tr1 = F1338_12441(RTCW(arg1), tr1);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1305, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1305, 0x01),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(1192, 0x01).id, 1192, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1193_10944(RTCW(Result), tr1, arg2);
		tr1 = F1338_12449(RTCW(arg1));
		tr1 = F1168_10066(RTCW(tr1));
		F1193_10975(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1193_10979(RTCW(Result), tr1);
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1305, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			tr1 = F1306_11489(loc4);
			F1193_10980(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1305, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			tr1 = F1306_11489(loc5);
			F1193_10981(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(1304, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			loc1 = *(EIF_REFERENCE *)(loc6);
			tb1 = F1168_10043(RTCW(loc1));
			if (tb1) {
				tu4_1 = F1168_10077(RTCW(loc1));
				F1193_10982(RTCW(Result), tu4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1305, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1193_10984(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(1305, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1193_10986(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1304, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			loc1 = *(EIF_REFERENCE *)(loc9);
			tb1 = F1168_10038(RTCW(loc1));
			if (tb1) {
				ti4_1 = F1168_10072(RTCW(loc1));
				F1193_10983(RTCW(Result), ti4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1338, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			tr1 = F1339_12476(loc10);
			loc11 = F1059_8922(RTCW(tr1));
			for (;;) {
				tb1 = F659_7888(loc11);
				if (tb1) break;
				tr1 = F659_7879(loc11);
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(1305, 0x01),loc12);
				if (EIF_TEST(loc12)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F1059_8948(RTCW(tr1), tr2);
				}
				F659_7894(loc11);
			}
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(1338, 0x01),loc13);
		if (EIF_TEST(loc13)) {
			tr1 = F1339_12476(loc13);
			loc14 = F1059_8922(RTCW(tr1));
			for (;;) {
				tb2 = F659_7888(loc14);
				if (tb2) break;
				tr1 = F659_7879(loc14);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1305, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					tr2 = F1306_11489(loc15);
					F1059_8948(RTCW(tr1), tr2);
				}
				F659_7894(loc14);
			}
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1337, 0x01),loc16);
		if (EIF_TEST(loc16)) {
			loc17 = F1338_12451(loc16);
			for (;;) {
				tb3 = F650_7876(loc17);
				if (tb3) break;
				tr1 = F650_7873(loc17);
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(1305, 0x01),loc18);
				if (EIF_TEST(loc18)) {
					tr1 = F1306_11489(loc18);
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					tr3 = F650_7874(loc17);
					tr3 = F1306_11489(RTCW(tr3));
					tr2 = F1173_10271(tr2, tr3);
					tr3 = F1168_10066(RTMS_EX_H("]",1,93));
					tr2 = F1173_10271(RTCW(tr2), tr3);
					F1193_10978(RTCW(Result), tr1, tr2);
				}
				F650_7877(loc17);
			}
		}
		tr1 = RTLNS(eif_new_type(1305, 0x00).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F1306_11476(RTCW(tr1), tr2);
		tr1 = F1338_12441(RTCW(arg1), tr1);
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(1337, 0x01),loc19);
		if (EIF_TEST(loc19)) {
			loc20 = F1338_12451(loc19);
			for (;;) {
				tb4 = F650_7876(loc20);
				if (tb4) break;
				tr1 = F650_7873(loc20);
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(1305, 0x01),loc21);
				if (EIF_TEST(loc21)) {
					tr1 = F1306_11489(loc21);
					tr2 = F650_7874(loc20);
					tr2 = F1306_11489(RTCW(tr2));
					F1193_10978(RTCW(Result), tr1, tr2);
				}
				F650_7877(loc20);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F53_1100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F562_6842(RTCW(loc1), arg1);
	tb1 = F562_6865(RTCW(loc1));
	if (tb1) {
		tr1 = F562_6856(RTCW(loc1));
		tr1 = F1059_8922(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F659_7888(loc2);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			tb2 = '\01';
			tr1 = F659_7879(loc2);
			tb3 = F1194_10996(RTCW(tr1));
			if (!tb3) {
				tr1 = F659_7879(loc2);
				tb3 = F1194_10997(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = F659_7879(loc2);
				tr1 = F1194_11008(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F1168_10049(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = F659_7879(loc2);
					Result = F1194_11019(RTCW(arg1), tr1);
				}
			}
			F659_7894(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.ensure_folder_exists */
void F53_1101 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(561, 0x01).id, 561, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F562_6842(RTCW(loc1), arg1);
	tb1 = F562_6865(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		F562_6845(RTCW(loc1));
	}
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F53_1102 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F936_8193(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F936_8227(RTCW(loc1));
	if (tb2) {
		tb2 = F936_8246(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F936_8262(RTCW(loc1));
		Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1174_10304(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			tb1 = F742_7994(RTCW(loc1));
			if (tb1) break;
			F936_8341(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, tr1);
		}
		F936_8279(RTCW(loc1));
	}
	RTLE;
	return Result;
}

void EIF_Minit48 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
