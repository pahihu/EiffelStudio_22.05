
#ifndef _C1_i110_
#define _C1_i110_

#ifdef __cplusplus
extern "C" {
#endif

extern void F15_109(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit10(void);
extern void F151_2449(EIF_REFERENCE, EIF_REFERENCE);
extern long O2259[];
extern long O2260[];

#ifdef __cplusplus
}
#endif

#endif
