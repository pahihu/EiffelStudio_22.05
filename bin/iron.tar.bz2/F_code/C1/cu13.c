/*
 * Code for class CURL_UTILITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cu13.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CURL_UTILITY}.api_loader */
static EIF_REFERENCE F18_126_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(705)

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOTP;
	loc1 = RTLNS(eif_new_type(415, 0x01).id, 415, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tb1 = '\01';
	tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_unix__b;
	if (!tb2) {
		tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(549, 0x01).id, 549, _OBJSIZ_2_0_0_0_0_1_0_0_);
		tr2 = F1168_10066(RTCV(RTOUCR(734,F18_127, (Current))));
		tr3 = F1168_10066(RTMS_EX_H("4",1,52));
		F550_6662(RTCW(tr1), tr2, tr3);
		Result = (EIF_REFERENCE) tr1;
		tb1 = F548_6653(RTCW(Result));
		if ((EIF_BOOLEAN) !tb1) {
			F548_6649(RTCW(Result));
			tr1 = RTLNS(eif_new_type(549, 0x01).id, 549, _OBJSIZ_2_0_0_0_0_1_0_0_);
			tr2 = F1168_10066(RTCV(RTOUCR(734,F18_127, (Current))));
			tr3 = F1168_10066(RTMS_EX_H("3",1,51));
			F550_6662(RTCW(tr1), tr2, tr3);
			Result = (EIF_REFERENCE) tr1;
		}
	} else {
		tr1 = RTLNS(eif_new_type(549, 0x01).id, 549, _OBJSIZ_2_0_0_0_0_1_0_0_);
		tr2 = F1168_10066(RTCV(RTOUCR(734,F18_127, (Current))));
		F550_6661(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F18_126 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(705,F18_126_body,(Current));
}

/* {CURL_UTILITY}.module_name */
static EIF_REFERENCE F18_127_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(734)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("libcurl",7,399537260);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F18_127 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(734,F18_127_body,(Current));
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
