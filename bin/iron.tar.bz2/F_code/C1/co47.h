
#ifndef _C1_co47_
#define _C1_co47_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F52_1076(EIF_REFERENCE);
extern EIF_BOOLEAN F52_1077(EIF_REFERENCE);
extern EIF_BOOLEAN F52_1078(EIF_REFERENCE);
extern EIF_BOOLEAN F52_1079(EIF_REFERENCE, EIF_NATURAL_8);
extern EIF_BOOLEAN F52_1080(EIF_REFERENCE);
extern void F52_1087(EIF_REFERENCE, EIF_BOOLEAN);
extern void F52_1088(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
