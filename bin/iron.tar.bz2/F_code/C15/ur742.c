/*
 * Code for class URI
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ur742.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {URI}.make_from_string */
void F1429_14845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc5);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(arg1))-1174])(arg1, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		F1429_14882(Current, tr1);
		tb1 = '\0';
		tb2 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
		if ((EIF_BOOLEAN) (ti4_1 > (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L))));
			tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
		}
		if (tb2) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L))));
			tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
		}
		if (tb1) {
			loc1 += ((EIF_INTEGER_32) 2L);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(arg1))-1174])(arg1, (EIF_CHARACTER_8) '/', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(arg1))-1174])(arg1, (EIF_CHARACTER_8) '@', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc2 < loc3)))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				loc6 = F1168_10060(RTCW(tr1));
				F1429_14883(Current, loc6);
				loc1 = (EIF_INTEGER_32) loc2;
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(arg1))-1174])(arg1, (EIF_CHARACTER_8) '/', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			} else {
				loc2 = (EIF_INTEGER_32) loc3;
			}
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(arg1))-1174])(arg1, (EIF_CHARACTER_8) '\?', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc4 < loc2)))) {
				loc2 = (EIF_INTEGER_32) loc4;
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				loc6 = F1168_10060(RTCW(tr1));
			} else {
				loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc2);
				loc6 = F1168_10060(RTCW(tr1));
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			tb1 = '\0';
			tb2 = F874_8129(RTCW(loc6));
			if ((EIF_BOOLEAN) !tb2) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(loc6))-960])(loc6, ((EIF_INTEGER_32) 1L)));
				tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '[');
			}
			if (tb1) {
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc6))-1174])(loc6, (EIF_CHARACTER_8) ']', ((EIF_INTEGER_32) 2L));
				if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc6))-1174])(loc6, (EIF_CHARACTER_8) ':', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 = (EIF_INTEGER_32) ti4_1;
				} else {
					*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc6))-1174])(loc6, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
			}
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc6))-1171])(loc6, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				F1429_14884(Current, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8590[Dtype(RTCW(loc6))-1172])(loc6, loc1);
				tb1 = F1168_10038(RTCW(loc6));
				if (tb1) {
					ti4_1 = F1168_10072(RTCW(loc6));
					F1429_14885(Current, ti4_1);
				} else {
					F1429_14885(Current, ((EIF_INTEGER_32) 0L));
					*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				F1429_14884(Current, loc6);
				F1429_14885(Current, ((EIF_INTEGER_32) 0L));
			}
		} else {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
			F1429_14884(Current, NULL);
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
			tb1 = (EIF_BOOLEAN) (loc2 <= ti4_1);
		}
		if (tb1) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc2, ti4_1);
			loc6 = F1168_10060(RTCW(tr1));
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc6))-1174])(loc6, (EIF_CHARACTER_8) '\?', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc6))-1171])(loc6, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				if (F1429_14908(Current, loc5)) {
					F1429_14886(Current, loc5);
				} else {
					tr1 = RTMS_EX_H("",0,0);
					F1429_14886(Current, tr1);
					*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8590[Dtype(RTCW(loc6))-1172])(loc6, loc2);
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R8682[Dtype(RTCW(loc6))-1174])(loc6, (EIF_CHARACTER_8) '#', ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc6))-1171])(loc6, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
					F1429_14889(Current, tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8590[Dtype(RTCW(loc6))-1172])(loc6, loc2);
					F1429_14890(Current, loc6);
				} else {
					F1429_14889(Current, loc6);
				}
			} else {
				if (F1429_14908(Current, loc6)) {
					F1429_14886(Current, loc6);
				} else {
					tr1 = RTMS_EX_H("",0,0);
					F1429_14886(Current, tr1);
					*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		} else {
			tr1 = RTMS_EX_H("",0,0);
			F1429_14886(Current, tr1);
		}
	} else {
		tr1 = RTMS_EX_H("",0,0);
		F1429_14882(Current, tr1);
		F1429_14884(Current, NULL);
		tr1 = RTMS_EX_H("",0,0);
		F1429_14886(Current, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current + O12155[dtype-1428])) {
		F1429_14848(Current, (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {URI}.make_from_uri */
void F1429_14847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O12166[Dtype(arg1)-1428]);
	*(EIF_INTEGER_32 *)(Current + O12166[dtype-1428]) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O12155[Dtype(arg1)-1428]);
	*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O12156[Dtype(arg1)-1428]);
	*(EIF_BOOLEAN *)(Current + O12156[dtype-1428]) = (EIF_BOOLEAN) tb1;
	RTLE;
}

/* {URI}.check_validity */
void F1429_14848 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1429_14896(Current, *(EIF_REFERENCE *)(Current))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	if ((EIF_BOOLEAN) !F1429_14897(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	if ((EIF_BOOLEAN) !F1429_14898(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb2 = F1174_10339(RTCW(tr1), (EIF_CHARACTER_8) ' ');
	if (tb2) {
		tb1 = arg1;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1174_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		tr1 = RTMS_EX_H(" ",1,32);
		tr2 = RTMS_EX_H("%20",3,2437680);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8717[Dtype(RTCW(loc1))-1175])(loc1, tr1, tr2);
		F1429_14886(Current, loc1);
		*(EIF_BOOLEAN *)(Current + O12156[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	if ((EIF_BOOLEAN) !F1429_14899(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb2 = F1174_10339(loc2, (EIF_CHARACTER_8) ' ');
		tb1 = tb2;
	}
	if (tb1) {
		if (arg1) {
			loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1174_10306(RTCW(loc1), loc2);
			tr1 = RTMS_EX_H(" ",1,32);
			tr2 = RTMS_EX_H("%20",3,2437680);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8717[Dtype(RTCW(loc1))-1175])(loc1, tr1, tr2);
			F1429_14889(Current, loc1);
			*(EIF_BOOLEAN *)(Current + O12156[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	if ((EIF_BOOLEAN) !F1429_14900(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	if ((EIF_BOOLEAN) !F1429_14901(Current, *(EIF_REFERENCE *)(Current + _REFACS_5_))) {
		*(EIF_BOOLEAN *)(Current + O12155[dtype-1428]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {URI}.has_authority */
EIF_BOOLEAN F1429_14851 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL);
}

/* {URI}.decoded_path */
EIF_REFERENCE F1429_14864 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
	F1171_10137(RTCW(Result), ti4_1);
	F1429_14906(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), Result);
	RTLE;
	return Result;
}

/* {URI}.path_segments */
EIF_REFERENCE F1429_14865 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1175_10373(RTCW(loc1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1173,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1059_8908(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_0_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tc1 = F1175_10361(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
		}
		if (tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1173,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				Result = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F1059_8908(RTCW(Result), ((EIF_INTEGER_32) 1L));
			tr1 = RTMS_EX_H("",0,0);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(Result))-936])(Result, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			Result = F1168_10085(RTCW(loc1), tw1);
		}
	}
	RTLE;
	return Result;
}

/* {URI}.decoded_path_segments */
EIF_REFERENCE F1429_14869 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1429_14865(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1170,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(loc1))-908])(loc1);
	F1059_8908(RTCW(Result), ti4_1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(loc1))-635])(loc1);
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc2)-515])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
		tr1 = F1429_14907(Current, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(Result))-936])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc2)-515])(loc2);
	}
	RTLE;
	return Result;
}

/* {URI}.hier */
EIF_REFERENCE F1429_14873 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(Result), ((EIF_INTEGER_32) 10L));
	tr1 = F1429_14877(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, loc1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
	return Result;
}

/* {URI}.authority */
EIF_REFERENCE F1429_14877 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1174_10306(RTCW(loc1), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) '@');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc1))-1175])(loc1, loc2);
		} else {
			loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1174_10306(RTCW(loc1), loc2);
		}
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12166[dtype-1428]) != ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) ':');
			F1176_10420(RTCW(loc1), *(EIF_INTEGER_32 *)(Current + O12166[dtype-1428]));
		}
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {URI}.append_to_string */
void F1429_14878 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		tb2 = F1175_10373(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8576[Dtype(RTCW(arg1))-1172])(arg1, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg1))-1172])(arg1, (EIF_NATURAL_32) ((EIF_INTEGER_32) 58L));
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12179[Dtype(Current)-1428])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8576[Dtype(RTCW(arg1))-1172])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg1))-1172])(arg1, (EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8576[Dtype(RTCW(arg1))-1172])(arg1, loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg1))-1172])(arg1, (EIF_NATURAL_32) ((EIF_INTEGER_32) 35L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8576[Dtype(RTCW(arg1))-1172])(arg1, loc3);
	}
	RTLE;
}

/* {URI}.string */
EIF_REFERENCE F1429_14879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	F1429_14878(Current, Result);
	RTLE;
	return Result;
}

/* {URI}.is_same_uri */
EIF_BOOLEAN F1429_14881 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1429_14879(Current);
	tr1 = F1429_14907(Current, tr1);
	tr2 = F1429_14879(RTCW(arg1));
	tr2 = F1429_14907(Current, tr2);
	Result = F1171_10164(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {URI}.set_scheme */
void F1429_14882 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1174, 1).id);
	F1174_10306(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {URI}.set_userinfo */
void F1429_14883 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTLNSMART(eif_new_type(1174, 0).id);
		F1174_10306(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {URI}.set_hostname */
void F1429_14884 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb1 = '\0';
		tr1 = RTMS_EX_H("xn--",4,2020486445);
		tb2 = F1168_10054(RTCW(arg1), tr1);
		if (tb2) {
			tb1 = F1429_14902(Current, arg1);
		}
		if (tb1) {
			tr1 = RTLNSMART(eif_new_type(1174, 0).id);
			tr2 = F1168_10060(RTCW(arg1));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(tr2))-1171])(tr2);
			F1174_10306(RTCW(tr1), tr2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		} else {
			if (F1429_14902(Current, arg1)) {
				tr1 = RTLNSMART(eif_new_type(1174, 0).id);
				tr2 = F1168_10060(RTCW(arg1));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(tr2))-1171])(tr2);
				F1174_10306(RTCW(tr1), tr2);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			} else {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc3 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
				F1174_10304(RTCW(loc3), ti4_1);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
				tr1 = F1168_10085(RTCW(arg1), tw1);
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
				for (;;) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc5)-515])(loc5);
					if (tb1) break;
					if (loc2) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc3))-1175])(loc3, (EIF_CHARACTER_8) '.');
					}
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
					if (F1429_14902(Current, loc4)) {
						tr1 = F1168_10060(RTCW(loc4));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc3))-1175])(loc3, tr1);
					} else {
						tr1 = RTLNS(eif_new_type(81, 0x01).id, 81, _OBJSIZ_0_0_0_0_0_0_0_0_);
						loc1 = F82_1597(RTCW(tr1), loc4);
						tr1 = RTMS_EX_H("xn--",4,2020486445);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc3))-1175])(loc3, tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc3))-1175])(loc3, loc1);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc5)-515])(loc5);
				}
				tr1 = RTLNSMART(eif_new_type(1174, 0).id);
				F1174_10306(RTCW(tr1), loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
}

/* {URI}.set_port */
void F1429_14885 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12166[Dtype(Current)-1428]) = (EIF_INTEGER_32) arg1;
}

/* {URI}.set_path */
void F1429_14886 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1174, 1).id);
	F1174_10306(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {URI}.set_unencoded_path */
void F1429_14887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
	if (tb1) {
		tr1 = RTMS_EX_H("",0,0);
		F1429_14886(Current, tr1);
	} else {
		tb1 = '\0';
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, ((EIF_INTEGER_32) 1L));
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			tr1 = RTMS_EX_H("/",1,47);
			F1429_14886(Current, tr1);
		} else {
			tr1 = RTMS_EX_H("",0,0);
			F1429_14886(Current, tr1);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc2 > loc3))) break;
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R8470[Dtype(RTCW(arg1))-1171])(arg1, tw1, loc2);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, loc1);
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb1 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb1) {
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
				} else {
					if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
						if ((EIF_BOOLEAN)(tw1 != tw2)) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc2, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
							F1429_14888(Current, tr1);
						}
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN)(loc1 == loc3)) {
							tr1 = RTMS_EX_H("",0,0);
							F1429_14888(Current, tr1);
						}
					} else {
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc2, loc3);
							F1429_14888(Current, tr1);
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {URI}.add_unencoded_path_segment */
void F1429_14888 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb2 = F1175_10373(RTCW(tr1));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1429_14851(Current);
	}
	if (tb1) {
		tr1 = F1429_14905(Current, arg1);
		F1429_14886(Current, tr1);
	} else {
		loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1174_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc1))-1175])(loc1, (EIF_CHARACTER_8) '/');
		F203_3019(Current, arg1, loc1);
		F1429_14886(Current, loc1);
	}
	RTLE;
}

/* {URI}.set_query */
void F1429_14889 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTLNSMART(eif_new_type(1174, 0).id);
		F1174_10306(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {URI}.set_fragment */
void F1429_14890 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTLNSMART(eif_new_type(1174, 0).id);
		F1174_10306(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {URI}.is_valid_scheme */
EIF_BOOLEAN F1429_14896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		tw1 = F1429_14903(Current, arg1, loc1);
		Result = F203_3033(Current, tw1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
			loc3 = F1429_14903(Current, arg1, loc1);
			Result = '\01';
			tb1 = '\01';
			tb2 = '\01';
			if (!F203_3032(Current, loc3)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb1 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (!tb1) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
				Result = (EIF_BOOLEAN)(loc3 == tw1);
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {URI}.is_valid_userinfo */
EIF_BOOLEAN F1429_14897 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
			loc3 = F1429_14903(Current, arg1, loc1);
			tb1 = '\01';
			tb2 = '\01';
			if (!F203_3035(Current, loc3)) {
				tb2 = F203_3038(Current, loc3);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
				tb1 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (tb1) {
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '%';
				if ((EIF_BOOLEAN)(loc3 == tw1)) {
					tb1 = '\0';
					tb2 = '\0';
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
						tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tb2 = F203_3031(Current, tw1);
					}
					if (tb2) {
						tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						tb1 = F203_3031(Current, tw1);
					}
					if (tb1) {
						loc1 += ((EIF_INTEGER_32) 2L);
					} else {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				} else {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {URI}.is_valid_host */
EIF_BOOLEAN F1429_14898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {URI}.is_valid_path */
EIF_BOOLEAN F1429_14899 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
	if (!tb2) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
		tb1 = (EIF_BOOLEAN)(F1429_14903(Current, arg1, ((EIF_INTEGER_32) 1L)) == tw1);
	}
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F1429_14908(Current, arg1);
	} else {
		if (F1429_14851(Current)) {
			tb1 = '\0';
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			if ((EIF_BOOLEAN)(F1429_14903(Current, arg1, ((EIF_INTEGER_32) 1L)) == tw1)) {
				tb2 = '\01';
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb2 = (EIF_BOOLEAN)(F1429_14903(Current, arg1, ((EIF_INTEGER_32) 2L)) != tw1);
				}
				tb1 = tb2;
			}
			if (tb1) {
				Result = F1429_14908(Current, arg1);
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg1))-1171])(arg1);
			if (tb1) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				Result = F1429_14908(Current, arg1);
				RTLE;
				return (EIF_BOOLEAN) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {URI}.is_valid_query */
EIF_BOOLEAN F1429_14900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
			loc3 = F1429_14903(Current, arg1, loc1);
			tb1 = '\01';
			tb2 = '\01';
			tb3 = '\01';
			if (!F203_3035(Current, loc3)) {
				tb3 = F203_3038(Current, loc3);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
				tb2 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '@';
				tb1 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = '\01';
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
				if (!(EIF_BOOLEAN)(loc3 == tw1)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
					tb1 = (EIF_BOOLEAN)(loc3 == tw1);
				}
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '%';
					if ((EIF_BOOLEAN)(loc3 == tw1)) {
						tb1 = '\0';
						tb2 = '\0';
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
							tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							tb2 = F203_3031(Current, tw1);
						}
						if (tb2) {
							tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
							tb1 = F203_3031(Current, tw1);
						}
						if (tb1) {
							loc1 += ((EIF_INTEGER_32) 2L);
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				}
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {URI}.is_valid_fragment */
EIF_BOOLEAN F1429_14901 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
			loc3 = F1429_14903(Current, arg1, loc1);
			tb1 = '\01';
			tb2 = '\01';
			tb3 = '\01';
			if (!F203_3035(Current, loc3)) {
				tb3 = F203_3038(Current, loc3);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
				tb2 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '@';
				tb1 = (EIF_BOOLEAN)(loc3 == tw1);
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = '\01';
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
				if (!(EIF_BOOLEAN)(loc3 == tw1)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
					tb1 = (EIF_BOOLEAN)(loc3 == tw1);
				}
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '%';
					if ((EIF_BOOLEAN)(loc3 == tw1)) {
						tb1 = '\0';
						tb2 = '\0';
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)) <= loc2)) {
							tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							tb2 = F203_3032(Current, tw1);
						}
						if (tb2) {
							tw1 = F1429_14903(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
							tb1 = F203_3032(Current, tw1);
						}
						if (tb1) {
							loc1 += ((EIF_INTEGER_32) 2L);
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				}
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {URI}.is_ascii_string */
EIF_BOOLEAN F1429_14902 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu4_1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L));
		loc1++;
	}
	RTLE;
	return Result;
}

/* {URI}.string_item */
EIF_CHARACTER_32 F1429_14903 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, arg2);
	Result = (EIF_CHARACTER_32) tu4_1;
	RTLE;
	return Result;
}

/* {URI}.append_www_form_urlencoded_string_to */
void F1429_14904 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F203_3020(Current, arg1, arg2);
}

/* {URI}.www_form_urlencoded_string */
EIF_REFERENCE F1429_14905 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	F1174_10304(RTCW(Result), ti4_1);
	F1429_14904(Current, arg1, Result);
	RTLE;
	return Result;
}

/* {URI}.append_decoded_www_form_urlencoded_string_to */
void F1429_14906 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F203_3028(Current, arg1, arg2);
}

/* {URI}.decoded_www_form_urlencoded_string */
EIF_REFERENCE F1429_14907 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	F1171_10137(RTCW(Result), ti4_1);
	F203_3028(Current, arg1, Result);
	RTLE;
	return Result;
}

/* {URI}.is_valid_in_uri_string */
EIF_BOOLEAN F1429_14908 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		if ((EIF_BOOLEAN) (tu4_1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit742 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
