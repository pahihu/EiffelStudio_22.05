/*
 * Code for class ES_IRON_CLIENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "es717.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ES_IRON_CLIENT}.initialize_iron */
void F1404_13622 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tr1 = F1110_9543(RTCW(tr1));
	tb2 = F870_8129(RTCW(tr1));
	if (tb2) {
		tb1 = F450_5994(Current);
	}
	if (tb1) {
		tr1 = RTMS_EX_H("First initialization with default repository...\012",48,958620938);
		F1402_13608(Current, tr1);
		loc2 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1174_10304(RTCW(loc2), ((EIF_INTEGER_32) 5L));
		tr1 = RTOUCR(0,F305_4199, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc2))-1175])(loc2, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc2))-1175])(loc2, (EIF_CHARACTER_8) '.');
		tr1 = RTOUCR(1,F305_4200, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc2))-1175])(loc2, tr1);
		loc1 = RTLNS(eif_new_type(1194, 0x01).id, 1194, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = RTLNS(eif_new_type(1428, 0x01).id, 1428, _OBJSIZ_6_2_0_1_0_0_0_0_);
		tr2 = RTMS_EX_H("https://iron.eiffel.com/",24,1561405743);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr2)-1174])(tr2, loc2);
		F1429_14845(RTCW(tr1), tr2);
		F1195_11052(RTCW(loc1), tr1);
		tr1 = F713_7961(RTCW(loc1));
		tr1 = F306_4233(Current, tr1);
		F1402_13608(Current, tr1);
		F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		F1110_9548(RTCW(tr1), loc1);
		tr1 = F306_4231(Current);
		F1402_13608(Current, tr1);
		F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		F1110_9541(RTCW(tr1));
		F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
	}
	RTLE;
}

/* {ES_IRON_CLIENT}.iron_layout */
EIF_REFERENCE F1404_13623 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !F450_5994(Current)) {
		loc1 = RTLNS(eif_new_type(1448, 0x01).id, 1448, _OBJSIZ_0_3_0_0_0_0_0_0_);
		F1448_15059(RTCW(loc1));
		F450_5995(Current, loc1);
	}
	Result = RTLNS(eif_new_type(1103, 0x01).id, 1103, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr1 = F450_5996(Current);
	F1104_9376(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {ES_IRON_CLIENT}.tasks */
static EIF_REFERENCE F1404_13624_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3)
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(4,F1403_13617, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1445,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1445,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A717_140_2, (EIF_POINTER) _A717_140_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("install package",15,901432421);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(5,F1445_15019, (Current));
	F961_8607(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1443,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1443,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A717_141_2, (EIF_POINTER) _A717_141_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("create or update package.iron file for a folder.",48,1390505518);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(6,F1444_15009, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1442,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1442,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A717_142_2, (EIF_POINTER) _A717_142_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("Update the given Eiffel Configuration File (.ecf) to use IRON references.",73,2108958510);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(7,F1443_14988, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1404_13624 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3,F1404_13624_body,(Current));
}

/* {ES_IRON_CLIENT}.inline-agent#1 of tasks */
EIF_REFERENCE F1404_15613 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1445, 0x01).id, 1445, _OBJSIZ_3_4_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ES_IRON_CLIENT}.inline-agent#2 of tasks */
EIF_REFERENCE F1404_15614 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_1_4_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ES_IRON_CLIENT}.inline-agent#3 of tasks */
EIF_REFERENCE F1404_15615 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1442, 0x01).id, 1442, _OBJSIZ_1_3_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ES_IRON_CLIENT}.inline-agent#4 of tasks */
EIF_REFERENCE F1404_15616 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1441, 0x01).id, 1441, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit717 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
