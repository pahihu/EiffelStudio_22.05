/*
 * Code for class IRON_SHARE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir746.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_SHARE_TASK}.name */

EIF_REFERENCE F1433_14949 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (46,RTMS_EX_H("share",5,1752099941));
}

/* {IRON_SHARE_TASK}.process */
void F1433_14950 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(482, 0x01).id, 482, _OBJSIZ_5_12_0_0_0_0_0_0_);
	F325_4593(RTCW(loc1), Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1113,0xFF01,0,0xFF01,481,0xFF01,100,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	((EIF_TYPED_VALUE *)tr1+3)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,0,1113,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A746_89, (EIF_POINTER) _A746_89, (EIF_POINTER)(F1433_14951),tr1, 1, 0);
	}
	F320_4507(RTCW(loc1), tr2);
	RTLE;
}

/* {IRON_SHARE_TASK}.execute */
void F1433_14951 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc20 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(37);
	RTLR(0,loc12);
	RTLR(1,arg1);
	RTLR(2,loc13);
	RTLR(3,loc14);
	RTLR(4,loc21);
	RTLR(5,tr1);
	RTLR(6,loc15);
	RTLR(7,loc22);
	RTLR(8,loc2);
	RTLR(9,loc23);
	RTLR(10,arg2);
	RTLR(11,loc11);
	RTLR(12,tr2);
	RTLR(13,loc1);
	RTLR(14,Current);
	RTLR(15,loc9);
	RTLR(16,loc8);
	RTLR(17,loc10);
	RTLR(18,loc24);
	RTLR(19,loc25);
	RTLR(20,loc5);
	RTLR(21,loc26);
	RTLR(22,loc27);
	RTLR(23,loc28);
	RTLR(24,loc29);
	RTLR(25,loc30);
	RTLR(26,loc31);
	RTLR(27,loc3);
	RTLR(28,loc18);
	RTLR(29,loc32);
	RTLR(30,loc33);
	RTLR(31,loc34);
	RTLR(32,loc19);
	RTLR(33,loc35);
	RTLR(34,loc16);
	RTLR(35,loc36);
	RTLR(36,loc37);
	RTLIU(37);
	
	RTGC;
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc12 = F483_6230(RTCW(arg1));
	loc13 = F483_6231(RTCW(arg1));
	loc14 = F483_6246(RTCW(arg1));
	tr1 = F483_6229(RTCW(arg1));
	loc21 = tr1;
	if (EIF_TEST(loc21)) {
		loc15 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F948_8539(RTCW(loc15), loc21);
		if ((EIF_BOOLEAN)(loc12 == NULL)) {
			tr1 = RTMS_EX_H("username",8,1977725541);
			loc12 = F948_8542(RTCW(loc15), tr1);
		}
		if ((EIF_BOOLEAN)(loc13 == NULL)) {
			tr1 = RTMS_EX_H("password",8,1686242660);
			loc13 = F948_8542(RTCW(loc15), tr1);
		}
		if ((EIF_BOOLEAN)(loc14 == NULL)) {
			tr1 = RTMS_EX_H("repository",10,818164089);
			loc14 = F948_8542(RTCW(loc15), tr1);
		}
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc12 != NULL) && (EIF_BOOLEAN)(loc13 != NULL)) && (EIF_BOOLEAN)(loc14 != NULL))) {
		tr1 = F483_6245(RTCW(arg1));
		loc22 = tr1;
		tb1 = EIF_TEST(loc22);
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1428, 0x01).id, 1428, _OBJSIZ_6_2_0_1_0_0_0_0_);
		tr1 = F1168_10060(RTCW(loc14));
		F1429_14845(RTCW(loc2), tr1);
		tb1 = '\0';
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc2) + O12155[Dtype(loc2)-1428]);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
			tr1 = F1110_9545(RTCW(tr1), loc2);
			loc23 = tr1;
			loc23 = RTRV(eif_new_type(1194, 0x01),loc23);
			tb1 = EIF_TEST(loc23);
		}
		if (tb1) {
			loc11 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_4_1_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
			tr2 = RTOUCR(31,F101_1890, (RTCW(arg2)));
			F1098_9282(RTCW(loc11), tr1, tr2, loc23);
			loc1 = F1433_14954(Current, arg1);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				loc9 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
				loc8 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
				loc10 = *(EIF_REFERENCE *)(RTCW(loc1));
				tr1 = F483_6238(RTCW(arg1));
				loc24 = tr1;
				if (EIF_TEST(loc24)) {
					loc25 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc24)-635])(loc24);
					for (;;) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc25)-515])(loc25);
						if (tb1) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc25)-515])(loc25);
						F60_1259(RTCW(loc1), tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc25)-515])(loc25);
					}
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				F1110_9542(RTCW(tr1), loc23, (EIF_BOOLEAN) 1);
				if ((EIF_BOOLEAN)(loc9 != NULL)) {
					loc5 = F1433_14955(Current, loc23, loc9);
				} else {
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						loc5 = F713_7964(loc23, loc10);
					}
				}
				loc17 = '\01';
				tb2 = '\01';
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					tb4 = F1193_10949(RTCW(loc5));
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				if (!tb3) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
					tb2 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (!tb2) {
					tb2 = F483_6239(RTCW(arg1));
					loc17 = tb2;
				}
				if (loc6) {
				} else {
					tb2 = F483_6243(RTCW(arg1));
					if (tb2) {
						if ((EIF_BOOLEAN)(loc5 != NULL)) {
							F1098_9293(RTCW(loc11), loc5, loc12, loc13);
							tb2 = *(EIF_BOOLEAN *)(RTCW(loc11)+ _CHROFF_4_0_);
							if (tb2) {
								tr1 = RTMS_EX_H("Package successfully deleted.",29,1305340974);
								F1402_13608(Current, tr1);
								F1432_14947(Current);
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
								loc26 = tr1;
								if (EIF_TEST(loc26)) {
									F1402_13608(Current, loc26);
								} else {
									tr1 = RTMS_EX_H("[Error] deletion failed!",24,1795790113);
									F1402_13608(Current, tr1);
								}
								F1432_14947(Current);
								loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						} else {
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000\"\000\000\000",38,2052347426);
								tr1 = F1173_10271(tr1, loc9);
								tr2 = F1168_10066(RTMS_EX_H("\" !",3,2236449));
								tr1 = F1173_10271(RTCW(tr1), tr2);
								F1402_13608(Current, tr1);
							} else {
								if ((EIF_BOOLEAN)(loc10 != NULL)) {
									tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000i\000\000\000d\000\000\000 \000\000\000\"\000\000\000",40,533482786);
									tr1 = F1173_10271(tr1, loc10);
									tr2 = F1168_10066(RTMS_EX_H("\" !",3,2236449));
									tr1 = F1173_10271(RTCW(tr1), tr2);
									F1402_13608(Current, tr1);
								} else {
									tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000!\000\000\000",32,1160338465);
									F1402_13608(Current, tr1);
								}
							}
							F1432_14947(Current);
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					} else {
						tb2 = F483_6240(RTCW(arg1));
						if (tb2) {
							if ((EIF_BOOLEAN)(loc5 != NULL)) {
								loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								if ((EIF_BOOLEAN)(loc9 != NULL)) {
									tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000a\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000\"\000\000\000",29,239172130);
									tr1 = F1173_10271(tr1, loc9);
									tr2 = F1168_10066(RTMS_EX_H("\" already exists!",17,1376193825));
									tr1 = F1173_10271(RTCW(tr1), tr2);
									F1402_13608(Current, tr1);
								} else {
									tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000p\000\000\000l\000\000\000e\000\000\000a\000\000\000s\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000v\000\000\000i\000\000\000d\000\000\000e\000\000\000 \000\000\000a\000\000\000 \000\000\000n\000\000\000o\000\000\000n\000\000\000 \000\000\000e\000\000\000m\000\000\000p\000\000\000t\000\000\000y\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000!\000\000\000",40,1590767393);
									F1402_13608(Current, tr1);
								}
								F1432_14947(Current);
							}
						} else {
							tb2 = F483_6241(RTCW(arg1));
							if (tb2) {
								if ((EIF_BOOLEAN)(loc5 == NULL)) {
									loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									if ((EIF_BOOLEAN)(loc9 != NULL)) {
										tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000\"\000\000\000",38,2052347426);
										tr1 = F1173_10271(tr1, loc9);
										tr2 = F1168_10066(RTMS_EX_H("\" !",3,2236449));
										tr1 = F1173_10271(RTCW(tr1), tr2);
										F1402_13608(Current, tr1);
									} else {
										if ((EIF_BOOLEAN)(loc10 != NULL)) {
											tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000i\000\000\000d\000\000\000 \000\000\000\"\000\000\000",40,533482786);
											tr1 = F1173_10271(tr1, loc10);
											tr2 = F1168_10066(RTMS_EX_H("\" !",3,2236449));
											tr1 = F1173_10271(RTCW(tr1), tr2);
											F1402_13608(Current, tr1);
										} else {
											tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000]\000\000\000 \000\000\000C\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000!\000\000\000",32,1160338465);
											F1402_13608(Current, tr1);
										}
									}
									F1432_14947(Current);
								} else {
									loc10 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
									F1173_10213(RTCW(loc10), tr1);
								}
							} else {
								loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								tr1 = RTMS32_EX_H("[\000\000\000",1,91);
								tr1 = F1173_10271(tr1, loc22);
								tr2 = RTMS32_EX_H("]\000\000\000 \000\000\000N\000\000\000o\000\000\000t\000\000\000 \000\000\000y\000\000\000e\000\000\000t\000\000\000 \000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000!\000\000\000",20,1245013281);
								tr1 = F1173_10271(RTCW(tr1), tr2);
								F1402_13608(Current, tr1);
								F1432_14947(Current);
							}
						}
					}
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 && (EIF_BOOLEAN) !loc6)) {
					if ((EIF_BOOLEAN)(loc5 == NULL)) {
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							tr1 = RTMS32_EX_H("C\000\000\000r\000\000\000e\000\000\000a\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000e\000\000\000w\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000\"\000\000\000",20,1462605602);
							tr1 = F1173_10271(tr1, loc9);
							tr2 = F1168_10066(RTMS_EX_H("\"\012",2,8714));
							tr1 = F1173_10271(RTCW(tr1), tr2);
							F1402_13608(Current, tr1);
						} else {
							tr1 = RTMS32_EX_H("C\000\000\000r\000\000\000e\000\000\000a\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000e\000\000\000w\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000\012\000\000\000",20,1462605578);
							F1402_13608(Current, tr1);
						}
					} else {
						tr1 = RTMS32_EX_H("U\000\000\000p\000\000\000d\000\000\000a\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000",15,1450212128);
						tr2 = F1193_10958(RTCW(loc5));
						tr1 = F1173_10271(tr1, tr2);
						tr2 = RTMS32_EX_H(" \000\000\000\012\000\000\000",2,8202);
						tr1 = F1173_10271(RTCW(tr1), tr2);
						F1402_13608(Current, tr1);
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
					tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
					F1098_9290(RTCW(loc11), loc10, loc9, loc8, tr1, tr2, loc5, NULL, loc12, loc13);
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc11)+ _CHROFF_4_0_);
					if (tb2) {
						if ((EIF_BOOLEAN)(loc5 != NULL)) {
							tr1 = RTMS32_EX_H("P\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000",8,1277724704);
							tr2 = F1193_10958(RTCW(loc5));
							tr1 = F1173_10271(tr1, tr2);
							tr2 = RTMS32_EX_H(" \000\000\000u\000\000\000p\000\000\000d\000\000\000a\000\000\000t\000\000\000e\000\000\000d\000\000\000.\000\000\000",9,306559534);
							tr1 = F1173_10271(RTCW(tr1), tr2);
							F1402_13608(Current, tr1);
							F1432_14947(Current);
						} else {
							tr1 = RTMS32_EX_H("P\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000c\000\000\000r\000\000\000e\000\000\000a\000\000\000t\000\000\000e\000\000\000d\000\000\000.\000\000\000",16,1316677422);
							F1402_13608(Current, tr1);
							F1432_14947(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
							F1110_9542(RTCW(tr1), loc23, (EIF_BOOLEAN) 1);
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								loc5 = F1433_14955(Current, loc23, loc9);
							} else {
								loc5 = (EIF_REFERENCE) NULL;
								loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
						loc27 = tr1;
						if (EIF_TEST(loc27)) {
							F1402_13608(Current, loc27);
						} else {
							tr1 = RTMS_EX_H("[Error] operation failed!",25,579461921);
							F1402_13608(Current, tr1);
						}
						F1432_14947(Current);
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc6 && (EIF_BOOLEAN)(loc5 != NULL))) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_7_);
						loc28 = tr1;
						if (EIF_TEST(loc28)) {
							tr1 = RTMS32_EX_H("A\000\000\000d\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000d\000\000\000e\000\000\000x\000\000\000e\000\000\000s\000\000\000:\000\000\000\012\000\000\000",16,235936778);
							F1402_13608(Current, tr1);
							F1059_8939(loc28);
							for (;;) {
								tb2 = F1030_8827(loc28);
								if (tb2) break;
								tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000-\000\000\000 \000\000\000",4,538979616);
								tr2 = F1059_8913(loc28);
								tr1 = F1173_10271(tr1, tr2);
								F1402_13608(Current, tr1);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_5_);
								loc29 = F1059_8922(RTCW(tr1));
								tb3 = EIF_FALSE;
								for (;;) {
									if (tb3) break;
									tb4 = F659_7888(loc29);
									if (tb4) break;
									tr1 = F659_7879(loc29);
									tr2 = F1059_8913(loc28);
									tr2 = F1168_10063(RTCW(tr2));
									tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(RTCW(tr1))-1174])(tr1, tr2);
									tb3 = tb5;
									F659_7894(loc29);
								}
								if (tb3) {
									(FUNCTION_CAST(void, (EIF_REFERENCE)) R7082[Dtype(loc28)-908])(loc28);
									tr1 = RTMS_EX_H(" : already associated (skipped)",31,1490583081);
									F1402_13608(Current, tr1);
								} else {
									F1059_8941(loc28);
								}
								F1432_14947(Current);
							}
							tb3 = F870_8129(loc28);
							if (tb3) {
								tr1 = RTMS_EX_H("Package has no new index.",25,823330606);
								F1402_13608(Current, tr1);
							} else {
								F1098_9291(RTCW(loc11), loc5, loc28, loc12, loc13);
								tb3 = *(EIF_BOOLEAN *)(RTCW(loc11)+ _CHROFF_4_0_);
								if (tb3) {
									ti4_1 = F1059_8929(loc28);
									if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
										tr1 = RTMS_EX_H("Package successfully associated with indexes!",45,2124396321);
										F1402_13608(Current, tr1);
									} else {
										tr1 = RTMS_EX_H("Package successfully associated with index!",43,1321104673);
										F1402_13608(Current, tr1);
									}
									F1432_14947(Current);
								} else {
									tr1 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
									loc30 = tr1;
									if (EIF_TEST(loc30)) {
										F1402_13608(Current, loc30);
									} else {
										tr1 = RTMS_EX_H("[Error] path association failed!",32,708063777);
										F1402_13608(Current, tr1);
									}
									F1432_14947(Current);
									loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								}
							}
						}
						if (loc17) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
							loc31 = tr1;
							if (EIF_TEST(loc31)) {
								loc3 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
								tr1 = RTMS_EX_H("tmp_archive_",12,1475031135);
								tr2 = RTLNS(eif_new_type(62, 0x01).id, 62, _OBJSIZ_0_0_0_0_0_0_0_0_);
								tr2 = F63_1297(RTCW(tr2));
								tr2 = F1187_10662(RTCW(tr2));
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
								F1194_10991(RTCW(loc3), tr1);
								tr1 = RTMS32_EX_H("B\000\000\000u\000\000\000i\000\000\000l\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000t\000\000\000h\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000c\000\000\000h\000\000\000i\000\000\000v\000\000\000e\000\000\000 \000\000\000f\000\000\000r\000\000\000o\000\000\000m\000\000\000 \000\000\000f\000\000\000o\000\000\000l\000\000\000d\000\000\000e\000\000\000r\000\000\000 \000\000\000\"\000\000\000",34,2083740962);
								tr2 = F1194_11030(loc31);
								tr1 = F1173_10271(tr1, tr2);
								tr2 = RTMS32_EX_H("\"\000\000\000 \000\000\000\012\000\000\000",3,2236426);
								tr1 = F1173_10271(RTCW(tr1), tr2);
								F1402_13608(Current, tr1);
								tr1 = RTLNS(eif_new_type(1096, 0x01).id, 1096, _OBJSIZ_0_0_0_0_0_0_0_0_);
								tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
								loc18 = F1097_9274(RTCW(tr1), loc5, loc31, loc3, tr2);
								tb3 = '\01';
								if (!(EIF_BOOLEAN)(loc18 == NULL)) {
									tb4 = F59_1225(RTCW(loc18));
									tb3 = (EIF_BOOLEAN) !tb4;
								}
								if (tb3) {
									tr1 = RTMS_EX_H("[Error] Failure occured during package archive creation!\012",57,233979658);
									F1402_13608(Current, tr1);
								}
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
								loc32 = tr1;
								if (EIF_TEST(loc32)) {
									loc18 = RTLNS(eif_new_type(58, 0x01).id, 58, _OBJSIZ_3_0_0_1_0_0_0_0_);
									F59_1221(RTCW(loc18), loc32);
								}
							}
							if ((EIF_BOOLEAN)(loc18 != NULL)) {
								tb3 = F59_1225(RTCW(loc18));
								if (tb3) {
									tb3 = '\0';
									tb4 = '\0';
									tb5 = '\0';
									tb6 = F1193_10949(RTCW(loc5));
									if (tb6) {
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_10_0_0_1_);
										ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc18)+ _LNGOFF_3_0_0_0_);
										tb5 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
									}
									if (tb5) {
										tb5 = '\0';
										tr1 = F1193_10968(RTCW(loc5));
										loc33 = tr1;
										if (EIF_TEST(loc33)) {
											tr1 = F59_1228(RTCW(loc18));
											loc34 = tr1;
											tb5 = EIF_TEST(loc34);
										}
										tb4 = tb5;
									}
									if (tb4) {
										tb4 = F1168_10049(loc33, loc34);
										tb3 = tb4;
									}
									if (tb3) {
										tr1 = RTMS_EX_H("Package archive is already uploaded (",37,447624488);
										F1402_13608(Current, tr1);
										tr1 = RTMS_EX_H(" size=",6,1833426749);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc18)+ _LNGOFF_3_0_0_0_);
										tr2 = eif_out__i4_s1(ti4_1);
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
										F1402_13608(Current, tr1);
										tr1 = RTMS_EX_H(" hash=",6,1698666557);
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc34);
										F1402_13608(Current, tr1);
										tr1 = RTMS_EX_H(" ).",3,2107694);
										F1402_13608(Current, tr1);
										F1432_14947(Current);
									} else {
										tb3 = F481_6205(RTCW(arg1));
										if (tb3) {
											tr1 = RTMS_EX_H("Computing the archive hash (sha1) ...\012",38,1483972618);
											F1402_13608(Current, tr1);
											loc19 = F59_1228(RTCW(loc18));
										} else {
											loc19 = (EIF_REFERENCE) NULL;
										}
										tr1 = RTMS_EX_H("Uploading package archive [size=",32,981187389);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc18)+ _LNGOFF_3_0_0_0_);
										tr2 = eif_out__i4_s1(ti4_1);
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
										tr2 = RTMS_EX_H("]",1,93);
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
										F1402_13608(Current, tr1);
										if ((EIF_BOOLEAN)(loc19 != NULL)) {
											tr1 = RTMS_EX_H(" [",2,8283);
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc19);
											tr2 = RTMS_EX_H("]",1,93);
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
											F1402_13608(Current, tr1);
										}
										tr1 = RTMS_EX_H("...\012",4,774778378);
										F1402_13608(Current, tr1);
										tb3 = F1193_10949(RTCW(loc5));
										if (tb3) {
											tr1 = RTMS_EX_H(" -> replacing previous archive [size=",37,889528893);
											ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_10_0_0_1_);
											tr2 = eif_out__i4_s1(ti4_1);
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
											F1402_13608(Current, tr1);
											tr1 = F1193_10968(RTCW(loc5));
											loc35 = tr1;
											if (EIF_TEST(loc35)) {
												tr1 = RTMS_EX_H(" hash=",6,1698666557);
												tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc35);
												F1402_13608(Current, tr1);
											}
											tr1 = RTMS_EX_H(" ].",3,2121006);
											F1402_13608(Current, tr1);
											F1432_14947(Current);
										}
										{
											static EIF_TYPE_INDEX typarr0[] = {0xFF01,206,1173,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											loc16 = RTLNS(typres0.id, 206, _OBJSIZ_1_0_0_0_0_0_0_0_);
										}
										F207_3115(RTCW(loc16), NULL);
										F1098_9292(RTCW(loc11), loc5, loc18, loc12, loc13, loc16);
										tb3 = *(EIF_BOOLEAN *)(RTCW(loc11)+ _CHROFF_4_0_);
										if (tb3) {
											tr1 = RTMS_EX_H("Archive successfully uploaded!",30,513945121);
											F1402_13608(Current, tr1);
											F1432_14947(Current);
										} else {
											tr1 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
											loc36 = tr1;
											if (EIF_TEST(loc36)) {
												F1402_13608(Current, loc36);
											} else {
												tr1 = RTMS_EX_H("[Error] Archive uploading failed!",33,258527521);
												F1402_13608(Current, tr1);
											}
											F1432_14947(Current);
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										}
										tb3 = F481_6205(RTCW(arg1));
										if (tb3) {
											tr1 = *(EIF_REFERENCE *)(RTCW(loc16));
											loc37 = tr1;
											if (EIF_TEST(loc37)) {
												F1402_13608(Current, loc37);
												F1432_14947(Current);
											}
										}
									}
									if (loc4) {
										F59_1231(RTCW(loc18));
									}
								} else {
									tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000a\000\000\000b\000\000\000l\000\000\000e\000\000\000 \000\000\000t\000\000\000o\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000p\000\000\000a\000\000\000c\000\000\000k\000\000\000a\000\000\000g\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000c\000\000\000h\000\000\000i\000\000\000v\000\000\000e\000\000\000 \000\000\000\"\000\000\000",32,1005635874);
									tr2 = *(EIF_REFERENCE *)(RTCW(loc18));
									tr2 = F1194_11030(RTCW(tr2));
									tr1 = F1173_10271(tr1, tr2);
									tr2 = F1168_10066(RTMS_EX_H("\"!",2,8737));
									tr1 = F1173_10271(RTCW(tr1), tr2);
									F1402_13608(Current, tr1);
									F1432_14947(Current);
								}
							}
						}
					}
				}
			} else {
				tr1 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000i\000\000\000n\000\000\000p\000\000\000u\000\000\000t\000\000\000 \000\000\000d\000\000\000a\000\000\000t\000\000\000a\000\000\000!\000\000\000",30,1680643617);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			}
		} else {
			tr1 = RTMS32_EX_H("R\000\000\000e\000\000\000p\000\000\000o\000\000\000s\000\000\000i\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000 \000\000\000u\000\000\000r\000\000\000l\000\000\000 \000\000\000[\000\000\000",16,1739758427);
			tr1 = F1173_10271(tr1, loc14);
			tr2 = F1168_10066(RTMS_EX_H("] is unknown or invalid!",24,1795367201));
			tr1 = F1173_10271(RTCW(tr1), tr2);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
			tr1 = RTMS32_EX_H("h\000\000\000i\000\000\000n\000\000\000t\000\000\000:\000\000\000 \000\000\000i\000\000\000r\000\000\000o\000\000\000n\000\000\000 \000\000\000r\000\000\000e\000\000\000p\000\000\000o\000\000\000s\000\000\000i\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000 \000\000\000-\000\000\000-\000\000\000a\000\000\000d\000\000\000d\000\000\000 \000\000\000",28,1350706720);
			tr1 = F1173_10271(tr1, loc14);
			tr2 = F1168_10066(RTMS_EX_H(" !",2,8225));
			tr1 = F1173_10271(RTCW(tr1), tr2);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
		}
	} else {
		loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		if ((EIF_BOOLEAN)(loc12 == NULL)) {
			loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000R\000\000\000R\000\000\000O\000\000\000R\000\000\000]\000\000\000 \000\000\000M\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000r\000\000\000e\000\000\000q\000\000\000u\000\000\000i\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000\"\000\000\000u\000\000\000s\000\000\000e\000\000\000r\000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000\"\000\000\000!\000\000\000",45,1104616225);
			F1402_13608(Current, tr1);
		}
		if ((EIF_BOOLEAN)(loc13 == NULL)) {
			loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000R\000\000\000R\000\000\000O\000\000\000R\000\000\000]\000\000\000 \000\000\000M\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000r\000\000\000e\000\000\000q\000\000\000u\000\000\000i\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000\"\000\000\000p\000\000\000a\000\000\000s\000\000\000s\000\000\000w\000\000\000o\000\000\000r\000\000\000d\000\000\000\"\000\000\000!\000\000\000",45,315419169);
			F1402_13608(Current, tr1);
		}
		if ((EIF_BOOLEAN)(loc14 == NULL)) {
			loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000R\000\000\000R\000\000\000O\000\000\000R\000\000\000]\000\000\000 \000\000\000M\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000r\000\000\000e\000\000\000q\000\000\000u\000\000\000i\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000\"\000\000\000r\000\000\000e\000\000\000p\000\000\000o\000\000\000s\000\000\000i\000\000\000t\000\000\000o\000\000\000r\000\000\000y\000\000\000\"\000\000\000!\000\000\000",47,1130432289);
			F1402_13608(Current, tr1);
		}
		tr1 = F483_6245(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000R\000\000\000R\000\000\000O\000\000\000R\000\000\000]\000\000\000 \000\000\000M\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000r\000\000\000e\000\000\000q\000\000\000u\000\000\000i\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000\"\000\000\000o\000\000\000p\000\000\000e\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000\"\000\000\000!\000\000\000",46,1328422689);
			F1402_13608(Current, tr1);
		}
		if ((EIF_BOOLEAN) !loc20) {
			tr1 = RTMS32_EX_H("[\000\000\000E\000\000\000R\000\000\000R\000\000\000O\000\000\000R\000\000\000]\000\000\000 \000\000\000M\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000a\000\000\000r\000\000\000g\000\000\000u\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000s\000\000\000!\000\000\000",26,1593995297);
			F1402_13608(Current, tr1);
		}
		F1432_14947(Current);
	}
	RTLE;
}

/* {IRON_SHARE_TASK}.data_from */
EIF_REFERENCE F1433_14954 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_70 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(76, 0x00).id);
	RTLI(17);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,Current);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,loc11);
	RTLR(15,loc12);
	RTLR(16,tr2);
	RTLIU(17);
	
	RTGC;
	loc2 = F483_6244(RTCW(arg1));
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb2 = F77_1439(RTCW(loc1), loc2);
		tb1 = tb2;
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(59, 0x01).id, 59, _OBJSIZ_8_0_0_0_0_0_0_0_);
		F60_1237(RTCW(Result), loc2);
	} else {
		Result = RTLNS(eif_new_type(59, 0x01).id, 59, _OBJSIZ_8_0_0_0_0_0_0_0_);
	}
	tr1 = F483_6232(RTCW(arg1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F60_1256(RTCW(Result), loc5);
		tr1 = RTLNS(eif_new_type(73, 0x01).id, 73, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc3 = F74_1420(RTCW(tr1), loc5);
		tr1 = F288_3948(RTCW(loc3));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F60_1254(RTCW(Result), loc6);
		}
		tr1 = F288_3949(RTCW(loc3));
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			F60_1255(RTCW(Result), loc7);
		}
		tr1 = F1194_11006(loc5);
		F60_1258(RTCW(Result), tr1);
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3775[Dtype(RTCW(loc3))-288])(loc3);
	}
	tb1 = F60_1247(RTCW(Result));
	if (tb1) {
	} else {
		tr1 = F483_6233(RTCW(arg1));
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			F60_1253(RTCW(Result), loc8);
		} else {
			tb1 = F481_6207(RTCW(arg1));
			if (tb1) {
				F60_1253(RTCW(Result), loc4);
			} else {
				tr1 = RTMS_EX_H("Name\? ",6,1989451040);
				F1402_13608(Current, tr1);
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tr1 = RTMS_EX_H("[",1,91);
					F1402_13608(Current, tr1);
					F1402_13608(Current, loc4);
					tr1 = RTMS_EX_H("]",1,93);
					F1402_13608(Current, tr1);
				}
				tr1 = RTMS_EX_H(" >",2,8254);
				F1402_13608(Current, tr1);
				F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tr1 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
					tb2 = F1168_10025(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
					F60_1253(RTCW(Result), loc4);
				} else {
					tr1 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
					tr1 = F1168_10067(RTCW(tr1));
					F60_1253(RTCW(Result), tr1);
				}
			}
		}
	}
	tb1 = F483_6243(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = F60_1248(RTCW(Result));
		if (tb1) {
		} else {
			tr1 = F483_6234(RTCW(arg1));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				F60_1254(RTCW(Result), loc9);
			} else {
				tb1 = F481_6207(RTCW(arg1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTMS_EX_H("Title\? >",8,1108119358);
					F1402_13608(Current, tr1);
					F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
					tr1 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
					tr1 = F1168_10067(RTCW(tr1));
					F60_1254(RTCW(Result), tr1);
				}
			}
		}
		tb1 = F60_1249(RTCW(Result));
		if (tb1) {
		} else {
			tr1 = F483_6235(RTCW(arg1));
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				F60_1255(RTCW(Result), loc10);
			} else {
				tb1 = F481_6207(RTCW(arg1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTMS_EX_H("Description\? >",14,2089061438);
					F1402_13608(Current, tr1);
					F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
					tr1 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
					tr1 = F1168_10067(RTCW(tr1));
					F60_1255(RTCW(Result), tr1);
				}
			}
		}
		tr1 = F483_6236(RTCW(arg1));
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			F60_1257(RTCW(Result), loc11);
		} else {
			tb1 = F60_1250(RTCW(Result));
			if (tb1) {
			} else {
				tr1 = F483_6237(RTCW(arg1));
				loc12 = tr1;
				if (EIF_TEST(loc12)) {
					F60_1258(RTCW(Result), loc12);
				} else {
					tb1 = F481_6207(RTCW(arg1));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = RTMS_EX_H("Archive file\? >",15,1938636094);
						F1402_13608(Current, tr1);
						F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
						tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
						tr2 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
						F1194_10991(RTCW(tr1), tr2);
						F60_1257(RTCW(Result), tr1);
						tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
						if ((EIF_BOOLEAN)(tr1 == NULL)) {
							tr1 = RTMS_EX_H("Source folder\? >",16,815166782);
							F1402_13608(Current, tr1);
							F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
							tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
							tr2 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
							F1194_10991(RTCW(tr1), tr2);
							F60_1258(RTCW(Result), tr1);
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_SHARE_TASK}.package_by_name_from_repo */
EIF_REFERENCE F1433_14955 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tr1 = F713_7965(RTCW(arg1), arg2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc1)-908])(loc1);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7541[Dtype(loc1)-1053])(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit746 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
