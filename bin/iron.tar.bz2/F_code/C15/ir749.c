/*
 * Code for class IRON_PATH_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir749.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PATH_TASK}.name */

EIF_REFERENCE F1436_14963 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (43,RTMS_EX_H("path",4,1885434984));
}

/* {IRON_PATH_TASK}.process */
void F1436_14964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(488, 0x01).id, 488, _OBJSIZ_5_12_0_0_0_0_0_0_);
	F489_6296(RTCW(loc1), Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1113,0xFF01,0,0xFF01,487,0xFF01,100,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	((EIF_TYPED_VALUE *)tr1+3)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,0,1113,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A749_89, (EIF_POINTER) _A749_89, (EIF_POINTER)(F1436_14965),tr1, 1, 0);
	}
	F320_4507(RTCW(loc1), tr2);
	RTLE;
}

/* {IRON_PATH_TASK}.execute */
void F1436_14965 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLIU(10);
	
	RTGC;
	loc1 = RTOUCR(238,F489_6297, (RTCW(arg1)));
	tb1 = F870_8129(RTCW(loc1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr1 = F1194_11030(RTCW(tr1));
		F1402_13608(Current, tr1);
		F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(loc1))-635])(loc1);
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc2)-515])(loc2);
			if (tb1) break;
			tb2 = '\01';
			tb3 = '\01';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
			tr2 = F1168_10066(RTMS_EX_H("http://",7,769736239));
			tb4 = F1171_10172(RTCW(tr1), tr2);
			if (!tb4) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
				tr2 = F1168_10066(RTMS_EX_H("https://",8,441357103));
				tb4 = F1171_10172(RTCW(tr1), tr2);
				tb3 = tb4;
			}
			if (!tb3) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
				tr2 = F1168_10066(RTMS_EX_H("file://",7,1704345391));
				tb3 = F1171_10172(RTCW(tr1), tr2);
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
				tr1 = F1110_9554(RTCW(tr1), tr2);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					F1436_14966(Current, loc3, arg1, arg2);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
				tr1 = F1110_9553(RTCW(tr1), tr2);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc4)-635])(loc4);
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc5)-515])(loc5);
						if (tb2) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
						F1436_14966(Current, tr1, arg1, arg2);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc5)-515])(loc5);
					}
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc2)-515])(loc2);
		}
	}
	RTLE;
}

/* {IRON_PATH_TASK}.display_information */
void F1436_14966 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg3);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_2_);
	tb2 = F1111_9583(RTCW(tr1), arg1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_2_);
		tr1 = F1111_9586(RTCW(tr1), arg1);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tr1 = F1194_11030(loc1);
		F1402_13608(Current, tr1);
		F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
	}
	RTLE;
}

void EIF_Minit749 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
