
#ifndef _C15_lo715_
#define _C15_lo715_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1402_13608(EIF_REFERENCE, EIF_REFERENCE);
extern void F1402_13609(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit715(void);
extern void F100_1836(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F100_1807(EIF_REFERENCE);
extern EIF_REFERENCE F1168_10067(EIF_REFERENCE);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);
extern void F100_1838(EIF_REFERENCE, EIF_REFERENCE);
extern void F937_8443(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6252[])();

#ifdef __cplusplus
}
#endif

#endif
