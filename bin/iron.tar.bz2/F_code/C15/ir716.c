/*
 * Code for class IRON_CLIENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir716.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT}.make */
void F1403_13612 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(100, 0x01).id, 100, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1404_13623(Current);
	F101_1885(RTCW(loc2), tr1);
	F1404_13622(Current, loc2);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4 > ((EIF_INTEGER_32) 0L))) {
		loc3 = RTLNS(eif_new_type(1440, 0x01).id, 1440, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = F709_7928(Current);
		tr1 = F1403_13615(Current, tr1);
		F1432_14942(RTCW(loc3), tr1);
		tb1 = F1441_14981(RTCW(loc3), loc2);
		if (tb1) {
			loc1 = (EIF_REFERENCE) loc3;
		} else {
			tr1 = F709_7927(Current, ((EIF_INTEGER_32) 1L));
			tr2 = F709_7928(Current);
			tr2 = F1403_13614(Current, tr2);
			loc1 = F1403_13616(Current, tr1, tr2);
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12247[Dtype(RTCW(loc1))-1432])(loc1, loc2);
	} else {
		tr1 = RTOUCR(36,F1403_13619, (Current));
		F1402_13609(Current, tr1);
		tr1 = RTMS_EX_H(" - Version: ",12,1246374688);
		F1402_13609(Current, tr1);
		tr1 = RTOUCR(37,F1403_13621, (Current));
		F1402_13609(Current, tr1);
		tr1 = RTMS_EX_H("\012",1,10);
		F1402_13609(Current, tr1);
		tr1 = RTMS_EX_H("Copyright ",10,917764896);
		F1402_13609(Current, tr1);
		tr1 = RTOUCR(38,F1403_13620, (Current));
		F1402_13609(Current, tr1);
		tr1 = RTMS_EX_H("\012\012",2,2570);
		F1402_13609(Current, tr1);
		tr1 = RTMS_EX_H("Usage: command ...\012",19,2136882442);
		F1402_13609(Current, tr1);
		loc4 = F961_8573(RTCV(RTOUCR(3,F1404_13624, (Current))));
		for (;;) {
			tb1 = F650_7876(loc4);
			if (tb1) break;
			tr1 = RTMS_EX_H("\011 ",2,2336);
			tr2 = F650_7874(loc4);
			tr2 = F1168_10060(RTCW(tr2));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(" : ",3,2112032);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = F650_7873(loc4);
			tr2 = eif_boxed_item(tr2,2);
			tr2 = F1168_10060(RTCW(tr2));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H("\012",1,10);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			F1402_13609(Current, tr1);
			F650_7877(loc4);
		}
		tr1 = RTMS_EX_H("note: command {action} --help: gives specific help usage on action {action}.\012",77,333005834);
		F1402_13609(Current, tr1);
	}
	RTLE;
}

/* {IRON_CLIENT}.task_arguments */
EIF_REFERENCE F1403_13614 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	tb1 = F989_8749(RTCW(arg1), loc1);
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 988, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		tr1 = F989_8734(RTCW(arg1), loc1);
		F989_8729(RTCW(Result), tr1, loc1, loc2);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 988, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F989_8728(RTCW(Result));
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F989_8734(RTCW(arg1), loc1);
		F989_8753(RTCW(Result), tr1, loc1);
		loc1++;
	}
	F989_8777(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {IRON_CLIENT}.command_task_arguments */
EIF_REFERENCE F1403_13615 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	tb1 = F989_8749(RTCW(arg1), loc1);
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 988, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		tr1 = F989_8734(RTCW(arg1), loc1);
		F989_8729(RTCW(Result), tr1, loc1, loc2);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 988, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F989_8728(RTCW(Result));
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F989_8734(RTCW(arg1), loc1);
		F989_8753(RTCW(Result), tr1, loc1);
		loc1++;
	}
	F989_8777(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {IRON_CLIENT}.task_by_name */
EIF_REFERENCE F1403_13616 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = RTOUCR(3,F1404_13624, (Current));
	tr1 = F961_8564(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = eif_boxed_item(loc1,1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg2;
		RTAR(tr2,arg2);
		Result = F1164_9998(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT}.tasks */
static EIF_REFERENCE F1403_13617_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(4)
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1431,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 970, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F971_8682(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 7L) + ((EIF_INTEGER_32) 1L)));
	Result = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1439,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1439,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_76_2, (EIF_POINTER) _A716_76_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("Update package information..",28,1546808878);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(39,F1440_14977, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1438,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1438,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_77_2, (EIF_POINTER) _A716_77_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("list packages..",15,1068409646);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(40,F1439_14974, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1437,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1437,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_78_2, (EIF_POINTER) _A716_78_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("search package",14,548820837);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(41,F1438_14971, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1436,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1436,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_79_2, (EIF_POINTER) _A716_79_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("information about a package",27,2128424293);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(42,F1437_14967, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1435,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1435,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_80_2, (EIF_POINTER) _A716_80_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("output the installation folder for a package (if installed)",59,448951081);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(43,F1436_14963, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1444,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1444,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_81_2, (EIF_POINTER) _A716_81_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("install package",15,901432421);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(5,F1445_15019, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1434,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1434,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_82_2, (EIF_POINTER) _A716_82_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("remove a package",16,466622565);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(44,F1435_14960, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1433,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1433,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_83_2, (EIF_POINTER) _A716_83_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("manage repository list",22,667796596);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(45,F1434_14956, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1432,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1432,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_84_2, (EIF_POINTER) _A716_84_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("share and manage your package (auth required)",45,176870953);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTOUCR(46,F1433_14949, (Current));
	F961_8605(RTCW(Result), tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1440,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,988,0xFF01,1171,0xFF01,1440,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A716_85_2, (EIF_POINTER) _A716_85_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr5;
	RTAR(tr1,tr5);
	tr2 = RTMS_EX_H("extension command for iron",26,1780856942);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	tr2 = RTMS_EX_H("command",7,342989924);
	F961_8605(RTCW(Result), tr1, tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1403_13617 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(4,F1403_13617_body,(Current));
}

/* {IRON_CLIENT}.iron_executable_name */
static EIF_REFERENCE F1403_13619_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(36)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(72, 0x01).id, 72, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(47,F73_1414, (RTCW(tr2)));
	F1172_10190(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1403_13619 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(36,F1403_13619_body,(Current));
}

/* {IRON_CLIENT}.iron_copyright */
static EIF_REFERENCE F1403_13620_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(38)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(72, 0x01).id, 72, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(48,F73_1419, (RTCW(tr2)));
	F1172_10190(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1403_13620 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(38,F1403_13620_body,(Current));
}

/* {IRON_CLIENT}.iron_version */
static EIF_REFERENCE F1403_13621_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(37)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1171, 0x01).id, 1171, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(72, 0x01).id, 72, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(49,F73_1418, (RTCW(tr2)));
	F1172_10190(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1403_13621 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(37,F1403_13621_body,(Current));
}

/* {IRON_CLIENT}.inline-agent#1 of tasks */
EIF_REFERENCE F1403_15602 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1439, 0x01).id, 1439, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#2 of tasks */
EIF_REFERENCE F1403_15603 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1438, 0x01).id, 1438, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#3 of tasks */
EIF_REFERENCE F1403_15604 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1437, 0x01).id, 1437, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#4 of tasks */
EIF_REFERENCE F1403_15605 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1436, 0x01).id, 1436, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#5 of tasks */
EIF_REFERENCE F1403_15606 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1435, 0x01).id, 1435, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#6 of tasks */
EIF_REFERENCE F1403_15607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1444, 0x01).id, 1444, _OBJSIZ_3_4_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#7 of tasks */
EIF_REFERENCE F1403_15608 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1434, 0x01).id, 1434, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#8 of tasks */
EIF_REFERENCE F1403_15609 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1433, 0x01).id, 1433, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#9 of tasks */
EIF_REFERENCE F1403_15610 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1432, 0x01).id, 1432, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#10 of tasks */
EIF_REFERENCE F1403_15611 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1440, 0x01).id, 1440, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT}.inline-agent#11 of tasks */
EIF_REFERENCE F1403_15612 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1441, 0x01).id, 1441, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1432_14942(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit716 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
