/*
 * Code for class CONF_LOCATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co712.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION}.evaluated_path */
EIF_REFERENCE F1399_13589 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1192_10838(RTCW(tr1));
	Result = F1399_13590(Current, tr1);
	RTLE;
	return Result;
}

/* {CONF_LOCATION}.evaluated_path_relative_to_location */
EIF_REFERENCE F1399_13590 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,tr1);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,loc12);
	RTLR(9,Result);
	RTLR(10,arg1);
	RTLIU(11);
	
	RTGC;
	RTAOMS(13589,1);
	loc10 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1171_10139(RTCW(loc10), *(EIF_REFERENCE *)(Current));
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L));
	}
	if (tb3) {
		tw1 = F1173_10219(RTCW(loc10), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		tb2 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb2) {
		tw1 = F1173_10219(RTCW(loc10), ((EIF_INTEGER_32) 2L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
		tb1 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb1) {
		tr1 = F1399_13589(loc11);
		loc7 = F1194_11030(RTCW(tr1));
		F1173_10228(RTCW(loc10), loc7, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O8624[Dtype(loc7)-1170]);
		F1173_10270(RTCW(loc10), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	}
	loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
	loc1 = F1171_10149(RTCW(loc10), tw1, loc8);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L)) || loc9)) break;
		loc5 = (EIF_REFERENCE) NULL;
		loc4 = (EIF_INTEGER_32) loc1;
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			tw1 = F1173_10219(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			loc2 = F1171_10149(RTCW(loc10), tw1, loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 > (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L))))) {
				loc5 = F1173_10299(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			}
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				tw1 = F1173_10219(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
				loc8 = F1171_10149(RTCW(loc10), tw1, loc1);
				loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 2L));
			} else {
				if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc2 = F1171_10149(RTCW(loc10), tw1, loc1);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
					loc3 = F1171_10149(RTCW(loc10), tw1, loc1);
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
					if ((EIF_BOOLEAN) (loc2 < loc1)) {
						loc2 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
					}
					if ((EIF_BOOLEAN) (loc3 > loc1)) {
						ti4_1 = eif_min_int32 (loc2,loc3);
						loc2 = (EIF_INTEGER_32) ti4_1;
					}
					loc5 = F1173_10299(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc2);
				}
			}
		}
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F1192_10860(RTCW(tr1));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8527[Dtype(RTCW(loc5))-1171])(loc5);
			loc6 = F961_8564(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				tr1 = RTOUCR(33,F1095_9251, (Current));
				loc6 = F455_6049(RTCW(tr1), loc5);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc6 == NULL)) {
					tb1 = F450_5994(Current);
				}
				if (tb1) {
					tr1 = F450_5996(Current);
					loc6 = F1448_15160(RTCW(tr1), loc5);
				}
				if ((EIF_BOOLEAN)(loc6 == NULL)) {
					RTCOMS32(tr1,13589,0,"",0,0);
					loc6 = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1192_10837(RTCW(tr1), loc6, loc5);
			}
			tr1 = F1399_13600(Current, loc6);
			F1173_10228(RTCW(loc10), tr1, loc1, loc2);
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		loc1 = F1171_10149(RTCW(loc10), tw1, loc8);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == loc1);
		}
	}
	tr1 = F283_3902(Current);
	tr1 = F48_1048(RTCW(tr1), loc10);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		loc10 = F1168_10066(loc12);
	}
	tb1 = RTOUCB(EIF_BOOLEAN,228,F45_975, (RTCV(RTOUCR(229,F342_4861, (Current)))));
	if (tb1) {
		F1173_10293(RTCW(loc10));
	} else {
		F1399_13601(Current, loc10);
	}
	Result = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1194_10991(RTCW(Result), loc10);
	tb1 = F1194_11000(RTCW(Result));
	if (tb1) {
		tb1 = F1194_10999(RTCW(Result));
		if (tb1) {
			tr1 = arg1;
		} else {
			tr2 = F1194_11019(RTCW(arg1), Result);
			tr1 = tr2;
		}
		tr1 = F1194_11012(RTCV(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {CONF_LOCATION}.set_parent */
void F1399_13595 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {CONF_LOCATION}.is_equal */
EIF_BOOLEAN F1399_13597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = F1_10(Current, *(EIF_REFERENCE *)(Current), tr1);
	RTLE;
	return Result;
}

/* {CONF_LOCATION}.to_internal_format */
EIF_REFERENCE F1399_13600 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1173_10213(RTCW(Result), arg1);
	F1173_10236(RTCW(Result));
	F1173_10237(RTCW(Result));
	tr1 = RTMS32_EX_H("/\000\000\000",1,47);
	tr2 = RTMS32_EX_H("\\\000\000\000",1,92);
	F1173_10229(RTCW(Result), tr1, tr2);
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
		tw1 = F1173_10219(RTCW(Result), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		tb2 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb2) {
		tw1 = F1173_10219(RTCW(Result), ((EIF_INTEGER_32) 2L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		tb1 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
		F1173_10239(RTCW(Result), tw1, ((EIF_INTEGER_32) 2L));
	}
	RTLE;
	return Result;
}

/* {CONF_LOCATION}.update_path_to_unix */
void F1399_13601 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1173_10229(RTCW(arg1), tr1, tr2);
	RTLE;
}

void EIF_Minit712 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
