/*
 * Code for class IRON_REPOSITORY_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir747.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY_TASK}.name */

EIF_REFERENCE F1434_14956 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (45,RTMS_EX_H("repository",10,818164089));
}

/* {IRON_REPOSITORY_TASK}.process */
void F1434_14957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(484, 0x01).id, 484, _OBJSIZ_5_12_0_0_0_0_0_0_);
	F325_4593(RTCW(loc1), Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1113,0xFF01,0,0xFF01,483,0xFF01,100,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	((EIF_TYPED_VALUE *)tr1+3)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,0,1113,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A747_89, (EIF_POINTER) _A747_89, (EIF_POINTER)(F1434_14958),tr1, 1, 0);
	}
	F320_4507(RTCW(loc1), tr2);
	RTLE;
}

/* {IRON_REPOSITORY_TASK}.execute */
void F1434_14958 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc1);
	RTLR(11,loc8);
	RTLR(12,loc9);
	RTLIU(13);
	
	RTGC;
	tb1 = F485_6270(RTCW(arg1));
	if (tb1) {
		tr1 = RTMS_EX_H("Iron packages installation:\012  - ",32,423249696);
		F1402_13608(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr1 = F1194_11030(RTCW(tr1));
		F1402_13608(Current, tr1);
		F1432_14947(Current);
		tr1 = RTMS_EX_H("Iron client installation:\012  - ",30,930861856);
		F1402_13608(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tr1 = F1194_11030(RTCW(tr1));
		F1402_13608(Current, tr1);
		F1432_14947(Current);
	} else {
		tb1 = F485_6271(RTCW(arg1));
		if (tb1) {
			F1434_14959(Current, arg2);
		} else {
			tb1 = F485_6272(RTCW(arg1));
			if (tb1) {
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				tr1 = F1110_9544(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tb2 = F870_8129(loc3);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tr1 = RTMS_EX_H("Clean invalid repositories:\012",28,1545010698);
					F1402_13608(Current, tr1);
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc3)-635])(loc3);
					for (;;) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc4)-515])(loc4);
						if (tb1) break;
						tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
						tr2 = F713_7961(RTCW(tr2));
						tb2 = F1110_9546(RTCW(tr1), tr2);
						if (tb2) {
							tr1 = RTMS_EX_H(" - ",3,2108704);
							F1402_13608(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
							tr1 = F713_7961(RTCW(tr1));
							tr1 = F306_4234(Current, tr1);
							F1402_13608(Current, tr1);
							F1432_14947(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
							tr2 = F713_7961(RTCW(tr2));
							F1110_9549(RTCW(tr1), tr2);
						}
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc4)-515])(loc4);
					}
				}
				tb2 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tr1 = F1111_9570(RTCW(tr1));
				loc5 = tr1;
				if ((EIF_TRUE)) {
					tb3 = F870_8129(loc5);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					tr1 = RTMS_EX_H("Clean unexpected packages:\012",27,1213092362);
					F1402_13608(Current, tr1);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
					tr1 = F1111_9570(RTCW(tr1));
					loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc6)-515])(loc6);
						if (tb2) break;
						tr1 = RTMS_EX_H(" - ",3,2108704);
						F1402_13608(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
						tr1 = F1193_10958(RTCW(tr1));
						F1402_13608(Current, tr1);
						F1432_14947(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
						F1110_9559(RTCW(tr1), tr2);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc6)-515])(loc6);
					}
				}
				tr1 = RTMS_EX_H("Cleaning finished.",18,1554059310);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			} else {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	tr1 = F485_6274(RTCW(arg1));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = F306_4233(Current, loc7);
		F1402_13608(Current, tr1);
		F1432_14947(Current);
		loc1 = RTLNS(eif_new_type(74, 0x01).id, 74, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		tr1 = F1110_9547(RTCW(tr1), loc7);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F306_4236(Current, loc7);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
		} else {
			tr1 = F75_1422(RTCW(loc1), loc7);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				F1110_9548(RTCW(tr1), loc8);
			} else {
				tr1 = F306_4235(Current, loc7);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			}
		}
	}
	tr1 = F485_6275(RTCW(arg1));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = F306_4234(Current, loc9);
		F1402_13608(Current, tr1);
		F1432_14947(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		tb3 = F1110_9546(RTCW(tr1), loc9);
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
			F1110_9549(RTCW(tr1), loc9);
		} else {
			tr1 = F306_4237(Current, loc9);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
			F1432_14947(Current);
			tr1 = F306_4238(Current);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
		}
	}
	if (loc2) {
		F1434_14959(Current, arg2);
	}
	RTLE;
}

/* {IRON_REPOSITORY_TASK}.list_repositories */
void F1434_14959 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tr1 = F1110_9543(RTCW(tr1));
	loc1 = tr1;
	if ((EIF_TRUE)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc1)-908])(loc1);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc1)-635])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc2)-515])(loc2);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
			tr1 = F713_7961(RTCW(tr1));
			F1402_13608(Current, tr1);
			tb2 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc2)-515])(loc2);
			loc3 = tr1;
			loc3 = RTRV(eif_new_type(1190, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tb3 = F1191_10793(loc3);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTMS_EX_H(" -- Warning: path does not exist!",33,1271745057);
				F1402_13608(Current, tr1);
			}
			F1432_14947(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc2)-515])(loc2);
		}
	} else {
		tr1 = F306_4202(Current);
		F1402_13608(Current, tr1);
		F1432_14947(Current);
		F1432_14947(Current);
		tr1 = F306_4239(Current);
		F1402_13608(Current, tr1);
		F1432_14947(Current);
	}
	RTLE;
}

void EIF_Minit747 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
