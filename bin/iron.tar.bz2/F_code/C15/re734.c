/*
 * Code for class REGULAR_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re734.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REGULAR_EXPRESSION}.default_create */
void F1421_14651 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1420_14571(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1233,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F1234_11098(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_11_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1233,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,ti4_1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F1234_11098(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_9_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_10_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_12_);
	ti4_1 = (EIF_INTEGER_32) tu4_1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1233,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,ti4_1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F1234_11098(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_23_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_24_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {REGULAR_EXPRESSION}.reset */
void F1421_14652 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1420_14608(Current);
	F1421_14653(Current);
	RTLE;
}

/* {REGULAR_EXPRESSION}.wipe_out */
void F1421_14653 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F169_2702(Current);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_5_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_);
	RTLE;
}

/* {REGULAR_EXPRESSION}.compile */
void F1421_14654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1421_14653(Current);
	F1420_14602(Current, arg1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) * (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	tu4_1 = (EIF_NATURAL_32) ti4_1;
	if ((EIF_BOOLEAN) (tu4_1 < *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_7_);
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		tr1 = F1234_11133(RTCW(tr1), ((EIF_INTEGER_32) 0L), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

void EIF_Minit734 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
