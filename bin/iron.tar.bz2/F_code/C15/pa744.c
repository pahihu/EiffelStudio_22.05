/*
 * Code for class PATH_URI
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa744.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PATH_URI}.make_from_string */
void F1431_14934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("file:",5,1769494842);
	tb1 = F1168_10054(RTCW(arg1), tr1);
	if (tb1) {
		F1429_14845(Current, arg1);
		F1431_14938(Current);
	} else {
		tr1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1194_10991(RTCW(tr1), arg1);
		F1431_14937(Current, tr1);
	}
	RTLE;
}

/* {PATH_URI}.make_from_file_uri */
void F1431_14936 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1429_14847(Current, arg1);
	F1431_14938(Current);
	RTLE;
}

/* {PATH_URI}.make_from_path */
void F1431_14937 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_REFERENCE) arg1;
	tb1 = F1194_11001(RTCW(arg1));
	if (tb1) {
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTMS_EX_H("",0,0);
		F1429_14884(Current, tr1);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	tr1 = RTMS_EX_H("file",4,1718185061);
	F1429_14882(Current, tr1);
	tr1 = RTMS_EX_H("",0,0);
	F1429_14886(Current, tr1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) loc5;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		loc4 = F1194_11009(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc4))-867])(loc4);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc4))-867])(loc4);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
			loc3 = F1194_11030(RTCW(tr1));
			tb2 = '\0';
			tb3 = F1194_10998(RTCW(loc1));
			if (tb3) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7545[Dtype(RTCW(loc4))-1053])(loc4);
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = RTMS_EX_H("\\\\",2,23644);
				tb2 = F1168_10054(RTCW(loc3), tr1);
				if (tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
					loc6 = F1171_10149(RTCW(loc3), tw1, ((EIF_INTEGER_32) 3L));
					if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 0L))) {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc3))-1171])(loc3, ((EIF_INTEGER_32) 3L), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L)));
						tr1 = F1168_10060(RTCW(tr1));
						F1429_14884(Current, tr1);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O8624[Dtype(loc3)-1170]);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(loc3))-1171])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)), ti4_1);
						loc3 = (EIF_REFERENCE) tr1;
					} else {
					}
				}
				loc2 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1171_10139(RTCW(loc2), loc3);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				tw1 = F1173_10219(RTCW(loc2), ti4_1);
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
				if ((EIF_BOOLEAN)(tw1 == tw2)) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7546[Dtype(RTCW(loc4))-1053])(loc4);
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
						F1173_10239(RTCW(loc2), tw1, ti4_1);
					} else {
						F1173_10276(RTCW(loc2), ((EIF_INTEGER_32) 1L));
					}
				}
				tb2 = '\0';
				if (loc5) {
					tb3 = '\01';
					tb4 = F878_8129(RTCW(loc2));
					if (!tb4) {
						tw1 = F1173_10219(RTCW(loc2), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					tb2 = tb3;
				}
				if (tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					F1173_10243(RTCW(loc2), tw1);
				}
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7546[Dtype(RTCW(loc4))-1053])(loc4);
				if ((EIF_BOOLEAN) !tb2) {
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
					tb2 = '\0';
					if (loc5) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
						tw1 = F1173_10219(RTCW(loc2), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						tb2 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						F1173_10265(RTCW(loc2), tw1);
					}
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc4))-867])(loc4);
					tr1 = F1194_11030(RTCW(tr1));
					F203_3016(Current, tr1, loc2);
				}
				tb2 = F1171_10169(RTCW(loc2));
				if (tb2) {
					tr1 = F1168_10060(RTCW(loc2));
					F1429_14886(Current, tr1);
				} else {
					tr1 = F1168_10060(RTCW(loc2));
					F1429_14886(Current, tr1);
				}
			} else {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7545[Dtype(RTCW(loc4))-1053])(loc4);
				if (tb2) {
					F1429_14887(Current, loc3);
				} else {
					F1429_14888(Current, loc3);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc4))-867])(loc4);
		}
	} else {
		tr1 = F1194_11030(RTCW(loc1));
		F1429_14887(Current, tr1);
	}
	RTLE;
}

/* {PATH_URI}.get_file_path */
void F1431_14938 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc2 = F1429_14869(Current);
	tb1 = F870_8129(RTCW(loc2));
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1194_10989(RTCW(loc1));
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7044[Dtype(RTCW(loc2))-867])(loc2);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(tr1))-1171])(tr1);
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc2))-867])(loc2);
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc2))-867])(loc2);
			if (tb1) {
				loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
				F1194_10989(RTCW(loc1));
			} else {
				loc3 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
				F1171_10139(RTCW(loc3), tr1);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
				loc4 = F1171_10149(RTCW(loc3), tw1, ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
					F1173_10239(RTCW(loc3), tw1, loc4);
				} else {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
					loc4 = F1171_10149(RTCW(loc3), tw1, ((EIF_INTEGER_32) 1L));
				}
				if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tb1 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7546[Dtype(RTCW(loc2))-1053])(loc2);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
						F1173_10265(RTCW(loc3), tw1);
					}
					loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
					F1194_10991(RTCW(loc1), loc3);
				} else {
					loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
					F1194_10989(RTCW(loc1));
					tr1 = F1194_11018(RTCW(loc1), loc3);
					loc1 = (EIF_REFERENCE) tr1;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc2))-867])(loc2);
			}
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(tr1))-1171])(tr1);
			if (tb1) {
				loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
				tr1 = RTMS_EX_H("/",1,47);
				F1194_10991(RTCW(loc1), tr1);
			} else {
				loc1 = RTLNS(eif_new_type(1193, 0x01).id, 1193, _OBJSIZ_2_1_0_0_0_0_0_0_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
				F1194_10991(RTCW(loc1), tr1);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc2))-867])(loc2);
		}
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7055[Dtype(RTCW(loc2))-867])(loc2);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8483[Dtype(RTCW(tr1))-1171])(tr1);
			if ((EIF_BOOLEAN) !tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7077[Dtype(RTCW(loc2))-867])(loc2);
				tr1 = F1194_11018(RTCW(loc1), tr1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7057[Dtype(RTCW(loc2))-867])(loc2);
		}
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {PATH_URI}.hier */
EIF_REFERENCE F1431_14941 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1174_10304(RTCW(Result), ((EIF_INTEGER_32) 10L));
	tr1 = F1429_14877(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, loc1);
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(Result))-1175])(Result, (EIF_CHARACTER_8) '/');
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(Result))-1175])(Result, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
	return Result;
}

void EIF_Minit744 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
