/*
 * Code for class CONF_INTERFACE_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co719.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_INTERFACE_NAMES}.e_internal_parse_error */
EIF_REFERENCE F1406_14096 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Cannot parse configuration file. Unknown internal error.",56,572767278);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_tag */
EIF_REFERENCE F1406_14097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid tag/tag position \'$1\'",29,1128956967);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_value */
EIF_REFERENCE F1406_14098 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid or empty value for \'$1\'",31,1272069671);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_attribute */
EIF_REFERENCE F1406_14099 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid attribute \'$1\'",22,399476519);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_unsupported_attribute */
EIF_REFERENCE F1406_14100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Attribute \'$1\' is no longer supported for this element.",55,1313146926);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_missing_attribute */
EIF_REFERENCE F1406_14101 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Missing attribute \'$1\'",22,445998631);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_content */
EIF_REFERENCE F1406_14102 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid content: $1",19,500652337);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_no_name */
EIF_REFERENCE F1406_14103 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Incorrect system tag, no name specified.",40,920394542);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_name */
EIF_REFERENCE F1406_14104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid system name $1.",23,1844033582);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_invalid_uuid */
EIF_REFERENCE F1406_14105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Incorrect system tag $1 invalid UUID specified.",47,432980526);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_multiple_target_with_name */
EIF_REFERENCE F1406_14106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Multiple targets with name $1.",30,901095214);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_parent */
EIF_REFERENCE F1406_14107 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Missing parent target: $1 in target $2",38,397130546);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
	RTAR(tr3,arg2);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_no_name */
EIF_REFERENCE F1406_14109 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Target without a name specified.",32,1002044718);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_invalid_name */
EIF_REFERENCE F1406_14110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid target name $1.",23,1782017582);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_all */
EIF_REFERENCE F1406_14111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid value for all_classes attribute in root tag.",52,856382254);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root */
EIF_REFERENCE F1406_14112 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid root tag.",17,14597934);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_cluster */
EIF_REFERENCE F1406_14113 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid root cluster.",21,1514168622);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_class */
EIF_REFERENCE F1406_14114 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid root class.",19,932237358);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_feature */
EIF_REFERENCE F1406_14115 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid root procedure.",23,1447810862);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting_no_name */
EIF_REFERENCE F1406_14116 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid setting tag, no name specified.",39,1357443118);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting */
EIF_REFERENCE F1406_14117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid setting tag $1.",23,630025518);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting_value */
EIF_REFERENCE F1406_14118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid value for setting $1.",29,2079571758);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_file_rule */
EIF_REFERENCE F1406_14119 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid file_rule tag.",22,1232171822);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_external */
EIF_REFERENCE F1406_14120 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid external tag.",21,305412142);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_invalid */
EIF_REFERENCE F1406_14121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid action tag $1.",22,1423975726);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_succeed */
EIF_REFERENCE F1406_14122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Non boolean value for succeed attribute of action $1.",53,1247440174);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_no_command */
EIF_REFERENCE F1406_14123 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid action tag.",19,1747474990);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_variable_no_name */
EIF_REFERENCE F1406_14124 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid variable tag.",21,766237486);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library_no_name */
EIF_REFERENCE F1406_14126 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid library tag.",20,533826350);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library_name */
EIF_REFERENCE F1406_14127 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid library name $1.",24,797493806);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library */
EIF_REFERENCE F1406_14128 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid library tag $1.",23,1521673262);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_no_name */
EIF_REFERENCE F1406_14130 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid precompile tag.",23,740139054);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_name */
EIF_REFERENCE F1406_14131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid precompile name $1.",27,438962222);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile */
EIF_REFERENCE F1406_14132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid precompile tag $1.",26,1268614958);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_multiple */
EIF_REFERENCE F1406_14134 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid precompile tag $1, there is already another precompile specified $2.",76,2020039982);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
	RTAR(tr3,arg2);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly_no_name */
EIF_REFERENCE F1406_14135 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid assembly tag no name specified.",39,1199055662);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly_name */
EIF_REFERENCE F1406_14136 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid assembly name $1.",25,802585902);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly */
EIF_REFERENCE F1406_14137 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid assembly tag $1 no location specified.",46,162868782);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_no_name */
EIF_REFERENCE F1406_14139 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid cluster tag no name specified.",38,775220526);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_name */
EIF_REFERENCE F1406_14140 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid cluster name $1.",24,1008770606);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster */
EIF_REFERENCE F1406_14141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid cluster tag $1 no location specified.",45,896843566);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_conflict */
EIF_REFERENCE F1406_14142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid cluster tag there is already a group with the name $1.",62,924025902);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override_no_name */
EIF_REFERENCE F1406_14143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid override tag no name specified.",39,228885806);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override_name */
EIF_REFERENCE F1406_14144 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid override name $1.",25,707149102);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override */
EIF_REFERENCE F1406_14145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid override tag $1 no location specified.",46,2053781294);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_debug_no_name */
EIF_REFERENCE F1406_14147 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid debug tag.",18,1017523246);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_debug */
EIF_REFERENCE F1406_14148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid debug tag $1.",21,1000221486);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_warning_no_name */
EIF_REFERENCE F1406_14149 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid warning tag.",20,1554314030);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_warning */
EIF_REFERENCE F1406_14150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid warning tag $1.",23,2071586350);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_name */
EIF_REFERENCE F1406_14151 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid renaming tag.",21,943068974);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_new */
EIF_REFERENCE F1406_14152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid renaming tag, no new name specified for $1.",51,723573806);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_old */
EIF_REFERENCE F1406_14153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid renaming tag, no old name specified for $1.",51,911450926);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_class_opt */
EIF_REFERENCE F1406_14154 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid class_option tag.",25,1606584878);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_option_override */
EIF_REFERENCE F1406_14155 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Library option \"$1\" cannot be overridden outside the library.",61,912991278);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible */
EIF_REFERENCE F1406_14156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid visible tag on $1.",26,420685870);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible_feature */
EIF_REFERENCE F1406_14157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Incorrect feature name $1 in visible clause .",45,1732298030);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible_class */
EIF_REFERENCE F1406_14158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Incorrect class name $1 in visible clause .",43,2104216110);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_uses */
EIF_REFERENCE F1406_14159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid uses tag in group $1.",29,918257966);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_overrides */
EIF_REFERENCE F1406_14160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid overrides tag in group $1.",34,816658478);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_condition */
EIF_REFERENCE F1406_14161 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid condition tag.",22,1360920878);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_mult */
EIF_REFERENCE F1406_14162 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Cannot have multiple platform specifications in one condition.",62,1414380590);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_conflict */
EIF_REFERENCE F1406_14163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Value and exclude attribute in platform condition cannot appear at the same time.",81,2138170158);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_none */
EIF_REFERENCE F1406_14164 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No value or excluded-value specified in platform condition.",59,1233620526);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform */
EIF_REFERENCE F1406_14165 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid platform $1.",20,453053486);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_mult */
EIF_REFERENCE F1406_14166 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Cannot have multiple build specifications in one condition.",59,550406446);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_conflict */
EIF_REFERENCE F1406_14167 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Value and exclude attribute in build condition cannot appear at the same time.",78,1780802350);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_none */
EIF_REFERENCE F1406_14168 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No value or excluded-value specified in build condition.",56,400633134);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build */
EIF_REFERENCE F1406_14169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid build $1.",17,1066298414);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_multithreaded */
EIF_REFERENCE F1406_14170 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No valid value specified in multithreaded condition.",52,1547612718);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_concurrency */
EIF_REFERENCE F1406_14171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid concurrency condition $1.",33,812965678);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_void_safety */
EIF_REFERENCE F1406_14172 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid void_safety condition $1.",33,1750704430);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_dotnet */
EIF_REFERENCE F1406_14173 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No valid value specified in .NET condition.",43,467556398);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_dynamic_runtime */
EIF_REFERENCE F1406_14174 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No valid value specified in dynamic runtime condition.",54,761611566);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_min */
EIF_REFERENCE F1406_14175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid minimum version number in version condition: ",53,430672160);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_max */
EIF_REFERENCE F1406_14176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid maximum version number in version condition: ",53,582231328);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_no_type */
EIF_REFERENCE F1406_14177 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No version type specified in version condition.",47,184137262);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_no_version */
EIF_REFERENCE F1406_14178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("No minimum or maximum version in version condition $1 specified.",64,790179630);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_type */
EIF_REFERENCE F1406_14179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Invalid version type $1 in version condition.",45,1885535790);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_min_max */
EIF_REFERENCE F1406_14180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Minimum version cannot be greater than maximum version in version condition $1.",79,638589230);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_custom_no_name */
EIF_REFERENCE F1406_14181 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("No name attribute in custom condition.",38,1294095406);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_custom_conflict */
EIF_REFERENCE F1406_14183 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Value and exclude attribute in custom condition $1 cannot appear at the same time.",82,1706507310);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_mapping */
EIF_REFERENCE F1406_14184 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid mapping tag.",20,1023125806);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_description */
EIF_REFERENCE F1406_14185 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("Invalid description tag.",24,1977759790);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_more_than_one_note */
EIF_REFERENCE F1406_14186 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = F1405_13625(Current);
	tr3 = RTMS_EX_H("Multiple note elements under $1.",32,284655150);
	tr2 = F28_286(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F28_290(RTCW(tr1), tr2, tr3);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_external_outside_target_element */
EIF_REFERENCE F1406_14187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1405_13625(Current);
	tr2 = RTMS_EX_H("External element found outside a target element.",48,414953518);
	Result = F28_286(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_regexp */
EIF_REFERENCE F1406_14188 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg2 != NULL) && (EIF_BOOLEAN)(arg3 != NULL))) {
		if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 0L))) {
			tr1 = F1405_13625(Current);
			tr2 = F1405_13625(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" in \"$2\": $3.",44,29675566);
			tr2 = F28_286(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,1113,0xFF01,1167,0xFF01,1167,0xFF01,1167,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 4, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			((EIF_TYPED_VALUE *)tr3+3)->it_r = arg3;
			RTAR(tr3,arg3);
			Result = F28_290(RTCW(tr1), tr2, tr3);
		} else {
			tr1 = F1405_13625(Current);
			tr2 = F1405_13625(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" (error position: $4) in \"$2\": $3.",65,22094382);
			tr2 = F28_286(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,4,1113,0xFF01,1167,0xFF01,1167,0xFF01,1167,1312,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 5, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			((EIF_TYPED_VALUE *)tr3+3)->it_r = arg3;
			RTAR(tr3,arg3);
			((EIF_TYPED_VALUE *)tr3+4)->it_i4 = arg4;
			Result = F28_290(RTCW(tr1), tr2, tr3);
		}
	} else {
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tr1 = F1405_13625(Current);
			tr2 = F1405_13625(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" in \"$2\".",40,867593774);
			tr2 = F28_286(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1167,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 3, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			Result = F28_290(RTCW(tr1), tr2, tr3);
		} else {
			if ((EIF_BOOLEAN)(arg3 != NULL)) {
				if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 0L))) {
					tr1 = F1405_13625(Current);
					tr2 = F1405_13625(Current);
					tr3 = RTMS_EX_H("Invalid regular expression \"$1\": $2.",36,1540005934);
					tr2 = F28_286(RTCW(tr2), tr3);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1167,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
					RTAR(tr3,arg1);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = arg3;
					RTAR(tr3,arg3);
					Result = F28_290(RTCW(tr1), tr2, tr3);
				} else {
					tr1 = F1405_13625(Current);
					tr2 = F1405_13625(Current);
					tr3 = RTMS_EX_H("Invalid regular expression \"$1\" (error position: $3): $2.",57,2077588526);
					tr2 = F28_286(RTCW(tr2), tr3);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,1113,0xFF01,1167,0xFF01,1167,1312,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 4, 0);
					}
					((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
					RTAR(tr3,arg1);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = arg3;
					RTAR(tr3,arg3);
					((EIF_TYPED_VALUE *)tr3+3)->it_i4 = arg4;
					Result = F28_290(RTCW(tr1), tr2, tr3);
				}
			} else {
				tr1 = F1405_13625(Current);
				tr2 = F1405_13625(Current);
				tr3 = RTMS_EX_H("Invalid regular expression: \"$1\".",33,1445287214);
				tr2 = F28_286(RTCW(tr2), tr3);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1113,0xFF01,1167,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
				RTAR(tr3,arg1);
				Result = F28_290(RTCW(tr1), tr2, tr3);
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit719 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
