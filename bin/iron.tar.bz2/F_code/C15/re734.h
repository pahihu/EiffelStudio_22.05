
#ifndef _C15_re734_
#define _C15_re734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1421_14651(EIF_REFERENCE);
extern void F1421_14652(EIF_REFERENCE);
extern void F1421_14653(EIF_REFERENCE);
extern void F1421_14654(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F169_2702(EIF_REFERENCE);
extern EIF_REFERENCE F1234_11133(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1234_11098(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1420_14571(EIF_REFERENCE);
extern void F1420_14602(EIF_REFERENCE, EIF_REFERENCE);
extern void F1420_14608(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
