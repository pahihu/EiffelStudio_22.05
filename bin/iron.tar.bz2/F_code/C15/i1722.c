/*
 * Code for class I18N_FORMAT_STRING_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1722.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FORMAT_STRING_PARSER}.make */
void F1409_14242 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {I18N_FORMAT_STRING_PARSER}.parse */
EIF_REFERENCE F1409_14243 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLIU(8);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1053,0xFF01,398,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 1053, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F1054_8838(RTCW(Result));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R8470[Dtype(RTCW(arg1))-1171])(arg1, tw1, loc1);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
			tb1 = (EIF_BOOLEAN)(loc2 == ti4_2);
		}
		if (tb1) {
			loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc1, ti4_2);
			F402_5205(RTCW(loc3), tr1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
			tr1 = F1_14(loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(Result))-867])(Result, tr1);
		} else {
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc1) > ((EIF_INTEGER_32) 0L))) {
				loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8546[Dtype(RTCW(arg1))-1171])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				F402_5205(RTCW(loc3), tr1);
				tr1 = F1_14(loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(Result))-867])(Result, tr1);
			}
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8469[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
			loc4 = (EIF_CHARACTER_8) tw1;
			switch (loc4) {
				case (EIF_CHARACTER_8) 'e':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_113_2, (EIF_POINTER) _A722_113_2, (EIF_POINTER)(F1356_12715),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'd':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_114_2, (EIF_POINTER) _A722_114_2, (EIF_POINTER)(F1356_12716),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'a':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_115_2, (EIF_POINTER) _A722_115_2, (EIF_POINTER)(F1356_12717),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'A':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_116_2, (EIF_POINTER) _A722_116_2, (EIF_POINTER)(F1356_12718),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'j':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_117_2, (EIF_POINTER) _A722_117_2, (EIF_POINTER)(F1356_12719),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'u':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_118_2, (EIF_POINTER) _A722_118_2, (EIF_POINTER)(F1356_12720),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'w':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_119_2, (EIF_POINTER) _A722_119_2, (EIF_POINTER)(F1356_12721),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '1':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_120_2, (EIF_POINTER) _A722_120_2, (EIF_POINTER)(F1356_12722),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'm':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_121_2, (EIF_POINTER) _A722_121_2, (EIF_POINTER)(F1356_12723),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'b':
				case (EIF_CHARACTER_8) 'h':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_122_2, (EIF_POINTER) _A722_122_2, (EIF_POINTER)(F1356_12724),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'B':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_123_2, (EIF_POINTER) _A722_123_2, (EIF_POINTER)(F1356_12725),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'C':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_124_2, (EIF_POINTER) _A722_124_2, (EIF_POINTER)(F1356_12726),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'G':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_128_2, (EIF_POINTER) _A722_128_2, (EIF_POINTER)(F1356_12730),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'g':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_129_2, (EIF_POINTER) _A722_129_2, (EIF_POINTER)(F1356_12731),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'V':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_125_2, (EIF_POINTER) _A722_125_2, (EIF_POINTER)(F1356_12727),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'U':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_126_2, (EIF_POINTER) _A722_126_2, (EIF_POINTER)(F1356_12728),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'W':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_127_2, (EIF_POINTER) _A722_127_2, (EIF_POINTER)(F1356_12729),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '2':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_130_2, (EIF_POINTER) _A722_130_2, (EIF_POINTER)(F1356_12732),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'y':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_131_2, (EIF_POINTER) _A722_131_2, (EIF_POINTER)(F1356_12733),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'Y':
					loc3 = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_132_2, (EIF_POINTER) _A722_132_2, (EIF_POINTER)(F1356_12734),tr1, 1, 1);
					}
					F400_5199(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'l':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_102_2, (EIF_POINTER) _A722_102_2, (EIF_POINTER)(F1356_12704),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'I':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_103_2, (EIF_POINTER) _A722_103_2, (EIF_POINTER)(F1356_12705),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'k':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_104_2, (EIF_POINTER) _A722_104_2, (EIF_POINTER)(F1356_12706),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'H':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_104_2, (EIF_POINTER) _A722_104_2, (EIF_POINTER)(F1356_12706),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '4':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_106_2, (EIF_POINTER) _A722_106_2, (EIF_POINTER)(F1356_12708),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'M':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_107_2, (EIF_POINTER) _A722_107_2, (EIF_POINTER)(F1356_12709),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'S':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_108_2, (EIF_POINTER) _A722_108_2, (EIF_POINTER)(F1356_12710),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '5':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_109_2, (EIF_POINTER) _A722_109_2, (EIF_POINTER)(F1356_12711),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '8':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_110_2, (EIF_POINTER) _A722_110_2, (EIF_POINTER)(F1356_12712),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) '9':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_111_2, (EIF_POINTER) _A722_111_2, (EIF_POINTER)(F1356_12713),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) 'P':
					loc3 = RTLNS(eif_new_type(400, 0x01).id, 400, _OBJSIZ_1_0_0_0_0_0_0_0_);
					{
						EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
						EIF_TYPE typres0;
						typarr0[4] = dftype;
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr1 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
					RTAR(tr1,Current);
					tr2 = *(EIF_REFERENCE *)(Current);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
					RTAR(tr1,tr2);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1424,0xFF01,1172,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_112_2, (EIF_POINTER) _A722_112_2, (EIF_POINTER)(F1356_12714),tr1, 1, 1);
					}
					F401_5202(RTCW(loc3), tr4);
					break;
				case (EIF_CHARACTER_8) ':':
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
					F402_5205(RTCW(loc3), tr1);
					break;
				case (EIF_CHARACTER_8) '/':
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_11_);
					F402_5205(RTCW(loc3), tr1);
					break;
				case (EIF_CHARACTER_8) 'c':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
					F403_5208(RTCW(loc3), tr1, *(EIF_REFERENCE *)(Current));
					break;
				case (EIF_CHARACTER_8) 'D':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'm');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("/",1,47);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'd');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("/",1,47);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'y');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = *(EIF_REFERENCE *)(Current);
					F403_5208(RTCW(loc3), tr1, tr2);
					break;
				case (EIF_CHARACTER_8) 'F':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'Y');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("-",1,45);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'm');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H("-",1,45);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'd');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = *(EIF_REFERENCE *)(Current);
					F403_5208(RTCW(loc3), tr1, tr2);
					break;
				case (EIF_CHARACTER_8) 'r':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'I');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(":",1,58);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'M');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(":",1,58);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'S');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(" ",1,32);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '9');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = *(EIF_REFERENCE *)(Current);
					F403_5208(RTCW(loc3), tr1, tr2);
					break;
				case (EIF_CHARACTER_8) 'R':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'H');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(":",1,58);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'M');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = *(EIF_REFERENCE *)(Current);
					F403_5208(RTCW(loc3), tr1, tr2);
					break;
				case (EIF_CHARACTER_8) 'T':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'H');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(":",1,58);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'M');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = RTMS_EX_H(":",1,58);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'S');
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
					tr2 = *(EIF_REFERENCE *)(Current);
					F403_5208(RTCW(loc3), tr1, tr2);
					break;
				case (EIF_CHARACTER_8) 'x':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
					F403_5208(RTCW(loc3), tr1, *(EIF_REFERENCE *)(Current));
					break;
				case (EIF_CHARACTER_8) 'X':
					loc3 = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
					F403_5208(RTCW(loc3), tr1, *(EIF_REFERENCE *)(Current));
					break;
				case (EIF_CHARACTER_8) '&':
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
					F402_5205(RTCW(loc3), tr1);
					break;
				case (EIF_CHARACTER_8) 't':
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = RTMS_EX_H("\011",1,9);
					F402_5205(RTCW(loc3), tr1);
					break;
				case (EIF_CHARACTER_8) 'n':
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = RTMS_EX_H("\012",1,10);
					F402_5205(RTCW(loc3), tr1);
					break;
				case (EIF_CHARACTER_8) 'E':
					loc3 = F1409_14245(Current, loc4);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
					break;
				case (EIF_CHARACTER_8) 'O':
					loc3 = F1409_14246(Current, loc4);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
					break;
				default:
					loc3 = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
					tr1 = RTMS_EX_H(" ",1,32);
					F402_5205(RTCW(loc3), tr1);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					break;
			}
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7064[Dtype(RTCW(Result))-867])(Result, loc3);
		}
	}
	RTLE;
	return Result;
}

/* {I18N_FORMAT_STRING_PARSER}.parse_modified_1 */
EIF_REFERENCE F1409_14245 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	switch (arg1) {
		case (EIF_CHARACTER_8) 'c':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
			tr2 = F1168_10066(RTMS_EX_H(" ",1,32));
			tr1 = F1173_10271(RTCW(tr1), tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_4_);
			tr1 = F1173_10271(RTCW(tr1), tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			F403_5208(RTCW(Result), tr1, tr2);
			break;
		case (EIF_CHARACTER_8) 'X':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
			F403_5208(RTCW(Result), tr1, *(EIF_REFERENCE *)(Current));
			break;
		case (EIF_CHARACTER_8) 'x':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			F403_5208(RTCW(Result), tr1, *(EIF_REFERENCE *)(Current));
			break;
		case (EIF_CHARACTER_8) 'Y':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_132_2, (EIF_POINTER) _A722_132_2, (EIF_POINTER)(F1356_12734),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		default:
			Result = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = RTMS_EX_H(" ",1,32);
			F402_5205(RTCW(Result), tr1);
			break;
	}
	RTLE;
	return Result;
}

/* {I18N_FORMAT_STRING_PARSER}.parse_modified_2 */
EIF_REFERENCE F1409_14246 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	switch (arg1) {
		case (EIF_CHARACTER_8) 'H':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'H');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'M');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'S');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			F403_5208(RTCW(Result), tr1, tr2);
			break;
		case (EIF_CHARACTER_8) 'I':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'I');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'M');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'S');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = RTMS_EX_H(" ",1,32);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '9');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			F403_5208(RTCW(Result), tr1, tr2);
			break;
		case (EIF_CHARACTER_8) 'M':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) '4');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			F403_5208(RTCW(Result), tr1, tr2);
			break;
		case (EIF_CHARACTER_8) 'S':
			Result = RTLNS(eif_new_type(402, 0x01).id, 402, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '&');
			tr2 = eif_out__c1_s1((EIF_CHARACTER_8) 'S');
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			tr2 = *(EIF_REFERENCE *)(Current);
			F403_5208(RTCW(Result), tr1, tr2);
			break;
		case (EIF_CHARACTER_8) 'd':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_113_2, (EIF_POINTER) _A722_113_2, (EIF_POINTER)(F1356_12715),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		case (EIF_CHARACTER_8) 'e':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_114_2, (EIF_POINTER) _A722_114_2, (EIF_POINTER)(F1356_12716),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		case (EIF_CHARACTER_8) 'm':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_120_2, (EIF_POINTER) _A722_120_2, (EIF_POINTER)(F1356_12722),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		case (EIF_CHARACTER_8) 'u':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1113,0xFF01,0,0xFF01,129,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
			RTAR(tr1,tr2);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_116_2, (EIF_POINTER) _A722_116_2, (EIF_POINTER)(F1356_12718),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		case (EIF_CHARACTER_8) 'U':
		case (EIF_CHARACTER_8) 'w':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_126_2, (EIF_POINTER) _A722_126_2, (EIF_POINTER)(F1356_12728),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		case (EIF_CHARACTER_8) 'V':
		case (EIF_CHARACTER_8) 'W':
			Result = RTLNS(eif_new_type(399, 0x01).id, 399, _OBJSIZ_1_0_0_0_0_0_0_0_);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1113,0xFF01,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[4] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1163,0xFF01,0xFFF9,1,1113,0xFF01,1422,0xFF01,1172,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A722_126_2, (EIF_POINTER) _A722_126_2, (EIF_POINTER)(F1356_12728),tr1, 1, 1);
			}
			F400_5199(RTCW(Result), tr4);
			break;
		default:
			Result = RTLNS(eif_new_type(401, 0x01).id, 401, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr1 = RTMS_EX_H(" ",1,32);
			F402_5205(RTCW(Result), tr1);
			break;
	}
	RTLE;
	return Result;
}

void EIF_Minit722 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
