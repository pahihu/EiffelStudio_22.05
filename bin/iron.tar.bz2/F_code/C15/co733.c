/*
 * Code for class COMPILER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co733.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER}.default_create */
void F1420_14571 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(25, 1).id);
	F26_257(RTCW(tr1), ((EIF_INTEGER_32) 1024L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(21, 1).id);
	F22_187(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = F1_14(RTOUCR(626,F1420_14647, (Current)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1421_14652(Current);
	tr1 = RTOUCR(627,F158_2533, (Current));
	F1420_14600(Current, tr1);
	tr1 = RTOUCR(628,F158_2534, (Current));
	F1420_14601(Current, tr1);
	F1420_14587(Current);
	RTLE;
}

/* {COMPILER}.is_compiled */
EIF_BOOLEAN F1420_14572 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = RTOUCR(629,F23_197, (Current));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(RTCW(tr1))-1174])(tr1, tr2);
	RTLE;
	return Result;
}

/* {COMPILER}.set_default_options */
void F1420_14587 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1420_14588(Current, (EIF_BOOLEAN) 0);
	F1420_14592(Current, (EIF_BOOLEAN) 0);
	F1420_14593(Current, (EIF_BOOLEAN) 0);
	F1420_14589(Current, (EIF_BOOLEAN) 0);
	F1420_14594(Current, (EIF_BOOLEAN) 1);
	F1420_14595(Current, (EIF_BOOLEAN) 0);
	F1420_14596(Current, (EIF_BOOLEAN) 1);
	F1420_14597(Current, (EIF_BOOLEAN) 1);
	F1420_14598(Current, (EIF_BOOLEAN) 0);
	F1420_14590(Current, (EIF_BOOLEAN) 1);
	F1420_14591(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {COMPILER}.set_caseless */
void F1420_14588 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_extended */
void F1420_14589 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_greedy */
void F1420_14590 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_strict */
void F1420_14591 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_multiline */
void F1420_14592 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_dotall */
void F1420_14593 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_empty_allowed */
void F1420_14594 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_dollar_endonly */
void F1420_14595 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_6_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_bol */
void F1420_14596 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_7_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_eol */
void F1420_14597 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_8_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_anchored */
void F1420_14598 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_ims_options */
void F1420_14599 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = F159_2551(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) tb1;
	tb1 = F159_2552(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) = (EIF_BOOLEAN) tb1;
	tb1 = F159_2553(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) tb1;
	RTLE;
}

/* {COMPILER}.set_character_case_mapping */
void F1420_14600 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {COMPILER}.set_word_set */
void F1420_14601 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {COMPILER}.compile */
void F1420_14602 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	F1174_10306(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(tr1))-1175])(tr1, (EIF_CHARACTER_8) '\000');
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F26_276(RTCW(tr1));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	F1420_14613(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	tr1 = RTOUCR(630,F23_234, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	F1420_14607(Current, tr1, ((EIF_INTEGER_32) 99L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F26_270(RTCW(tr1), ((EIF_INTEGER_32) 70L));
	F1420_14628(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_), (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) -1L));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(tr1 == RTOUCR(630,F23_234, (Current)))) {
		tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_));
	}
	if (tb1) {
		tr1 = RTOUCR(631,F23_219, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1420_14607(Current, tr1, ((EIF_INTEGER_32) 22L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) > *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_))) {
			tr1 = RTOUCR(632,F23_212, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
			F1420_14607(Current, tr1, ((EIF_INTEGER_32) 15L), ti4_1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(tr1 == RTOUCR(630,F23_234, (Current)))) {
		tr1 = RTOUCR(629,F23_197, (Current));
		F1420_14607(Current, tr1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F26_270(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		loc1 = F1420_14612(Current);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if (F1420_14643(Current, loc1)) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				F1420_14598(Current, (EIF_BOOLEAN) 1);
			} else {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				ti4_1 = F1420_14642(Current, loc1);
				loc1 = (EIF_INTEGER_32) ti4_1;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				tb1 = '\0';
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					tb1 = F1420_14644(Current);
				}
				if (tb1) {
					F1420_14614(Current, (EIF_BOOLEAN) 1);
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) <= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) >= ((EIF_INTEGER_32) 0L)))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	}
	RTLE;
}

/* {COMPILER}.optimize */
void F1420_14603 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_9_) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_11_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F22_195(RTCW(tr1));
		F1420_14645(Current, ((EIF_INTEGER_32) 0L), *(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_));
	}
	RTLE;
}

/* {COMPILER}.set_error */
void F1420_14607 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_13_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_14_) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {COMPILER}.reset */
void F1420_14608 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(630,F23_234, (Current));
	F1420_14607(Current, tr1, ((EIF_INTEGER_32) 99L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(tr1))-1172])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(tr1))-1175])(tr1, (EIF_CHARACTER_8) '\000');
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {COMPILER}.ims_options */
EIF_INTEGER_32 F1420_14612 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
		ti4_1 = F159_2558(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_)) {
		ti4_1 = F159_2560(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_)) {
		RTLE;
		return (EIF_INTEGER_32) F159_2562(Current, Result);
	}
	RTLE;
	return Result;
}

/* {COMPILER}.set_default_internal_options */
void F1420_14613 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1420_14614(Current, (EIF_BOOLEAN) 0);
	F1420_14615(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {COMPILER}.set_startline */
void F1420_14614 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_11_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.set_ichanged */
void F1420_14615 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_12_) = (EIF_BOOLEAN) arg1;
}

/* {COMPILER}.find_fixed_code_length */
EIF_INTEGER_32 F1420_14627 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	for (;;) {
		if (loc5) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = F26_258(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 70L))) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
		}
		switch (loc3) {
			case 65L:
			case 66L:
			case 70L:
				loc2 = F1420_14627(Current, loc1);
				if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc4 += loc2;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_1;
					for (;;) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F26_258(RTCW(tr1), loc1);
						if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 56L))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						loc1 += ti4_2;
					}
					loc1 += ((EIF_INTEGER_32) 2L);
				}
				break;
			case 0L:
			case 56L:
			case 57L:
			case 58L:
			case 59L:
				if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
					Result = (EIF_INTEGER_32) loc4;
				} else {
					if ((EIF_BOOLEAN)(Result != loc4)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				if ((EIF_BOOLEAN) !loc5) {
					if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 56L))) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc1 += ((EIF_INTEGER_32) 2L);
						loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
				break;
			case 60L:
			case 61L:
			case 62L:
			case 63L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_2 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc1 += ti4_2;
				for (;;) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_2 = F26_258(RTCW(tr1), loc1);
					if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 56L))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_3 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_3;
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 64L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 12L:
			case 67L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 1L:
			case 2L:
			case 3L:
			case 10L:
			case 11L:
			case 13L:
			case 14L:
				loc1++;
				break;
			case 16L:
				loc1++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc2 = F26_260(RTCW(tr1), loc1);
				loc4 += loc2;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) + ((EIF_INTEGER_32) 1L));
				break;
			case 26L:
			case 44L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_3 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc4 += ti4_3;
				loc1 += ((EIF_INTEGER_32) 3L);
				break;
			case 4L:
			case 5L:
			case 6L:
			case 7L:
			case 8L:
			case 9L:
			case 15L:
				loc4++;
				loc1++;
				break;
			case 53L:
				loc1 += ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_3 = F26_258(RTCW(tr1), loc1);
				switch (ti4_3) {
					case 45L:
					case 46L:
					case 49L:
					case 50L:
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
					case 51L:
					case 52L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc2 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_3 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
						if ((EIF_BOOLEAN)(loc2 != ti4_3)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc4 += loc2;
							loc1 += ((EIF_INTEGER_32) 3L);
						}
						break;
					default:
						loc4++;
						break;
				}
				break;
			default:
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.compile_regexp */
void F1420_14628 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc7 = (EIF_INTEGER_32) arg1;
	loc8 = F1420_14612(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = (EIF_INTEGER_32) loc1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	ti4_1 = RTOUCB(EIF_INTEGER_32,633,F1420_14649, (Current));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F26_270(RTCW(tr1), ((EIF_INTEGER_32) 67L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F26_272(RTCW(tr1), arg4);
	}
	for (;;) {
		if (loc9) break;
		if ((EIF_BOOLEAN) !F159_2556(Current, loc7)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_270(RTCW(tr1), ((EIF_INTEGER_32) 12L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_272(RTCW(tr1), loc7);
			F1420_14599(Current, loc7);
		}
		if (arg3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_270(RTCW(tr1), ((EIF_INTEGER_32) 64L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		}
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) loc7;
		F1420_14629(Current, arg2);
		loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		if ((EIF_BOOLEAN)(tr1 == RTOUCR(630,F23_234, (Current)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_269(RTCW(tr1), loc6, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) -2L))) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) >= ((EIF_INTEGER_32) 0L))) {
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
						loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
					} else {
						if ((EIF_BOOLEAN)(loc4 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_))) {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
						}
					}
				} else {
					loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
				}
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) < loc5)) {
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) loc5;
			if (arg3) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				loc6 = F1420_14627(Current, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F26_266(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
					tr1 = RTOUCR(634,F23_222, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
					F1420_14607(Current, tr1, ((EIF_INTEGER_32) 25L), ti4_1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_269(RTCW(tr1), loc6, loc3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 124L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), ((EIF_INTEGER_32) 57L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_272(RTCW(tr1), loc6);
				tb1 = '\0';
				if (arg2) {
					tb1 = (EIF_BOOLEAN) !F159_2556(Current, loc7);
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), ((EIF_INTEGER_32) 12L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_272(RTCW(tr1), loc8);
				}
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), ((EIF_INTEGER_32) 56L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
			}
		} else {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {COMPILER}.compile_branch */
void F1420_14629 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc20 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc21 = (EIF_BOOLEAN) 0;
	struct eif_ex_29 sloc22;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) sloc22.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	memset (&sloc22.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc22.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc22.overhead, eif_new_type(35, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc22);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc16 = F1420_14612(Current);
	loc17 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_);
	loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
		F1420_14639(Current);
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc20 || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOUCR(630,F23_234, (Current)));
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc19 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 123L))) {
			tb2 = F1420_14633(Current, loc5, loc11, loc9);
		}
		if (tb2) {
			loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			switch (loc19) {
				case 41L:
				case 124L:
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
					loc20 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case 94L:
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), ((EIF_INTEGER_32) 13L));
					break;
				case 36L:
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), ((EIF_INTEGER_32) 14L));
					break;
				case 46L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), ((EIF_INTEGER_32) 15L));
					break;
				case 91L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					F1420_14630(Current);
					break;
				case 42L:
					F1420_14631(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) -1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 43L:
					F1420_14631(Current, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) -1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 63L:
					F1420_14631(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc5, loc11, loc9);
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
				case 40L:
					loc15 = F1420_14612(Current);
					loc14 = (EIF_INTEGER_32) loc15;
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 63L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						switch (ti4_1) {
							case 35L:
								loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L));
								for (;;) {
									tb2 = '\01';
									if (!(EIF_BOOLEAN) (loc7 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc7);
										tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 41L));
									}
									if (tb2) break;
									loc7++;
								}
								if ((EIF_BOOLEAN) (loc7 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
									tr1 = RTOUCR(635,F23_215, (Current));
									F1420_14607(Current, tr1, ((EIF_INTEGER_32) 18L), loc7);
								} else {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc7;
								}
								break;
							case 58L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 40L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								switch (ti4_1) {
									case 48L:
									case 49L:
									case 50L:
									case 51L:
									case 52L:
									case 53L:
									case 54L:
									case 55L:
									case 56L:
									case 57L:
										loc8 = F1420_14636(Current, ((EIF_INTEGER_32) 10L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
										if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 41L))) {
											tr1 = RTOUCR(636,F23_223, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1420_14607(Current, tr1, ((EIF_INTEGER_32) 26L), ti4_1);
										}
										if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
											tr1 = RTOUCR(637,F23_232, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1420_14607(Current, tr1, ((EIF_INTEGER_32) 35L), ti4_1);
										} else {
											(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										}
										break;
									default:
										loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc7);
										if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 63L))) {
											tr1 = RTOUCR(638,F23_225, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1420_14607(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
											ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
											switch (ti4_1) {
												case 33L:
												case 60L:
												case 61L:
													break;
												default:
													tr1 = RTOUCR(638,F23_225, (Current));
													ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
													F1420_14607(Current, tr1, ((EIF_INTEGER_32) 28L), ti4_1);
													break;
											}
										}
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
										break;
								}
								break;
							case 61L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 33L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 60L:
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								switch (ti4_1) {
									case 61L:
										loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										break;
									case 33L:
										loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										break;
									default:
										tr1 = RTOUCR(639,F23_221, (Current));
										ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
										F1420_14607(Current, tr1, ((EIF_INTEGER_32) 24L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 3L)));
										break;
								}
								break;
							case 62L:
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							case 82L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F26_270(RTCW(tr1), ((EIF_INTEGER_32) 55L));
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								break;
							default:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								loc19 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								for (;;) {
									tb3 = '\01';
									if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 41L)) || (EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 58L)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
										tb3 = (EIF_BOOLEAN)(tr1 != RTOUCR(630,F23_234, (Current)));
									}
									if (tb3) break;
									switch (loc19) {
										case 45L:
											loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc21;
											break;
										case 105L:
											if (loc21) {
												ti4_1 = F159_2558(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F159_2559(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 109L:
											if (loc21) {
												ti4_1 = F159_2560(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F159_2561(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 115L:
											if (loc21) {
												ti4_1 = F159_2562(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											} else {
												ti4_1 = F159_2563(Current, loc14);
												loc14 = (EIF_INTEGER_32) ti4_1;
											}
											break;
										case 120L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) loc21;
											break;
										case 88L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_) = (EIF_BOOLEAN) loc21;
											break;
										case 85L:
											*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc21;
											break;
										default:
											tr1 = RTOUCR(640,F23_209, (Current));
											ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
											F1420_14607(Current, tr1, ((EIF_INTEGER_32) 12L), ti4_1);
											break;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									if ((EIF_BOOLEAN)(tr1 != RTOUCR(630,F23_234, (Current)))) {
										loc19 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									} else {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
										loc19 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
									}
								}
								if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 41L))) {
									if (arg1) {
										if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) != F159_2551(Current, loc14))) {
											F1420_14615(Current, (EIF_BOOLEAN) 1);
										}
										if ((EIF_BOOLEAN)(F159_2570(Current, loc15) != loc14)) {
											*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_) = (EIF_INTEGER_32) loc14;
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_270(RTCW(tr1), ((EIF_INTEGER_32) 12L));
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_272(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_15_));
										}
									} else {
										loc18 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
										loc17 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_);
										loc16 = (EIF_INTEGER_32) loc14;
									}
									F1420_14599(Current, loc14);
									loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
									if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) != F159_2551(Current, loc14))) {
										F1420_14615(Current, (EIF_BOOLEAN) 1);
									}
								}
								break;
						}
					} else {
						(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
						tu4_1 = F36_638(RTCW(loc22));
						if ((EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_) > tu4_1)) {
							tr1 = RTOUCR(641,F23_210, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 13L), ti4_1);
						} else {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
							loc1 = (EIF_INTEGER_32) tu4_1;
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 70L) + loc1);
						}
					}
					if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 65L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						} else {
							loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F26_270(RTCW(tr1), loc1);
						loc13 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						loc12 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
						if ((EIF_BOOLEAN)(F159_2570(Current, loc15) == loc14)) {
							loc15 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
						} else {
							loc15 = (EIF_INTEGER_32) loc14;
						}
						F1420_14628(Current, loc15, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 62L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 63L))), loc8);
						loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_);
						loc10 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) loc12;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc13;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						if ((EIF_BOOLEAN)(tr1 == RTOUCR(630,F23_234, (Current)))) {
							if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 66L))) {
								loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc7 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
								loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + loc7);
								for (;;) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_1 = F26_258(RTCW(tr1), loc7);
									if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 57L))) break;
									loc4++;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_2 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
									loc7 += ti4_2;
								}
								if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 2L))) {
									tr1 = RTOUCR(642,F23_224, (Current));
									ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
									F1420_14607(Current, tr1, ((EIF_INTEGER_32) 27L), ti4_2);
								}
							}
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 66L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 2L)))))) {
								loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) loc10;
								if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 60L))) {
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) += loc9;
								}
							}
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
							if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 41L))) {
								tr1 = RTOUCR(643,F23_211, (Current));
								ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								F1420_14607(Current, tr1, ((EIF_INTEGER_32) 14L), ti4_2);
							}
						}
					}
					break;
				default:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), ((EIF_INTEGER_32) 16L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc19 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					for (;;) {
						if (loc21) break;
						if ((EIF_BOOLEAN)(loc19 == ((EIF_INTEGER_32) 92L))) {
							tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
							ti4_2 = (EIF_INTEGER_32) tu4_1;
							loc3 = F1420_14640(Current, ti4_2, (EIF_BOOLEAN) 0);
							if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_266(RTCW(tr1), loc5);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								}
								if ((EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 >= ((EIF_INTEGER_32) 12L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_270(RTCW(tr1), ((EIF_INTEGER_32) 54L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_272(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc3 - ((EIF_INTEGER_32) 12L)));
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 <= ((EIF_INTEGER_32) 3L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) -loc3 >= ((EIF_INTEGER_32) 10L)))) {
										loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_270(RTCW(tr1), (EIF_INTEGER_32) -loc3);
								}
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								loc19 = (EIF_INTEGER_32) loc3;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F26_271(RTCW(tr1), loc19);
								loc2++;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = RTOUCR(630,F23_234, (Current));
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != tr2);
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F26_271(RTCW(tr1), loc19);
							loc2++;
						}
						if ((EIF_BOOLEAN) !loc21) {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
								F1420_14639(Current);
							}
							tb4 = '\01';
							if (!(EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
								tb4 = (EIF_BOOLEAN) (loc2 >= RTOUCB(EIF_INTEGER_32,644,F1420_14650, (Current)));
							}
							if (tb4) {
								loc21 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								loc19 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
								tr1 = RTOUCR(645,F158_2547, (Current));
								loc21 = F22_190(RTCW(tr1), loc19);
							}
						}
					}
					if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 1L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc11 = F26_259(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + loc2) - ((EIF_INTEGER_32) 1L)));
						} else {
							loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_);
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_2 = F26_259(RTCW(tr1), (EIF_INTEGER_32) (loc6 + loc2));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) ti4_2;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) += loc2;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F26_269(RTCW(tr1), loc2, loc6);
					}
					if ((EIF_BOOLEAN) (loc2 <= RTOUCB(EIF_INTEGER_32,644,F1420_14650, (Current)))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
					}
					break;
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
			F1420_14639(Current);
		}
	}
	F1420_14599(Current, loc16);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) loc17;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) loc18;
	RTLE;
}

/* {COMPILER}.compile_character_class */
void F1420_14630 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOUCR(646,F1420_14648, (Current));
	F22_195(RTCW(loc1));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 94L))) {
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 93L)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = (EIF_BOOLEAN)(tr1 != RTOUCR(630,F23_234, (Current)));
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
			tr1 = RTOUCR(647,F23_203, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
			F1420_14607(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
		} else {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 91L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
				switch (ti4_1) {
					case 46L:
					case 58L:
					case 61L:
						loc2 = F1420_14634(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						break;
				}
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 58L))) {
					tr1 = RTOUCR(648,F23_228, (Current));
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
					F1420_14607(Current, tr1, ((EIF_INTEGER_32) 31L), ti4_1);
				} else {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) += ((EIF_INTEGER_32) 2L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 94L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					loc3 = F1420_14635(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_), (EIF_INTEGER_32) (loc2 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)));
					if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
						tr1 = RTOUCR(649,F23_227, (Current));
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
						F1420_14607(Current, tr1, ((EIF_INTEGER_32) 30L), ti4_1);
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 3L)) && *(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_))) {
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						if (loc10) {
							tr1 = RTOUCR(650,F158_2549, (Current));
							tr1 = F989_8734(RTCW(tr1), loc3);
							F22_194(RTCW(loc1), tr1);
						} else {
							tr1 = RTOUCR(650,F158_2549, (Current));
							tr1 = F989_8734(RTCW(tr1), loc3);
							F22_193(RTCW(loc1), tr1);
						}
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
						loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
					}
				}
			} else {
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 92L))) {
					tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
					ti4_1 = (EIF_INTEGER_32) tu4_1;
					loc4 = F1420_14640(Current, ti4_1, (EIF_BOOLEAN) 1);
					if ((EIF_BOOLEAN)((EIF_INTEGER_32) -loc4 == ((EIF_INTEGER_32) 3L))) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
						loc4 = (EIF_INTEGER_32) loc7;
					} else {
						if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
							loc5++;
							loc6 = (EIF_INTEGER_32) loc4;
							switch ((EIF_INTEGER_32) -loc4) {
								case 5L:
									tr1 = RTOUCR(651,F158_2538, (Current));
									F22_193(RTCW(loc1), tr1);
									break;
								case 4L:
									tr1 = RTOUCR(651,F158_2538, (Current));
									F22_194(RTCW(loc1), tr1);
									break;
								case 9L:
									F22_193(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
									break;
								case 8L:
									F22_194(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
									break;
								case 7L:
									tr1 = RTOUCR(652,F158_2546, (Current));
									F22_193(RTCW(loc1), tr1);
									break;
								case 6L:
									tr1 = RTOUCR(652,F158_2546, (Current));
									F22_194(RTCW(loc1), tr1);
									break;
								default:
									tr1 = RTOUCR(653,F23_204, (Current));
									ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
									F1420_14607(Current, tr1, ((EIF_INTEGER_32) 7L), ti4_1);
									break;
							}
						} else {
							loc7 = (EIF_INTEGER_32) loc4;
						}
					}
				}
				if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 45L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 2L)));
						tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 93L));
					}
					if (tb2) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) += ((EIF_INTEGER_32) 2L);
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
							tr1 = RTOUCR(647,F23_203, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 6L), ti4_1);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
							loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 92L))) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_3_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								loc4 = F1420_14640(Current, ti4_1, (EIF_BOOLEAN) 1);
								if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
									if ((EIF_BOOLEAN)(loc4 == (EIF_INTEGER_32) -((EIF_INTEGER_32) 3L))) {
										loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
									} else {
										*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L));
										loc8 = (EIF_INTEGER_32) loc7;
									}
								} else {
									loc8 = (EIF_INTEGER_32) loc4;
								}
							}
							if ((EIF_BOOLEAN) (loc8 < loc7)) {
								tr1 = RTOUCR(654,F23_205, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
								F1420_14607(Current, tr1, ((EIF_INTEGER_32) 8L), ti4_1);
							} else {
								F22_192(RTCW(loc1), loc8);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									ti4_1 = F25_252(RTCW(tr1), loc8);
									F22_192(RTCW(loc1), ti4_1);
								}
								loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc8) - loc7) + ((EIF_INTEGER_32) 1L));
								loc6 = (EIF_INTEGER_32) loc8;
								for (;;) {
									if ((EIF_BOOLEAN) (loc7 >= loc8)) break;
									F22_192(RTCW(loc1), loc7);
									if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										ti4_1 = F25_252(RTCW(tr1), loc7);
										F22_192(RTCW(loc1), ti4_1);
									}
									loc7++;
								}
							}
						}
					} else {
						F22_192(RTCW(loc1), loc7);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F25_252(RTCW(tr1), loc7);
							F22_192(RTCW(loc1), ti4_1);
						}
						loc5++;
						loc6 = (EIF_INTEGER_32) loc7;
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		if ((EIF_BOOLEAN)(tr1 == RTOUCR(630,F23_234, (Current)))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
		}
	}
	if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
			if (loc9) {
				if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 + ((EIF_INTEGER_32) 1L)));
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 - ((EIF_INTEGER_32) 1L)));
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), (EIF_INTEGER_32) -loc6);
			}
		} else {
			if (loc9) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), ((EIF_INTEGER_32) 17L));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), ((EIF_INTEGER_32) 16L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_272(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_271(RTCW(tr1), loc6);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F26_270(RTCW(tr1), ((EIF_INTEGER_32) 53L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F26_273(RTCW(tr1), loc1, loc9);
	}
	RTLE;
}

/* {COMPILER}.compile_repeats */
void F1420_14631 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc14 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
	loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc14;
	loc3 = (EIF_INTEGER_32) arg1;
	loc4 = (EIF_INTEGER_32) arg2;
	loc8 = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOUCR(655,F23_206, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1420_14607(Current, tr1, ((EIF_INTEGER_32) 9L), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) + ((EIF_INTEGER_32) 1L)));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 63L))) {
			if (loc15) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		} else {
			if (loc14) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = F26_258(RTCW(tr1), loc8);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 16L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc7 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) arg4;
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_) + loc3) - ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F26_259(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 2L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_266(RTCW(tr1), loc8);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F26_259(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + loc7) + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F26_260(RTCW(tr2), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				F26_269(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
				F26_266(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			}
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
				F1420_14632(Current, loc13, loc8, loc3, loc4, loc2, loc1);
			}
		} else {
			if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 17L))) {
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 27L) - ((EIF_INTEGER_32) 18L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc13 = F26_259(RTCW(tr1), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_266(RTCW(tr1), loc8);
				if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
					F1420_14632(Current, loc13, loc8, loc3, loc4, loc2, loc1);
				}
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 15L)))) {
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 36L) - ((EIF_INTEGER_32) 18L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc13 = F26_259(RTCW(tr1), loc8);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_266(RTCW(tr1), loc8);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
						F1420_14632(Current, loc13, loc8, loc3, loc4, loc2, loc1);
					}
				} else {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 53L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 54L)))) {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F26_266(RTCW(tr1), loc8);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 45L) + loc1));
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L)))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 47L) + loc1));
								} else {
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L)))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 49L) + loc1));
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 51L) + loc1));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_272(RTCW(tr1), loc3);
										if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
											loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_272(RTCW(tr1), loc4);
										}
									}
								}
							}
						}
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 66L)))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
							loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - loc8);
							if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -1L))) {
								loc6 = (EIF_INTEGER_32) loc8;
								for (;;) {
									if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 57L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
									loc6 += ti4_1;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc5 = F26_258(RTCW(tr1), loc6);
								}
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc9 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
								loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - loc6);
							}
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 0L))) {
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_20_) = (EIF_INTEGER_32) arg4;
									(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_21_)) -= arg5;
								}
								if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_266(RTCW(tr1), loc8);
								} else {
									if ((EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 1L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_275(RTCW(tr1), loc8, ((EIF_INTEGER_32) 1L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_267(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1), loc8);
										loc8++;
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_275(RTCW(tr1), loc8, ((EIF_INTEGER_32) 3L));
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_267(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1), loc8);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_267(RTCW(tr1), ((EIF_INTEGER_32) 70L), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
										loc8 += ((EIF_INTEGER_32) 2L);
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_269(RTCW(tr1), ((EIF_INTEGER_32) 0L), loc8);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_269(RTCW(tr1), (EIF_INTEGER_32) (loc8 - loc12), loc8);
										}
										loc12 = (EIF_INTEGER_32) loc8;
										loc8++;
									}
									loc4--;
								}
							} else {
								loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 >= loc3)) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_274(RTCW(tr1), loc8, loc7);
									loc6++;
								}
								if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
									loc4 -= loc3;
								}
							}
							if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L))) {
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
								for (;;) {
									if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 68L) + loc1));
									if ((EIF_BOOLEAN)(loc6 != ((EIF_INTEGER_32) 0L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
										F26_270(RTCW(tr1), ((EIF_INTEGER_32) 70L));
										if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_272(RTCW(tr1), ((EIF_INTEGER_32) 0L));
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 - loc12);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											F26_272(RTCW(tr1), loc10);
										}
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_274(RTCW(tr1), loc8, loc7);
									loc6--;
								}
								for (;;) {
									if ((EIF_BOOLEAN)(loc12 == ((EIF_INTEGER_32) 0L))) break;
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc10 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc10 - loc12) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
									loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc10) + ((EIF_INTEGER_32) 1L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc11 = F26_260(RTCW(tr1), loc6);
									if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
										loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									} else {
										loc12 -= loc11;
									}
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_270(RTCW(tr1), ((EIF_INTEGER_32) 57L));
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_272(RTCW(tr1), loc10);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									F26_269(RTCW(tr1), loc10, loc6);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_2_0_0_0_);
								F26_267(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 58L) + loc1), (EIF_INTEGER_32) (ti4_1 - loc9));
							}
						} else {
							tr1 = RTOUCR(656,F23_208, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 11L), ti4_1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {COMPILER}.compile_single_repeat */
void F1420_14632 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg6 + arg5);
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 18L) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 22L) + loc1));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 24L) + loc1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_272(RTCW(tr1), arg4);
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) -1L)))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + loc1));
		} else {
			if ((EIF_BOOLEAN)(arg3 != ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 26L) + arg5));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_272(RTCW(tr1), arg3);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_266(RTCW(tr1), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F26_258(RTCW(tr1), arg2);
				switch (ti4_1) {
					case 16L:
						if ((EIF_BOOLEAN)(loc2 == arg2)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F26_266(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							F26_266(RTCW(tr1), loc2);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_1 = F26_260(RTCW(tr2), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
							F26_269(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
						}
						break;
					case 17L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F26_266(RTCW(tr1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						break;
					default:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F26_266(RTCW(tr1), loc2);
						break;
				}
			}
			if ((EIF_BOOLEAN) (arg4 < ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_271(RTCW(tr1), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 18L) + loc1));
			} else {
				if ((EIF_BOOLEAN)(arg4 != arg3)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_271(RTCW(tr1), arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_270(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 24L) + loc1));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					F26_272(RTCW(tr1), (EIF_INTEGER_32) (arg4 - arg3));
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F26_271(RTCW(tr1), arg1);
	RTLE;
}

/* {COMPILER}.compile_counted_repeats */
EIF_BOOLEAN F1420_14633 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc3);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 57L)))) break;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 10L)) + loc4) - ((EIF_INTEGER_32) 48L));
		loc3++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc3);
	}
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 65535L))) {
		tr1 = RTOUCR(657,F23_202, (Current));
		F1420_14607(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
	} else {
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_)) > ((EIF_INTEGER_32) 1L))) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 125L))) {
				loc2 = (EIF_INTEGER_32) loc1;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 44L))) {
					loc3++;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc3);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 125L))) {
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 57L)))) break;
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 10L)) + loc4) - ((EIF_INTEGER_32) 48L));
							loc3++;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc3);
						}
					}
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 125L))) {
						if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 65535L))) {
							tr1 = RTOUCR(657,F23_202, (Current));
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 5L), loc3);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc1 > loc2))) {
								tr1 = RTOUCR(658,F23_201, (Current));
								F1420_14607(Current, tr1, ((EIF_INTEGER_32) 4L), loc3);
							} else {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					}
				}
			}
		}
	}
	if (Result) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc3;
		F1420_14631(Current, loc1, loc2, arg1, arg2, arg3);
	}
	RTLE;
	return Result;
}

/* {COMPILER}.check_posix_syntax */
EIF_INTEGER_32 F1420_14634 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOUCR(659,F158_2537, (Current));
	loc2 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 94L))) {
		loc2 += ((EIF_INTEGER_32) 3L);
	} else {
		loc2 += ((EIF_INTEGER_32) 2L);
	}
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc2);
		tb1 = F22_190(RTCW(loc1), ti4_1);
		if ((EIF_BOOLEAN) !tb1) break;
		loc2++;
	}
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc2);
	if ((EIF_BOOLEAN)(ti4_1 == loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 93L));
	}
	if (tb2) {
		RTLE;
		return (EIF_INTEGER_32) loc2;
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}/* NOTREACHED */
	
}

/* {COMPILER}.check_posix_name */
EIF_INTEGER_32 F1420_14635 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = F989_8741(RTCV(RTOUCR(660,F158_2548, (Current))));
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc4)) break;
		tr1 = RTOUCR(660,F158_2548, (Current));
		loc5 = F989_8734(RTCW(tr1), loc1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O8704[Dtype(loc5)-1173]);
		if ((EIF_BOOLEAN)(arg2 == ti4_1)) {
			Result = (EIF_INTEGER_32) loc1;
			loc3 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg2)) break;
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(loc5))-1175])(loc5, loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc3);
				if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc2++;
					loc3++;
				}
			}
		}
		if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) -1L))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_decimal_number */
EIF_INTEGER_32 F1420_14636 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 57L)) || (EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 48L))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2))) break;
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 10L)) + loc1) - ((EIF_INTEGER_32) 48L));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_octal_number */
EIF_INTEGER_32 F1420_14637 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 55L)) || (EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 48L))) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2))) break;
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 8L)) + loc1) - ((EIF_INTEGER_32) 48L));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_hex_number */
EIF_INTEGER_32 F1420_14638 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	for (;;) {
		tb1 = '\01';
		tr1 = RTOUCR(661,F158_2540, (Current));
		tb2 = F22_190(RTCW(tr1), loc1);
		if (!(EIF_BOOLEAN) !tb2) {
			tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) >= loc2);
		}
		if (tb1) break;
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 65L))) {
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 48L));
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 97L))) {
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 65L)) + ((EIF_INTEGER_32) 10L));
			} else {
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 16L)) + loc1) - ((EIF_INTEGER_32) 97L)) + ((EIF_INTEGER_32) 10L));
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	}
	RTLE;
	return Result;
}

/* {COMPILER}.scan_comment */
void F1420_14639 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		loc1 = (EIF_INTEGER_32) loc2;
		for (;;) {
			tr1 = RTOUCR(652,F158_2546, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr2))-1175])(tr2, loc2);
			tb1 = F22_190(RTCW(tr1), ti4_1);
			if ((EIF_BOOLEAN) !tb1) break;
			loc2++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc2);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 35L))) {
			loc2++;
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, loc2);
					tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L));
				}
				if (tb2) break;
				loc2++;
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc2;
	RTLE;
}

/* {COMPILER}.scan_escape */
EIF_INTEGER_32 F1420_14640 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
		tr1 = RTOUCR(662,F23_198, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
		F1420_14607(Current, tr1, ((EIF_INTEGER_32) 1L), ti4_1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 122L)))) {
			RTLE;
			return (EIF_INTEGER_32) loc2;
		} else {
			Result = F1420_14646(Current, loc2);
			if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 0L))) {
				switch (loc2) {
					case 49L:
					case 50L:
					case 51L:
					case 52L:
					case 53L:
					case 54L:
					case 55L:
					case 56L:
					case 57L:
						if ((EIF_BOOLEAN) !arg2) {
							loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							Result = F1420_14636(Current, ((EIF_INTEGER_32) 10L));
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) (Result <= arg1))) {
								tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN) (Result > ti4_1)) {
									tu4_1 = (EIF_NATURAL_32) Result;
									*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_4_) = (EIF_NATURAL_32) tu4_1;
								}
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((EIF_INTEGER_32) 12L) + Result);
							} else {
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) = (EIF_INTEGER_32) loc1;
								if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 56L))) {
									Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								} else {
									Result = F1420_14637(Current, ((EIF_INTEGER_32) 3L));
									Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
								}
							}
						} else {
							if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 56L))) {
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							} else {
								Result = F1420_14637(Current, ((EIF_INTEGER_32) 3L));
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
							}
						}
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 48L:
						Result = F1420_14637(Current, ((EIF_INTEGER_32) 3L));
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 256L));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 120L:
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						Result = F1420_14638(Current, ((EIF_INTEGER_32) 2L));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))--;
						break;
					case 99L:
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_))++;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8680[Dtype(RTCW(tr1))-1175])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_));
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_18_))) {
							tr1 = RTOUCR(663,F23_199, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 2L), ti4_1);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 97L) <= loc2) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 122L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								ti4_1 = F25_252(RTCW(tr1), loc2);
								loc2 = (EIF_INTEGER_32) ti4_1;
							}
							if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 64L))) {
								Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 64L));
							} else {
								if ((EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 127L))) {
									Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 64L));
								} else {
									Result = (EIF_INTEGER_32) loc2;
								}
							}
						}
						break;
					default:
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_10_)) {
							tr1 = RTOUCR(664,F23_200, (Current));
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_17_);
							F1420_14607(Current, tr1, ((EIF_INTEGER_32) 3L), ti4_1);
						}
						Result = (EIF_INTEGER_32) loc2;
						break;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.first_significant_code */
EIF_INTEGER_32 F1420_14641 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	for (;;) {
		if (loc3) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = F26_258(RTCW(tr1), loc1);
		switch (ti4_1) {
			case 12L:
				switch (arg2) {
					case 1L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc4 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F159_2551(Current, loc4) != F159_2551(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_INTEGER_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					case 2L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc4 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(F159_2552(Current, loc4) != F159_2552(Current, Result))) {
							if (arg3) {
								loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								Result = (EIF_INTEGER_32) loc4;
								loc1 += ((EIF_INTEGER_32) 2L);
							}
						} else {
							loc1 += ((EIF_INTEGER_32) 2L);
						}
						break;
					default:
						loc1 += ((EIF_INTEGER_32) 2L);
						break;
				}
				break;
			case 67L:
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			case 2L:
			case 3L:
				loc1++;
				break;
			case 61L:
			case 62L:
			case 63L:
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L))) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
					loc1 += ti4_1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc2 = F26_258(RTCW(tr1), loc1);
				}
				loc1 += ((EIF_INTEGER_32) 2L);
				break;
			default:
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {COMPILER}.find_firstchar */
EIF_INTEGER_32 F1420_14642 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || loc4)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1420_14641(Current, Result, ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 1);
		Result = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F26_258(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
		}
		switch (loc2) {
			case 60L:
			case 65L:
			case 66L:
			case 70L:
				loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_);
				ti4_1 = F1420_14642(Current, Result);
				Result = (EIF_INTEGER_32) ti4_1;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
					} else {
						if ((EIF_BOOLEAN)(loc3 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
				break;
			case 16L:
			case 20L:
			case 21L:
			case 26L:
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 26L))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_))++;
				} else {
					if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 16L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_))++;
					}
				}
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) < ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F26_259(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ti4_1;
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F26_259(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) != ti4_1)) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				break;
			default:
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
		if ((EIF_BOOLEAN) !loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F26_258(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.can_anchored */
EIF_BOOLEAN F1420_14643 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) arg1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1420_14641(Current, loc3, ((EIF_INTEGER_32) 2L), (EIF_BOOLEAN) 0);
		loc3 = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F26_258(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 66L)))) {
			Result = F1420_14643(Current, loc3);
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 36L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 37L)))) {
				tb1 = F159_2553(Current, loc3);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F26_258(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 15L));
			} else {
				Result = '\01';
				if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 13L))) {
						tb1 = (EIF_BOOLEAN) !F159_2552(Current, loc3);
					}
					Result = tb1;
				}
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F26_258(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.has_startline */
EIF_BOOLEAN F1420_14644 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 56L)) || (EIF_BOOLEAN) !Result)) break;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L));
		ti4_1 = F1420_14641(Current, loc3, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 0);
		loc3 = (EIF_INTEGER_32) ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = F26_258(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 60L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 65L))) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 66L)))) {
			Result = F1420_14644(Current);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 36L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 37L)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = F26_258(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_16_0_16_) + ((EIF_INTEGER_32) 1L)));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 15L));
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 13L));
			}
		}
		if (Result) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			loc1 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = F26_258(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {COMPILER}.set_start_bits */
void F1420_14645 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc9 = (EIF_BOOLEAN) arg2;
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	loc3 = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 56L)) || (EIF_BOOLEAN) (loc4 > loc2))) break;
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L));
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		for (;;) {
			if (loc8) break;
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc5 = F26_258(RTCW(tr1), loc4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 70L)) || (EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 60L)))) {
				F1420_14645(Current, loc4, loc9);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) == NULL)) {
					loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				switch (loc5) {
					case 61L:
					case 62L:
					case 63L:
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
						for (;;) {
							if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 56L))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
							loc4 += ti4_1;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc5 = F26_260(RTCW(tr1), loc4);
						}
						loc4 += ((EIF_INTEGER_32) 2L);
						break;
					case 12L:
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						loc9 = F159_2551(Current, ti4_1);
						loc4 += ((EIF_INTEGER_32) 2L);
						break;
					case 68L:
					case 69L:
						loc4++;
						F1420_14645(Current, loc4, loc9);
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) == NULL)) {
							loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
							for (;;) {
								if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 56L))) break;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
								loc4 += ti4_1;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								loc5 = F26_260(RTCW(tr1), loc4);
							}
							loc4 += ((EIF_INTEGER_32) 2L);
						}
						break;
					case 18L:
					case 19L:
					case 22L:
					case 23L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_192(RTCW(tr1), loc6);
						if (loc9) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F25_252(RTCW(tr2), loc6);
							F22_192(RTCW(tr1), ti4_1);
						}
						loc4 += ((EIF_INTEGER_32) 2L);
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 24L:
					case 25L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_192(RTCW(tr1), loc6);
						if (loc9) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F25_252(RTCW(tr2), loc6);
							F22_192(RTCW(tr1), ti4_1);
						}
						loc4 += ((EIF_INTEGER_32) 3L);
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 16L:
					case 26L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_192(RTCW(tr1), loc6);
						if (loc9) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F25_252(RTCW(tr2), loc6);
							F22_192(RTCW(tr1), ti4_1);
						}
						break;
					case 20L:
					case 21L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc6 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_192(RTCW(tr1), loc6);
						if (loc9) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							ti4_1 = F25_252(RTCW(tr2), loc6);
							F22_192(RTCW(tr1), ti4_1);
						}
						break;
					case 4L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr2 = RTOUCR(651,F158_2538, (Current));
						F22_194(RTCW(tr1), tr2);
						break;
					case 5L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr2 = RTOUCR(651,F158_2538, (Current));
						F22_193(RTCW(tr1), tr2);
						break;
					case 6L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr2 = RTOUCR(652,F158_2546, (Current));
						F22_194(RTCW(tr1), tr2);
						break;
					case 7L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr2 = RTOUCR(652,F158_2546, (Current));
						F22_193(RTCW(tr1), tr2);
						break;
					case 8L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_194(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
						break;
					case 9L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F22_193(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
						break;
					case 38L:
					case 39L:
						loc4++;
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 44L:
						loc4 += ((EIF_INTEGER_32) 2L);
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 42L:
					case 43L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
						switch (ti4_1) {
							case 4L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(651,F158_2538, (Current));
								F22_194(RTCW(tr1), tr2);
								break;
							case 5L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(651,F158_2538, (Current));
								F22_193(RTCW(tr1), tr2);
								break;
							case 6L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(652,F158_2546, (Current));
								F22_194(RTCW(tr1), tr2);
								break;
							case 7L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(652,F158_2546, (Current));
								F22_193(RTCW(tr1), tr2);
								break;
							case 8L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								F22_194(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
								break;
							case 9L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								F22_193(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
								break;
						}
						loc4 += ((EIF_INTEGER_32) 3L);
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 36L:
					case 37L:
					case 40L:
					case 41L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						switch (ti4_1) {
							case 4L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(651,F158_2538, (Current));
								F22_194(RTCW(tr1), tr2);
								break;
							case 5L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(651,F158_2538, (Current));
								F22_193(RTCW(tr1), tr2);
								break;
							case 6L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(652,F158_2546, (Current));
								F22_194(RTCW(tr1), tr2);
								break;
							case 7L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tr2 = RTOUCR(652,F158_2546, (Current));
								F22_193(RTCW(tr1), tr2);
								break;
							case 8L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								F22_194(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
								break;
							case 9L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								F22_193(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
								break;
						}
						loc4 += ((EIF_INTEGER_32) 2L);
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					case 53L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc7 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 255L))) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tb1 = F26_262(RTCW(tr1), loc7, loc1);
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								F22_192(RTCW(tr1), loc1);
							}
							loc1++;
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
						switch (ti4_1) {
							case 45L:
							case 46L:
							case 49L:
							case 50L:
								loc4 += ((EIF_INTEGER_32) 3L);
								loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								break;
							case 51L:
							case 52L:
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 3L)));
								if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
									loc4 += ((EIF_INTEGER_32) 5L);
									loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								} else {
									loc4 += ((EIF_INTEGER_32) 2L);
								}
								break;
							default:
								loc4 += ((EIF_INTEGER_32) 2L);
								break;
						}
						break;
					case 56L:
						loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
					default:
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						break;
				}
			}
		}
		if (loc10) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F26_260(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
			loc3 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc5 = F26_258(RTCW(tr1), loc3);
		}
	}
	if (loc10) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {COMPILER}.escape_character */
EIF_INTEGER_32 F1420_14646 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	switch (arg1) {
		case 58L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
			break;
		case 59L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
			break;
		case 60L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
			break;
		case 61L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
			break;
		case 62L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
			break;
		case 63L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
			break;
		case 64L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
			break;
		case 65L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 1L);
			break;
		case 66L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 2L);
			break;
		case 68L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 4L);
			break;
		case 83L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 6L);
			break;
		case 87L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 8L);
			break;
		case 90L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 10L);
			break;
		case 91L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
			break;
		case 92L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
			break;
		case 93L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
			break;
		case 124L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
			break;
		case 95L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
			break;
		case 96L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
			break;
		case 97L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 98L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 3L);
			break;
		case 100L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 5L);
			break;
		case 101L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
			break;
		case 102L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 110L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 114L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
			break;
		case 115L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 7L);
			break;
		case 116L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		case 119L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 9L);
			break;
		case 122L:
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -((EIF_INTEGER_32) 11L);
			break;
		default:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	return Result;
}

/* {COMPILER}.empty_pattern */
static EIF_REFERENCE F1420_14647_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	
#define Result RTOTRR
	RTOUDR(626)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("T",1,84);
	tc1 = (EIF_CHARACTER_8) '\000';
	ti4_1 = ((EIF_INTEGER_32) 1L);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R7073[Dtype(RTCW(Result))-960])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &ti4_1);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1420_14647 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(626,F1420_14647_body,(Current));
}

/* {COMPILER}.actual_set */
static EIF_REFERENCE F1420_14648_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(646)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(21, 0x01).id, 21, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F22_187(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1420_14648 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(646,F1420_14648_body,(Current));
}

/* {COMPILER}.infinity */
static EIF_INTEGER_32 F1420_14649_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 633)

	
	RTEV;
	RTOTP;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1420_14649 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,633,F1420_14649_body,(Current));
}

/* {COMPILER}.maxlit */
static EIF_INTEGER_32 F1420_14650_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 644)

	
	RTEV;
	RTOTP;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1420_14650 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,644,F1420_14650_body,(Current));
}

void EIF_Minit733 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
