/*
 * Code for class JSON_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js726.h"
#include "eif_built_in.h"
#include <ctype.h>
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_PARSER}.make_with_string */
void F1413_14330 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1413_14332(Current);
	F177_2769(Current, arg1);
	RTLE;
}

/* {JSON_PARSER}.initialize */
void F1413_14332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(loc1));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
	tr1 = RTLNSMART(eif_new_type(1302, 1).id);
	F1303_11437(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1302, 1).id);
	F1303_11436(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1303, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1053,0xFF01,1175,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1054_8838(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_PARSER}.is_valid */
EIF_BOOLEAN F1413_14334 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_);
}

/* {JSON_PARSER}.json_string_buffer_size */
EIF_INTEGER_32 F1413_14343 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 512L);
}

/* {JSON_PARSER}.json_number_buffer_size */
EIF_INTEGER_32 F1413_14344 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
}

/* {JSON_PARSER}.parsed_json_object */
EIF_REFERENCE F1413_14346 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1337, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {JSON_PARSER}.reset */
void F1413_14348 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F177_2770(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1054_8874(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1413_14377(Current);
	tr1 = RTLNSMART(eif_new_type(1303, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1302, 1).id);
	F1303_11437(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1302, 1).id);
	F1303_11436(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_PARSER}.parse_content */
void F1413_14350 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_)) {
		F1413_14376(Current);
		if (F1413_14369(Current)) {
			tr1 = F1413_14357(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			tb1 = '\0';
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
				tb1 = F1413_14368(Current);
			}
			if (tb1) {
				tr1 = RTMS_EX_H("Remaining element outside the main json value",45,341899109);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1413_14352(Current, tr1, ti4_1);
			}
		} else {
			tr1 = RTMS_EX_H("Syntax error unexpected token, expecting \'{\' or \'[\'",51,1020017191);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
			F1413_14352(Current, tr1, ti4_1);
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1413_14377(Current);
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {JSON_PARSER}.report_error */
void F1413_14351 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7161[Dtype(RTCW(tr1))-936])(tr1, arg1);
	RTLE;
}

/* {JSON_PARSER}.report_error_at */
void F1413_14352 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H(" (position: ",12,1385097760);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(arg1))-1174])(arg1, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
		tr2 = RTMS_EX_H(")",1,41);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
		F1413_14351(Current, tr1);
	} else {
		F1413_14351(Current, arg1);
	}
	RTLE;
}

/* {JSON_PARSER}.next_json_value */
EIF_REFERENCE F1413_14357 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
		F177_2775(Current);
		loc1 = F177_2781(Current);
		switch (loc1) {
			case (EIF_CHARACTER_8) '{':
				Result = F1413_14358(Current);
				break;
			case (EIF_CHARACTER_8) '\"':
				Result = F1413_14359(Current);
				break;
			case (EIF_CHARACTER_8) '[':
				Result = F1413_14360(Current);
				break;
			default:
				tb1 = '\01';
				tb2 = EIF_TEST(isdigit(loc1));
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-');
				}
				if (tb1) {
					Result = F1413_14361(Current);
				} else {
					if (F1413_14362(Current)) {
						Result = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						F177_2773(Current);
						F177_2773(Current);
						F177_2773(Current);
					} else {
						if (F1413_14364(Current)) {
							Result = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							F177_2773(Current);
							F177_2773(Current);
							F177_2773(Current);
						} else {
							if (F1413_14363(Current)) {
								Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								F177_2773(Current);
								F177_2773(Current);
								F177_2773(Current);
								F177_2773(Current);
							} else {
								tr1 = RTMS_EX_H("JSON value is not well formed",29,1143638628);
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
								F1413_14352(Current, tr1, ti4_1);
								Result = (EIF_REFERENCE) NULL;
							}
						}
					}
				}
				break;
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.next_json_object */
EIF_REFERENCE F1413_14358 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	F177_2773(Current);
	F177_2775(Current);
	if ((EIF_BOOLEAN)(F177_2781(Current) == (EIF_CHARACTER_8) '}')) {
		tr1 = RTLNS(eif_new_type(1337, 0x01).id, 1337, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1338_12421(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1337, 0x01).id, 1337, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1338_12421(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_2_));
		F177_2774(Current);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			if ((EIF_BOOLEAN) !loc1) break;
			F177_2773(Current);
			F177_2775(Current);
			loc2 = F1413_14359(Current);
			F177_2773(Current);
			F177_2775(Current);
			if ((EIF_BOOLEAN)(F177_2781(Current) == (EIF_CHARACTER_8) ':')) {
				F177_2773(Current);
				F177_2775(Current);
			} else {
				tr1 = RTMS_EX_H("\012 Input string is a not well formed JSON, expected [:] found [",62,979945051);
				tr2 = eif_out__c1_s1(F177_2781(Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
				tr2 = RTMS_EX_H("]",1,93);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1413_14352(Current, tr1, ti4_1);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			loc3 = F1413_14357(Current);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc2 != NULL)))) {
				F1338_12425(RTCW(Result), loc3, loc2);
				F177_2773(Current);
				F177_2775(Current);
				if ((EIF_BOOLEAN)(F177_2781(Current) == (EIF_CHARACTER_8) '}')) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					if ((EIF_BOOLEAN)(F177_2781(Current) != (EIF_CHARACTER_8) ',')) {
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						tr1 = RTMS_EX_H("JSON Object syntactically malformed expected , found [",54,605843291);
						tr2 = eif_out__c1_s1(F177_2781(Current));
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1413_14352(Current, tr1, ti4_1);
					}
				}
			} else {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.next_json_string */
EIF_REFERENCE F1413_14359 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(loc3))-1172])(loc3);
	if ((EIF_BOOLEAN)(F177_2781(Current) == (EIF_CHARACTER_8) '\"')) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			if ((EIF_BOOLEAN) !loc1) break;
			F177_2773(Current);
			loc2 = F177_2781(Current);
			if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\"')) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\\')) {
					F177_2773(Current);
					loc2 = F177_2781(Current);
					if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) 'u')) {
						loc4 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O8704[Dtype(loc3)-1173]);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						tr1 = RTMS_EX_H("\\u",2,23669);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8728[Dtype(RTCW(loc3))-1175])(loc3, tr1);
						F1413_14365(Current, loc3);
						loc2 = F177_2781(Current);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O8704[Dtype(loc3)-1173]);
						if ((EIF_BOOLEAN) !F1413_14367(Current, loc3, loc4, ti4_1)) {
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr1 = RTMS_EX_H("Input string is not well formed JSON, expected Unicode value, found [",69,2033199195);
							tr2 = eif_out__c1_s1(loc2);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
							tr2 = RTMS_EX_H("]",1,93);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
							F1413_14352(Current, tr1, ti4_1);
						}
					} else {
						tb1 = '\01';
						tb2 = '\0';
						if ((EIF_BOOLEAN) !F176_2766(Current, loc2)) {
							tb2 = (EIF_BOOLEAN) !F176_2767(Current, loc2);
						}
						if (!tb2) {
							tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\012');
						}
						if (tb1) {
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr1 = RTMS_EX_H("Input string is not well formed JSON, found [",45,1899730011);
							tr2 = eif_out__c1_s1(loc2);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
							tr2 = RTMS_EX_H("]",1,93);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
							F1413_14352(Current, tr1, ti4_1);
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc3))-1175])(loc3, (EIF_CHARACTER_8) '\\');
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc3))-1175])(loc3, loc2);
						}
					}
				} else {
					tb1 = '\0';
					if (F176_2766(Current, loc2)) {
						tb1 = (EIF_BOOLEAN)(loc2 != (EIF_CHARACTER_8) '/');
					}
					if (tb1) {
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						tr1 = RTMS_EX_H("Input string is not well formed JSON, found [",45,1899730011);
						tr2 = eif_out__c1_s1(loc2);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1413_14352(Current, tr1, ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\000')) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc3))-1175])(loc3, loc2);
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc3))-1175])(loc3, loc2);
						}
					}
				}
			}
		}
		Result = RTLNS(eif_new_type(1305, 0x01).id, 1305, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = F1_14(loc3);
		F1306_11479(RTCW(Result), tr1);
	} else {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.parse_array */
EIF_REFERENCE F1413_14360 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1338, 0x01).id, 1338, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1339_12458(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_1_));
	F177_2773(Current);
	F177_2775(Current);
	if ((EIF_BOOLEAN)(F177_2781(Current) == (EIF_CHARACTER_8) ']')) {
	} else {
		F177_2774(Current);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			if ((EIF_BOOLEAN) !loc1) break;
			F177_2773(Current);
			F177_2775(Current);
			loc2 = F1413_14357(Current);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) && (EIF_BOOLEAN)(loc2 != NULL))) {
				F1339_12471(RTCW(Result), loc2);
				F177_2773(Current);
				F177_2775(Current);
				loc3 = F177_2781(Current);
				if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ']')) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					if ((EIF_BOOLEAN)(loc3 != (EIF_CHARACTER_8) ',')) {
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						tr1 = RTMS_EX_H("Array is not well formed JSON, found [",38,206143579);
						tr2 = eif_out__c1_s1(loc3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1413_14352(Current, tr1, ti4_1);
					}
				}
			} else {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = RTMS_EX_H("Array is not well formed JSON, found [",38,206143579);
				tr2 = eif_out__c1_s1(F177_2781(Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
				tr2 = RTMS_EX_H("]",1,93);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1413_14352(Current, tr1, ti4_1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.next_json_number */
EIF_REFERENCE F1413_14361 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(loc4))-1172])(loc4);
	tc1 = F177_2781(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc4))-1175])(loc4, tc1);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		if ((EIF_BOOLEAN) !loc1) break;
		F177_2773(Current);
		loc3 = F177_2781(Current);
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		if (!(EIF_BOOLEAN) !F177_2778(Current)) {
			tb4 = F176_2765(Current, loc3);
		}
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ',');
		}
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '\012');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '\015');
		}
		if (tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			F177_2774(Current);
		} else {
			tc1 = F177_2781(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(loc4))-1175])(loc4, tc1);
		}
	}
	if (F1413_14366(Current, loc4)) {
		tb1 = F1168_10040(RTCW(loc4));
		if (tb1) {
			Result = RTLNS(eif_new_type(1304, 0x01).id, 1304, _OBJSIZ_1_0_0_1_0_0_0_0_);
			ti8_1 = F1168_10074(RTCW(loc4));
			F1305_11450(RTCW(Result), ti8_1);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F1168_10033(RTCW(loc4));
			if (tb1) {
				Result = RTLNS(eif_new_type(1304, 0x01).id, 1304, _OBJSIZ_1_0_0_1_0_0_0_0_);
				tr8_1 = F1168_10082(RTCW(loc4));
				F1305_11452(RTCW(Result), tr8_1);
			}
		}
	} else {
		tr1 = RTMS_EX_H("Expected a number, found [",26,1659187803);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, loc4);
		tr2 = RTMS_EX_H("]",1,93);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
		F1413_14352(Current, tr1, ti4_1);
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.is_null */
EIF_BOOLEAN F1413_14362 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(573,F1413_14372, (Current));
	Result = F177_2777(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	RTLE;
	return Result;
}

/* {JSON_PARSER}.is_false */
EIF_BOOLEAN F1413_14363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(574,F1413_14370, (Current));
	Result = F177_2777(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 5L));
	RTLE;
	return Result;
}

/* {JSON_PARSER}.is_true */
EIF_BOOLEAN F1413_14364 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(575,F1413_14371, (Current));
	Result = F177_2777(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	RTLE;
	return Result;
}

/* {JSON_PARSER}.read_unicode_info */
void F1413_14365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 4L))) {
			tb1 = (EIF_BOOLEAN) !F177_2778(Current);
		}
		if (tb1) break;
		F177_2773(Current);
		tc1 = F177_2781(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8732[Dtype(RTCW(arg1))-1175])(arg1, tc1);
		loc1++;
	}
	RTLE;
}

/* {JSON_PARSER}.is_valid_number */
EIF_BOOLEAN F1413_14366 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8593[Dtype(RTCW(loc4))-1172])(loc4);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
		if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-')) {
			F1176_10431(RTCW(loc4), loc1);
			loc2++;
			if ((EIF_BOOLEAN) (loc2 > loc3)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
			}
		}
		tb1 = '\0';
		if (Result) {
			tb2 = EIF_TEST(isdigit(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '0')) {
				F1176_10431(RTCW(loc4), loc1);
				loc2++;
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
				}
			} else {
				F1176_10431(RTCW(loc4), loc1);
				loc2++;
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
					for (;;) {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb2 = EIF_TEST(isdigit(loc1));
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) break;
						F1176_10431(RTCW(loc4), loc1);
						loc2++;
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
						}
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) (loc2 > loc3)) {
	} else {
		if (Result) {
			if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '.')) {
				F1176_10431(RTCW(loc4), loc1);
				loc2++;
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
				tb2 = EIF_TEST(isdigit(loc1));
				if (tb2) {
					for (;;) {
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb3 = EIF_TEST(isdigit(loc1));
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						F1176_10431(RTCW(loc4), loc1);
						loc2++;
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
						}
					}
				} else {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		}
		if (Result) {
			if (F176_2768(Current, loc1)) {
				F1176_10431(RTCW(loc4), loc1);
				loc2++;
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '+') || (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-'))) {
					F1176_10431(RTCW(loc4), loc1);
					loc2++;
					if ((EIF_BOOLEAN) (loc2 <= loc3)) {
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
					}
				}
				tb3 = EIF_TEST(isdigit(loc1));
				if (tb3) {
					for (;;) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb4 = EIF_TEST(isdigit(loc1));
							tb3 = (EIF_BOOLEAN) !tb4;
						}
						if (tb3) break;
						F1176_10431(RTCW(loc4), loc1);
						loc2++;
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
						}
					}
				} else {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		}
		if (Result) {
			for (;;) {
				tb4 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > loc3)) {
					tb5 = eif_builtin_CHARACTER_8_is_space__c1_b(loc1);
					tb4 = (EIF_BOOLEAN) !tb5;
				}
				if (tb4) break;
				F1176_10431(RTCW(loc4), loc1);
				loc2++;
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc2));
				}
			}
			Result = '\0';
			if ((EIF_BOOLEAN) (loc2 > loc3)) {
				tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8689[Dtype(RTCW(loc4))-1174])(loc4, arg1);
				Result = tb5;
			}
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.is_substring_valid_unicode */
EIF_BOOLEAN F1413_14367 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg3 - arg2) == ((EIF_INTEGER_32) 5L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, arg2));
		tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
	}
	if (tb2) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L))));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'u');
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L));
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > arg3) || (EIF_BOOLEAN)(Result == (EIF_BOOLEAN) 0))) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(RTCW(arg1))-960])(arg1, loc1));
			switch (tc1) {
				case (EIF_CHARACTER_8) '0':
				case (EIF_CHARACTER_8) '1':
				case (EIF_CHARACTER_8) '2':
				case (EIF_CHARACTER_8) '3':
				case (EIF_CHARACTER_8) '4':
				case (EIF_CHARACTER_8) '5':
				case (EIF_CHARACTER_8) '6':
				case (EIF_CHARACTER_8) '7':
				case (EIF_CHARACTER_8) '8':
				case (EIF_CHARACTER_8) '9':
				case (EIF_CHARACTER_8) 'A':
				case (EIF_CHARACTER_8) 'B':
				case (EIF_CHARACTER_8) 'C':
				case (EIF_CHARACTER_8) 'D':
				case (EIF_CHARACTER_8) 'E':
				case (EIF_CHARACTER_8) 'F':
				case (EIF_CHARACTER_8) 'a':
				case (EIF_CHARACTER_8) 'b':
				case (EIF_CHARACTER_8) 'c':
				case (EIF_CHARACTER_8) 'd':
				case (EIF_CHARACTER_8) 'e':
				case (EIF_CHARACTER_8) 'f':
					break;
				default:
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.extra_elements */
EIF_BOOLEAN F1413_14368 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F177_2778(Current)) {
		F177_2773(Current);
	}
	loc1 = F177_2781(Current);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) ' ') || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\015')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\000')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\011')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\012'))) {
			tb1 = (EIF_BOOLEAN) !F177_2778(Current);
		}
		if (tb1) break;
		F177_2773(Current);
		loc1 = F177_2781(Current);
	}
	RTLE;
	return (EIF_BOOLEAN) F177_2778(Current);
}

/* {JSON_PARSER}.is_valid_start_symbol */
EIF_BOOLEAN F1413_14369 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O8704[Dtype(loc1)-1173]);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		Result = '\01';
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(loc1)-960])(loc1, ((EIF_INTEGER_32) 1L)));
		if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '{')) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7374[Dtype(loc1)-960])(loc1, ((EIF_INTEGER_32) 1L)));
			Result = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '[');
		}
	}
	RTLE;
	return Result;
}

/* {JSON_PARSER}.false_id */

EIF_REFERENCE F1413_14370 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (574,RTMS_EX_H("false",5,1635280741));
}

/* {JSON_PARSER}.true_id */

EIF_REFERENCE F1413_14371 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (575,RTMS_EX_H("true",4,1953658213));
}

/* {JSON_PARSER}.null_id */

EIF_REFERENCE F1413_14372 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (573,RTMS_EX_H("null",4,1853189228));
}

/* {JSON_PARSER}.initialize_buffers */
void F1413_14376 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	tr2 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O8704[Dtype(tr2)-1173]);
	ti4_2 = F1413_14343(Current);
	ti4_1 = eif_min_int32 (ti4_1,ti4_2);
	F1174_10304(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	ti4_1 = F1413_14344(Current);
	F1174_10304(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1175, 1).id);
	ti4_1 = F1413_14344(Current);
	F1174_10304(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_PARSER}.free_buffers */
void F1413_14377 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(loc1));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit726 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
