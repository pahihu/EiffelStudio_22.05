/*
 * Code for class IRI
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir743.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRI}.make_from_string */
void F1430_14911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	F1174_10304(RTCW(loc1), ti4_1);
	F1430_14930(Current, arg1, loc1);
	F1429_14845(Current, loc1);
	tr1 = F1430_14931(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1429_14884(Current, tr1);
	RTLE;
}

/* {IRI}.make_from_uri */
void F1430_14912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = F1429_14879(RTCW(arg1));
	F1429_14845(Current, tr1);
	RTLE;
}

/* {IRI}.to_uri */
EIF_REFERENCE F1430_14929 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1428, 0x01).id, 1428, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = F1429_14879(Current);
	F1429_14845(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {IRI}.iri_into_uri */
void F1430_14930 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc3 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			F203_3025(Current, loc3, arg2);
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8565[Dtype(RTCW(arg2))-1172])(arg2, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {IRI}.to_internationalized_percent_encoded_string */
EIF_REFERENCE F1430_14931 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1430_14932(Current, arg1);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {IRI}.to_attached_internationalized_percent_encoded_string */
EIF_REFERENCE F1430_14932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8704[Dtype(arg1)-1173]);
	F1171_10137(RTCW(Result), ti4_1);
	F1430_14933(Current, arg1, Result);
	RTLE;
	return Result;
}

/* {IRI}.append_percent_encoded_string_into_internationalized_percent_encoded_string */
void F1430_14933 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,207,1312,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc5 = RTLNS(typres0.id, 207, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F208_3115(RTCW(loc5), loc1);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8505[Dtype(RTCW(arg1))-1171])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, loc1);
		switch (loc4) {
			case 43U:
				F1170_10107(RTCW(arg2), (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L));
				F1170_10107(RTCW(arg2), (EIF_NATURAL_32) ((EIF_INTEGER_32) 50L));
				F1170_10107(RTCW(arg2), (EIF_NATURAL_32) ((EIF_INTEGER_32) 48L));
				break;
			case 37U:
				if ((EIF_BOOLEAN)(loc1 == loc2)) {
					F1170_10107(RTCW(arg2), loc4);
				} else {
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc2)) {
						loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8468[Dtype(RTCW(arg1))-1171])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 85L)) || (EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 117L)))) {
							F208_3116(RTCW(loc5), loc1);
							loc3 = F203_3029(Current, arg1, loc5);
							loc1 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O3052[Dtype(loc5)-206]);
							F1170_10107(RTCW(arg2), loc3);
						} else {
							F208_3116(RTCW(loc5), loc1);
							loc3 = F203_3030(Current, arg1, loc5);
							if ((EIF_BOOLEAN) (loc3 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
								F1170_10107(RTCW(arg2), loc3);
								loc1 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O3052[Dtype(loc5)-206]);
							} else {
								F1170_10107(RTCW(arg2), loc4);
							}
						}
					}
				}
				break;
			default:
				F1170_10107(RTCW(arg2), loc4);
				break;
		}
		loc1++;
	}
	RTLE;
}

void EIF_Minit743 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
