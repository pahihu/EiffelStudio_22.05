/*
 * Code for class IRON_REMOVE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir748.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REMOVE_TASK}.name */

EIF_REFERENCE F1435_14960 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (44,RTMS_EX_H("remove",6,2060930149));
}

/* {IRON_REMOVE_TASK}.process */
void F1435_14961 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(486, 0x01).id, 486, _OBJSIZ_5_12_0_0_0_0_0_0_);
	F326_4596(RTCW(loc1), Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1113,0xFF01,0,0xFF01,485,0xFF01,100,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	((EIF_TYPED_VALUE *)tr1+3)->it_r = arg1;
	RTAR(tr1,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1162,0xFF01,0xFFF9,0,1113,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A748_89, (EIF_POINTER) _A748_89, (EIF_POINTER)(F1435_14962),tr1, 1, 0);
	}
	F320_4507(RTCW(loc1), tr2);
	RTLE;
}

/* {IRON_REMOVE_TASK}.execute */
void F1435_14962 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLR(7,tr2);
	RTLR(8,loc5);
	RTLR(9,loc3);
	RTLR(10,loc6);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLIU(13);
	
	RTGC;
	tb1 = F487_6288(RTCW(arg1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc2 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1059_8908(RTCW(loc2), ((EIF_INTEGER_32) 10L));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		tr1 = F1111_9569(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7162[Dtype(RTCW(loc2))-1053])(loc2, tr1);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,1192,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc2 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		tr1 = RTOUCR(239,F487_6289, (RTCW(arg1)));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(tr1))-908])(tr1);
		F1059_8908(RTCW(loc2), ti4_1);
		tr1 = RTOUCR(239,F487_6289, (RTCW(arg1)));
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(tr1))-635])(tr1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc4)-515])(loc4);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
			tr1 = F306_4224(Current, tr1);
			F1402_13608(Current, tr1);
			F1432_14947(Current);
			loc1 = (EIF_REFERENCE) NULL;
			tb2 = '\01';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
			tb3 = F1171_10171(RTCW(tr1), tw1);
			if (!tb3) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
				tb3 = F1171_10171(RTCW(tr1), tw1);
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
				loc1 = F1111_9590(RTCW(tr1), tr2);
			} else {
				tb2 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
				tr1 = F1111_9589(RTCW(tr1), tr2);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					tb3 = F870_8129(loc5);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc5)-908])(loc5);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
						loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7541[Dtype(loc5)-1053])(loc5);
					} else {
						tr1 = RTMS_EX_H("-> ",3,2965024);
						F1402_13608(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
						tr1 = F306_4225(Current, tr1);
						F1402_13608(Current, tr1);
						F1432_14947(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,0xFF01,0xFFF9,2,1113,0xFF01,1167,0xFF01,1192,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc3 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
						}
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(loc5)-908])(loc5);
						F1059_8908(RTCW(loc3), ti4_1);
						loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(loc5)-635])(loc5);
						for (;;) {
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc6)-515])(loc6);
							if (tb2) break;
							tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
							tb3 = F1111_9583(RTCW(tr1), tr2);
							if (tb3) {
								loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1172,0xFF01,1192,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr1 = RTLNTS(typres0.id, 3, 0);
								}
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
								tr2 = F1193_10958(RTCW(tr2));
								((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
								RTAR(tr1,tr2);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
								((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
								RTAR(tr1,tr2);
								F1059_8948(RTCW(loc3), tr1);
							}
							tb3 = F481_6207(RTCW(arg1));
							if (tb3) {
								tr1 = RTMS_EX_H("    - ",6,602139936);
								F1402_13608(Current, tr1);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc6)-515])(loc6);
								tr1 = F1193_10958(RTCW(tr1));
								F1402_13608(Current, tr1);
								tr1 = RTMS_EX_H("\012",1,10);
								F1402_13608(Current, tr1);
							}
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc6)-515])(loc6);
						}
						tb3 = F481_6207(RTCW(arg1));
						if (tb3) {
						} else {
							tr1 = RTMS_EX_H("Select a package",16,1951861349);
							tr1 = F1432_14948(Current, tr1, loc3, loc1);
							loc1 = (EIF_REFERENCE) tr1;
						}
						if ((EIF_BOOLEAN)(loc1 != NULL)) {
							tr1 = RTMS_EX_H("-> Remove ",10,634747168);
							F1402_13608(Current, tr1);
							tr1 = F1193_10958(RTCW(loc1));
							F1402_13608(Current, tr1);
							tr1 = RTMS_EX_H("\012",1,10);
							F1402_13608(Current, tr1);
						}
					}
				}
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc4)-515])(loc4);
					loc1 = F1111_9588(RTCW(tr1), tr2);
				}
			}
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = RTMS_EX_H("  -> ",5,540081696);
				F1402_13608(Current, tr1);
				tr1 = F306_4209(Current);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tb3 = F1111_9583(RTCW(tr1), loc1);
				if ((EIF_BOOLEAN) !tb3) {
					tr1 = RTMS_EX_H("  -> ",5,540081696);
					F1402_13608(Current, tr1);
					tr1 = F306_4210(Current);
					F1402_13608(Current, tr1);
					F1432_14947(Current);
				} else {
					F1059_8948(RTCW(loc2), loc1);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc4)-515])(loc4);
		}
	}
	tb3 = F870_8129(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb3) {
		loc7 = F1059_8922(RTCW(loc2));
		for (;;) {
			tb3 = F659_7888(loc7);
			if (tb3) break;
			loc1 = F659_7879(loc7);
			tr1 = F1193_10958(RTCW(loc1));
			tr1 = F306_4223(Current, tr1);
			F1402_13608(Current, tr1);
			tb4 = '\0';
			tb5 = F481_6205(RTCW(arg1));
			if (tb5) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tr1 = F1111_9586(RTCW(tr1), loc1);
				loc8 = tr1;
				tb4 = EIF_TEST(loc8);
			}
			if (tb4) {
				tr1 = RTMS_EX_H(" from \"",7,997127202);
				F1402_13608(Current, tr1);
				tr1 = F1194_11030(loc8);
				F1402_13608(Current, tr1);
				tr1 = RTMS_EX_H("\"",1,34);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			}
			tb4 = F481_6206(RTCW(arg1));
			if (tb4) {
				tr1 = RTMS_EX_H(" -> ",4,539835936);
				F1402_13608(Current, tr1);
				tr1 = F306_4218(Current);
				F1402_13608(Current, tr1);
				F1432_14947(Current);
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
				F1110_9559(RTCW(tr1), loc1);
				tr1 = RTMS_EX_H(" -> ",4,539835936);
				F1402_13608(Current, tr1);
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				F1111_9573(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				F1111_9575(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
				tb4 = F1111_9583(RTCW(tr1), loc1);
				if (tb4) {
					tr1 = F306_4214(Current);
					F1402_13608(Current, tr1);
				} else {
					tr1 = F306_4213(Current);
					F1402_13608(Current, tr1);
				}
				F1432_14947(Current);
			}
			F659_7894(loc7);
		}
	}
	RTLE;
}

void EIF_Minit748 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
