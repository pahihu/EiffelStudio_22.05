/*
 * Code for class IRON_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir745.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_TASK}.make */
void F1432_14942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(301, 0x01).id, 301, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F302_4155(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_TASK}.print_new_line */
void F1432_14947 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F100_1858(RTCV(RTOUCR(2,F1_24, (Current))));
	RTLE;
}

/* {IRON_TASK}.selected_package */
EIF_REFERENCE F1432_14948 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc5);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Current);
	RTLR(6,arg1);
	RTLR(7,loc4);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6830[Dtype(RTCW(arg2))-635])(arg2);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5821[Dtype(loc5)-515])(loc5);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
		tr1 = eif_boxed_item(tr1,2);
		if ((EIF_BOOLEAN)(arg3 == tr1)) {
			loc2 = (EIF_INTEGER_32) loc1;
		}
		tr1 = RTMS_EX_H("  ",2,8224);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
		tr2 = RTMS_EX_H(") ",2,10528);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
		F1402_13608(Current, tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5820[Dtype(loc5)-515])(loc5);
		tr1 = eif_boxed_item(tr1,1);
		F1402_13608(Current, tr1);
		tr1 = RTMS_EX_H("\012",1,10);
		F1402_13608(Current, tr1);
		loc1++;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5822[Dtype(loc5)-515])(loc5);
	}
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 0L))) break;
		tr1 = RTMS_EX_H("  > ",4,538983968);
		F1402_13608(Current, tr1);
		F1402_13608(Current, arg1);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H(" [",2,8283);
			tr2 = eif_out__i4_s1(loc2);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(tr1)-1174])(tr1, tr2);
			tr2 = RTMS_EX_H("] ",2,23840);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8694[Dtype(RTCW(tr1))-1174])(tr1, tr2);
			F1402_13608(Current, tr1);
		}
		tr1 = RTMS_EX_H("(q=cancel): ",12,1452986656);
		F1402_13608(Current, tr1);
		F100_1875(RTCV(RTOUCR(2,F1_24, (Current))));
		loc4 = F100_1826(RTCV(RTOUCR(2,F1_24, (Current))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8586[Dtype(RTCW(loc4))-1172])(loc4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8587[Dtype(RTCW(loc4))-1172])(loc4);
		tb2 = F874_8129(RTCW(loc4));
		if (tb2) {
			loc3 = (EIF_INTEGER_32) loc2;
		} else {
			tr1 = RTMS_EX_H("q",1,113);
			tb2 = F1168_10049(RTCW(loc4), tr1);
			if (tb2) {
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				tb2 = F1168_10038(RTCW(loc4));
				if (tb2) {
					loc3 = F1168_10072(RTCW(loc4));
					tb2 = '\0';
					if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 1L))) {
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(arg2))-908])(arg2);
						tb2 = (EIF_BOOLEAN) (loc3 <= ti4_1);
					}
					if (tb2) {
					} else {
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					}
				}
			}
		}
	}
	tb2 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7140[Dtype(RTCW(arg2))-908])(arg2);
		tb2 = (EIF_BOOLEAN) (loc3 <= ti4_1);
	}
	if (tb2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7070[Dtype(RTCW(arg2))-987])(arg2, (EIF_REFERENCE) &loc3);
		Result = eif_boxed_item(tr1,2);
	}
	RTLE;
	return Result;
}

void EIF_Minit745 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
