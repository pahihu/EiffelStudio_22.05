/*
 * Code for class CONF_DIRECTORY_LOCATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co713.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_DIRECTORY_LOCATION}.make */
void F1400_13602 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1400_13604(Current, arg1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {CONF_DIRECTORY_LOCATION}.set_path */
void F1400_13604 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = F1399_13600(Current, arg1);
	tb1 = F878_8129(RTCW(loc1));
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1173_10265(RTCW(loc1), tw1);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	tw1 = F1173_10219(RTCW(loc1), ti4_1);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
	if ((EIF_BOOLEAN)(tw1 != tw2)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		F1173_10265(RTCW(loc1), tw1);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit713 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
