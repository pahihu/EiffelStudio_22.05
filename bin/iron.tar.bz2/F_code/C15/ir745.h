
#ifndef _C15_ir745_
#define _C15_ir745_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1432_14942(EIF_REFERENCE, EIF_REFERENCE);
extern void F1432_14947(EIF_REFERENCE);
extern EIF_REFERENCE F1432_14948(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit745(void);
extern void F1402_13608(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F100_1826(EIF_REFERENCE);
extern void F302_4155(EIF_REFERENCE, EIF_REFERENCE);
extern void F100_1858(EIF_REFERENCE);
extern void F100_1875(EIF_REFERENCE);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);
extern EIF_BOOLEAN F874_8129(EIF_REFERENCE);
extern EIF_BOOLEAN F1168_10049(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1168_10038(EIF_REFERENCE);
extern EIF_INTEGER_32 F1168_10072(EIF_REFERENCE);
extern char *(*R8586[])();
extern char *(*R8587[])();
extern char *(*R7070[])();
extern char *(*R8694[])();
extern char *(*R5820[])();
extern char *(*R5821[])();
extern char *(*R5822[])();
extern char *(*R6830[])();
extern char *(*R7140[])();

#ifdef __cplusplus
}
#endif

#endif
