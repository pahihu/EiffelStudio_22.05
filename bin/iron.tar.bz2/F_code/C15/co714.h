
#ifndef _C15_co714_
#define _C15_co714_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1401_13605(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1401_13607(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit714(void);
extern EIF_REFERENCE F1399_13600(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
