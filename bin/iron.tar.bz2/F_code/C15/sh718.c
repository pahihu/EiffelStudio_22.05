/*
 * Code for class SHARED_LOCALE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh718.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_LOCALE}.locale */
EIF_REFERENCE F1405_13625 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(RTCV(RTOUCR(622,F1405_13631, (Current))));
	RTLE;
	return Result;
}

/* {SHARED_LOCALE}.locale_manager */
static EIF_REFERENCE F1405_13626_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(623)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tb1 = '\0';
	if (F450_5994(Current)) {
		tb2 = *(EIF_BOOLEAN *)(RTCV(F450_5996(Current))+ _CHROFF_0_0_);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1347, 0x01).id, 1347, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTOUCR(98,F1448_15093, (RTCV(F450_5996(Current))));
		tr2 = F1194_11030(RTCW(tr2));
		F1348_12515(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1347, 0x01).id, 1347, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H(".",1,46);
		F1348_12515(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1405_13626 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(623,F1405_13626_body,(Current));
}

/* {SHARED_LOCALE}.locale_internal */
static EIF_REFERENCE F1405_13631_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(622)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,206,0xFF01,27,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 206, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	tr2 = RTOUCR(624,F1405_13633, (Current));
	F207_3115(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1405_13631 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(622,F1405_13631_body,(Current));
}

/* {SHARED_LOCALE}.empty_locale */
static EIF_REFERENCE F1405_13633_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(624)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTOUCR(623,F1405_13626, (Current));
	tr2 = RTLNS(eif_new_type(1348, 0x01).id, 1348, _OBJSIZ_6_0_0_0_0_0_0_0_);
	tr3 = RTMS_EX_H("",0,0);
	F1349_12526(RTCW(tr2), tr3);
	Result = F1348_12516(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1405_13633 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(624,F1405_13633_body,(Current));
}

void EIF_Minit718 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
