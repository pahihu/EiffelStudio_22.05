/*
 * Code for class CONF_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co720.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION}.make */
void F1407_14201 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,0xFF01,0xFFF9,2,1113,1353,1353,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F961_8558(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,970,0xFF01,970,0xFF01,51,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F971_8682(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_CONDITION}.make_with_target */
void F1407_14202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1407_14201(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {CONF_CONDITION}.set_target */
void F1407_14215 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
}

/* {CONF_CONDITION}.add_platform */
void F1407_14216 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.exclude_platform */
void F1407_14217 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.add_build */
void F1407_14219 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.exclude_build */
void F1407_14220 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.add_concurrency */
void F1407_14222 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.exclude_concurrency */
void F1407_14223 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.add_void_safety */
void F1407_14225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.exclude_void_safety */
void F1407_14226 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,0xFF01,1061,1312,1127,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1061,1312,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 1061, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1062_8908(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		F1114_9633(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	tr1 = eif_boxed_item(loc1,1);
	F1062_8948(RTCW(tr1), arg1);
	RTLE;
}

/* {CONF_CONDITION}.set_dotnet */
void F1407_14228 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {208,1127,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F209_3115(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_CONDITION}.set_dynamic_runtime */
void F1407_14229 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {208,1127,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F209_3115(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_CONDITION}.add_custom */
void F1407_14232 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,arg3);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F961_8564(RTCW(tr1), arg1);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		{
			static EIF_TYPE_INDEX typarr1[] = {0xFF01,970,0xFF01,970,0xFF01,51,0xFFFF};
			EIF_TYPE typres1;
			static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
			
			typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
			loc1 = RTLNSMART(eif_final_id(Y7388,Y7388_gen_type,typres1.id,960).id);
		}
		F961_8558(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F961_8605(RTCW(tr1), loc1, arg1);
	}
	F961_8605(RTCW(loc1), arg3, arg2);
	RTLE;
}

/* {CONF_CONDITION}.add_version */
void F1407_14236 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1113,1353,1353,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
	RTAR(tr1,arg1);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = arg2;
	RTAR(tr1,arg2);
	loc1 = (EIF_REFERENCE) tr1;
	F1114_9633(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F961_8605(RTCW(tr1), loc1, arg3);
	RTLE;
}

/* {CONF_CONDITION}.is_equal */
EIF_BOOLEAN F1407_14237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1407_14238(Current);
	tr2 = F1407_14238(RTCW(arg1));
	Result = F1171_10161(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_CONDITION}.text */
EIF_REFERENCE F1407_14238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTGC;
	Result = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1168_10007(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOUCR(466,F426_5577, (Current));
	F1407_14239(Current, tr1, tr2, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(467,F426_5578, (Current));
	F1407_14239(Current, tr1, tr2, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOUCR(468,F426_5579, (Current));
	F1407_14239(Current, tr1, tr2, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOUCR(469,F426_5580, (Current));
	F1407_14239(Current, tr1, tr2, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F961_8597(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = F961_8592(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F961_8570(RTCW(tr1));
		tr1 = eif_boxed_item(tr1,1);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1354_12617(loc1);
			F1173_10252(RTCW(Result), tr1);
			tr1 = RTMS_EX_H(" <= ",4,540818720);
			F1173_10251(RTCW(Result), tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F961_8571(RTCW(tr1));
		F1173_10251(RTCW(Result), tr1);
		tr1 = RTMS_EX_H(" version",8,1405022062);
		F1173_10251(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F961_8570(RTCW(tr1));
		tr1 = eif_boxed_item(tr1,2);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTMS_EX_H(" <= ",4,540818720);
			F1173_10251(RTCW(Result), tr1);
			tr1 = F1354_12617(loc2);
			F1173_10252(RTCW(Result), tr1);
		}
		tr1 = RTMS_EX_H(" and ",5,1634870304);
		F1173_10251(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F961_8598(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb2 = *(EIF_BOOLEAN *)(loc3+ _CHROFF_0_0_);
		if (tb2) {
			tr1 = RTMS_EX_H(".NET and ",9,605383200);
			F1173_10251(RTCW(Result), tr1);
		} else {
			tr1 = RTMS_EX_H("not .NET and ",13,608823840);
			F1173_10251(RTCW(Result), tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = *(EIF_BOOLEAN *)(loc4+ _CHROFF_0_0_);
		if (tb2) {
			tr1 = RTMS_EX_H("dynamic_runtime and ",20,444064800);
			F1173_10251(RTCW(Result), tr1);
		} else {
			tr1 = RTMS_EX_H("not dynamic_runtime and ",24,593065760);
			F1173_10251(RTCW(Result), tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = F961_8573(RTCW(tr1));
	for (;;) {
		tb2 = F650_7876(loc5);
		if (tb2) break;
		tr1 = F650_7873(loc5);
		loc6 = F961_8573(RTCW(tr1));
		for (;;) {
			tb3 = F650_7876(loc6);
			if (tb3) break;
			tr1 = F650_7874(loc5);
			F1173_10251(RTCW(Result), tr1);
			tr1 = F650_7873(loc6);
			tb4 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
			if (tb4) {
				tr1 = F650_7873(loc6);
				tb4 = F52_1076(RTCW(tr1));
				if (tb4) {
					tr1 = RTMS_EX_H(" /<caseless>= ",14,934141216);
					F1173_10251(RTCW(Result), tr1);
				} else {
					tr1 = F650_7873(loc6);
					tb4 = F52_1078(RTCW(tr1));
					if (tb4) {
						tr1 = RTMS_EX_H(" /<wildcard>= ",14,701941024);
						F1173_10251(RTCW(Result), tr1);
					} else {
						tr1 = F650_7873(loc6);
						tb4 = F52_1077(RTCW(tr1));
						if (tb4) {
							tr1 = RTMS_EX_H(" /<regexp>= ",12,1388727584);
							F1173_10251(RTCW(Result), tr1);
						} else {
							tr1 = RTMS_EX_H(" /= ",4,539966752);
							F1173_10251(RTCW(Result), tr1);
						}
					}
				}
			} else {
				tr1 = F650_7873(loc6);
				tb4 = F52_1076(RTCW(tr1));
				if (tb4) {
					tr1 = RTMS_EX_H(" =<caseless>= ",14,1213916192);
					F1173_10251(RTCW(Result), tr1);
				} else {
					tr1 = F650_7873(loc6);
					tb4 = F52_1078(RTCW(tr1));
					if (tb4) {
						tr1 = RTMS_EX_H(" =<wildcard>= ",14,981716000);
						F1173_10251(RTCW(Result), tr1);
					} else {
						tr1 = F650_7873(loc6);
						tb4 = F52_1077(RTCW(tr1));
						if (tb4) {
							tr1 = RTMS_EX_H(" =<regexp>= ",12,1485495584);
							F1173_10251(RTCW(Result), tr1);
						} else {
							tr1 = RTMS_EX_H(" = ",3,2112800);
							F1173_10251(RTCW(Result), tr1);
						}
					}
				}
			}
			tr1 = F650_7874(loc6);
			F1173_10251(RTCW(Result), tr1);
			tr1 = RTMS_EX_H(" and ",5,1634870304);
			F1173_10251(RTCW(Result), tr1);
			F650_7877(loc6);
		}
		F650_7877(loc5);
	}
	tb4 = F878_8129(RTCW(Result));
	if ((EIF_BOOLEAN) !tb4) {
		F1173_10276(RTCW(Result), ((EIF_INTEGER_32) 5L));
	}
	RTLE;
	return Result;
}

/* {CONF_CONDITION}.append_list */
void F1407_14239 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLR(6,loc1);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb1 = '\0';
		loc2 = arg1;
		if ((EIF_TRUE)) {
			tr1 = eif_boxed_item(loc2,1);
			loc3 = tr1;
			tb1 = (EIF_TRUE);
		}
		if (tb1) {
			tb1 = eif_boolean_item(loc2,2);
			if (tb1) {
				tr1 = RTMS_EX_H("not ",4,1852797984);
				F1173_10251(RTCW(arg3), tr1);
				loc1 = RTMS_EX_H(" and ",5,1634870304);
			} else {
				loc1 = RTMS_EX_H(" or ",4,544174624);
			}
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
			F1173_10265(RTCW(arg3), tw1);
			F1062_8939(loc3);
			for (;;) {
				tb1 = F1033_8827(loc3);
				if (tb1) break;
				ti4_1 = F1062_8913(loc3);
				tr1 = F963_8564(RTCW(arg2), ti4_1);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					F1173_10251(RTCW(arg3), loc4);
				} else {
					tr1 = RTMS_EX_H("False",5,1635034981);
					F1173_10251(RTCW(arg3), tr1);
				}
				F1173_10251(RTCW(arg3), loc1);
				F1062_8941(loc3);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O8704[Dtype(loc1)-1173]);
			F1173_10276(RTCW(arg3), ti4_1);
			tr1 = RTMS_EX_H(") and ",6,1715479584);
			F1173_10251(RTCW(arg3), tr1);
		} else {
		}
	}
	RTLE;
}

void EIF_Minit720 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
