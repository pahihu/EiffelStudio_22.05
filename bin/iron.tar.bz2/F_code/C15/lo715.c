/*
 * Code for class LOCALIZED_PRINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lo715.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LOCALIZED_PRINTER}.localized_print */
void F1402_13608 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1173, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tr1 = RTOUCR(2,F1_24, (Current));
			F100_1836(RTCW(tr1), loc1);
		} else {
			tr1 = RTOUCR(2,F1_24, (Current));
			tr2 = F1168_10067(RTCW(arg1));
			F100_1838(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {LOCALIZED_PRINTER}.localized_print_error */
void F1402_13609 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1173, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tr1 = RTOUCR(34,F100_1807, (RTCV(RTOUCR(2,F1_24, (Current)))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6252[Dtype(RTCW(tr1))-563])(tr1, loc1);
		} else {
			tr1 = RTOUCR(34,F100_1807, (RTCV(RTOUCR(2,F1_24, (Current)))));
			tr2 = F1168_10067(RTCW(arg1));
			F937_8443(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

void EIF_Minit715 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
