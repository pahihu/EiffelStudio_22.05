
#ifndef _C17_ar811_
#define _C17_ar811_

#ifdef __cplusplus
extern "C" {
#endif

extern void F671_7899(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F671_7900(EIF_REFERENCE);
extern EIF_REFERENCE F671_7901(EIF_REFERENCE);
extern EIF_REFERENCE F671_7903(EIF_REFERENCE);
extern EIF_INTEGER_32 F671_7904(EIF_REFERENCE);
extern void EIF_Minit811(void);
extern char *(*R7582[])();
extern char *(*R7586[])();
extern char *(*R6979[])();
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
