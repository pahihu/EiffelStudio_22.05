
#ifndef _C17_to820_
#define _C17_to820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F463_6100(EIF_REFERENCE, EIF_INTEGER_32);
extern void F463_6101(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F463_6107(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern char *(*R9315[])();
extern EIF_TYPE_INDEX Y5594[];
extern EIF_TYPE_INDEX *Y5594_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
