
#ifndef _C17_ar840_
#define _C17_ar840_

#ifdef __cplusplus
extern "C" {
#endif

extern void F686_7917(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F686_7918(EIF_REFERENCE);
extern EIF_REFERENCE F686_7919(EIF_REFERENCE);
extern EIF_REFERENCE F686_7921(EIF_REFERENCE);
extern EIF_INTEGER_32 F686_7922(EIF_REFERENCE);
extern void EIF_Minit840(void);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
