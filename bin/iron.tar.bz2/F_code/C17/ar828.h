
#ifndef _C17_ar828_
#define _C17_ar828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F672_7899(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F672_7900(EIF_REFERENCE);
extern EIF_REFERENCE F672_7901(EIF_REFERENCE);
extern EIF_REFERENCE F672_7903(EIF_REFERENCE);
extern EIF_INTEGER_32 F672_7904(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern EIF_INTEGER_32 F1060_8931(EIF_REFERENCE);
extern EIF_REFERENCE F1060_8912(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
