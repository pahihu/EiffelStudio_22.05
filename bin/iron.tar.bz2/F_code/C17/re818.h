
#ifndef _C17_re818_
#define _C17_re818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F894_8135(EIF_REFERENCE);
extern void F894_8137(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R7147[])();
extern char *(*R7141[])();
extern char *(*R7145[])();

#ifdef __cplusplus
}
#endif

#endif
