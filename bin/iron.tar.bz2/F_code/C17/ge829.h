
#ifndef _C17_ge829_
#define _C17_ge829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F660_7879(EIF_REFERENCE);
extern EIF_INTEGER_32 F660_7881(EIF_REFERENCE);
extern EIF_BOOLEAN F660_7888(EIF_REFERENCE);
extern EIF_BOOLEAN F660_7891(EIF_REFERENCE);
extern EIF_BOOLEAN F660_7892(EIF_REFERENCE);
extern void F660_7893(EIF_REFERENCE);
extern void F660_7894(EIF_REFERENCE);
extern EIF_REFERENCE F660_7895(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern char *(*R6977[])();
extern char *(*R6950[])();
extern long O6976[];
extern long O6978[];

#ifdef __cplusplus
}
#endif

#endif
