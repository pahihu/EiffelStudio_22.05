
#ifndef _C17_re834_
#define _C17_re834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F950_8553(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern void F637_7845(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6961[])();
extern EIF_TYPE_INDEX Y6831[];
extern EIF_TYPE_INDEX *Y6831_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
