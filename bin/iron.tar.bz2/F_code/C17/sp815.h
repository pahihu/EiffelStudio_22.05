
#ifndef _C17_sp815_
#define _C17_sp815_

#ifdef __cplusplus
extern "C" {
#endif

extern void F697_7923(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F697_7924(EIF_REFERENCE);
extern EIF_REFERENCE F697_7925(EIF_REFERENCE);
extern EIF_INTEGER_32 F697_7926(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R6990[])();
extern char *(*R7376[])();
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
