
#ifndef _C17_fi847_
#define _C17_fi847_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F871_8129(EIF_REFERENCE);
extern void EIF_Minit847(void);
extern char *(*R7140[])();

#ifdef __cplusplus
}
#endif

#endif
