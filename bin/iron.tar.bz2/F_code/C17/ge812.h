
#ifndef _C17_ge812_
#define _C17_ge812_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F659_7879(EIF_REFERENCE);
extern EIF_INTEGER_32 F659_7881(EIF_REFERENCE);
extern EIF_BOOLEAN F659_7888(EIF_REFERENCE);
extern EIF_BOOLEAN F659_7891(EIF_REFERENCE);
extern EIF_BOOLEAN F659_7892(EIF_REFERENCE);
extern void F659_7893(EIF_REFERENCE);
extern void F659_7894(EIF_REFERENCE);
extern EIF_REFERENCE F659_7895(EIF_REFERENCE);
extern void EIF_Minit812(void);
extern char *(*R6977[])();
extern char *(*R7374[])();
extern char *(*R6950[])();
extern long O6976[];
extern long O6978[];

#ifdef __cplusplus
}
#endif

#endif
