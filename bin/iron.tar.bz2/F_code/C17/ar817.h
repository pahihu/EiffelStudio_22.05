
#ifndef _C17_ar817_
#define _C17_ar817_

#ifdef __cplusplus
extern "C" {
#endif

extern void F685_7917(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F685_7918(EIF_REFERENCE);
extern EIF_REFERENCE F685_7919(EIF_REFERENCE);
extern EIF_REFERENCE F685_7921(EIF_REFERENCE);
extern EIF_INTEGER_32 F685_7922(EIF_REFERENCE);
extern void EIF_Minit817(void);
extern char *(*R6987[])();
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
