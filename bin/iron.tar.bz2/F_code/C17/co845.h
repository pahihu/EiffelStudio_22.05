
#ifndef _C17_co845_
#define _C17_co845_

#ifdef __cplusplus
extern "C" {
#endif

extern void F763_8013(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit845(void);
extern EIF_BOOLEAN F1007_8803(EIF_REFERENCE);
extern void F1060_8939(EIF_REFERENCE);
extern EIF_POINTER F1060_8913(EIF_REFERENCE);
extern void F1060_8941(EIF_REFERENCE);
extern char *(*R7040[])();
extern char *(*R7060[])();
extern char *(*R7064[])();

#ifdef __cplusplus
}
#endif

#endif
