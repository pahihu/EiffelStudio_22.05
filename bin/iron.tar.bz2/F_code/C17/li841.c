/*
 * Code for class LINEAR [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li841.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F739_7988 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1060_8939(Current);
	if ((EIF_BOOLEAN) !F1007_8803(Current)) {
		F1060_8945(Current, arg1);
	}
	Result = F739_7994(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F739_7990 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O7036[Dtype(Current)-713])) {
		for (;;) {
			tb1 = '\01';
			if (!F739_7994(Current)) {
				tb1 = (arg1 == F1060_8913(Current));
			}
			if (tb1) break;
			F1060_8941(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F739_7994(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F1060_8913(Current));
			}
			if (tb2) break;
			F1060_8941(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F739_7994 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1007_8803(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F739_7996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F871_8129(Current)) {
		Result = F1031_8827(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F739_8003 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit841 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
