
#ifndef _C17_ty835_
#define _C17_ty835_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F625_7839(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern char *(*R6962[])();
extern char *(*R6949[])();
extern char *(*R7374[])();

#ifdef __cplusplus
}
#endif

#endif
