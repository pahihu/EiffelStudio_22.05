
#ifndef _C17_dy822_
#define _C17_dy822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1018_8812(EIF_REFERENCE);
extern void F1018_8818(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern char *(*R7082[])();
extern char *(*R7050[])();
extern char *(*R7054[])();

#ifdef __cplusplus
}
#endif

#endif
