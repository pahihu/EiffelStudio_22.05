/*
 * Code for class READABLE_INDEXABLE [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re834.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {READABLE_INDEXABLE}.new_cursor */
EIF_REFERENCE F950_8553 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	{
		EIF_TYPE_INDEX typarr0[] = {0xFF01,636,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y6831,Y6831_gen_type,Dftype(Current),596);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 636, _OBJSIZ_1_1_0_5_0_0_0_0_);
	}
	F637_7845(RTCW(Result), Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6961[Dtype(RTCW(Result))-635])(Result);
	RTLE;
	return Result;
}

void EIF_Minit834 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
