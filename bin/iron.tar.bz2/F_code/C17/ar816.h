
#ifndef _C17_ar816_
#define _C17_ar816_

#ifdef __cplusplus
extern "C" {
#endif

extern void F989_8728(EIF_REFERENCE);
extern void F989_8729(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F989_8730(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F989_8732(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F989_8734(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F989_8737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F989_8738(EIF_REFERENCE);
extern EIF_INTEGER_32 F989_8739(EIF_REFERENCE);
extern EIF_INTEGER_32 F989_8740(EIF_REFERENCE);
extern EIF_INTEGER_32 F989_8741(EIF_REFERENCE);
extern EIF_INTEGER_32 F989_8742(EIF_REFERENCE);
extern EIF_BOOLEAN F989_8744(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F989_8749(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F989_8750(EIF_REFERENCE);
extern void F989_8753(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F989_8755(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F989_8758(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F989_8772(EIF_REFERENCE, EIF_INTEGER_32);
extern void F989_8774(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F989_8777(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F989_8781(EIF_REFERENCE);
extern void F989_8782(EIF_REFERENCE, EIF_REFERENCE);
extern void F989_8785(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F989_8786(EIF_REFERENCE);
extern void EIF_Minit816(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R9311[])();
extern char *(*R9312[])();
extern char *(*R7578[])();
extern char *(*R7537[])();
extern char *(*R7070[])();
extern char *(*R9324[])();
extern char *(*R9325[])();
extern char *(*R9327[])();
extern char *(*R9329[])();
extern char *(*R9299[])();
extern char *(*R9332[])();
extern char *(*R9333[])();
extern char *(*R6987[])();
extern char *(*R9342[])();
extern char *(*R9343[])();
extern char *(*R5592[])();
extern char *(*R5593[])();
extern char *(*R7374[])();
extern char *(*R5599[])();
extern char *(*R7064[])();
extern char *(*R7140[])();
extern char *(*R7141[])();
extern char *(*R7530[])();
extern char *(*R7145[])();
extern EIF_TYPE_INDEX Y6831[];
extern EIF_TYPE_INDEX *Y6831_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
