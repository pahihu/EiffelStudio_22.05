
#ifndef _C17_ar810_
#define _C17_ar810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1059_8908(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8910(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8911(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1059_8912(EIF_REFERENCE);
extern EIF_REFERENCE F1059_8913(EIF_REFERENCE);
extern EIF_REFERENCE F1059_8914(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1059_8916(EIF_REFERENCE);
extern EIF_REFERENCE F1059_8917(EIF_REFERENCE);
extern EIF_INTEGER_32 F1059_8918(EIF_REFERENCE);
extern EIF_REFERENCE F1059_8919(EIF_REFERENCE);
extern EIF_BOOLEAN F1059_8920(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1059_8922(EIF_REFERENCE);
extern void F1059_8923(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1059_8926(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1059_8929(EIF_REFERENCE);
extern EIF_INTEGER_32 F1059_8930(EIF_REFERENCE);
extern EIF_INTEGER_32 F1059_8931(EIF_REFERENCE);
extern EIF_BOOLEAN F1059_8932(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1059_8935(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8939(EIF_REFERENCE);
extern void F1059_8940(EIF_REFERENCE);
extern void F1059_8941(EIF_REFERENCE);
extern void F1059_8942(EIF_REFERENCE);
extern void F1059_8943(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8944(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8945(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8947(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8948(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8949(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8950(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8952(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8955(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8956(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8957(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1059_8959(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8961(EIF_REFERENCE, EIF_REFERENCE);
extern void F1059_8962(EIF_REFERENCE);
extern void F1059_8967(EIF_REFERENCE);
extern void F1059_8969(EIF_REFERENCE);
extern void F1059_8972(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit810(void);
extern void F530_6450(EIF_REFERENCE);
extern EIF_REFERENCE F530_6451(EIF_REFERENCE);
extern EIF_REFERENCE F961_8564(EIF_REFERENCE, EIF_REFERENCE);
extern void F1006_8807(EIF_REFERENCE, EIF_REFERENCE);
extern void F350_5037(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F961_8566(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R9311[])();
extern char *(*R9312[])();
extern char *(*R7578[])();
extern char *(*R9332[])();
extern char *(*R7070[])();
extern char *(*R7073[])();
extern char *(*R7034[])();
extern char *(*R7586[])();
extern char *(*R9324[])();
extern char *(*R9325[])();
extern char *(*R9327[])();
extern char *(*R7082[])();
extern char *(*R7041[])();
extern char *(*R7590[])();
extern char *(*R7077[])();
extern char *(*R6979[])();
extern char *(*R9333[])();
extern char *(*R9339[])();
extern char *(*R7055[])();
extern char *(*R7057[])();
extern char *(*R7058[])();
extern char *(*R9347[])();
extern char *(*R9342[])();
extern char *(*R9345[])();
extern char *(*R5820[])();
extern char *(*R5821[])();
extern char *(*R5822[])();
extern char *(*R7374[])();
extern char *(*R6830[])();
extern char *(*R5599[])();
extern char *(*R7064[])();
extern char *(*R7140[])();
extern char *(*R7141[])();
extern char *(*R9350[])();
extern char *(*R7147[])();
extern char *(*R7145[])();
extern long O7036[];
extern long O7592[];
extern EIF_TYPE_INDEX Y5594[];
extern EIF_TYPE_INDEX *Y5594_gen_type [];
extern EIF_TYPE_INDEX Y5600[];
extern EIF_TYPE_INDEX *Y5600_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
