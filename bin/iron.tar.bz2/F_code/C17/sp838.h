
#ifndef _C17_sp838_
#define _C17_sp838_

#ifdef __cplusplus
extern "C" {
#endif

extern void F698_7923(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F698_7924(EIF_REFERENCE);
extern EIF_REFERENCE F698_7925(EIF_REFERENCE);
extern EIF_INTEGER_32 F698_7926(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern EIF_INTEGER_32 F1232_11109(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5823[];
extern EIF_TYPE_INDEX *Y5823_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
