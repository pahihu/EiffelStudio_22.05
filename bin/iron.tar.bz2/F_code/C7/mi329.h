
#ifndef _C7_mi329_
#define _C7_mi329_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F378_5153(EIF_REFERENCE);
extern void EIF_Minit329(void);

#ifdef __cplusplus
}
#endif

#endif
