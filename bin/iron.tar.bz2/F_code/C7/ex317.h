
#ifndef _C7_ex317_
#define _C7_ex317_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F366_5133(EIF_REFERENCE);
extern void EIF_Minit317(void);

#ifdef __cplusplus
}
#endif

#endif
