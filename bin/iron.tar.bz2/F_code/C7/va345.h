
#ifndef _C7_va345_
#define _C7_va345_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F394_5186(EIF_REFERENCE);
extern void EIF_Minit345(void);

#ifdef __cplusplus
}
#endif

#endif
