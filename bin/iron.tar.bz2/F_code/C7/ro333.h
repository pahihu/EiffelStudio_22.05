
#ifndef _C7_ro333_
#define _C7_ro333_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F382_5165(EIF_REFERENCE);
extern void F382_5167(EIF_REFERENCE, EIF_REFERENCE);
extern void F382_5168(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit333(void);

#ifdef __cplusplus
}
#endif

#endif
