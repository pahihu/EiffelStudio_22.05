
#ifndef _C7_co341_
#define _C7_co341_

#ifdef __cplusplus
extern "C" {
#endif

extern void F390_5182(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit341(void);
extern void F357_5088(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
