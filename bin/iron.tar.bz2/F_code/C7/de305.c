/*
 * Code for class DEFAULT_HTTP_CLIENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "de305.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DEFAULT_HTTP_CLIENT}.new_session */
EIF_REFERENCE F354_5045 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(351, 0x01).id, 351, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F352_5043(RTCW(loc1), arg1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10910[Dtype(RTCW(Result))-1383])(Result);
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = RTLNS(eif_new_type(352, 0x01).id, 352, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F353_5044(RTCW(loc2), arg1);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit305 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
