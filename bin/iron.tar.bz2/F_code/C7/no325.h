
#ifndef _C7_no325_
#define _C7_no325_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F374_5145(EIF_REFERENCE);
extern void F374_5147(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit325(void);

#ifdef __cplusplus
}
#endif

#endif
