
#ifndef _C7_vo335_
#define _C7_vo335_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F384_5171(EIF_REFERENCE);
extern void EIF_Minit335(void);

#ifdef __cplusplus
}
#endif

#endif
