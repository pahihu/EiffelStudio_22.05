
#ifndef _C7_ar301_
#define _C7_ar301_

#ifdef __cplusplus
extern "C" {
#endif

extern void F350_5037(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit301(void);

#ifdef __cplusplus
}
#endif

#endif
