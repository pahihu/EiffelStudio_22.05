
#ifndef _C7_ad337_
#define _C7_ad337_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F386_5173(EIF_REFERENCE);
extern void EIF_Minit337(void);

#ifdef __cplusplus
}
#endif

#endif
