
#ifndef _C7_pr349_
#define _C7_pr349_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F398_5196(EIF_REFERENCE);
extern void EIF_Minit349(void);

#ifdef __cplusplus
}
#endif

#endif
