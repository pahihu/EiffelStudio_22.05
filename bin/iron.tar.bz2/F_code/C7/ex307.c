/*
 * Code for class EXCEPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex307.h"
#include "eif_except.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXCEPTIONS}.assertion_violation */
EIF_BOOLEAN F356_5048 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = F205_3054(RTCV(RTOUCR(24,F355_5046, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F357_5081(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(391, 0x01),loc2);
		Result = EIF_TEST(loc2);
	}
	RTLE;
	return Result;
}

/* {EXCEPTIONS}.is_signal */
EIF_BOOLEAN F356_5052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = F205_3054(RTCV(RTOUCR(24,F355_5046, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F357_5081(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(361, 0x01),loc2);
		Result = EIF_TEST(loc2);
	}
	RTLE;
	return Result;
}

/* {EXCEPTIONS}.raise */
void F356_5065 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(387, 0x01).id, 387, _OBJSIZ_5_1_0_1_0_0_0_0_);
	F357_5088(RTCW(loc1), arg1);
	F357_5073(RTCW(loc1));
	RTLE;
}

/* {EXCEPTIONS}.raise_retrieval_exception */
void F356_5066 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(24,F355_5046, (Current));
	tr1 = F205_3064(RTCW(tr1), ((EIF_INTEGER_32) 31L));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F357_5088(loc1, arg1);
		F357_5073(loc1);
	}
	RTLE;
}

/* {EXCEPTIONS}.die */
void F356_5067 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	esdie(arg1);
	
	RTEC (EN_POST);
}

void EIF_Minit307 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
