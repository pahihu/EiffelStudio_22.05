
#ifndef _C7_lo344_
#define _C7_lo344_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F393_5184(EIF_REFERENCE);
extern void EIF_Minit344(void);

#ifdef __cplusplus
}
#endif

#endif
