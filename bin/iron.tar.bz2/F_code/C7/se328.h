
#ifndef _C7_se328_
#define _C7_se328_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F377_5151(EIF_REFERENCE);
extern void EIF_Minit328(void);

#ifdef __cplusplus
}
#endif

#endif
