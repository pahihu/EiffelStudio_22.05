
#ifndef _C7_op313_
#define _C7_op313_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F362_5106(EIF_REFERENCE);
extern void F362_5109(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit313(void);

#ifdef __cplusplus
}
#endif

#endif
