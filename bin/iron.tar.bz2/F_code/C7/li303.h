
#ifndef _C7_li303_
#define _C7_li303_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F352_5043(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit303(void);
extern void F1383_13359(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
