
#ifndef _C7_re318_
#define _C7_re318_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F367_5135(EIF_REFERENCE);
extern void EIF_Minit318(void);

#ifdef __cplusplus
}
#endif

#endif
