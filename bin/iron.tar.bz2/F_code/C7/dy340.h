
#ifndef _C7_dy340_
#define _C7_dy340_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_5179(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit340(void);
extern void F357_5088(EIF_REFERENCE, EIF_REFERENCE);
extern void F1174_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1171_10137(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_10251(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
