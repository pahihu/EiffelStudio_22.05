
#ifndef _C7_de305_
#define _C7_de305_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F354_5045(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit305(void);
extern EIF_REFERENCE F352_5043(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F353_5044(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10910[])();

#ifdef __cplusplus
}
#endif

#endif
