
#ifndef _C7_re319_
#define _C7_re319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F368_5137(EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
