
#ifndef _C7_io330_
#define _C7_io330_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F379_5155(EIF_REFERENCE);
extern void F379_5158(EIF_REFERENCE, EIF_INTEGER_32);
extern void F379_5159(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit330(void);

#ifdef __cplusplus
}
#endif

#endif
