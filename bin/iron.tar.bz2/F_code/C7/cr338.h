
#ifndef _C7_cr338_
#define _C7_cr338_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F387_5175(EIF_REFERENCE);
extern void EIF_Minit338(void);

#ifdef __cplusplus
}
#endif

#endif
