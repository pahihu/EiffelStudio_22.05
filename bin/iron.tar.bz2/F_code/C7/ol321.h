
#ifndef _C7_ol321_
#define _C7_ol321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F370_5139(EIF_REFERENCE);
extern void EIF_Minit321(void);

#ifdef __cplusplus
}
#endif

#endif
