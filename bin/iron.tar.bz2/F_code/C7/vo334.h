
#ifndef _C7_vo334_
#define _C7_vo334_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F383_5169(EIF_REFERENCE);
extern void EIF_Minit334(void);

#ifdef __cplusplus
}
#endif

#endif
