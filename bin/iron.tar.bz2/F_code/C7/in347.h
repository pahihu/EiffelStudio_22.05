
#ifndef _C7_in347_
#define _C7_in347_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F396_5190(EIF_REFERENCE);
extern void F396_5191(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit347(void);

#ifdef __cplusplus
}
#endif

#endif
