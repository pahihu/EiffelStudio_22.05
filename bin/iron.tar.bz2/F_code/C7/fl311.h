
#ifndef _C7_fl311_
#define _C7_fl311_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F360_5104(EIF_REFERENCE);
extern void EIF_Minit311(void);

#ifdef __cplusplus
}
#endif

#endif
