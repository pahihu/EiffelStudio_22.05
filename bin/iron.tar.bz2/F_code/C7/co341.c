/*
 * Code for class CONVERSION_FAILURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co341.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONVERSION_FAILURE}.make_message */
void F390_5182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F357_5088(Current, arg1);
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
