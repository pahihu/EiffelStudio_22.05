
#ifndef _C7_ex326_
#define _C7_ex326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F375_5149(EIF_REFERENCE);
extern void EIF_Minit326(void);

#ifdef __cplusplus
}
#endif

#endif
