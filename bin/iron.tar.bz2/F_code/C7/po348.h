
#ifndef _C7_po348_
#define _C7_po348_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F397_5194(EIF_REFERENCE);
extern void EIF_Minit348(void);

#ifdef __cplusplus
}
#endif

#endif
