
#ifndef _C7_ba332_
#define _C7_ba332_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F381_5161(EIF_REFERENCE);
extern void EIF_Minit332(void);

#ifdef __cplusplus
}
#endif

#endif
