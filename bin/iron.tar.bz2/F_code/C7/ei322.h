
#ifndef _C7_ei322_
#define _C7_ei322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F371_5141(EIF_REFERENCE);
extern void F371_5143(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit322(void);

#ifdef __cplusplus
}
#endif

#endif
