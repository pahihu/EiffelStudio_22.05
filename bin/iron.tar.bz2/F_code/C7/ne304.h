
#ifndef _C7_ne304_
#define _C7_ne304_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F353_5044(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit304(void);
extern void F1383_13359(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
