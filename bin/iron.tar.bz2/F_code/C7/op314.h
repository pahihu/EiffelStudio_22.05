
#ifndef _C7_op314_
#define _C7_op314_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F363_5110(EIF_REFERENCE);
extern void F363_5113(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit314(void);

#ifdef __cplusplus
}
#endif

#endif
