
#ifndef _C7_ex306_
#define _C7_ex306_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F355_5046_body(EIF_REFERENCE);
extern EIF_REFERENCE F355_5046(EIF_REFERENCE);
extern void EIF_Minit306(void);

#ifdef __cplusplus
}
#endif

#endif
