/*
 * Code for class DYNAMIC_API_UNAVAILABLE_EXCEPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_API_UNAVAILABLE_EXCEPTION}.make */
void F389_5179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1174, 1).id);
	F1174_10306(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1171_10137(RTCW(loc1), ((EIF_INTEGER_32) 40L));
	tr1 = RTMS_EX_H("The API function or variable `",30,323802464);
	F1173_10251(RTCW(loc1), tr1);
	F1173_10251(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = RTMS_EX_H("\' is not available.",19,60956462);
	F1173_10251(RTCW(loc1), tr1);
	F357_5088(Current, loc1);
	RTLE;
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
