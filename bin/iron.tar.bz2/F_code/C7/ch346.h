
#ifndef _C7_ch346_
#define _C7_ch346_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F395_5188(EIF_REFERENCE);
extern void EIF_Minit346(void);

#ifdef __cplusplus
}
#endif

#endif
