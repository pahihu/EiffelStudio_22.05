
#ifndef _C7_ar305_
#define _C7_ar305_

#ifdef __cplusplus
extern "C" {
#endif

extern void F307_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F307_2188(EIF_REFERENCE);
extern EIF_REFERENCE F307_2191(EIF_REFERENCE);
extern void EIF_Minit305(void);
extern EIF_REFERENCE F661_3018(EIF_REFERENCE);
extern EIF_INTEGER_32 F661_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
