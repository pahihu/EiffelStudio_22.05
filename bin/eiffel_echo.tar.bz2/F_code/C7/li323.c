/*
 * Code for class LINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li323.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.item_for_iteration */
EIF_CHARACTER_32 F370_2236 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_32) F662_3019(Current);
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F370_2237 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F609_2889(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F370_2239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F495_2350(Current)) {
		Result = F633_2913(Current);
	}
	RTLE;
	return Result;
}

void EIF_Minit323 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
