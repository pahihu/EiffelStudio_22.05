
#ifndef _C7_fi321_
#define _C7_fi321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F495_2350(EIF_REFERENCE);
extern void EIF_Minit321(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
