
#ifndef _C7_re318_
#define _C7_re318_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F521_2363(EIF_REFERENCE);
extern void EIF_Minit318(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
