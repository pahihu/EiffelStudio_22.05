
#ifndef _C7_co326_
#define _C7_co326_

#ifdef __cplusplus
extern "C" {
#endif

extern void F346_2220(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
