
#ifndef _C7_li347_
#define _C7_li347_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F633_2913(EIF_REFERENCE);
extern void EIF_Minit347(void);
extern EIF_INTEGER_32 F662_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
