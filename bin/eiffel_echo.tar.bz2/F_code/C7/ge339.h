
#ifndef _C7_ge339_
#define _C7_ge339_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F296_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F296_2180(EIF_REFERENCE);
extern void F296_2182(EIF_REFERENCE);
extern void EIF_Minit339(void);

#ifdef __cplusplus
}
#endif

#endif
