
#ifndef _C7_ar344_
#define _C7_ar344_

#ifdef __cplusplus
extern "C" {
#endif

extern void F322_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2206(EIF_REFERENCE);
extern EIF_REFERENCE F322_2209(EIF_REFERENCE);
extern void EIF_Minit344(void);

#ifdef __cplusplus
}
#endif

#endif
