
#ifndef _C7_ce312_
#define _C7_ce312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F53_802(EIF_REFERENCE);
extern void F53_803(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit312(void);
extern long O780[];

#ifdef __cplusplus
}
#endif

#endif
