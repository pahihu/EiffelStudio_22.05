
#ifndef _C7_re328_
#define _C7_re328_

#ifdef __cplusplus
extern "C" {
#endif

extern void F276_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F276_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F276_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F276_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F276_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F276_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F276_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F276_2149(EIF_REFERENCE);
extern void F276_2152(EIF_REFERENCE);
extern void EIF_Minit328(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
