
#ifndef _C7_li323_
#define _C7_li323_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F370_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F370_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F370_2239(EIF_REFERENCE);
extern void EIF_Minit323(void);
extern EIF_BOOLEAN F633_2913(EIF_REFERENCE);
extern EIF_CHARACTER_32 F662_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F609_2889(EIF_REFERENCE);
extern EIF_BOOLEAN F495_2350(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
