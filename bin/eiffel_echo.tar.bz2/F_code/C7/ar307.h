
#ifndef _C7_ar307_
#define _C7_ar307_

#ifdef __cplusplus
extern "C" {
#endif

extern void F321_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2206(EIF_REFERENCE);
extern EIF_REFERENCE F321_2209(EIF_REFERENCE);
extern void EIF_Minit307(void);

#ifdef __cplusplus
}
#endif

#endif
