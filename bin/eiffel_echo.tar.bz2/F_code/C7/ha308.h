
#ifndef _C7_ha308_
#define _C7_ha308_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F289_2161(EIF_REFERENCE);
extern EIF_INTEGER_32 F289_2162(EIF_REFERENCE);
extern EIF_BOOLEAN F289_2164(EIF_REFERENCE);
extern void F289_2165(EIF_REFERENCE);
extern EIF_REFERENCE F289_2166(EIF_REFERENCE);
extern void EIF_Minit308(void);
extern char *(*R2280[])();
extern char *(*R2479[])();
extern char *(*R1949[])();
extern char *(*R2478[])();
extern long O2487[];
extern long O2488[];

#ifdef __cplusplus
}
#endif

#endif
