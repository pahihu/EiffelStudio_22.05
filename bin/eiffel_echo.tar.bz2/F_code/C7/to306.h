
#ifndef _C7_to306_
#define _C7_to306_

#ifdef __cplusplus
extern "C" {
#endif

extern void F142_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F142_1716(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F142_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit306(void);
extern void F571_2728(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
