
#ifndef _C7_to345_
#define _C7_to345_

#ifdef __cplusplus
extern "C" {
#endif

extern void F143_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F143_1716(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F143_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit345(void);
extern void F572_2728(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
