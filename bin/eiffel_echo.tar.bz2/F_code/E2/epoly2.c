#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O780[6];
void O780_init () {
	O780[0] = 0;
	O780[1] = + _LNGOFF_0_0_0_0_;
	O780[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O780[3] = + _LNGOFF_0_0_0_0_;
	O780[4] = 0;
	O780[5] = + _LNGOFF_1_0_0_0_;
}

long O937[4];
void O937_init () {
	O937[0] = + _CHROFF_2_0_;
	O937[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O937[i] = + _CHROFF_2_0_;}
}

long O938[4];
void O938_init () {
	O938[0] = + _CHROFF_2_1_;
	O938[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O938[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y1584_pgtype0[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype1[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype2[] = {0xFF01,571,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype3[] = {0xFF01,572,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype4[] = {0xFF01,573,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype5[] = {0xFF01,574,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype6[] = {0xFF01,575,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype7[] = {0xFF01,576,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype8[] = {0xFF01,577,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype9[] = {0xFF01,578,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype10[] = {0xFF01,579,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype11[] = {0xFF01,580,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype12[] = {0xFF01,576,744,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype13[] = {0xFF01,576,744,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype14[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype15[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype16[] = {0xFF01,571,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype17[] = {0xFF01,572,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype18[] = {0xFF01,573,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype19[] = {0xFF01,574,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype20[] = {0xFF01,575,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype21[] = {0xFF01,576,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype22[] = {0xFF01,577,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype23[] = {0xFF01,578,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype24[] = {0xFF01,579,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype25[] = {0xFF01,580,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype26[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype27[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype28[] = {0xFF01,571,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype29[] = {0xFF01,572,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype30[] = {0xFF01,573,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype31[] = {0xFF01,574,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype32[] = {0xFF01,575,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype33[] = {0xFF01,576,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype34[] = {0xFF01,577,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype35[] = {0xFF01,578,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype36[] = {0xFF01,579,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype37[] = {0xFF01,580,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype38[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype39[] = {0xFF01,571,753,0xFFFF};
static EIF_TYPE_INDEX Y1584_pgtype40[] = {0xFF01,579,756,0xFFFF};
EIF_TYPE_INDEX *Y1584_gen_type [664];
EIF_TYPE_INDEX Y1584 [664];
void Y1584_init (void)
{
	egc_routines_types [1584] = Y1584;
	egc_routines_gen_types [1584] = Y1584_gen_type;
	egc_routines_offset [1584] = 140;
	Y1584_gen_type [0] = Y1584_pgtype0;
	Y1584_gen_type [1] = Y1584_pgtype1;
	Y1584_gen_type [2] = Y1584_pgtype2;
	Y1584_gen_type [3] = Y1584_pgtype3;
	Y1584_gen_type [4] = Y1584_pgtype4;
	Y1584_gen_type [5] = Y1584_pgtype5;
	Y1584_gen_type [6] = Y1584_pgtype6;
	Y1584_gen_type [7] = Y1584_pgtype7;
	Y1584_gen_type [8] = Y1584_pgtype8;
	Y1584_gen_type [9] = Y1584_pgtype9;
	Y1584_gen_type [10] = Y1584_pgtype10;
	Y1584_gen_type [11] = Y1584_pgtype11;
	Y1584_gen_type [16] = Y1584_pgtype12;
	Y1584_gen_type [17] = Y1584_pgtype13;
	Y1584_gen_type [454] = Y1584_pgtype14;
	Y1584_gen_type [455] = Y1584_pgtype15;
	Y1584_gen_type [456] = Y1584_pgtype16;
	Y1584_gen_type [457] = Y1584_pgtype17;
	Y1584_gen_type [458] = Y1584_pgtype18;
	Y1584_gen_type [459] = Y1584_pgtype19;
	Y1584_gen_type [460] = Y1584_pgtype20;
	Y1584_gen_type [461] = Y1584_pgtype21;
	Y1584_gen_type [462] = Y1584_pgtype22;
	Y1584_gen_type [463] = Y1584_pgtype23;
	Y1584_gen_type [464] = Y1584_pgtype24;
	Y1584_gen_type [465] = Y1584_pgtype25;
	Y1584_gen_type [519] = Y1584_pgtype26;
	Y1584_gen_type [520] = Y1584_pgtype27;
	Y1584_gen_type [521] = Y1584_pgtype28;
	Y1584_gen_type [522] = Y1584_pgtype29;
	Y1584_gen_type [523] = Y1584_pgtype30;
	Y1584_gen_type [524] = Y1584_pgtype31;
	Y1584_gen_type [525] = Y1584_pgtype32;
	Y1584_gen_type [526] = Y1584_pgtype33;
	Y1584_gen_type [527] = Y1584_pgtype34;
	Y1584_gen_type [528] = Y1584_pgtype35;
	Y1584_gen_type [529] = Y1584_pgtype36;
	Y1584_gen_type [530] = Y1584_pgtype37;
	Y1584_gen_type [531] = Y1584_pgtype38;
	Y1584_gen_type [660] = Y1584_pgtype39;
	Y1584_gen_type [663] = Y1584_pgtype40;
	Y1584[0] = 569;
	Y1584[1] = 570;
	Y1584[2] = 571;
	Y1584[3] = 572;
	Y1584[4] = 573;
	Y1584[5] = 574;
	Y1584[6] = 575;
	Y1584[7] = 576;
	Y1584[8] = 577;
	Y1584[9] = 578;
	Y1584[10] = 579;
	Y1584[11] = 580;
	{long i; for (i = 16; i < 18; i++) Y1584[i] = 576;};
	Y1584[454] = 569;
	Y1584[455] = 570;
	Y1584[456] = 571;
	Y1584[457] = 572;
	Y1584[458] = 573;
	Y1584[459] = 574;
	Y1584[460] = 575;
	Y1584[461] = 576;
	Y1584[462] = 577;
	Y1584[463] = 578;
	Y1584[464] = 579;
	Y1584[465] = 580;
	Y1584[519] = 569;
	Y1584[520] = 570;
	Y1584[521] = 571;
	Y1584[522] = 572;
	Y1584[523] = 573;
	Y1584[524] = 574;
	Y1584[525] = 575;
	Y1584[526] = 576;
	Y1584[527] = 577;
	Y1584[528] = 578;
	Y1584[529] = 579;
	Y1584[530] = 580;
	Y1584[531] = 569;
	Y1584[660] = 571;
	Y1584[663] = 579;
}

long O1985[463];
void O1985_init () {
	{long i; for (i = 0; i < 211; i++) O1985[i] = + _CHROFF_0_0_;}
	O1985[211] = + _CHROFF_3_2_;
	O1985[212] = + _CHROFF_4_2_;
	O1985[213] = + _CHROFF_5_2_;
	{long i; for (i = 238; i < 251; i++) O1985[i] = + _CHROFF_0_0_;}
	{long i; for (i = 251; i < 263; i++) O1985[i] = + _CHROFF_1_0_;}
	{long i; for (i = 263; i < 311; i++) O1985[i] = + _CHROFF_0_0_;}
	{long i; for (i = 311; i < 314; i++) O1985[i] = + _CHROFF_2_0_;}
	{long i; for (i = 315; i < 329; i++) O1985[i] = + _CHROFF_1_0_;}
	O1985[329] = + _CHROFF_7_0_;
	O1985[330] = + _CHROFF_6_0_;
	{long i; for (i = 331; i < 333; i++) O1985[i] = + _CHROFF_5_0_;}
	O1985[333] = + _CHROFF_4_0_;
	O1985[334] = + _CHROFF_5_0_;
	O1985[335] = + _CHROFF_7_0_;
	{long i; for (i = 336; i < 338; i++) O1985[i] = + _CHROFF_5_0_;}
	O1985[338] = + _CHROFF_9_0_;
	O1985[457] = + _CHROFF_1_0_;
	O1985[460] = + _CHROFF_1_0_;
	O1985[462] = + _CHROFF_5_2_;
}

EIF_TYPE_INDEX *Y2428_gen_type [1];
EIF_TYPE_INDEX Y2428 [1];
void Y2428_init (void)
{
	egc_routines_types [2428] = Y2428;
	egc_routines_gen_types [2428] = Y2428_gen_type;
	egc_routines_offset [2428] = 658;
	Y2428[0] = 726;
}

long O2451[10];
void O2451_init () {
	{long i; for (i = 0; i < 2; i++) O2451[i] = 0;}
	O2451[2] = + _LNGOFF_5_3_0_0_;
	O2451[3] = + _PTROFF_5_3_0_7_0_0_;
	O2451[4] = + _LNGOFF_4_3_0_0_;
	O2451[5] = + _CHROFF_5_1_;
	O2451[6] = 0;
	O2451[7] = + _LNGOFF_5_4_0_0_;
	O2451[8] = + _CHROFF_5_1_;
	O2451[9] = 0;
}

long O2460[10];
void O2460_init () {
	O2460[0] = + _LNGOFF_7_3_0_0_;
	O2460[1] = + _LNGOFF_6_3_0_0_;
	O2460[2] = + _LNGOFF_5_3_0_1_;
	O2460[3] = + _LNGOFF_5_3_0_0_;
	O2460[4] = + _LNGOFF_4_3_0_1_;
	O2460[5] = + _LNGOFF_5_5_0_0_;
	O2460[6] = + _LNGOFF_7_4_0_0_;
	O2460[7] = + _LNGOFF_5_4_0_1_;
	O2460[8] = + _LNGOFF_5_6_0_0_;
	O2460[9] = + _LNGOFF_9_3_0_0_;
}

long O2487[10];
void O2487_init () {
	{long i; for (i = 0; i < 2; i++) O2487[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 6; i++) O2487[i] = 0;}
	O2487[6] =  + _REFACS_1_;
	{long i; for (i = 7; i < 9; i++) O2487[i] = 0;}
	O2487[9] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y2487_pgtype0[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype1[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype2[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype3[] = {0xFF01,572,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype4[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype5[] = {0xFF01,577,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype6[] = {0xFF01,569,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype7[] = {0xFF01,570,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype8[] = {0xFF01,577,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2487_pgtype9[] = {0xFF01,569,0,0xFFFF};
EIF_TYPE_INDEX *Y2487_gen_type [10];
EIF_TYPE_INDEX Y2487 [10];
void Y2487_init (void)
{
	egc_routines_types [2487] = Y2487;
	egc_routines_gen_types [2487] = Y2487_gen_type;
	egc_routines_offset [2487] = 672;
	Y2487_gen_type [0] = Y2487_pgtype0;
	Y2487_gen_type [1] = Y2487_pgtype1;
	Y2487_gen_type [2] = Y2487_pgtype2;
	Y2487_gen_type [3] = Y2487_pgtype3;
	Y2487_gen_type [4] = Y2487_pgtype4;
	Y2487_gen_type [5] = Y2487_pgtype5;
	Y2487_gen_type [6] = Y2487_pgtype6;
	Y2487_gen_type [7] = Y2487_pgtype7;
	Y2487_gen_type [8] = Y2487_pgtype8;
	Y2487_gen_type [9] = Y2487_pgtype9;
	{long i; for (i = 0; i < 2; i++) Y2487[i] = 569;};
	Y2487[2] = 570;
	Y2487[3] = 572;
	Y2487[4] = 570;
	Y2487[5] = 577;
	Y2487[6] = 569;
	Y2487[7] = 570;
	Y2487[8] = 577;
	Y2487[9] = 569;
}

long O2488[10];
void O2488_init () {
	{long i; for (i = 0; i < 2; i++) O2488[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 6; i++) O2488[i] =  + _REFACS_1_;}
	O2488[6] =  + _REFACS_2_;
	{long i; for (i = 7; i < 9; i++) O2488[i] =  + _REFACS_1_;}
	O2488[9] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y2488_pgtype0[] = {0xFF01,569,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype1[] = {0xFF01,570,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype2[] = {0xFF01,569,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype3[] = {0xFF01,569,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype4[] = {0xFF01,570,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype5[] = {0xFF01,569,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype6[] = {0xFF01,569,0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype7[] = {0xFF01,569,0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype8[] = {0xFF01,569,0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2488_pgtype9[] = {0xFF01,569,0xFF01,803,0xFFFF};
EIF_TYPE_INDEX *Y2488_gen_type [10];
EIF_TYPE_INDEX Y2488 [10];
void Y2488_init (void)
{
	egc_routines_types [2488] = Y2488;
	egc_routines_gen_types [2488] = Y2488_gen_type;
	egc_routines_offset [2488] = 672;
	Y2488_gen_type [0] = Y2488_pgtype0;
	Y2488_gen_type [1] = Y2488_pgtype1;
	Y2488_gen_type [2] = Y2488_pgtype2;
	Y2488_gen_type [3] = Y2488_pgtype3;
	Y2488_gen_type [4] = Y2488_pgtype4;
	Y2488_gen_type [5] = Y2488_pgtype5;
	Y2488_gen_type [6] = Y2488_pgtype6;
	Y2488_gen_type [7] = Y2488_pgtype7;
	Y2488_gen_type [8] = Y2488_pgtype8;
	Y2488_gen_type [9] = Y2488_pgtype9;
	Y2488[0] = 569;
	Y2488[1] = 570;
	{long i; for (i = 2; i < 4; i++) Y2488[i] = 569;};
	Y2488[4] = 570;
	{long i; for (i = 5; i < 10; i++) Y2488[i] = 569;};
}

long O2489[10];
void O2489_init () {
	{long i; for (i = 0; i < 2; i++) O2489[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 6; i++) O2489[i] =  + _REFACS_2_;}
	O2489[6] =  + _REFACS_3_;
	{long i; for (i = 7; i < 9; i++) O2489[i] =  + _REFACS_2_;}
	O2489[9] =  + _REFACS_3_;
}

long O2490[10];
void O2490_init () {
	{long i; for (i = 0; i < 2; i++) O2490[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 6; i++) O2490[i] =  + _REFACS_3_;}
	O2490[6] =  + _REFACS_4_;
	{long i; for (i = 7; i < 9; i++) O2490[i] =  + _REFACS_3_;}
	O2490[9] =  + _REFACS_4_;
}

long O2491[10];
void O2491_init () {
	O2491[0] = + _LNGOFF_7_3_0_1_;
	O2491[1] = + _LNGOFF_6_3_0_1_;
	O2491[2] = + _LNGOFF_5_3_0_2_;
	O2491[3] = + _LNGOFF_5_3_0_1_;
	O2491[4] = + _LNGOFF_4_3_0_2_;
	O2491[5] = + _LNGOFF_5_5_0_1_;
	O2491[6] = + _LNGOFF_7_4_0_1_;
	O2491[7] = + _LNGOFF_5_4_0_2_;
	O2491[8] = + _LNGOFF_5_6_0_1_;
	O2491[9] = + _LNGOFF_9_3_0_1_;
}

long O2492[10];
void O2492_init () {
	O2492[0] = + _CHROFF_7_2_;
	O2492[1] = + _CHROFF_6_2_;
	{long i; for (i = 2; i < 4; i++) O2492[i] = + _CHROFF_5_2_;}
	O2492[4] = + _CHROFF_4_2_;
	O2492[5] = + _CHROFF_5_3_;
	O2492[6] = + _CHROFF_7_2_;
	O2492[7] = + _CHROFF_5_2_;
	O2492[8] = + _CHROFF_5_3_;
	O2492[9] = + _CHROFF_9_2_;
}

long O2493[10];
void O2493_init () {
	O2493[0] = + _LNGOFF_7_3_0_2_;
	O2493[1] = + _LNGOFF_6_3_0_2_;
	O2493[2] = + _LNGOFF_5_3_0_3_;
	O2493[3] = + _LNGOFF_5_3_0_2_;
	O2493[4] = + _LNGOFF_4_3_0_3_;
	O2493[5] = + _LNGOFF_5_5_0_2_;
	O2493[6] = + _LNGOFF_7_4_0_2_;
	O2493[7] = + _LNGOFF_5_4_0_3_;
	O2493[8] = + _LNGOFF_5_6_0_2_;
	O2493[9] = + _LNGOFF_9_3_0_2_;
}

long O2496[10];
void O2496_init () {
	O2496[0] = + _LNGOFF_7_3_0_3_;
	O2496[1] = + _LNGOFF_6_3_0_3_;
	O2496[2] = + _LNGOFF_5_3_0_4_;
	O2496[3] = + _LNGOFF_5_3_0_3_;
	O2496[4] = + _LNGOFF_4_3_0_4_;
	O2496[5] = + _LNGOFF_5_5_0_3_;
	O2496[6] = + _LNGOFF_7_4_0_3_;
	O2496[7] = + _LNGOFF_5_4_0_4_;
	O2496[8] = + _LNGOFF_5_6_0_3_;
	O2496[9] = + _LNGOFF_9_3_0_3_;
}

long O2497[10];
void O2497_init () {
	O2497[0] = + _LNGOFF_7_3_0_4_;
	O2497[1] = + _LNGOFF_6_3_0_4_;
	O2497[2] = + _LNGOFF_5_3_0_5_;
	O2497[3] = + _LNGOFF_5_3_0_4_;
	O2497[4] = + _LNGOFF_4_3_0_5_;
	O2497[5] = + _LNGOFF_5_5_0_4_;
	O2497[6] = + _LNGOFF_7_4_0_4_;
	O2497[7] = + _LNGOFF_5_4_0_5_;
	O2497[8] = + _LNGOFF_5_6_0_4_;
	O2497[9] = + _LNGOFF_9_3_0_4_;
}

long O2501[10];
void O2501_init () {
	O2501[0] = + _LNGOFF_7_3_0_5_;
	O2501[1] = + _LNGOFF_6_3_0_5_;
	O2501[2] = + _LNGOFF_5_3_0_6_;
	O2501[3] = + _LNGOFF_5_3_0_5_;
	O2501[4] = + _LNGOFF_4_3_0_6_;
	O2501[5] = + _LNGOFF_5_5_0_5_;
	O2501[6] = + _LNGOFF_7_4_0_5_;
	O2501[7] = + _LNGOFF_5_4_0_6_;
	O2501[8] = + _LNGOFF_5_6_0_5_;
	O2501[9] = + _LNGOFF_9_3_0_5_;
}

long O2502[10];
void O2502_init () {
	{long i; for (i = 0; i < 2; i++) O2502[i] =  + _REFACS_5_;}
	O2502[2] = + _LNGOFF_5_3_0_7_;
	O2502[3] = + _PTROFF_5_3_0_7_0_1_;
	O2502[4] = + _LNGOFF_4_3_0_7_;
	O2502[5] = + _CHROFF_5_4_;
	O2502[6] =  + _REFACS_5_;
	O2502[7] = + _LNGOFF_5_4_0_7_;
	O2502[8] = + _CHROFF_5_4_;
	O2502[9] =  + _REFACS_5_;
}

long O2503[10];
void O2503_init () {
	O2503[0] =  + _REFACS_6_;
	O2503[1] = + _LNGOFF_6_3_0_6_;
	{long i; for (i = 2; i < 4; i++) O2503[i] =  + _REFACS_4_;}
	O2503[4] = + _LNGOFF_4_3_0_8_;
	O2503[5] =  + _REFACS_4_;
	O2503[6] =  + _REFACS_6_;
	{long i; for (i = 7; i < 9; i++) O2503[i] =  + _REFACS_4_;}
	O2503[9] =  + _REFACS_6_;
}

long O2537[10];
void O2537_init () {
	O2537[0] = + _LNGOFF_7_3_0_6_;
	O2537[1] = + _LNGOFF_6_3_0_7_;
	O2537[2] = + _LNGOFF_5_3_0_8_;
	O2537[3] = + _LNGOFF_5_3_0_6_;
	O2537[4] = + _LNGOFF_4_3_0_9_;
	O2537[5] = + _LNGOFF_5_5_0_6_;
	O2537[6] = + _LNGOFF_7_4_0_6_;
	O2537[7] = + _LNGOFF_5_4_0_8_;
	O2537[8] = + _LNGOFF_5_6_0_6_;
	O2537[9] = + _LNGOFF_9_3_0_6_;
}

long O2540[3];
void O2540_init () {
	O2540[0] = + _CHROFF_7_3_;
	O2540[1] = + _CHROFF_5_3_;
	O2540[2] = + _CHROFF_5_5_;
}

long O3410[5];
void O3410_init () {
	{long i; for (i = 0; i < 2; i++) O3410[i] = + _LNGOFF_4_2_0_0_;}
	O3410[2] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 3; i < 5; i++) O3410[i] = + _LNGOFF_4_3_0_0_;}
}

long O3418[5];
void O3418_init () {
	{long i; for (i = 0; i < 2; i++) O3418[i] = + _PTROFF_4_2_0_3_0_0_;}
	O3418[2] = + _PTROFF_5_2_0_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O3418[i] = + _PTROFF_4_3_0_3_0_0_;}
}

long O3419[5];
void O3419_init () {
	{long i; for (i = 0; i < 2; i++) O3419[i] = + _PTROFF_4_2_0_3_0_1_;}
	O3419[2] = + _PTROFF_5_2_0_3_0_1_;
	{long i; for (i = 3; i < 5; i++) O3419[i] = + _PTROFF_4_3_0_3_0_1_;}
}

long O3421[5];
void O3421_init () {
	{long i; for (i = 0; i < 2; i++) O3421[i] = + _PTROFF_4_2_0_3_0_2_;}
	O3421[2] = + _PTROFF_5_2_0_3_0_2_;
	{long i; for (i = 3; i < 5; i++) O3421[i] = + _PTROFF_4_3_0_3_0_2_;}
}

long O3422[5];
void O3422_init () {
	{long i; for (i = 0; i < 2; i++) O3422[i] = + _LNGOFF_4_2_0_1_;}
	O3422[2] = + _LNGOFF_5_2_0_1_;
	{long i; for (i = 3; i < 5; i++) O3422[i] = + _LNGOFF_4_3_0_1_;}
}

long O3424[5];
void O3424_init () {
	{long i; for (i = 0; i < 2; i++) O3424[i] = + _LNGOFF_4_2_0_2_;}
	O3424[2] = + _LNGOFF_5_2_0_2_;
	{long i; for (i = 3; i < 5; i++) O3424[i] = + _LNGOFF_4_3_0_2_;}
}

long O3437[3];
void O3437_init () {
	O3437[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O3437[i] = + _CHROFF_4_2_;}
}

long O3536[9];
void O3536_init () {
	{long i; for (i = 0; i < 3; i++) O3536[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O3536[i] = + _LNGOFF_1_0_0_0_;}
	O3536[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O3536[i] = + _LNGOFF_1_0_0_0_;}
	O3536[8] = + _LNGOFF_1_1_0_0_;
}

long O3537[9];
void O3537_init () {
	{long i; for (i = 0; i < 3; i++) O3537[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O3537[i] = + _LNGOFF_1_0_0_1_;}
	O3537[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O3537[i] = + _LNGOFF_1_0_0_1_;}
	O3537[8] = + _LNGOFF_1_1_0_1_;
}

long O3602[3];
void O3602_init () {
	{long i; for (i = 0; i < 2; i++) O3602[i] = + _LNGOFF_1_0_0_2_;}
	O3602[2] = + _LNGOFF_1_1_0_2_;
}

long O3682[3];
void O3682_init () {
	{long i; for (i = 0; i < 2; i++) O3682[i] = + _LNGOFF_1_0_0_2_;}
	O3682[2] = + _LNGOFF_1_1_0_2_;
}


#ifdef __cplusplus
}
#endif
