#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2022[210])();
void R2022_init () {
	R2022[0] = (char *(*)()) F595_2840_2022_9;
	R2022[1] = (char *(*)()) F596_2840_2022_9;
	R2022[2] = (char *(*)()) F597_2840_2022_9;
	R2022[3] = (char *(*)()) F598_2840_2022_9;
	R2022[4] = (char *(*)()) F599_2840_2022_9;
	R2022[5] = (char *(*)()) F600_2840_2022_9;
	R2022[6] = (char *(*)()) F601_2840_2022_9;
	R2022[7] = (char *(*)()) F602_2840_2022_9;
	R2022[8] = (char *(*)()) F603_2840_2022_9;
	R2022[9] = (char *(*)()) F604_2840_2022_9;
	R2022[10] = (char *(*)()) F605_2840_2022_9;
	R2022[11] = (char *(*)()) F606_2840_2022_9;
	R2022[65] = (char *(*)()) F660_3053_2022_9;
	R2022[66] = (char *(*)()) F661_3053_2022_9;
	R2022[67] = (char *(*)()) F662_3053_2022_9;
	R2022[68] = (char *(*)()) F663_3053_2022_9;
	R2022[69] = (char *(*)()) F664_3053_2022_9;
	R2022[70] = (char *(*)()) F665_3053_2022_9;
	R2022[71] = (char *(*)()) F666_3053_2022_9;
	R2022[72] = (char *(*)()) F667_3053_2022_9;
	R2022[73] = (char *(*)()) F668_3053_2022_9;
	R2022[74] = (char *(*)()) F669_3053_2022_9;
	R2022[75] = (char *(*)()) F670_3053_2022_9;
	R2022[76] = (char *(*)()) F671_3053_2022_9;
	R2022[77] = (char *(*)()) F660_3053_2022_9;
	R2022[78] = (char *(*)()) F673_3136;
	R2022[79] = (char *(*)()) F674_3136_2022_9;
	R2022[80] = (char *(*)()) F675_3136_2022_9;
	R2022[81] = (char *(*)()) F676_3136_2022_9;
	R2022[82] = (char *(*)()) F677_3136_2022_9;
	R2022[83] = (char *(*)()) F678_3136_2022_9;
	R2022[84] = (char *(*)()) F673_3136;
	R2022[85] = (char *(*)()) F675_3136_2022_9;
	R2022[86] = (char *(*)()) F678_3136_2022_9;
	R2022[87] = (char *(*)()) F673_3136;
	R2022[209] = (char *(*)()) F804_4973_2022_9;
}
static void F595_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F595_2840(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F596_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F596_2840(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F597_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F597_2840(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F598_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F598_2840(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F599_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F599_2840(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F600_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F600_2840(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F601_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F601_2840(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F602_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F602_2840(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F603_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F603_2840(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F604_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F604_2840(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F605_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F605_2840(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F606_2840_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F606_2840(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_3053(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F661_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F661_3053(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F662_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F662_3053(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F663_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F663_3053(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F664_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_3053(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_3053(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_3053(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_3053(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_3053(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F669_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F669_3053(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F670_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F670_3053(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F671_3053_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F671_3053(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F674_3136_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F674_3136(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F675_3136_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F675_3136(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F676_3136_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F676_3136(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F677_3136_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F677_3136(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F678_3136_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F678_3136(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F804_4973_2022_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F804_4973(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2024_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype32[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype33[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype34[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype35[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype36[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype37[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype38[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype39[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype40[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype41[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype42[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype43[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype44[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype45[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype46[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype47[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype48[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype49[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype50[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype51[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype52[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype53[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype54[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype55[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype56[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype57[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype58[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype59[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype60[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype61[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype62[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype63[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype64[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype65[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype66[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype67[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype68[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype69[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype70[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype71[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype72[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype73[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype74[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype75[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype76[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype77[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype78[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype79[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype80[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype81[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype82[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype83[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype84[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype85[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype86[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype87[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype88[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype89[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype90[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype91[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype92[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype93[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype94[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype95[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype96[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype97[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype98[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype99[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype100[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype101[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype102[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype103[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype104[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype105[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype106[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype107[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype108[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype109[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype110[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype111[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype112[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype113[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype114[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype115[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype116[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype117[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype118[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype119[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype120[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype127[] = {0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype128[] = {0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype129[] = {0xFF01,795,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype130[] = {0xFF01,803,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype131[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y2024_pgtype132[] = {726,0xFFFF};
EIF_TYPE_INDEX *Y2024_gen_type [389];
EIF_TYPE_INDEX Y2024 [389];
void Y2024_init (void)
{
	egc_routines_types [2024] = Y2024;
	egc_routines_gen_types [2024] = Y2024_gen_type;
	egc_routines_offset [2024] = 415;
	Y2024_gen_type [0] = Y2024_pgtype0;
	Y2024_gen_type [1] = Y2024_pgtype1;
	Y2024_gen_type [2] = Y2024_pgtype2;
	Y2024_gen_type [3] = Y2024_pgtype3;
	Y2024_gen_type [4] = Y2024_pgtype4;
	Y2024_gen_type [5] = Y2024_pgtype5;
	Y2024_gen_type [6] = Y2024_pgtype6;
	Y2024_gen_type [7] = Y2024_pgtype7;
	Y2024_gen_type [8] = Y2024_pgtype8;
	Y2024_gen_type [9] = Y2024_pgtype9;
	Y2024_gen_type [10] = Y2024_pgtype10;
	Y2024_gen_type [11] = Y2024_pgtype11;
	Y2024_gen_type [12] = Y2024_pgtype12;
	Y2024_gen_type [13] = Y2024_pgtype13;
	Y2024_gen_type [14] = Y2024_pgtype14;
	Y2024_gen_type [15] = Y2024_pgtype15;
	Y2024_gen_type [16] = Y2024_pgtype16;
	Y2024_gen_type [17] = Y2024_pgtype17;
	Y2024_gen_type [18] = Y2024_pgtype18;
	Y2024_gen_type [19] = Y2024_pgtype19;
	Y2024_gen_type [20] = Y2024_pgtype20;
	Y2024_gen_type [21] = Y2024_pgtype21;
	Y2024_gen_type [22] = Y2024_pgtype22;
	Y2024_gen_type [23] = Y2024_pgtype23;
	Y2024_gen_type [24] = Y2024_pgtype24;
	Y2024_gen_type [25] = Y2024_pgtype25;
	Y2024_gen_type [26] = Y2024_pgtype26;
	Y2024_gen_type [27] = Y2024_pgtype27;
	Y2024_gen_type [28] = Y2024_pgtype28;
	Y2024_gen_type [29] = Y2024_pgtype29;
	Y2024_gen_type [30] = Y2024_pgtype30;
	Y2024_gen_type [31] = Y2024_pgtype31;
	Y2024_gen_type [166] = Y2024_pgtype32;
	Y2024_gen_type [167] = Y2024_pgtype33;
	Y2024_gen_type [168] = Y2024_pgtype34;
	Y2024_gen_type [169] = Y2024_pgtype35;
	Y2024_gen_type [170] = Y2024_pgtype36;
	Y2024_gen_type [171] = Y2024_pgtype37;
	Y2024_gen_type [172] = Y2024_pgtype38;
	Y2024_gen_type [173] = Y2024_pgtype39;
	Y2024_gen_type [174] = Y2024_pgtype40;
	Y2024_gen_type [175] = Y2024_pgtype41;
	Y2024_gen_type [176] = Y2024_pgtype42;
	Y2024_gen_type [177] = Y2024_pgtype43;
	Y2024_gen_type [178] = Y2024_pgtype44;
	Y2024_gen_type [179] = Y2024_pgtype45;
	Y2024_gen_type [180] = Y2024_pgtype46;
	Y2024_gen_type [181] = Y2024_pgtype47;
	Y2024_gen_type [182] = Y2024_pgtype48;
	Y2024_gen_type [183] = Y2024_pgtype49;
	Y2024_gen_type [184] = Y2024_pgtype50;
	Y2024_gen_type [185] = Y2024_pgtype51;
	Y2024_gen_type [186] = Y2024_pgtype52;
	Y2024_gen_type [187] = Y2024_pgtype53;
	Y2024_gen_type [188] = Y2024_pgtype54;
	Y2024_gen_type [189] = Y2024_pgtype55;
	Y2024_gen_type [190] = Y2024_pgtype56;
	Y2024_gen_type [191] = Y2024_pgtype57;
	Y2024_gen_type [192] = Y2024_pgtype58;
	Y2024_gen_type [193] = Y2024_pgtype59;
	Y2024_gen_type [194] = Y2024_pgtype60;
	Y2024_gen_type [195] = Y2024_pgtype61;
	Y2024_gen_type [196] = Y2024_pgtype62;
	Y2024_gen_type [197] = Y2024_pgtype63;
	Y2024_gen_type [198] = Y2024_pgtype64;
	Y2024_gen_type [199] = Y2024_pgtype65;
	Y2024_gen_type [200] = Y2024_pgtype66;
	Y2024_gen_type [201] = Y2024_pgtype67;
	Y2024_gen_type [202] = Y2024_pgtype68;
	Y2024_gen_type [203] = Y2024_pgtype69;
	Y2024_gen_type [204] = Y2024_pgtype70;
	Y2024_gen_type [205] = Y2024_pgtype71;
	Y2024_gen_type [206] = Y2024_pgtype72;
	Y2024_gen_type [207] = Y2024_pgtype73;
	Y2024_gen_type [208] = Y2024_pgtype74;
	Y2024_gen_type [209] = Y2024_pgtype75;
	Y2024_gen_type [210] = Y2024_pgtype76;
	Y2024_gen_type [211] = Y2024_pgtype77;
	Y2024_gen_type [212] = Y2024_pgtype78;
	Y2024_gen_type [213] = Y2024_pgtype79;
	Y2024_gen_type [214] = Y2024_pgtype80;
	Y2024_gen_type [215] = Y2024_pgtype81;
	Y2024_gen_type [216] = Y2024_pgtype82;
	Y2024_gen_type [217] = Y2024_pgtype83;
	Y2024_gen_type [218] = Y2024_pgtype84;
	Y2024_gen_type [219] = Y2024_pgtype85;
	Y2024_gen_type [220] = Y2024_pgtype86;
	Y2024_gen_type [221] = Y2024_pgtype87;
	Y2024_gen_type [222] = Y2024_pgtype88;
	Y2024_gen_type [223] = Y2024_pgtype89;
	Y2024_gen_type [224] = Y2024_pgtype90;
	Y2024_gen_type [225] = Y2024_pgtype91;
	Y2024_gen_type [226] = Y2024_pgtype92;
	Y2024_gen_type [227] = Y2024_pgtype93;
	Y2024_gen_type [228] = Y2024_pgtype94;
	Y2024_gen_type [229] = Y2024_pgtype95;
	Y2024_gen_type [230] = Y2024_pgtype96;
	Y2024_gen_type [231] = Y2024_pgtype97;
	Y2024_gen_type [232] = Y2024_pgtype98;
	Y2024_gen_type [233] = Y2024_pgtype99;
	Y2024_gen_type [234] = Y2024_pgtype100;
	Y2024_gen_type [235] = Y2024_pgtype101;
	Y2024_gen_type [236] = Y2024_pgtype102;
	Y2024_gen_type [237] = Y2024_pgtype103;
	Y2024_gen_type [238] = Y2024_pgtype104;
	Y2024_gen_type [239] = Y2024_pgtype105;
	Y2024_gen_type [240] = Y2024_pgtype106;
	Y2024_gen_type [241] = Y2024_pgtype107;
	Y2024_gen_type [244] = Y2024_pgtype108;
	Y2024_gen_type [245] = Y2024_pgtype109;
	Y2024_gen_type [246] = Y2024_pgtype110;
	Y2024_gen_type [247] = Y2024_pgtype111;
	Y2024_gen_type [248] = Y2024_pgtype112;
	Y2024_gen_type [249] = Y2024_pgtype113;
	Y2024_gen_type [250] = Y2024_pgtype114;
	Y2024_gen_type [251] = Y2024_pgtype115;
	Y2024_gen_type [252] = Y2024_pgtype116;
	Y2024_gen_type [253] = Y2024_pgtype117;
	Y2024_gen_type [254] = Y2024_pgtype118;
	Y2024_gen_type [255] = Y2024_pgtype119;
	Y2024_gen_type [256] = Y2024_pgtype120;
	Y2024_gen_type [257] = Y2024_pgtype121;
	Y2024_gen_type [258] = Y2024_pgtype122;
	Y2024_gen_type [259] = Y2024_pgtype123;
	Y2024_gen_type [260] = Y2024_pgtype124;
	Y2024_gen_type [261] = Y2024_pgtype125;
	Y2024_gen_type [262] = Y2024_pgtype126;
	Y2024_gen_type [263] = Y2024_pgtype127;
	Y2024_gen_type [264] = Y2024_pgtype128;
	Y2024_gen_type [265] = Y2024_pgtype129;
	Y2024_gen_type [266] = Y2024_pgtype130;
	Y2024_gen_type [385] = Y2024_pgtype131;
	Y2024_gen_type [388] = Y2024_pgtype132;
	{long i; for (i = 166; i < 242; i++) Y2024[i] = 726;};
	{long i; for (i = 244; i < 257; i++) Y2024[i] = 726;};
	{long i; for (i = 263; i < 266; i++) Y2024[i] = 795;};
	Y2024[266] = 803;
	Y2024[385] = 726;
	Y2024[388] = 726;
}

char *(*R2026[315])();
void R2026_init () {
	R2026[0] = (char *(*)()) F491_2321_2026_1;
	R2026[168] = (char *(*)()) F660_3019;
	R2026[169] = (char *(*)()) F661_3019_2026_1;
	R2026[170] = (char *(*)()) F662_3019_2026_1;
	R2026[171] = (char *(*)()) F663_3019_2026_1;
	R2026[172] = (char *(*)()) F664_3019_2026_1;
	R2026[173] = (char *(*)()) F665_3019_2026_1;
	R2026[174] = (char *(*)()) F666_3019_2026_1;
	R2026[175] = (char *(*)()) F667_3019_2026_1;
	R2026[176] = (char *(*)()) F668_3019_2026_1;
	R2026[177] = (char *(*)()) F669_3019_2026_1;
	R2026[178] = (char *(*)()) F670_3019_2026_1;
	R2026[179] = (char *(*)()) F671_3019_2026_1;
	R2026[180] = (char *(*)()) F660_3019;
	R2026[314] = (char *(*)()) F555_2388_2026_1;
}
static EIF_REFERENCE F491_2321_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F491_2321(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F661_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F662_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F663_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F664_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F665_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F669_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F670_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3019_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F671_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F555_2388_2026_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F555_2388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2032[13])();
void R2032_init () {
	R2032[0] = (char *(*)()) F660_3025;
	R2032[1] = (char *(*)()) F661_3025;
	R2032[2] = (char *(*)()) F662_3025;
	R2032[3] = (char *(*)()) F663_3025;
	R2032[4] = (char *(*)()) F664_3025;
	R2032[5] = (char *(*)()) F665_3025;
	R2032[6] = (char *(*)()) F666_3025;
	R2032[7] = (char *(*)()) F667_3025;
	R2032[8] = (char *(*)()) F668_3025;
	R2032[9] = (char *(*)()) F669_3025;
	R2032[10] = (char *(*)()) F670_3025;
	R2032[11] = (char *(*)()) F671_3025;
	R2032[12] = (char *(*)()) F660_3025;
}

char *(*R2034[13])();
void R2034_init () {
	R2034[0] = (char *(*)()) F660_3050;
	R2034[1] = (char *(*)()) F661_3050;
	R2034[2] = (char *(*)()) F662_3050;
	R2034[3] = (char *(*)()) F663_3050;
	R2034[4] = (char *(*)()) F664_3050;
	R2034[5] = (char *(*)()) F665_3050;
	R2034[6] = (char *(*)()) F666_3050;
	R2034[7] = (char *(*)()) F667_3050;
	R2034[8] = (char *(*)()) F668_3050;
	R2034[9] = (char *(*)()) F669_3050;
	R2034[10] = (char *(*)()) F670_3050;
	R2034[11] = (char *(*)()) F671_3050;
	R2034[12] = (char *(*)()) F660_3050;
}

char *(*R2070[212])();
void R2070_init () {
	R2070[0] = (char *(*)()) F595_2828;
	R2070[1] = (char *(*)()) F596_2828;
	R2070[2] = (char *(*)()) F597_2828;
	R2070[3] = (char *(*)()) F598_2828;
	R2070[4] = (char *(*)()) F599_2828;
	R2070[5] = (char *(*)()) F600_2828;
	R2070[6] = (char *(*)()) F601_2828;
	R2070[7] = (char *(*)()) F602_2828;
	R2070[8] = (char *(*)()) F603_2828;
	R2070[9] = (char *(*)()) F604_2828;
	R2070[10] = (char *(*)()) F605_2828;
	R2070[11] = (char *(*)()) F606_2828;
	R2070[65] = (char *(*)()) F660_3035;
	R2070[66] = (char *(*)()) F661_3035;
	R2070[67] = (char *(*)()) F662_3035;
	R2070[68] = (char *(*)()) F663_3035;
	R2070[69] = (char *(*)()) F664_3035;
	R2070[70] = (char *(*)()) F665_3035;
	R2070[71] = (char *(*)()) F666_3035;
	R2070[72] = (char *(*)()) F667_3035;
	R2070[73] = (char *(*)()) F668_3035;
	R2070[74] = (char *(*)()) F669_3035;
	R2070[75] = (char *(*)()) F670_3035;
	R2070[76] = (char *(*)()) F671_3035;
	R2070[77] = (char *(*)()) F660_3035;
	R2070[78] = (char *(*)()) F673_3108;
	R2070[79] = (char *(*)()) F674_3108;
	R2070[80] = (char *(*)()) F675_3108;
	R2070[81] = (char *(*)()) F676_3108;
	R2070[82] = (char *(*)()) F677_3108;
	R2070[83] = (char *(*)()) F678_3108;
	R2070[84] = (char *(*)()) F673_3108;
	R2070[85] = (char *(*)()) F675_3108;
	R2070[86] = (char *(*)()) F678_3108;
	R2070[87] = (char *(*)()) F673_3108;
	R2070[206] = (char *(*)()) F799_4727;
	R2070[209] = (char *(*)()) F802_4895;
	R2070[211] = (char *(*)()) F806_5055;
}

char *(*R2073[210])();
void R2073_init () {
	R2073[0] = (char *(*)()) F595_2829;
	R2073[1] = (char *(*)()) F596_2829;
	R2073[2] = (char *(*)()) F597_2829;
	R2073[3] = (char *(*)()) F598_2829;
	R2073[4] = (char *(*)()) F599_2829;
	R2073[5] = (char *(*)()) F600_2829;
	R2073[6] = (char *(*)()) F601_2829;
	R2073[7] = (char *(*)()) F602_2829;
	R2073[8] = (char *(*)()) F603_2829;
	R2073[9] = (char *(*)()) F604_2829;
	R2073[10] = (char *(*)()) F605_2829;
	R2073[11] = (char *(*)()) F606_2829;
	R2073[65] = (char *(*)()) F660_3036;
	R2073[66] = (char *(*)()) F661_3036;
	R2073[67] = (char *(*)()) F662_3036;
	R2073[68] = (char *(*)()) F663_3036;
	R2073[69] = (char *(*)()) F664_3036;
	R2073[70] = (char *(*)()) F665_3036;
	R2073[71] = (char *(*)()) F666_3036;
	R2073[72] = (char *(*)()) F667_3036;
	R2073[73] = (char *(*)()) F668_3036;
	R2073[74] = (char *(*)()) F669_3036;
	R2073[75] = (char *(*)()) F670_3036;
	R2073[76] = (char *(*)()) F671_3036;
	R2073[77] = (char *(*)()) F660_3036;
	R2073[206] = (char *(*)()) F799_4726;
	R2073[209] = (char *(*)()) F802_4894;
}

char *(*R2077[210])();
void R2077_init () {
	R2077[0] = (char *(*)()) F519_2363;
	R2077[1] = (char *(*)()) F520_2363;
	R2077[2] = (char *(*)()) F521_2363;
	R2077[3] = (char *(*)()) F522_2363;
	R2077[4] = (char *(*)()) F523_2363;
	R2077[5] = (char *(*)()) F524_2363;
	R2077[6] = (char *(*)()) F525_2363;
	R2077[7] = (char *(*)()) F526_2363;
	R2077[8] = (char *(*)()) F527_2363;
	R2077[9] = (char *(*)()) F528_2363;
	R2077[10] = (char *(*)()) F529_2363;
	R2077[11] = (char *(*)()) F530_2363;
	R2077[65] = (char *(*)()) F519_2363;
	R2077[66] = (char *(*)()) F520_2363;
	R2077[67] = (char *(*)()) F521_2363;
	R2077[68] = (char *(*)()) F522_2363;
	R2077[69] = (char *(*)()) F523_2363;
	R2077[70] = (char *(*)()) F524_2363;
	R2077[71] = (char *(*)()) F525_2363;
	R2077[72] = (char *(*)()) F526_2363;
	R2077[73] = (char *(*)()) F527_2363;
	R2077[74] = (char *(*)()) F528_2363;
	R2077[75] = (char *(*)()) F529_2363;
	R2077[76] = (char *(*)()) F530_2363;
	R2077[77] = (char *(*)()) F519_2363;
	R2077[206] = (char *(*)()) F521_2363;
	R2077[209] = (char *(*)()) F529_2363;
}

char *(*R2079[145])();
void R2079_init () {
	R2079[0] = (char *(*)()) F660_3062;
	R2079[1] = (char *(*)()) F661_3062;
	R2079[2] = (char *(*)()) F662_3062;
	R2079[3] = (char *(*)()) F663_3062;
	R2079[4] = (char *(*)()) F664_3062;
	R2079[5] = (char *(*)()) F665_3062;
	R2079[6] = (char *(*)()) F666_3062;
	R2079[7] = (char *(*)()) F667_3062;
	R2079[8] = (char *(*)()) F668_3062;
	R2079[9] = (char *(*)()) F669_3062;
	R2079[10] = (char *(*)()) F670_3062;
	R2079[11] = (char *(*)()) F671_3062;
	R2079[12] = (char *(*)()) F660_3062;
	R2079[141] = (char *(*)()) F801_4854;
	R2079[144] = (char *(*)()) F804_5019;
}

char *(*R2280[235])();
void R2280_init () {
	R2280[0] = (char *(*)()) F570_2730;
	R2280[1] = (char *(*)()) F571_2730_2280_33;
	R2280[2] = (char *(*)()) F572_2730_2280_33;
	R2280[3] = (char *(*)()) F573_2730_2280_33;
	R2280[4] = (char *(*)()) F574_2730_2280_33;
	R2280[5] = (char *(*)()) F575_2730_2280_33;
	R2280[6] = (char *(*)()) F576_2730_2280_33;
	R2280[7] = (char *(*)()) F577_2730_2280_33;
	R2280[8] = (char *(*)()) F578_2730_2280_33;
	R2280[9] = (char *(*)()) F579_2730_2280_33;
	R2280[10] = (char *(*)()) F580_2730_2280_33;
	R2280[11] = (char *(*)()) F581_2730_2280_33;
	R2280[25] = (char *(*)()) F595_2821;
	R2280[26] = (char *(*)()) F596_2821_2280_33;
	R2280[27] = (char *(*)()) F597_2821_2280_33;
	R2280[28] = (char *(*)()) F598_2821_2280_33;
	R2280[29] = (char *(*)()) F599_2821_2280_33;
	R2280[30] = (char *(*)()) F600_2821_2280_33;
	R2280[31] = (char *(*)()) F601_2821_2280_33;
	R2280[32] = (char *(*)()) F602_2821_2280_33;
	R2280[33] = (char *(*)()) F603_2821_2280_33;
	R2280[34] = (char *(*)()) F604_2821_2280_33;
	R2280[35] = (char *(*)()) F605_2821_2280_33;
	R2280[36] = (char *(*)()) F606_2821_2280_33;
	R2280[90] = (char *(*)()) F660_3020;
	R2280[91] = (char *(*)()) F661_3020_2280_33;
	R2280[92] = (char *(*)()) F662_3020_2280_33;
	R2280[93] = (char *(*)()) F663_3020_2280_33;
	R2280[94] = (char *(*)()) F664_3020_2280_33;
	R2280[95] = (char *(*)()) F665_3020_2280_33;
	R2280[96] = (char *(*)()) F666_3020_2280_33;
	R2280[97] = (char *(*)()) F667_3020_2280_33;
	R2280[98] = (char *(*)()) F668_3020_2280_33;
	R2280[99] = (char *(*)()) F669_3020_2280_33;
	R2280[100] = (char *(*)()) F670_3020_2280_33;
	R2280[101] = (char *(*)()) F671_3020_2280_33;
	R2280[102] = (char *(*)()) F660_3020;
	R2280[146] = (char *(*)()) F716_3315;
	R2280[230] = (char *(*)()) F800_4765_2280_33;
	R2280[231] = (char *(*)()) F801_4788_2280_33;
	R2280[234] = (char *(*)()) F804_4952_2280_33;
}
static EIF_REFERENCE F571_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F571_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F572_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F572_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F573_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F573_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F574_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F574_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F575_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F575_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F576_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F577_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F578_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F579_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F580_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_2730_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F581_2730(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F596_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F597_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F598_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F599_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F599_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F600_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F600_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F601_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F601_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F602_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F602_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F604_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F604_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F605_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F605_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_2821_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F606_2821(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F661_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F662_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F663_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F664_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F665_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F669_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F670_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3020_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F671_3020(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_4765_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F800_4765(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4788_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F801_4788(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4952_2280_33 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F804_4952(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2281[235])();
void R2281_init () {
	R2281[0] = (char *(*)()) F570_2738;
	R2281[1] = (char *(*)()) F571_2738;
	R2281[2] = (char *(*)()) F572_2738;
	R2281[3] = (char *(*)()) F573_2738;
	R2281[4] = (char *(*)()) F574_2738;
	R2281[5] = (char *(*)()) F575_2738;
	R2281[6] = (char *(*)()) F576_2738;
	R2281[7] = (char *(*)()) F577_2738;
	R2281[8] = (char *(*)()) F578_2738;
	R2281[9] = (char *(*)()) F579_2738;
	R2281[10] = (char *(*)()) F580_2738;
	R2281[11] = (char *(*)()) F581_2738;
	R2281[25] = (char *(*)()) F595_2826;
	R2281[26] = (char *(*)()) F596_2826;
	R2281[27] = (char *(*)()) F597_2826;
	R2281[28] = (char *(*)()) F598_2826;
	R2281[29] = (char *(*)()) F599_2826;
	R2281[30] = (char *(*)()) F600_2826;
	R2281[31] = (char *(*)()) F601_2826;
	R2281[32] = (char *(*)()) F602_2826;
	R2281[33] = (char *(*)()) F603_2826;
	R2281[34] = (char *(*)()) F604_2826;
	R2281[35] = (char *(*)()) F605_2826;
	R2281[36] = (char *(*)()) F606_2826;
	R2281[90] = (char *(*)()) F607_2881;
	R2281[91] = (char *(*)()) F608_2881;
	R2281[92] = (char *(*)()) F609_2881;
	R2281[93] = (char *(*)()) F610_2881;
	R2281[94] = (char *(*)()) F611_2881;
	R2281[95] = (char *(*)()) F612_2881;
	R2281[96] = (char *(*)()) F613_2881;
	R2281[97] = (char *(*)()) F614_2881;
	R2281[98] = (char *(*)()) F615_2881;
	R2281[99] = (char *(*)()) F616_2881;
	R2281[100] = (char *(*)()) F617_2881;
	R2281[101] = (char *(*)()) F618_2881;
	R2281[102] = (char *(*)()) F607_2881;
	R2281[103] = (char *(*)()) F673_3111;
	R2281[104] = (char *(*)()) F674_3111;
	R2281[105] = (char *(*)()) F675_3111;
	R2281[106] = (char *(*)()) F676_3111;
	R2281[107] = (char *(*)()) F677_3111;
	R2281[108] = (char *(*)()) F678_3111;
	R2281[109] = (char *(*)()) F673_3111;
	R2281[110] = (char *(*)()) F675_3111;
	R2281[111] = (char *(*)()) F678_3111;
	R2281[112] = (char *(*)()) F673_3111;
	R2281[146] = (char *(*)()) F716_3345;
	{long i; for (i = 230; i < 232; i++) R2281[i] = (char *(*)()) F799_4729;}
	{long i; for (i = 233; i < 235; i++) R2281[i] = (char *(*)()) F802_4897;}
}

EIF_TYPE_INDEX *Y2281_gen_type [247];
EIF_TYPE_INDEX Y2281 [247];
void Y2281_init (void)
{
	egc_routines_types [2281] = Y2281;
	egc_routines_gen_types [2281] = Y2281_gen_type;
	egc_routines_offset [2281] = 557;
	{long i; for (i = 0; i < 100; i++) Y2281[i] = 726;};
	{long i; for (i = 102; i < 125; i++) Y2281[i] = 726;};
	Y2281[158] = 726;
	{long i; for (i = 241; i < 247; i++) Y2281[i] = 726;};
}

char *(*R2282[235])();
void R2282_init () {
	R2282[0] = (char *(*)()) F570_2739;
	R2282[1] = (char *(*)()) F571_2739;
	R2282[2] = (char *(*)()) F572_2739;
	R2282[3] = (char *(*)()) F573_2739;
	R2282[4] = (char *(*)()) F574_2739;
	R2282[5] = (char *(*)()) F575_2739;
	R2282[6] = (char *(*)()) F576_2739;
	R2282[7] = (char *(*)()) F577_2739;
	R2282[8] = (char *(*)()) F578_2739;
	R2282[9] = (char *(*)()) F579_2739;
	R2282[10] = (char *(*)()) F580_2739;
	R2282[11] = (char *(*)()) F581_2739;
	R2282[25] = (char *(*)()) F595_2827;
	R2282[26] = (char *(*)()) F596_2827;
	R2282[27] = (char *(*)()) F597_2827;
	R2282[28] = (char *(*)()) F598_2827;
	R2282[29] = (char *(*)()) F599_2827;
	R2282[30] = (char *(*)()) F600_2827;
	R2282[31] = (char *(*)()) F601_2827;
	R2282[32] = (char *(*)()) F602_2827;
	R2282[33] = (char *(*)()) F603_2827;
	R2282[34] = (char *(*)()) F604_2827;
	R2282[35] = (char *(*)()) F605_2827;
	R2282[36] = (char *(*)()) F606_2827;
	R2282[90] = (char *(*)()) F660_3035;
	R2282[91] = (char *(*)()) F661_3035;
	R2282[92] = (char *(*)()) F662_3035;
	R2282[93] = (char *(*)()) F663_3035;
	R2282[94] = (char *(*)()) F664_3035;
	R2282[95] = (char *(*)()) F665_3035;
	R2282[96] = (char *(*)()) F666_3035;
	R2282[97] = (char *(*)()) F667_3035;
	R2282[98] = (char *(*)()) F668_3035;
	R2282[99] = (char *(*)()) F669_3035;
	R2282[100] = (char *(*)()) F670_3035;
	R2282[101] = (char *(*)()) F671_3035;
	R2282[102] = (char *(*)()) F660_3035;
	R2282[103] = (char *(*)()) F673_3112;
	R2282[104] = (char *(*)()) F674_3112;
	R2282[105] = (char *(*)()) F675_3112;
	R2282[106] = (char *(*)()) F676_3112;
	R2282[107] = (char *(*)()) F677_3112;
	R2282[108] = (char *(*)()) F678_3112;
	R2282[109] = (char *(*)()) F673_3112;
	R2282[110] = (char *(*)()) F675_3112;
	R2282[111] = (char *(*)()) F678_3112;
	R2282[112] = (char *(*)()) F673_3112;
	R2282[146] = (char *(*)()) F716_3344;
	{long i; for (i = 230; i < 232; i++) R2282[i] = (char *(*)()) F799_4727;}
	{long i; for (i = 233; i < 235; i++) R2282[i] = (char *(*)()) F802_4895;}
}

char *(*R2285[12])();
void R2285_init () {
	R2285[0] = (char *(*)()) F570_2727;
	R2285[1] = (char *(*)()) F571_2727;
	R2285[2] = (char *(*)()) F572_2727;
	R2285[3] = (char *(*)()) F573_2727;
	R2285[4] = (char *(*)()) F574_2727;
	R2285[5] = (char *(*)()) F575_2727;
	R2285[6] = (char *(*)()) F576_2727;
	R2285[7] = (char *(*)()) F577_2727;
	R2285[8] = (char *(*)()) F578_2727;
	R2285[9] = (char *(*)()) F579_2727;
	R2285[10] = (char *(*)()) F580_2727;
	R2285[11] = (char *(*)()) F581_2727;
}

char *(*R2286[12])();
void R2286_init () {
	R2286[0] = (char *(*)()) F570_2728;
	R2286[1] = (char *(*)()) F571_2728_2286_114;
	R2286[2] = (char *(*)()) F572_2728_2286_114;
	R2286[3] = (char *(*)()) F573_2728_2286_114;
	R2286[4] = (char *(*)()) F574_2728_2286_114;
	R2286[5] = (char *(*)()) F575_2728_2286_114;
	R2286[6] = (char *(*)()) F576_2728_2286_114;
	R2286[7] = (char *(*)()) F577_2728_2286_114;
	R2286[8] = (char *(*)()) F578_2728_2286_114;
	R2286[9] = (char *(*)()) F579_2728_2286_114;
	R2286[10] = (char *(*)()) F580_2728_2286_114;
	R2286[11] = (char *(*)()) F581_2728_2286_114;
}
static void F571_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F571_2728(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F572_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F572_2728(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F573_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F573_2728(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F574_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F574_2728(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F575_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F575_2728(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F576_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F576_2728(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F577_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F577_2728(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F578_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F578_2728(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F579_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F579_2728(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F580_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F580_2728(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F581_2728_2286_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F581_2728(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R2295[12])();
void R2295_init () {
	R2295[0] = (char *(*)()) F570_2743;
	R2295[1] = (char *(*)()) F571_2743;
	R2295[2] = (char *(*)()) F572_2743;
	R2295[3] = (char *(*)()) F573_2743;
	R2295[4] = (char *(*)()) F574_2743;
	R2295[5] = (char *(*)()) F575_2743;
	R2295[6] = (char *(*)()) F576_2743;
	R2295[7] = (char *(*)()) F577_2743;
	R2295[8] = (char *(*)()) F578_2743;
	R2295[9] = (char *(*)()) F579_2743;
	R2295[10] = (char *(*)()) F580_2743;
	R2295[11] = (char *(*)()) F581_2743;
}

char *(*R2296[12])();
void R2296_init () {
	R2296[0] = (char *(*)()) F570_2745;
	R2296[1] = (char *(*)()) F571_2745_2296_114;
	R2296[2] = (char *(*)()) F572_2745_2296_114;
	R2296[3] = (char *(*)()) F573_2745_2296_114;
	R2296[4] = (char *(*)()) F574_2745_2296_114;
	R2296[5] = (char *(*)()) F575_2745_2296_114;
	R2296[6] = (char *(*)()) F576_2745_2296_114;
	R2296[7] = (char *(*)()) F577_2745_2296_114;
	R2296[8] = (char *(*)()) F578_2745_2296_114;
	R2296[9] = (char *(*)()) F579_2745_2296_114;
	R2296[10] = (char *(*)()) F580_2745_2296_114;
	R2296[11] = (char *(*)()) F581_2745_2296_114;
}
static void F571_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F571_2745(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F572_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F572_2745(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F573_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F573_2745(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F574_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F574_2745(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F575_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F575_2745(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F576_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F576_2745(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F577_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F577_2745(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F578_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F578_2745(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F579_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F579_2745(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F580_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F580_2745(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F581_2745_2296_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F581_2745(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R2297[12])();
void R2297_init () {
	R2297[0] = (char *(*)()) F570_2746;
	R2297[1] = (char *(*)()) F571_2746_2297_114;
	R2297[2] = (char *(*)()) F572_2746_2297_114;
	R2297[3] = (char *(*)()) F573_2746_2297_114;
	R2297[4] = (char *(*)()) F574_2746_2297_114;
	R2297[5] = (char *(*)()) F575_2746_2297_114;
	R2297[6] = (char *(*)()) F576_2746_2297_114;
	R2297[7] = (char *(*)()) F577_2746_2297_114;
	R2297[8] = (char *(*)()) F578_2746_2297_114;
	R2297[9] = (char *(*)()) F579_2746_2297_114;
	R2297[10] = (char *(*)()) F580_2746_2297_114;
	R2297[11] = (char *(*)()) F581_2746_2297_114;
}
static void F571_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F571_2746(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F572_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F572_2746(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F573_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F573_2746(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F574_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F574_2746(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F575_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F575_2746(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F576_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F576_2746(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F577_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F577_2746(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F578_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F578_2746(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F579_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F579_2746(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F580_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F580_2746(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F581_2746_2297_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F581_2746(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R2298[12])();
void R2298_init () {
	R2298[0] = (char *(*)()) F570_2747;
	R2298[1] = (char *(*)()) F571_2747_2298_4;
	R2298[2] = (char *(*)()) F572_2747_2298_4;
	R2298[3] = (char *(*)()) F573_2747_2298_4;
	R2298[4] = (char *(*)()) F574_2747_2298_4;
	R2298[5] = (char *(*)()) F575_2747_2298_4;
	R2298[6] = (char *(*)()) F576_2747_2298_4;
	R2298[7] = (char *(*)()) F577_2747_2298_4;
	R2298[8] = (char *(*)()) F578_2747_2298_4;
	R2298[9] = (char *(*)()) F579_2747_2298_4;
	R2298[10] = (char *(*)()) F580_2747_2298_4;
	R2298[11] = (char *(*)()) F581_2747_2298_4;
}
static void F571_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F571_2747(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F572_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F572_2747(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F573_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F573_2747(Current, *(EIF_POINTER *)arg1);
}
static void F574_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F574_2747(Current, *(EIF_REAL_32 *)arg1);
}
static void F575_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F575_2747(Current, *(EIF_REAL_64 *)arg1);
}
static void F576_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_2747(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F577_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F577_2747(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F578_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F578_2747(Current, *(EIF_BOOLEAN *)arg1);
}
static void F579_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_2747(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F580_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_2747(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F581_2747_2298_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F581_2747(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R2300[12])();
void R2300_init () {
	R2300[0] = (char *(*)()) F570_2749;
	R2300[1] = (char *(*)()) F571_2749_2300_117;
	R2300[2] = (char *(*)()) F572_2749_2300_117;
	R2300[3] = (char *(*)()) F573_2749_2300_117;
	R2300[4] = (char *(*)()) F574_2749_2300_117;
	R2300[5] = (char *(*)()) F575_2749_2300_117;
	R2300[6] = (char *(*)()) F576_2749_2300_117;
	R2300[7] = (char *(*)()) F577_2749_2300_117;
	R2300[8] = (char *(*)()) F578_2749_2300_117;
	R2300[9] = (char *(*)()) F579_2749_2300_117;
	R2300[10] = (char *(*)()) F580_2749_2300_117;
	R2300[11] = (char *(*)()) F581_2749_2300_117;
}
static void F571_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F571_2749(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F572_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F572_2749(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F573_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F573_2749(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F574_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F574_2749(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F575_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F575_2749(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F576_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F576_2749(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F577_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F577_2749(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F578_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F578_2749(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F579_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F579_2749(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F580_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F580_2749(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F581_2749_2300_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F581_2749(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}

char *(*R2303[12])();
void R2303_init () {
	R2303[0] = (char *(*)()) F570_2752;
	R2303[1] = (char *(*)()) F571_2752;
	R2303[2] = (char *(*)()) F572_2752;
	R2303[3] = (char *(*)()) F573_2752;
	R2303[4] = (char *(*)()) F574_2752;
	R2303[5] = (char *(*)()) F575_2752;
	R2303[6] = (char *(*)()) F576_2752;
	R2303[7] = (char *(*)()) F577_2752;
	R2303[8] = (char *(*)()) F578_2752;
	R2303[9] = (char *(*)()) F579_2752;
	R2303[10] = (char *(*)()) F580_2752;
	R2303[11] = (char *(*)()) F581_2752;
}

char *(*R2304[12])();
void R2304_init () {
	R2304[0] = (char *(*)()) F570_2753;
	R2304[1] = (char *(*)()) F571_2753;
	R2304[2] = (char *(*)()) F572_2753;
	R2304[3] = (char *(*)()) F573_2753;
	R2304[4] = (char *(*)()) F574_2753;
	R2304[5] = (char *(*)()) F575_2753;
	R2304[6] = (char *(*)()) F576_2753;
	R2304[7] = (char *(*)()) F577_2753;
	R2304[8] = (char *(*)()) F578_2753;
	R2304[9] = (char *(*)()) F579_2753;
	R2304[10] = (char *(*)()) F580_2753;
	R2304[11] = (char *(*)()) F581_2753;
}

char *(*R2305[12])();
void R2305_init () {
	R2305[0] = (char *(*)()) F570_2754;
	R2305[1] = (char *(*)()) F571_2754;
	R2305[2] = (char *(*)()) F572_2754;
	R2305[3] = (char *(*)()) F573_2754;
	R2305[4] = (char *(*)()) F574_2754;
	R2305[5] = (char *(*)()) F575_2754;
	R2305[6] = (char *(*)()) F576_2754;
	R2305[7] = (char *(*)()) F577_2754;
	R2305[8] = (char *(*)()) F578_2754;
	R2305[9] = (char *(*)()) F579_2754;
	R2305[10] = (char *(*)()) F580_2754;
	R2305[11] = (char *(*)()) F581_2754;
}

char *(*R2306[12])();
void R2306_init () {
	R2306[0] = (char *(*)()) F570_2755;
	R2306[1] = (char *(*)()) F571_2755;
	R2306[2] = (char *(*)()) F572_2755;
	R2306[3] = (char *(*)()) F573_2755;
	R2306[4] = (char *(*)()) F574_2755;
	R2306[5] = (char *(*)()) F575_2755;
	R2306[6] = (char *(*)()) F576_2755;
	R2306[7] = (char *(*)()) F577_2755;
	R2306[8] = (char *(*)()) F578_2755;
	R2306[9] = (char *(*)()) F579_2755;
	R2306[10] = (char *(*)()) F580_2755;
	R2306[11] = (char *(*)()) F581_2755;
}

char *(*R2307[12])();
void R2307_init () {
	R2307[0] = (char *(*)()) F570_2756;
	R2307[1] = (char *(*)()) F571_2756;
	R2307[2] = (char *(*)()) F572_2756;
	R2307[3] = (char *(*)()) F573_2756;
	R2307[4] = (char *(*)()) F574_2756;
	R2307[5] = (char *(*)()) F575_2756;
	R2307[6] = (char *(*)()) F576_2756;
	R2307[7] = (char *(*)()) F577_2756;
	R2307[8] = (char *(*)()) F578_2756;
	R2307[9] = (char *(*)()) F579_2756;
	R2307[10] = (char *(*)()) F580_2756;
	R2307[11] = (char *(*)()) F581_2756;
}

char *(*R2310[12])();
void R2310_init () {
	R2310[0] = (char *(*)()) F570_2759;
	R2310[1] = (char *(*)()) F571_2759;
	R2310[2] = (char *(*)()) F572_2759;
	R2310[3] = (char *(*)()) F573_2759;
	R2310[4] = (char *(*)()) F574_2759;
	R2310[5] = (char *(*)()) F575_2759;
	R2310[6] = (char *(*)()) F576_2759;
	R2310[7] = (char *(*)()) F577_2759;
	R2310[8] = (char *(*)()) F578_2759;
	R2310[9] = (char *(*)()) F579_2759;
	R2310[10] = (char *(*)()) F580_2759;
	R2310[11] = (char *(*)()) F581_2759;
}

char *(*R2313[12])();
void R2313_init () {
	R2313[0] = (char *(*)()) F570_2762;
	R2313[1] = (char *(*)()) F571_2762;
	R2313[2] = (char *(*)()) F572_2762;
	R2313[3] = (char *(*)()) F573_2762;
	R2313[4] = (char *(*)()) F574_2762;
	R2313[5] = (char *(*)()) F575_2762;
	R2313[6] = (char *(*)()) F576_2762;
	R2313[7] = (char *(*)()) F577_2762;
	R2313[8] = (char *(*)()) F578_2762;
	R2313[9] = (char *(*)()) F579_2762;
	R2313[10] = (char *(*)()) F580_2762;
	R2313[11] = (char *(*)()) F581_2762;
}

char *(*R2316[12])();
void R2316_init () {
	R2316[0] = (char *(*)()) F570_2765;
	R2316[1] = (char *(*)()) F571_2765;
	R2316[2] = (char *(*)()) F572_2765;
	R2316[3] = (char *(*)()) F573_2765;
	R2316[4] = (char *(*)()) F574_2765;
	R2316[5] = (char *(*)()) F575_2765;
	R2316[6] = (char *(*)()) F576_2765;
	R2316[7] = (char *(*)()) F577_2765;
	R2316[8] = (char *(*)()) F578_2765;
	R2316[9] = (char *(*)()) F579_2765;
	R2316[10] = (char *(*)()) F580_2765;
	R2316[11] = (char *(*)()) F581_2765;
}

char *(*R2321[12])();
void R2321_init () {
	R2321[0] = (char *(*)()) F570_2770;
	R2321[1] = (char *(*)()) F571_2770;
	R2321[2] = (char *(*)()) F572_2770;
	R2321[3] = (char *(*)()) F573_2770;
	R2321[4] = (char *(*)()) F574_2770;
	R2321[5] = (char *(*)()) F575_2770;
	R2321[6] = (char *(*)()) F576_2770;
	R2321[7] = (char *(*)()) F577_2770;
	R2321[8] = (char *(*)()) F578_2770;
	R2321[9] = (char *(*)()) F579_2770;
	R2321[10] = (char *(*)()) F580_2770;
	R2321[11] = (char *(*)()) F581_2770;
}

char *(*R2325[12])();
void R2325_init () {
	R2325[0] = (char *(*)()) F570_2775;
	R2325[1] = (char *(*)()) F571_2775;
	R2325[2] = (char *(*)()) F572_2775;
	R2325[3] = (char *(*)()) F573_2775;
	R2325[4] = (char *(*)()) F574_2775;
	R2325[5] = (char *(*)()) F575_2775;
	R2325[6] = (char *(*)()) F576_2775;
	R2325[7] = (char *(*)()) F577_2775;
	R2325[8] = (char *(*)()) F578_2775;
	R2325[9] = (char *(*)()) F579_2775;
	R2325[10] = (char *(*)()) F580_2775;
	R2325[11] = (char *(*)()) F581_2775;
}

char *(*R2349[12])();
void R2349_init () {
	R2349[0] = (char *(*)()) F595_2819;
	R2349[1] = (char *(*)()) F596_2819;
	R2349[2] = (char *(*)()) F597_2819;
	R2349[3] = (char *(*)()) F598_2819;
	R2349[4] = (char *(*)()) F599_2819;
	R2349[5] = (char *(*)()) F600_2819;
	R2349[6] = (char *(*)()) F601_2819;
	R2349[7] = (char *(*)()) F602_2819;
	R2349[8] = (char *(*)()) F603_2819;
	R2349[9] = (char *(*)()) F604_2819;
	R2349[10] = (char *(*)()) F605_2819;
	R2349[11] = (char *(*)()) F606_2819;
}

char *(*R2417[145])();
void R2417_init () {
	R2417[0] = (char *(*)()) F660_3075;
	R2417[1] = (char *(*)()) F661_3075;
	R2417[2] = (char *(*)()) F662_3075;
	R2417[3] = (char *(*)()) F663_3075;
	R2417[4] = (char *(*)()) F664_3075;
	R2417[5] = (char *(*)()) F665_3075;
	R2417[6] = (char *(*)()) F666_3075;
	R2417[7] = (char *(*)()) F667_3075;
	R2417[8] = (char *(*)()) F668_3075;
	R2417[9] = (char *(*)()) F669_3075;
	R2417[10] = (char *(*)()) F670_3075;
	R2417[11] = (char *(*)()) F671_3075;
	R2417[12] = (char *(*)()) F660_3075;
	R2417[13] = (char *(*)()) F673_3149;
	R2417[14] = (char *(*)()) F674_3149;
	R2417[15] = (char *(*)()) F675_3149;
	R2417[16] = (char *(*)()) F676_3149;
	R2417[17] = (char *(*)()) F677_3149;
	R2417[18] = (char *(*)()) F678_3149;
	R2417[19] = (char *(*)()) F673_3149;
	R2417[20] = (char *(*)()) F675_3149;
	R2417[21] = (char *(*)()) F678_3149;
	R2417[22] = (char *(*)()) F673_3149;
	R2417[56] = (char *(*)()) F716_3423;
	R2417[132] = (char *(*)()) F791_4542;
	R2417[135] = (char *(*)()) F791_4542;
	R2417[140] = (char *(*)()) F800_4781;
	R2417[141] = (char *(*)()) F801_4872;
	R2417[144] = (char *(*)()) F804_5036;
}

char *(*R2433[13])();
void R2433_init () {
	R2433[0] = (char *(*)()) F660_3018;
	R2433[1] = (char *(*)()) F661_3018;
	R2433[2] = (char *(*)()) F662_3018;
	R2433[3] = (char *(*)()) F663_3018;
	R2433[4] = (char *(*)()) F664_3018;
	R2433[5] = (char *(*)()) F665_3018;
	R2433[6] = (char *(*)()) F666_3018;
	R2433[7] = (char *(*)()) F667_3018;
	R2433[8] = (char *(*)()) F668_3018;
	R2433[9] = (char *(*)()) F669_3018;
	R2433[10] = (char *(*)()) F670_3018;
	R2433[11] = (char *(*)()) F671_3018;
	R2433[12] = (char *(*)()) F660_3018;
}

char *(*R2437[13])();
void R2437_init () {
	R2437[0] = (char *(*)()) F660_3037;
	R2437[1] = (char *(*)()) F661_3037;
	R2437[2] = (char *(*)()) F662_3037;
	R2437[3] = (char *(*)()) F663_3037;
	R2437[4] = (char *(*)()) F664_3037;
	R2437[5] = (char *(*)()) F665_3037;
	R2437[6] = (char *(*)()) F666_3037;
	R2437[7] = (char *(*)()) F667_3037;
	R2437[8] = (char *(*)()) F668_3037;
	R2437[9] = (char *(*)()) F669_3037;
	R2437[10] = (char *(*)()) F670_3037;
	R2437[11] = (char *(*)()) F671_3037;
	R2437[12] = (char *(*)()) F660_3037;
}

char *(*R2447[10])();
void R2447_init () {
	R2447[0] = (char *(*)()) F673_3090;
	R2447[1] = (char *(*)()) F674_3090;
	R2447[2] = (char *(*)()) F675_3090;
	R2447[3] = (char *(*)()) F676_3090;
	R2447[4] = (char *(*)()) F677_3090;
	R2447[5] = (char *(*)()) F678_3090;
	R2447[6] = (char *(*)()) F673_3090;
	R2447[7] = (char *(*)()) F675_3090;
	R2447[8] = (char *(*)()) F678_3090;
	R2447[9] = (char *(*)()) F673_3090;
}

char *(*R2450[10])();
void R2450_init () {
	R2450[0] = (char *(*)()) F673_3093;
	R2450[1] = (char *(*)()) F674_3093;
	R2450[2] = (char *(*)()) F675_3093;
	R2450[3] = (char *(*)()) F676_3093;
	R2450[4] = (char *(*)()) F677_3093;
	R2450[5] = (char *(*)()) F678_3093;
	R2450[6] = (char *(*)()) F673_3093;
	R2450[7] = (char *(*)()) F675_3093;
	R2450[8] = (char *(*)()) F678_3093;
	R2450[9] = (char *(*)()) F673_3093;
}

char *(*R2451[10])();
void R2451_init () {
	R2451[0] = (char *(*)()) F673_3094;
	R2451[1] = (char *(*)()) F674_3094;
	R2451[2] = (char *(*)()) F675_3094_2451_1;
	R2451[3] = (char *(*)()) F676_3094_2451_1;
	R2451[4] = (char *(*)()) F677_3094_2451_1;
	R2451[5] = (char *(*)()) F678_3094_2451_1;
	R2451[6] = (char *(*)()) F673_3094;
	R2451[7] = (char *(*)()) F675_3094_2451_1;
	R2451[8] = (char *(*)()) F678_3094_2451_1;
	R2451[9] = (char *(*)()) F673_3094;
}
static EIF_REFERENCE F675_3094_2451_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F675_3094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3094_2451_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F676_3094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3094_2451_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F677_3094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3094_2451_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3094(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R2459[10])();
void R2459_init () {
	R2459[0] = (char *(*)()) F673_3107;
	R2459[1] = (char *(*)()) F674_3107_2459_15;
	R2459[2] = (char *(*)()) F675_3107;
	R2459[3] = (char *(*)()) F676_3107;
	R2459[4] = (char *(*)()) F677_3107_2459_15;
	R2459[5] = (char *(*)()) F678_3107;
	R2459[6] = (char *(*)()) F679_3204;
	R2459[7] = (char *(*)()) F680_3204;
	R2459[8] = (char *(*)()) F681_3204;
	R2459[9] = (char *(*)()) F673_3107;
}
static EIF_INTEGER_32 F674_3107_2459_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F674_3107(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F677_3107_2459_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F677_3107(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2461[10])();
void R2461_init () {
	R2461[0] = (char *(*)()) F673_3114;
	R2461[1] = (char *(*)()) F674_3114_2461_3;
	R2461[2] = (char *(*)()) F675_3114;
	R2461[3] = (char *(*)()) F676_3114;
	R2461[4] = (char *(*)()) F677_3114_2461_3;
	R2461[5] = (char *(*)()) F678_3114;
	R2461[6] = (char *(*)()) F679_3206;
	R2461[7] = (char *(*)()) F680_3206;
	R2461[8] = (char *(*)()) F681_3206;
	R2461[9] = (char *(*)()) F673_3114;
}
static EIF_BOOLEAN F674_3114_2461_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F674_3114(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F677_3114_2461_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F677_3114(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2467[10])();
void R2467_init () {
	R2467[0] = (char *(*)()) F673_3122;
	R2467[1] = (char *(*)()) F674_3122;
	R2467[2] = (char *(*)()) F675_3122;
	R2467[3] = (char *(*)()) F676_3122;
	R2467[4] = (char *(*)()) F677_3122;
	R2467[5] = (char *(*)()) F678_3122;
	R2467[6] = (char *(*)()) F673_3122;
	R2467[7] = (char *(*)()) F675_3122;
	R2467[8] = (char *(*)()) F678_3122;
	R2467[9] = (char *(*)()) F673_3122;
}

char *(*R2468[10])();
void R2468_init () {
	R2468[0] = (char *(*)()) F673_3123;
	R2468[1] = (char *(*)()) F674_3123;
	R2468[2] = (char *(*)()) F675_3123;
	R2468[3] = (char *(*)()) F676_3123;
	R2468[4] = (char *(*)()) F677_3123;
	R2468[5] = (char *(*)()) F678_3123;
	R2468[6] = (char *(*)()) F673_3123;
	R2468[7] = (char *(*)()) F675_3123;
	R2468[8] = (char *(*)()) F678_3123;
	R2468[9] = (char *(*)()) F673_3123;
}

char *(*R2476[10])();
void R2476_init () {
	R2476[0] = (char *(*)()) F673_3132;
	R2476[1] = (char *(*)()) F674_3132_2476_4;
	R2476[2] = (char *(*)()) F675_3132;
	R2476[3] = (char *(*)()) F676_3132;
	R2476[4] = (char *(*)()) F677_3132_2476_4;
	R2476[5] = (char *(*)()) F678_3132;
	R2476[6] = (char *(*)()) F673_3132;
	R2476[7] = (char *(*)()) F675_3132;
	R2476[8] = (char *(*)()) F678_3132;
	R2476[9] = (char *(*)()) F673_3132;
}
static void F674_3132_2476_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3132(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F677_3132_2476_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_3132(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2478[10])();
void R2478_init () {
	R2478[0] = (char *(*)()) F673_3134;
	R2478[1] = (char *(*)()) F674_3134;
	R2478[2] = (char *(*)()) F675_3134;
	R2478[3] = (char *(*)()) F676_3134;
	R2478[4] = (char *(*)()) F677_3134;
	R2478[5] = (char *(*)()) F678_3134;
	R2478[6] = (char *(*)()) F673_3134;
	R2478[7] = (char *(*)()) F675_3134;
	R2478[8] = (char *(*)()) F678_3134;
	R2478[9] = (char *(*)()) F673_3134;
}

char *(*R2479[10])();
void R2479_init () {
	R2479[0] = (char *(*)()) F673_3135;
	R2479[1] = (char *(*)()) F674_3135;
	R2479[2] = (char *(*)()) F675_3135;
	R2479[3] = (char *(*)()) F676_3135;
	R2479[4] = (char *(*)()) F677_3135;
	R2479[5] = (char *(*)()) F678_3135;
	R2479[6] = (char *(*)()) F673_3135;
	R2479[7] = (char *(*)()) F675_3135;
	R2479[8] = (char *(*)()) F678_3135;
	R2479[9] = (char *(*)()) F673_3135;
}

char *(*R2485[10])();
void R2485_init () {
	R2485[0] = (char *(*)()) F673_3148;
	R2485[1] = (char *(*)()) F674_3148;
	R2485[2] = (char *(*)()) F675_3148;
	R2485[3] = (char *(*)()) F676_3148;
	R2485[4] = (char *(*)()) F677_3148;
	R2485[5] = (char *(*)()) F678_3148;
	R2485[6] = (char *(*)()) F679_3208;
	R2485[7] = (char *(*)()) F680_3208;
	R2485[8] = (char *(*)()) F681_3208;
	R2485[9] = (char *(*)()) F673_3148;
}

char *(*R2494[10])();
void R2494_init () {
	R2494[0] = (char *(*)()) F673_3158;
	R2494[1] = (char *(*)()) F674_3158;
	R2494[2] = (char *(*)()) F675_3158;
	R2494[3] = (char *(*)()) F676_3158;
	R2494[4] = (char *(*)()) F677_3158;
	R2494[5] = (char *(*)()) F678_3158;
	R2494[6] = (char *(*)()) F673_3158;
	R2494[7] = (char *(*)()) F675_3158;
	R2494[8] = (char *(*)()) F678_3158;
	R2494[9] = (char *(*)()) F673_3158;
}

char *(*R2495[10])();
void R2495_init () {
	R2495[0] = (char *(*)()) F673_3159;
	R2495[1] = (char *(*)()) F674_3159;
	R2495[2] = (char *(*)()) F675_3159;
	R2495[3] = (char *(*)()) F676_3159;
	R2495[4] = (char *(*)()) F677_3159;
	R2495[5] = (char *(*)()) F678_3159;
	R2495[6] = (char *(*)()) F673_3159;
	R2495[7] = (char *(*)()) F675_3159;
	R2495[8] = (char *(*)()) F678_3159;
	R2495[9] = (char *(*)()) F673_3159;
}

char *(*R2502[10])();
void R2502_init () {
	R2502[0] = (char *(*)()) F673_3166;
	R2502[1] = (char *(*)()) F674_3166;
	R2502[2] = (char *(*)()) F675_3166_2502_1;
	R2502[3] = (char *(*)()) F676_3166_2502_1;
	R2502[4] = (char *(*)()) F677_3166_2502_1;
	R2502[5] = (char *(*)()) F678_3166_2502_1;
	R2502[6] = (char *(*)()) F673_3166;
	R2502[7] = (char *(*)()) F675_3166_2502_1;
	R2502[8] = (char *(*)()) F678_3166_2502_1;
	R2502[9] = (char *(*)()) F673_3166;
}
static EIF_REFERENCE F675_3166_2502_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F675_3166(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F676_3166_2502_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F676_3166(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3166_2502_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F677_3166(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F678_3166_2502_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F678_3166(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R2503[10])();
void R2503_init () {
	R2503[0] = (char *(*)()) F673_3167;
	R2503[1] = (char *(*)()) F674_3167_2503_1;
	R2503[2] = (char *(*)()) F675_3167;
	R2503[3] = (char *(*)()) F676_3167;
	R2503[4] = (char *(*)()) F677_3167_2503_1;
	R2503[5] = (char *(*)()) F678_3167;
	R2503[6] = (char *(*)()) F673_3167;
	R2503[7] = (char *(*)()) F675_3167;
	R2503[8] = (char *(*)()) F678_3167;
	R2503[9] = (char *(*)()) F673_3167;
}
static EIF_REFERENCE F674_3167_2503_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F674_3167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F677_3167_2503_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F677_3167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2504[10])();
void R2504_init () {
	R2504[0] = (char *(*)()) F673_3168;
	R2504[1] = (char *(*)()) F674_3168;
	R2504[2] = (char *(*)()) F675_3168;
	R2504[3] = (char *(*)()) F676_3168;
	R2504[4] = (char *(*)()) F677_3168;
	R2504[5] = (char *(*)()) F678_3168;
	R2504[6] = (char *(*)()) F673_3168;
	R2504[7] = (char *(*)()) F675_3168;
	R2504[8] = (char *(*)()) F678_3168;
	R2504[9] = (char *(*)()) F673_3168;
}

char *(*R2505[10])();
void R2505_init () {
	R2505[0] = (char *(*)()) F673_3169;
	R2505[1] = (char *(*)()) F674_3169;
	R2505[2] = (char *(*)()) F675_3169;
	R2505[3] = (char *(*)()) F676_3169;
	R2505[4] = (char *(*)()) F677_3169;
	R2505[5] = (char *(*)()) F678_3169;
	R2505[6] = (char *(*)()) F673_3169;
	R2505[7] = (char *(*)()) F675_3169;
	R2505[8] = (char *(*)()) F678_3169;
	R2505[9] = (char *(*)()) F673_3169;
}

char *(*R2507[10])();
void R2507_init () {
	R2507[0] = (char *(*)()) F673_3171;
	R2507[1] = (char *(*)()) F674_3171;
	R2507[2] = (char *(*)()) F675_3171;
	R2507[3] = (char *(*)()) F676_3171;
	R2507[4] = (char *(*)()) F677_3171;
	R2507[5] = (char *(*)()) F678_3171;
	R2507[6] = (char *(*)()) F673_3171;
	R2507[7] = (char *(*)()) F675_3171;
	R2507[8] = (char *(*)()) F678_3171;
	R2507[9] = (char *(*)()) F673_3171;
}

char *(*R2508[10])();
void R2508_init () {
	R2508[0] = (char *(*)()) F673_3172;
	R2508[1] = (char *(*)()) F674_3172;
	R2508[2] = (char *(*)()) F675_3172;
	R2508[3] = (char *(*)()) F676_3172;
	R2508[4] = (char *(*)()) F677_3172;
	R2508[5] = (char *(*)()) F678_3172;
	R2508[6] = (char *(*)()) F673_3172;
	R2508[7] = (char *(*)()) F675_3172;
	R2508[8] = (char *(*)()) F678_3172;
	R2508[9] = (char *(*)()) F673_3172;
}

char *(*R2510[10])();
void R2510_init () {
	R2510[0] = (char *(*)()) F673_3174;
	R2510[1] = (char *(*)()) F674_3174;
	R2510[2] = (char *(*)()) F675_3174;
	R2510[3] = (char *(*)()) F676_3174;
	R2510[4] = (char *(*)()) F677_3174;
	R2510[5] = (char *(*)()) F678_3174;
	R2510[6] = (char *(*)()) F673_3174;
	R2510[7] = (char *(*)()) F675_3174;
	R2510[8] = (char *(*)()) F678_3174;
	R2510[9] = (char *(*)()) F673_3174;
}

char *(*R2511[10])();
void R2511_init () {
	R2511[0] = (char *(*)()) F673_3175;
	R2511[1] = (char *(*)()) F674_3175;
	R2511[2] = (char *(*)()) F675_3175;
	R2511[3] = (char *(*)()) F676_3175;
	R2511[4] = (char *(*)()) F677_3175;
	R2511[5] = (char *(*)()) F678_3175;
	R2511[6] = (char *(*)()) F673_3175;
	R2511[7] = (char *(*)()) F675_3175;
	R2511[8] = (char *(*)()) F678_3175;
	R2511[9] = (char *(*)()) F673_3175;
}

char *(*R2512[10])();
void R2512_init () {
	R2512[0] = (char *(*)()) F673_3176;
	R2512[1] = (char *(*)()) F674_3176;
	R2512[2] = (char *(*)()) F675_3176;
	R2512[3] = (char *(*)()) F676_3176;
	R2512[4] = (char *(*)()) F677_3176;
	R2512[5] = (char *(*)()) F678_3176;
	R2512[6] = (char *(*)()) F673_3176;
	R2512[7] = (char *(*)()) F675_3176;
	R2512[8] = (char *(*)()) F678_3176;
	R2512[9] = (char *(*)()) F673_3176;
}

char *(*R2516[10])();
void R2516_init () {
	R2516[0] = (char *(*)()) F673_3180;
	R2516[1] = (char *(*)()) F674_3180_2516_4;
	R2516[2] = (char *(*)()) F675_3180;
	R2516[3] = (char *(*)()) F676_3180;
	R2516[4] = (char *(*)()) F677_3180_2516_4;
	R2516[5] = (char *(*)()) F678_3180;
	R2516[6] = (char *(*)()) F673_3180;
	R2516[7] = (char *(*)()) F675_3180;
	R2516[8] = (char *(*)()) F678_3180;
	R2516[9] = (char *(*)()) F673_3180;
}
static void F674_3180_2516_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F674_3180(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F677_3180_2516_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F677_3180(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2522[10])();
void R2522_init () {
	R2522[0] = (char *(*)()) F673_3186;
	R2522[1] = (char *(*)()) F674_3186;
	R2522[2] = (char *(*)()) F675_3186;
	R2522[3] = (char *(*)()) F676_3186;
	R2522[4] = (char *(*)()) F677_3186;
	R2522[5] = (char *(*)()) F678_3186;
	R2522[6] = (char *(*)()) F673_3186;
	R2522[7] = (char *(*)()) F675_3186;
	R2522[8] = (char *(*)()) F678_3186;
	R2522[9] = (char *(*)()) F673_3186;
}

char *(*R2535[10])();
void R2535_init () {
	R2535[0] = (char *(*)()) F673_3199;
	R2535[1] = (char *(*)()) F674_3199;
	R2535[2] = (char *(*)()) F675_3199;
	R2535[3] = (char *(*)()) F676_3199;
	R2535[4] = (char *(*)()) F677_3199;
	R2535[5] = (char *(*)()) F678_3199;
	R2535[6] = (char *(*)()) F673_3199;
	R2535[7] = (char *(*)()) F675_3199;
	R2535[8] = (char *(*)()) F678_3199;
	R2535[9] = (char *(*)()) F673_3199;
}

char *(*R2538[3])();
void R2538_init () {
	R2538[0] = (char *(*)()) F679_3202;
	R2538[1] = (char *(*)()) F680_3202;
	R2538[2] = (char *(*)()) F681_3202;
}

char *(*R2551[121])();
void R2551_init () {
	R2551[0] = (char *(*)()) F684_3247;
	R2551[1] = (char *(*)()) F685_3289;
	R2551[2] = (char *(*)()) F686_3289;
	R2551[3] = (char *(*)()) F687_3289;
	R2551[4] = (char *(*)()) F688_3289;
	R2551[5] = (char *(*)()) F689_3289;
	R2551[6] = (char *(*)()) F690_3289;
	R2551[7] = (char *(*)()) F691_3289;
	R2551[8] = (char *(*)()) F692_3289;
	R2551[9] = (char *(*)()) F693_3289;
	R2551[10] = (char *(*)()) F694_3289;
	R2551[11] = (char *(*)()) F695_3289;
	R2551[12] = (char *(*)()) F696_3289;
	R2551[13] = (char *(*)()) F697_3289;
	R2551[14] = (char *(*)()) F698_3289;
	R2551[15] = (char *(*)()) F699_3289;
	R2551[16] = (char *(*)()) F700_3289;
	R2551[17] = (char *(*)()) F701_3289;
	R2551[18] = (char *(*)()) F702_3289;
	R2551[19] = (char *(*)()) F703_3289;
	R2551[20] = (char *(*)()) F704_3289;
	R2551[21] = (char *(*)()) F705_3289;
	R2551[22] = (char *(*)()) F706_3289;
	R2551[23] = (char *(*)()) F707_3289;
	R2551[24] = (char *(*)()) F708_3289;
	R2551[25] = (char *(*)()) F709_3289;
	R2551[26] = (char *(*)()) F710_3289;
	R2551[27] = (char *(*)()) F711_3289;
	R2551[28] = (char *(*)()) F712_3289;
	R2551[29] = (char *(*)()) F713_3289;
	R2551[30] = (char *(*)()) F714_3289;
	R2551[31] = (char *(*)()) F715_3289;
	R2551[32] = (char *(*)()) F716_3341;
	R2551[33] = (char *(*)()) F717_3454;
	{long i; for (i = 36; i < 38; i++) R2551[i] = (char *(*)()) F719_3476;}
	{long i; for (i = 39; i < 41; i++) R2551[i] = (char *(*)()) F722_3497;}
	{long i; for (i = 42; i < 44; i++) R2551[i] = (char *(*)()) F725_3595;}
	{long i; for (i = 45; i < 47; i++) R2551[i] = (char *(*)()) F728_3694;}
	{long i; for (i = 48; i < 50; i++) R2551[i] = (char *(*)()) F731_3793;}
	{long i; for (i = 51; i < 53; i++) R2551[i] = (char *(*)()) F734_3892;}
	{long i; for (i = 54; i < 56; i++) R2551[i] = (char *(*)()) F737_3986;}
	{long i; for (i = 57; i < 59; i++) R2551[i] = (char *(*)()) F740_4080;}
	{long i; for (i = 60; i < 62; i++) R2551[i] = (char *(*)()) F743_4175;}
	{long i; for (i = 63; i < 65; i++) R2551[i] = (char *(*)()) F746_4270;}
	{long i; for (i = 66; i < 68; i++) R2551[i] = (char *(*)()) F749_4336;}
	{long i; for (i = 69; i < 71; i++) R2551[i] = (char *(*)()) F752_4403;}
	{long i; for (i = 72; i < 74; i++) R2551[i] = (char *(*)()) F755_4444;}
	{long i; for (i = 75; i < 105; i++) R2551[i] = (char *(*)()) F758_4492;}
	R2551[105] = (char *(*)()) F789_4518;
	R2551[106] = (char *(*)()) F790_4518;
	R2551[108] = (char *(*)()) F791_4526;
	R2551[111] = (char *(*)()) F791_4526;
	{long i; for (i = 116; i < 118; i++) R2551[i] = (char *(*)()) F796_4585;}
	{long i; for (i = 119; i < 121; i++) R2551[i] = (char *(*)()) F796_4585;}
}

char *(*R2609[31])();
void R2609_init () {
	R2609[0] = (char *(*)()) F685_3285;
	R2609[1] = (char *(*)()) F686_3285;
	R2609[2] = (char *(*)()) F687_3285;
	R2609[3] = (char *(*)()) F688_3285;
	R2609[4] = (char *(*)()) F689_3285;
	R2609[5] = (char *(*)()) F690_3285;
	R2609[6] = (char *(*)()) F691_3285;
	R2609[7] = (char *(*)()) F692_3285;
	R2609[8] = (char *(*)()) F693_3285;
	R2609[9] = (char *(*)()) F694_3285;
	R2609[10] = (char *(*)()) F695_3285;
	R2609[11] = (char *(*)()) F696_3285;
	R2609[12] = (char *(*)()) F697_3285;
	R2609[13] = (char *(*)()) F698_3285;
	R2609[14] = (char *(*)()) F699_3285;
	R2609[15] = (char *(*)()) F700_3285;
	R2609[16] = (char *(*)()) F701_3285;
	R2609[17] = (char *(*)()) F702_3285;
	R2609[18] = (char *(*)()) F703_3285;
	R2609[19] = (char *(*)()) F704_3285;
	R2609[20] = (char *(*)()) F705_3285;
	R2609[21] = (char *(*)()) F706_3285;
	R2609[22] = (char *(*)()) F707_3285;
	R2609[23] = (char *(*)()) F708_3285;
	R2609[24] = (char *(*)()) F709_3285;
	R2609[25] = (char *(*)()) F710_3285;
	R2609[26] = (char *(*)()) F711_3285;
	R2609[27] = (char *(*)()) F712_3285;
	R2609[28] = (char *(*)()) F713_3285;
	R2609[29] = (char *(*)()) F714_3285;
	R2609[30] = (char *(*)()) F715_3285;
}

char *(*R2610[31])();
void R2610_init () {
	R2610[0] = (char *(*)()) F685_3286;
	R2610[1] = (char *(*)()) F686_3286;
	R2610[2] = (char *(*)()) F687_3286;
	R2610[3] = (char *(*)()) F688_3286;
	R2610[4] = (char *(*)()) F689_3286;
	R2610[5] = (char *(*)()) F690_3286;
	R2610[6] = (char *(*)()) F691_3286;
	R2610[7] = (char *(*)()) F692_3286;
	R2610[8] = (char *(*)()) F693_3286;
	R2610[9] = (char *(*)()) F694_3286;
	R2610[10] = (char *(*)()) F695_3286;
	R2610[11] = (char *(*)()) F696_3286;
	R2610[12] = (char *(*)()) F697_3286;
	R2610[13] = (char *(*)()) F698_3286;
	R2610[14] = (char *(*)()) F699_3286;
	R2610[15] = (char *(*)()) F700_3286;
	R2610[16] = (char *(*)()) F701_3286;
	R2610[17] = (char *(*)()) F702_3286;
	R2610[18] = (char *(*)()) F703_3286;
	R2610[19] = (char *(*)()) F704_3286;
	R2610[20] = (char *(*)()) F705_3286;
	R2610[21] = (char *(*)()) F706_3286;
	R2610[22] = (char *(*)()) F707_3286;
	R2610[23] = (char *(*)()) F708_3286;
	R2610[24] = (char *(*)()) F709_3286;
	R2610[25] = (char *(*)()) F710_3286;
	R2610[26] = (char *(*)()) F711_3286;
	R2610[27] = (char *(*)()) F712_3286;
	R2610[28] = (char *(*)()) F713_3286;
	R2610[29] = (char *(*)()) F714_3286;
	R2610[30] = (char *(*)()) F715_3286;
}

char *(*R2612[31])();
void R2612_init () {
	R2612[0] = (char *(*)()) F685_3288;
	R2612[1] = (char *(*)()) F686_3288;
	R2612[2] = (char *(*)()) F687_3288;
	R2612[3] = (char *(*)()) F688_3288;
	R2612[4] = (char *(*)()) F689_3288;
	R2612[5] = (char *(*)()) F690_3288;
	R2612[6] = (char *(*)()) F691_3288;
	R2612[7] = (char *(*)()) F692_3288;
	R2612[8] = (char *(*)()) F693_3288;
	R2612[9] = (char *(*)()) F694_3288;
	R2612[10] = (char *(*)()) F695_3288;
	R2612[11] = (char *(*)()) F696_3288;
	R2612[12] = (char *(*)()) F697_3288;
	R2612[13] = (char *(*)()) F698_3288;
	R2612[14] = (char *(*)()) F699_3288;
	R2612[15] = (char *(*)()) F700_3288;
	R2612[16] = (char *(*)()) F701_3288;
	R2612[17] = (char *(*)()) F702_3288;
	R2612[18] = (char *(*)()) F703_3288;
	R2612[19] = (char *(*)()) F704_3288;
	R2612[20] = (char *(*)()) F705_3288;
	R2612[21] = (char *(*)()) F706_3288;
	R2612[22] = (char *(*)()) F707_3288;
	R2612[23] = (char *(*)()) F708_3288;
	R2612[24] = (char *(*)()) F709_3288;
	R2612[25] = (char *(*)()) F710_3288;
	R2612[26] = (char *(*)()) F711_3288;
	R2612[27] = (char *(*)()) F712_3288;
	R2612[28] = (char *(*)()) F713_3288;
	R2612[29] = (char *(*)()) F714_3288;
	R2612[30] = (char *(*)()) F715_3288;
}

char *(*R2617[31])();
void R2617_init () {
	R2617[0] = (char *(*)()) F685_3294;
	R2617[1] = (char *(*)()) F686_3294;
	R2617[2] = (char *(*)()) F687_3294;
	R2617[3] = (char *(*)()) F688_3294;
	R2617[4] = (char *(*)()) F689_3294;
	R2617[5] = (char *(*)()) F690_3294;
	R2617[6] = (char *(*)()) F691_3294;
	R2617[7] = (char *(*)()) F692_3294;
	R2617[8] = (char *(*)()) F693_3294;
	R2617[9] = (char *(*)()) F694_3294;
	R2617[10] = (char *(*)()) F695_3294;
	R2617[11] = (char *(*)()) F696_3294;
	R2617[12] = (char *(*)()) F697_3294;
	R2617[13] = (char *(*)()) F698_3294;
	R2617[14] = (char *(*)()) F699_3294;
	R2617[15] = (char *(*)()) F700_3294;
	R2617[16] = (char *(*)()) F701_3294;
	R2617[17] = (char *(*)()) F702_3294;
	R2617[18] = (char *(*)()) F703_3294;
	R2617[19] = (char *(*)()) F704_3294;
	R2617[20] = (char *(*)()) F705_3294;
	R2617[21] = (char *(*)()) F706_3294;
	R2617[22] = (char *(*)()) F707_3294;
	R2617[23] = (char *(*)()) F708_3294;
	R2617[24] = (char *(*)()) F709_3294;
	R2617[25] = (char *(*)()) F710_3294;
	R2617[26] = (char *(*)()) F711_3294;
	R2617[27] = (char *(*)()) F712_3294;
	R2617[28] = (char *(*)()) F713_3294;
	R2617[29] = (char *(*)()) F714_3294;
	R2617[30] = (char *(*)()) F715_3294;
}

char *(*R2622[31])();
void R2622_init () {
	R2622[0] = (char *(*)()) F685_3302;
	R2622[1] = (char *(*)()) F686_3302_2622_1;
	R2622[2] = (char *(*)()) F687_3302_2622_1;
	R2622[3] = (char *(*)()) F688_3302_2622_1;
	R2622[4] = (char *(*)()) F689_3302_2622_1;
	R2622[5] = (char *(*)()) F690_3302_2622_1;
	R2622[6] = (char *(*)()) F691_3302_2622_1;
	R2622[7] = (char *(*)()) F692_3302_2622_1;
	R2622[8] = (char *(*)()) F693_3302_2622_1;
	R2622[9] = (char *(*)()) F694_3302_2622_1;
	R2622[10] = (char *(*)()) F695_3302_2622_1;
	R2622[11] = (char *(*)()) F696_3302_2622_1;
	R2622[12] = (char *(*)()) F697_3302_2622_1;
	R2622[13] = (char *(*)()) F698_3302_2622_1;
	R2622[14] = (char *(*)()) F699_3302_2622_1;
	R2622[15] = (char *(*)()) F700_3302_2622_1;
	R2622[16] = (char *(*)()) F701_3302;
	R2622[17] = (char *(*)()) F702_3302_2622_1;
	R2622[18] = (char *(*)()) F703_3302_2622_1;
	R2622[19] = (char *(*)()) F704_3302_2622_1;
	R2622[20] = (char *(*)()) F705_3302_2622_1;
	R2622[21] = (char *(*)()) F706_3302_2622_1;
	R2622[22] = (char *(*)()) F707_3302_2622_1;
	R2622[23] = (char *(*)()) F708_3302_2622_1;
	R2622[24] = (char *(*)()) F709_3302_2622_1;
	R2622[25] = (char *(*)()) F710_3302_2622_1;
	R2622[26] = (char *(*)()) F711_3302_2622_1;
	R2622[27] = (char *(*)()) F712_3302_2622_1;
	R2622[28] = (char *(*)()) F713_3302_2622_1;
	R2622[29] = (char *(*)()) F714_3302_2622_1;
	R2622[30] = (char *(*)()) F715_3302_2622_1;
}
static EIF_REFERENCE F686_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F686_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F687_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {759,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F688_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F689_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F689_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F690_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F690_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F691_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F691_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F692_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F692_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F693_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F693_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F694_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F694_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(732, 0x00).id, 732, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F695_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F695_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(729, 0x00).id, 729, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F696_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F696_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F697_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F697_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F698_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F698_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F699_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F699_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F700_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F700_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F702_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F702_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {761,723,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 761, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F703_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {763,756,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 763, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F704_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {765,732,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 765, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F705_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {767,729,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 767, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F706_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {769,726,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 769, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F707_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {771,720,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 771, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F708_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {773,753,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 773, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F709_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {775,744,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 775, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F710_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {777,750,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 777, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F711_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {779,735,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 779, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F712_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F712_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {781,738,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 781, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F713_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F713_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {783,741,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 783, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F714_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F714_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {785,747,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 785, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F715_3302_2622_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F715_3302(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {787,789,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 787, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}

char *(*R2632[31])();
void R2632_init () {
	R2632[0] = (char *(*)()) F685_3314;
	R2632[1] = (char *(*)()) F686_3314;
	R2632[2] = (char *(*)()) F687_3314;
	R2632[3] = (char *(*)()) F688_3314;
	R2632[4] = (char *(*)()) F689_3314;
	R2632[5] = (char *(*)()) F690_3314;
	R2632[6] = (char *(*)()) F691_3314;
	R2632[7] = (char *(*)()) F692_3314;
	R2632[8] = (char *(*)()) F693_3314;
	R2632[9] = (char *(*)()) F694_3314;
	R2632[10] = (char *(*)()) F695_3314;
	R2632[11] = (char *(*)()) F696_3314;
	R2632[12] = (char *(*)()) F697_3314;
	R2632[13] = (char *(*)()) F698_3314;
	R2632[14] = (char *(*)()) F699_3314;
	R2632[15] = (char *(*)()) F700_3314;
	R2632[16] = (char *(*)()) F701_3314;
	R2632[17] = (char *(*)()) F702_3314;
	R2632[18] = (char *(*)()) F703_3314;
	R2632[19] = (char *(*)()) F704_3314;
	R2632[20] = (char *(*)()) F705_3314;
	R2632[21] = (char *(*)()) F706_3314;
	R2632[22] = (char *(*)()) F707_3314;
	R2632[23] = (char *(*)()) F708_3314;
	R2632[24] = (char *(*)()) F709_3314;
	R2632[25] = (char *(*)()) F710_3314;
	R2632[26] = (char *(*)()) F711_3314;
	R2632[27] = (char *(*)()) F712_3314;
	R2632[28] = (char *(*)()) F713_3314;
	R2632[29] = (char *(*)()) F714_3314;
	R2632[30] = (char *(*)()) F715_3314;
}

char *(*R2817[2])();
void R2817_init () {
	R2817[0] = (char *(*)()) F723_3579;
	R2817[1] = (char *(*)()) F724_3579;
}

char *(*R2820[2])();
void R2820_init () {
	R2820[0] = (char *(*)()) F723_3582;
	R2820[1] = (char *(*)()) F724_3582;
}

char *(*R2872[2])();
void R2872_init () {
	R2872[0] = (char *(*)()) F726_3677;
	R2872[1] = (char *(*)()) F727_3677;
}

char *(*R2873[2])();
void R2873_init () {
	R2873[0] = (char *(*)()) F726_3678;
	R2873[1] = (char *(*)()) F727_3678;
}

char *(*R2877[2])();
void R2877_init () {
	R2877[0] = (char *(*)()) F726_3682;
	R2877[1] = (char *(*)()) F727_3682;
}

char *(*R2929[2])();
void R2929_init () {
	R2929[0] = (char *(*)()) F729_3777;
	R2929[1] = (char *(*)()) F730_3777;
}

char *(*R2932[2])();
void R2932_init () {
	R2932[0] = (char *(*)()) F729_3780;
	R2932[1] = (char *(*)()) F730_3780;
}

char *(*R2982[2])();
void R2982_init () {
	R2982[0] = (char *(*)()) F732_3873;
	R2982[1] = (char *(*)()) F733_3873;
}

char *(*R2985[2])();
void R2985_init () {
	R2985[0] = (char *(*)()) F732_3876;
	R2985[1] = (char *(*)()) F733_3876;
}

char *(*R2988[2])();
void R2988_init () {
	R2988[0] = (char *(*)()) F732_3879;
	R2988[1] = (char *(*)()) F733_3879;
}

char *(*R3042[2])();
void R3042_init () {
	R3042[0] = (char *(*)()) F735_3973;
	R3042[1] = (char *(*)()) F736_3973;
}

char *(*R3088[2])();
void R3088_init () {
	R3088[0] = (char *(*)()) F738_4061;
	R3088[1] = (char *(*)()) F739_4061;
}

char *(*R3089[2])();
void R3089_init () {
	R3089[0] = (char *(*)()) F738_4062;
	R3089[1] = (char *(*)()) F739_4062;
}

char *(*R3091[2])();
void R3091_init () {
	R3091[0] = (char *(*)()) F738_4064;
	R3091[1] = (char *(*)()) F739_4064;
}

char *(*R3094[2])();
void R3094_init () {
	R3094[0] = (char *(*)()) F738_4067;
	R3094[1] = (char *(*)()) F739_4067;
}

char *(*R3095[2])();
void R3095_init () {
	R3095[0] = (char *(*)()) F738_4068;
	R3095[1] = (char *(*)()) F739_4068;
}

char *(*R3143[2])();
void R3143_init () {
	R3143[0] = (char *(*)()) F741_4158;
	R3143[1] = (char *(*)()) F742_4158;
}

char *(*R3144[2])();
void R3144_init () {
	R3144[0] = (char *(*)()) F741_4159;
	R3144[1] = (char *(*)()) F742_4159;
}

char *(*R3147[2])();
void R3147_init () {
	R3147[0] = (char *(*)()) F741_4162;
	R3147[1] = (char *(*)()) F742_4162;
}

char *(*R3195[2])();
void R3195_init () {
	R3195[0] = (char *(*)()) F744_4252;
	R3195[1] = (char *(*)()) F745_4252;
}

char *(*R3196[2])();
void R3196_init () {
	R3196[0] = (char *(*)()) F744_4253;
	R3196[1] = (char *(*)()) F745_4253;
}

char *(*R3197[2])();
void R3197_init () {
	R3197[0] = (char *(*)()) F744_4254;
	R3197[1] = (char *(*)()) F745_4254;
}

char *(*R3198[2])();
void R3198_init () {
	R3198[0] = (char *(*)()) F744_4255;
	R3198[1] = (char *(*)()) F745_4255;
}

char *(*R3200[2])();
void R3200_init () {
	R3200[0] = (char *(*)()) F744_4257;
	R3200[1] = (char *(*)()) F745_4257;
}

char *(*R3246[2])();
void R3246_init () {
	R3246[0] = (char *(*)()) F747_4315;
	R3246[1] = (char *(*)()) F748_4315;
}

char *(*R3280[2])();
void R3280_init () {
	R3280[0] = (char *(*)()) F750_4381;
	R3280[1] = (char *(*)()) F751_4381;
}

char *(*R3301[2])();
void R3301_init () {
	R3301[0] = (char *(*)()) F753_4439;
	R3301[1] = (char *(*)()) F754_4439;
}

char *(*R3437[1])();
void R3437_init () {
	R3437[0] = (char *(*)()) F794_4565_3437_1;
}
static EIF_REFERENCE F794_4565_3437_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F794_4565(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R3442[1])();
void R3442_init () {
	R3442[0] = (char *(*)()) F794_4574_3442_456;
}
static EIF_REFERENCE F794_4574_3442_456 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F794_4574(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y3443_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3443_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3443_pgtype2[] = {720,0xFFFF};
EIF_TYPE_INDEX *Y3443_gen_type [3];
EIF_TYPE_INDEX Y3443 [3];
void Y3443_init (void)
{
	egc_routines_types [3443] = Y3443;
	egc_routines_gen_types [3443] = Y3443_gen_type;
	egc_routines_offset [3443] = 792;
	Y3443_gen_type [0] = Y3443_pgtype0;
	Y3443_gen_type [1] = Y3443_pgtype1;
	Y3443_gen_type [2] = Y3443_pgtype2;
	Y3443[2] = 720;
}

char *(*R3444[5])();
void R3444_init () {
	{long i; for (i = 0; i < 2; i++) R3444[i] = (char *(*)()) F799_4706;}
	{long i; for (i = 3; i < 5; i++) R3444[i] = (char *(*)()) F802_4873;}
}

char *(*R3446[5])();
void R3446_init () {
	R3446[0] = (char *(*)()) F800_4767;
	R3446[1] = (char *(*)()) F801_4790;
	R3446[3] = (char *(*)()) F803_4933;
	R3446[4] = (char *(*)()) F804_4955;
}

char *(*R3447[5])();
void R3447_init () {
	R3447[0] = (char *(*)()) F800_4765;
	R3447[1] = (char *(*)()) F801_4788;
	R3447[3] = (char *(*)()) F803_4932;
	R3447[4] = (char *(*)()) F804_4954;
}

char *(*R3448[5])();
void R3448_init () {
	{long i; for (i = 0; i < 2; i++) R3448[i] = (char *(*)()) F799_4718;}
	{long i; for (i = 3; i < 5; i++) R3448[i] = (char *(*)()) F796_4579;}
}

char *(*R3458[5])();
void R3458_init () {
	{long i; for (i = 0; i < 2; i++) R3458[i] = (char *(*)()) F799_4736;}
	{long i; for (i = 3; i < 5; i++) R3458[i] = (char *(*)()) F802_4904;}
}

char *(*R3460[5])();
void R3460_init () {
	{long i; for (i = 0; i < 2; i++) R3460[i] = (char *(*)()) F799_4738;}
	{long i; for (i = 3; i < 5; i++) R3460[i] = (char *(*)()) F802_4906;}
}

char *(*R3461[5])();
void R3461_init () {
	R3461[0] = (char *(*)()) F800_4777;
	R3461[1] = (char *(*)()) F495_2350;
	R3461[3] = (char *(*)()) F803_4942;
	R3461[4] = (char *(*)()) F503_2350;
}

char *(*R3483[5])();
void R3483_init () {
	{long i; for (i = 0; i < 2; i++) R3483[i] = (char *(*)()) F799_4727;}
	{long i; for (i = 3; i < 5; i++) R3483[i] = (char *(*)()) F802_4895;}
}

char *(*R3484[5])();
void R3484_init () {
	{long i; for (i = 0; i < 2; i++) R3484[i] = (char *(*)()) F799_4726;}
	{long i; for (i = 3; i < 5; i++) R3484[i] = (char *(*)()) F802_4894;}
}

char *(*R3505[5])();
void R3505_init () {
	R3505[0] = (char *(*)()) F800_4772;
	R3505[1] = (char *(*)()) F801_4856;
	R3505[3] = (char *(*)()) F803_4938;
	R3505[4] = (char *(*)()) F804_5021;
}

char *(*R3524[5])();
void R3524_init () {
	R3524[0] = (char *(*)()) F800_4774;
	R3524[1] = (char *(*)()) F801_4868;
	R3524[3] = (char *(*)()) F803_4940;
	R3524[4] = (char *(*)()) F804_5033;
}

char *(*R3528[5])();
void R3528_init () {
	R3528[0] = (char *(*)()) F800_4778;
	R3528[1] = (char *(*)()) F801_4871;
	R3528[3] = (char *(*)()) F803_4944;
	R3528[4] = (char *(*)()) F804_5037;
}

char *(*R3539[4])();
void R3539_init () {
	R3539[0] = (char *(*)()) F801_4870;
	R3539[3] = (char *(*)()) F804_5035;
}

char *(*R3542[4])();
void R3542_init () {
	R3542[0] = (char *(*)()) F801_4809;
	R3542[3] = (char *(*)()) F804_4974;
}

char *(*R3572[4])();
void R3572_init () {
	R3572[0] = (char *(*)()) F801_4853;
	R3572[3] = (char *(*)()) F804_5018;
}

char *(*R3600[2])();
void R3600_init () {
	R3600[0] = (char *(*)()) F800_4780;
	R3600[1] = (char *(*)()) F799_4757;
}

char *(*R3672[2])();
void R3672_init () {
	R3672[0] = (char *(*)()) F803_4935;
	R3672[1] = (char *(*)()) F804_5005;
}

char *(*R3680[2])();
void R3680_init () {
	R3680[0] = (char *(*)()) F803_4946;
	R3680[1] = (char *(*)()) F802_4925;
}

char *(*R3756[2])();
void R3756_init () {
	R3756[0] = (char *(*)()) F808_5126;
	R3756[1] = (char *(*)()) F809_5134;
}

char *(*R3761[2])();
void R3761_init () {
	R3761[0] = (char *(*)()) F808_5121;
	R3761[1] = (char *(*)()) F809_5135;
}

char *(*R3763[2])();
void R3763_init () {
	R3763[0] = (char *(*)()) F808_5122;
	R3763[1] = (char *(*)()) F809_5136;
}
char *(*R2[813])();
void R2_init () {}
char *(*R6[813])();
void R6_init () {}

char *(*R3[813])();
void R3_init () {
	R3[131] = (char *(*)()) F132_1368;
	R3[805] = (char *(*)()) F806_5056;
}

char *(*R4[813])();
void R4_init () {
	{long i; for (i = 1; i < 3; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 4; i < 7; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 8; i < 10; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 12; i < 15; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 27; i < 31; i++) R4[i] = (char *(*)()) F1_15;}
	R4[35] = (char *(*)()) F1_15;
	R4[37] = (char *(*)()) F1_15;
	R4[41] = (char *(*)()) F1_15;
	{long i; for (i = 44; i < 46; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 50; i < 56; i++) R4[i] = (char *(*)()) F1_15;}
	R4[58] = (char *(*)()) F1_15;
	R4[63] = (char *(*)()) F1_15;
	R4[69] = (char *(*)()) F1_15;
	{long i; for (i = 71; i < 73; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 74; i < 76; i++) R4[i] = (char *(*)()) F1_15;}
	R4[78] = (char *(*)()) F1_15;
	R4[82] = (char *(*)()) F1_15;
	R4[87] = (char *(*)()) F1_15;
	{long i; for (i = 89; i < 93; i++) R4[i] = (char *(*)()) F1_15;}
	R4[95] = (char *(*)()) F1_15;
	{long i; for (i = 97; i < 100; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 101; i < 104; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 105; i < 107; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 109; i < 111; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 112; i < 115; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 116; i < 120; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 121; i < 123; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 124; i < 130; i++) R4[i] = (char *(*)()) F1_15;}
	R4[131] = (char *(*)()) F132_1287;
	R4[135] = (char *(*)()) F1_15;
	R4[155] = (char *(*)()) F1_15;
	R4[156] = (char *(*)()) F157_1885;
	R4[241] = (char *(*)()) F1_15;
	{long i; for (i = 287; i < 293; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 305; i < 331; i++) R4[i] = (char *(*)()) F1_15;}
	R4[491] = (char *(*)()) F1_15;
	{long i; for (i = 569; i < 581; i++) R4[i] = (char *(*)()) F1_15;}
	R4[594] = (char *(*)()) F595_2869;
	R4[595] = (char *(*)()) F596_2869;
	R4[596] = (char *(*)()) F597_2869;
	R4[597] = (char *(*)()) F598_2869;
	R4[598] = (char *(*)()) F599_2869;
	R4[599] = (char *(*)()) F600_2869;
	R4[600] = (char *(*)()) F601_2869;
	R4[601] = (char *(*)()) F602_2869;
	R4[602] = (char *(*)()) F603_2869;
	R4[603] = (char *(*)()) F604_2869;
	R4[604] = (char *(*)()) F605_2869;
	R4[605] = (char *(*)()) F606_2869;
	R4[659] = (char *(*)()) F660_3065;
	R4[660] = (char *(*)()) F661_3065;
	R4[661] = (char *(*)()) F662_3065;
	R4[662] = (char *(*)()) F663_3065;
	R4[663] = (char *(*)()) F664_3065;
	R4[664] = (char *(*)()) F665_3065;
	R4[665] = (char *(*)()) F666_3065;
	R4[666] = (char *(*)()) F667_3065;
	R4[667] = (char *(*)()) F668_3065;
	R4[668] = (char *(*)()) F669_3065;
	R4[669] = (char *(*)()) F670_3065;
	R4[670] = (char *(*)()) F671_3065;
	R4[671] = (char *(*)()) F660_3065;
	R4[672] = (char *(*)()) F673_3147;
	R4[673] = (char *(*)()) F674_3147;
	R4[674] = (char *(*)()) F675_3147;
	R4[675] = (char *(*)()) F676_3147;
	R4[676] = (char *(*)()) F677_3147;
	R4[677] = (char *(*)()) F678_3147;
	R4[678] = (char *(*)()) F673_3147;
	R4[679] = (char *(*)()) F675_3147;
	R4[680] = (char *(*)()) F678_3147;
	R4[681] = (char *(*)()) F673_3147;
	R4[683] = (char *(*)()) F684_3261;
	{long i; for (i = 684; i < 717; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 719; i < 721; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 722; i < 724; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 725; i < 727; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 728; i < 730; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 731; i < 733; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 734; i < 736; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 737; i < 739; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 740; i < 742; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 743; i < 745; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 746; i < 748; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 749; i < 751; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 752; i < 754; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 755; i < 757; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 758; i < 790; i++) R4[i] = (char *(*)()) F1_15;}
	R4[791] = (char *(*)()) F791_4538;
	R4[794] = (char *(*)()) F794_4570;
	R4[799] = (char *(*)()) F800_4764;
	R4[800] = (char *(*)()) F799_4745;
	R4[802] = (char *(*)()) F803_4929;
	R4[803] = (char *(*)()) F802_4913;
	{long i; for (i = 804; i < 806; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 807; i < 809; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 810; i < 812; i++) R4[i] = (char *(*)()) F1_15;}
}

char *(*R5[813])();
void R5_init () {
	{long i; for (i = 1; i < 3; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 4; i < 7; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 8; i < 10; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 12; i < 15; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 27; i < 31; i++) R5[i] = (char *(*)()) F1_8;}
	R5[35] = (char *(*)()) F1_8;
	R5[37] = (char *(*)()) F1_8;
	R5[41] = (char *(*)()) F1_8;
	{long i; for (i = 44; i < 46; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 50; i < 56; i++) R5[i] = (char *(*)()) F1_8;}
	R5[58] = (char *(*)()) F1_8;
	R5[63] = (char *(*)()) F1_8;
	R5[69] = (char *(*)()) F1_8;
	{long i; for (i = 71; i < 73; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 74; i < 76; i++) R5[i] = (char *(*)()) F1_8;}
	R5[78] = (char *(*)()) F1_8;
	R5[82] = (char *(*)()) F1_8;
	R5[87] = (char *(*)()) F1_8;
	{long i; for (i = 89; i < 93; i++) R5[i] = (char *(*)()) F1_8;}
	R5[95] = (char *(*)()) F1_8;
	{long i; for (i = 97; i < 100; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 101; i < 104; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 105; i < 107; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 109; i < 111; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 112; i < 115; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 116; i < 120; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 121; i < 123; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 124; i < 130; i++) R5[i] = (char *(*)()) F1_8;}
	R5[131] = (char *(*)()) F132_1286;
	R5[135] = (char *(*)()) F1_8;
	R5[155] = (char *(*)()) F156_1835;
	R5[156] = (char *(*)()) F157_1884;
	R5[241] = (char *(*)()) F1_8;
	{long i; for (i = 287; i < 293; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 305; i < 331; i++) R5[i] = (char *(*)()) F1_8;}
	R5[491] = (char *(*)()) F1_8;
	{long i; for (i = 569; i < 581; i++) R5[i] = (char *(*)()) F1_8;}
	R5[594] = (char *(*)()) F595_2831;
	R5[595] = (char *(*)()) F596_2831;
	R5[596] = (char *(*)()) F597_2831;
	R5[597] = (char *(*)()) F598_2831;
	R5[598] = (char *(*)()) F599_2831;
	R5[599] = (char *(*)()) F600_2831;
	R5[600] = (char *(*)()) F601_2831;
	R5[601] = (char *(*)()) F602_2831;
	R5[602] = (char *(*)()) F603_2831;
	R5[603] = (char *(*)()) F604_2831;
	R5[604] = (char *(*)()) F605_2831;
	R5[605] = (char *(*)()) F606_2831;
	R5[659] = (char *(*)()) F660_3038;
	R5[660] = (char *(*)()) F661_3038;
	R5[661] = (char *(*)()) F662_3038;
	R5[662] = (char *(*)()) F663_3038;
	R5[663] = (char *(*)()) F664_3038;
	R5[664] = (char *(*)()) F665_3038;
	R5[665] = (char *(*)()) F666_3038;
	R5[666] = (char *(*)()) F667_3038;
	R5[667] = (char *(*)()) F668_3038;
	R5[668] = (char *(*)()) F669_3038;
	R5[669] = (char *(*)()) F670_3038;
	R5[670] = (char *(*)()) F671_3038;
	R5[671] = (char *(*)()) F660_3038;
	R5[672] = (char *(*)()) F673_3113;
	R5[673] = (char *(*)()) F674_3113;
	R5[674] = (char *(*)()) F675_3113;
	R5[675] = (char *(*)()) F676_3113;
	R5[676] = (char *(*)()) F677_3113;
	R5[677] = (char *(*)()) F678_3113;
	R5[678] = (char *(*)()) F679_3207;
	R5[679] = (char *(*)()) F680_3207;
	R5[680] = (char *(*)()) F681_3207;
	R5[681] = (char *(*)()) F673_3113;
	R5[683] = (char *(*)()) F684_3258;
	R5[684] = (char *(*)()) F685_3295;
	R5[685] = (char *(*)()) F686_3295;
	R5[686] = (char *(*)()) F687_3295;
	R5[687] = (char *(*)()) F688_3295;
	R5[688] = (char *(*)()) F689_3295;
	R5[689] = (char *(*)()) F690_3295;
	R5[690] = (char *(*)()) F691_3295;
	R5[691] = (char *(*)()) F692_3295;
	R5[692] = (char *(*)()) F693_3295;
	R5[693] = (char *(*)()) F694_3295;
	R5[694] = (char *(*)()) F695_3295;
	R5[695] = (char *(*)()) F696_3295;
	R5[696] = (char *(*)()) F697_3295;
	R5[697] = (char *(*)()) F698_3295;
	R5[698] = (char *(*)()) F699_3295;
	R5[699] = (char *(*)()) F700_3295;
	R5[700] = (char *(*)()) F701_3295;
	R5[701] = (char *(*)()) F702_3295;
	R5[702] = (char *(*)()) F703_3295;
	R5[703] = (char *(*)()) F704_3295;
	R5[704] = (char *(*)()) F705_3295;
	R5[705] = (char *(*)()) F706_3295;
	R5[706] = (char *(*)()) F707_3295;
	R5[707] = (char *(*)()) F708_3295;
	R5[708] = (char *(*)()) F709_3295;
	R5[709] = (char *(*)()) F710_3295;
	R5[710] = (char *(*)()) F711_3295;
	R5[711] = (char *(*)()) F712_3295;
	R5[712] = (char *(*)()) F713_3295;
	R5[713] = (char *(*)()) F714_3295;
	R5[714] = (char *(*)()) F715_3295;
	R5[715] = (char *(*)()) F716_3338;
	R5[716] = (char *(*)()) F1_8;
	{long i; for (i = 719; i < 721; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 722; i < 724; i++) R5[i] = (char *(*)()) F722_3505;}
	{long i; for (i = 725; i < 727; i++) R5[i] = (char *(*)()) F725_3603;}
	{long i; for (i = 728; i < 730; i++) R5[i] = (char *(*)()) F728_3702;}
	{long i; for (i = 731; i < 733; i++) R5[i] = (char *(*)()) F731_3801;}
	{long i; for (i = 734; i < 736; i++) R5[i] = (char *(*)()) F734_3900;}
	{long i; for (i = 737; i < 739; i++) R5[i] = (char *(*)()) F737_3994;}
	{long i; for (i = 740; i < 742; i++) R5[i] = (char *(*)()) F740_4088;}
	{long i; for (i = 743; i < 745; i++) R5[i] = (char *(*)()) F743_4183;}
	{long i; for (i = 746; i < 748; i++) R5[i] = (char *(*)()) F746_4282;}
	{long i; for (i = 749; i < 751; i++) R5[i] = (char *(*)()) F749_4348;}
	{long i; for (i = 752; i < 754; i++) R5[i] = (char *(*)()) F752_4409;}
	{long i; for (i = 755; i < 757; i++) R5[i] = (char *(*)()) F755_4449;}
	{long i; for (i = 758; i < 790; i++) R5[i] = (char *(*)()) F758_4494;}
	R5[791] = (char *(*)()) F791_4531;
	R5[794] = (char *(*)()) F794_4569;
	{long i; for (i = 799; i < 801; i++) R5[i] = (char *(*)()) F799_4730;}
	{long i; for (i = 802; i < 804; i++) R5[i] = (char *(*)()) F802_4898;}
	{long i; for (i = 804; i < 806; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 807; i < 809; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 810; i < 812; i++) R5[i] = (char *(*)()) F1_8;}
}


#ifdef __cplusplus
}
#endif
