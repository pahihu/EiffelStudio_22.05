#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[811])();
void R28_init () {
	{long i; for (i = 0; i < 2; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 3; i < 6; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 7; i < 9; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 11; i < 14; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 26; i < 30; i++) R28[i] = (char *(*)()) F1_25;}
	R28[34] = (char *(*)()) F1_25;
	R28[36] = (char *(*)()) F1_25;
	R28[40] = (char *(*)()) F1_25;
	{long i; for (i = 43; i < 45; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 49; i < 55; i++) R28[i] = (char *(*)()) F1_25;}
	R28[57] = (char *(*)()) F1_25;
	R28[62] = (char *(*)()) F1_25;
	R28[68] = (char *(*)()) F1_25;
	{long i; for (i = 70; i < 72; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 73; i < 75; i++) R28[i] = (char *(*)()) F1_25;}
	R28[77] = (char *(*)()) F1_25;
	R28[81] = (char *(*)()) F1_25;
	R28[86] = (char *(*)()) F1_25;
	R28[88] = (char *(*)()) F1_25;
	{long i; for (i = 89; i < 92; i++) R28[i] = (char *(*)()) F91_1174;}
	R28[94] = (char *(*)()) F91_1174;
	{long i; for (i = 96; i < 99; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 100; i < 103; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 104; i < 106; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 108; i < 110; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 111; i < 114; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 115; i < 119; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 120; i < 122; i++) R28[i] = (char *(*)()) F91_1174;}
	{long i; for (i = 123; i < 129; i++) R28[i] = (char *(*)()) F91_1174;}
	R28[130] = (char *(*)()) F1_25;
	R28[134] = (char *(*)()) F1_25;
	{long i; for (i = 154; i < 156; i++) R28[i] = (char *(*)()) F1_25;}
	R28[240] = (char *(*)()) F1_25;
	{long i; for (i = 286; i < 292; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 304; i < 330; i++) R28[i] = (char *(*)()) F1_25;}
	R28[490] = (char *(*)()) F1_25;
	{long i; for (i = 568; i < 580; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 593; i < 605; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 658; i < 680; i++) R28[i] = (char *(*)()) F1_25;}
	R28[680] = (char *(*)()) F682_3216;
	R28[682] = (char *(*)()) F684_3262;
	R28[683] = (char *(*)()) F685_3303;
	R28[684] = (char *(*)()) F686_3303;
	R28[685] = (char *(*)()) F687_3303;
	R28[686] = (char *(*)()) F688_3303;
	R28[687] = (char *(*)()) F689_3303;
	R28[688] = (char *(*)()) F690_3303;
	R28[689] = (char *(*)()) F691_3303;
	R28[690] = (char *(*)()) F692_3303;
	R28[691] = (char *(*)()) F693_3303;
	R28[692] = (char *(*)()) F694_3303;
	R28[693] = (char *(*)()) F695_3303;
	R28[694] = (char *(*)()) F696_3303;
	R28[695] = (char *(*)()) F697_3303;
	R28[696] = (char *(*)()) F698_3303;
	R28[697] = (char *(*)()) F699_3303;
	R28[698] = (char *(*)()) F700_3303;
	R28[699] = (char *(*)()) F701_3303;
	R28[700] = (char *(*)()) F702_3303;
	R28[701] = (char *(*)()) F703_3303;
	R28[702] = (char *(*)()) F704_3303;
	R28[703] = (char *(*)()) F705_3303;
	R28[704] = (char *(*)()) F706_3303;
	R28[705] = (char *(*)()) F707_3303;
	R28[706] = (char *(*)()) F708_3303;
	R28[707] = (char *(*)()) F709_3303;
	R28[708] = (char *(*)()) F710_3303;
	R28[709] = (char *(*)()) F711_3303;
	R28[710] = (char *(*)()) F712_3303;
	R28[711] = (char *(*)()) F713_3303;
	R28[712] = (char *(*)()) F714_3303;
	R28[713] = (char *(*)()) F715_3303;
	{long i; for (i = 714; i < 716; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 718; i < 720; i++) R28[i] = (char *(*)()) F719_3488;}
	{long i; for (i = 721; i < 723; i++) R28[i] = (char *(*)()) F722_3564;}
	{long i; for (i = 724; i < 726; i++) R28[i] = (char *(*)()) F725_3663;}
	{long i; for (i = 727; i < 729; i++) R28[i] = (char *(*)()) F728_3762;}
	{long i; for (i = 730; i < 732; i++) R28[i] = (char *(*)()) F731_3861;}
	{long i; for (i = 733; i < 735; i++) R28[i] = (char *(*)()) F734_3957;}
	{long i; for (i = 736; i < 738; i++) R28[i] = (char *(*)()) F737_4051;}
	{long i; for (i = 739; i < 741; i++) R28[i] = (char *(*)()) F740_4146;}
	{long i; for (i = 742; i < 744; i++) R28[i] = (char *(*)()) F743_4241;}
	R28[745] = (char *(*)()) F747_4334;
	R28[746] = (char *(*)()) F748_4334;
	R28[748] = (char *(*)()) F750_4400;
	R28[749] = (char *(*)()) F751_4400;
	{long i; for (i = 751; i < 753; i++) R28[i] = (char *(*)()) F752_4416;}
	{long i; for (i = 754; i < 756; i++) R28[i] = (char *(*)()) F755_4456;}
	{long i; for (i = 757; i < 787; i++) R28[i] = (char *(*)()) F758_4509;}
	R28[787] = (char *(*)()) F789_4522;
	R28[788] = (char *(*)()) F790_4522;
	R28[790] = (char *(*)()) F1_25;
	R28[793] = (char *(*)()) F1_25;
	{long i; for (i = 798; i < 800; i++) R28[i] = (char *(*)()) F799_4750;}
	{long i; for (i = 801; i < 803; i++) R28[i] = (char *(*)()) F802_4918;}
	{long i; for (i = 803; i < 805; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 806; i < 808; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 809; i < 811; i++) R28[i] = (char *(*)()) F1_25;}
}

char *(*R780[4])();
void R780_init () {
	R780[0] = (char *(*)()) F53_802;
	R780[1] = (char *(*)()) F54_802_780_1;
	R780[2] = (char *(*)()) F55_802_780_1;
	R780[3] = (char *(*)()) F56_802_780_1;
}
static EIF_REFERENCE F54_802_780_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F54_802(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F55_802_780_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F55_802(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F56_802_780_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F56_802(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R1006[733])();
void R1006_init () {
	R1006[0] = (char *(*)()) F79_1069;
	R1006[732] = (char *(*)()) F811_5162;
}

char *(*R1007[733])();
void R1007_init () {
	R1007[0] = (char *(*)()) F79_1071;
	R1007[732] = (char *(*)()) F811_5165;
}

char *(*R1008[733])();
void R1008_init () {
	R1008[0] = (char *(*)()) F79_1072;
	R1008[732] = (char *(*)()) F811_5166;
}

char *(*R1011[121])();
void R1011_init () {
	R1011[0] = (char *(*)()) F684_3257;
	R1011[39] = (char *(*)()) F723_3566_1011_2;
	R1011[40] = (char *(*)()) F724_3566_1011_2;
	R1011[42] = (char *(*)()) F726_3665_1011_2;
	R1011[43] = (char *(*)()) F727_3665_1011_2;
	R1011[45] = (char *(*)()) F729_3764_1011_2;
	R1011[46] = (char *(*)()) F730_3764_1011_2;
	R1011[48] = (char *(*)()) F732_3863_1011_2;
	R1011[49] = (char *(*)()) F733_3863_1011_2;
	R1011[51] = (char *(*)()) F735_3958_1011_2;
	R1011[52] = (char *(*)()) F736_3958_1011_2;
	R1011[54] = (char *(*)()) F738_4052_1011_2;
	R1011[55] = (char *(*)()) F739_4052_1011_2;
	R1011[57] = (char *(*)()) F741_4147_1011_2;
	R1011[58] = (char *(*)()) F742_4147_1011_2;
	R1011[60] = (char *(*)()) F744_4242_1011_2;
	R1011[61] = (char *(*)()) F745_4242_1011_2;
	R1011[63] = (char *(*)()) F747_4311_1011_2;
	R1011[64] = (char *(*)()) F748_4311_1011_2;
	R1011[66] = (char *(*)()) F750_4377_1011_2;
	R1011[67] = (char *(*)()) F751_4377_1011_2;
	{long i; for (i = 69; i < 71; i++) R1011[i] = (char *(*)()) F752_4408;}
	{long i; for (i = 72; i < 74; i++) R1011[i] = (char *(*)()) F755_4448;}
	{long i; for (i = 116; i < 118; i++) R1011[i] = (char *(*)()) F799_4735;}
	{long i; for (i = 119; i < 121; i++) R1011[i] = (char *(*)()) F802_4903;}
}
static EIF_BOOLEAN F723_3566_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F723_3566(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F724_3566_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F724_3566(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F726_3665_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F726_3665(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F727_3665_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F727_3665(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F729_3764_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F729_3764(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F730_3764_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F730_3764(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F732_3863_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F732_3863(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F733_3863_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F733_3863(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F735_3958_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F735_3958(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F736_3958_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F736_3958(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F738_4052_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F738_4052(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F739_4052_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F739_4052(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F741_4147_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F741_4147(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F742_4147_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F742_4147(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F744_4242_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F744_4242(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F745_4242_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F745_4242(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F747_4311_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F747_4311(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F748_4311_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F748_4311(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F750_4377_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F750_4377(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F751_4377_1011_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F751_4377(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R1095[40])();
void R1095_init () {
	R1095[0] = (char *(*)()) F91_1161;
	{long i; for (i = 1; i < 3; i++) R1095[i] = (char *(*)()) F92_1185;}
	R1095[5] = (char *(*)()) F96_1188;
	R1095[7] = (char *(*)()) F98_1190;
	R1095[8] = (char *(*)()) F99_1196;
	R1095[9] = (char *(*)()) F100_1213;
	R1095[11] = (char *(*)()) F102_1217;
	R1095[12] = (char *(*)()) F103_1219;
	R1095[13] = (char *(*)()) F104_1221;
	R1095[15] = (char *(*)()) F106_1223;
	R1095[16] = (char *(*)()) F107_1227;
	R1095[19] = (char *(*)()) F110_1229;
	R1095[20] = (char *(*)()) F111_1231;
	R1095[22] = (char *(*)()) F113_1235;
	R1095[23] = (char *(*)()) F114_1241;
	R1095[24] = (char *(*)()) F115_1243;
	R1095[26] = (char *(*)()) F117_1245;
	R1095[27] = (char *(*)()) F118_1247;
	R1095[28] = (char *(*)()) F119_1251;
	R1095[29] = (char *(*)()) F120_1255;
	R1095[31] = (char *(*)()) F122_1257;
	R1095[32] = (char *(*)()) F123_1259;
	R1095[34] = (char *(*)()) F125_1261;
	R1095[35] = (char *(*)()) F126_1263;
	R1095[36] = (char *(*)()) F127_1265;
	R1095[37] = (char *(*)()) F128_1267;
	R1095[38] = (char *(*)()) F129_1271;
	R1095[39] = (char *(*)()) F130_1273;
}

char *(*R1582[648])();
void R1582_init () {
	R1582[0] = (char *(*)()) F148_1715;
	R1582[438] = (char *(*)()) F141_1715;
	R1582[439] = (char *(*)()) F142_1715;
	R1582[440] = (char *(*)()) F143_1715;
	R1582[441] = (char *(*)()) F144_1715;
	R1582[442] = (char *(*)()) F145_1715;
	R1582[443] = (char *(*)()) F146_1715;
	R1582[444] = (char *(*)()) F147_1715;
	R1582[445] = (char *(*)()) F148_1715;
	R1582[446] = (char *(*)()) F149_1715;
	R1582[447] = (char *(*)()) F150_1715;
	R1582[448] = (char *(*)()) F151_1715;
	R1582[449] = (char *(*)()) F152_1715;
	R1582[503] = (char *(*)()) F141_1715;
	R1582[504] = (char *(*)()) F142_1715;
	R1582[505] = (char *(*)()) F143_1715;
	R1582[506] = (char *(*)()) F144_1715;
	R1582[507] = (char *(*)()) F145_1715;
	R1582[508] = (char *(*)()) F146_1715;
	R1582[509] = (char *(*)()) F147_1715;
	R1582[510] = (char *(*)()) F148_1715;
	R1582[511] = (char *(*)()) F149_1715;
	R1582[512] = (char *(*)()) F150_1715;
	R1582[513] = (char *(*)()) F151_1715;
	R1582[514] = (char *(*)()) F152_1715;
	R1582[515] = (char *(*)()) F141_1715;
	R1582[644] = (char *(*)()) F143_1715;
	R1582[647] = (char *(*)()) F151_1715;
}

char *(*R1583[648])();
void R1583_init () {
	R1583[0] = (char *(*)()) F148_1716_1583_114;
	R1583[438] = (char *(*)()) F141_1716;
	R1583[439] = (char *(*)()) F142_1716_1583_114;
	R1583[440] = (char *(*)()) F143_1716_1583_114;
	R1583[441] = (char *(*)()) F144_1716_1583_114;
	R1583[442] = (char *(*)()) F145_1716_1583_114;
	R1583[443] = (char *(*)()) F146_1716_1583_114;
	R1583[444] = (char *(*)()) F147_1716_1583_114;
	R1583[445] = (char *(*)()) F148_1716_1583_114;
	R1583[446] = (char *(*)()) F149_1716_1583_114;
	R1583[447] = (char *(*)()) F150_1716_1583_114;
	R1583[448] = (char *(*)()) F151_1716_1583_114;
	R1583[449] = (char *(*)()) F152_1716_1583_114;
	R1583[503] = (char *(*)()) F141_1716;
	R1583[504] = (char *(*)()) F142_1716_1583_114;
	R1583[505] = (char *(*)()) F143_1716_1583_114;
	R1583[506] = (char *(*)()) F144_1716_1583_114;
	R1583[507] = (char *(*)()) F145_1716_1583_114;
	R1583[508] = (char *(*)()) F146_1716_1583_114;
	R1583[509] = (char *(*)()) F147_1716_1583_114;
	R1583[510] = (char *(*)()) F148_1716_1583_114;
	R1583[511] = (char *(*)()) F149_1716_1583_114;
	R1583[512] = (char *(*)()) F150_1716_1583_114;
	R1583[513] = (char *(*)()) F151_1716_1583_114;
	R1583[514] = (char *(*)()) F152_1716_1583_114;
	R1583[515] = (char *(*)()) F141_1716;
	R1583[644] = (char *(*)()) F143_1716_1583_114;
	R1583[647] = (char *(*)()) F151_1716_1583_114;
}
static void F148_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F148_1716(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F142_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F142_1716(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F143_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F143_1716(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F144_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F144_1716(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F145_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F145_1716(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F146_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F146_1716(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F147_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F147_1716(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F149_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F149_1716(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F150_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F150_1716(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F151_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F151_1716(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F152_1716_1583_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F152_1716(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R1589[648])();
void R1589_init () {
	R1589[0] = (char *(*)()) F148_1722;
	R1589[438] = (char *(*)()) F141_1722;
	R1589[439] = (char *(*)()) F142_1722;
	R1589[440] = (char *(*)()) F143_1722;
	R1589[441] = (char *(*)()) F144_1722;
	R1589[442] = (char *(*)()) F145_1722;
	R1589[443] = (char *(*)()) F146_1722;
	R1589[444] = (char *(*)()) F147_1722;
	R1589[445] = (char *(*)()) F148_1722;
	R1589[446] = (char *(*)()) F149_1722;
	R1589[447] = (char *(*)()) F150_1722;
	R1589[448] = (char *(*)()) F151_1722;
	R1589[449] = (char *(*)()) F152_1722;
	R1589[503] = (char *(*)()) F141_1722;
	R1589[504] = (char *(*)()) F142_1722;
	R1589[505] = (char *(*)()) F143_1722;
	R1589[506] = (char *(*)()) F144_1722;
	R1589[507] = (char *(*)()) F145_1722;
	R1589[508] = (char *(*)()) F146_1722;
	R1589[509] = (char *(*)()) F147_1722;
	R1589[510] = (char *(*)()) F148_1722;
	R1589[511] = (char *(*)()) F149_1722;
	R1589[512] = (char *(*)()) F150_1722;
	R1589[513] = (char *(*)()) F151_1722;
	R1589[514] = (char *(*)()) F152_1722;
	R1589[515] = (char *(*)()) F141_1722;
	R1589[644] = (char *(*)()) F143_1722;
	R1589[647] = (char *(*)()) F151_1722;
}

static EIF_TYPE_INDEX Y1590_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype12[] = {744,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype13[] = {744,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype39[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype40[] = {756,0xFFFF};
EIF_TYPE_INDEX *Y1590_gen_type [664];
EIF_TYPE_INDEX Y1590 [664];
void Y1590_init (void)
{
	egc_routines_types [1590] = Y1590;
	egc_routines_gen_types [1590] = Y1590_gen_type;
	egc_routines_offset [1590] = 140;
	Y1590_gen_type [0] = Y1590_pgtype0;
	Y1590_gen_type [1] = Y1590_pgtype1;
	Y1590_gen_type [2] = Y1590_pgtype2;
	Y1590_gen_type [3] = Y1590_pgtype3;
	Y1590_gen_type [4] = Y1590_pgtype4;
	Y1590_gen_type [5] = Y1590_pgtype5;
	Y1590_gen_type [6] = Y1590_pgtype6;
	Y1590_gen_type [7] = Y1590_pgtype7;
	Y1590_gen_type [8] = Y1590_pgtype8;
	Y1590_gen_type [9] = Y1590_pgtype9;
	Y1590_gen_type [10] = Y1590_pgtype10;
	Y1590_gen_type [11] = Y1590_pgtype11;
	Y1590_gen_type [16] = Y1590_pgtype12;
	Y1590_gen_type [17] = Y1590_pgtype13;
	Y1590_gen_type [454] = Y1590_pgtype14;
	Y1590_gen_type [455] = Y1590_pgtype15;
	Y1590_gen_type [456] = Y1590_pgtype16;
	Y1590_gen_type [457] = Y1590_pgtype17;
	Y1590_gen_type [458] = Y1590_pgtype18;
	Y1590_gen_type [459] = Y1590_pgtype19;
	Y1590_gen_type [460] = Y1590_pgtype20;
	Y1590_gen_type [461] = Y1590_pgtype21;
	Y1590_gen_type [462] = Y1590_pgtype22;
	Y1590_gen_type [463] = Y1590_pgtype23;
	Y1590_gen_type [464] = Y1590_pgtype24;
	Y1590_gen_type [465] = Y1590_pgtype25;
	Y1590_gen_type [519] = Y1590_pgtype26;
	Y1590_gen_type [520] = Y1590_pgtype27;
	Y1590_gen_type [521] = Y1590_pgtype28;
	Y1590_gen_type [522] = Y1590_pgtype29;
	Y1590_gen_type [523] = Y1590_pgtype30;
	Y1590_gen_type [524] = Y1590_pgtype31;
	Y1590_gen_type [525] = Y1590_pgtype32;
	Y1590_gen_type [526] = Y1590_pgtype33;
	Y1590_gen_type [527] = Y1590_pgtype34;
	Y1590_gen_type [528] = Y1590_pgtype35;
	Y1590_gen_type [529] = Y1590_pgtype36;
	Y1590_gen_type [530] = Y1590_pgtype37;
	Y1590_gen_type [531] = Y1590_pgtype38;
	Y1590_gen_type [660] = Y1590_pgtype39;
	Y1590_gen_type [663] = Y1590_pgtype40;
	{long i; for (i = 16; i < 18; i++) Y1590[i] = 744;};
	Y1590[660] = 753;
	Y1590[663] = 756;
}

char *(*R1821[12])();
void R1821_init () {
	R1821[0] = (char *(*)()) F570_2740;
	R1821[1] = (char *(*)()) F571_2740;
	R1821[2] = (char *(*)()) F572_2740;
	R1821[3] = (char *(*)()) F573_2740;
	R1821[4] = (char *(*)()) F574_2740;
	R1821[5] = (char *(*)()) F575_2740;
	R1821[6] = (char *(*)()) F576_2740;
	R1821[7] = (char *(*)()) F577_2740;
	R1821[8] = (char *(*)()) F578_2740;
	R1821[9] = (char *(*)()) F579_2740;
	R1821[10] = (char *(*)()) F580_2740;
	R1821[11] = (char *(*)()) F581_2740;
}

char *(*R1822[12])();
void R1822_init () {
	R1822[0] = (char *(*)()) F570_2741;
	R1822[1] = (char *(*)()) F571_2741;
	R1822[2] = (char *(*)()) F572_2741;
	R1822[3] = (char *(*)()) F573_2741;
	R1822[4] = (char *(*)()) F574_2741;
	R1822[5] = (char *(*)()) F575_2741;
	R1822[6] = (char *(*)()) F576_2741;
	R1822[7] = (char *(*)()) F577_2741;
	R1822[8] = (char *(*)()) F578_2741;
	R1822[9] = (char *(*)()) F579_2741;
	R1822[10] = (char *(*)()) F580_2741;
	R1822[11] = (char *(*)()) F581_2741;
}

char *(*R1871[205])();
void R1871_init () {
	R1871[0] = (char *(*)()) F288_2161;
	R1871[1] = (char *(*)()) F289_2161;
	R1871[2] = (char *(*)()) F290_2161_1871_1;
	R1871[3] = (char *(*)()) F291_2161_1871_1;
	R1871[4] = (char *(*)()) F292_2161_1871_1;
	R1871[5] = (char *(*)()) F293_2161_1871_1;
	R1871[18] = (char *(*)()) F294_2167;
	R1871[19] = (char *(*)()) F295_2167_1871_1;
	R1871[20] = (char *(*)()) F296_2167_1871_1;
	R1871[21] = (char *(*)()) F297_2167_1871_1;
	R1871[22] = (char *(*)()) F298_2167_1871_1;
	R1871[23] = (char *(*)()) F299_2167_1871_1;
	R1871[24] = (char *(*)()) F300_2167_1871_1;
	R1871[25] = (char *(*)()) F301_2167_1871_1;
	R1871[26] = (char *(*)()) F302_2167_1871_1;
	R1871[27] = (char *(*)()) F303_2167_1871_1;
	R1871[28] = (char *(*)()) F304_2167_1871_1;
	R1871[29] = (char *(*)()) F305_2167_1871_1;
	R1871[30] = (char *(*)()) F296_2167_1871_1;
	R1871[31] = (char *(*)()) F304_2167_1871_1;
	R1871[32] = (char *(*)()) F294_2167;
	R1871[33] = (char *(*)()) F295_2167_1871_1;
	R1871[34] = (char *(*)()) F296_2167_1871_1;
	R1871[35] = (char *(*)()) F297_2167_1871_1;
	R1871[36] = (char *(*)()) F298_2167_1871_1;
	R1871[37] = (char *(*)()) F299_2167_1871_1;
	R1871[38] = (char *(*)()) F300_2167_1871_1;
	R1871[39] = (char *(*)()) F301_2167_1871_1;
	R1871[40] = (char *(*)()) F302_2167_1871_1;
	R1871[41] = (char *(*)()) F303_2167_1871_1;
	R1871[42] = (char *(*)()) F304_2167_1871_1;
	R1871[43] = (char *(*)()) F305_2167_1871_1;
	R1871[204] = (char *(*)()) F491_2321_1871_1;
}
static EIF_REFERENCE F290_2161_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F290_2161(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F291_2161_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F291_2161(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F292_2161_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F292_2161(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F293_2161_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F293_2161(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F295_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F295_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F296_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F296_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F297_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F297_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F298_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F298_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F299_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F299_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F300_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F300_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F301_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F301_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F302_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F302_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F303_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F303_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F304_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F304_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F305_2167_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F305_2167(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F491_2321_1871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F491_2321(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1872[205])();
void R1872_init () {
	R1872[0] = (char *(*)()) F288_2164;
	R1872[1] = (char *(*)()) F289_2164;
	R1872[2] = (char *(*)()) F290_2164;
	R1872[3] = (char *(*)()) F291_2164;
	R1872[4] = (char *(*)()) F292_2164;
	R1872[5] = (char *(*)()) F293_2164;
	R1872[18] = (char *(*)()) F294_2176;
	R1872[19] = (char *(*)()) F295_2176;
	R1872[20] = (char *(*)()) F296_2176;
	R1872[21] = (char *(*)()) F297_2176;
	R1872[22] = (char *(*)()) F298_2176;
	R1872[23] = (char *(*)()) F299_2176;
	R1872[24] = (char *(*)()) F300_2176;
	R1872[25] = (char *(*)()) F301_2176;
	R1872[26] = (char *(*)()) F302_2176;
	R1872[27] = (char *(*)()) F303_2176;
	R1872[28] = (char *(*)()) F304_2176;
	R1872[29] = (char *(*)()) F305_2176;
	R1872[30] = (char *(*)()) F296_2176;
	R1872[31] = (char *(*)()) F304_2176;
	R1872[32] = (char *(*)()) F294_2176;
	R1872[33] = (char *(*)()) F295_2176;
	R1872[34] = (char *(*)()) F296_2176;
	R1872[35] = (char *(*)()) F297_2176;
	R1872[36] = (char *(*)()) F298_2176;
	R1872[37] = (char *(*)()) F299_2176;
	R1872[38] = (char *(*)()) F300_2176;
	R1872[39] = (char *(*)()) F301_2176;
	R1872[40] = (char *(*)()) F302_2176;
	R1872[41] = (char *(*)()) F303_2176;
	R1872[42] = (char *(*)()) F304_2176;
	R1872[43] = (char *(*)()) F305_2176;
	R1872[204] = (char *(*)()) F491_2322;
}

char *(*R1873[205])();
void R1873_init () {
	R1873[0] = (char *(*)()) F288_2165;
	R1873[1] = (char *(*)()) F289_2165;
	R1873[2] = (char *(*)()) F290_2165;
	R1873[3] = (char *(*)()) F291_2165;
	R1873[4] = (char *(*)()) F292_2165;
	R1873[5] = (char *(*)()) F293_2165;
	R1873[18] = (char *(*)()) F294_2182;
	R1873[19] = (char *(*)()) F295_2182;
	R1873[20] = (char *(*)()) F296_2182;
	R1873[21] = (char *(*)()) F297_2182;
	R1873[22] = (char *(*)()) F298_2182;
	R1873[23] = (char *(*)()) F299_2182;
	R1873[24] = (char *(*)()) F300_2182;
	R1873[25] = (char *(*)()) F301_2182;
	R1873[26] = (char *(*)()) F302_2182;
	R1873[27] = (char *(*)()) F303_2182;
	R1873[28] = (char *(*)()) F304_2182;
	R1873[29] = (char *(*)()) F305_2182;
	R1873[30] = (char *(*)()) F296_2182;
	R1873[31] = (char *(*)()) F304_2182;
	R1873[32] = (char *(*)()) F294_2182;
	R1873[33] = (char *(*)()) F295_2182;
	R1873[34] = (char *(*)()) F296_2182;
	R1873[35] = (char *(*)()) F297_2182;
	R1873[36] = (char *(*)()) F298_2182;
	R1873[37] = (char *(*)()) F299_2182;
	R1873[38] = (char *(*)()) F300_2182;
	R1873[39] = (char *(*)()) F301_2182;
	R1873[40] = (char *(*)()) F302_2182;
	R1873[41] = (char *(*)()) F303_2182;
	R1873[42] = (char *(*)()) F304_2182;
	R1873[43] = (char *(*)()) F305_2182;
	R1873[204] = (char *(*)()) F491_2328;
}

char *(*R1884[6])();
void R1884_init () {
	R1884[0] = (char *(*)()) F288_2162;
	R1884[1] = (char *(*)()) F289_2162_1884_1;
	R1884[2] = (char *(*)()) F290_2162;
	R1884[3] = (char *(*)()) F291_2162;
	R1884[4] = (char *(*)()) F292_2162_1884_1;
	R1884[5] = (char *(*)()) F293_2162;
}
static EIF_REFERENCE F289_2162_1884_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F289_2162(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F292_2162_1884_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F292_2162(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1886[210])();
void R1886_init () {
	R1886[0] = (char *(*)()) F595_2825;
	R1886[1] = (char *(*)()) F596_2825;
	R1886[2] = (char *(*)()) F597_2825;
	R1886[3] = (char *(*)()) F598_2825;
	R1886[4] = (char *(*)()) F599_2825;
	R1886[5] = (char *(*)()) F600_2825;
	R1886[6] = (char *(*)()) F601_2825;
	R1886[7] = (char *(*)()) F602_2825;
	R1886[8] = (char *(*)()) F603_2825;
	R1886[9] = (char *(*)()) F604_2825;
	R1886[10] = (char *(*)()) F605_2825;
	R1886[11] = (char *(*)()) F606_2825;
	R1886[65] = (char *(*)()) F660_3028;
	R1886[66] = (char *(*)()) F661_3028;
	R1886[67] = (char *(*)()) F662_3028;
	R1886[68] = (char *(*)()) F663_3028;
	R1886[69] = (char *(*)()) F664_3028;
	R1886[70] = (char *(*)()) F665_3028;
	R1886[71] = (char *(*)()) F666_3028;
	R1886[72] = (char *(*)()) F667_3028;
	R1886[73] = (char *(*)()) F668_3028;
	R1886[74] = (char *(*)()) F669_3028;
	R1886[75] = (char *(*)()) F670_3028;
	R1886[76] = (char *(*)()) F671_3028;
	R1886[77] = (char *(*)()) F660_3028;
	R1886[78] = (char *(*)()) F673_3105;
	R1886[79] = (char *(*)()) F674_3105;
	R1886[80] = (char *(*)()) F675_3105;
	R1886[81] = (char *(*)()) F676_3105;
	R1886[82] = (char *(*)()) F677_3105;
	R1886[83] = (char *(*)()) F678_3105;
	R1886[84] = (char *(*)()) F673_3105;
	R1886[85] = (char *(*)()) F675_3105;
	R1886[86] = (char *(*)()) F678_3105;
	R1886[87] = (char *(*)()) F673_3105;
	{long i; for (i = 205; i < 207; i++) R1886[i] = (char *(*)()) F799_4725;}
	{long i; for (i = 208; i < 210; i++) R1886[i] = (char *(*)()) F802_4893;}
}

static EIF_TYPE_INDEX Y1887_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype12[] = {0xFF01,803,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype13[] = {0xFF01,799,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype14[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype89[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype90[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype263[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype326[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype327[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype328[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype365[] = {726,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype452[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype453[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype454[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype455[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype456[] = {753,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype457[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype458[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype459[] = {756,0xFFFF};
static EIF_TYPE_INDEX Y1887_pgtype460[] = {756,0xFFFF};
EIF_TYPE_INDEX *Y1887_gen_type [578];
EIF_TYPE_INDEX Y1887 [578];
void Y1887_init (void)
{
	egc_routines_types [1887] = Y1887;
	egc_routines_gen_types [1887] = Y1887_gen_type;
	egc_routines_offset [1887] = 228;
	Y1887_gen_type [0] = Y1887_pgtype0;
	Y1887_gen_type [1] = Y1887_pgtype1;
	Y1887_gen_type [2] = Y1887_pgtype2;
	Y1887_gen_type [3] = Y1887_pgtype3;
	Y1887_gen_type [4] = Y1887_pgtype4;
	Y1887_gen_type [5] = Y1887_pgtype5;
	Y1887_gen_type [6] = Y1887_pgtype6;
	Y1887_gen_type [7] = Y1887_pgtype7;
	Y1887_gen_type [8] = Y1887_pgtype8;
	Y1887_gen_type [9] = Y1887_pgtype9;
	Y1887_gen_type [10] = Y1887_pgtype10;
	Y1887_gen_type [11] = Y1887_pgtype11;
	Y1887_gen_type [12] = Y1887_pgtype12;
	Y1887_gen_type [13] = Y1887_pgtype13;
	Y1887_gen_type [14] = Y1887_pgtype14;
	Y1887_gen_type [15] = Y1887_pgtype15;
	Y1887_gen_type [16] = Y1887_pgtype16;
	Y1887_gen_type [17] = Y1887_pgtype17;
	Y1887_gen_type [18] = Y1887_pgtype18;
	Y1887_gen_type [19] = Y1887_pgtype19;
	Y1887_gen_type [20] = Y1887_pgtype20;
	Y1887_gen_type [21] = Y1887_pgtype21;
	Y1887_gen_type [22] = Y1887_pgtype22;
	Y1887_gen_type [23] = Y1887_pgtype23;
	Y1887_gen_type [24] = Y1887_pgtype24;
	Y1887_gen_type [25] = Y1887_pgtype25;
	Y1887_gen_type [26] = Y1887_pgtype26;
	Y1887_gen_type [27] = Y1887_pgtype27;
	Y1887_gen_type [28] = Y1887_pgtype28;
	Y1887_gen_type [29] = Y1887_pgtype29;
	Y1887_gen_type [30] = Y1887_pgtype30;
	Y1887_gen_type [31] = Y1887_pgtype31;
	Y1887_gen_type [32] = Y1887_pgtype32;
	Y1887_gen_type [33] = Y1887_pgtype33;
	Y1887_gen_type [34] = Y1887_pgtype34;
	Y1887_gen_type [35] = Y1887_pgtype35;
	Y1887_gen_type [36] = Y1887_pgtype36;
	Y1887_gen_type [37] = Y1887_pgtype37;
	Y1887_gen_type [38] = Y1887_pgtype38;
	Y1887_gen_type [39] = Y1887_pgtype39;
	Y1887_gen_type [40] = Y1887_pgtype40;
	Y1887_gen_type [41] = Y1887_pgtype41;
	Y1887_gen_type [42] = Y1887_pgtype42;
	Y1887_gen_type [43] = Y1887_pgtype43;
	Y1887_gen_type [44] = Y1887_pgtype44;
	Y1887_gen_type [45] = Y1887_pgtype45;
	Y1887_gen_type [46] = Y1887_pgtype46;
	Y1887_gen_type [47] = Y1887_pgtype47;
	Y1887_gen_type [48] = Y1887_pgtype48;
	Y1887_gen_type [49] = Y1887_pgtype49;
	Y1887_gen_type [50] = Y1887_pgtype50;
	Y1887_gen_type [51] = Y1887_pgtype51;
	Y1887_gen_type [52] = Y1887_pgtype52;
	Y1887_gen_type [53] = Y1887_pgtype53;
	Y1887_gen_type [54] = Y1887_pgtype54;
	Y1887_gen_type [55] = Y1887_pgtype55;
	Y1887_gen_type [56] = Y1887_pgtype56;
	Y1887_gen_type [57] = Y1887_pgtype57;
	Y1887_gen_type [58] = Y1887_pgtype58;
	Y1887_gen_type [59] = Y1887_pgtype59;
	Y1887_gen_type [60] = Y1887_pgtype60;
	Y1887_gen_type [61] = Y1887_pgtype61;
	Y1887_gen_type [62] = Y1887_pgtype62;
	Y1887_gen_type [63] = Y1887_pgtype63;
	Y1887_gen_type [64] = Y1887_pgtype64;
	Y1887_gen_type [65] = Y1887_pgtype65;
	Y1887_gen_type [66] = Y1887_pgtype66;
	Y1887_gen_type [67] = Y1887_pgtype67;
	Y1887_gen_type [68] = Y1887_pgtype68;
	Y1887_gen_type [69] = Y1887_pgtype69;
	Y1887_gen_type [70] = Y1887_pgtype70;
	Y1887_gen_type [71] = Y1887_pgtype71;
	Y1887_gen_type [72] = Y1887_pgtype72;
	Y1887_gen_type [73] = Y1887_pgtype73;
	Y1887_gen_type [74] = Y1887_pgtype74;
	Y1887_gen_type [75] = Y1887_pgtype75;
	Y1887_gen_type [76] = Y1887_pgtype76;
	Y1887_gen_type [77] = Y1887_pgtype77;
	Y1887_gen_type [78] = Y1887_pgtype78;
	Y1887_gen_type [79] = Y1887_pgtype79;
	Y1887_gen_type [80] = Y1887_pgtype80;
	Y1887_gen_type [81] = Y1887_pgtype81;
	Y1887_gen_type [82] = Y1887_pgtype82;
	Y1887_gen_type [83] = Y1887_pgtype83;
	Y1887_gen_type [84] = Y1887_pgtype84;
	Y1887_gen_type [85] = Y1887_pgtype85;
	Y1887_gen_type [86] = Y1887_pgtype86;
	Y1887_gen_type [87] = Y1887_pgtype87;
	Y1887_gen_type [88] = Y1887_pgtype88;
	Y1887_gen_type [89] = Y1887_pgtype89;
	Y1887_gen_type [90] = Y1887_pgtype90;
	Y1887_gen_type [91] = Y1887_pgtype91;
	Y1887_gen_type [92] = Y1887_pgtype92;
	Y1887_gen_type [93] = Y1887_pgtype93;
	Y1887_gen_type [94] = Y1887_pgtype94;
	Y1887_gen_type [95] = Y1887_pgtype95;
	Y1887_gen_type [96] = Y1887_pgtype96;
	Y1887_gen_type [97] = Y1887_pgtype97;
	Y1887_gen_type [98] = Y1887_pgtype98;
	Y1887_gen_type [99] = Y1887_pgtype99;
	Y1887_gen_type [100] = Y1887_pgtype100;
	Y1887_gen_type [101] = Y1887_pgtype101;
	Y1887_gen_type [102] = Y1887_pgtype102;
	Y1887_gen_type [103] = Y1887_pgtype103;
	Y1887_gen_type [104] = Y1887_pgtype104;
	Y1887_gen_type [105] = Y1887_pgtype105;
	Y1887_gen_type [106] = Y1887_pgtype106;
	Y1887_gen_type [107] = Y1887_pgtype107;
	Y1887_gen_type [108] = Y1887_pgtype108;
	Y1887_gen_type [109] = Y1887_pgtype109;
	Y1887_gen_type [110] = Y1887_pgtype110;
	Y1887_gen_type [111] = Y1887_pgtype111;
	Y1887_gen_type [112] = Y1887_pgtype112;
	Y1887_gen_type [113] = Y1887_pgtype113;
	Y1887_gen_type [114] = Y1887_pgtype114;
	Y1887_gen_type [115] = Y1887_pgtype115;
	Y1887_gen_type [116] = Y1887_pgtype116;
	Y1887_gen_type [117] = Y1887_pgtype117;
	Y1887_gen_type [118] = Y1887_pgtype118;
	Y1887_gen_type [119] = Y1887_pgtype119;
	Y1887_gen_type [120] = Y1887_pgtype120;
	Y1887_gen_type [121] = Y1887_pgtype121;
	Y1887_gen_type [122] = Y1887_pgtype122;
	Y1887_gen_type [123] = Y1887_pgtype123;
	Y1887_gen_type [124] = Y1887_pgtype124;
	Y1887_gen_type [125] = Y1887_pgtype125;
	Y1887_gen_type [126] = Y1887_pgtype126;
	Y1887_gen_type [127] = Y1887_pgtype127;
	Y1887_gen_type [128] = Y1887_pgtype128;
	Y1887_gen_type [129] = Y1887_pgtype129;
	Y1887_gen_type [130] = Y1887_pgtype130;
	Y1887_gen_type [131] = Y1887_pgtype131;
	Y1887_gen_type [132] = Y1887_pgtype132;
	Y1887_gen_type [133] = Y1887_pgtype133;
	Y1887_gen_type [134] = Y1887_pgtype134;
	Y1887_gen_type [135] = Y1887_pgtype135;
	Y1887_gen_type [136] = Y1887_pgtype136;
	Y1887_gen_type [137] = Y1887_pgtype137;
	Y1887_gen_type [138] = Y1887_pgtype138;
	Y1887_gen_type [139] = Y1887_pgtype139;
	Y1887_gen_type [140] = Y1887_pgtype140;
	Y1887_gen_type [141] = Y1887_pgtype141;
	Y1887_gen_type [142] = Y1887_pgtype142;
	Y1887_gen_type [143] = Y1887_pgtype143;
	Y1887_gen_type [144] = Y1887_pgtype144;
	Y1887_gen_type [145] = Y1887_pgtype145;
	Y1887_gen_type [146] = Y1887_pgtype146;
	Y1887_gen_type [147] = Y1887_pgtype147;
	Y1887_gen_type [148] = Y1887_pgtype148;
	Y1887_gen_type [149] = Y1887_pgtype149;
	Y1887_gen_type [150] = Y1887_pgtype150;
	Y1887_gen_type [151] = Y1887_pgtype151;
	Y1887_gen_type [152] = Y1887_pgtype152;
	Y1887_gen_type [153] = Y1887_pgtype153;
	Y1887_gen_type [154] = Y1887_pgtype154;
	Y1887_gen_type [155] = Y1887_pgtype155;
	Y1887_gen_type [156] = Y1887_pgtype156;
	Y1887_gen_type [157] = Y1887_pgtype157;
	Y1887_gen_type [158] = Y1887_pgtype158;
	Y1887_gen_type [159] = Y1887_pgtype159;
	Y1887_gen_type [160] = Y1887_pgtype160;
	Y1887_gen_type [161] = Y1887_pgtype161;
	Y1887_gen_type [162] = Y1887_pgtype162;
	Y1887_gen_type [163] = Y1887_pgtype163;
	Y1887_gen_type [164] = Y1887_pgtype164;
	Y1887_gen_type [165] = Y1887_pgtype165;
	Y1887_gen_type [166] = Y1887_pgtype166;
	Y1887_gen_type [167] = Y1887_pgtype167;
	Y1887_gen_type [168] = Y1887_pgtype168;
	Y1887_gen_type [169] = Y1887_pgtype169;
	Y1887_gen_type [170] = Y1887_pgtype170;
	Y1887_gen_type [171] = Y1887_pgtype171;
	Y1887_gen_type [172] = Y1887_pgtype172;
	Y1887_gen_type [173] = Y1887_pgtype173;
	Y1887_gen_type [174] = Y1887_pgtype174;
	Y1887_gen_type [175] = Y1887_pgtype175;
	Y1887_gen_type [176] = Y1887_pgtype176;
	Y1887_gen_type [177] = Y1887_pgtype177;
	Y1887_gen_type [178] = Y1887_pgtype178;
	Y1887_gen_type [179] = Y1887_pgtype179;
	Y1887_gen_type [180] = Y1887_pgtype180;
	Y1887_gen_type [181] = Y1887_pgtype181;
	Y1887_gen_type [182] = Y1887_pgtype182;
	Y1887_gen_type [183] = Y1887_pgtype183;
	Y1887_gen_type [184] = Y1887_pgtype184;
	Y1887_gen_type [185] = Y1887_pgtype185;
	Y1887_gen_type [186] = Y1887_pgtype186;
	Y1887_gen_type [187] = Y1887_pgtype187;
	Y1887_gen_type [188] = Y1887_pgtype188;
	Y1887_gen_type [189] = Y1887_pgtype189;
	Y1887_gen_type [190] = Y1887_pgtype190;
	Y1887_gen_type [191] = Y1887_pgtype191;
	Y1887_gen_type [192] = Y1887_pgtype192;
	Y1887_gen_type [193] = Y1887_pgtype193;
	Y1887_gen_type [194] = Y1887_pgtype194;
	Y1887_gen_type [195] = Y1887_pgtype195;
	Y1887_gen_type [196] = Y1887_pgtype196;
	Y1887_gen_type [197] = Y1887_pgtype197;
	Y1887_gen_type [198] = Y1887_pgtype198;
	Y1887_gen_type [199] = Y1887_pgtype199;
	Y1887_gen_type [200] = Y1887_pgtype200;
	Y1887_gen_type [201] = Y1887_pgtype201;
	Y1887_gen_type [202] = Y1887_pgtype202;
	Y1887_gen_type [203] = Y1887_pgtype203;
	Y1887_gen_type [204] = Y1887_pgtype204;
	Y1887_gen_type [205] = Y1887_pgtype205;
	Y1887_gen_type [206] = Y1887_pgtype206;
	Y1887_gen_type [207] = Y1887_pgtype207;
	Y1887_gen_type [208] = Y1887_pgtype208;
	Y1887_gen_type [209] = Y1887_pgtype209;
	Y1887_gen_type [210] = Y1887_pgtype210;
	Y1887_gen_type [211] = Y1887_pgtype211;
	Y1887_gen_type [212] = Y1887_pgtype212;
	Y1887_gen_type [213] = Y1887_pgtype213;
	Y1887_gen_type [214] = Y1887_pgtype214;
	Y1887_gen_type [215] = Y1887_pgtype215;
	Y1887_gen_type [216] = Y1887_pgtype216;
	Y1887_gen_type [217] = Y1887_pgtype217;
	Y1887_gen_type [218] = Y1887_pgtype218;
	Y1887_gen_type [219] = Y1887_pgtype219;
	Y1887_gen_type [220] = Y1887_pgtype220;
	Y1887_gen_type [221] = Y1887_pgtype221;
	Y1887_gen_type [222] = Y1887_pgtype222;
	Y1887_gen_type [223] = Y1887_pgtype223;
	Y1887_gen_type [224] = Y1887_pgtype224;
	Y1887_gen_type [225] = Y1887_pgtype225;
	Y1887_gen_type [226] = Y1887_pgtype226;
	Y1887_gen_type [227] = Y1887_pgtype227;
	Y1887_gen_type [228] = Y1887_pgtype228;
	Y1887_gen_type [229] = Y1887_pgtype229;
	Y1887_gen_type [230] = Y1887_pgtype230;
	Y1887_gen_type [231] = Y1887_pgtype231;
	Y1887_gen_type [232] = Y1887_pgtype232;
	Y1887_gen_type [233] = Y1887_pgtype233;
	Y1887_gen_type [234] = Y1887_pgtype234;
	Y1887_gen_type [235] = Y1887_pgtype235;
	Y1887_gen_type [236] = Y1887_pgtype236;
	Y1887_gen_type [237] = Y1887_pgtype237;
	Y1887_gen_type [238] = Y1887_pgtype238;
	Y1887_gen_type [239] = Y1887_pgtype239;
	Y1887_gen_type [240] = Y1887_pgtype240;
	Y1887_gen_type [241] = Y1887_pgtype241;
	Y1887_gen_type [242] = Y1887_pgtype242;
	Y1887_gen_type [243] = Y1887_pgtype243;
	Y1887_gen_type [244] = Y1887_pgtype244;
	Y1887_gen_type [245] = Y1887_pgtype245;
	Y1887_gen_type [246] = Y1887_pgtype246;
	Y1887_gen_type [247] = Y1887_pgtype247;
	Y1887_gen_type [248] = Y1887_pgtype248;
	Y1887_gen_type [249] = Y1887_pgtype249;
	Y1887_gen_type [250] = Y1887_pgtype250;
	Y1887_gen_type [251] = Y1887_pgtype251;
	Y1887_gen_type [252] = Y1887_pgtype252;
	Y1887_gen_type [253] = Y1887_pgtype253;
	Y1887_gen_type [254] = Y1887_pgtype254;
	Y1887_gen_type [255] = Y1887_pgtype255;
	Y1887_gen_type [256] = Y1887_pgtype256;
	Y1887_gen_type [257] = Y1887_pgtype257;
	Y1887_gen_type [258] = Y1887_pgtype258;
	Y1887_gen_type [259] = Y1887_pgtype259;
	Y1887_gen_type [260] = Y1887_pgtype260;
	Y1887_gen_type [261] = Y1887_pgtype261;
	Y1887_gen_type [262] = Y1887_pgtype262;
	Y1887_gen_type [263] = Y1887_pgtype263;
	Y1887_gen_type [264] = Y1887_pgtype264;
	Y1887_gen_type [265] = Y1887_pgtype265;
	Y1887_gen_type [266] = Y1887_pgtype266;
	Y1887_gen_type [267] = Y1887_pgtype267;
	Y1887_gen_type [268] = Y1887_pgtype268;
	Y1887_gen_type [269] = Y1887_pgtype269;
	Y1887_gen_type [270] = Y1887_pgtype270;
	Y1887_gen_type [271] = Y1887_pgtype271;
	Y1887_gen_type [272] = Y1887_pgtype272;
	Y1887_gen_type [273] = Y1887_pgtype273;
	Y1887_gen_type [274] = Y1887_pgtype274;
	Y1887_gen_type [275] = Y1887_pgtype275;
	Y1887_gen_type [276] = Y1887_pgtype276;
	Y1887_gen_type [277] = Y1887_pgtype277;
	Y1887_gen_type [278] = Y1887_pgtype278;
	Y1887_gen_type [279] = Y1887_pgtype279;
	Y1887_gen_type [280] = Y1887_pgtype280;
	Y1887_gen_type [281] = Y1887_pgtype281;
	Y1887_gen_type [282] = Y1887_pgtype282;
	Y1887_gen_type [283] = Y1887_pgtype283;
	Y1887_gen_type [284] = Y1887_pgtype284;
	Y1887_gen_type [285] = Y1887_pgtype285;
	Y1887_gen_type [286] = Y1887_pgtype286;
	Y1887_gen_type [287] = Y1887_pgtype287;
	Y1887_gen_type [288] = Y1887_pgtype288;
	Y1887_gen_type [289] = Y1887_pgtype289;
	Y1887_gen_type [290] = Y1887_pgtype290;
	Y1887_gen_type [291] = Y1887_pgtype291;
	Y1887_gen_type [292] = Y1887_pgtype292;
	Y1887_gen_type [293] = Y1887_pgtype293;
	Y1887_gen_type [294] = Y1887_pgtype294;
	Y1887_gen_type [295] = Y1887_pgtype295;
	Y1887_gen_type [296] = Y1887_pgtype296;
	Y1887_gen_type [297] = Y1887_pgtype297;
	Y1887_gen_type [298] = Y1887_pgtype298;
	Y1887_gen_type [299] = Y1887_pgtype299;
	Y1887_gen_type [300] = Y1887_pgtype300;
	Y1887_gen_type [301] = Y1887_pgtype301;
	Y1887_gen_type [302] = Y1887_pgtype302;
	Y1887_gen_type [303] = Y1887_pgtype303;
	Y1887_gen_type [304] = Y1887_pgtype304;
	Y1887_gen_type [305] = Y1887_pgtype305;
	Y1887_gen_type [306] = Y1887_pgtype306;
	Y1887_gen_type [307] = Y1887_pgtype307;
	Y1887_gen_type [308] = Y1887_pgtype308;
	Y1887_gen_type [309] = Y1887_pgtype309;
	Y1887_gen_type [310] = Y1887_pgtype310;
	Y1887_gen_type [311] = Y1887_pgtype311;
	Y1887_gen_type [312] = Y1887_pgtype312;
	Y1887_gen_type [313] = Y1887_pgtype313;
	Y1887_gen_type [314] = Y1887_pgtype314;
	Y1887_gen_type [315] = Y1887_pgtype315;
	Y1887_gen_type [316] = Y1887_pgtype316;
	Y1887_gen_type [317] = Y1887_pgtype317;
	Y1887_gen_type [318] = Y1887_pgtype318;
	Y1887_gen_type [319] = Y1887_pgtype319;
	Y1887_gen_type [320] = Y1887_pgtype320;
	Y1887_gen_type [321] = Y1887_pgtype321;
	Y1887_gen_type [322] = Y1887_pgtype322;
	Y1887_gen_type [323] = Y1887_pgtype323;
	Y1887_gen_type [324] = Y1887_pgtype324;
	Y1887_gen_type [325] = Y1887_pgtype325;
	Y1887_gen_type [326] = Y1887_pgtype326;
	Y1887_gen_type [327] = Y1887_pgtype327;
	Y1887_gen_type [328] = Y1887_pgtype328;
	Y1887_gen_type [329] = Y1887_pgtype329;
	Y1887_gen_type [330] = Y1887_pgtype330;
	Y1887_gen_type [331] = Y1887_pgtype331;
	Y1887_gen_type [332] = Y1887_pgtype332;
	Y1887_gen_type [333] = Y1887_pgtype333;
	Y1887_gen_type [334] = Y1887_pgtype334;
	Y1887_gen_type [335] = Y1887_pgtype335;
	Y1887_gen_type [336] = Y1887_pgtype336;
	Y1887_gen_type [337] = Y1887_pgtype337;
	Y1887_gen_type [338] = Y1887_pgtype338;
	Y1887_gen_type [339] = Y1887_pgtype339;
	Y1887_gen_type [340] = Y1887_pgtype340;
	Y1887_gen_type [341] = Y1887_pgtype341;
	Y1887_gen_type [342] = Y1887_pgtype342;
	Y1887_gen_type [343] = Y1887_pgtype343;
	Y1887_gen_type [344] = Y1887_pgtype344;
	Y1887_gen_type [345] = Y1887_pgtype345;
	Y1887_gen_type [346] = Y1887_pgtype346;
	Y1887_gen_type [347] = Y1887_pgtype347;
	Y1887_gen_type [348] = Y1887_pgtype348;
	Y1887_gen_type [349] = Y1887_pgtype349;
	Y1887_gen_type [350] = Y1887_pgtype350;
	Y1887_gen_type [351] = Y1887_pgtype351;
	Y1887_gen_type [352] = Y1887_pgtype352;
	Y1887_gen_type [353] = Y1887_pgtype353;
	Y1887_gen_type [354] = Y1887_pgtype354;
	Y1887_gen_type [355] = Y1887_pgtype355;
	Y1887_gen_type [356] = Y1887_pgtype356;
	Y1887_gen_type [357] = Y1887_pgtype357;
	Y1887_gen_type [358] = Y1887_pgtype358;
	Y1887_gen_type [359] = Y1887_pgtype359;
	Y1887_gen_type [360] = Y1887_pgtype360;
	Y1887_gen_type [361] = Y1887_pgtype361;
	Y1887_gen_type [362] = Y1887_pgtype362;
	Y1887_gen_type [363] = Y1887_pgtype363;
	Y1887_gen_type [364] = Y1887_pgtype364;
	Y1887_gen_type [365] = Y1887_pgtype365;
	Y1887_gen_type [366] = Y1887_pgtype366;
	Y1887_gen_type [367] = Y1887_pgtype367;
	Y1887_gen_type [368] = Y1887_pgtype368;
	Y1887_gen_type [369] = Y1887_pgtype369;
	Y1887_gen_type [370] = Y1887_pgtype370;
	Y1887_gen_type [371] = Y1887_pgtype371;
	Y1887_gen_type [372] = Y1887_pgtype372;
	Y1887_gen_type [373] = Y1887_pgtype373;
	Y1887_gen_type [374] = Y1887_pgtype374;
	Y1887_gen_type [375] = Y1887_pgtype375;
	Y1887_gen_type [376] = Y1887_pgtype376;
	Y1887_gen_type [377] = Y1887_pgtype377;
	Y1887_gen_type [378] = Y1887_pgtype378;
	Y1887_gen_type [379] = Y1887_pgtype379;
	Y1887_gen_type [380] = Y1887_pgtype380;
	Y1887_gen_type [381] = Y1887_pgtype381;
	Y1887_gen_type [382] = Y1887_pgtype382;
	Y1887_gen_type [383] = Y1887_pgtype383;
	Y1887_gen_type [384] = Y1887_pgtype384;
	Y1887_gen_type [385] = Y1887_pgtype385;
	Y1887_gen_type [386] = Y1887_pgtype386;
	Y1887_gen_type [387] = Y1887_pgtype387;
	Y1887_gen_type [388] = Y1887_pgtype388;
	Y1887_gen_type [389] = Y1887_pgtype389;
	Y1887_gen_type [390] = Y1887_pgtype390;
	Y1887_gen_type [391] = Y1887_pgtype391;
	Y1887_gen_type [392] = Y1887_pgtype392;
	Y1887_gen_type [393] = Y1887_pgtype393;
	Y1887_gen_type [394] = Y1887_pgtype394;
	Y1887_gen_type [395] = Y1887_pgtype395;
	Y1887_gen_type [396] = Y1887_pgtype396;
	Y1887_gen_type [397] = Y1887_pgtype397;
	Y1887_gen_type [398] = Y1887_pgtype398;
	Y1887_gen_type [399] = Y1887_pgtype399;
	Y1887_gen_type [400] = Y1887_pgtype400;
	Y1887_gen_type [401] = Y1887_pgtype401;
	Y1887_gen_type [402] = Y1887_pgtype402;
	Y1887_gen_type [403] = Y1887_pgtype403;
	Y1887_gen_type [404] = Y1887_pgtype404;
	Y1887_gen_type [405] = Y1887_pgtype405;
	Y1887_gen_type [406] = Y1887_pgtype406;
	Y1887_gen_type [407] = Y1887_pgtype407;
	Y1887_gen_type [408] = Y1887_pgtype408;
	Y1887_gen_type [409] = Y1887_pgtype409;
	Y1887_gen_type [410] = Y1887_pgtype410;
	Y1887_gen_type [411] = Y1887_pgtype411;
	Y1887_gen_type [412] = Y1887_pgtype412;
	Y1887_gen_type [413] = Y1887_pgtype413;
	Y1887_gen_type [414] = Y1887_pgtype414;
	Y1887_gen_type [415] = Y1887_pgtype415;
	Y1887_gen_type [416] = Y1887_pgtype416;
	Y1887_gen_type [417] = Y1887_pgtype417;
	Y1887_gen_type [418] = Y1887_pgtype418;
	Y1887_gen_type [419] = Y1887_pgtype419;
	Y1887_gen_type [420] = Y1887_pgtype420;
	Y1887_gen_type [421] = Y1887_pgtype421;
	Y1887_gen_type [422] = Y1887_pgtype422;
	Y1887_gen_type [423] = Y1887_pgtype423;
	Y1887_gen_type [424] = Y1887_pgtype424;
	Y1887_gen_type [425] = Y1887_pgtype425;
	Y1887_gen_type [426] = Y1887_pgtype426;
	Y1887_gen_type [427] = Y1887_pgtype427;
	Y1887_gen_type [428] = Y1887_pgtype428;
	Y1887_gen_type [430] = Y1887_pgtype429;
	Y1887_gen_type [431] = Y1887_pgtype430;
	Y1887_gen_type [432] = Y1887_pgtype431;
	Y1887_gen_type [433] = Y1887_pgtype432;
	Y1887_gen_type [434] = Y1887_pgtype433;
	Y1887_gen_type [435] = Y1887_pgtype434;
	Y1887_gen_type [436] = Y1887_pgtype435;
	Y1887_gen_type [437] = Y1887_pgtype436;
	Y1887_gen_type [438] = Y1887_pgtype437;
	Y1887_gen_type [439] = Y1887_pgtype438;
	Y1887_gen_type [440] = Y1887_pgtype439;
	Y1887_gen_type [441] = Y1887_pgtype440;
	Y1887_gen_type [442] = Y1887_pgtype441;
	Y1887_gen_type [443] = Y1887_pgtype442;
	Y1887_gen_type [444] = Y1887_pgtype443;
	Y1887_gen_type [445] = Y1887_pgtype444;
	Y1887_gen_type [446] = Y1887_pgtype445;
	Y1887_gen_type [447] = Y1887_pgtype446;
	Y1887_gen_type [448] = Y1887_pgtype447;
	Y1887_gen_type [449] = Y1887_pgtype448;
	Y1887_gen_type [450] = Y1887_pgtype449;
	Y1887_gen_type [451] = Y1887_pgtype450;
	Y1887_gen_type [452] = Y1887_pgtype451;
	Y1887_gen_type [453] = Y1887_pgtype452;
	Y1887_gen_type [487] = Y1887_pgtype453;
	Y1887_gen_type [570] = Y1887_pgtype454;
	Y1887_gen_type [571] = Y1887_pgtype455;
	Y1887_gen_type [572] = Y1887_pgtype456;
	Y1887_gen_type [573] = Y1887_pgtype457;
	Y1887_gen_type [574] = Y1887_pgtype458;
	Y1887_gen_type [575] = Y1887_pgtype459;
	Y1887_gen_type [577] = Y1887_pgtype460;
	Y1887[12] = 803;
	Y1887[13] = 799;
	Y1887[14] = 753;
	Y1887[89] = 753;
	Y1887[90] = 756;
	Y1887[263] = 726;
	{long i; for (i = 326; i < 329; i++) Y1887[i] = 756;};
	Y1887[365] = 726;
	Y1887[453] = 0;
	Y1887[487] = 0;
	{long i; for (i = 570; i < 573; i++) Y1887[i] = 753;};
	{long i; for (i = 573; i < 576; i++) Y1887[i] = 756;};
	Y1887[577] = 756;
}

char *(*R1949[6])();
void R1949_init () {
	{long i; for (i = 0; i < 2; i++) R1949[i] = (char *(*)()) F274_2147;}
	R1949[2] = (char *(*)()) F275_2147;
	R1949[3] = (char *(*)()) F277_2147;
	R1949[4] = (char *(*)()) F275_2147;
	R1949[5] = (char *(*)()) F282_2147;
}

char *(*R1951[44])();
void R1951_init () {
	{long i; for (i = 0; i < 2; i++) R1951[i] = (char *(*)()) F274_2149;}
	R1951[2] = (char *(*)()) F275_2149;
	R1951[3] = (char *(*)()) F277_2149;
	R1951[4] = (char *(*)()) F275_2149;
	R1951[5] = (char *(*)()) F282_2149;
	R1951[18] = (char *(*)()) F294_2180;
	R1951[19] = (char *(*)()) F295_2180;
	R1951[20] = (char *(*)()) F296_2180;
	R1951[21] = (char *(*)()) F297_2180;
	R1951[22] = (char *(*)()) F298_2180;
	R1951[23] = (char *(*)()) F299_2180;
	R1951[24] = (char *(*)()) F300_2180;
	R1951[25] = (char *(*)()) F301_2180;
	R1951[26] = (char *(*)()) F302_2180;
	R1951[27] = (char *(*)()) F303_2180;
	R1951[28] = (char *(*)()) F304_2180;
	R1951[29] = (char *(*)()) F305_2180;
	R1951[30] = (char *(*)()) F296_2180;
	R1951[31] = (char *(*)()) F304_2180;
	R1951[32] = (char *(*)()) F294_2180;
	R1951[33] = (char *(*)()) F295_2180;
	R1951[34] = (char *(*)()) F296_2180;
	R1951[35] = (char *(*)()) F297_2180;
	R1951[36] = (char *(*)()) F298_2180;
	R1951[37] = (char *(*)()) F299_2180;
	R1951[38] = (char *(*)()) F300_2180;
	R1951[39] = (char *(*)()) F301_2180;
	R1951[40] = (char *(*)()) F302_2180;
	R1951[41] = (char *(*)()) F303_2180;
	R1951[42] = (char *(*)()) F304_2180;
	R1951[43] = (char *(*)()) F305_2180;
}

char *(*R1952[6])();
void R1952_init () {
	{long i; for (i = 0; i < 2; i++) R1952[i] = (char *(*)()) F274_2152;}
	R1952[2] = (char *(*)()) F275_2152;
	R1952[3] = (char *(*)()) F277_2152;
	R1952[4] = (char *(*)()) F275_2152;
	R1952[5] = (char *(*)()) F282_2152;
}

char *(*R1955[6])();
void R1955_init () {
	{long i; for (i = 0; i < 2; i++) R1955[i] = (char *(*)()) F274_2133;}
	R1955[2] = (char *(*)()) F275_2133;
	R1955[3] = (char *(*)()) F277_2133;
	R1955[4] = (char *(*)()) F275_2133;
	R1955[5] = (char *(*)()) F282_2133;
}

char *(*R1970[12])();
void R1970_init () {
	R1970[0] = (char *(*)()) F306_2187;
	R1970[1] = (char *(*)()) F307_2187;
	R1970[2] = (char *(*)()) F308_2187;
	R1970[3] = (char *(*)()) F309_2187;
	R1970[4] = (char *(*)()) F310_2187;
	R1970[5] = (char *(*)()) F311_2187;
	R1970[6] = (char *(*)()) F312_2187;
	R1970[7] = (char *(*)()) F313_2187;
	R1970[8] = (char *(*)()) F314_2187;
	R1970[9] = (char *(*)()) F315_2187;
	R1970[10] = (char *(*)()) F316_2187;
	R1970[11] = (char *(*)()) F317_2187;
}

char *(*R1978[12])();
void R1978_init () {
	R1978[0] = (char *(*)()) F320_2205;
	R1978[1] = (char *(*)()) F321_2205;
	R1978[2] = (char *(*)()) F322_2205;
	R1978[3] = (char *(*)()) F323_2205;
	R1978[4] = (char *(*)()) F324_2205;
	R1978[5] = (char *(*)()) F325_2205;
	R1978[6] = (char *(*)()) F326_2205;
	R1978[7] = (char *(*)()) F327_2205;
	R1978[8] = (char *(*)()) F328_2205;
	R1978[9] = (char *(*)()) F329_2205;
	R1978[10] = (char *(*)()) F330_2205;
	R1978[11] = (char *(*)()) F331_2205;
}

char *(*R1983[315])();
void R1983_init () {
	R1983[0] = (char *(*)()) F489_2317;
	R1983[103] = (char *(*)()) F493_2350;
	R1983[104] = (char *(*)()) F494_2350;
	R1983[105] = (char *(*)()) F495_2350;
	R1983[106] = (char *(*)()) F496_2350;
	R1983[107] = (char *(*)()) F497_2350;
	R1983[108] = (char *(*)()) F498_2350;
	R1983[109] = (char *(*)()) F499_2350;
	R1983[110] = (char *(*)()) F500_2350;
	R1983[111] = (char *(*)()) F501_2350;
	R1983[112] = (char *(*)()) F502_2350;
	R1983[113] = (char *(*)()) F503_2350;
	R1983[114] = (char *(*)()) F504_2350;
	R1983[168] = (char *(*)()) F493_2350;
	R1983[169] = (char *(*)()) F494_2350;
	R1983[170] = (char *(*)()) F495_2350;
	R1983[171] = (char *(*)()) F496_2350;
	R1983[172] = (char *(*)()) F497_2350;
	R1983[173] = (char *(*)()) F498_2350;
	R1983[174] = (char *(*)()) F499_2350;
	R1983[175] = (char *(*)()) F500_2350;
	R1983[176] = (char *(*)()) F501_2350;
	R1983[177] = (char *(*)()) F502_2350;
	R1983[178] = (char *(*)()) F503_2350;
	R1983[179] = (char *(*)()) F504_2350;
	{long i; for (i = 180; i < 183; i++) R1983[i] = (char *(*)()) F493_2350;}
	R1983[183] = (char *(*)()) F494_2350;
	R1983[184] = (char *(*)()) F496_2350;
	R1983[185] = (char *(*)()) F494_2350;
	R1983[186] = (char *(*)()) F501_2350;
	R1983[187] = (char *(*)()) F493_2350;
	R1983[188] = (char *(*)()) F494_2350;
	R1983[189] = (char *(*)()) F501_2350;
	R1983[190] = (char *(*)()) F493_2350;
	R1983[309] = (char *(*)()) F495_2350;
	R1983[312] = (char *(*)()) F503_2350;
	R1983[314] = (char *(*)()) F806_5087;
}

char *(*R1987[315])();
void R1987_init () {
	R1987[0] = (char *(*)()) F345_2220;
	R1987[103] = (char *(*)()) F344_2220;
	R1987[104] = (char *(*)()) F345_2220;
	R1987[105] = (char *(*)()) F346_2220;
	R1987[106] = (char *(*)()) F347_2220;
	R1987[107] = (char *(*)()) F348_2220;
	R1987[108] = (char *(*)()) F349_2220;
	R1987[109] = (char *(*)()) F350_2220;
	R1987[110] = (char *(*)()) F351_2220;
	R1987[111] = (char *(*)()) F352_2220;
	R1987[112] = (char *(*)()) F353_2220;
	R1987[113] = (char *(*)()) F354_2220;
	R1987[114] = (char *(*)()) F355_2220;
	R1987[168] = (char *(*)()) F344_2220;
	R1987[169] = (char *(*)()) F345_2220;
	R1987[170] = (char *(*)()) F346_2220;
	R1987[171] = (char *(*)()) F347_2220;
	R1987[172] = (char *(*)()) F348_2220;
	R1987[173] = (char *(*)()) F349_2220;
	R1987[174] = (char *(*)()) F350_2220;
	R1987[175] = (char *(*)()) F351_2220;
	R1987[176] = (char *(*)()) F352_2220;
	R1987[177] = (char *(*)()) F353_2220;
	R1987[178] = (char *(*)()) F354_2220;
	R1987[179] = (char *(*)()) F355_2220;
	{long i; for (i = 180; i < 183; i++) R1987[i] = (char *(*)()) F344_2220;}
	R1987[183] = (char *(*)()) F345_2220;
	R1987[184] = (char *(*)()) F347_2220;
	R1987[185] = (char *(*)()) F345_2220;
	R1987[186] = (char *(*)()) F352_2220;
	R1987[187] = (char *(*)()) F344_2220;
	R1987[188] = (char *(*)()) F345_2220;
	R1987[189] = (char *(*)()) F352_2220;
	R1987[190] = (char *(*)()) F344_2220;
	R1987[309] = (char *(*)()) F346_2220;
	R1987[312] = (char *(*)()) F354_2220;
	R1987[314] = (char *(*)()) F354_2220;
}

char *(*R1991[315])();
void R1991_init () {
	R1991[0] = (char *(*)()) F491_2321_1991_1;
	R1991[168] = (char *(*)()) F660_3019;
	R1991[169] = (char *(*)()) F661_3019_1991_1;
	R1991[170] = (char *(*)()) F662_3019_1991_1;
	R1991[171] = (char *(*)()) F663_3019_1991_1;
	R1991[172] = (char *(*)()) F664_3019_1991_1;
	R1991[173] = (char *(*)()) F665_3019_1991_1;
	R1991[174] = (char *(*)()) F666_3019_1991_1;
	R1991[175] = (char *(*)()) F667_3019_1991_1;
	R1991[176] = (char *(*)()) F668_3019_1991_1;
	R1991[177] = (char *(*)()) F669_3019_1991_1;
	R1991[178] = (char *(*)()) F670_3019_1991_1;
	R1991[179] = (char *(*)()) F671_3019_1991_1;
	R1991[180] = (char *(*)()) F660_3019;
	R1991[314] = (char *(*)()) F555_2388_1991_1;
}
static EIF_REFERENCE F491_2321_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F491_2321(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F661_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F662_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F663_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F664_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F665_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F669_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F670_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3019_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F671_3019(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F555_2388_1991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F555_2388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1992[315])();
void R1992_init () {
	R1992[0] = (char *(*)()) F369_2239;
	R1992[168] = (char *(*)()) F607_2889;
	R1992[169] = (char *(*)()) F608_2889;
	R1992[170] = (char *(*)()) F609_2889;
	R1992[171] = (char *(*)()) F610_2889;
	R1992[172] = (char *(*)()) F611_2889;
	R1992[173] = (char *(*)()) F612_2889;
	R1992[174] = (char *(*)()) F613_2889;
	R1992[175] = (char *(*)()) F614_2889;
	R1992[176] = (char *(*)()) F615_2889;
	R1992[177] = (char *(*)()) F616_2889;
	R1992[178] = (char *(*)()) F617_2889;
	R1992[179] = (char *(*)()) F618_2889;
	R1992[180] = (char *(*)()) F607_2889;
	R1992[314] = (char *(*)()) F555_2409;
}

char *(*R1993[147])();
void R1993_init () {
	R1993[0] = (char *(*)()) F660_3045;
	R1993[1] = (char *(*)()) F661_3045;
	R1993[2] = (char *(*)()) F662_3045;
	R1993[3] = (char *(*)()) F663_3045;
	R1993[4] = (char *(*)()) F664_3045;
	R1993[5] = (char *(*)()) F665_3045;
	R1993[6] = (char *(*)()) F666_3045;
	R1993[7] = (char *(*)()) F667_3045;
	R1993[8] = (char *(*)()) F668_3045;
	R1993[9] = (char *(*)()) F669_3045;
	R1993[10] = (char *(*)()) F670_3045;
	R1993[11] = (char *(*)()) F671_3045;
	R1993[12] = (char *(*)()) F660_3045;
	R1993[146] = (char *(*)()) F555_2464;
}

char *(*R2000[181])();
void R2000_init () {
	R2000[0] = (char *(*)()) F491_2320;
	R2000[168] = (char *(*)()) F660_3024;
	R2000[169] = (char *(*)()) F661_3024;
	R2000[170] = (char *(*)()) F662_3024;
	R2000[171] = (char *(*)()) F663_3024;
	R2000[172] = (char *(*)()) F664_3024;
	R2000[173] = (char *(*)()) F665_3024;
	R2000[174] = (char *(*)()) F666_3024;
	R2000[175] = (char *(*)()) F667_3024;
	R2000[176] = (char *(*)()) F668_3024;
	R2000[177] = (char *(*)()) F669_3024;
	R2000[178] = (char *(*)()) F670_3024;
	R2000[179] = (char *(*)()) F671_3024;
	R2000[180] = (char *(*)()) F660_3024;
}

char *(*R2003[315])();
void R2003_init () {
	R2003[0] = (char *(*)()) F369_2237;
	R2003[168] = (char *(*)()) F368_2237;
	R2003[169] = (char *(*)()) F369_2237;
	R2003[170] = (char *(*)()) F370_2237;
	R2003[171] = (char *(*)()) F371_2237;
	R2003[172] = (char *(*)()) F372_2237;
	R2003[173] = (char *(*)()) F373_2237;
	R2003[174] = (char *(*)()) F374_2237;
	R2003[175] = (char *(*)()) F375_2237;
	R2003[176] = (char *(*)()) F376_2237;
	R2003[177] = (char *(*)()) F377_2237;
	R2003[178] = (char *(*)()) F378_2237;
	R2003[179] = (char *(*)()) F379_2237;
	R2003[180] = (char *(*)()) F368_2237;
	R2003[314] = (char *(*)()) F378_2237;
}

char *(*R2004[315])();
void R2004_init () {
	R2004[0] = (char *(*)()) F491_2322;
	R2004[168] = (char *(*)()) F631_2913;
	R2004[169] = (char *(*)()) F632_2913;
	R2004[170] = (char *(*)()) F633_2913;
	R2004[171] = (char *(*)()) F634_2913;
	R2004[172] = (char *(*)()) F635_2913;
	R2004[173] = (char *(*)()) F636_2913;
	R2004[174] = (char *(*)()) F637_2913;
	R2004[175] = (char *(*)()) F638_2913;
	R2004[176] = (char *(*)()) F639_2913;
	R2004[177] = (char *(*)()) F640_2913;
	R2004[178] = (char *(*)()) F641_2913;
	R2004[179] = (char *(*)()) F642_2913;
	R2004[180] = (char *(*)()) F631_2913;
	R2004[314] = (char *(*)()) F555_2407;
}

char *(*R2005[13])();
void R2005_init () {
	R2005[0] = (char *(*)()) F660_3046;
	R2005[1] = (char *(*)()) F661_3046;
	R2005[2] = (char *(*)()) F662_3046;
	R2005[3] = (char *(*)()) F663_3046;
	R2005[4] = (char *(*)()) F664_3046;
	R2005[5] = (char *(*)()) F665_3046;
	R2005[6] = (char *(*)()) F666_3046;
	R2005[7] = (char *(*)()) F667_3046;
	R2005[8] = (char *(*)()) F668_3046;
	R2005[9] = (char *(*)()) F669_3046;
	R2005[10] = (char *(*)()) F670_3046;
	R2005[11] = (char *(*)()) F671_3046;
	R2005[12] = (char *(*)()) F660_3046;
}

char *(*R2006[315])();
void R2006_init () {
	R2006[0] = (char *(*)()) F491_2328;
	R2006[168] = (char *(*)()) F660_3047;
	R2006[169] = (char *(*)()) F661_3047;
	R2006[170] = (char *(*)()) F662_3047;
	R2006[171] = (char *(*)()) F663_3047;
	R2006[172] = (char *(*)()) F664_3047;
	R2006[173] = (char *(*)()) F665_3047;
	R2006[174] = (char *(*)()) F666_3047;
	R2006[175] = (char *(*)()) F667_3047;
	R2006[176] = (char *(*)()) F668_3047;
	R2006[177] = (char *(*)()) F669_3047;
	R2006[178] = (char *(*)()) F670_3047;
	R2006[179] = (char *(*)()) F671_3047;
	R2006[180] = (char *(*)()) F660_3047;
	R2006[314] = (char *(*)()) F555_2466;
}

char *(*R2013[145])();
void R2013_init () {
	R2013[0] = (char *(*)()) F660_3055;
	R2013[1] = (char *(*)()) F661_3055_2013_4;
	R2013[2] = (char *(*)()) F662_3055_2013_4;
	R2013[3] = (char *(*)()) F663_3055_2013_4;
	R2013[4] = (char *(*)()) F664_3055_2013_4;
	R2013[5] = (char *(*)()) F665_3055_2013_4;
	R2013[6] = (char *(*)()) F666_3055_2013_4;
	R2013[7] = (char *(*)()) F667_3055_2013_4;
	R2013[8] = (char *(*)()) F668_3055_2013_4;
	R2013[9] = (char *(*)()) F669_3055_2013_4;
	R2013[10] = (char *(*)()) F670_3055_2013_4;
	R2013[11] = (char *(*)()) F671_3055_2013_4;
	R2013[12] = (char *(*)()) F672_3082;
	R2013[141] = (char *(*)()) F801_4835_2013_4;
	R2013[144] = (char *(*)()) F804_5000_2013_4;
}
static void F661_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_3055(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F662_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_3055(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F663_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_3055(Current, *(EIF_POINTER *)arg1);
}
static void F664_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_3055(Current, *(EIF_REAL_32 *)arg1);
}
static void F665_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_3055(Current, *(EIF_REAL_64 *)arg1);
}
static void F666_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_3055(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F667_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_3055(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F668_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_3055(Current, *(EIF_BOOLEAN *)arg1);
}
static void F669_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F669_3055(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F670_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_3055(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F671_3055_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_3055(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F801_4835_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F801_4835(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F804_5000_2013_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F804_5000(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R2019[210])();
void R2019_init () {
	R2019[0] = (char *(*)()) F595_2821_2019_5;
	R2019[1] = (char *(*)()) F596_2821_2019_5;
	R2019[2] = (char *(*)()) F597_2821_2019_5;
	R2019[3] = (char *(*)()) F598_2821_2019_5;
	R2019[4] = (char *(*)()) F599_2821_2019_5;
	R2019[5] = (char *(*)()) F600_2821_2019_5;
	R2019[6] = (char *(*)()) F601_2821_2019_5;
	R2019[7] = (char *(*)()) F602_2821_2019_5;
	R2019[8] = (char *(*)()) F603_2821_2019_5;
	R2019[9] = (char *(*)()) F604_2821_2019_5;
	R2019[10] = (char *(*)()) F605_2821_2019_5;
	R2019[11] = (char *(*)()) F606_2821_2019_5;
	R2019[65] = (char *(*)()) F660_3020_2019_5;
	R2019[66] = (char *(*)()) F661_3020_2019_5;
	R2019[67] = (char *(*)()) F662_3020_2019_5;
	R2019[68] = (char *(*)()) F663_3020_2019_5;
	R2019[69] = (char *(*)()) F664_3020_2019_5;
	R2019[70] = (char *(*)()) F665_3020_2019_5;
	R2019[71] = (char *(*)()) F666_3020_2019_5;
	R2019[72] = (char *(*)()) F667_3020_2019_5;
	R2019[73] = (char *(*)()) F668_3020_2019_5;
	R2019[74] = (char *(*)()) F669_3020_2019_5;
	R2019[75] = (char *(*)()) F670_3020_2019_5;
	R2019[76] = (char *(*)()) F671_3020_2019_5;
	R2019[77] = (char *(*)()) F660_3020_2019_5;
	R2019[206] = (char *(*)()) F801_4788_2019_5;
	R2019[209] = (char *(*)()) F804_4952_2019_5;
}
static EIF_REFERENCE F595_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F595_2821(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F596_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F596_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F597_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F598_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F598_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F599_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F599_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F600_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F600_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F601_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F601_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F602_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F602_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F603_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F603_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F604_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F604_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F605_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F605_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F606_2821_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F606_2821(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_3020(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F661_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F661_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F662_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F663_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F664_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(747, 0x00).id, 747, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F665_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(750, 0x00).id, 750, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F666_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(741, 0x00).id, 741, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F667_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(744, 0x00).id, 744, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F668_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F669_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F669_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(735, 0x00).id, 735, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F670_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F670_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F671_3020_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F671_3020(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(738, 0x00).id, 738, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4788_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F801_4788(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4952_2019_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F804_4952(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(756, 0x00).id, 756, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
