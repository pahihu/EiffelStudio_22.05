
#ifndef _C16_re777_
#define _C16_re777_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F530_2363(EIF_REFERENCE);
extern void EIF_Minit777(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
