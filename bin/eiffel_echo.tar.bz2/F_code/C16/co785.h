
#ifndef _C16_co785_
#define _C16_co785_

#ifdef __cplusplus
extern "C" {
#endif

extern void F355_2220(EIF_REFERENCE);
extern void EIF_Minit785(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
