
#ifndef _C16_ge799_
#define _C16_ge799_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F305_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F305_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F305_2180(EIF_REFERENCE);
extern void F305_2182(EIF_REFERENCE);
extern void EIF_Minit799(void);

#ifdef __cplusplus
}
#endif

#endif
