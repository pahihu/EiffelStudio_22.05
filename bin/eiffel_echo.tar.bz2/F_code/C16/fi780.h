
#ifndef _C16_fi780_
#define _C16_fi780_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F504_2350(EIF_REFERENCE);
extern void EIF_Minit780(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
