
#ifndef _C16_li782_
#define _C16_li782_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F379_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F379_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F379_2239(EIF_REFERENCE);
extern void EIF_Minit782(void);
extern EIF_BOOLEAN F618_2889(EIF_REFERENCE);
extern EIF_NATURAL_32 F671_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F504_2350(EIF_REFERENCE);
extern EIF_BOOLEAN F642_2913(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
