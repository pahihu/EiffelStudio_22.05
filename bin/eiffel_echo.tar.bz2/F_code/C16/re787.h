
#ifndef _C16_re787_
#define _C16_re787_

#ifdef __cplusplus
extern "C" {
#endif

extern void F285_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F285_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F285_2149(EIF_REFERENCE);
extern void F285_2152(EIF_REFERENCE);
extern void EIF_Minit787(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
