/*
 * Code for class LINEAR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li782.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.item_for_iteration */
EIF_NATURAL_32 F379_2236 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_32) F671_3019(Current);
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F379_2237 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F618_2889(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F379_2239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F504_2350(Current)) {
		Result = F642_2913(Current);
	}
	RTLE;
	return Result;
}

void EIF_Minit782 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
