
#ifndef _C16_ha773_
#define _C16_ha773_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F293_2161(EIF_REFERENCE);
extern EIF_REFERENCE F293_2162(EIF_REFERENCE);
extern EIF_BOOLEAN F293_2164(EIF_REFERENCE);
extern void F293_2165(EIF_REFERENCE);
extern EIF_REFERENCE F293_2166(EIF_REFERENCE);
extern void EIF_Minit773(void);
extern EIF_INTEGER_32 F678_3135(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F678_3134(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F282_2147(EIF_REFERENCE);
extern char *(*R2280[])();
extern char *(*R1821[])();

#ifdef __cplusplus
}
#endif

#endif
