
#ifndef _C2_ro96_
#define _C2_ro96_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F119_1251(EIF_REFERENCE);
extern void F119_1253(EIF_REFERENCE, EIF_REFERENCE);
extern void F119_1254(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit96(void);

#ifdef __cplusplus
}
#endif

#endif
