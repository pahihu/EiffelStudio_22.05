
#ifndef _C2_ex66_
#define _C2_ex66_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1127)
static EIF_REFERENCE F89_1127_body(EIF_REFERENCE);
extern EIF_REFERENCE F89_1127(EIF_REFERENCE);
extern void EIF_Minit66(void);

#ifdef __cplusplus
}
#endif

#endif
