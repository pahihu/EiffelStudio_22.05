
#ifndef _C2_in58_
#define _C2_in58_

#ifdef __cplusplus
extern "C" {
#endif

extern void F79_1068(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F79_1069(EIF_REFERENCE);
extern EIF_BOOLEAN F79_1071(EIF_REFERENCE);
extern void F79_1072(EIF_REFERENCE);
extern void EIF_Minit58(void);
extern EIF_REFERENCE F660_3028(EIF_REFERENCE);
extern void F660_3047(EIF_REFERENCE);
extern EIF_REFERENCE F368_2236(EIF_REFERENCE);
extern EIF_INTEGER_32 F660_3035(EIF_REFERENCE);
extern EIF_BOOLEAN F631_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F607_2889(EIF_REFERENCE);
extern void F660_3014(EIF_REFERENCE, EIF_INTEGER_32);
extern void F660_3049(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R2013[])();
extern char *(*R1871[])();
extern char *(*R1872[])();
extern char *(*R1873[])();

#ifdef __cplusplus
}
#endif

#endif
