
#ifndef _C2_ex87_
#define _C2_ex87_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F110_1229(EIF_REFERENCE);
extern void EIF_Minit87(void);

#ifdef __cplusplus
}
#endif

#endif
