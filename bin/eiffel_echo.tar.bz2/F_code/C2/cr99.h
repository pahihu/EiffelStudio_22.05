
#ifndef _C2_cr99_
#define _C2_cr99_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F122_1257(EIF_REFERENCE);
extern void EIF_Minit99(void);

#ifdef __cplusplus
}
#endif

#endif
