
#ifndef _C2_mi92_
#define _C2_mi92_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F115_1243(EIF_REFERENCE);
extern void EIF_Minit92(void);

#ifdef __cplusplus
}
#endif

#endif
