
#ifndef _C2_ar65_
#define _C2_ar65_

#ifdef __cplusplus
extern "C" {
#endif

extern void F88_1125(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit65(void);

#ifdef __cplusplus
}
#endif

#endif
