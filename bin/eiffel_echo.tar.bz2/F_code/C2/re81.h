
#ifndef _C2_re81_
#define _C2_re81_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F104_1221(EIF_REFERENCE);
extern void EIF_Minit81(void);

#ifdef __cplusplus
}
#endif

#endif
