
#ifndef _C2_ei83_
#define _C2_ei83_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F106_1223(EIF_REFERENCE);
extern void F106_1225(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit83(void);

#ifdef __cplusplus
}
#endif

#endif
