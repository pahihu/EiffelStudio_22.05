/*
 * Code for class CONVERSION_FAILURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co70.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONVERSION_FAILURE}.make_message */
void F93_1187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F91_1169(Current, arg1);
}

void EIF_Minit70 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
