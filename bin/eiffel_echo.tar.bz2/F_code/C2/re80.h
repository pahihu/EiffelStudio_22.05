
#ifndef _C2_re80_
#define _C2_re80_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F103_1219(EIF_REFERENCE);
extern void EIF_Minit80(void);

#ifdef __cplusplus
}
#endif

#endif
