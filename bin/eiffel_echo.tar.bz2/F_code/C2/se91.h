
#ifndef _C2_se91_
#define _C2_se91_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F114_1241(EIF_REFERENCE);
extern void EIF_Minit91(void);

#ifdef __cplusplus
}
#endif

#endif
