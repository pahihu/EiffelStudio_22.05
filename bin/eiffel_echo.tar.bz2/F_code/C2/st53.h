
#ifndef _C2_st53_
#define _C2_st53_

#ifdef __cplusplus
extern "C" {
#endif

extern void F74_983(EIF_REFERENCE, EIF_BOOLEAN);
extern void F74_984(EIF_REFERENCE, EIF_BOOLEAN);
extern void F74_985(EIF_REFERENCE, EIF_REFERENCE);
extern void F74_986(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit53(void);
extern void F802_4875(EIF_REFERENCE, EIF_REFERENCE);
extern long O937[];
extern long O938[];

#ifdef __cplusplus
}
#endif

#endif
