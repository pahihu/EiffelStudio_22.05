
#ifndef _C2_ex79_
#define _C2_ex79_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F102_1217(EIF_REFERENCE);
extern void EIF_Minit79(void);

#ifdef __cplusplus
}
#endif

#endif
