
#ifndef _C2_vo97_
#define _C2_vo97_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F120_1255(EIF_REFERENCE);
extern void EIF_Minit97(void);

#ifdef __cplusplus
}
#endif

#endif
