
#ifndef _C2_no88_
#define _C2_no88_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F111_1231(EIF_REFERENCE);
extern void F111_1233(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit88(void);

#ifdef __cplusplus
}
#endif

#endif
