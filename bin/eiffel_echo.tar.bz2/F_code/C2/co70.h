
#ifndef _C2_co70_
#define _C2_co70_

#ifdef __cplusplus
extern "C" {
#endif

extern void F93_1187(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit70(void);
extern void F91_1169(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
