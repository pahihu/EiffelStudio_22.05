
#ifndef _C2_in52_
#define _C2_in52_

#ifdef __cplusplus
extern "C" {
#endif

extern void F73_966(EIF_REFERENCE);
extern EIF_BOOLEAN F73_967(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit52(void);
extern void F579_2747(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
