
#ifndef _C2_de69_
#define _C2_de69_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F92_1185(EIF_REFERENCE);
extern void EIF_Minit69(void);

#ifdef __cplusplus
}
#endif

#endif
