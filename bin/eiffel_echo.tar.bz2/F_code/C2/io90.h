
#ifndef _C2_io90_
#define _C2_io90_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F113_1235(EIF_REFERENCE);
extern void F113_1238(EIF_REFERENCE, EIF_INTEGER_32);
extern void F113_1239(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit90(void);

#ifdef __cplusplus
}
#endif

#endif
