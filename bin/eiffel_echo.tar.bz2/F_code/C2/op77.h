
#ifndef _C2_op77_
#define _C2_op77_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F100_1213(EIF_REFERENCE);
extern void F100_1216(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit77(void);

#ifdef __cplusplus
}
#endif

#endif
