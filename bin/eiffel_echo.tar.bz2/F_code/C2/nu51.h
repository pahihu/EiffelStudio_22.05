
#ifndef _C2_nu51_
#define _C2_nu51_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F72_944(EIF_REFERENCE);
extern void EIF_Minit51(void);

#ifdef __cplusplus
}
#endif

#endif
