
#ifndef _C2_vo94_
#define _C2_vo94_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F117_1245(EIF_REFERENCE);
extern void EIF_Minit94(void);

#ifdef __cplusplus
}
#endif

#endif
