
#ifndef _C2_ex67_
#define _C2_ex67_

#ifdef __cplusplus
extern "C" {
#endif

extern void F90_1146(EIF_REFERENCE, EIF_REFERENCE);
extern void F90_1147(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit67(void);
extern EIF_REFERENCE F51_752(EIF_REFERENCE, EIF_INTEGER_32);
extern void F91_1154(EIF_REFERENCE);
extern void F91_1169(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F89_1127(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1127)

#ifdef __cplusplus
}
#endif

#endif
