
#ifndef _C2_co60_
#define _C2_co60_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F81_1078(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F81_1079(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F81_1080(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F81_1083(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F81_1084(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit60(void);
extern char *(*R1011[])();

#ifdef __cplusplus
}
#endif

#endif
