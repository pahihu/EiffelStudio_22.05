
#ifndef _C2_op75_
#define _C2_op75_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F98_1190(EIF_REFERENCE);
extern void F98_1193(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit75(void);

#ifdef __cplusplus
}
#endif

#endif
