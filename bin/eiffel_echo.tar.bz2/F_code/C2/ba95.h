
#ifndef _C2_ba95_
#define _C2_ba95_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F118_1247(EIF_REFERENCE);
extern void EIF_Minit95(void);

#ifdef __cplusplus
}
#endif

#endif
