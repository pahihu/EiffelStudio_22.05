
#ifndef _C3_pr107_
#define _C3_pr107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F130_1273(EIF_REFERENCE);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
