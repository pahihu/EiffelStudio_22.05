
#ifndef _C3_ch104_
#define _C3_ch104_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F127_1265(EIF_REFERENCE);
extern void EIF_Minit104(void);

#ifdef __cplusplus
}
#endif

#endif
