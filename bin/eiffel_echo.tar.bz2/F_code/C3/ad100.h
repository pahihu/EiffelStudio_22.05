
#ifndef _C3_ad100_
#define _C3_ad100_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F123_1259(EIF_REFERENCE);
extern void EIF_Minit100(void);

#ifdef __cplusplus
}
#endif

#endif
