/*
 * Code for class PLAIN_TEXT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pl138.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PLAIN_TEXT_FILE}.make_with_name */
void F557_2657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F555_2376(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(800, 1).id);
	F796_4576(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.put_string_32 */
void F557_2680 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F557_2681(Current, arg1);
}

/* {PLAIN_TEXT_FILE}.put_string_general */
void F557_2681 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc4 = F557_2702(Current);
	tr1 = RTLNS(eif_new_type(45, 0x01).id, 45, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc2 = RTOSCF(711,F46_711, (RTCW(tr1)));
	F7_71(RTCW(loc2), loc4, arg1);
	tb1 = F7_72(RTCW(loc2));
	if (tb1) {
		loc1 = F7_68(RTCW(loc2));
	} else {
		tr1 = RTLNS(eif_new_type(45, 0x01).id, 45, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc3 = RTOSCF(709,F46_709, (RTCW(tr1)));
		F7_71(RTCW(loc2), loc3, arg1);
		tb1 = F7_72(RTCW(loc2));
		if (tb1) {
			loc1 = F7_68(RTCW(loc2));
			tb1 = F7_74(RTCW(loc3), loc4);
			if ((EIF_BOOLEAN) !tb1) {
				F7_71(RTCW(loc3), loc4, loc1);
				tb1 = F7_72(RTCW(loc3));
				if (tb1) {
					loc1 = F7_68(RTCW(loc3));
				}
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3460[Dtype(RTCW(arg1))-799])(arg1);
			if (tb1) {
				loc1 = F796_4629(RTCW(arg1));
			} else {
				tr2 = F796_4635(RTCW(arg1));
				tr1 = RTLNS(eif_new_type(13, 0x00).id, 13, _OBJSIZ_0_0_0_0_0_0_0_0_);
				loc1 = F14_244(RTCW(tr1), tr2);
			}
		}
	}
	F806_5077(Current, loc1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.encoding */
EIF_REFERENCE F557_2702 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = RTOSCF(5051,F806_5051, (Current));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
