
#ifndef _C3_va103_
#define _C3_va103_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F126_1263(EIF_REFERENCE);
extern void EIF_Minit103(void);

#ifdef __cplusplus
}
#endif

#endif
