
#ifndef _C3_re113_
#define _C3_re113_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F136_1559(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit113(void);

#ifdef __cplusplus
}
#endif

#endif
