
#ifndef _C3_po106_
#define _C3_po106_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F129_1271(EIF_REFERENCE);
extern void EIF_Minit106(void);

#ifdef __cplusplus
}
#endif

#endif
