
#ifndef _C3_lo102_
#define _C3_lo102_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F125_1261(EIF_REFERENCE);
extern void EIF_Minit102(void);

#ifdef __cplusplus
}
#endif

#endif
