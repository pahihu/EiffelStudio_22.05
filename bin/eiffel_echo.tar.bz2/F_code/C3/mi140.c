/*
 * Code for class MISMATCH_CORRECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi140.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_CORRECTOR}.correct_mismatch */
void F658_2980 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("Mismatch: ",10,1538098208);
	F801_4782(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(89, 0x01).id, 89, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F685_3285(RTCV(F1_5(Current)));
	F801_4821(RTCW(loc1), tr1);
	F90_1147(RTCW(loc2), loc1);
	RTLE;
}

/* {MISMATCH_CORRECTOR}.mismatch_information */
static EIF_REFERENCE F658_2981_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2981);
#define Result RTOSR(2981)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(681, 0x01).id, 681, _OBJSIZ_9_3_0_7_0_0_0_0_);
	F682_3209(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2981);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F658_2981 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2981,F658_2981_body,(Current));
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
