
#ifndef _C3_st134_
#define _C3_st134_

#ifdef __cplusplus
extern "C" {
#endif

extern void F319_2199(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F319_2203(EIF_REFERENCE);
extern EIF_INTEGER_32 F319_2204(EIF_REFERENCE);
extern void EIF_Minit134(void);
extern EIF_INTEGER_32 F802_4926(EIF_REFERENCE);
extern char *(*R3680[])();

#ifdef __cplusplus
}
#endif

#endif
