/*
 * Code for class FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi136.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE}.make_with_name */
void F555_2376 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F555_2539(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_7_2_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_) = (EIF_POINTER) tp2;
	tr1 = RTLNSMART(eif_new_type(803, 1).id);
	F796_4576(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.item */
EIF_CHARACTER_8 F555_2388 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F806_5072(Current);
	Result = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_5_0_);
	{
		/* INLINED CODE (FILE.back) */
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {FILE}.after */
EIF_BOOLEAN F555_2407 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F555_2435(Current)) {
		tb1 = '\01';
		if (!F806_5053(Current)) {
			tb1 = (EIF_BOOLEAN)(((EIF_INTEGER_32) 1L) == ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE}.off */
EIF_BOOLEAN F555_2409 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(((EIF_INTEGER_32) 1L) == ((EIF_INTEGER_32) 0L))) {
		tb1 = F555_2435(Current);
	}
	if (!tb1) {
		Result = F806_5053(Current);
	}
	RTLE;
	return Result;
}

/* {FILE}.is_closed */
EIF_BOOLEAN F555_2435 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_7_2_3_) == ((EIF_INTEGER_32) 0L));
}

/* {FILE}.start */
void F555_2464 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
}

/* {FILE}.forth */
void F555_2466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
	tc1 = (EIF_CHARACTER_8) eif_file_gc((FILE*) tp1);
	eif_do_nothing_value.it_c1 = tc1;
	if ((EIF_BOOLEAN) !F806_5053(Current)) {
		{
			/* INLINED CODE (FILE.back) */
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {FILE}.set_name */
void F555_2539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(2545,F555_2545, (Current));
	tr1 = F157_1859(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.buffered_file_info */
static EIF_REFERENCE F555_2545_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2545);
#define Result RTOSR(2545)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F157_1842(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2545);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F555_2545 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2545,F555_2545_body,(Current));
}

/* {FILE}.read_data_buffer */
static EIF_REFERENCE F555_2546_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2546);
#define Result RTOSR(2546)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(82, 0x01).id, 82, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F83_1086(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2546);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F555_2546 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2546,F555_2546_body,(Current));
}

/* {FILE}.file_gc */
EIF_CHARACTER_8 F555_2554 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) eif_file_gc((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_go */
void F555_2576 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_go((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.file_move */
void F555_2578 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_move((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.set_read_mode */
void F555_2602 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_7_2_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {FILE}.set_write_mode */
void F555_2603 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_7_2_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
}

void EIF_Minit136 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
