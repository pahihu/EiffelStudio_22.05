/*
 * Code for class ARGUMENT_SWITCH
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_SWITCH}.make */
void F717_3447 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = F717_3464(Current, arg1);
	tw1 = eif_character_32_item(RTCW(loc1),2);
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_4_0_0_) = (EIF_CHARACTER_32) tw1;
	tr1 = eif_boxed_item(loc1,1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) arg4;
	RTLE;
}

/* {ARGUMENT_SWITCH}.name */
EIF_REFERENCE F717_3450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F717_3459(Current)) {
		loc1 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F799_4706(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		F801_4834(RTCW(loc1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_4_0_0_));
		tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F799_4708(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}/* NOTREACHED */
	
}

/* {ARGUMENT_SWITCH}.hash_code */
EIF_INTEGER_32 F717_3454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F796_4585(RTCV(F717_3450(Current)));
	RTLE;
	return Result;
}

/* {ARGUMENT_SWITCH}.has_short_name */
EIF_BOOLEAN F717_3459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_4_0_0_);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 != tw2);
	RTLE;
	return Result;
}

/* {ARGUMENT_SWITCH}.set_is_special */
void F717_3461 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ARGUMENT_SWITCH}.new_option */
EIF_REFERENCE F717_3462 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(5, 0x01).id, 5, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F6_58(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ARGUMENT_SWITCH}.split_canonical_id */
EIF_REFERENCE F717_3464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R3448[Dtype(RTCW(arg1))-799])(arg1, tw1, ((EIF_INTEGER_32) 1L));
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3483[Dtype(RTCW(arg1))-799])(arg1);
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3483[Dtype(RTCW(arg1))-799])(arg1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R3524[Dtype(RTCW(arg1))-799])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		F800_4759(RTCW(loc2), tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,715,0xFF01,799,753,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc2;
		RTAR(tr1,loc2);
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R3447[Dtype(RTCW(arg1))-799])(arg1, ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+2)->it_c4 = tw1;
		Result = (EIF_REFERENCE) tr1;
	} else {
		loc2 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F800_4759(RTCW(loc2), arg1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,715,0xFF01,799,753,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc2;
		RTAR(tr1,loc2);
		((EIF_TYPED_VALUE *)tr1+2)->it_c4 = (EIF_CHARACTER_32) 0U;
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
