
#ifndef _C3_mi140_
#define _C3_mi140_

#ifdef __cplusplus
extern "C" {
#endif

extern void F658_2980(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,2981)
static EIF_REFERENCE F658_2981_body(EIF_REFERENCE);
extern EIF_REFERENCE F658_2981(EIF_REFERENCE);
extern void EIF_Minit140(void);
extern EIF_REFERENCE F1_5(EIF_REFERENCE);
extern void F90_1147(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F685_3285(EIF_REFERENCE);
extern void F682_3209(EIF_REFERENCE);
extern void F801_4782(EIF_REFERENCE, EIF_REFERENCE);
extern void F801_4821(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
