
#ifndef _C3_st133_
#define _C3_st133_

#ifdef __cplusplus
extern "C" {
#endif

extern void F318_2193(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F318_2197(EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2198(EIF_REFERENCE);
extern void EIF_Minit133(void);
extern EIF_INTEGER_32 F799_4758(EIF_REFERENCE);
extern char *(*R3600[])();

#ifdef __cplusplus
}
#endif

#endif
