
#ifndef _C3_na118_
#define _C3_na118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F153_1723(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F153_1724(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
