
#ifndef _C3_in105_
#define _C3_in105_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F128_1267(EIF_REFERENCE);
extern void F128_1268(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit105(void);

#ifdef __cplusplus
}
#endif

#endif
