
#ifndef _C11_ar507_
#define _C11_ar507_

#ifdef __cplusplus
extern "C" {
#endif

extern void F312_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F312_2188(EIF_REFERENCE);
extern EIF_REFERENCE F312_2191(EIF_REFERENCE);
extern void EIF_Minit507(void);
extern EIF_REFERENCE F666_3018(EIF_REFERENCE);
extern EIF_INTEGER_32 F666_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
