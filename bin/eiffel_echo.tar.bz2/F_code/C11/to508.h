
#ifndef _C11_to508_
#define _C11_to508_

#ifdef __cplusplus
extern "C" {
#endif

extern void F147_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F147_1716(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F147_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit508(void);
extern void F576_2728(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
