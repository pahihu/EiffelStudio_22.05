
#ifndef _C11_li500_
#define _C11_li500_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F637_2913(EIF_REFERENCE);
extern void EIF_Minit500(void);
extern EIF_INTEGER_32 F666_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
