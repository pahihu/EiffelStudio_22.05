
#ifndef _C11_co519_
#define _C11_co519_

#ifdef __cplusplus
extern "C" {
#endif

extern void F351_2220(EIF_REFERENCE);
extern void EIF_Minit519(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
