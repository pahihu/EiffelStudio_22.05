
#ifndef _C11_ge533_
#define _C11_ge533_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F301_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F301_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F301_2180(EIF_REFERENCE);
extern void F301_2182(EIF_REFERENCE);
extern void EIF_Minit533(void);

#ifdef __cplusplus
}
#endif

#endif
