
#ifndef _C11_ar509_
#define _C11_ar509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F326_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F326_2206(EIF_REFERENCE);
extern EIF_REFERENCE F326_2209(EIF_REFERENCE);
extern void EIF_Minit509(void);

#ifdef __cplusplus
}
#endif

#endif
