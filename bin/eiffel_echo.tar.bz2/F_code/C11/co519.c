/*
 * Code for class CONTAINER [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F351_2220 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O1985[Dtype(Current)-343]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
