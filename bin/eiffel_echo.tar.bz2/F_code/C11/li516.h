
#ifndef _C11_li516_
#define _C11_li516_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F375_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F375_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F375_2239(EIF_REFERENCE);
extern void EIF_Minit516(void);
extern EIF_BOOLEAN F638_2913(EIF_REFERENCE);
extern EIF_NATURAL_8 F667_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F500_2350(EIF_REFERENCE);
extern EIF_BOOLEAN F614_2889(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
