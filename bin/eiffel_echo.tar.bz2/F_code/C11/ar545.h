
#ifndef _C11_ar545_
#define _C11_ar545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F327_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2206(EIF_REFERENCE);
extern EIF_REFERENCE F327_2209(EIF_REFERENCE);
extern void EIF_Minit545(void);

#ifdef __cplusplus
}
#endif

#endif
