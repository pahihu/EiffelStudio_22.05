
#ifndef _C11_to544_
#define _C11_to544_

#ifdef __cplusplus
extern "C" {
#endif

extern void F148_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F148_1716(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F148_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit544(void);
extern void F577_2728(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
