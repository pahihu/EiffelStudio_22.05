
#ifndef _C11_fi514_
#define _C11_fi514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F500_2350(EIF_REFERENCE);
extern void EIF_Minit514(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
