
#ifndef _C11_ar543_
#define _C11_ar543_

#ifdef __cplusplus
extern "C" {
#endif

extern void F313_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F313_2188(EIF_REFERENCE);
extern EIF_REFERENCE F313_2191(EIF_REFERENCE);
extern void EIF_Minit543(void);
extern EIF_INTEGER_32 F667_3037(EIF_REFERENCE);
extern EIF_REFERENCE F667_3018(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
