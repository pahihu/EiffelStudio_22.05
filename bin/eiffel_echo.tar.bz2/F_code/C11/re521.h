
#ifndef _C11_re521_
#define _C11_re521_

#ifdef __cplusplus
extern "C" {
#endif

extern void F281_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F281_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F281_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F281_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F281_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F281_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F281_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F281_2149(EIF_REFERENCE);
extern void F281_2152(EIF_REFERENCE);
extern void EIF_Minit521(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
