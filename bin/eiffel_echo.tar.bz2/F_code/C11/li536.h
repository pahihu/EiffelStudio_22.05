
#ifndef _C11_li536_
#define _C11_li536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F638_2913(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern EIF_INTEGER_32 F667_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
