
#ifndef _C11_re511_
#define _C11_re511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F526_2363(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
