
#ifndef _C9_ar437_
#define _C9_ar437_

#ifdef __cplusplus
extern "C" {
#endif

extern void F324_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F324_2206(EIF_REFERENCE);
extern EIF_REFERENCE F324_2209(EIF_REFERENCE);
extern void EIF_Minit437(void);

#ifdef __cplusplus
}
#endif

#endif
