
#ifndef _C9_re449_
#define _C9_re449_

#ifdef __cplusplus
extern "C" {
#endif

extern void F279_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F279_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F279_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F279_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F279_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F279_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F279_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F279_2149(EIF_REFERENCE);
extern void F279_2152(EIF_REFERENCE);
extern void EIF_Minit449(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
