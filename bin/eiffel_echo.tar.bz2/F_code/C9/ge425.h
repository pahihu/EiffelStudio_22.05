
#ifndef _C9_ge425_
#define _C9_ge425_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F298_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F298_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F298_2180(EIF_REFERENCE);
extern void F298_2182(EIF_REFERENCE);
extern void EIF_Minit425(void);

#ifdef __cplusplus
}
#endif

#endif
