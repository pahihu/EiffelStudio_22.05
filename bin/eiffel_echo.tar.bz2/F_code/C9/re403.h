
#ifndef _C9_re403_
#define _C9_re403_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F523_2363(EIF_REFERENCE);
extern void EIF_Minit403(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
