
#ifndef _C9_to400_
#define _C9_to400_

#ifdef __cplusplus
extern "C" {
#endif

extern void F144_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F144_1716(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F144_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit400(void);
extern void F573_2728(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
