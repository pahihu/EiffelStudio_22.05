
#ifndef _C9_fi406_
#define _C9_fi406_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F497_2350(EIF_REFERENCE);
extern void EIF_Minit406(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
