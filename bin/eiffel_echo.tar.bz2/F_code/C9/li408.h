
#ifndef _C9_li408_
#define _C9_li408_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_32 F372_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F372_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F372_2239(EIF_REFERENCE);
extern void EIF_Minit408(void);
extern EIF_BOOLEAN F611_2889(EIF_REFERENCE);
extern EIF_BOOLEAN F635_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F497_2350(EIF_REFERENCE);
extern EIF_REAL_32 F664_3019(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
