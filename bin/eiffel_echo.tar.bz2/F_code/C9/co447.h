
#ifndef _C9_co447_
#define _C9_co447_

#ifdef __cplusplus
extern "C" {
#endif

extern void F349_2220(EIF_REFERENCE);
extern void EIF_Minit447(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
