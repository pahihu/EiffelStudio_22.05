
#ifndef _C9_to436_
#define _C9_to436_

#ifdef __cplusplus
extern "C" {
#endif

extern void F145_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F145_1716(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern void F145_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit436(void);
extern void F574_2728(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
