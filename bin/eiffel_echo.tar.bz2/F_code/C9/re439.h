
#ifndef _C9_re439_
#define _C9_re439_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F524_2363(EIF_REFERENCE);
extern void EIF_Minit439(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
