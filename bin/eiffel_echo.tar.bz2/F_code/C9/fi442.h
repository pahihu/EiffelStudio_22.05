
#ifndef _C9_fi442_
#define _C9_fi442_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F498_2350(EIF_REFERENCE);
extern void EIF_Minit442(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
