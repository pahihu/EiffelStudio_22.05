
#ifndef _C9_ar435_
#define _C9_ar435_

#ifdef __cplusplus
extern "C" {
#endif

extern void F310_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F310_2188(EIF_REFERENCE);
extern EIF_REFERENCE F310_2191(EIF_REFERENCE);
extern void EIF_Minit435(void);
extern EIF_REFERENCE F664_3018(EIF_REFERENCE);
extern EIF_INTEGER_32 F664_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
