
#ifndef _C9_li444_
#define _C9_li444_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F373_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F373_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F373_2239(EIF_REFERENCE);
extern void EIF_Minit444(void);
extern EIF_BOOLEAN F636_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F498_2350(EIF_REFERENCE);
extern EIF_REAL_64 F665_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F612_2889(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
