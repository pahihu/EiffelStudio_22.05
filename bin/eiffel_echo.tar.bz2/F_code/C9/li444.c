/*
 * Code for class LINEAR [REAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li444.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.item_for_iteration */
EIF_REAL_64 F373_2236 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_64) F665_3019(Current);
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F373_2237 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F612_2889(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F373_2239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F498_2350(Current)) {
		Result = F636_2913(Current);
	}
	RTLE;
	return Result;
}

void EIF_Minit444 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
