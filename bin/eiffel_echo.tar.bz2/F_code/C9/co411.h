
#ifndef _C9_co411_
#define _C9_co411_

#ifdef __cplusplus
extern "C" {
#endif

extern void F348_2220(EIF_REFERENCE);
extern void EIF_Minit411(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
