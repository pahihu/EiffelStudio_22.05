
#ifndef _C9_re413_
#define _C9_re413_

#ifdef __cplusplus
extern "C" {
#endif

extern void F278_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F278_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F278_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F278_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F278_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F278_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F278_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F278_2149(EIF_REFERENCE);
extern void F278_2152(EIF_REFERENCE);
extern void EIF_Minit413(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
