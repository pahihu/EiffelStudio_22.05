
#ifndef _C9_ar401_
#define _C9_ar401_

#ifdef __cplusplus
extern "C" {
#endif

extern void F323_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F323_2206(EIF_REFERENCE);
extern EIF_REFERENCE F323_2209(EIF_REFERENCE);
extern void EIF_Minit401(void);

#ifdef __cplusplus
}
#endif

#endif
