
#ifndef _C9_li428_
#define _C9_li428_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F635_2913(EIF_REFERENCE);
extern void EIF_Minit428(void);
extern EIF_INTEGER_32 F664_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
