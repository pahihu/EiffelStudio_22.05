
#ifndef _C13_co639_
#define _C13_co639_

#ifdef __cplusplus
extern "C" {
#endif

extern void F354_2220(EIF_REFERENCE);
extern void EIF_Minit639(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
