
#ifndef _C13_re607_
#define _C13_re607_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F528_2363(EIF_REFERENCE);
extern void EIF_Minit607(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
