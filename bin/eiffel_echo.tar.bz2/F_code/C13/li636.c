/*
 * Code for class LINEAR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li636.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.item_for_iteration */
EIF_CHARACTER_8 F378_2236 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1991[Dtype(Current)-491])(Current));
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F378_2237 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1992[Dtype(Current)-491])(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F378_2239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1983[dtype-491])(Current)) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2004[dtype-491])(Current);
	}
	RTLE;
	return Result;
}

void EIF_Minit636 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
