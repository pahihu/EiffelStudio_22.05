
#ifndef _C13_li610_
#define _C13_li610_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F377_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F377_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F377_2239(EIF_REFERENCE);
extern void EIF_Minit610(void);
extern EIF_BOOLEAN F502_2350(EIF_REFERENCE);
extern EIF_NATURAL_64 F669_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F640_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F616_2889(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
