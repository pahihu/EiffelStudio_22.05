
#ifndef _C13_fi609_
#define _C13_fi609_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F502_2350(EIF_REFERENCE);
extern void EIF_Minit609(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
