
#ifndef _C13_fi635_
#define _C13_fi635_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F503_2350(EIF_REFERENCE);
extern void EIF_Minit635(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
