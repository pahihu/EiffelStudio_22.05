
#ifndef _C13_to630_
#define _C13_to630_

#ifdef __cplusplus
extern "C" {
#endif

extern void F150_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F150_1716(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F150_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit630(void);
extern void F579_2728(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
