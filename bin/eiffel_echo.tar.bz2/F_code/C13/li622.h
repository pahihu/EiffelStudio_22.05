
#ifndef _C13_li622_
#define _C13_li622_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F640_2913(EIF_REFERENCE);
extern void EIF_Minit622(void);
extern EIF_INTEGER_32 F669_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
