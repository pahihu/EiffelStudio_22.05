
#ifndef _C13_li636_
#define _C13_li636_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F378_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F378_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F378_2239(EIF_REFERENCE);
extern void EIF_Minit636(void);
extern char *(*R2004[])();
extern char *(*R1983[])();
extern char *(*R1991[])();
extern char *(*R1992[])();

#ifdef __cplusplus
}
#endif

#endif
