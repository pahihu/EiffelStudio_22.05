/*
 * Code for class CONTAINER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co639.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F354_2220 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O1985[Dtype(Current)-343]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit639 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
