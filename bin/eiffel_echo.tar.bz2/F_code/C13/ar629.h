
#ifndef _C13_ar629_
#define _C13_ar629_

#ifdef __cplusplus
extern "C" {
#endif

extern void F315_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F315_2188(EIF_REFERENCE);
extern EIF_REFERENCE F315_2191(EIF_REFERENCE);
extern void EIF_Minit629(void);
extern EIF_INTEGER_32 F669_3037(EIF_REFERENCE);
extern EIF_REFERENCE F669_3018(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
