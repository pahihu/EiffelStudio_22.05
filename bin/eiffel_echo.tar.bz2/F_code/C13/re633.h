
#ifndef _C13_re633_
#define _C13_re633_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F529_2363(EIF_REFERENCE);
extern void EIF_Minit633(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
