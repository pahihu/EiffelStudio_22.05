
#ifndef _C13_re641_
#define _C13_re641_

#ifdef __cplusplus
extern "C" {
#endif

extern void F284_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F284_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F284_2149(EIF_REFERENCE);
extern void F284_2152(EIF_REFERENCE);
extern void EIF_Minit641(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
