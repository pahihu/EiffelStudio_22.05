
#ifndef _C13_ar631_
#define _C13_ar631_

#ifdef __cplusplus
extern "C" {
#endif

extern void F329_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F329_2206(EIF_REFERENCE);
extern EIF_REFERENCE F329_2209(EIF_REFERENCE);
extern void EIF_Minit631(void);

#ifdef __cplusplus
}
#endif

#endif
