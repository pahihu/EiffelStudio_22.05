
#ifndef _C13_ge604_
#define _C13_ge604_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F303_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F303_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F303_2180(EIF_REFERENCE);
extern void F303_2182(EIF_REFERENCE);
extern void EIF_Minit604(void);

#ifdef __cplusplus
}
#endif

#endif
