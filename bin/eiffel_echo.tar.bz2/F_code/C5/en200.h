
#ifndef _C5_en200_
#define _C5_en200_

#ifdef __cplusplus
extern "C" {
#endif

extern void F807_5111(EIF_REFERENCE);
extern EIF_REFERENCE F807_5112(EIF_REFERENCE);
extern void EIF_Minit200(void);
extern EIF_REFERENCE F796_4635(EIF_REFERENCE);
extern EIF_REFERENCE F63_872(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F63_873(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
