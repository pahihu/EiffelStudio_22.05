
#ifndef _C5_ar239_
#define _C5_ar239_

#ifdef __cplusplus
extern "C" {
#endif

extern void F595_2816(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F595_2817(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F595_2819(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F595_2821(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F595_2824(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F595_2825(EIF_REFERENCE);
extern EIF_INTEGER_32 F595_2826(EIF_REFERENCE);
extern EIF_INTEGER_32 F595_2827(EIF_REFERENCE);
extern EIF_INTEGER_32 F595_2828(EIF_REFERENCE);
extern EIF_INTEGER_32 F595_2829(EIF_REFERENCE);
extern EIF_BOOLEAN F595_2831(EIF_REFERENCE, EIF_REFERENCE);
extern void F595_2840(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F595_2869(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit239(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R2622[])();
extern char *(*R1582[])();
extern char *(*R1583[])();
extern char *(*R1589[])();
extern char *(*R1978[])();
extern char *(*R1821[])();
extern char *(*R2019[])();
extern char *(*R2295[])();
extern char *(*R2296[])();
extern char *(*R2280[])();
extern char *(*R2070[])();
extern EIF_TYPE_INDEX Y1887[];
extern EIF_TYPE_INDEX *Y1887_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
