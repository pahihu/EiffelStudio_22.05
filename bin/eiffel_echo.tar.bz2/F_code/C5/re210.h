
#ifndef _C5_re210_
#define _C5_re210_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F519_2363(EIF_REFERENCE);
extern void EIF_Minit210(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
