
#ifndef _C5_pr230_
#define _C5_pr230_

#ifdef __cplusplus
extern "C" {
#endif

extern void F792_4563(EIF_REFERENCE, EIF_REFERENCE);
extern void F792_4564(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER);
extern void EIF_Minit230(void);
extern EIF_INTEGER_32 F791_4544(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
