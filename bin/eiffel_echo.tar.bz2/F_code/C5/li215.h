
#ifndef _C5_li215_
#define _C5_li215_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F368_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F368_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F368_2239(EIF_REFERENCE);
extern void EIF_Minit215(void);
extern char *(*R2004[])();
extern char *(*R1983[])();
extern char *(*R1991[])();
extern char *(*R1992[])();

#ifdef __cplusplus
}
#endif

#endif
