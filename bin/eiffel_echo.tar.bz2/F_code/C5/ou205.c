/*
 * Code for class OUTPUT_MEDIUM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ou205.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OUTPUT_MEDIUM}.make */
void F812_5167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {OUTPUT_MEDIUM}.put */
void F812_5169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(708,F46_708, (Current));
	tr1 = F810_5159(Current, tr1, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F806_5077(RTCW(tr1), loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("Console output truncated: ",26,2060641568);
		F806_5077(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F796_4632(RTCW(arg1));
		F806_5077(RTCW(tr1), tr2);
	}
	RTLE;
}

void EIF_Minit205 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
