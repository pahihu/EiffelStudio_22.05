
#ifndef _C5_ro220_
#define _C5_ro220_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F791_4524(EIF_REFERENCE);
extern EIF_INTEGER_32 F791_4526(EIF_REFERENCE);
extern EIF_BOOLEAN F791_4531(EIF_REFERENCE, EIF_REFERENCE);
extern void F791_4538(EIF_REFERENCE, EIF_REFERENCE);
extern void F791_4542(EIF_REFERENCE);
extern EIF_INTEGER_32 F791_4544(EIF_REFERENCE);
extern void F791_4553(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_POINTER, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void EIF_Minit220(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern long O3418[];
extern long O3419[];
extern long O3421[];
extern long O3422[];
extern long O3424[];
extern long O3410[];

#ifdef __cplusplus
}
#endif

#endif
