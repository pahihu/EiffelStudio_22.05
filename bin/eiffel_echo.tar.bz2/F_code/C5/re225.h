
#ifndef _C5_re225_
#define _C5_re225_

#ifdef __cplusplus
extern "C" {
#endif

extern void F274_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F274_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F274_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F274_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F274_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F274_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F274_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F274_2149(EIF_REFERENCE);
extern void F274_2152(EIF_REFERENCE);
extern void EIF_Minit225(void);
extern char *(*R2281[])();
extern char *(*R2282[])();
extern char *(*R1949[])();

#ifdef __cplusplus
}
#endif

#endif
