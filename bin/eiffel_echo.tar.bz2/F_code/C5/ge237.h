
#ifndef _C5_ge237_
#define _C5_ge237_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F294_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F294_2180(EIF_REFERENCE);
extern void F294_2182(EIF_REFERENCE);
extern void EIF_Minit237(void);
extern char *(*R2280[])();

#ifdef __cplusplus
}
#endif

#endif
