
#ifndef _C5_li241_
#define _C5_li241_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F631_2913(EIF_REFERENCE);
extern void EIF_Minit241(void);
extern char *(*R2000[])();
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
