

#ifdef __cplusplus
extern "C" {
#endif

char *names2 [] =
{
"cache",
"converted_pair",
};

char *names4 [] =
{
"version",
};

char *names6 [] =
{
"switch",
"internal_value",
};

char *names7 [] =
{
"code_page",
"encoding_i",
};

char *names10 [] =
{
"switches",
"is_hidden",
"is_allowing_non_switched_arguments",
};

char *names12 [] =
{
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"maximum_record_count",
};

char *names28 [] =
{
"default_output",
};

char *names30 [] =
{
"output",
};

char *names33 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names34 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names35 [] =
{
"internal_reason",
"is_option_valid",
"has_validated",
};

char *names36 [] =
{
"internal_reason",
"is_option_valid",
"has_validated",
};

char *names43 [] =
{
"non_switched_argument_validator",
"internal_option_values",
"internal_values",
"internal_argument_source",
"is_using_separated_switch_values",
"is_showing_argument_usage_inline",
"is_usage_verbose",
"is_usage_displayed_on_error",
"has_executed",
"is_case_sensitive",
"is_using_builtin_switches",
"is_allowing_non_switched_arguments",
"is_non_switch_argument_required",
"is_logo_information_suppressed",
"is_help_usage_displayed",
"has_parsed",
};

char *names44 [] =
{
"non_switched_argument_validator",
"internal_option_values",
"internal_values",
"internal_argument_source",
"is_using_separated_switch_values",
"is_showing_argument_usage_inline",
"is_usage_verbose",
"is_usage_displayed_on_error",
"has_executed",
"is_case_sensitive",
"is_using_builtin_switches",
"is_allowing_non_switched_arguments",
"is_non_switch_argument_required",
"is_logo_information_suppressed",
"is_help_usage_displayed",
"has_parsed",
};

char *names45 [] =
{
"non_switched_argument_validator",
"internal_option_values",
"internal_values",
"internal_argument_source",
"is_using_separated_switch_values",
"is_showing_argument_usage_inline",
"is_usage_verbose",
"is_usage_displayed_on_error",
"has_executed",
"is_case_sensitive",
"is_using_builtin_switches",
"is_allowing_non_switched_arguments",
"is_non_switch_argument_required",
"is_logo_information_suppressed",
"is_help_usage_displayed",
"has_parsed",
};

char *names53 [] =
{
"item",
};

char *names54 [] =
{
"item",
};

char *names55 [] =
{
"item",
};

char *names56 [] =
{
"item",
};

char *names57 [] =
{
"item",
"right",
};

char *names58 [] =
{
"right",
"item",
};

char *names69 [] =
{
"deltas",
"deltas_array",
};

char *names70 [] =
{
"deltas",
"deltas_array",
};

char *names71 [] =
{
"deltas",
"deltas_array",
};

char *names73 [] =
{
"integer_overflow_state1",
"integer_overflow_state2",
"natural_overflow_state1",
"natural_overflow_state2",
};

char *names74 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"conversion_type",
"last_state",
"sign",
};

char *names75 [] =
{
"leading_separators",
"trailing_separators",
"internal_lookahead",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names76 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names77 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"is_negative",
"has_negative_exponent",
"has_fractional_part",
"needs_digit",
"conversion_type",
"last_state",
"sign",
"exponent",
"natural_part",
"fractional_part",
"fractional_divider",
};

char *names79 [] =
{
"items",
};

char *names83 [] =
{
"managed_data",
"count",
};

char *names85 [] =
{
"active",
"after",
"before",
};

char *names86 [] =
{
"active",
"after",
"before",
};

char *names87 [] =
{
"position",
};

char *names88 [] =
{
"index",
};

char *names91 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names92 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names93 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names94 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names95 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names96 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names97 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names98 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"signal_code",
};

char *names99 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"exception_information",
"internal_is_ignorable",
"line_number",
"hresult",
"hresult_code",
};

char *names100 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
};

char *names101 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names102 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names103 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names104 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names105 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names106 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names107 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names108 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names109 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names110 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names111 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names112 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names113 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
"internal_code",
};

char *names114 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names115 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names116 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names117 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names118 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names119 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"routine_name",
"class_name",
"internal_is_ignorable",
"line_number",
};

char *names120 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names121 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names122 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names123 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names124 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names125 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names126 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names127 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names128 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"is_entry",
"line_number",
};

char *names129 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names130 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names132 [] =
{
"is_shared",
"count",
"item",
"counter",
};

char *names133 [] =
{
"last_string",
"last_character",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"last_real",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names135 [] =
{
"dynamic_type",
};

char *names139 [] =
{
"referring_object",
"dynamic_type",
"physical_offset",
"referring_physical_offset",
};

char *names140 [] =
{
"enclosing_object",
"dynamic_type",
"physical_offset",
};

char *names141 [] =
{
"area",
};

char *names142 [] =
{
"area",
};

char *names143 [] =
{
"area",
};

char *names144 [] =
{
"area",
};

char *names145 [] =
{
"area",
};

char *names146 [] =
{
"area",
};

char *names147 [] =
{
"area",
};

char *names148 [] =
{
"area",
};

char *names149 [] =
{
"area",
};

char *names150 [] =
{
"area",
};

char *names151 [] =
{
"area",
};

char *names152 [] =
{
"area",
};

char *names154 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names155 [] =
{
"return_code",
};

char *names156 [] =
{
"managed_data",
"unit_count",
};

char *names157 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names158 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names160 [] =
{
"recorder",
"object",
"breakable_info",
"parent",
"steps",
"call_records",
"value_records",
"last_position",
"rt_information_available",
"is_expanded",
"is_flat",
"is_closed",
"class_type_id",
"feature_rout_id",
"depth",
};

char *names162 [] =
{
"breakable_info",
"position",
"type",
};

char *names163 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names164 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names165 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names166 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names167 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names168 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"value",
"callstack_depth",
};

char *names169 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names170 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names171 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names172 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names173 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names174 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names175 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names176 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names177 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names178 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names179 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names180 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names181 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names182 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names183 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names184 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names185 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names186 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names187 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names188 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names189 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names190 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names191 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names192 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names193 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names194 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names195 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names196 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names197 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names198 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names199 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names200 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names201 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names202 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names203 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names204 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names205 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names206 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names207 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names221 [] =
{
"area",
"area_index",
"remaining_count",
};

char *names222 [] =
{
"byte",
"file_pointer",
};

char *names243 [] =
{
"target",
"target_index",
"start_index",
"end_index",
};

char *names274 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names275 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names276 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names277 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names278 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names279 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names280 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names281 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names282 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names283 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names284 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names285 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names286 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names287 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names288 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names289 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names290 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names291 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names292 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names293 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names294 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names295 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names296 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names297 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names298 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names299 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names300 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names301 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names302 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names303 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names304 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names305 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names306 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names307 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names308 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names309 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names310 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names311 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names312 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names313 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names314 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names315 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names316 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names317 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names318 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names319 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names320 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names321 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names322 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names323 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names324 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names325 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names326 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names327 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names328 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names329 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names330 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names331 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names332 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names333 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names334 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names335 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names336 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names337 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names338 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names339 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names340 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names341 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names342 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names343 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names344 [] =
{
"object_comparison",
};

char *names345 [] =
{
"object_comparison",
};

char *names346 [] =
{
"object_comparison",
};

char *names347 [] =
{
"object_comparison",
};

char *names348 [] =
{
"object_comparison",
};

char *names349 [] =
{
"object_comparison",
};

char *names350 [] =
{
"object_comparison",
};

char *names351 [] =
{
"object_comparison",
};

char *names352 [] =
{
"object_comparison",
};

char *names353 [] =
{
"object_comparison",
};

char *names354 [] =
{
"object_comparison",
};

char *names355 [] =
{
"object_comparison",
};

char *names356 [] =
{
"object_comparison",
};

char *names357 [] =
{
"object_comparison",
};

char *names358 [] =
{
"object_comparison",
};

char *names359 [] =
{
"object_comparison",
};

char *names360 [] =
{
"object_comparison",
};

char *names361 [] =
{
"object_comparison",
};

char *names362 [] =
{
"object_comparison",
};

char *names363 [] =
{
"object_comparison",
};

char *names364 [] =
{
"object_comparison",
};

char *names365 [] =
{
"object_comparison",
};

char *names366 [] =
{
"object_comparison",
};

char *names367 [] =
{
"object_comparison",
};

char *names368 [] =
{
"object_comparison",
};

char *names369 [] =
{
"object_comparison",
};

char *names370 [] =
{
"object_comparison",
};

char *names371 [] =
{
"object_comparison",
};

char *names372 [] =
{
"object_comparison",
};

char *names373 [] =
{
"object_comparison",
};

char *names374 [] =
{
"object_comparison",
};

char *names375 [] =
{
"object_comparison",
};

char *names376 [] =
{
"object_comparison",
};

char *names377 [] =
{
"object_comparison",
};

char *names378 [] =
{
"object_comparison",
};

char *names379 [] =
{
"object_comparison",
};

char *names380 [] =
{
"object_comparison",
};

char *names381 [] =
{
"object_comparison",
};

char *names382 [] =
{
"object_comparison",
};

char *names383 [] =
{
"object_comparison",
};

char *names384 [] =
{
"object_comparison",
};

char *names385 [] =
{
"object_comparison",
};

char *names386 [] =
{
"object_comparison",
};

char *names387 [] =
{
"object_comparison",
};

char *names388 [] =
{
"object_comparison",
};

char *names389 [] =
{
"object_comparison",
};

char *names390 [] =
{
"object_comparison",
};

char *names391 [] =
{
"object_comparison",
};

char *names392 [] =
{
"object_comparison",
};

char *names393 [] =
{
"object_comparison",
};

char *names394 [] =
{
"object_comparison",
};

char *names395 [] =
{
"object_comparison",
};

char *names396 [] =
{
"object_comparison",
};

char *names397 [] =
{
"object_comparison",
};

char *names398 [] =
{
"object_comparison",
};

char *names399 [] =
{
"object_comparison",
};

char *names400 [] =
{
"object_comparison",
};

char *names401 [] =
{
"object_comparison",
};

char *names402 [] =
{
"object_comparison",
};

char *names403 [] =
{
"object_comparison",
};

char *names404 [] =
{
"object_comparison",
};

char *names405 [] =
{
"object_comparison",
};

char *names406 [] =
{
"object_comparison",
};

char *names407 [] =
{
"object_comparison",
};

char *names408 [] =
{
"object_comparison",
};

char *names409 [] =
{
"object_comparison",
};

char *names410 [] =
{
"object_comparison",
};

char *names411 [] =
{
"object_comparison",
};

char *names412 [] =
{
"object_comparison",
};

char *names413 [] =
{
"object_comparison",
};

char *names414 [] =
{
"object_comparison",
};

char *names415 [] =
{
"object_comparison",
};

char *names416 [] =
{
"object_comparison",
};

char *names417 [] =
{
"object_comparison",
};

char *names418 [] =
{
"object_comparison",
};

char *names419 [] =
{
"object_comparison",
};

char *names420 [] =
{
"object_comparison",
};

char *names421 [] =
{
"object_comparison",
};

char *names422 [] =
{
"object_comparison",
};

char *names423 [] =
{
"object_comparison",
};

char *names424 [] =
{
"object_comparison",
};

char *names425 [] =
{
"object_comparison",
};

char *names426 [] =
{
"object_comparison",
};

char *names427 [] =
{
"object_comparison",
};

char *names428 [] =
{
"object_comparison",
};

char *names429 [] =
{
"object_comparison",
};

char *names430 [] =
{
"object_comparison",
};

char *names431 [] =
{
"object_comparison",
};

char *names432 [] =
{
"object_comparison",
};

char *names433 [] =
{
"object_comparison",
};

char *names434 [] =
{
"object_comparison",
};

char *names435 [] =
{
"object_comparison",
};

char *names436 [] =
{
"object_comparison",
};

char *names437 [] =
{
"object_comparison",
};

char *names438 [] =
{
"object_comparison",
};

char *names439 [] =
{
"object_comparison",
};

char *names440 [] =
{
"object_comparison",
};

char *names441 [] =
{
"object_comparison",
};

char *names442 [] =
{
"object_comparison",
};

char *names443 [] =
{
"object_comparison",
};

char *names444 [] =
{
"object_comparison",
};

char *names445 [] =
{
"object_comparison",
};

char *names446 [] =
{
"object_comparison",
};

char *names447 [] =
{
"object_comparison",
};

char *names448 [] =
{
"object_comparison",
};

char *names449 [] =
{
"object_comparison",
};

char *names450 [] =
{
"object_comparison",
};

char *names451 [] =
{
"object_comparison",
};

char *names452 [] =
{
"object_comparison",
};

char *names453 [] =
{
"object_comparison",
};

char *names454 [] =
{
"object_comparison",
};

char *names455 [] =
{
"object_comparison",
};

char *names456 [] =
{
"object_comparison",
};

char *names457 [] =
{
"object_comparison",
};

char *names458 [] =
{
"object_comparison",
};

char *names459 [] =
{
"object_comparison",
};

char *names460 [] =
{
"object_comparison",
};

char *names461 [] =
{
"object_comparison",
};

char *names462 [] =
{
"object_comparison",
};

char *names463 [] =
{
"object_comparison",
};

char *names464 [] =
{
"object_comparison",
};

char *names465 [] =
{
"object_comparison",
};

char *names466 [] =
{
"object_comparison",
};

char *names467 [] =
{
"object_comparison",
};

char *names468 [] =
{
"object_comparison",
};

char *names469 [] =
{
"object_comparison",
};

char *names470 [] =
{
"object_comparison",
};

char *names471 [] =
{
"object_comparison",
};

char *names472 [] =
{
"object_comparison",
};

char *names473 [] =
{
"object_comparison",
};

char *names474 [] =
{
"object_comparison",
};

char *names475 [] =
{
"object_comparison",
};

char *names476 [] =
{
"object_comparison",
};

char *names477 [] =
{
"object_comparison",
};

char *names478 [] =
{
"object_comparison",
};

char *names479 [] =
{
"object_comparison",
};

char *names480 [] =
{
"object_comparison",
};

char *names481 [] =
{
"object_comparison",
};

char *names482 [] =
{
"object_comparison",
};

char *names483 [] =
{
"object_comparison",
};

char *names484 [] =
{
"object_comparison",
};

char *names485 [] =
{
"object_comparison",
};

char *names486 [] =
{
"object_comparison",
};

char *names487 [] =
{
"object_comparison",
};

char *names488 [] =
{
"object_comparison",
};

char *names489 [] =
{
"object_comparison",
};

char *names490 [] =
{
"object_comparison",
};

char *names491 [] =
{
"object_comparison",
"index",
};

char *names492 [] =
{
"object_comparison",
"index",
};

char *names493 [] =
{
"object_comparison",
};

char *names494 [] =
{
"object_comparison",
};

char *names495 [] =
{
"object_comparison",
};

char *names496 [] =
{
"object_comparison",
};

char *names497 [] =
{
"object_comparison",
};

char *names498 [] =
{
"object_comparison",
};

char *names499 [] =
{
"object_comparison",
};

char *names500 [] =
{
"object_comparison",
};

char *names501 [] =
{
"object_comparison",
};

char *names502 [] =
{
"object_comparison",
};

char *names503 [] =
{
"object_comparison",
};

char *names504 [] =
{
"object_comparison",
};

char *names505 [] =
{
"object_comparison",
};

char *names506 [] =
{
"object_comparison",
};

char *names507 [] =
{
"object_comparison",
};

char *names508 [] =
{
"object_comparison",
};

char *names509 [] =
{
"object_comparison",
};

char *names510 [] =
{
"object_comparison",
};

char *names511 [] =
{
"object_comparison",
};

char *names512 [] =
{
"object_comparison",
};

char *names513 [] =
{
"object_comparison",
};

char *names514 [] =
{
"object_comparison",
};

char *names515 [] =
{
"object_comparison",
};

char *names516 [] =
{
"object_comparison",
};

char *names517 [] =
{
"object_comparison",
};

char *names518 [] =
{
"object_comparison",
};

char *names519 [] =
{
"object_comparison",
};

char *names520 [] =
{
"object_comparison",
};

char *names521 [] =
{
"object_comparison",
};

char *names522 [] =
{
"object_comparison",
};

char *names523 [] =
{
"object_comparison",
};

char *names524 [] =
{
"object_comparison",
};

char *names525 [] =
{
"object_comparison",
};

char *names526 [] =
{
"object_comparison",
};

char *names527 [] =
{
"object_comparison",
};

char *names528 [] =
{
"object_comparison",
};

char *names529 [] =
{
"object_comparison",
};

char *names530 [] =
{
"object_comparison",
};

char *names531 [] =
{
"object_comparison",
};

char *names532 [] =
{
"object_comparison",
};

char *names533 [] =
{
"object_comparison",
};

char *names534 [] =
{
"object_comparison",
};

char *names535 [] =
{
"object_comparison",
};

char *names536 [] =
{
"object_comparison",
};

char *names537 [] =
{
"object_comparison",
};

char *names538 [] =
{
"object_comparison",
};

char *names539 [] =
{
"object_comparison",
};

char *names540 [] =
{
"object_comparison",
};

char *names541 [] =
{
"object_comparison",
};

char *names542 [] =
{
"object_comparison",
};

char *names543 [] =
{
"object_comparison",
};

char *names544 [] =
{
"object_comparison",
};

char *names545 [] =
{
"object_comparison",
};

char *names546 [] =
{
"object_comparison",
};

char *names547 [] =
{
"object_comparison",
};

char *names548 [] =
{
"object_comparison",
};

char *names549 [] =
{
"object_comparison",
};

char *names550 [] =
{
"object_comparison",
};

char *names551 [] =
{
"object_comparison",
};

char *names552 [] =
{
"object_comparison",
};

char *names553 [] =
{
"object_comparison",
};

char *names554 [] =
{
"object_comparison",
};

char *names555 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names556 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names557 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names582 [] =
{
"object_comparison",
};

char *names583 [] =
{
"object_comparison",
};

char *names584 [] =
{
"object_comparison",
};

char *names585 [] =
{
"object_comparison",
};

char *names586 [] =
{
"object_comparison",
};

char *names587 [] =
{
"object_comparison",
};

char *names588 [] =
{
"object_comparison",
};

char *names589 [] =
{
"object_comparison",
};

char *names590 [] =
{
"object_comparison",
};

char *names591 [] =
{
"object_comparison",
};

char *names592 [] =
{
"object_comparison",
};

char *names593 [] =
{
"object_comparison",
};

char *names594 [] =
{
"object_comparison",
"upper",
"lower",
};

char *names595 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names596 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names597 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names598 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names599 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names600 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names601 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names602 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names603 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names604 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names605 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names606 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names607 [] =
{
"object_comparison",
};

char *names608 [] =
{
"object_comparison",
};

char *names609 [] =
{
"object_comparison",
};

char *names610 [] =
{
"object_comparison",
};

char *names611 [] =
{
"object_comparison",
};

char *names612 [] =
{
"object_comparison",
};

char *names613 [] =
{
"object_comparison",
};

char *names614 [] =
{
"object_comparison",
};

char *names615 [] =
{
"object_comparison",
};

char *names616 [] =
{
"object_comparison",
};

char *names617 [] =
{
"object_comparison",
};

char *names618 [] =
{
"object_comparison",
};

char *names619 [] =
{
"object_comparison",
};

char *names620 [] =
{
"object_comparison",
};

char *names621 [] =
{
"object_comparison",
};

char *names622 [] =
{
"object_comparison",
};

char *names623 [] =
{
"object_comparison",
};

char *names624 [] =
{
"object_comparison",
};

char *names625 [] =
{
"object_comparison",
};

char *names626 [] =
{
"object_comparison",
};

char *names627 [] =
{
"object_comparison",
};

char *names628 [] =
{
"object_comparison",
};

char *names629 [] =
{
"object_comparison",
};

char *names630 [] =
{
"object_comparison",
};

char *names631 [] =
{
"object_comparison",
};

char *names632 [] =
{
"object_comparison",
};

char *names633 [] =
{
"object_comparison",
};

char *names634 [] =
{
"object_comparison",
};

char *names635 [] =
{
"object_comparison",
};

char *names636 [] =
{
"object_comparison",
};

char *names637 [] =
{
"object_comparison",
};

char *names638 [] =
{
"object_comparison",
};

char *names639 [] =
{
"object_comparison",
};

char *names640 [] =
{
"object_comparison",
};

char *names641 [] =
{
"object_comparison",
};

char *names642 [] =
{
"object_comparison",
};

char *names643 [] =
{
"object_comparison",
};

char *names644 [] =
{
"object_comparison",
};

char *names645 [] =
{
"object_comparison",
};

char *names646 [] =
{
"object_comparison",
};

char *names647 [] =
{
"object_comparison",
};

char *names648 [] =
{
"object_comparison",
};

char *names649 [] =
{
"object_comparison",
};

char *names650 [] =
{
"object_comparison",
};

char *names651 [] =
{
"object_comparison",
};

char *names652 [] =
{
"object_comparison",
};

char *names653 [] =
{
"object_comparison",
};

char *names654 [] =
{
"object_comparison",
};

char *names655 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names656 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names657 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names659 [] =
{
"area",
"object_comparison",
"out_index",
"count",
};

char *names660 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names661 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names662 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names663 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names664 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names665 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names666 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names667 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names668 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names669 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names670 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names671 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names672 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names673 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names674 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_key",
"count",
};

char *names675 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names676 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
"found_item",
"ht_deleted_item",
};

char *names677 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"ht_deleted_key",
"count",
};

char *names678 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"found_item",
"hash_table_version_64",
"has_default",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names679 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names680 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names681 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"found_item",
"hash_table_version_64",
"has_default",
"ht_deleted_item",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names682 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"stored_version",
"current_version",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names684 [] =
{
"storage",
"internal_name",
"is_normalized",
};

char *names685 [] =
{
"internal_name_32",
"internal_name",
};

char *names686 [] =
{
"internal_name_32",
"internal_name",
};

char *names687 [] =
{
"internal_name_32",
"internal_name",
};

char *names688 [] =
{
"internal_name_32",
"internal_name",
};

char *names689 [] =
{
"internal_name_32",
"internal_name",
};

char *names690 [] =
{
"internal_name_32",
"internal_name",
};

char *names691 [] =
{
"internal_name_32",
"internal_name",
};

char *names692 [] =
{
"internal_name_32",
"internal_name",
};

char *names693 [] =
{
"internal_name_32",
"internal_name",
};

char *names694 [] =
{
"internal_name_32",
"internal_name",
};

char *names695 [] =
{
"internal_name_32",
"internal_name",
};

char *names696 [] =
{
"internal_name_32",
"internal_name",
};

char *names697 [] =
{
"internal_name_32",
"internal_name",
};

char *names698 [] =
{
"internal_name_32",
"internal_name",
};

char *names699 [] =
{
"internal_name_32",
"internal_name",
};

char *names700 [] =
{
"internal_name_32",
"internal_name",
};

char *names701 [] =
{
"internal_name_32",
"internal_name",
};

char *names702 [] =
{
"internal_name_32",
"internal_name",
};

char *names703 [] =
{
"internal_name_32",
"internal_name",
};

char *names704 [] =
{
"internal_name_32",
"internal_name",
};

char *names705 [] =
{
"internal_name_32",
"internal_name",
};

char *names706 [] =
{
"internal_name_32",
"internal_name",
};

char *names707 [] =
{
"internal_name_32",
"internal_name",
};

char *names708 [] =
{
"internal_name_32",
"internal_name",
};

char *names709 [] =
{
"internal_name_32",
"internal_name",
};

char *names710 [] =
{
"internal_name_32",
"internal_name",
};

char *names711 [] =
{
"internal_name_32",
"internal_name",
};

char *names712 [] =
{
"internal_name_32",
"internal_name",
};

char *names713 [] =
{
"internal_name_32",
"internal_name",
};

char *names714 [] =
{
"internal_name_32",
"internal_name",
};

char *names715 [] =
{
"internal_name_32",
"internal_name",
};

char *names717 [] =
{
"id",
"long_name",
"description",
"optional",
"allow_multiple",
"is_hidden",
"is_special",
"short_name",
};

char *names718 [] =
{
"id",
"long_name",
"description",
"arg_name",
"arg_description",
"optional",
"allow_multiple",
"is_hidden",
"is_special",
"is_value_optional",
"short_name",
};

char *names719 [] =
{
"item",
};

char *names720 [] =
{
"item",
};

char *names721 [] =
{
"item",
};

char *names722 [] =
{
"item",
};

char *names723 [] =
{
"item",
};

char *names724 [] =
{
"item",
};

char *names725 [] =
{
"item",
};

char *names726 [] =
{
"item",
};

char *names727 [] =
{
"item",
};

char *names728 [] =
{
"item",
};

char *names729 [] =
{
"item",
};

char *names730 [] =
{
"item",
};

char *names731 [] =
{
"item",
};

char *names732 [] =
{
"item",
};

char *names733 [] =
{
"item",
};

char *names734 [] =
{
"item",
};

char *names735 [] =
{
"item",
};

char *names736 [] =
{
"item",
};

char *names737 [] =
{
"item",
};

char *names738 [] =
{
"item",
};

char *names739 [] =
{
"item",
};

char *names740 [] =
{
"item",
};

char *names741 [] =
{
"item",
};

char *names742 [] =
{
"item",
};

char *names743 [] =
{
"item",
};

char *names744 [] =
{
"item",
};

char *names745 [] =
{
"item",
};

char *names746 [] =
{
"item",
};

char *names747 [] =
{
"item",
};

char *names748 [] =
{
"item",
};

char *names749 [] =
{
"item",
};

char *names750 [] =
{
"item",
};

char *names751 [] =
{
"item",
};

char *names752 [] =
{
"item",
};

char *names753 [] =
{
"item",
};

char *names754 [] =
{
"item",
};

char *names755 [] =
{
"item",
};

char *names756 [] =
{
"item",
};

char *names757 [] =
{
"item",
};

char *names758 [] =
{
"item",
};

char *names759 [] =
{
"to_pointer",
};

char *names760 [] =
{
"to_pointer",
};

char *names761 [] =
{
"to_pointer",
};

char *names762 [] =
{
"to_pointer",
};

char *names763 [] =
{
"to_pointer",
};

char *names764 [] =
{
"to_pointer",
};

char *names765 [] =
{
"to_pointer",
};

char *names766 [] =
{
"to_pointer",
};

char *names767 [] =
{
"to_pointer",
};

char *names768 [] =
{
"to_pointer",
};

char *names769 [] =
{
"to_pointer",
};

char *names770 [] =
{
"to_pointer",
};

char *names771 [] =
{
"to_pointer",
};

char *names772 [] =
{
"to_pointer",
};

char *names773 [] =
{
"to_pointer",
};

char *names774 [] =
{
"to_pointer",
};

char *names775 [] =
{
"to_pointer",
};

char *names776 [] =
{
"to_pointer",
};

char *names777 [] =
{
"to_pointer",
};

char *names778 [] =
{
"to_pointer",
};

char *names779 [] =
{
"to_pointer",
};

char *names780 [] =
{
"to_pointer",
};

char *names781 [] =
{
"to_pointer",
};

char *names782 [] =
{
"to_pointer",
};

char *names783 [] =
{
"to_pointer",
};

char *names784 [] =
{
"to_pointer",
};

char *names785 [] =
{
"to_pointer",
};

char *names786 [] =
{
"to_pointer",
};

char *names787 [] =
{
"to_pointer",
};

char *names788 [] =
{
"to_pointer",
};

char *names789 [] =
{
"item",
};

char *names790 [] =
{
"item",
};

char *names791 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names792 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names793 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"last_result",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names794 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names795 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names796 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names797 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names798 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names799 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names800 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names801 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names802 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names803 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names804 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names806 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names807 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names808 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names809 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names811 [] =
{
"medium",
"last_line",
};

char *names812 [] =
{
"medium",
};

char *names813 [] =
{
"top_callstack_record",
"bottom_callstack_record",
"replayed_call",
"replay_stack",
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"is_replaying",
"last_replay_operation_failed",
"record_count",
"maximum_record_count",
};



#ifdef __cplusplus
}
#endif
