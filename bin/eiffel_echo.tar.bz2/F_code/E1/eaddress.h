#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F43_5226(EIF_REFERENCE, EIF_REFERENCE);
extern void F682_3217(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F682_3218(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F673_3144(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif
