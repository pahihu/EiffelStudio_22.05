#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names2[];
static const uint32 types2 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags2 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype2_0 [] = {0xFF01,675,789,0xFF01,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_1 [] = {0xFF01,672,0xFF01,801,0xFF01,801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes2 [] = {
g_atype2_0,
g_atype2_1,
};

static const long offsets2 [] =
{
0,
 + @REFACS(1),
};

extern const char *names4[];
static const uint32 types4 [] =
{
SK_UINT32,
};

static const uint16 attr_flags4 [] =
{1,};

static const EIF_TYPE_INDEX g_atype4_0 [] = {738,0xFFFF};

static const EIF_TYPE_INDEX *gtypes4 [] = {
g_atype4_0,
};

static const long offsets4 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names6[];
static const uint32 types6 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags6 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype6_0 [] = {0xFF01,716,0xFFFF};
static const EIF_TYPE_INDEX g_atype6_1 [] = {799,0xFFFF};

static const EIF_TYPE_INDEX *gtypes6 [] = {
g_atype6_0,
g_atype6_1,
};

static const long offsets6 [] =
{
0,
 + @REFACS(1),
};

extern const char *names7[];
static const uint32 types7 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags7 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype7_0 [] = {0xFF01,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype7_1 [] = {0xFF01,806,0xFFFF};

static const EIF_TYPE_INDEX *gtypes7 [] = {
g_atype7_0,
g_atype7_1,
};

static const long offsets7 [] =
{
0,
 + @REFACS(1),
};

extern const char *names10[];
static const uint32 types10 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags10 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype10_0 [] = {0xFF01,671,0xFF01,716,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes10 [] = {
g_atype10_0,
g_atype10_1,
g_atype10_2,
};

static const long offsets10 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names12[];
static const uint32 types12 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags12 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype12_0 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes12 [] = {
g_atype12_0,
g_atype12_1,
g_atype12_2,
g_atype12_3,
};

static const long offsets12 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
};

static const uint16 attr_flags28 [] =
{0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {556,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
};

static const long offsets28 [] =
{
0,
};

extern const char *names30[];
static const uint32 types30 [] =
{
SK_REF,
};

static const uint16 attr_flags30 [] =
{0,};

static const EIF_TYPE_INDEX g_atype30_0 [] = {0xFF01,48,0xFFFF};

static const EIF_TYPE_INDEX *gtypes30 [] = {
g_atype30_0,
};

static const long offsets30 [] =
{
0,
};

extern const char *names33[];
static const uint32 types33 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags33 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype33_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_1 [] = {791,0xFF01,0xFFF9,1,715,0xFF01,134,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_2 [] = {791,0xFF01,0xFFF9,2,715,0xFF01,134,0xFF01,134,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_3 [] = {791,0xFF01,0xFFF9,1,715,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_4 [] = {659,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_5 [] = {676,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_11 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes33 [] = {
g_atype33_0,
g_atype33_1,
g_atype33_2,
g_atype33_3,
g_atype33_4,
g_atype33_5,
g_atype33_6,
g_atype33_7,
g_atype33_8,
g_atype33_9,
g_atype33_10,
g_atype33_11,
};

static const long offsets33 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags34 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {791,0xFF01,0xFFF9,1,715,0xFF01,134,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_2 [] = {791,0xFF01,0xFFF9,2,715,0xFF01,134,0xFF01,134,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_3 [] = {791,0xFF01,0xFFF9,1,715,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_4 [] = {659,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_5 [] = {676,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_11 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
g_atype34_2,
g_atype34_3,
g_atype34_4,
g_atype34_5,
g_atype34_6,
g_atype34_7,
g_atype34_8,
g_atype34_9,
g_atype34_10,
g_atype34_11,
};

static const long offsets34 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names35[];
static const uint32 types35 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags35 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype35_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes35 [] = {
g_atype35_0,
g_atype35_1,
g_atype35_2,
};

static const long offsets35 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names36[];
static const uint32 types36 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags36 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype36_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes36 [] = {
g_atype36_0,
g_atype36_1,
g_atype36_2,
};

static const long offsets36 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags43 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_1 [] = {0xFF01,659,0xFF01,5,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_2 [] = {0xFF01,659,0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_3 [] = {36,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_11 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_12 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_13 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_14 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_15 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
g_atype43_1,
g_atype43_2,
g_atype43_3,
g_atype43_4,
g_atype43_5,
g_atype43_6,
g_atype43_7,
g_atype43_8,
g_atype43_9,
g_atype43_10,
g_atype43_11,
g_atype43_12,
g_atype43_13,
g_atype43_14,
g_atype43_15,
};

static const long offsets43 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags44 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_1 [] = {0xFF01,659,0xFF01,5,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_2 [] = {0xFF01,659,0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_3 [] = {36,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_11 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_12 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_13 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_14 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_15 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
g_atype44_1,
g_atype44_2,
g_atype44_3,
g_atype44_4,
g_atype44_5,
g_atype44_6,
g_atype44_7,
g_atype44_8,
g_atype44_9,
g_atype44_10,
g_atype44_11,
g_atype44_12,
g_atype44_13,
g_atype44_14,
g_atype44_15,
};

static const long offsets44 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags45 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_1 [] = {0xFF01,659,0xFF01,5,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_2 [] = {0xFF01,659,0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_3 [] = {36,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_11 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_12 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_13 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_14 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_15 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
g_atype45_1,
g_atype45_2,
g_atype45_3,
g_atype45_4,
g_atype45_5,
g_atype45_6,
g_atype45_7,
g_atype45_8,
g_atype45_9,
g_atype45_10,
g_atype45_11,
g_atype45_12,
g_atype45_13,
g_atype45_14,
g_atype45_15,
};

static const long offsets45 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names53[];
static const uint32 types53 [] =
{
SK_REF,
};

static const uint16 attr_flags53 [] =
{0,};

static const EIF_TYPE_INDEX g_atype53_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes53 [] = {
g_atype53_0,
};

static const long offsets53 [] =
{
0,
};

extern const char *names54[];
static const uint32 types54 [] =
{
SK_INT32,
};

static const uint16 attr_flags54 [] =
{0,};

static const EIF_TYPE_INDEX g_atype54_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes54 [] = {
g_atype54_0,
};

static const long offsets54 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names55[];
static const uint32 types55 [] =
{
SK_UINT64,
};

static const uint16 attr_flags55 [] =
{0,};

static const EIF_TYPE_INDEX g_atype55_0 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes55 [] = {
g_atype55_0,
};

static const long offsets55 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names56[];
static const uint32 types56 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags56 [] =
{0,};

static const EIF_TYPE_INDEX g_atype56_0 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes56 [] = {
g_atype56_0,
};

static const long offsets56 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags57 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_1 [] = {56,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
g_atype57_1,
};

static const long offsets57 [] =
{
0,
 + @REFACS(1),
};

extern const char *names58[];
static const uint32 types58 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags58 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype58_0 [] = {57,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes58 [] = {
g_atype58_0,
g_atype58_1,
};

static const long offsets58 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names69[];
static const uint32 types69 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags69 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype69_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype69_1 [] = {569,0xFF01,570,726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes69 [] = {
g_atype69_0,
g_atype69_1,
};

static const long offsets69 [] =
{
0,
 + @REFACS(1),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags70 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {569,0xFF01,570,726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
};

static const long offsets70 [] =
{
0,
 + @REFACS(1),
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags71 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_1 [] = {569,0xFF01,570,726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
g_atype71_1,
};

static const long offsets71 [] =
{
0,
 + @REFACS(1),
};

extern const char *names73[];
static const uint32 types73 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags73 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype73_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_1 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_2 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_3 [] = {0xFF01,578,735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes73 [] = {
g_atype73_0,
g_atype73_1,
g_atype73_2,
g_atype73_3,
};

static const long offsets73 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names74[];
static const uint32 types74 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags74 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype74_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_1 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes74 [] = {
g_atype74_0,
g_atype74_1,
g_atype74_2,
g_atype74_3,
g_atype74_4,
g_atype74_5,
g_atype74_6,
};

static const long offsets74 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names75[];
static const uint32 types75 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags75 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype75_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_1 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_2 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_9 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_10 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes75 [] = {
g_atype75_0,
g_atype75_1,
g_atype75_2,
g_atype75_3,
g_atype75_4,
g_atype75_5,
g_atype75_6,
g_atype75_7,
g_atype75_8,
g_atype75_9,
g_atype75_10,
};

static const long offsets75 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names76[];
static const uint32 types76 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags76 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype76_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_1 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_8 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_9 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes76 [] = {
g_atype76_0,
g_atype76_1,
g_atype76_2,
g_atype76_3,
g_atype76_4,
g_atype76_5,
g_atype76_6,
g_atype76_7,
g_atype76_8,
g_atype76_9,
};

static const long offsets76 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags77 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_1 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_12 [] = {750,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_13 [] = {750,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_14 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
g_atype77_1,
g_atype77_2,
g_atype77_3,
g_atype77_4,
g_atype77_5,
g_atype77_6,
g_atype77_7,
g_atype77_8,
g_atype77_9,
g_atype77_10,
g_atype77_11,
g_atype77_12,
g_atype77_13,
g_atype77_14,
};

static const long offsets77 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names79[];
static const uint32 types79 [] =
{
SK_REF,
};

static const uint16 attr_flags79 [] =
{0,};

static const EIF_TYPE_INDEX g_atype79_0 [] = {0xFF01,659,0xFF01,795,0xFFFF};

static const EIF_TYPE_INDEX *gtypes79 [] = {
g_atype79_0,
};

static const long offsets79 [] =
{
0,
};

extern const char *names83[];
static const uint32 types83 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags83 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype83_0 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes83 [] = {
g_atype83_0,
g_atype83_1,
};

static const long offsets83 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names85[];
static const uint32 types85 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags85 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype85_0 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes85 [] = {
g_atype85_0,
g_atype85_1,
g_atype85_2,
};

static const long offsets85 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags86 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {57,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
g_atype86_1,
g_atype86_2,
};

static const long offsets86 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names87[];
static const uint32 types87 [] =
{
SK_INT32,
};

static const uint16 attr_flags87 [] =
{0,};

static const EIF_TYPE_INDEX g_atype87_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes87 [] = {
g_atype87_0,
};

static const long offsets87 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names88[];
static const uint32 types88 [] =
{
SK_INT32,
};

static const uint16 attr_flags88 [] =
{0,};

static const EIF_TYPE_INDEX g_atype88_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes88 [] = {
g_atype88_0,
};

static const long offsets88 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names91[];
static const uint32 types91 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags91 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype91_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes91 [] = {
g_atype91_0,
g_atype91_1,
g_atype91_2,
g_atype91_3,
g_atype91_4,
g_atype91_5,
g_atype91_6,
};

static const long offsets91 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names92[];
static const uint32 types92 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags92 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype92_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes92 [] = {
g_atype92_0,
g_atype92_1,
g_atype92_2,
g_atype92_3,
g_atype92_4,
g_atype92_5,
g_atype92_6,
};

static const long offsets92 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names93[];
static const uint32 types93 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags93 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype93_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes93 [] = {
g_atype93_0,
g_atype93_1,
g_atype93_2,
g_atype93_3,
g_atype93_4,
g_atype93_5,
g_atype93_6,
};

static const long offsets93 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names94[];
static const uint32 types94 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags94 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype94_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes94 [] = {
g_atype94_0,
g_atype94_1,
g_atype94_2,
g_atype94_3,
g_atype94_4,
g_atype94_5,
g_atype94_6,
};

static const long offsets94 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags95 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
g_atype95_1,
g_atype95_2,
g_atype95_3,
g_atype95_4,
g_atype95_5,
g_atype95_6,
};

static const long offsets95 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags96 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
g_atype96_3,
g_atype96_4,
g_atype96_5,
g_atype96_6,
};

static const long offsets96 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags97 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
g_atype97_1,
g_atype97_2,
g_atype97_3,
g_atype97_4,
g_atype97_5,
g_atype97_6,
};

static const long offsets97 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names98[];
static const uint32 types98 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags98 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype98_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes98 [] = {
g_atype98_0,
g_atype98_1,
g_atype98_2,
g_atype98_3,
g_atype98_4,
g_atype98_5,
g_atype98_6,
g_atype98_7,
};

static const long offsets98 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names99[];
static const uint32 types99 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags99 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype99_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_5 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_9 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes99 [] = {
g_atype99_0,
g_atype99_1,
g_atype99_2,
g_atype99_3,
g_atype99_4,
g_atype99_5,
g_atype99_6,
g_atype99_7,
g_atype99_8,
g_atype99_9,
};

static const long offsets99 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags100 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
g_atype100_1,
g_atype100_2,
g_atype100_3,
g_atype100_4,
g_atype100_5,
g_atype100_6,
g_atype100_7,
};

static const long offsets100 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags101 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
g_atype101_1,
g_atype101_2,
g_atype101_3,
g_atype101_4,
g_atype101_5,
g_atype101_6,
};

static const long offsets101 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags102 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
g_atype102_1,
g_atype102_2,
g_atype102_3,
g_atype102_4,
g_atype102_5,
g_atype102_6,
};

static const long offsets102 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags103 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
g_atype103_1,
g_atype103_2,
g_atype103_3,
g_atype103_4,
g_atype103_5,
g_atype103_6,
};

static const long offsets103 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags104 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
g_atype104_1,
g_atype104_2,
g_atype104_3,
g_atype104_4,
g_atype104_5,
g_atype104_6,
};

static const long offsets104 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names105[];
static const uint32 types105 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags105 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype105_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes105 [] = {
g_atype105_0,
g_atype105_1,
g_atype105_2,
g_atype105_3,
g_atype105_4,
g_atype105_5,
g_atype105_6,
};

static const long offsets105 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names106[];
static const uint32 types106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags106 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype106_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes106 [] = {
g_atype106_0,
g_atype106_1,
g_atype106_2,
g_atype106_3,
g_atype106_4,
g_atype106_5,
g_atype106_6,
g_atype106_7,
};

static const long offsets106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags107 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
g_atype107_1,
g_atype107_2,
g_atype107_3,
g_atype107_4,
g_atype107_5,
g_atype107_6,
};

static const long offsets107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names108[];
static const uint32 types108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags108 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype108_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes108 [] = {
g_atype108_0,
g_atype108_1,
g_atype108_2,
g_atype108_3,
g_atype108_4,
g_atype108_5,
g_atype108_6,
};

static const long offsets108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags109 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
g_atype109_1,
g_atype109_2,
g_atype109_3,
g_atype109_4,
g_atype109_5,
g_atype109_6,
};

static const long offsets109 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags110 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
g_atype110_1,
g_atype110_2,
g_atype110_3,
g_atype110_4,
g_atype110_5,
g_atype110_6,
};

static const long offsets110 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names111[];
static const uint32 types111 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags111 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype111_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes111 [] = {
g_atype111_0,
g_atype111_1,
g_atype111_2,
g_atype111_3,
g_atype111_4,
g_atype111_5,
g_atype111_6,
g_atype111_7,
};

static const long offsets111 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags112 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
g_atype112_1,
g_atype112_2,
g_atype112_3,
g_atype112_4,
g_atype112_5,
g_atype112_6,
};

static const long offsets112 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags113 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_8 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
g_atype113_2,
g_atype113_3,
g_atype113_4,
g_atype113_5,
g_atype113_6,
g_atype113_7,
g_atype113_8,
};

static const long offsets113 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags114 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
g_atype114_1,
g_atype114_2,
g_atype114_3,
g_atype114_4,
g_atype114_5,
g_atype114_6,
};

static const long offsets114 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags115 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
g_atype115_2,
g_atype115_3,
g_atype115_4,
g_atype115_5,
g_atype115_6,
};

static const long offsets115 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names116[];
static const uint32 types116 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags116 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype116_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes116 [] = {
g_atype116_0,
g_atype116_1,
g_atype116_2,
g_atype116_3,
g_atype116_4,
g_atype116_5,
g_atype116_6,
};

static const long offsets116 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names117[];
static const uint32 types117 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags117 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype117_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes117 [] = {
g_atype117_0,
g_atype117_1,
g_atype117_2,
g_atype117_3,
g_atype117_4,
g_atype117_5,
g_atype117_6,
};

static const long offsets117 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names118[];
static const uint32 types118 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags118 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype118_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes118 [] = {
g_atype118_0,
g_atype118_1,
g_atype118_2,
g_atype118_3,
g_atype118_4,
g_atype118_5,
g_atype118_6,
};

static const long offsets118 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names119[];
static const uint32 types119 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags119 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype119_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_5 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_6 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_8 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes119 [] = {
g_atype119_0,
g_atype119_1,
g_atype119_2,
g_atype119_3,
g_atype119_4,
g_atype119_5,
g_atype119_6,
g_atype119_7,
g_atype119_8,
};

static const long offsets119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names120[];
static const uint32 types120 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags120 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype120_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes120 [] = {
g_atype120_0,
g_atype120_1,
g_atype120_2,
g_atype120_3,
g_atype120_4,
g_atype120_5,
g_atype120_6,
};

static const long offsets120 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names121[];
static const uint32 types121 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags121 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype121_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes121 [] = {
g_atype121_0,
g_atype121_1,
g_atype121_2,
g_atype121_3,
g_atype121_4,
g_atype121_5,
g_atype121_6,
};

static const long offsets121 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags122 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
g_atype122_1,
g_atype122_2,
g_atype122_3,
g_atype122_4,
g_atype122_5,
g_atype122_6,
};

static const long offsets122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags123 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
g_atype123_1,
g_atype123_2,
g_atype123_3,
g_atype123_4,
g_atype123_5,
g_atype123_6,
};

static const long offsets123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags124 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
g_atype124_1,
g_atype124_2,
g_atype124_3,
g_atype124_4,
g_atype124_5,
g_atype124_6,
};

static const long offsets124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags125 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
g_atype125_1,
g_atype125_2,
g_atype125_3,
g_atype125_4,
g_atype125_5,
g_atype125_6,
};

static const long offsets125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags126 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
g_atype126_1,
g_atype126_2,
g_atype126_3,
g_atype126_4,
g_atype126_5,
g_atype126_6,
};

static const long offsets126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags127 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
g_atype127_2,
g_atype127_3,
g_atype127_4,
g_atype127_5,
g_atype127_6,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
g_atype128_2,
g_atype128_3,
g_atype128_4,
g_atype128_5,
g_atype128_6,
g_atype128_7,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags129 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
g_atype129_2,
g_atype129_3,
g_atype129_4,
g_atype129_5,
g_atype129_6,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags130 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {90,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_3 [] = {82,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_4 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
g_atype130_3,
g_atype130_4,
g_atype130_5,
g_atype130_6,
};

static const long offsets130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags132 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_3 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
g_atype132_1,
g_atype132_2,
g_atype132_3,
};

static const long offsets132 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags133 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_1 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_2 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_3 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_4 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_5 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_6 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_9 [] = {747,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_10 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_11 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_12 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
g_atype133_1,
g_atype133_2,
g_atype133_3,
g_atype133_4,
g_atype133_5,
g_atype133_6,
g_atype133_7,
g_atype133_8,
g_atype133_9,
g_atype133_10,
g_atype133_11,
g_atype133_12,
};

static const long offsets133 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_INT32,
};

static const uint16 attr_flags135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
};

static const long offsets135 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {0xFF01,134,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
};

static const long offsets139 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
};

static const long offsets140 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
};

static const uint16 attr_flags141 [] =
{0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
};

static const long offsets141 [] =
{
0,
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
};

static const uint16 attr_flags142 [] =
{0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {0xFF01,570,726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
};

static const long offsets142 [] =
{
0,
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
};

static const uint16 attr_flags143 [] =
{0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {0xFF01,571,753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
};

static const long offsets143 [] =
{
0,
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
};

static const uint16 attr_flags144 [] =
{0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {0xFF01,572,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
};

static const long offsets144 [] =
{
0,
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
};

static const uint16 attr_flags145 [] =
{0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {0xFF01,573,747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
};

static const long offsets145 [] =
{
0,
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
};

static const uint16 attr_flags146 [] =
{0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {0xFF01,574,750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
};

static const long offsets146 [] =
{
0,
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
};

static const uint16 attr_flags147 [] =
{0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {0xFF01,575,741,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
};

static const long offsets147 [] =
{
0,
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
};

static const uint16 attr_flags148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {0xFF01,576,744,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
};

static const long offsets148 [] =
{
0,
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
};

static const uint16 attr_flags149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {0xFF01,577,720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
};

static const long offsets149 [] =
{
0,
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
};

static const uint16 attr_flags150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {0xFF01,578,735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
};

static const long offsets150 [] =
{
0,
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
};

static const uint16 attr_flags151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {0xFF01,579,756,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
};

static const long offsets151 [] =
{
0,
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
};

static const uint16 attr_flags152 [] =
{0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {0xFF01,580,738,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
};

static const long offsets152 [] =
{
0,
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
g_atype154_5,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
};

static const long offsets155 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
};

static const long offsets156 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags158 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_4 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
g_atype158_2,
g_atype158_3,
g_atype158_4,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names160[];
static const uint32 types160 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags160 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype160_0 [] = {0xFF01,812,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_2 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_3 [] = {159,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_4 [] = {0xFF01,667,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_5 [] = {659,159,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_6 [] = {659,0xFF01,161,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_7 [] = {0xFF01,0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_11 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_14 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes160 [] = {
g_atype160_0,
g_atype160_1,
g_atype160_2,
g_atype160_3,
g_atype160_4,
g_atype160_5,
g_atype160_6,
g_atype160_7,
g_atype160_8,
g_atype160_9,
g_atype160_10,
g_atype160_11,
g_atype160_12,
g_atype160_13,
g_atype160_14,
};

static const long offsets160 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags162 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
g_atype162_1,
g_atype162_2,
};

static const long offsets162 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
g_atype163_3,
g_atype163_4,
g_atype163_5,
};

static const long offsets163 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags164 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_5 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
g_atype164_1,
g_atype164_2,
g_atype164_3,
g_atype164_4,
g_atype164_5,
};

static const long offsets164 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags165 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
g_atype165_3,
g_atype165_4,
g_atype165_5,
};

static const long offsets165 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags166 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
g_atype166_3,
g_atype166_4,
g_atype166_5,
};

static const long offsets166 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags167 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
g_atype167_2,
g_atype167_3,
g_atype167_4,
g_atype167_5,
};

static const long offsets167 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags168 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
g_atype168_2,
g_atype168_3,
g_atype168_4,
g_atype168_5,
};

static const long offsets168 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags169 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
g_atype169_3,
g_atype169_4,
g_atype169_5,
};

static const long offsets169 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags170 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {753,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
g_atype170_3,
g_atype170_4,
g_atype170_5,
};

static const long offsets170 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags171 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
g_atype171_3,
g_atype171_4,
g_atype171_5,
};

static const long offsets171 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags172 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_5 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
g_atype172_1,
g_atype172_2,
g_atype172_3,
g_atype172_4,
g_atype172_5,
};

static const long offsets172 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags173 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_5 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
g_atype173_3,
g_atype173_4,
g_atype173_5,
};

static const long offsets173 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags174 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
g_atype174_1,
g_atype174_2,
g_atype174_3,
g_atype174_4,
g_atype174_5,
};

static const long offsets174 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_1 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
g_atype175_1,
g_atype175_2,
g_atype175_3,
g_atype175_4,
g_atype175_5,
};

static const long offsets175 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags176 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
g_atype176_1,
g_atype176_2,
g_atype176_3,
g_atype176_4,
g_atype176_5,
};

static const long offsets176 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags177 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_5 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
g_atype177_2,
g_atype177_3,
g_atype177_4,
g_atype177_5,
};

static const long offsets177 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags178 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
g_atype178_2,
g_atype178_3,
g_atype178_4,
g_atype178_5,
};

static const long offsets178 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags179 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_5 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
g_atype179_2,
g_atype179_3,
g_atype179_4,
g_atype179_5,
};

static const long offsets179 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
g_atype180_4,
g_atype180_5,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {753,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags184 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
g_atype184_2,
g_atype184_3,
g_atype184_4,
g_atype184_5,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags189 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_5 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
g_atype189_1,
g_atype189_2,
g_atype189_3,
g_atype189_4,
g_atype189_5,
};

static const long offsets189 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
g_atype190_4,
g_atype190_5,
};

static const long offsets190 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags191 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_5 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
g_atype191_3,
g_atype191_4,
g_atype191_5,
};

static const long offsets191 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags192 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
g_atype192_1,
g_atype192_2,
g_atype192_3,
g_atype192_4,
g_atype192_5,
};

static const long offsets192 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags193 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
g_atype193_1,
g_atype193_2,
g_atype193_3,
g_atype193_4,
};

static const long offsets193 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags194 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
g_atype194_2,
g_atype194_3,
g_atype194_4,
};

static const long offsets194 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags195 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_2 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
g_atype195_1,
g_atype195_2,
g_atype195_3,
g_atype195_4,
};

static const long offsets195 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags196 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_2 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
g_atype196_1,
g_atype196_2,
g_atype196_3,
g_atype196_4,
};

static const long offsets196 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags197 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_4 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
g_atype197_1,
g_atype197_2,
g_atype197_3,
g_atype197_4,
};

static const long offsets197 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags198 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
g_atype198_1,
g_atype198_2,
g_atype198_3,
g_atype198_4,
};

static const long offsets198 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags199 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_4 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
g_atype199_2,
g_atype199_3,
g_atype199_4,
};

static const long offsets199 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
g_atype200_3,
g_atype200_4,
};

static const long offsets200 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
g_atype201_4,
};

static const long offsets201 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags202 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_2 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
g_atype202_1,
g_atype202_2,
g_atype202_3,
g_atype202_4,
};

static const long offsets202 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
};

static const long offsets203 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags204 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
g_atype204_3,
g_atype204_4,
};

static const long offsets204 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_4 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
g_atype205_4,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {753,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {0xFFF9,2,715,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags221 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {0xFFF5,1,0xFF01,569,0xFFF8,1,2281,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {0xFFF5,1,0xFF01,658,0xFFF8,1,2428,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
};

static const long offsets221 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names222[];
static const uint32 types222 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags222 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype222_0 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes222 [] = {
g_atype222_0,
g_atype222_1,
};

static const long offsets222 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags243 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
g_atype243_3,
};

static const long offsets243 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags274 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {0xFF01,557,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
g_atype274_3,
g_atype274_4,
g_atype274_5,
g_atype274_6,
};

static const long offsets274 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags275 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {0xFF01,558,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
g_atype275_3,
g_atype275_4,
g_atype275_5,
g_atype275_6,
};

static const long offsets275 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {0xFF01,559,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
g_atype276_3,
g_atype276_4,
g_atype276_5,
g_atype276_6,
};

static const long offsets276 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags277 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {0xFF01,560,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
g_atype277_1,
g_atype277_2,
g_atype277_3,
g_atype277_4,
g_atype277_5,
g_atype277_6,
};

static const long offsets277 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags278 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFF01,561,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
g_atype278_3,
g_atype278_4,
g_atype278_5,
g_atype278_6,
};

static const long offsets278 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags279 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFF01,562,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
g_atype279_3,
g_atype279_4,
g_atype279_5,
g_atype279_6,
};

static const long offsets279 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags280 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFF01,563,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
g_atype280_2,
g_atype280_3,
g_atype280_4,
g_atype280_5,
g_atype280_6,
};

static const long offsets280 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags281 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFF01,564,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
g_atype281_2,
g_atype281_3,
g_atype281_4,
g_atype281_5,
g_atype281_6,
};

static const long offsets281 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {0xFF01,565,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
g_atype282_4,
g_atype282_5,
g_atype282_6,
};

static const long offsets282 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags283 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {0xFF01,566,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
g_atype283_3,
g_atype283_4,
g_atype283_5,
g_atype283_6,
};

static const long offsets283 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {0xFF01,567,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
g_atype284_1,
g_atype284_2,
g_atype284_3,
g_atype284_4,
g_atype284_5,
g_atype284_6,
};

static const long offsets284 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags285 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {0xFF01,568,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
g_atype285_1,
g_atype285_2,
g_atype285_3,
g_atype285_4,
g_atype285_5,
g_atype285_6,
};

static const long offsets285 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags286 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFF01,654,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
g_atype286_3,
g_atype286_4,
g_atype286_5,
g_atype286_6,
g_atype286_7,
};

static const long offsets286 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {0xFF01,655,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {57,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_7 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
g_atype287_4,
g_atype287_5,
g_atype287_6,
g_atype287_7,
};

static const long offsets287 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,672,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
g_atype288_5,
g_atype288_6,
};

static const long offsets288 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags289 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFF01,673,0xFFF8,1,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
g_atype289_6,
};

static const long offsets289 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFF01,674,726,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
g_atype290_6,
};

static const long offsets290 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFF01,675,789,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
g_atype291_6,
};

static const long offsets291 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFF01,676,726,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
g_atype292_6,
};

static const long offsets292 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFF01,677,720,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_6 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
g_atype293_6,
};

static const long offsets293 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
};

static const long offsets294 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
};

static const long offsets295 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags296 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
};

static const long offsets296 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags297 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
};

static const long offsets297 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
};

static const long offsets298 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
};

static const long offsets299 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags300 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
};

static const long offsets300 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags301 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
};

static const long offsets301 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags302 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
};

static const long offsets302 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags303 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
};

static const long offsets303 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags304 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
g_atype304_2,
};

static const long offsets304 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
g_atype305_2,
};

static const long offsets305 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags306 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {0xFF01,659,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
g_atype306_3,
};

static const long offsets306 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names307[];
static const uint32 types307 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags307 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype307_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_1 [] = {0xFF01,660,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes307 [] = {
g_atype307_0,
g_atype307_1,
g_atype307_2,
g_atype307_3,
};

static const long offsets307 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {0xFF01,661,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
};

static const long offsets308 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {0xFF01,662,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {0xFF01,663,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
};

static const long offsets310 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {0xFF01,664,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {0xFF01,665,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,666,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {0xFF01,667,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {0xFF01,668,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags316 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {0xFF01,669,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
g_atype316_3,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {0xFF01,670,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
};

static const long offsets317 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {0xFF01,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {0xFF01,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
g_atype319_4,
};

static const long offsets319 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {0xFF01,594,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {0xFF01,595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {0xFF01,596,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {0xFF01,597,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
g_atype323_4,
};

static const long offsets323 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {0xFF01,598,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {0xFF01,599,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {0xFF01,600,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {0xFF01,601,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
};

static const long offsets327 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_1 [] = {0xFF01,602,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
g_atype328_1,
g_atype328_2,
g_atype328_3,
g_atype328_4,
};

static const long offsets328 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {0xFF01,603,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
};

static const long offsets329 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {0xFF01,604,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {0xFF01,605,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
};

static const long offsets331 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
};

static const long offsets332 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
};

static const long offsets333 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags334 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
g_atype334_2,
};

static const long offsets334 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags335 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
};

static const long offsets335 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
};

static const long offsets336 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
};

static const long offsets337 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags338 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
};

static const long offsets338 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags339 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
};

static const long offsets339 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags340 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
g_atype340_2,
};

static const long offsets340 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
};

static const long offsets341 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags342 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
};

static const long offsets342 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
};

static const long offsets343 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_BOOL,
};

static const uint16 attr_flags344 [] =
{0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
};

static const long offsets344 [] =
{
+ @CHROFF(0,0),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_BOOL,
};

static const uint16 attr_flags345 [] =
{0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
};

static const long offsets345 [] =
{
+ @CHROFF(0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_BOOL,
};

static const uint16 attr_flags346 [] =
{0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
};

static const long offsets346 [] =
{
+ @CHROFF(0,0),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_BOOL,
};

static const uint16 attr_flags347 [] =
{0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
};

static const long offsets347 [] =
{
+ @CHROFF(0,0),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_BOOL,
};

static const uint16 attr_flags348 [] =
{0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
};

static const long offsets348 [] =
{
+ @CHROFF(0,0),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_BOOL,
};

static const uint16 attr_flags349 [] =
{0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
};

static const long offsets349 [] =
{
+ @CHROFF(0,0),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_BOOL,
};

static const uint16 attr_flags350 [] =
{0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
};

static const long offsets350 [] =
{
+ @CHROFF(0,0),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_BOOL,
};

static const uint16 attr_flags351 [] =
{0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
};

static const long offsets351 [] =
{
+ @CHROFF(0,0),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_BOOL,
};

static const uint16 attr_flags352 [] =
{0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
};

static const long offsets352 [] =
{
+ @CHROFF(0,0),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_BOOL,
};

static const uint16 attr_flags353 [] =
{0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
};

static const long offsets353 [] =
{
+ @CHROFF(0,0),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_BOOL,
};

static const uint16 attr_flags354 [] =
{0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
};

static const long offsets354 [] =
{
+ @CHROFF(0,0),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_BOOL,
};

static const uint16 attr_flags355 [] =
{0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
};

static const long offsets355 [] =
{
+ @CHROFF(0,0),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_BOOL,
};

static const uint16 attr_flags356 [] =
{0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
};

static const long offsets356 [] =
{
+ @CHROFF(0,0),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_BOOL,
};

static const uint16 attr_flags357 [] =
{0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
};

static const long offsets357 [] =
{
+ @CHROFF(0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_BOOL,
};

static const uint16 attr_flags358 [] =
{0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
};

static const long offsets358 [] =
{
+ @CHROFF(0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_BOOL,
};

static const uint16 attr_flags359 [] =
{0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
};

static const long offsets359 [] =
{
+ @CHROFF(0,0),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_BOOL,
};

static const uint16 attr_flags360 [] =
{0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
};

static const long offsets360 [] =
{
+ @CHROFF(0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_BOOL,
};

static const uint16 attr_flags361 [] =
{0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
};

static const long offsets361 [] =
{
+ @CHROFF(0,0),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_BOOL,
};

static const uint16 attr_flags362 [] =
{0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
};

static const long offsets362 [] =
{
+ @CHROFF(0,0),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_BOOL,
};

static const uint16 attr_flags363 [] =
{0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
};

static const long offsets363 [] =
{
+ @CHROFF(0,0),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_BOOL,
};

static const uint16 attr_flags364 [] =
{0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
};

static const long offsets364 [] =
{
+ @CHROFF(0,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_BOOL,
};

static const uint16 attr_flags365 [] =
{0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
};

static const long offsets365 [] =
{
+ @CHROFF(0,0),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_BOOL,
};

static const uint16 attr_flags366 [] =
{0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
};

static const long offsets366 [] =
{
+ @CHROFF(0,0),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_BOOL,
};

static const uint16 attr_flags367 [] =
{0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
};

static const long offsets367 [] =
{
+ @CHROFF(0,0),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_BOOL,
};

static const uint16 attr_flags368 [] =
{0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
};

static const long offsets368 [] =
{
+ @CHROFF(0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_BOOL,
};

static const uint16 attr_flags369 [] =
{0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
};

static const long offsets369 [] =
{
+ @CHROFF(0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_BOOL,
};

static const uint16 attr_flags370 [] =
{0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
};

static const long offsets370 [] =
{
+ @CHROFF(0,0),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_BOOL,
};

static const uint16 attr_flags371 [] =
{0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
};

static const long offsets371 [] =
{
+ @CHROFF(0,0),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_BOOL,
};

static const uint16 attr_flags372 [] =
{0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
};

static const long offsets372 [] =
{
+ @CHROFF(0,0),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_BOOL,
};

static const uint16 attr_flags373 [] =
{0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
};

static const long offsets373 [] =
{
+ @CHROFF(0,0),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_BOOL,
};

static const uint16 attr_flags374 [] =
{0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
};

static const long offsets374 [] =
{
+ @CHROFF(0,0),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_BOOL,
};

static const uint16 attr_flags375 [] =
{0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
};

static const long offsets375 [] =
{
+ @CHROFF(0,0),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_BOOL,
};

static const uint16 attr_flags376 [] =
{0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
};

static const long offsets376 [] =
{
+ @CHROFF(0,0),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_BOOL,
};

static const uint16 attr_flags377 [] =
{0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
};

static const long offsets377 [] =
{
+ @CHROFF(0,0),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_BOOL,
};

static const uint16 attr_flags378 [] =
{0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
};

static const long offsets378 [] =
{
+ @CHROFF(0,0),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_BOOL,
};

static const uint16 attr_flags379 [] =
{0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
};

static const long offsets379 [] =
{
+ @CHROFF(0,0),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_BOOL,
};

static const uint16 attr_flags380 [] =
{0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
};

static const long offsets380 [] =
{
+ @CHROFF(0,0),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_BOOL,
};

static const uint16 attr_flags381 [] =
{0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
};

static const long offsets381 [] =
{
+ @CHROFF(0,0),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_BOOL,
};

static const uint16 attr_flags382 [] =
{0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
};

static const long offsets382 [] =
{
+ @CHROFF(0,0),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_BOOL,
};

static const uint16 attr_flags383 [] =
{0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
};

static const long offsets383 [] =
{
+ @CHROFF(0,0),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_BOOL,
};

static const uint16 attr_flags384 [] =
{0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
};

static const long offsets384 [] =
{
+ @CHROFF(0,0),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_BOOL,
};

static const uint16 attr_flags385 [] =
{0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
};

static const long offsets385 [] =
{
+ @CHROFF(0,0),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_BOOL,
};

static const uint16 attr_flags386 [] =
{0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
};

static const long offsets386 [] =
{
+ @CHROFF(0,0),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_BOOL,
};

static const uint16 attr_flags387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
};

static const long offsets387 [] =
{
+ @CHROFF(0,0),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_BOOL,
};

static const uint16 attr_flags388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
};

static const long offsets388 [] =
{
+ @CHROFF(0,0),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_BOOL,
};

static const uint16 attr_flags389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
};

static const long offsets389 [] =
{
+ @CHROFF(0,0),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_BOOL,
};

static const uint16 attr_flags390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
};

static const long offsets390 [] =
{
+ @CHROFF(0,0),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_BOOL,
};

static const uint16 attr_flags391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
};

static const long offsets391 [] =
{
+ @CHROFF(0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_BOOL,
};

static const uint16 attr_flags392 [] =
{0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
};

static const long offsets392 [] =
{
+ @CHROFF(0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_BOOL,
};

static const uint16 attr_flags393 [] =
{0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
};

static const long offsets393 [] =
{
+ @CHROFF(0,0),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_BOOL,
};

static const uint16 attr_flags394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
};

static const long offsets394 [] =
{
+ @CHROFF(0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_BOOL,
};

static const uint16 attr_flags395 [] =
{0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
};

static const long offsets395 [] =
{
+ @CHROFF(0,0),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_BOOL,
};

static const uint16 attr_flags396 [] =
{0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
};

static const long offsets396 [] =
{
+ @CHROFF(0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_BOOL,
};

static const uint16 attr_flags397 [] =
{0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
};

static const long offsets397 [] =
{
+ @CHROFF(0,0),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_BOOL,
};

static const uint16 attr_flags398 [] =
{0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
};

static const long offsets398 [] =
{
+ @CHROFF(0,0),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_BOOL,
};

static const uint16 attr_flags399 [] =
{0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
};

static const long offsets399 [] =
{
+ @CHROFF(0,0),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_BOOL,
};

static const uint16 attr_flags400 [] =
{0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
};

static const long offsets400 [] =
{
+ @CHROFF(0,0),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_BOOL,
};

static const uint16 attr_flags401 [] =
{0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
};

static const long offsets401 [] =
{
+ @CHROFF(0,0),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_BOOL,
};

static const uint16 attr_flags402 [] =
{0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
};

static const long offsets402 [] =
{
+ @CHROFF(0,0),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_BOOL,
};

static const uint16 attr_flags403 [] =
{0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
};

static const long offsets403 [] =
{
+ @CHROFF(0,0),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_BOOL,
};

static const uint16 attr_flags404 [] =
{0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
};

static const long offsets404 [] =
{
+ @CHROFF(0,0),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_BOOL,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
+ @CHROFF(0,0),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_BOOL,
};

static const uint16 attr_flags406 [] =
{0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
};

static const long offsets406 [] =
{
+ @CHROFF(0,0),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_BOOL,
};

static const uint16 attr_flags407 [] =
{0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
};

static const long offsets407 [] =
{
+ @CHROFF(0,0),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_BOOL,
};

static const uint16 attr_flags408 [] =
{0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
};

static const long offsets408 [] =
{
+ @CHROFF(0,0),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_BOOL,
};

static const uint16 attr_flags409 [] =
{0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
};

static const long offsets409 [] =
{
+ @CHROFF(0,0),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_BOOL,
};

static const uint16 attr_flags410 [] =
{0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
};

static const long offsets410 [] =
{
+ @CHROFF(0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_BOOL,
};

static const uint16 attr_flags411 [] =
{0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
};

static const long offsets411 [] =
{
+ @CHROFF(0,0),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_BOOL,
};

static const uint16 attr_flags412 [] =
{0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
};

static const long offsets412 [] =
{
+ @CHROFF(0,0),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_BOOL,
};

static const uint16 attr_flags413 [] =
{0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
};

static const long offsets413 [] =
{
+ @CHROFF(0,0),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_BOOL,
};

static const uint16 attr_flags414 [] =
{0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
};

static const long offsets414 [] =
{
+ @CHROFF(0,0),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_BOOL,
};

static const uint16 attr_flags415 [] =
{0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
};

static const long offsets415 [] =
{
+ @CHROFF(0,0),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_BOOL,
};

static const uint16 attr_flags416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
};

static const long offsets416 [] =
{
+ @CHROFF(0,0),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_BOOL,
};

static const uint16 attr_flags417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
};

static const long offsets417 [] =
{
+ @CHROFF(0,0),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_BOOL,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
+ @CHROFF(0,0),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_BOOL,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
+ @CHROFF(0,0),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_BOOL,
};

static const uint16 attr_flags420 [] =
{0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
};

static const long offsets420 [] =
{
+ @CHROFF(0,0),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_BOOL,
};

static const uint16 attr_flags421 [] =
{0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
};

static const long offsets421 [] =
{
+ @CHROFF(0,0),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_BOOL,
};

static const uint16 attr_flags422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
};

static const long offsets422 [] =
{
+ @CHROFF(0,0),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_BOOL,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
+ @CHROFF(0,0),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_BOOL,
};

static const uint16 attr_flags424 [] =
{0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
};

static const long offsets424 [] =
{
+ @CHROFF(0,0),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_BOOL,
};

static const uint16 attr_flags425 [] =
{0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
};

static const long offsets425 [] =
{
+ @CHROFF(0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_BOOL,
};

static const uint16 attr_flags426 [] =
{0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
};

static const long offsets426 [] =
{
+ @CHROFF(0,0),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_BOOL,
};

static const uint16 attr_flags427 [] =
{0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
};

static const long offsets427 [] =
{
+ @CHROFF(0,0),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_BOOL,
};

static const uint16 attr_flags428 [] =
{0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
};

static const long offsets428 [] =
{
+ @CHROFF(0,0),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_BOOL,
};

static const uint16 attr_flags429 [] =
{0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
};

static const long offsets429 [] =
{
+ @CHROFF(0,0),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_BOOL,
};

static const uint16 attr_flags430 [] =
{0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
};

static const long offsets430 [] =
{
+ @CHROFF(0,0),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_BOOL,
};

static const uint16 attr_flags431 [] =
{0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
};

static const long offsets431 [] =
{
+ @CHROFF(0,0),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_BOOL,
};

static const uint16 attr_flags432 [] =
{0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
};

static const long offsets432 [] =
{
+ @CHROFF(0,0),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_BOOL,
};

static const uint16 attr_flags433 [] =
{0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
};

static const long offsets433 [] =
{
+ @CHROFF(0,0),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_BOOL,
};

static const uint16 attr_flags434 [] =
{0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
};

static const long offsets434 [] =
{
+ @CHROFF(0,0),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_BOOL,
};

static const uint16 attr_flags435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
};

static const long offsets435 [] =
{
+ @CHROFF(0,0),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_BOOL,
};

static const uint16 attr_flags436 [] =
{0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
};

static const long offsets436 [] =
{
+ @CHROFF(0,0),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_BOOL,
};

static const uint16 attr_flags437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
};

static const long offsets437 [] =
{
+ @CHROFF(0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_BOOL,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @CHROFF(0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_BOOL,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @CHROFF(0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_BOOL,
};

static const uint16 attr_flags440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
};

static const long offsets440 [] =
{
+ @CHROFF(0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_BOOL,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @CHROFF(0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_BOOL,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @CHROFF(0,0),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_BOOL,
};

static const uint16 attr_flags443 [] =
{0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
};

static const long offsets443 [] =
{
+ @CHROFF(0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_BOOL,
};

static const uint16 attr_flags444 [] =
{0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
};

static const long offsets444 [] =
{
+ @CHROFF(0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
};

static const uint16 attr_flags445 [] =
{0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_BOOL,
};

static const uint16 attr_flags446 [] =
{0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
};

static const long offsets446 [] =
{
+ @CHROFF(0,0),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_BOOL,
};

static const uint16 attr_flags447 [] =
{0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
};

static const long offsets447 [] =
{
+ @CHROFF(0,0),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_BOOL,
};

static const uint16 attr_flags448 [] =
{0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
};

static const long offsets448 [] =
{
+ @CHROFF(0,0),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_BOOL,
};

static const uint16 attr_flags449 [] =
{0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
};

static const long offsets449 [] =
{
+ @CHROFF(0,0),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_BOOL,
};

static const uint16 attr_flags450 [] =
{0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
};

static const long offsets450 [] =
{
+ @CHROFF(0,0),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_BOOL,
};

static const uint16 attr_flags451 [] =
{0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
};

static const long offsets451 [] =
{
+ @CHROFF(0,0),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_BOOL,
};

static const uint16 attr_flags452 [] =
{0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
};

static const long offsets452 [] =
{
+ @CHROFF(0,0),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_BOOL,
};

static const uint16 attr_flags453 [] =
{0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
};

static const long offsets453 [] =
{
+ @CHROFF(0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_BOOL,
};

static const uint16 attr_flags454 [] =
{0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
};

static const long offsets454 [] =
{
+ @CHROFF(0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_BOOL,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @CHROFF(0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_BOOL,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
+ @CHROFF(0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags491 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
g_atype491_1,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags492 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
g_atype492_1,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags555 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_1 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_3 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_4 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_7 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_8 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_9 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_10 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_11 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_15 [] = {747,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_17 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_18 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_19 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
g_atype555_1,
g_atype555_2,
g_atype555_3,
g_atype555_4,
g_atype555_5,
g_atype555_6,
g_atype555_7,
g_atype555_8,
g_atype555_9,
g_atype555_10,
g_atype555_11,
g_atype555_12,
g_atype555_13,
g_atype555_14,
g_atype555_15,
g_atype555_16,
g_atype555_17,
g_atype555_18,
g_atype555_19,
};

static const long offsets555 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags556 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_1 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_3 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_4 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_5 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_8 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_9 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_10 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_11 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_12 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_16 [] = {747,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_18 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_19 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_20 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
g_atype556_1,
g_atype556_2,
g_atype556_3,
g_atype556_4,
g_atype556_5,
g_atype556_6,
g_atype556_7,
g_atype556_8,
g_atype556_9,
g_atype556_10,
g_atype556_11,
g_atype556_12,
g_atype556_13,
g_atype556_14,
g_atype556_15,
g_atype556_16,
g_atype556_17,
g_atype556_18,
g_atype556_19,
g_atype556_20,
};

static const long offsets556 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags557 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_1 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_3 [] = {0xFF01,800,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_4 [] = {6,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_5 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_6 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_10 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_11 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_12 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_13 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_14 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_17 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_18 [] = {747,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_20 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_21 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_22 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
g_atype557_1,
g_atype557_2,
g_atype557_3,
g_atype557_4,
g_atype557_5,
g_atype557_6,
g_atype557_7,
g_atype557_8,
g_atype557_9,
g_atype557_10,
g_atype557_11,
g_atype557_12,
g_atype557_13,
g_atype557_14,
g_atype557_15,
g_atype557_16,
g_atype557_17,
g_atype557_18,
g_atype557_19,
g_atype557_20,
g_atype557_21,
g_atype557_22,
};

static const long offsets557 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags594 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
g_atype594_1,
g_atype594_2,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags595 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
g_atype595_1,
g_atype595_2,
g_atype595_3,
};

static const long offsets595 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags596 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
g_atype596_1,
g_atype596_2,
g_atype596_3,
};

static const long offsets596 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags597 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype597_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype597_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype597_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
g_atype597_1,
g_atype597_2,
g_atype597_3,
};

static const long offsets597 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags598 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
g_atype598_1,
g_atype598_2,
g_atype598_3,
};

static const long offsets598 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags599 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
g_atype599_1,
g_atype599_2,
g_atype599_3,
};

static const long offsets599 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags600 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype600_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype600_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype600_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
g_atype600_1,
g_atype600_2,
g_atype600_3,
};

static const long offsets600 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags601 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype601_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype601_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype601_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
g_atype601_1,
g_atype601_2,
g_atype601_3,
};

static const long offsets601 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags602 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype602_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype602_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype602_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
g_atype602_1,
g_atype602_2,
g_atype602_3,
};

static const long offsets602 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags603 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype603_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype603_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype603_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
g_atype603_1,
g_atype603_2,
g_atype603_3,
};

static const long offsets603 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags604 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype604_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype604_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype604_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
g_atype604_1,
g_atype604_2,
g_atype604_3,
};

static const long offsets604 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags605 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype605_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype605_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype605_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
g_atype605_1,
g_atype605_2,
g_atype605_3,
};

static const long offsets605 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags606 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype606_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype606_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype606_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
g_atype606_1,
g_atype606_2,
g_atype606_3,
};

static const long offsets606 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags655 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_1 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype655_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
g_atype655_1,
g_atype655_2,
g_atype655_3,
g_atype655_4,
g_atype655_5,
};

static const long offsets655 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags656 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {57,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_1 [] = {57,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
g_atype656_1,
g_atype656_2,
g_atype656_3,
g_atype656_4,
g_atype656_5,
};

static const long offsets656 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags657 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_1 [] = {56,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
g_atype657_1,
g_atype657_2,
g_atype657_3,
g_atype657_4,
g_atype657_5,
};

static const long offsets657 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags659 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
g_atype659_1,
g_atype659_2,
g_atype659_3,
};

static const long offsets659 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags660 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
g_atype660_1,
g_atype660_2,
};

static const long offsets660 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags661 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
g_atype661_1,
g_atype661_2,
};

static const long offsets661 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags662 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
g_atype662_1,
g_atype662_2,
};

static const long offsets662 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags663 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
g_atype663_1,
g_atype663_2,
};

static const long offsets663 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags664 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {0xFF01,573,747,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
g_atype664_1,
g_atype664_2,
};

static const long offsets664 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags665 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {0xFF01,574,750,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
g_atype665_1,
g_atype665_2,
};

static const long offsets665 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags666 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {0xFF01,575,741,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
g_atype666_1,
g_atype666_2,
};

static const long offsets666 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags667 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {0xFF01,576,744,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
g_atype667_1,
g_atype667_2,
};

static const long offsets667 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags668 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
g_atype668_1,
g_atype668_2,
};

static const long offsets668 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags669 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {0xFF01,578,735,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
g_atype669_1,
g_atype669_2,
};

static const long offsets669 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags670 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
g_atype670_1,
g_atype670_2,
};

static const long offsets670 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags671 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {0xFF01,580,738,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
g_atype671_1,
g_atype671_2,
};

static const long offsets671 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags672 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_2 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
g_atype672_1,
g_atype672_2,
};

static const long offsets672 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags673 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_1 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_2 [] = {0xFF01,569,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_3 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_4 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_16 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
g_atype673_1,
g_atype673_2,
g_atype673_3,
g_atype673_4,
g_atype673_5,
g_atype673_6,
g_atype673_7,
g_atype673_8,
g_atype673_9,
g_atype673_10,
g_atype673_11,
g_atype673_12,
g_atype673_13,
g_atype673_14,
g_atype673_15,
g_atype673_16,
};

static const long offsets673 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags674 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_1 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_3 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_4 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_16 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
g_atype674_1,
g_atype674_2,
g_atype674_3,
g_atype674_4,
g_atype674_5,
g_atype674_6,
g_atype674_7,
g_atype674_8,
g_atype674_9,
g_atype674_10,
g_atype674_11,
g_atype674_12,
g_atype674_13,
g_atype674_14,
g_atype674_15,
g_atype674_16,
};

static const long offsets674 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags675 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_1 [] = {0xFF01,569,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_16 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
g_atype675_1,
g_atype675_2,
g_atype675_3,
g_atype675_4,
g_atype675_5,
g_atype675_6,
g_atype675_7,
g_atype675_8,
g_atype675_9,
g_atype675_10,
g_atype675_11,
g_atype675_12,
g_atype675_13,
g_atype675_14,
g_atype675_15,
g_atype675_16,
};

static const long offsets675 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags676 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {0xFF01,572,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_1 [] = {0xFF01,569,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_16 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
g_atype676_1,
g_atype676_2,
g_atype676_3,
g_atype676_4,
g_atype676_5,
g_atype676_6,
g_atype676_7,
g_atype676_8,
g_atype676_9,
g_atype676_10,
g_atype676_11,
g_atype676_12,
g_atype676_13,
g_atype676_14,
g_atype676_15,
g_atype676_16,
};

static const long offsets676 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags677 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_1 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_16 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
g_atype677_1,
g_atype677_2,
g_atype677_3,
g_atype677_4,
g_atype677_5,
g_atype677_6,
g_atype677_7,
g_atype677_8,
g_atype677_9,
g_atype677_10,
g_atype677_11,
g_atype677_12,
g_atype677_13,
g_atype677_14,
g_atype677_15,
g_atype677_16,
};

static const long offsets677 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags678 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_1 [] = {0xFF01,569,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_16 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
g_atype678_1,
g_atype678_2,
g_atype678_3,
g_atype678_4,
g_atype678_5,
g_atype678_6,
g_atype678_7,
g_atype678_8,
g_atype678_9,
g_atype678_10,
g_atype678_11,
g_atype678_12,
g_atype678_13,
g_atype678_14,
g_atype678_15,
g_atype678_16,
};

static const long offsets678 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags679 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_1 [] = {0xFF01,569,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_2 [] = {0xFF01,569,0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_3 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_4 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_6 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_17 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
g_atype679_1,
g_atype679_2,
g_atype679_3,
g_atype679_4,
g_atype679_5,
g_atype679_6,
g_atype679_7,
g_atype679_8,
g_atype679_9,
g_atype679_10,
g_atype679_11,
g_atype679_12,
g_atype679_13,
g_atype679_14,
g_atype679_15,
g_atype679_16,
g_atype679_17,
};

static const long offsets679 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags680 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_1 [] = {0xFF01,569,0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_4 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_10 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_17 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
g_atype680_1,
g_atype680_2,
g_atype680_3,
g_atype680_4,
g_atype680_5,
g_atype680_6,
g_atype680_7,
g_atype680_8,
g_atype680_9,
g_atype680_10,
g_atype680_11,
g_atype680_12,
g_atype680_13,
g_atype680_14,
g_atype680_15,
g_atype680_16,
g_atype680_17,
};

static const long offsets680 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags681 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_1 [] = {0xFF01,569,0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_2 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_3 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_4 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_17 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
g_atype681_1,
g_atype681_2,
g_atype681_3,
g_atype681_4,
g_atype681_5,
g_atype681_6,
g_atype681_7,
g_atype681_8,
g_atype681_9,
g_atype681_10,
g_atype681_11,
g_atype681_12,
g_atype681_13,
g_atype681_14,
g_atype681_15,
g_atype681_16,
g_atype681_17,
};

static const long offsets681 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags682 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_1 [] = {0xFF01,569,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_2 [] = {0xFF01,569,0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_3 [] = {0xFF01,570,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_4 [] = {0xFF01,577,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_6 [] = {803,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_7 [] = {802,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_8 [] = {802,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_10 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_11 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_12 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_13 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_14 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_17 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_18 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
g_atype682_1,
g_atype682_2,
g_atype682_3,
g_atype682_4,
g_atype682_5,
g_atype682_6,
g_atype682_7,
g_atype682_8,
g_atype682_9,
g_atype682_10,
g_atype682_11,
g_atype682_12,
g_atype682_13,
g_atype682_14,
g_atype682_15,
g_atype682_16,
g_atype682_17,
g_atype682_18,
};

static const long offsets682 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_1 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
g_atype684_1,
g_atype684_2,
};

static const long offsets684 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags685 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
g_atype685_1,
};

static const long offsets685 [] =
{
0,
 + @REFACS(1),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags686 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
g_atype686_1,
};

static const long offsets686 [] =
{
0,
 + @REFACS(1),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags687 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
g_atype687_1,
};

static const long offsets687 [] =
{
0,
 + @REFACS(1),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags688 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype688_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
g_atype688_1,
};

static const long offsets688 [] =
{
0,
 + @REFACS(1),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags689 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype689_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
g_atype689_1,
};

static const long offsets689 [] =
{
0,
 + @REFACS(1),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags690 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype690_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
g_atype690_1,
};

static const long offsets690 [] =
{
0,
 + @REFACS(1),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags691 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype691_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
g_atype691_1,
};

static const long offsets691 [] =
{
0,
 + @REFACS(1),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags692 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype692_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
g_atype692_1,
};

static const long offsets692 [] =
{
0,
 + @REFACS(1),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags693 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype693_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
g_atype693_1,
};

static const long offsets693 [] =
{
0,
 + @REFACS(1),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags694 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype694_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
g_atype694_1,
};

static const long offsets694 [] =
{
0,
 + @REFACS(1),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags695 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype695_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
g_atype695_1,
};

static const long offsets695 [] =
{
0,
 + @REFACS(1),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags696 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype696_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
g_atype696_1,
};

static const long offsets696 [] =
{
0,
 + @REFACS(1),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags697 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
g_atype697_1,
};

static const long offsets697 [] =
{
0,
 + @REFACS(1),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags698 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
};

static const long offsets698 [] =
{
0,
 + @REFACS(1),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags699 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
g_atype699_1,
};

static const long offsets699 [] =
{
0,
 + @REFACS(1),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags700 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
g_atype700_1,
};

static const long offsets700 [] =
{
0,
 + @REFACS(1),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags701 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
g_atype701_1,
};

static const long offsets701 [] =
{
0,
 + @REFACS(1),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags702 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
g_atype702_1,
};

static const long offsets702 [] =
{
0,
 + @REFACS(1),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags703 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
};

static const long offsets703 [] =
{
0,
 + @REFACS(1),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags704 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
};

static const long offsets704 [] =
{
0,
 + @REFACS(1),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags705 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
};

static const long offsets705 [] =
{
0,
 + @REFACS(1),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags706 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
};

static const long offsets706 [] =
{
0,
 + @REFACS(1),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags707 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
};

static const long offsets707 [] =
{
0,
 + @REFACS(1),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags708 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
};

static const long offsets708 [] =
{
0,
 + @REFACS(1),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags709 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
g_atype709_1,
};

static const long offsets709 [] =
{
0,
 + @REFACS(1),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags710 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
g_atype710_1,
};

static const long offsets710 [] =
{
0,
 + @REFACS(1),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags711 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
g_atype711_1,
};

static const long offsets711 [] =
{
0,
 + @REFACS(1),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags712 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
g_atype712_1,
};

static const long offsets712 [] =
{
0,
 + @REFACS(1),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags713 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
g_atype713_1,
};

static const long offsets713 [] =
{
0,
 + @REFACS(1),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags714 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
g_atype714_1,
};

static const long offsets714 [] =
{
0,
 + @REFACS(1),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags715 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {799,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_1 [] = {802,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
g_atype715_1,
};

static const long offsets715 [] =
{
0,
 + @REFACS(1),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags717 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_1 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_2 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_7 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
g_atype717_1,
g_atype717_2,
g_atype717_3,
g_atype717_4,
g_atype717_5,
g_atype717_6,
g_atype717_7,
};

static const long offsets717 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @LNGOFF(3,4,0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags718 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_1 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_2 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_3 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_4 [] = {0xFF01,799,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_10 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
g_atype718_1,
g_atype718_2,
g_atype718_3,
g_atype718_4,
g_atype718_5,
g_atype718_6,
g_atype718_7,
g_atype718_8,
g_atype718_9,
g_atype718_10,
};

static const long offsets718 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_INT64,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_INT64,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_INT64,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_INT32,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_INT32,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_INT32,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_INT16,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {729,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_INT16,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {729,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_INT16,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {729,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_INT8,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {732,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_INT8,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {732,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_INT8,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {732,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_UINT64,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_UINT64,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_UINT64,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {735,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_UINT32,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {738,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_UINT32,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {738,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_UINT32,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {738,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_UINT16,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {741,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_UINT16,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {741,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_UINT16,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {741,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_UINT8,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {744,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_UINT8,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {744,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_UINT8,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {744,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_REAL32,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_REAL32,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_REAL32,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {747,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_REAL64,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_REAL64,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_REAL64,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {753,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {756,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {756,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {756,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_POINTER,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_POINTER,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_POINTER,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_POINTER,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_POINTER,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_POINTER,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_POINTER,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_POINTER,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_POINTER,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_POINTER,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_POINTER,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_POINTER,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_POINTER,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_POINTER,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_POINTER,
};

static const uint16 attr_flags772 [] =
{0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
};

static const long offsets772 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_POINTER,
};

static const uint16 attr_flags773 [] =
{0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
};

static const long offsets773 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_POINTER,
};

static const uint16 attr_flags774 [] =
{0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
};

static const long offsets774 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_POINTER,
};

static const uint16 attr_flags775 [] =
{0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
};

static const long offsets775 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_POINTER,
};

static const uint16 attr_flags776 [] =
{0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
};

static const long offsets776 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_POINTER,
};

static const uint16 attr_flags777 [] =
{0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
};

static const long offsets777 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_POINTER,
};

static const uint16 attr_flags778 [] =
{0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
};

static const long offsets778 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_POINTER,
};

static const uint16 attr_flags779 [] =
{0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
};

static const long offsets779 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_POINTER,
};

static const uint16 attr_flags780 [] =
{0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
};

static const long offsets780 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_POINTER,
};

static const uint16 attr_flags781 [] =
{0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
};

static const long offsets781 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_POINTER,
};

static const uint16 attr_flags782 [] =
{0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
};

static const long offsets782 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_POINTER,
};

static const uint16 attr_flags783 [] =
{0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
};

static const long offsets783 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_POINTER,
};

static const uint16 attr_flags784 [] =
{0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
};

static const long offsets784 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_POINTER,
};

static const uint16 attr_flags785 [] =
{0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
};

static const long offsets785 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_POINTER,
};

static const uint16 attr_flags786 [] =
{0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
};

static const long offsets786 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_POINTER,
};

static const uint16 attr_flags787 [] =
{0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
};

static const long offsets787 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_POINTER,
};

static const uint16 attr_flags788 [] =
{0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
};

static const long offsets788 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_POINTER,
};

static const uint16 attr_flags789 [] =
{0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
};

static const long offsets789 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_POINTER,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags791 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_1 [] = {0xFFF9,0,715,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_2 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_3 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_11 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
g_atype791_1,
g_atype791_2,
g_atype791_3,
g_atype791_4,
g_atype791_5,
g_atype791_6,
g_atype791_7,
g_atype791_8,
g_atype791_9,
g_atype791_10,
g_atype791_11,
};

static const long offsets791 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags792 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_1 [] = {0xFFF9,0,715,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_2 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_3 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_6 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_11 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
g_atype792_1,
g_atype792_2,
g_atype792_3,
g_atype792_4,
g_atype792_5,
g_atype792_6,
g_atype792_7,
g_atype792_8,
g_atype792_9,
g_atype792_10,
g_atype792_11,
};

static const long offsets792 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags793 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_1 [] = {0xFFF9,0,715,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_2 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_3 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_12 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
g_atype793_1,
g_atype793_2,
g_atype793_3,
g_atype793_4,
g_atype793_5,
g_atype793_6,
g_atype793_7,
g_atype793_8,
g_atype793_9,
g_atype793_10,
g_atype793_11,
g_atype793_12,
};

static const long offsets793 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags794 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_1 [] = {0xFFF9,0,715,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_2 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_3 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_12 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
g_atype794_1,
g_atype794_2,
g_atype794_3,
g_atype794_4,
g_atype794_5,
g_atype794_6,
g_atype794_7,
g_atype794_8,
g_atype794_9,
g_atype794_10,
g_atype794_11,
g_atype794_12,
};

static const long offsets794 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags795 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_1 [] = {0xFFF9,0,715,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_2 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_3 [] = {595,726,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_7 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_8 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_12 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
g_atype795_1,
g_atype795_2,
g_atype795_3,
g_atype795_4,
g_atype795_5,
g_atype795_6,
g_atype795_7,
g_atype795_8,
g_atype795_9,
g_atype795_10,
g_atype795_11,
g_atype795_12,
};

static const long offsets795 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags796 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
};

static const long offsets796 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags797 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
};

static const long offsets797 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags798 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
};

static const long offsets798 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags799 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
g_atype799_2,
g_atype799_3,
};

static const long offsets799 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags800 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
g_atype800_2,
g_atype800_3,
g_atype800_4,
};

static const long offsets800 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags801 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {0xFF01,571,753,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
g_atype801_2,
g_atype801_3,
g_atype801_4,
};

static const long offsets801 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags802 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_3 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
g_atype802_2,
g_atype802_3,
};

static const long offsets802 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags803 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
g_atype803_2,
g_atype803_3,
g_atype803_4,
};

static const long offsets803 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags804 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {0xFF01,579,756,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_2 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_3 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
g_atype804_2,
g_atype804_3,
g_atype804_4,
};

static const long offsets804 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags806 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {0xFF01,803,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {0xFF01,795,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_2 [] = {131,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_3 [] = {0xFF01,800,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_4 [] = {6,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_5 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_6 [] = {756,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_9 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_10 [] = {744,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_11 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_12 [] = {741,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_13 [] = {729,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_14 [] = {738,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_15 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_16 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_17 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_18 [] = {747,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_20 [] = {735,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_21 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_22 [] = {750,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
g_atype806_2,
g_atype806_3,
g_atype806_4,
g_atype806_5,
g_atype806_6,
g_atype806_7,
g_atype806_8,
g_atype806_9,
g_atype806_10,
g_atype806_11,
g_atype806_12,
g_atype806_13,
g_atype806_14,
g_atype806_15,
g_atype806_16,
g_atype806_17,
g_atype806_18,
g_atype806_19,
g_atype806_20,
g_atype806_21,
g_atype806_22,
};

static const long offsets806 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags807 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
g_atype807_2,
};

static const long offsets807 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags808 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
g_atype808_2,
};

static const long offsets808 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags809 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_2 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
g_atype809_2,
};

static const long offsets809 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags811 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {0xFF01,132,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_1 [] = {800,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
g_atype811_1,
};

static const long offsets811 [] =
{
0,
 + @REFACS(1),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_REF,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {0xFF01,132,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
0,
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags813 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {159,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_1 [] = {159,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_2 [] = {159,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_3 [] = {654,0xFF01,0xFFF9,2,715,0xFF01,159,659,0xFF01,0xFFF9,2,715,0xFF01,161,0xFF01,161,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_7 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_8 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_9 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_10 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
g_atype813_1,
g_atype813_2,
g_atype813_3,
g_atype813_4,
g_atype813_5,
g_atype813_6,
g_atype813_7,
g_atype813_8,
g_atype813_9,
g_atype813_10,
};

static const long offsets813 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names2,
	types2,
	attr_flags2,
	gtypes2,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets2,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names4,
	types4,
	attr_flags4,
	gtypes4,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets4,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ARGUMENT_OPTION",
	names6,
	types6,
	attr_flags6,
	gtypes6,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets6,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names7,
	types7,
	attr_flags7,
	gtypes7,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets7,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_GROUP",
	names10,
	types10,
	attr_flags10,
	gtypes10,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets10,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names12,
	types12,
	attr_flags12,
	gtypes12,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets12,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ECHO",
	names30,
	types30,
	attr_flags30,
	gtypes30,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets30,
	NULL
},
{
	(long) 0,
	(long) 0,
	"APPLICATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names33,
	types33,
	attr_flags33,
	gtypes33,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets33,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_VALUE_VALIDATOR",
	names35,
	types35,
	attr_flags35,
	gtypes35,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets35,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_DEFAULT_VALIDATOR",
	names36,
	types36,
	attr_flags36,
	gtypes36,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets36,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_TERMINAL_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_BASE_PARSER",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_MULTI_PARSER",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_PARSER",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OUTPUT_REDIRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names53,
	types53,
	attr_flags53,
	gtypes53,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets53,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names54,
	types54,
	attr_flags54,
	gtypes54,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets54,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names55,
	types55,
	attr_flags55,
	gtypes55,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets55,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names56,
	types56,
	attr_flags56,
	gtypes56,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets56,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names58,
	types58,
	attr_flags58,
	gtypes58,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets58,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_GENERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names69,
	types69,
	attr_flags69,
	gtypes69,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets69,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names73,
	types73,
	attr_flags73,
	gtypes73,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets73,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names74,
	types74,
	attr_flags74,
	gtypes74,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets74,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names75,
	types75,
	attr_flags75,
	gtypes75,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets75,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names76,
	types76,
	attr_flags76,
	gtypes76,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets76,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INPUT_PROVIDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INPUT_LIST",
	names79,
	types79,
	attr_flags79,
	gtypes79,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets79,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names83,
	types83,
	attr_flags83,
	gtypes83,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets83,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names85,
	types85,
	attr_flags85,
	gtypes85,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets85,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names87,
	types87,
	attr_flags87,
	gtypes87,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets87,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names88,
	types88,
	attr_flags88,
	gtypes88,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets88,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names91,
	types91,
	attr_flags91,
	gtypes91,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets91,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names92,
	types92,
	attr_flags92,
	gtypes92,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets92,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names93,
	types93,
	attr_flags93,
	gtypes93,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets93,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names94,
	types94,
	attr_flags94,
	gtypes94,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets94,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names98,
	types98,
	attr_flags98,
	gtypes98,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets98,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names99,
	types99,
	attr_flags99,
	gtypes99,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets99,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names105,
	types105,
	attr_flags105,
	gtypes105,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets105,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names106,
	types106,
	attr_flags106,
	gtypes106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets106,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names108,
	types108,
	attr_flags108,
	gtypes108,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets108,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names111,
	types111,
	attr_flags111,
	gtypes111,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets111,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names116,
	types116,
	attr_flags116,
	gtypes116,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets116,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names117,
	types117,
	attr_flags117,
	gtypes117,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets117,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names118,
	types118,
	attr_flags118,
	gtypes118,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets118,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names119,
	types119,
	attr_flags119,
	gtypes119,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets119,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names120,
	types120,
	attr_flags120,
	gtypes120,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets120,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names121,
	types121,
	attr_flags121,
	gtypes121,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets121,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names160,
	types160,
	attr_flags160,
	gtypes160,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets160,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names222,
	types222,
	attr_flags222,
	gtypes222,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets222,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names307,
	types307,
	attr_flags307,
	gtypes307,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets307,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SUBSET",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE_SUBSET",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR_SUBSET",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_SET",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_SET",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ARGUMENT_SWITCH",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 11,
	(long) 11,
	"ARGUMENT_VALUE_SWITCH",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LOCALIZED_PRINTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INPUT_LINE_READER",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"OUTPUT_MEDIUM",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets813,
	NULL
},};


#ifdef __cplusplus
}
#endif
