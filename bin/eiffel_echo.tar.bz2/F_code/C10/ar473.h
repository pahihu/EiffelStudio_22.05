
#ifndef _C10_ar473_
#define _C10_ar473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F325_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F325_2206(EIF_REFERENCE);
extern EIF_REFERENCE F325_2209(EIF_REFERENCE);
extern void EIF_Minit473(void);

#ifdef __cplusplus
}
#endif

#endif
