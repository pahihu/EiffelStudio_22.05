
#ifndef _C10_li480_
#define _C10_li480_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F374_2236(EIF_REFERENCE);
extern EIF_BOOLEAN F374_2237(EIF_REFERENCE);
extern EIF_BOOLEAN F374_2239(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern EIF_NATURAL_16 F666_3019(EIF_REFERENCE);
extern EIF_BOOLEAN F613_2889(EIF_REFERENCE);
extern EIF_BOOLEAN F637_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F499_2350(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
