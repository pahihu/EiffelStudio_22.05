
#ifndef _C10_co483_
#define _C10_co483_

#ifdef __cplusplus
extern "C" {
#endif

extern void F350_2220(EIF_REFERENCE);
extern void EIF_Minit483(void);
extern long O1985[];

#ifdef __cplusplus
}
#endif

#endif
