
#ifndef _C10_li464_
#define _C10_li464_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F636_2913(EIF_REFERENCE);
extern void EIF_Minit464(void);
extern EIF_INTEGER_32 F665_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
