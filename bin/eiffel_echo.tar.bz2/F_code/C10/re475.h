
#ifndef _C10_re475_
#define _C10_re475_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F525_2363(EIF_REFERENCE);
extern void EIF_Minit475(void);
extern char *(*R2073[])();

#ifdef __cplusplus
}
#endif

#endif
