
#ifndef _C10_fi478_
#define _C10_fi478_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F499_2350(EIF_REFERENCE);
extern void EIF_Minit478(void);
extern char *(*R2070[])();

#ifdef __cplusplus
}
#endif

#endif
