
#ifndef _C10_to472_
#define _C10_to472_

#ifdef __cplusplus
extern "C" {
#endif

extern void F146_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F146_1716(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern void F146_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit472(void);
extern void F575_2728(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
