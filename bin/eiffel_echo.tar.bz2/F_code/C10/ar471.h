
#ifndef _C10_ar471_
#define _C10_ar471_

#ifdef __cplusplus
extern "C" {
#endif

extern void F311_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F311_2188(EIF_REFERENCE);
extern EIF_REFERENCE F311_2191(EIF_REFERENCE);
extern void EIF_Minit471(void);
extern EIF_REFERENCE F665_3018(EIF_REFERENCE);
extern EIF_INTEGER_32 F665_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
