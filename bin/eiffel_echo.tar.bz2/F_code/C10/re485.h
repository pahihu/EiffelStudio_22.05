
#ifndef _C10_re485_
#define _C10_re485_

#ifdef __cplusplus
extern "C" {
#endif

extern void F280_2133(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F280_2135(EIF_REFERENCE);
extern EIF_INTEGER_32 F280_2136(EIF_REFERENCE);
extern EIF_INTEGER_32 F280_2137(EIF_REFERENCE);
extern EIF_INTEGER_32 F280_2138(EIF_REFERENCE);
extern EIF_BOOLEAN F280_2146(EIF_REFERENCE);
extern EIF_BOOLEAN F280_2147(EIF_REFERENCE);
extern EIF_BOOLEAN F280_2149(EIF_REFERENCE);
extern void F280_2152(EIF_REFERENCE);
extern void EIF_Minit485(void);
extern char *(*R2281[])();
extern char *(*R2282[])();

#ifdef __cplusplus
}
#endif

#endif
