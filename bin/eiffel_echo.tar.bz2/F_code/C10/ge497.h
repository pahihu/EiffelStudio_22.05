
#ifndef _C10_ge497_
#define _C10_ge497_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F300_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F300_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F300_2180(EIF_REFERENCE);
extern void F300_2182(EIF_REFERENCE);
extern void EIF_Minit497(void);

#ifdef __cplusplus
}
#endif

#endif
