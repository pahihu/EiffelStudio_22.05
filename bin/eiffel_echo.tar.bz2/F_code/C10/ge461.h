
#ifndef _C10_ge461_
#define _C10_ge461_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F299_2167(EIF_REFERENCE);
extern EIF_BOOLEAN F299_2176(EIF_REFERENCE);
extern EIF_BOOLEAN F299_2180(EIF_REFERENCE);
extern void F299_2182(EIF_REFERENCE);
extern void EIF_Minit461(void);

#ifdef __cplusplus
}
#endif

#endif
