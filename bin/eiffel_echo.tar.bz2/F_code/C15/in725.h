
#ifndef _C15_in725_
#define _C15_in725_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F489_2317(EIF_REFERENCE);
extern void EIF_Minit725(void);

#ifdef __cplusplus
}
#endif

#endif
