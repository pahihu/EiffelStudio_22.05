
#ifndef _C15_co723_
#define _C15_co723_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F491_2320(EIF_REFERENCE);
extern EIF_INTEGER_32 F491_2321(EIF_REFERENCE);
extern EIF_BOOLEAN F491_2322(EIF_REFERENCE);
extern void F491_2328(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern EIF_INTEGER_32 F492_2344(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
