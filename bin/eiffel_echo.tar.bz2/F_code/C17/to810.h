
#ifndef _C17_to810_
#define _C17_to810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F152_1715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F152_1716(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F152_1722(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit810(void);
extern void F581_2728(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1584[];
extern EIF_TYPE_INDEX *Y1584_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
