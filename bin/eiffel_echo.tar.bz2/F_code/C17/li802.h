
#ifndef _C17_li802_
#define _C17_li802_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F642_2913(EIF_REFERENCE);
extern void EIF_Minit802(void);
extern EIF_INTEGER_32 F671_3035(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
