
#ifndef _C17_ar811_
#define _C17_ar811_

#ifdef __cplusplus
extern "C" {
#endif

extern void F331_2205(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F331_2206(EIF_REFERENCE);
extern EIF_REFERENCE F331_2209(EIF_REFERENCE);
extern void EIF_Minit811(void);

#ifdef __cplusplus
}
#endif

#endif
