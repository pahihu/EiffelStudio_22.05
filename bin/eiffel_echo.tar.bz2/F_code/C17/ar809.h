
#ifndef _C17_ar809_
#define _C17_ar809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F317_2187(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F317_2188(EIF_REFERENCE);
extern EIF_REFERENCE F317_2191(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern EIF_INTEGER_32 F671_3037(EIF_REFERENCE);
extern EIF_REFERENCE F671_3018(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
