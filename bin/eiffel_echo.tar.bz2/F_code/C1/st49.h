
#ifndef _C1_st49_
#define _C1_st49_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F70_936(EIF_REFERENCE);
extern EIF_INTEGER_32 F70_937(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit49(void);
extern char *(*R3483[])();
extern char *(*R3446[])();
extern char *(*R3600[])();

#ifdef __cplusplus
}
#endif

#endif
