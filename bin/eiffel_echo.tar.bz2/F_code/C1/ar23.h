
#ifndef _C1_ar23_
#define _C1_ar23_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F35_543(EIF_REFERENCE);
extern void F35_547(EIF_REFERENCE, EIF_REFERENCE);
extern void F35_549(EIF_REFERENCE);
extern void EIF_Minit23(void);
extern void F796_4576(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
