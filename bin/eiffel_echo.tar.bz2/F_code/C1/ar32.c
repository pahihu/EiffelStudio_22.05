/*
 * Code for class ARGUMENT_MULTI_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar32.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_MULTI_PARSER}.make */
void F44_686 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	F43_586(Current, arg1, (EIF_BOOLEAN) 1, arg2);
}

/* {ARGUMENT_MULTI_PARSER}.non_switched_argument_name_arg */
static EIF_REFERENCE F44_690_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (690);
#define Result RTOSR(690)
	RTOC_NEW(Result);
	loc1 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTOSCF(698,F45_698, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3483[Dtype(RTCW(tr1))-799])(tr1);
	F799_4706(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
	F801_4834(RTCW(loc1), tw1);
	tr1 = RTOSCF(698,F45_698, (Current));
	F801_4820(RTCW(loc1), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
	F801_4834(RTCW(loc1), tw1);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F800_4759(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (690);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F44_690 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(690,F44_690_body,(Current));
}

/* {ARGUMENT_MULTI_PARSER}.command_option_group_configuration */
EIF_REFERENCE F44_691 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg5);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	loc1 = F43_651(Current, arg1, arg2, arg3, arg4, arg5);
	Result = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	F799_4706(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 50L)));
	F801_4821(RTCW(Result), loc1);
	if (arg2) {
		tb1 = F495_2350(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F801_4834(RTCW(Result), tw1);
		}
		if ((EIF_BOOLEAN) !arg3) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			F801_4834(RTCW(Result), tw1);
		}
		loc2 = F796_4635(RTCV(RTOSCF(690,F44_690, (Current))));
		F801_4821(RTCW(Result), loc2);
		tr1 = RTMS32_EX_H(" \000\000\000[\000\000\000",2,8283);
		F801_4821(RTCW(Result), tr1);
		F801_4821(RTCW(Result), loc2);
		tr1 = RTMS32_EX_H(",\000\000\000 \000\000\000.\000\000\000.\000\000\000.\000\000\000]\000\000\000",6,861531741);
		F801_4821(RTCW(Result), tr1);
		if ((EIF_BOOLEAN) !arg3) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			F801_4834(RTCW(Result), tw1);
		}
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_MULTI_PARSER}.extended_usage */
static EIF_REFERENCE F44_692_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (692);
#define Result RTOSR(692)
	RTOC_NEW(Result);
	loc1 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(668,F43_668, (Current)))+ _LNGOFF_1_0_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(690,F44_690, (Current)))+ _LNGOFF_1_0_0_2_);
	F799_4707(RTCW(loc1), tw1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) + ti4_2));
	tr1 = F796_4635(RTMS_EX_H("\012",1,10));
	F801_4838(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
	loc2 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTOSCF(697,F45_697, (Current));
	F801_4782(RTCW(loc2), tr1);
	tr1 = F796_4635(RTMS_EX_H("\012",1,10));
	F801_4798(RTCW(loc2), tr1, loc1);
	loc3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F799_4706(RTCW(loc3), ((EIF_INTEGER_32) 30L));
	tr1 = F796_4635(RTMS_EX_H("NON-SWITCHED ARGUMENTS:\012",24,1327131914));
	F801_4821(RTCW(loc3), tr1);
	tr1 = RTOSCF(668,F43_668, (Current));
	F801_4821(RTCW(loc3), tr1);
	tr1 = RTOSCF(690,F44_690, (Current));
	F801_4821(RTCW(loc3), tr1);
	tr1 = F796_4635(RTMS_EX_H(": ",2,14880));
	F801_4821(RTCW(loc3), tr1);
	F801_4821(RTCW(loc3), loc2);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F800_4761(RTCW(tr1), loc3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (692);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F44_692 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(692,F44_692_body,(Current));
}

/* {ARGUMENT_MULTI_PARSER}.validate_non_switched_arguments */
void F44_693 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	F43_635(Current, arg1);
	loc1 = F493_2350(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		loc2 = F660_3028(RTCW(arg1));
		tb1 = EIF_FALSE;
		for (;;) {
			if (tb1) break;
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc2)-287])(loc2);
			if (tb2) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc2)-287])(loc2);
			tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_1_);
			tb1 = tb3;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc2)-287])(loc2);
		}
		loc1 = (EIF_BOOLEAN) tb1;
	}
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if (loc1) {
		tb3 = (EIF_BOOLEAN) !F43_606(Current);
	}
	if (tb3) {
		tb2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_);
	}
	if (tb1) {
		tr1 = RTOSCF(694,F44_694, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,795,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		tr3 = RTOSCF(699,F45_699, (Current));
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3505[Dtype(RTCW(tr3))-799])(tr3);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		F43_641(Current, tr1, tr2);
	}
	RTLE;
}

/* {ARGUMENT_MULTI_PARSER}.e_missing_non_switched_argument */
static EIF_REFERENCE F44_694_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (694);
#define Result RTOSR(694)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("The required argument \"{1}\" is missing.",39,1612871470);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (694);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F44_694 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(694,F44_694_body,(Current));
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
