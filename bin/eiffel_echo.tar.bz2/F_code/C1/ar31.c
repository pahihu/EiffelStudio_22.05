/*
 * Code for class ARGUMENT_BASE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar31.h"
#include "eif_built_in.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F3_46
static EIF_INTEGER_32 inline_F3_46 (void)
{
	#ifdef TIOCGSIZE
	struct ttysize win;
    if (ioctl (STDIN_FILENO, TIOCGSIZE, &win))
        return 0;
    else
        return win.ts_cols;
#elif defined TIOCGWINSZ
	struct winsize win;
    if (ioctl (STDIN_FILENO, TIOCGWINSZ, &win))
        return 0;
    else
        return win.ws_col;
#else
    {
		// Not likely to work because COLUMNS generally is a shell variable.
        const char *s;
        s = getenv ("COLUMNS");
        if (s)
            return strtol (s, 0, 10);
        else
            return 0;
    }
#endif
	;
}
#define INLINE_F3_46
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_BASE_PARSER}.make */
void F43_586 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F43_587(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.initialize_defaults */
void F43_587 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,5,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,799,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(35, 0x01).id, 35, _OBJSIZ_1_2_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.values */
EIF_REFERENCE F43_589 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {ARGUMENT_BASE_PARSER}.option_values */
EIF_REFERENCE F43_590 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

/* {ARGUMENT_BASE_PARSER}.error_messages */
static EIF_REFERENCE F43_591_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (591);
#define Result RTOSR(591)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,795,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (591);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_591 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(591,F43_591_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.system_name */
EIF_REFERENCE F43_592 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(552,F37_552, (RTCV(F43_595(Current))));
	tr1 = F684_3241(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F684_3264(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(667,F43_667, (Current));
	}/* NOTREACHED */
	
}

/* {ARGUMENT_BASE_PARSER}.sub_system_name */
EIF_REFERENCE F43_593 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ARGUMENT_BASE_PARSER}.arguments */
EIF_REFERENCE F43_594 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,Result);
	RTLR(3,loc4);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	if (RTOSCF(615,F43_615, (Current))) {
		loc1 = RTOSCF(556,F38_556, (RTCV(F43_595(Current))));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,799,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		ti4_1 = F660_3035(RTCW(loc1));
		F660_3014(RTCW(Result), ti4_1);
		loc4 = RTOSCF(665,F43_665, (Current));
		loc5 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
		tr1 = F660_3028(RTCW(loc1));
		loc8 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F294_2176(loc8);
			if (tb1) break;
			loc2 = F294_2167(loc8);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
				tb2 = '\0';
				tw1 = F800_4765(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb3 = F597_2824(RTCW(loc4), tw1);
				if (tb3) {
					tw1 = F800_4765(RTCW(loc2), ((EIF_INTEGER_32) 2L));
					tb3 = F597_2824(RTCW(loc4), tw1);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					if (loc5) {
						loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
					} else {
						tw1 = RTOSCF(666,F43_666, (Current));
						loc7 = F799_4718(RTCW(loc2), tw1, ((EIF_INTEGER_32) 2L));
						if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 0L))) {
							loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
						} else {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
							ti4_1 = eif_min_int32 (loc7,ti4_1);
							loc7 = (EIF_INTEGER_32) ti4_1;
						}
					}
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc6 > loc7)) break;
						loc3 = (EIF_REFERENCE) NULL;
						tb2 = '\0';
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && (EIF_BOOLEAN) (loc6 < loc7))) {
							tw1 = F800_4765(RTCW(loc2), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
							tb2 = (EIF_BOOLEAN)(tw1 == RTOSCF(666,F43_666, (Current)));
						}
						if (tb2) {
							loc3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F799_4706(RTCW(loc3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc7 - loc6)));
							tw1 = F597_2821(RTCW(loc4), ((EIF_INTEGER_32) 1L));
							F801_4834(RTCW(loc3), tw1);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
							tr1 = F800_4774(RTCW(loc2), loc6, ti4_1);
							F801_4821(RTCW(loc3), tr1);
							loc6 = (EIF_INTEGER_32) loc7;
						}
						tb2 = '\0';
						if ((EIF_BOOLEAN)(loc3 == NULL)) {
							tb3 = '\01';
							if (!loc5) {
								tw1 = F800_4765(RTCW(loc2), loc6);
								tb3 = (EIF_BOOLEAN)(tw1 != RTOSCF(666,F43_666, (Current)));
							}
							tb2 = tb3;
						}
						if (tb2) {
							loc3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F799_4706(RTCW(loc3), ((EIF_INTEGER_32) 2L));
							tw1 = F597_2821(RTCW(loc4), ((EIF_INTEGER_32) 1L));
							F801_4834(RTCW(loc3), tw1);
							tw1 = F800_4765(RTCW(loc2), loc6);
							F801_4834(RTCW(loc3), tw1);
						}
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							tr1 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
							F800_4761(RTCW(tr1), loc3);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
						}
						loc6++;
					}
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
			}
			F294_2182(loc8);
		}
	} else {
		Result = RTOSCF(556,F38_556, (RTCV(F43_595(Current))));
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.argument_source */
EIF_REFERENCE F43_595 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		Result = F43_664(Current);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.max_columns */
static EIF_NATURAL_32 F43_599_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	

	
	RTEV;
	RTGC;
	RTOSP (599);
#define Result RTOSR(599)
	Result = (EIF_NATURAL_32) inline_F3_46();
	if ((EIF_BOOLEAN)(Result == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_NATURAL_32) ((EIF_INTEGER_32) 2147483647L);
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			Result -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		tu4_1 = eif_max_uint32 (Result,(EIF_NATURAL_32) ((EIF_INTEGER_32) 25L));
		Result = (EIF_NATURAL_32) tu4_1;
	}
	RTOSE (599);
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_32 F43_599 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(599,F43_599_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.is_successful */
EIF_BOOLEAN F43_600 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_)) {
		tb1 = F493_2350(RTCV(RTOSCF(591,F43_591, (Current))));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.has_non_switched_argument */
EIF_BOOLEAN F43_606 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_)) {
		tb1 = F493_2350(RTCV(F43_589(Current)));
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.has_option */
EIF_BOOLEAN F43_607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_)) {
		Result = (EIF_BOOLEAN)(F43_682(Current, arg1) != NULL);
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.is_using_unix_switch_style */
static EIF_BOOLEAN F43_615_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (615);
#define Result RTOSR(615)
	loc1 = F660_3028(RTCV(RTOSCF(701,F45_701, (Current))));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F294_2176(loc1);
		if (tb2) break;
		tr1 = F294_2167(loc1);
		tb3 = F717_3459(RTCW(tr1));
		tb1 = tb3;
		F294_2182(loc1);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTOSE (615);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F43_615 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(615,F43_615_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.has_visible_available_options */
EIF_BOOLEAN F43_617 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F493_2350(RTCV(RTOSCF(658,F43_658, (Current))));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.has_switch */
EIF_BOOLEAN F43_619 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	loc2 = F660_3028(RTCV(RTOSCF(657,F43_657, (Current))));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F294_2176(loc2);
		if (tb2) break;
		if (loc1) {
			tr1 = F294_2167(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F796_4621(RTCW(tr1), arg1);
		} else {
			tr1 = F294_2167(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb4 = F796_4618(RTCW(tr1), arg1);
			tb3 = tb4;
		}
		tb1 = tb3;
		F294_2182(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.options_of_name */
EIF_REFERENCE F43_625 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,5,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(Result), ((EIF_INTEGER_32) 0L));
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	loc3 = F660_3028(RTCV(F43_590(Current)));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc3)-287])(loc3);
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc3)-287])(loc3);
		if (loc1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = F796_4621(RTCW(tr1), arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F796_4618(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		if (tb2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc3)-287])(loc3);
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.switch_of_name */
EIF_REFERENCE F43_628 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	loc2 = F660_3028(RTCV(RTOSCF(657,F43_657, (Current))));
	for (;;) {
		tb1 = F294_2176(loc2);
		if (tb1) break;
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		if (loc1) {
			tr1 = F294_2167(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = F796_4621(RTCW(tr1), arg1);
		} else {
			tr1 = F294_2167(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F796_4618(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		if (tb2) {
			Result = F294_2167(loc2);
		}
		F294_2182(loc2);
	}
	RTCT0("from_precondition_has_switch", EX_CHECK);
	if ((EIF_BOOLEAN)(Result != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.string_formatter */
static EIF_REFERENCE F43_629_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (629);
#define Result RTOSR(629)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(804, 0x01).id, 804, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (629);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_629 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(629,F43_629_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.execute */
void F43_630 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F43_632(Current);
	if (F43_600(Current)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_);
		}
		if (tb1) {
			F43_643(Current);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_)) {
			F43_642(Current);
		} else {
			tb1 = '\0';
			tr1 = RTOSCF(656,F43_656, (Current));
			if (F43_619(Current, tr1)) {
				tr1 = RTOSCF(656,F43_656, (Current));
				tb1 = F43_607(Current, tr1);
			}
			if (tb1) {
				F43_644(Current);
			} else {
				tb1 = '\0';
				tb2 = F493_2350(RTCV(F43_590(Current)));
				if (tb2) {
					tb2 = F493_2350(RTCV(F43_589(Current)));
					tb1 = tb2;
				}
				if (tb1) {
					F43_631(Current, arg1);
				} else {
					(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
						*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
						*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_));
				}
			}
		}
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(654,F43_654, (Current));
		if (F43_619(Current, tr1)) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_);
		}
		if (tb1) {
			F43_643(Current);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
			F43_642(Current);
		}
		F43_645(Current);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.execute_noop */
void F43_631 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_))) {
		F43_642(Current);
	} else {
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_));
	}
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.parse_arguments */
void F43_632 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc8);
	RTLR(4,loc18);
	RTLR(5,loc12);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLR(11,loc7);
	RTLR(12,loc19);
	RTLR(13,loc6);
	RTLR(14,loc20);
	RTLR(15,loc21);
	RTLR(16,loc22);
	RTLIU(17);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F660_3073(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F660_3073(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = RTOSCF(657,F43_657, (Current));
	loc8 = RTOSCF(665,F43_665, (Current));
	loc9 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
	loc18 = F660_3028(RTCV(F43_594(Current)));
	for (;;) {
		tb1 = F294_2176(loc18);
		if (tb1) break;
		loc12 = F294_2167(loc18);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		if ((EIF_BOOLEAN) !loc14) {
			tb5 = F800_4777(RTCW(loc12));
			tb4 = (EIF_BOOLEAN) !tb5;
		}
		if (tb4) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
			tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		}
		if (tb3) {
			tw1 = F800_4765(RTCW(loc12), ((EIF_INTEGER_32) 1L));
			tb3 = F597_2824(RTCW(loc8), tw1);
			tb2 = tb3;
		}
		if (tb2) {
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
				tw1 = F800_4765(RTCW(loc12), ((EIF_INTEGER_32) 2L));
				tb3 = F597_2824(RTCW(loc8), tw1);
				tb2 = tb3;
			}
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
				loc4 = F800_4775(RTCW(loc12), ((EIF_INTEGER_32) 3L), ti4_1);
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
					tr1 = RTMS_EX_H("--",2,11565);
					tb3 = F796_4621(RTCW(loc12), tr1);
					tb2 = tb3;
				}
				if (tb2) {
					loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_REFERENCE) loc12;
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
					loc4 = F800_4775(RTCW(loc12), ((EIF_INTEGER_32) 2L), ti4_1);
				}
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			if ((EIF_BOOLEAN) !loc14) {
				loc3 = (EIF_REFERENCE) NULL;
				tb2 = F800_4777(RTCW(loc4));
				if ((EIF_BOOLEAN) !tb2) {
					loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc5 = (EIF_REFERENCE) NULL;
					if ((EIF_BOOLEAN) !loc2) {
						tw1 = RTOSCF(666,F43_666, (Current));
						loc16 = F799_4718(RTCW(loc4), tw1, ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN) (loc16 > ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc16 == ((EIF_INTEGER_32) 1L))) {
								tr1 = RTOSCF(669,F43_669, (Current));
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,800,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr2 = RTLNTS(typres0.id, 2, 0);
								}
								tr3 = F43_662(Current, loc12);
								((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
								RTAR(tr2,tr3);
								F43_641(Current, tr1, tr2);
								loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_2_);
								loc5 = F800_4775(RTCW(loc4), (EIF_INTEGER_32) (loc16 + ((EIF_INTEGER_32) 1L)), ti4_1);
								tr1 = F800_4775(RTCW(loc4), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc16 - ((EIF_INTEGER_32) 1L)));
								loc4 = (EIF_REFERENCE) tr1;
							}
						}
					}
					if ((EIF_BOOLEAN) !loc11) {
						if ((EIF_BOOLEAN) !loc9) {
							tr1 = F800_4772(RTCW(loc4));
							loc4 = (EIF_REFERENCE) tr1;
						}
						loc7 = (EIF_REFERENCE) NULL;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc19 = F660_3028(RTCW(loc1));
						for (;;) {
							tb2 = F294_2176(loc19);
							if (tb2) break;
							if (loc10) break;
							loc6 = F294_2167(loc19);
							if (loc13) {
								if (loc9) {
									tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
									loc10 = F799_4733(RTCW(tr1), loc4);
								} else {
									tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
									loc10 = F799_4731(RTCW(tr1), loc4);
								}
							} else {
								if (loc9) {
									tr1 = F717_3450(RTCW(loc6));
									loc10 = F799_4733(RTCW(tr1), loc4);
								} else {
									tr1 = F717_3450(RTCW(loc6));
									loc10 = F799_4731(RTCW(tr1), loc4);
								}
							}
							if (loc10) {
								loc7 = (EIF_REFERENCE) loc6;
							}
							F294_2182(loc19);
						}
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc10 && (EIF_BOOLEAN) !loc13)) {
							loc17 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc15 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_2_);
							for (;;) {
								if ((EIF_BOOLEAN) (loc17 > loc15)) break;
								loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								loc20 = F660_3028(RTCW(loc1));
								for (;;) {
									tb3 = F294_2176(loc20);
									if (tb3) break;
									if (loc10) break;
									loc6 = F294_2167(loc20);
									tb4 = F717_3459(RTCW(loc6));
									if (tb4) {
										if (loc9) {
											tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc6)+ _LNGOFF_3_4_0_0_);
											tw2 = F800_4765(RTCW(loc4), loc17);
											loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
										} else {
											tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc6)+ _LNGOFF_3_4_0_0_);
											tr1 = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
											*(EIF_CHARACTER_32 *)tr1 = tw1;
											tw1 = F752_4423(RTCW(tr1));
											tw2 = F800_4765(RTCW(loc4), loc17);
											loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
										}
										if ((EIF_BOOLEAN) (loc10 && (EIF_BOOLEAN) (loc17 < loc15))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											tr2 = F717_3462(RTCW(loc6));
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-659])(tr1, tr2);
										}
									}
									F294_2182(loc20);
								}
								loc17++;
							}
							if (loc10) {
								loc7 = (EIF_REFERENCE) loc6;
							}
						}
						if (loc10) {
							if ((EIF_BOOLEAN)(loc6 != NULL)) {
								tb4 = '\0';
								tb5 = '\0';
								if ((EIF_BOOLEAN)(loc5 != NULL)) {
									tb6 = F800_4777(RTCW(loc5));
									tb5 = (EIF_BOOLEAN) !tb6;
								}
								if (tb5) {
									loc21 = loc7;
									loc21 = RTRV(eif_new_type(717, 0x01),loc21);
									tb4 = EIF_TEST(loc21);
								}
								if (tb4) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									tr2 = (RTNA((loc21, loc5)), ((EIF_REFERENCE) 0));
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-659])(tr1, tr2);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									tr2 = F717_3462(RTCW(loc6));
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-659])(tr1, tr2);
								}
							} else {
							}
							if (loc2) {
								loc3 = (EIF_REFERENCE) loc6;
							}
						} else {
							tr1 = RTOSCF(670,F43_670, (Current));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,800,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 2, 0);
							}
							tr3 = F43_662(Current, loc12);
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							F43_641(Current, tr1, tr2);
						}
					}
				} else {
					tr1 = RTOSCF(669,F43_669, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,800,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F43_662(Current, loc12);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F43_641(Current, tr1, tr2);
				}
			}
		} else {
			loc22 = loc3;
			loc22 = RTRV(eif_new_type(717, 0x01),loc22);
			if (EIF_TEST(loc22)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F660_3046(RTCW(tr1));
				tb4 = '\0';
				if ((EIF_BOOLEAN)(loc12 != NULL)) {
					tb5 = F800_4777(RTCW(loc12));
					tb4 = (EIF_BOOLEAN) !tb5;
				}
				if (tb4) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = (RTNA((loc22, loc12)), ((EIF_REFERENCE) 0));
					F660_3058(RTCW(tr1), tr2);
				}
			} else {
				tb4 = F800_4777(RTCW(loc12));
				if ((EIF_BOOLEAN) !tb4) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-659])(tr1, loc12);
				} else {
					tr1 = RTOSCF(669,F43_669, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,800,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F43_662(Current, loc12);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F43_641(Current, tr1, tr2);
				}
			}
			loc3 = (EIF_REFERENCE) NULL;
		}
		F294_2182(loc18);
	}
	if (F43_600(Current)) {
		tr1 = RTOSCF(655,F43_655, (Current));
		if ((EIF_BOOLEAN) !F43_607(Current, tr1)) {
			F43_634(Current);
			if (F43_600(Current)) {
				F43_633(Current);
			}
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tb4 = F43_600(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_) = (EIF_BOOLEAN) tb4;
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.post_process_arguments */
void F43_633 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTOSCF(654,F43_654, (Current));
	if (!(EIF_BOOLEAN) !F43_619(Current, tr1)) {
		tr1 = RTOSCF(654,F43_654, (Current));
		tb2 = F43_607(Current, tr1);
	}
	if (!tb2) {
		tr1 = RTOSCF(656,F43_656, (Current));
		tb1 = F43_607(Current, tr1);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_) = (EIF_BOOLEAN) tb1;
	tr1 = RTOSCF(655,F43_655, (Current));
	tb1 = F43_607(Current, tr1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_) = (EIF_BOOLEAN) tb1;
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.validate_arguments */
void F43_634 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc9);
	RTLR(10,loc10);
	RTLR(11,loc11);
	RTLR(12,loc6);
	RTLR(13,loc12);
	RTLR(14,loc5);
	RTLIU(15);
	
	RTGC;
	loc2 = RTOSCF(702,F45_702, (Current));
	tb1 = F493_2350(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = F43_637(Current);
		tb1 = F493_2350(RTCW(loc2));
		if (tb1) {
			tr1 = RTOSCF(678,F43_678, (Current));
			F43_640(Current, tr1);
		}
	}
	loc3 = RTOSCF(661,F43_661, (Current));
	tb1 = '\0';
	tb2 = F493_2350(RTCW(loc3));
	if ((EIF_BOOLEAN) !tb2) {
		tb2 = F493_2350(RTCV(F43_590(Current)));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F43_636(Current);
	}
	tb1 = F493_2350(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		F44_693(Current, loc2);
	}
	loc8 = F660_3028(RTCV(RTOSCF(657,F43_657, (Current))));
	for (;;) {
		tb1 = F294_2176(loc8);
		if (tb1) break;
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc4 = F294_2167(loc8);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
		if (F43_607(Current, tr1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			loc1 = F43_625(Current, tr1);
		} else {
			loc1 = (EIF_REFERENCE) NULL;
		}
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		tb5 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb5) {
			tb4 = (EIF_BOOLEAN)(loc1 == NULL);
		}
		if (tb4) {
			tb4 = F493_2350(RTCW(loc2));
			tb3 = tb4;
		}
		if (tb3) {
			tb3 = F493_2350(RTCW(loc3));
			tb2 = tb3;
		}
		if (tb2) {
			tr1 = RTOSCF(675,F43_675, (Current));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,799,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F717_3450(RTCW(loc4));
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F43_641(Current, tr1, tr2);
		} else {
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				tb3 = F493_2350(RTCW(loc1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tb2 = '\0';
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_3_1_);
				if ((EIF_BOOLEAN) !tb3) {
					ti4_1 = F660_3035(RTCW(loc1));
					tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
				}
				if (tb2) {
					tr1 = RTOSCF(673,F43_673, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,799,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F717_3450(RTCW(loc4));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F43_641(Current, tr1, tr2);
				}
				loc9 = loc4;
				loc9 = RTRV(eif_new_type(717, 0x01),loc9);
				if ((EIF_BOOLEAN) !EIF_TEST(loc9)) {
					loc10 = F660_3028(RTCW(loc1));
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc10)-287])(loc10);
						if (tb2) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc10)-287])(loc10);
						tb3 = F6_63(RTCW(tr1));
						if (tb3) {
							tr1 = RTOSCF(674,F43_674, (Current));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,0xFF01,799,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 2, 0);
							}
							tr3 = F717_3450(RTCW(loc4));
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							F43_641(Current, tr1, tr2);
						}
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc10)-287])(loc10);
					}
				} else {
					tb3 = *(EIF_BOOLEAN *)(loc9);
					if ((EIF_BOOLEAN) !tb3) {
						loc11 = F660_3028(RTCW(loc1));
						for (;;) {
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc11)-287])(loc11);
							if (tb3) break;
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc11)-287])(loc11);
							tb4 = F6_63(RTCW(tr1));
							if ((EIF_BOOLEAN) !tb4) {
								tr1 = RTOSCF(672,F43_672, (Current));
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,715,0xFF01,799,0xFF01,799,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr2 = RTLNTS(typres0.id, 3, 0);
								}
								tr3 = (RTNA((loc9)), ((EIF_REFERENCE) 0));
								((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
								RTAR(tr2,tr3);
								tr3 = *(EIF_REFERENCE *)(loc9);
								((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
								RTAR(tr2,tr3);
								F43_641(Current, tr1, tr2);
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc11)-287])(loc11);
						}
						if (loc7) {
							loc6 = (RTNA((loc9)), ((EIF_REFERENCE) 0));
							loc12 = F660_3028(RTCW(loc1));
							for (;;) {
								tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc12)-287])(loc12);
								if (tb4) break;
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc12)-287])(loc12);
								loc5 = F6_61(RTCW(tr1));
								F35_547(RTCW(loc6), loc5);
								tb5 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_1_0_);
								if ((EIF_BOOLEAN) !tb5) {
									tr1 = RTOSCF(680,F43_680, (Current));
									{
										static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,715,0xFF01,800,0xFF01,799,0xFF01,799,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr2 = RTLNTS(typres0.id, 4, 0);
									}
									tr3 = F43_662(Current, loc5);
									((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
									RTAR(tr2,tr3);
									tr3 = F717_3450(RTCW(loc4));
									((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
									RTAR(tr2,tr3);
									tr3 = F35_543(RTCW(loc6));
									((EIF_TYPED_VALUE *)tr2+3)->it_r = tr3;
									RTAR(tr2,tr3);
									F43_641(Current, tr1, tr2);
								}
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc12)-287])(loc12);
							}
						}
					}
				}
			}
		}
		F294_2182(loc8);
	}
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.validate_non_switched_arguments */
void F43_635 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc2 = F43_589(Current);
	tb1 = F493_2350(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_)) {
			loc1 = *(EIF_REFERENCE *)(Current);
			loc3 = F660_3028(RTCW(loc2));
			for (;;) {
				tb1 = F294_2176(loc3);
				if (tb1) break;
				tr1 = F294_2167(loc3);
				F35_547(RTCW(loc1), tr1);
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_0_);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTOSCF(681,F43_681, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,715,0xFF01,799,0xFF01,799,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F294_2167(loc3);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					tr3 = F35_543(RTCW(loc1));
					((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
					RTAR(tr2,tr3);
					F43_641(Current, tr1, tr2);
				}
				F294_2182(loc3);
			}
		} else {
			tr1 = RTOSCF(676,F43_676, (Current));
			F43_640(Current, tr1);
		}
	}
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.validate_switch_appurtenances */
void F43_636 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	loc1 = RTOSCF(661,F43_661, (Current));
	loc6 = F660_3028(RTCV(F43_590(Current)));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc6)-287])(loc6);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc6)-287])(loc6);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1));
		tb2 = F673_3098(RTCW(loc1), loc3);
		if (tb2) {
			tr1 = F673_3096(RTCW(loc1), loc3);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				loc5 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_1_);
				loc4 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_0_);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc4)) break;
					loc2 = F595_2821(loc7, loc5);
					tb2 = '\0';
					tb3 = '\0';
					tb4 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_0_);
					if ((EIF_BOOLEAN) !tb4) {
						tb4 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_3_);
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					if (tb3) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
						tb2 = (EIF_BOOLEAN) !F43_607(Current, tr1);
					}
					if (tb2) {
						tr1 = RTOSCF(679,F43_679, (Current));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,715,0xFF01,799,0xFF01,799,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 3, 0);
						}
						tr3 = F717_3450(RTCW(loc3));
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						tr3 = F717_3450(RTCW(loc2));
						((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
						RTAR(tr2,tr3);
						F43_641(Current, tr1, tr2);
					}
					loc5++;
				}
			} else {
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc6)-287])(loc6);
	}
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.valid_switch_groups */
EIF_REFERENCE F43_637 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	Result = F1_14(F43_638(Current));
	loc2 = F660_3028(RTCV(F43_590(Current)));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc2)-287])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc2)-287])(loc2);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F660_3045(RTCW(Result));
		for (;;) {
			tb2 = '\01';
			tb3 = F493_2350(RTCW(Result));
			if (!tb3) {
				tb3 = F631_2913(RTCW(Result));
				tb2 = tb3;
			}
			if (tb2) break;
			tb3 = '\0';
			tb4 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_3_);
			if ((EIF_BOOLEAN) !tb4) {
				tr1 = F660_3019(RTCW(Result));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tb4 = F660_3026(RTCW(tr1), loc1);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			if (tb3) {
				F660_3068(RTCW(Result));
			} else {
				F660_3047(RTCW(Result));
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc2)-287])(loc2);
	}
	F660_3045(RTCW(Result));
	for (;;) {
		tb3 = F631_2913(RTCW(Result));
		if (tb3) break;
		tr1 = F660_3019(RTCW(Result));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc3 = F660_3028(RTCW(tr1));
		tb4 = EIF_TRUE;
		for (;;) {
			if (!tb4) break;
			tb5 = F294_2176(loc3);
			if (tb5) break;
			tb6 = '\01';
			tr1 = F294_2167(loc3);
			tb7 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
			if (!tb7) {
				tr1 = F294_2167(loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tb6 = F43_607(Current, tr1);
			}
			tb4 = tb6;
			F294_2182(loc3);
		}
		if (tb4) {
			F660_3047(RTCW(Result));
		} else {
			F660_3068(RTCW(Result));
		}
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.expanded_switch_groups */
EIF_REFERENCE F43_638 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOSCF(702,F45_702, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,9,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F660_3035(RTCW(loc1));
	F660_3014(RTCW(Result), ti4_1);
	tr1 = F660_3028(RTCW(loc1));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F294_2176(loc2);
		if (tb1) break;
		tr1 = F294_2167(loc2);
		tr1 = F43_639(Current, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
		F294_2182(loc2);
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.expand_switch_group */
EIF_REFERENCE F43_639 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = F1_14(tr1);
	loc2 = RTOSCF(661,F43_661, (Current));
	tb1 = F493_2350(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		F660_3045(RTCW(loc1));
		for (;;) {
			tb1 = F631_2913(RTCW(loc1));
			if (tb1) break;
			loc3 = F660_3019(RTCW(loc1));
			tr1 = F673_3096(RTCW(loc2), loc3);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				loc5 = F595_2825(loc4);
				for (;;) {
					tb2 = F294_2176(loc5);
					if (tb2) break;
					loc3 = F294_2167(loc5);
					tb3 = F660_3026(RTCW(loc1), loc3);
					if ((EIF_BOOLEAN) !tb3) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(loc1))-659])(loc1, loc3);
					}
					F294_2182(loc5);
				}
			}
			F660_3047(RTCW(loc1));
		}
	}
	tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
	if (tb3) {
		Result = RTLNS(eif_new_type(9, 0x01).id, 9, _OBJSIZ_1_2_0_0_0_0_0_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
		F10_220(RTCW(Result), loc1, tb3);
	} else {
		Result = RTLNS(eif_new_type(9, 0x01).id, 9, _OBJSIZ_1_2_0_0_0_0_0_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
		F10_221(RTCW(Result), loc1, tb3);
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.add_error */
void F43_640 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(591,F43_591, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-659])(tr1, arg1);
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.add_template_error */
void F43_641 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(804, 0x01).id, 804, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F805_5040(RTCW(tr1), arg1, arg2);
	F43_640(Current, tr1);
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.display_usage */
void F43_642 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,tr3);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	tb1 = '\0';
	{
		/* INLINED CODE (ARGUMENT_BASE_PARSER.sub_system_name) */
		tr1 = (EIF_REFERENCE)  0;
		/* END INLINED CODE */
	}
	tr2 = tr1;
	loc5 = tr2;
	if (EIF_TEST(loc5)) {
		tb2 = F800_4777(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc3 = RTLNSMART(eif_new_type(799, 1).id);
		tr1 = F43_592(Current);
		tr2 = F796_4635(RTMS_EX_H(" ",1,32));
		tr1 = F800_4769(RTCW(tr1), tr2);
		tr1 = F800_4769(RTCW(tr1), loc5);
		F799_4708(RTCW(loc3), tr1);
	} else {
		loc3 = F43_592(Current);
	}
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTMS_EX_H("USAGE: \012",8,135033354));
	F28_450(RTCW(tr1), tr2);
	loc1 = RTOSCF(650,F43_650, (Current));
	tb1 = F493_2350(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		loc6 = F660_3028(RTCW(loc1));
		for (;;) {
			tb1 = F294_2176(loc6);
			if (tb1) break;
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = RTOSCF(668,F43_668, (Current));
			F28_450(RTCW(tr1), tr2);
			tr1 = RTOSCF(24,F1_24, (Current));
			F28_450(RTCW(tr1), loc3);
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = F796_4635(RTMS_EX_H(" ",1,32));
			F28_450(RTCW(tr1), tr2);
			loc4 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tr1 = F294_2167(loc6);
			F799_4708(RTCW(loc4), tr1);
			tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
			tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
			tr3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_2_);
			F799_4707(RTCW(tr3), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			tr2 = F801_4840(tr2, tr3);
			F801_4798(RTCW(loc4), tr1, tr2);
			tr1 = RTOSCF(24,F1_24, (Current));
			F28_450(RTCW(tr1), loc4);
			tb2 = F294_2180(loc6);
			if ((EIF_BOOLEAN) !tb2) {
				F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
			}
			F294_2182(loc6);
		}
	} else {
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = RTOSCF(668,F43_668, (Current));
		F28_450(RTCW(tr1), tr2);
		tr1 = RTOSCF(24,F1_24, (Current));
		F28_450(RTCW(tr1), loc3);
	}
	if (F43_617(Current)) {
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		F43_646(Current);
	}
	loc2 = RTOSCF(692,F44_692, (Current));
	tb2 = F800_4777(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb2) {
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		tr1 = RTOSCF(24,F1_24, (Current));
		F28_450(RTCW(tr1), loc2);
	}
	F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.display_logo */
void F43_643 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTCV(RTOSCF(696,F45_696, (Current))));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTMS_EX_H(" - Version: ",12,1246374688));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTCV(RTOSCF(700,F45_700, (Current))));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(695,F45_695, (Current));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3461[Dtype(RTCW(tr1))-799])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTCV(RTOSCF(695,F45_695, (Current))));
		F28_450(RTCW(tr1), tr2);
	}
	F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
	F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.display_version */
void F43_644 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTCV(RTOSCF(696,F45_696, (Current))));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTMS_EX_H(" version ",9,1056519968));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTCV(RTOSCF(700,F45_700, (Current))));
	F28_450(RTCW(tr1), tr2);
	tr1 = RTOSCF(695,F45_695, (Current));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3461[Dtype(RTCW(tr1))-799])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTCV(RTOSCF(695,F45_695, (Current))));
		F28_450(RTCW(tr1), tr2);
	}
	F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.display_errors */
void F43_645 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc1 = RTOSCF(591,F43_591, (Current));
	tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
	tr2 = RTOSCF(629,F43_629, (Current));
	tr3 = RTMS_EX_H("{1} error(s) occurred.\012",23,2016916746);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,715,726,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr4 = RTLNTS(typres0.id, 2, 1);
	}
	ti4_1 = F660_3035(RTCW(loc1));
	((EIF_TYPED_VALUE *)tr4+1)->it_i4 = ti4_1;
	tr2 = F805_5040(RTCW(tr2), tr3, tr4);
	F557_2680(RTCW(tr1), tr2);
	tr1 = F660_3028(RTCW(loc1));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F294_2176(loc2);
		if (tb1) break;
		tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
		tr2 = RTOSCF(668,F43_668, (Current));
		F557_2680(RTCW(tr1), tr2);
		tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
		tr2 = F796_4635(RTMS_EX_H("> ",2,15904));
		F557_2680(RTCW(tr1), tr2);
		tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
		tr2 = F294_2167(loc2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(668,F43_668, (Current)))+ _LNGOFF_1_0_0_2_);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		tr2 = F43_652(Current, tr2, (EIF_NATURAL_8) (tu1_1 + (EIF_NATURAL_8) ((EIF_INTEGER_32) 2L)));
		F557_2680(RTCW(tr1), tr2);
		tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
		F806_5086(RTCW(tr1));
		F294_2182(loc2);
	}
	tr1 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
	F806_5086(RTCW(tr1));
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.display_options */
void F43_646 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(22);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc7);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLR(7,loc4);
	RTLR(8,loc19);
	RTLR(9,loc5);
	RTLR(10,loc20);
	RTLR(11,loc21);
	RTLR(12,loc11);
	RTLR(13,loc10);
	RTLR(14,loc12);
	RTLR(15,loc22);
	RTLR(16,loc13);
	RTLR(17,loc15);
	RTLR(18,loc23);
	RTLR(19,loc24);
	RTLR(20,loc6);
	RTLR(21,loc14);
	RTLIU(22);
	
	RTGC;
	tr1 = RTOSCF(24,F1_24, (Current));
	tr2 = F796_4635(RTMS_EX_H("\012OPTIONS:\012",10,1841635338));
	F28_450(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,717,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc7 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(loc7), ((EIF_INTEGER_32) 0L));
	loc1 = RTOSCF(665,F43_665, (Current));
	loc3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F799_4706(RTCW(loc3), ((EIF_INTEGER_32) 1L));
	tw1 = F597_2821(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	F801_4834(RTCW(loc3), tw1);
	ti4_1 = F597_2828(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		loc2 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = F597_2828(RTCW(loc1));
		F799_4706(RTCW(loc2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 5L)) + ((EIF_INTEGER_32) 2L)));
		loc18 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_1_);
		loc17 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc18 > loc17)) break;
			if ((EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 1L))) {
				if ((EIF_BOOLEAN) (loc18 < loc17)) {
					tr1 = RTMS_EX_H(", ",2,11296);
					F801_4820(RTCW(loc2), tr1);
				} else {
					tr1 = RTMS_EX_H(" or ",4,544174624);
					F801_4820(RTCW(loc2), tr1);
				}
			}
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			F801_4834(RTCW(loc2), tw1);
			tw1 = F597_2821(RTCW(loc1), loc18);
			F801_4834(RTCW(loc2), tw1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			F801_4834(RTCW(loc2), tw1);
			loc18++;
		}
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = RTOSCF(668,F43_668, (Current));
		F28_450(RTCW(tr1), tr2);
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTMS_EX_H("Options ",8,506073632));
		F28_450(RTCW(tr1), tr2);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) {
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = F796_4635(RTMS_EX_H("are case-sensitive and ",23,1259914016));
			F28_450(RTCW(tr1), tr2);
		}
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTMS_EX_H("should be prefixed with: ",25,889669920));
		F28_450(RTCW(tr1), tr2);
		tr1 = RTOSCF(24,F1_24, (Current));
		F28_450(RTCW(tr1), loc2);
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
	}
	loc4 = RTOSCF(658,F43_658, (Current));
	loc19 = F660_3028(RTCW(loc4));
	for (;;) {
		tb1 = F294_2176(loc19);
		if (tb1) break;
		loc5 = F294_2167(loc19);
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_3_2_);
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = '\01';
			if (!RTOSCF(615,F43_615, (Current))) {
				tb3 = F717_3459(RTCW(loc5));
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
				ti4_1 = eif_max_int32 (loc9,(EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 5L)));
				loc9 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
				ti4_1 = eif_max_int32 (loc9,(EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				loc9 = (EIF_INTEGER_32) ti4_1;
			}
		}
		F294_2182(loc19);
	}
	loc16 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_);
	loc20 = F660_3028(RTCW(loc4));
	for (;;) {
		tb2 = F294_2176(loc20);
		if (tb2) break;
		loc5 = F294_2167(loc20);
		loc21 = loc5;
		loc21 = RTRV(eif_new_type(717, 0x01),loc21);
		if (EIF_TEST(loc21)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(loc7))-659])(loc7, loc21);
		}
		tb3 = F717_3459(RTCW(loc5));
		if (tb3) {
			loc11 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F799_4706(RTCW(loc11), ((EIF_INTEGER_32) 20L));
			F801_4821(RTCW(loc11), loc3);
			tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc5)+ _LNGOFF_3_4_0_0_);
			F801_4834(RTCW(loc11), tw1);
			tr1 = RTMS_EX_H(" ",1,32);
			F801_4820(RTCW(loc11), tr1);
			if (RTOSCF(615,F43_615, (Current))) {
				F801_4821(RTCW(loc11), loc3);
			}
			F801_4821(RTCW(loc11), loc3);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
			F801_4821(RTCW(loc11), tr1);
		} else {
			if (RTOSCF(615,F43_615, (Current))) {
				tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000 \000\000\000",3,2105376);
				tr1 = F801_4840(tr1, loc3);
				tr1 = F801_4840(RTCW(tr1), loc3);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				loc11 = F801_4840(RTCW(tr1), tr2);
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				loc11 = F801_4840(RTCW(loc3), tr1);
			}
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc9 > ti4_1)) {
			loc10 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_2_);
			F799_4707(RTCW(loc10), tw1, (EIF_INTEGER_32) (loc9 - ti4_1));
		} else {
			loc10 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F796_4576(RTCW(loc10));
		}
		F801_4838(RTCW(loc10), loc11, ((EIF_INTEGER_32) 1L));
		loc12 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F799_4706(RTCW(loc12), ((EIF_INTEGER_32) 256L));
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_2_);
		F801_4821(RTCW(loc12), tr1);
		tb3 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_3_0_);
		if (tb3) {
			tr1 = RTMS_EX_H(" (Optional)",11,1464035113);
			F801_4820(RTCW(loc12), tr1);
		}
		loc8 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(668,F43_668, (Current)))+ _LNGOFF_1_0_0_2_);
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + ti4_1) + ((EIF_INTEGER_32) 2L));
		tu1_1 = (EIF_NATURAL_8) loc8;
		tr1 = F43_652(Current, loc12, tu1_1);
		loc12 = (EIF_REFERENCE) tr1;
		loc22 = loc5;
		loc22 = RTRV(eif_new_type(717, 0x01),loc22);
		if ((EIF_BOOLEAN) (loc16 && EIF_TEST(loc22))) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			F801_4834(RTCW(loc12), tw1);
			tr1 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F799_4707(RTCW(tr1), tw1, loc8);
			F801_4821(RTCW(loc12), tr1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
			F801_4834(RTCW(loc12), tw1);
			tr1 = *(EIF_REFERENCE *)(loc22);
			F801_4821(RTCW(loc12), tr1);
			tr1 = RTMS_EX_H(">: ",3,4078112);
			F801_4820(RTCW(loc12), tr1);
			loc13 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F799_4706(RTCW(loc13), ((EIF_INTEGER_32) 32L));
			tb3 = *(EIF_BOOLEAN *)(loc22);
			if (tb3) {
				tr1 = RTMS_EX_H("(Optional) ",11,342873376);
				F801_4820(RTCW(loc13), tr1);
			}
			tr1 = *(EIF_REFERENCE *)(loc22);
			F801_4821(RTCW(loc13), tr1);
			tr1 = *(EIF_REFERENCE *)(loc22);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
			tu1_1 = (EIF_NATURAL_8) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + ti4_1) + ((EIF_INTEGER_32) 4L));
			tr1 = F43_652(Current, loc13, tu1_1);
			loc13 = (EIF_REFERENCE) tr1;
			F801_4821(RTCW(loc12), loc13);
		}
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = RTOSCF(668,F43_668, (Current));
		F28_450(RTCW(tr1), tr2);
		tr1 = RTOSCF(24,F1_24, (Current));
		F28_450(RTCW(tr1), loc10);
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTMS_EX_H(": ",2,14880));
		F28_450(RTCW(tr1), tr2);
		tr1 = RTOSCF(24,F1_24, (Current));
		F28_450(RTCW(tr1), loc12);
		F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
		F294_2182(loc20);
	}
	tb3 = '\0';
	if ((EIF_BOOLEAN) !loc16) {
		tb4 = F493_2350(RTCW(loc7));
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tr1 = RTOSCF(24,F1_24, (Current));
		tr2 = F796_4635(RTMS_EX_H("\012ARGUMENTS:\012",12,1590959370));
		F28_450(RTCW(tr1), tr2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,680,720,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc15 = RTLNS(typres0.id, 680, _OBJSIZ_5_6_0_7_0_0_0_0_);
		}
		ti4_1 = F660_3035(RTCW(loc7));
		F678_3090(RTCW(loc15), ti4_1);
		loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc23 = F660_3028(RTCW(loc7));
		for (;;) {
			tb3 = F294_2176(loc23);
			if (tb3) break;
			tr1 = F294_2167(loc23);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
			ti4_1 = eif_max_int32 (loc9,ti4_1);
			loc9 = (EIF_INTEGER_32) ti4_1;
			F294_2182(loc23);
		}
		loc24 = F660_3028(RTCW(loc7));
		for (;;) {
			tb4 = F294_2176(loc24);
			if (tb4) break;
			loc6 = F294_2167(loc24);
			loc14 = *(EIF_REFERENCE *)(RTCW(loc6));
			tb5 = F678_3098(RTCW(loc15), loc14);
			if ((EIF_BOOLEAN) !tb5) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				if ((EIF_BOOLEAN) (loc9 > ti4_1)) {
					loc10 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
					F799_4707(RTCW(loc10), tw1, (EIF_INTEGER_32) (loc9 - ti4_1));
				} else {
					loc10 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F796_4576(RTCW(loc10));
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
				F801_4839(RTCW(loc10), tw1, ((EIF_INTEGER_32) 1L));
				F801_4838(RTCW(loc10), loc14, ((EIF_INTEGER_32) 2L));
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				F801_4839(RTCW(loc10), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(668,F43_668, (Current)))+ _LNGOFF_1_0_0_2_);
				tu1_1 = (EIF_NATURAL_8) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 4L));
				loc12 = F43_652(Current, tr1, tu1_1);
				tr1 = RTOSCF(24,F1_24, (Current));
				tr2 = RTOSCF(668,F43_668, (Current));
				F28_450(RTCW(tr1), tr2);
				tr1 = RTOSCF(24,F1_24, (Current));
				F28_450(RTCW(tr1), loc10);
				tr1 = RTOSCF(24,F1_24, (Current));
				tr2 = F796_4635(RTMS_EX_H(": ",2,14880));
				F28_450(RTCW(tr1), tr2);
				tr1 = RTOSCF(24,F1_24, (Current));
				F28_450(RTCW(tr1), loc12);
				F28_471(RTCV(RTOSCF(24,F1_24, (Current))));
				F678_3136(RTCW(loc15), (EIF_BOOLEAN) 1, loc14);
			}
			F294_2182(loc24);
		}
	}
	RTLE;
}

/* {ARGUMENT_BASE_PARSER}.command_option_configurations */
static EIF_REFERENCE F43_650_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,loc2);
	RTLR(10,loc5);
	RTLIU(11);
	
	RTEV;
	RTGC;
	RTOSP (650);
#define Result RTOSR(650)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,799,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	F344_2220(RTCW(Result));
	loc1 = RTOSCF(702,F45_702, (Current));
	loc6 = F493_2350(RTCW(loc1));
	if ((EIF_BOOLEAN) !loc6) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,715,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,794,0xFF01,0xFFF9,1,715,0xFF01,9,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A31_132_2, (EIF_POINTER) _A31_132_2, 0, tr1, 0, 1);
		}
		loc6 = F660_3032(RTCW(loc1), tr4);
	}
	if (loc6) {
		loc4 = RTOSCF(658,F43_658, (Current));
		loc3 = F44_691(Current, loc4, *(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_), *(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_), (EIF_BOOLEAN) 1, loc4);
		tb1 = F495_2350(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
			F800_4761(RTCW(tr1), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
		}
	} else {
		F660_3063(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		tr1 = F660_3028(RTCW(loc1));
		loc7 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F294_2176(loc7);
			if (tb1) break;
			loc2 = F294_2167(loc7);
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_0_);
			if ((EIF_BOOLEAN) !tb2) {
				loc4 = *(EIF_REFERENCE *)(RTCW(loc2));
				tr1 = RTOSCF(654,F43_654, (Current));
				if (F43_619(Current, tr1)) {
					tr1 = RTOSCF(654,F43_654, (Current));
					loc5 = F43_628(Current, tr1);
					tb2 = F660_3026(RTCW(loc4), loc5);
					if ((EIF_BOOLEAN) !tb2) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(loc4))-659])(loc4, loc5);
					}
				}
				tb2 = '\0';
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_)) {
					tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_1_);
					tb2 = tb3;
				}
				loc3 = F44_691(Current, loc4, tb2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, loc4);
				tb2 = '\0';
				tb3 = F495_2350(RTCW(loc3));
				if ((EIF_BOOLEAN) !tb3) {
					tr1 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F800_4761(RTCW(tr1), loc3);
					tb3 = F660_3026(RTCW(Result), tr1);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					tr1 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F800_4761(RTCW(tr1), loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
				}
			}
			F294_2182(loc7);
		}
	}
	RTOSE (650);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_650 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(650,F43_650_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.command_option_group_configuration */
EIF_REFERENCE F43_651 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc8 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc14);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,arg5);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,loc2);
	RTLR(12,loc17);
	RTLR(13,loc7);
	RTLIU(14);
	
	RTGC;
	tb1 = F493_2350(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTOSCF(661,F43_661, (Current));
		tr1 = RTOSCF(665,F43_665, (Current));
		loc8 = F597_2821(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		loc3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
		loc4 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_);
		loc5 = RTOSCF(615,F43_615, (Current));
		Result = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = F660_3035(RTCW(arg1));
		F799_4706(RTCW(Result), (EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 12L)));
		loc14 = F660_3028(RTCW(arg1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc14)-287])(loc14);
			if (tb1) break;
			loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc14)-287])(loc14);
			loc9 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_3_0_);
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
			tr2 = RTOSCF(655,F43_655, (Current));
			tb3 = F799_4733(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_3_2_);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				loc11 = '\01';
				if ((EIF_BOOLEAN) !arg4) {
					tb2 = '\01';
					tb3 = F660_3026(RTCW(arg5), loc6);
					if (!(EIF_BOOLEAN) !tb3) {
						tb3 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_3_0_);
						tb2 = tb3;
					}
					loc11 = tb2;
				}
				if (loc11) {
					if (loc9) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
						F801_4834(RTCW(Result), tw1);
					}
					F801_4834(RTCW(Result), loc8);
					if (loc4) {
						if (loc5) {
							F801_4834(RTCW(Result), loc8);
						}
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
						F801_4821(RTCW(Result), tr1);
					} else {
						tb2 = '\0';
						if (loc5) {
							tb3 = F717_3459(RTCW(loc6));
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) {
							F801_4834(RTCW(Result), loc8);
						}
						tr1 = F717_3450(RTCW(loc6));
						F801_4821(RTCW(Result), tr1);
					}
					loc15 = loc6;
					loc15 = RTRV(eif_new_type(717, 0x01),loc15);
					if (EIF_TEST(loc15)) {
						loc10 = *(EIF_BOOLEAN *)(loc15);
						if (loc10) {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
							F801_4834(RTCW(Result), tw1);
						}
						if (loc3) {
							tr1 = RTMS_EX_H(" <",2,8252);
							F801_4820(RTCW(Result), tr1);
						} else {
							tw1 = RTOSCF(666,F43_666, (Current));
							F801_4834(RTCW(Result), tw1);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
							F801_4834(RTCW(Result), tw1);
						}
						tr1 = *(EIF_REFERENCE *)(loc15);
						F801_4821(RTCW(Result), tr1);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
						F801_4834(RTCW(Result), tw1);
						if (loc10) {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
							F801_4834(RTCW(Result), tw1);
						}
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN)(loc1 != NULL)) {
						tb3 = F673_3098(RTCW(loc1), loc6);
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = F673_3096(RTCW(loc1), loc6);
						loc16 = tr1;
						if (EIF_TEST(loc16)) {
							tb2 = F493_2350(loc16);
							if ((EIF_BOOLEAN) !tb2) {
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,716,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									loc2 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
								}
								ti4_1 = F595_2828(loc16);
								F660_3014(RTCW(loc2), ti4_1);
								loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								loc13 = *(EIF_INTEGER_32 *)(loc16+ _LNGOFF_1_1_0_0_);
								for (;;) {
									if ((EIF_BOOLEAN) (loc12 > loc13)) break;
									tr1 = F595_2821(loc16, loc12);
									loc17 = tr1;
									if (EIF_TEST(loc17)) {
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(loc2))-659])(loc2, loc17);
									}
									loc12++;
								}
								loc7 = F44_691(Current, loc2, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, arg5);
								tb2 = F495_2350(RTCW(loc7));
								if ((EIF_BOOLEAN) !tb2) {
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
									F801_4834(RTCW(Result), tw1);
									F801_4821(RTCW(Result), loc7);
								}
							}
						} else {
						}
					}
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_3_1_);
					if (tb2) {
						tr1 = RTMS_EX_H(" [",2,8283);
						F801_4820(RTCW(Result), tr1);
						F801_4834(RTCW(Result), loc8);
						tr1 = F717_3450(RTCW(loc6));
						F801_4821(RTCW(Result), tr1);
						tr1 = RTMS_EX_H("...]",4,774778461);
						F801_4820(RTCW(Result), tr1);
					}
					if (loc9) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
						F801_4834(RTCW(Result), tw1);
					}
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1951[Dtype(loc14)-287])(loc14);
					if ((EIF_BOOLEAN) !tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						F801_4834(RTCW(Result), tw1);
					}
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc14)-287])(loc14);
		}
	} else {
		Result = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F796_4576(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.format_terminal_text */
EIF_REFERENCE F43_652 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	tr1 = F796_4635(RTCW(arg1));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
	loc2 = F796_4654(RTCW(tr1), tw1);
	loc1 = (EIF_INTEGER_32) RTOSCF(599,F43_599, (Current));
	ti4_1 = (EIF_INTEGER_32) arg2;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	loc3 = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	ti4_1 = (EIF_INTEGER_32) arg2;
	F799_4707(RTCW(loc3), tw1, ti4_1);
	Result = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3483[Dtype(RTCW(arg1))-799])(arg1);
	ti4_2 = F660_3035(RTCW(loc2));
	ti4_3 = (EIF_INTEGER_32) ((EIF_NATURAL_8) (arg2 + (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L)));
	F799_4706(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (ti4_2 * ti4_3)));
	F660_3045(RTCW(loc2));
	for (;;) {
		tb1 = F631_2913(RTCW(loc2));
		if (tb1) break;
		tr1 = F660_3019(RTCW(loc2));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tb2 = F495_2350(RTCW(Result));
			if ((EIF_BOOLEAN) !tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				F801_4834(RTCW(Result), tw1);
				F801_4821(RTCW(Result), loc3);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > loc1)) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
				loc4 = eif_min_int32 (ti4_1,loc1);
				for (;;) {
					tb2 = '\01';
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
						tw1 = F801_4788(loc5, loc4);
						tr1 = RTLNS(eif_new_type(753, 0x00).id, 753, _OBJSIZ_0_0_0_1_0_0_0_0_);
						*(EIF_CHARACTER_32 *)tr1 = tw1;
						tb4 = F752_4433(RTCW(tr1));
						tb3 = tb4;
					}
					if (!tb3) {
						tw1 = F801_4788(loc5, loc4);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) break;
					loc4--;
				}
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_INTEGER_32) loc1;
				}
				tr1 = F801_4868(loc5, ((EIF_INTEGER_32) 1L), loc4);
				F801_4821(RTCW(Result), tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
				F801_4804(loc5, (EIF_INTEGER_32) (ti4_1 - loc4));
				F801_4805(loc5);
			} else {
				F801_4821(RTCW(Result), loc5);
				F801_4850(loc5);
			}
			tb3 = F495_2350(loc5);
			if (tb3) {
				F660_3047(RTCW(loc2));
			}
		} else {
			F660_3047(RTCW(loc2));
		}
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.nologo_switch */
static EIF_REFERENCE F43_654_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (654);
#define Result RTOSR(654)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("nologo",6,2036361583);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (654);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_654 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(654,F43_654_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.help_switch */
static EIF_REFERENCE F43_655_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (655);
#define Result RTOSR(655)
	RTOC_NEW(Result);
	if (RTOSCF(615,F43_615, (Current))) {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("\?|help",6,1876292720);
			F800_4759(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("h|help",6,1956902000);
			F800_4759(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("\?",1,63);
			F800_4760(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("help",4,1751477360);
			F800_4760(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTOSE (655);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_655 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(655,F43_655_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.version_switch */
static EIF_REFERENCE F43_656_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (656);
#define Result RTOSR(656)
	RTOC_NEW(Result);
	if (RTOSCF(615,F43_615, (Current))) {
		tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr2 = RTMS_EX_H("v|version",9,1943702638);
		F800_4759(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr2 = RTMS_EX_H("version",7,1397649262);
		F800_4759(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (656);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_656 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(656,F43_656_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.available_switches */
static EIF_REFERENCE F43_657_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOSP (657);
#define Result RTOSR(657)
	RTOC_NEW(Result);
	loc1 = RTOSCF(701,F45_701, (Current));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,716,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		ti4_1 = F660_3035(RTCW(loc1));
		F660_3014(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) + ti4_1));
		Result = (EIF_REFERENCE) tr1;
		F660_3061(RTCW(Result), loc1);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,716,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 3L));
		Result = (EIF_REFERENCE) tr1;
	}
	loc2 = RTLNS(eif_new_type(716, 0x01).id, 716, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr1 = RTOSCF(655,F43_655, (Current));
	tr2 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTMS_EX_H("Display usage information.",26,790767406);
	F800_4760(RTCW(tr2), tr3);
	F717_3447(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	F717_3461(RTCW(loc2));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_)) {
		loc2 = RTLNS(eif_new_type(716, 0x01).id, 716, _OBJSIZ_3_4_0_1_0_0_0_0_);
		tr1 = RTOSCF(656,F43_656, (Current));
		tr2 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr3 = RTMS_EX_H("Displays version information.",29,582720558);
		F800_4760(RTCW(tr2), tr3);
		F717_3447(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		F717_3461(RTCW(loc2));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
		loc2 = RTLNS(eif_new_type(716, 0x01).id, 716, _OBJSIZ_3_4_0_1_0_0_0_0_);
		tr1 = RTOSCF(654,F43_654, (Current));
		tr2 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr3 = RTMS_EX_H("Supresses copyright information.",32,1705082414);
		F800_4760(RTCW(tr2), tr3);
		F717_3447(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		F717_3461(RTCW(loc2));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
	}
	RTOSE (657);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_657 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(657,F43_657_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.available_visible_switches */
static EIF_REFERENCE F43_658_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (658);
#define Result RTOSR(658)
	RTOC_NEW(Result);
	loc1 = RTOSCF(657,F43_657, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,716,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F660_3035(RTCW(loc1));
	F660_3014(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	tr1 = F660_3028(RTCW(loc1));
	loc3 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F294_2176(loc3);
		if (tb1) break;
		loc2 = F294_2167(loc3);
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_2_);
		if ((EIF_BOOLEAN) !tb2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, loc2);
		}
		F294_2182(loc3);
	}
	RTOSE (658);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_658 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(658,F43_658_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.switch_dependencies */
static EIF_REFERENCE F43_661_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (661);
#define Result RTOSR(661)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,672,0xFF01,594,0xFF01,716,0xFF01,716,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 672, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F673_3090(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (661);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_661 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(661,F43_661_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.ellipse_text */
EIF_REFERENCE F43_662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3461[Dtype(RTCW(arg1))-799])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(629,F43_629, (Current));
		ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_8) 255U);
		Result = F805_5041(RTCW(tr1), arg1, ti4_1);
	} else {
		Result = RTLNS(eif_new_type(800, 0x01).id, 800, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F796_4576(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.new_argument_source */
EIF_REFERENCE F43_664 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ARGUMENT_BASE_PARSER}.switch_prefixes */
static EIF_REFERENCE F43_665_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (665);
#define Result RTOSR(665)
	RTOC_NEW(Result);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		{
			static EIF_TYPE_INDEX typarr0[] = {571,753,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 2L),sizeof(EIF_CHARACTER_32), EIF_TRUE);
			RT_SPECIAL_COUNT(tr2) = 2L;
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		*((EIF_CHARACTER_32 *)tr2+0) = (EIF_CHARACTER_32) tw1;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
		*((EIF_CHARACTER_32 *)tr2+1) = (EIF_CHARACTER_32) tw1;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F572_2736)(tr2);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {571,753,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 1L),sizeof(EIF_CHARACTER_32), EIF_TRUE);
			RT_SPECIAL_COUNT(tr3) = 1L;
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		*((EIF_CHARACTER_32 *)tr3+0) = (EIF_CHARACTER_32) tw1;
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F572_2736)(tr3);
		tr1 = tr2;
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (665);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_665 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(665,F43_665_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.switch_value_qualifer */
static EIF_CHARACTER_32 F43_666_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (666);
#define Result RTOSR(666)
	Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	RTOSE (666);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F43_666 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(666,F43_666_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.default_system_name */
static EIF_REFERENCE F43_667_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (667);
#define Result RTOSR(667)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("app",3,6385776);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (667);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_667 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(667,F43_667_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.tab_string */
static EIF_REFERENCE F43_668_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (668);
#define Result RTOSR(668)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("   ",3,2105376);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (668);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_668 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(668,F43_668_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_switch_error */
static EIF_REFERENCE F43_669_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (669);
#define Result RTOSR(669)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("The switch \'{1}\' is invalid.",28,1573419310);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (669);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_669 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(669,F43_669_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_unrecognized_switch_error */
static EIF_REFERENCE F43_670_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (670);
#define Result RTOSR(670)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Unrecognized switch \'{1}\'.",26,1405505070);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (670);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_670 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(670,F43_670_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_require_switch_value */
static EIF_REFERENCE F43_672_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (672);
#define Result RTOSR(672)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' requires a paired value \'{2}\'.",43,736796462);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (672);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_672 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(672,F43_672_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_multiple_switch_error */
static EIF_REFERENCE F43_673_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (673);
#define Result RTOSR(673)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' can only be used once.",35,2066790446);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (673);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_673 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(673,F43_673_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_non_value_switch */
static EIF_REFERENCE F43_674_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (674);
#define Result RTOSR(674)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' should not have any value paired with it.",54,510438446);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (674);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_674 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(674,F43_674_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_missing_switch_error */
static EIF_REFERENCE F43_675_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (675);
#define Result RTOSR(675)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' was not specified.",31,1763454766);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (675);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_675 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(675,F43_675_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_non_switched_argument_specified_error */
static EIF_REFERENCE F43_676_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (676);
#define Result RTOSR(676)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Arguments without a switch prefix are not valid arguments.",58,156258862);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (676);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_676 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(676,F43_676_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_switch_group_unrecognized_error */
static EIF_REFERENCE F43_678_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (678);
#define Result RTOSR(678)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("The specified switches are not in a valid configuration.",56,723639342);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (678);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_678 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(678,F43_678_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_missing_switch_dependency_error */
static EIF_REFERENCE F43_679_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (679);
#define Result RTOSR(679)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' require the switch \'{2}\' be specified also.",56,1344471598);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (679);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_679 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(679,F43_679_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_switch_value_with_reason */
static EIF_REFERENCE F43_680_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (680);
#define Result RTOSR(680)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("\'{1}\' is an invalid option for switch \'{2}\'.\012{3}",48,341313917);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (680);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_680 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(680,F43_680_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_non_switched_value_with_reason */
static EIF_REFERENCE F43_681_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (681);
#define Result RTOSR(681)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(799, 0x01).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("\'{1}\' is an invalid option.\012{2}",31,1578061949);
	F800_4759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (681);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_681 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(681,F43_681_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.internal_option_of_name */
EIF_REFERENCE F43_682 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	loc3 = F660_3028(RTCV(F43_590(Current)));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1872[Dtype(loc3)-287])(loc3);
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1871[Dtype(loc3)-287])(loc3);
		if (loc1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = F796_4621(RTCW(arg1), tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F796_4618(RTCW(arg1), tr1);
			tb2 = tb3;
		}
		if (tb2) {
			Result = (EIF_REFERENCE) loc2;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1873[Dtype(loc3)-287])(loc3);
	}
	RTLE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.fake inline-agent#5226#126#35# of command_option_configurations */
EIF_BOOLEAN F43_5226 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
