
#ifndef _C1_ar3_
#define _C1_ar3_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F3_46(EIF_REFERENCE);
extern void EIF_Minit3(void);

#ifdef __cplusplus
}
#endif

#endif
