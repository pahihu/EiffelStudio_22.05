
#ifndef _C1_ar6_
#define _C1_ar6_

#ifdef __cplusplus
extern "C" {
#endif

extern void F6_58(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F6_61(EIF_REFERENCE);
extern EIF_BOOLEAN F6_63(EIF_REFERENCE);
extern void EIF_Minit6(void);
extern void F796_4576(EIF_REFERENCE);
extern EIF_BOOLEAN F800_4777(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
