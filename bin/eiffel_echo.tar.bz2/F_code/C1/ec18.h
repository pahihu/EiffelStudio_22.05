
#ifndef _C1_ec18_
#define _C1_ec18_

#ifdef __cplusplus
extern "C" {
#endif

extern void F30_504(EIF_REFERENCE, EIF_REFERENCE);
extern void F30_506(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit18(void);
extern void F812_5169(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1006[])();
extern char *(*R1007[])();
extern char *(*R1008[])();

#ifdef __cplusplus
}
#endif

#endif
