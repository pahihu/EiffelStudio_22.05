/*
 * Code for class CODE_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co20.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_SETS}.two_byte_code_pages */
static EIF_REFERENCE F32_510_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (510);
#define Result RTOSR(510)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,678,0xFF01,801,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 678, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F679_3202(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2",5,1130177330);
	tr2 = RTMS_EX_H("ucs-2",5,1669391154);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-2",15,137660722);
	tr2 = RTMS_EX_H("iso-10646-ucs-2",15,932466994);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode",9,1140938597);
	tr2 = RTMS_EX_H("csunicode",9,67227493);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODE-1-1",11,1407647281);
	tr2 = RTMS_EX_H("unicode-1-1",11,366474289);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode11",11,1599950641);
	tr2 = RTMS_EX_H("csunicode11",11,1339907633);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(52,F5_52, (Current));
	tr2 = RTMS_EX_H("utf-16",6,1945159990);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(56,F5_56, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(54,F5_54, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-INTERNAL",14,834453068);
	tr2 = RTMS_EX_H("ucs-2-internal",14,1377880940);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-SWAPPED",13,297507908);
	tr2 = RTMS_EX_H("ucs-2-swapped",13,861666404);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("JAVA",4,1245795905);
	tr2 = RTMS_EX_H("java",4,1784772193);
	F673_3136(RTCW(Result), tr1, tr2);
	RTOSE (510);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_510 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(510,F32_510_body,(Current));
}

/* {CODE_SETS}.four_byte_code_pages */
static EIF_REFERENCE F32_511_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (511);
#define Result RTOSR(511)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,678,0xFF01,801,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 678, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F679_3202(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-4",5,1130177332);
	tr2 = RTMS_EX_H("ucs-4",5,1669391156);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-4",15,137660724);
	tr2 = RTMS_EX_H("iso-10646-ucs-4",15,932466996);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUCS4",6,1626000692);
	tr2 = RTMS_EX_H("csucs4",6,17497140);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(53,F5_53, (Current));
	tr2 = RTMS_EX_H("utf-32",6,1945160498);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(57,F5_57, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(55,F5_55, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-INTERNAL",14,968724556);
	tr2 = RTMS_EX_H("ucs-4-internal",14,1512152428);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-SWAPPED",13,415472708);
	tr2 = RTMS_EX_H("ucs-4-swapped",13,979631204);
	F673_3136(RTCW(Result), tr1, tr2);
	RTOSE (511);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_511 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(511,F32_511_body,(Current));
}

/* {CODE_SETS}.little_endian_code_pages */
static EIF_REFERENCE F32_512_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (512);
#define Result RTOSR(512)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,678,0xFF01,801,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 678, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F679_3202(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(54,F5_54, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(55,F5_55, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F673_3136(RTCW(Result), tr1, tr2);
	RTOSE (512);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_512 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(512,F32_512_body,(Current));
}

/* {CODE_SETS}.big_endian_code_pages */
static EIF_REFERENCE F32_513_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (513);
#define Result RTOSR(513)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,678,0xFF01,801,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 678, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F679_3202(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(56,F5_56, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F673_3136(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(57,F5_57, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F673_3136(RTCW(Result), tr1, tr2);
	RTOSE (513);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_513 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(513,F32_513_body,(Current));
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
