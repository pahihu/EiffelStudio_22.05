
#ifndef _C1_ar25_
#define _C1_ar25_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,552)
static EIF_REFERENCE F37_552_body(EIF_REFERENCE);
extern EIF_REFERENCE F37_552(EIF_REFERENCE);
extern void EIF_Minit25(void);
extern EIF_REFERENCE F242_2081(EIF_REFERENCE);
extern void F684_3225(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2081)

#ifdef __cplusplus
}
#endif

#endif
