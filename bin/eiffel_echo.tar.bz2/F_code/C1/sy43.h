
#ifndef _C1_sy43_
#define _C1_sy43_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F64_877(EIF_REFERENCE);
extern EIF_REFERENCE F64_878(EIF_REFERENCE);
extern EIF_BOOLEAN F64_880(EIF_REFERENCE);
extern EIF_POINTER F64_881(EIF_REFERENCE);
extern EIF_INTEGER_32 F64_882(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit43(void);
extern EIF_REFERENCE F63_867(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
