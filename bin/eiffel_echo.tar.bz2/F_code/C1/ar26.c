/*
 * Code for class ARGUMENT_TERMINAL_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar26.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_TERMINAL_SOURCE}.arguments */
static EIF_REFERENCE F38_556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (556);
#define Result RTOSR(556)
	RTOC_NEW(Result);
	loc1 = F242_2079(RTCV(RTOSCF(557,F38_557, (Current))));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,799,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(tr1), loc2);
	Result = (EIF_REFERENCE) tr1;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc2)) break;
		tr1 = F595_2821(RTCW(loc1), loc3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
		loc3++;
	}
	RTOSE (556);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(556,F38_556_body,(Current));
}

/* {ARGUMENT_TERMINAL_SOURCE}.terminal_arguments */
static EIF_REFERENCE F38_557_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (557);
#define Result RTOSR(557)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(241, 0x01).id, 241, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (557);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_557 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(557,F38_557_body,(Current));
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
