/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy34.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F46_708_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (708);
#define Result RTOSR(708)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(6, 0x01).id, 6, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F64_878(RTCV(RTOSCF(713,F46_713, (Current))));
	F7_65(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (708);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_708 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(708,F46_708_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F46_709_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (709);
#define Result RTOSR(709)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(6, 0x01).id, 6, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(51,F5_51, (Current));
	F7_65(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (709);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_709 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(709,F46_709_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F46_711_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (711);
#define Result RTOSR(711)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(6, 0x01).id, 6, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(53,F5_53, (Current));
	F7_65(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (711);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_711 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(711,F46_711_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F46_713_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (713);
#define Result RTOSR(713)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(63, 0x01).id, 63, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (713);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_713 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(713,F46_713_body,(Current));
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
