
#ifndef _C1_pl41_
#define _C1_pl41_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F59_811(EIF_REFERENCE);
RTOSHF (EIF_BOOLEAN,816)
static EIF_BOOLEAN F59_816_body(EIF_REFERENCE);
extern EIF_BOOLEAN F59_816(EIF_REFERENCE);
extern void EIF_Minit41(void);

#ifdef __cplusplus
}
#endif

#endif
