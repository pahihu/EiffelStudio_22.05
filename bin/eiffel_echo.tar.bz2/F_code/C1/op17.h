
#ifndef _C1_op17_
#define _C1_op17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F29_501(EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
