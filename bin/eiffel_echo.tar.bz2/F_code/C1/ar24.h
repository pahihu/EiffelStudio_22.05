
#ifndef _C1_ar24_
#define _C1_ar24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F36_551(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit24(void);

#ifdef __cplusplus
}
#endif

#endif
