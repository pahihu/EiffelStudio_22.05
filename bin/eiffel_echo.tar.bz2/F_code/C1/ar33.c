/*
 * Code for class ARGUMENT_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_PARSER}.copyright */

EIF_REFERENCE F45_695 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (695,RTMS_EX_H("Copyright Eiffel Software 1985-2022. All Rights Reserved.",57,1072541998));
}

/* {ARGUMENT_PARSER}.name */

EIF_REFERENCE F45_696 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (696,RTMS_EX_H("eiffel_echo",11,2111720815));
}

/* {ARGUMENT_PARSER}.non_switched_argument_description */

EIF_REFERENCE F45_697 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (697,RTMS_EX_H("Text which will be displayed by tool",36,1511474028));
}

/* {ARGUMENT_PARSER}.non_switched_argument_name */

EIF_REFERENCE F45_698 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (698,RTMS_EX_H("input",5,1853670260));
}

/* {ARGUMENT_PARSER}.non_switched_argument_type */

EIF_REFERENCE F45_699 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (699,RTMS_EX_H("string",6,2146502247));
}

/* {ARGUMENT_PARSER}.version */

EIF_REFERENCE F45_700 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (700,RTMS_EX_H("0.1",3,3157553));
}

/* {ARGUMENT_PARSER}.switches */
static EIF_REFERENCE F45_701_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (701);
#define Result RTOSR(701)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,716,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(716, 0x01).id, 716, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOSCF(703,F45_703, (Current));
	F800_4760(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Make tool read line from STDIN instead of using arguments. A line only containing \"quit\" will make tool quit..",110,2037480494);
	F800_4760(RTCW(tr3), tr4);
	F717_3447(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
	tr1 = RTLNS(eif_new_type(716, 0x01).id, 716, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOSCF(704,F45_704, (Current));
	F800_4760(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(799, 0x00).id, 799, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Make tool print output as errors.",33,478728238);
	F800_4760(RTCW(tr3), tr4);
	F717_3447(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
	RTOSE (701);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F45_701 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(701,F45_701_body,(Current));
}

/* {ARGUMENT_PARSER}.switch_groups */
static EIF_REFERENCE F45_702_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (702);
#define Result RTOSR(702)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,659,0xFF01,9,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 659, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F660_3014(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(9, 0x01).id, 9, _OBJSIZ_1_2_0_0_0_0_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {569,0xFF01,716,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 1L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTOSCF(704,F45_704, (Current));
	tr4 = F43_628(Current, tr4);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F570_2736)(tr3);
	F10_220(RTCW(tr1), tr2, (EIF_BOOLEAN) 1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
	tr1 = RTLNS(eif_new_type(9, 0x01).id, 9, _OBJSIZ_1_2_0_0_0_0_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {569,0xFF01,716,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 2L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTOSCF(703,F45_703, (Current));
	tr4 = F43_628(Current, tr4);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTOSCF(704,F45_704, (Current));
	tr4 = F43_628(Current, tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F570_2736)(tr3);
	F10_220(RTCW(tr1), tr2, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2013[Dtype(RTCW(Result))-659])(Result, tr1);
	RTOSE (702);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F45_702 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(702,F45_702_body,(Current));
}

/* {ARGUMENT_PARSER}.stdin_switch */

EIF_REFERENCE F45_703 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (703,RTMS_EX_H("i|stdin",7,1358649966));
}

/* {ARGUMENT_PARSER}.stderr_switch */

EIF_REFERENCE F45_704 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (704,RTMS_EX_H("e|stderr",8,2068959602));
}

/* {ARGUMENT_PARSER}.has_stdin_option */
EIF_BOOLEAN F45_705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(703,F45_703, (Current));
	Result = F43_607(Current, tr1);
	RTLE;
	return Result;
}

/* {ARGUMENT_PARSER}.has_stderr_option */
EIF_BOOLEAN F45_706 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(704,F45_704, (Current));
	Result = F43_607(Current, tr1);
	RTLE;
	return Result;
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
