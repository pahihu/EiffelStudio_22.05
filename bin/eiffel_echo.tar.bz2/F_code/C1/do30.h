
#ifndef _C1_do30_
#define _C1_do30_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F42_581(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
