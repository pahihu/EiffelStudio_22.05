/*
 * Code for class ARGUMENT_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar25.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_SOURCE}.application */
static EIF_REFERENCE F37_552_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (552);
#define Result RTOSR(552)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(683, 0x01).id, 683, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(241, 0x01).id, 241, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(2081,F242_2081, (RTCW(tr2)));
	F684_3225(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (552);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F37_552 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(552,F37_552_body,(Current));
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
