/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st16.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F28_417_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (417);
#define Result RTOSR(417)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(805, 0x01).id, 805, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F806_5048(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (417);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F28_417 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(417,F28_417_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F28_418_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (418);
#define Result RTOSR(418)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(805, 0x01).id, 805, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F806_5049(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (418);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F28_418 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(418,F28_418_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F28_419_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (419);
#define Result RTOSR(419)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(805, 0x01).id, 805, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F806_5050(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (419);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F28_419 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(419,F28_419_body,(Current));
}

/* {STD_FILES}.standard_default */
EIF_REFERENCE F28_421 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = RTOSCF(418,F28_418, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {STD_FILES}.set_output_default */
void F28_445 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(418,F28_418, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {STD_FILES}.put_string_32 */
void F28_450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F28_421(Current);
	F557_2680(RTCW(tr1), arg1);
	RTLE;
}

/* {STD_FILES}.new_line */
void F28_471 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F806_5085(RTCV(F28_421(Current)));
	RTLE;
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
