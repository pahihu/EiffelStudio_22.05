
#ifndef _C1_ar26_
#define _C1_ar26_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,556)
static EIF_REFERENCE F38_556_body(EIF_REFERENCE);
extern EIF_REFERENCE F38_556(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,557)
static EIF_REFERENCE F38_557_body(EIF_REFERENCE);
extern EIF_REFERENCE F38_557(EIF_REFERENCE);
extern void EIF_Minit26(void);
extern void F660_3014(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F595_2821(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F242_2079(EIF_REFERENCE);
extern char *(*R2013[])();

#ifdef __cplusplus
}
#endif

#endif
