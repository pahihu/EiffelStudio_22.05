/*
 * Code for class APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap19.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {APPLICATION}.make */
void F31_507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(44, 0x01).id, 44, _OBJSIZ_4_12_0_0_0_0_0_0_);
	F44_686(RTCW(loc1), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,715,0xFF01,0,0xFF01,44,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,791,0xFF01,0xFFF9,0,715,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A19_33, (EIF_POINTER) _A19_33, (EIF_POINTER)(F31_508),tr1, 1, 0);
	}
	F43_630(RTCW(loc1), tr2);
	RTLE;
}

/* {APPLICATION}.start */
void F31_508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tb1 = F45_706(RTCW(arg1));
	if (tb1) {
		loc1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = RTLNS(eif_new_type(811, 0x01).id, 811, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTOSCF(419,F28_419, (RTCV(RTOSCF(24,F1_24, (Current)))));
		F812_5167(RTCW(tr1), tr2);
		F30_504(RTCW(loc1), tr1);
	} else {
		loc1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = RTLNS(eif_new_type(811, 0x01).id, 811, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTOSCF(418,F28_418, (RTCV(RTOSCF(24,F1_24, (Current)))));
		F812_5167(RTCW(tr1), tr2);
		F30_504(RTCW(loc1), tr1);
	}
	tb1 = F45_705(RTCW(arg1));
	if (tb1) {
		tr1 = RTLNS(eif_new_type(810, 0x01).id, 810, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTOSCF(417,F28_417, (RTCV(RTOSCF(24,F1_24, (Current)))));
		F811_5161(RTCW(tr1), tr2);
		F30_506(RTCW(loc1), tr1);
	} else {
		tr1 = RTLNS(eif_new_type(78, 0x01).id, 78, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = F43_589(RTCW(arg1));
		F79_1068(RTCW(tr1), tr2);
		F30_506(RTCW(loc1), tr1);
	}
	RTLE;
}

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
