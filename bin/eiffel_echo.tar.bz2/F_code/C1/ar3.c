/*
 * Code for class ARGUMENT_EXTERNALS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar3.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F3_46
static EIF_INTEGER_32 inline_F3_46 (void)
{
	#ifdef TIOCGSIZE
	struct ttysize win;
    if (ioctl (STDIN_FILENO, TIOCGSIZE, &win))
        return 0;
    else
        return win.ts_cols;
#elif defined TIOCGWINSZ
	struct winsize win;
    if (ioctl (STDIN_FILENO, TIOCGWINSZ, &win))
        return 0;
    else
        return win.ws_col;
#else
    {
		// Not likely to work because COLUMNS generally is a shell variable.
        const char *s;
        s = getenv ("COLUMNS");
        if (s)
            return strtol (s, 0, 10);
        else
            return 0;
    }
#endif
	;
}
#define INLINE_F3_46
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_EXTERNALS}.c_get_term_columns */
EIF_INTEGER_32 F3_46 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F3_46 ();
	return Result;
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
