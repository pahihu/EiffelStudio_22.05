
#ifndef _C1_ar10_
#define _C1_ar10_

#ifdef __cplusplus
extern "C" {
#endif

extern void F10_220(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F10_221(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit10(void);
extern void F672_3082(EIF_REFERENCE, EIF_REFERENCE);
extern void F660_3014(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R1886[])();
extern char *(*R1871[])();
extern char *(*R1872[])();
extern char *(*R1873[])();

#ifdef __cplusplus
}
#endif

#endif
