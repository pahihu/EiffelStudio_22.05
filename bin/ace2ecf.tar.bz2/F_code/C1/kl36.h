
#ifndef _C1_kl36_
#define _C1_kl36_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,413)
static EIF_REFERENCE F36_413_body(EIF_REFERENCE);
extern EIF_REFERENCE F36_413(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,415)
static EIF_REFERENCE F36_415_body(EIF_REFERENCE);
extern EIF_REFERENCE F36_415(EIF_REFERENCE);
extern void EIF_Minit36(void);
extern void F966_7097(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
