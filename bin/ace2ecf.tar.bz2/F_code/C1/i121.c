/*
 * Code for class I18N_STRING_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i121.h"
#include <ctype.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_STRING_FORMATTER}.default_create */
void F21_201 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '$';
}

/* {I18N_STRING_FORMATTER}.formatted_string */
EIF_REFERENCE F21_205 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,loc10);
	RTLIU(8);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(Result));
	loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_);
	loc5 = (EIF_NATURAL_32) tc1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc6)) break;
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, loc1);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) <= loc6) && (EIF_BOOLEAN)(loc3 == loc5))) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
			loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, loc2);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				tb1 = '\01';
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > loc6)) {
					tr1 = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_NATURAL_32 *)tr1 = loc4;
					tb3 = F1198_9616(RTCW(tr1));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (!tb2) {
					tc1 = (EIF_CHARACTER_8) loc4;
					tb2 = EIF_TEST(isdigit(tc1));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) break;
				tc1 = (EIF_CHARACTER_8) loc4;
				tr1 = eif_out__c1_s1(tc1);
				ti4_1 = F1048_7750(RTCW(tr1));
				loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (loc7 * ((EIF_INTEGER_32) 10L)));
				loc2++;
				if ((EIF_BOOLEAN) (loc2 <= loc6)) {
					loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, loc2);
				}
			}
			if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
				tb2 = '\0';
				tb3 = F997_7356(RTCW(arg2), loc7);
				if (tb3) {
					tr1 = F997_7329(RTCW(arg2), loc7);
					loc8 = RTCCL(tr1);
					tb2 = EIF_TEST(loc8);
				}
				if (tb2) {
					loc9 = RTCCL(loc8);
					loc9 = RTRV(eif_new_type(1047, 0x00),loc9);
					if (EIF_TEST(loc9)) {
						F1058_8098(RTCW(Result), loc9);
					} else {
						loc10 = RTCCL(loc8);
						loc10 = RTRV(eif_new_type(1047, 0x00),loc10);
						if (EIF_TEST(loc10)) {
							tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F1056_7992(RTCW(tr1), loc10);
							F1058_8098(RTCW(Result), tr1);
						} else {
							tr1 = RTCCL(loc8);
							tr1 = F21_208(Current, tr1);
							F1058_8098(RTCW(Result), tr1);
						}
					}
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(arg1))-1051])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
					F1058_8098(RTCW(Result), tr1);
				}
				loc1 = (EIF_INTEGER_32) loc2;
			} else {
				F1050_7785(RTCW(Result), loc3);
				loc1++;
			}
		} else {
			F1050_7785(RTCW(Result), loc3);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {I18N_STRING_FORMATTER}.out_from_separate_any */
EIF_REFERENCE F21_208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(arg1))-1])(arg1);
	F1051_7823(RTCW(Result), tr1);
	RTLE;
	return Result;
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
