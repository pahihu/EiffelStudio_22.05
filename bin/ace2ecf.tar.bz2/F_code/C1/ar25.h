
#ifndef _C1_ar25_
#define _C1_ar25_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F25_232(EIF_REFERENCE);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
