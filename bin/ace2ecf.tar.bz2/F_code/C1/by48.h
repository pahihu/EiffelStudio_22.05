
#ifndef _C1_by48_
#define _C1_by48_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F49_750(EIF_REFERENCE);
extern void EIF_Minit48(void);

#ifdef __cplusplus
}
#endif

#endif
