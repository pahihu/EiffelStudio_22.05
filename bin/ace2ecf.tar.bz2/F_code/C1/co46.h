
#ifndef _C1_co46_
#define _C1_co46_

#ifdef __cplusplus
extern "C" {
#endif

extern void F46_496(EIF_REFERENCE);
extern void F46_498(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit46(void);
extern void F893_6362(EIF_REFERENCE, EIF_INTEGER_32);
extern void F893_6402(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
