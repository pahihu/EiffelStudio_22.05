
#ifndef _C1_ut2_
#define _C1_ut2_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2_35(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2(void);
extern EIF_REFERENCE F67_1025(EIF_REFERENCE, EIF_REFERENCE);
extern void F1048_7685(EIF_REFERENCE);
extern char *(*R4738[])();
extern long O4666[];

#ifdef __cplusplus
}
#endif

#endif
