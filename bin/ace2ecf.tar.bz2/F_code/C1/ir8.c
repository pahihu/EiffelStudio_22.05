/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir8.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F8_92 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F8_98(Current);
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F8_98 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_42 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(43, 0x00).id);
	RTLI(21);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,loc13);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc14);
	RTLR(11,loc5);
	RTLR(12,loc15);
	RTLR(13,loc6);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc8);
	RTLR(17,loc9);
	RTLR(18,loc7);
	RTLR(19,loc4);
	RTLR(20,loc18);
	RTLIU(21);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1072, 0).id);
	F1073_8625(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F8_103(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		loc1 = RTLNS(eif_new_type(1280, 0x00).id, 1280, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F1281_11720(RTCW(loc1), loc10);
		F1281_11740(RTCW(loc1));
		tb1 = '\0';
		tb2 = F1281_11724(RTCW(loc1));
		if (tb2) {
			tr1 = F1281_11736(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F1181_9072(RTCW(tr1), tr2);
			tr1 = F1214_10058(loc11, tr1);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(1213, 0x00),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F1181_9072(RTCW(tr1), tr2);
				tr1 = F1214_10058(loc12, tr1);
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(1180, 0x00),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				loc2 = RTLNS(eif_new_type(5, 0x00).id, 5, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F1048_7744(RTCW(tr1));
				loc3 = F6_88(RTCW(loc2), tr1);
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4881[Dtype(RTCW(loc3))-1060])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F1181_9072(RTCW(tr1), tr2);
				tr1 = F1214_10058(loc11, tr1);
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(1180, 0x00),loc14);
				if (EIF_TEST(loc14)) {
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F1048_7744(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F1181_9072(RTCW(tr1), tr2);
				tr1 = F1214_10058(loc11, tr1);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1180, 0x00),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F1048_7744(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F1181_9072(RTCW(tr1), tr2);
				tr1 = F1214_10058(loc11, tr1);
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(1180, 0x00),loc16);
				if (EIF_TEST(loc16)) {
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1062, 0x00),loc17);
					if (EIF_TEST(loc17)) {
						tr1 = RTLNSMART(eif_new_type(1072, 0).id);
						tr2 = F1181_9085(loc16);
						F1073_8627(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							loc8 = RTLNS(eif_new_type(6, 0x00).id, 6, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F1073_8654(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F1073_8657(RTCW(tr1), tr2);
							tb1 = F44_468(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F1073_8654(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F1073_8657(RTCW(tr1), tr2);
							}
							tb1 = F44_468(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								loc9 = F8_101(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F44_468(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								loc4 = F7_89(RTCW(loc8), loc9);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2318[Dtype(RTCW(loc4))-186])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						tr1 = RTLNSMART(eif_new_type(1072, 0).id);
						tr2 = F1181_9085(loc16);
						F1073_8627(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F1181_9072(RTCW(tr1), tr2);
						tr1 = F1214_10058(loc11, tr1);
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(1213, 0x00),loc18);
						if (EIF_TEST(loc18)) {
							tr1 = F8_100(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					tr1 = RTLNSMART(eif_new_type(1072, 0).id);
					F1073_8625(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F8_100 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc1);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLR(20,loc16);
	RTLR(21,loc17);
	RTLR(22,loc18);
	RTLR(23,tr3);
	RTLR(24,loc19);
	RTLR(25,loc20);
	RTLR(26,loc21);
	RTLIU(27);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F1181_9072(RTCW(tr1), tr2);
	tr1 = F1214_10058(RTCW(arg1), tr1);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1180, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1180, 0x00),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(1061, 0x00).id, 1061, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1062_8202(RTCW(Result), tr1, arg2);
		tr1 = F1214_10066(RTCW(arg1));
		tr1 = F1048_7744(RTCW(tr1));
		F1062_8233(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1062_8237(RTCW(Result), tr1);
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1180, 0x00),loc4);
		if (EIF_TEST(loc4)) {
			tr1 = F1181_9085(loc4);
			F1062_8238(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1180, 0x00),loc5);
		if (EIF_TEST(loc5)) {
			tr1 = F1181_9085(loc5);
			F1062_8239(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(1179, 0x00),loc6);
		if (EIF_TEST(loc6)) {
			loc1 = *(EIF_REFERENCE *)(loc6);
			tb1 = F1048_7721(RTCW(loc1));
			if (tb1) {
				tu4_1 = F1048_7755(RTCW(loc1));
				F1062_8240(RTCW(Result), tu4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1180, 0x00),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1062_8242(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(1180, 0x00),loc8);
		if (EIF_TEST(loc8)) {
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1062_8244(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1179, 0x00),loc9);
		if (EIF_TEST(loc9)) {
			loc1 = *(EIF_REFERENCE *)(loc9);
			tb1 = F1048_7716(RTCW(loc1));
			if (tb1) {
				ti4_1 = F1048_7750(RTCW(loc1));
				F1062_8241(RTCW(Result), ti4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1212, 0x00),loc10);
		if (EIF_TEST(loc10)) {
			tr1 = F1213_10035(loc10);
			loc11 = F893_6376(RTCW(tr1));
			for (;;) {
				tb1 = F501_5372(loc11);
				if (tb1) break;
				tr1 = F501_5363(loc11);
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(1180, 0x00),loc12);
				if (EIF_TEST(loc12)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F893_6402(RTCW(tr1), tr2);
				}
				F501_5378(loc11);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(1212, 0x00),loc13);
		if (EIF_TEST(loc13)) {
			tr1 = F1213_10035(loc13);
			loc14 = F893_6376(RTCW(tr1));
			for (;;) {
				tb2 = F501_5372(loc14);
				if (tb2) break;
				tr1 = F501_5363(loc14);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1180, 0x00),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					tr2 = F1181_9085(loc15);
					F893_6402(RTCW(tr1), tr2);
				}
				F501_5378(loc14);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1213, 0x00),loc16);
		if (EIF_TEST(loc16)) {
			loc17 = F1214_10068(loc16);
			for (;;) {
				tb3 = F493_5360(loc17);
				if (tb3) break;
				tr1 = F493_5357(loc17);
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(1180, 0x00),loc18);
				if (EIF_TEST(loc18)) {
					tr1 = F1181_9085(loc18);
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					tr3 = F493_5358(loc17);
					tr3 = F1181_9085(RTCW(tr3));
					tr2 = F1058_8118(tr2, tr3);
					tr3 = F1048_7744(RTMS_EX_H("]",1,93));
					tr2 = F1058_8118(RTCW(tr2), tr3);
					F1062_8236(RTCW(Result), tr1, tr2);
				}
				F493_5361(loc17);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F1181_9072(RTCW(tr1), tr2);
		tr1 = F1214_10058(RTCW(arg1), tr1);
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(1213, 0x00),loc19);
		if (EIF_TEST(loc19)) {
			loc20 = F1214_10068(loc19);
			for (;;) {
				tb4 = F493_5360(loc20);
				if (tb4) break;
				tr1 = F493_5357(loc20);
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(1180, 0x00),loc21);
				if (EIF_TEST(loc21)) {
					tr1 = F1181_9085(loc21);
					tr2 = F493_5358(loc20);
					tr2 = F1181_9085(RTCW(tr2));
					F1062_8236(RTCW(Result), tr1, tr2);
				}
				F493_5361(loc20);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F8_101 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F395_4822(RTCW(loc1), arg1);
	tb1 = F395_4845(RTCW(loc1));
	if (tb1) {
		tr1 = F395_4836(RTCW(loc1));
		tr1 = F893_6376(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F501_5372(loc2);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			tb2 = '\01';
			tr1 = F501_5363(loc2);
			tb3 = F1073_8632(RTCW(tr1));
			if (!tb3) {
				tr1 = F501_5363(loc2);
				tb3 = F1073_8633(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = F501_5363(loc2);
				tr1 = F1073_8644(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F1048_7727(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = F501_5363(loc2);
					Result = F1073_8655(RTCW(arg1), tr1);
				}
			}
			F501_5378(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F8_103 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F772_5647(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F772_5681(RTCW(loc1));
	if (tb2) {
		tb2 = F772_5700(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5071[Dtype(RTCW(loc1))-772])(loc1);
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1051_7815(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			tb1 = F580_5448(RTCW(loc1));
			if (tb1) break;
			F772_5795(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O4666[Dtype(loc1)-410]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(Result))-1052])(Result, tr1);
		}
		F772_5733(RTCW(loc1));
	}
	RTLE;
	return Result;
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
