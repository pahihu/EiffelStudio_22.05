
#ifndef _C1_pu10_
#define _C1_pu10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F10_112(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F10_121(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_BOOLEAN);
extern EIF_CHARACTER_8 F10_122(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_NATURAL_32 F10_123(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_REFERENCE);
extern EIF_NATURAL_32 F10_124(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F10_127(EIF_REFERENCE);
extern void EIF_Minit10(void);
extern void F1051_7815(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6650[])();
extern char *(*R6741[])();
extern char *(*R6590[])();
extern char *(*R6553[])();

#ifdef __cplusplus
}
#endif

#endif
