
#ifndef _C1_i19_
#define _C1_i19_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_104(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_105(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
