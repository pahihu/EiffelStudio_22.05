/*
 * Code for class IRON_CLIENT_DB
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir13.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT_DB}.make */
void F13_130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {IRON_CLIENT_DB}.revision */
EIF_INTEGER_32 F13_132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(4948,F401_4948, (RTCW(tr1)));
	F772_5647(RTCW(loc1), tr1);
	tb1 = '\0';
	tb2 = F772_5681(RTCW(loc1));
	if (tb2) {
		tb2 = F772_5684(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5071[Dtype(RTCW(loc1))-772])(loc1);
		F772_5794(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + O4666[Dtype(loc1)-410]);
		tb1 = F1048_7716(RTCW(loc2));
		if (tb1) {
			Result = F1048_7750(RTCW(loc2));
		} else {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		F772_5733(RTCW(loc1));
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.repositories */
EIF_REFERENCE F13_133 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(183, 0x00).id, 183, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(4947,F401_4947, (RTCW(tr1)));
	F184_2338(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.installed_packages */
EIF_REFERENCE F13_134 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,Result);
	RTLR(12,loc10);
	RTLR(13,tr2);
	RTLR(14,loc11);
	RTLIU(15);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1061,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F893_6362(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	F552_5431(RTCW(loc5));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(4951,F401_4951, (RTCW(tr1)));
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1072,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F893_6362(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	loc2 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F86_1276(RTCW(loc2), loc3);
	tr1 = F1073_8646(RTCW(loc1));
	tr1 = F1073_8648(RTCW(tr1));
	F86_1280(RTCW(loc2), tr1);
	loc6 = F893_6376(RTCW(loc3));
	for (;;) {
		tb1 = F501_5372(loc6);
		if (tb1) break;
		loc4 = RTLNS(eif_new_type(7, 0x00).id, 7, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F501_5363(loc6);
		F8_92(RTCW(loc4), tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			F893_6402(RTCW(loc5), loc7);
		} else {
			tb2 = '\0';
			tr1 = F501_5363(loc6);
			tr1 = F13_141(Current, tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tr1 = F13_142(Current, loc8);
				loc9 = tr1;
				tb2 = EIF_TEST(loc9);
			}
			if (tb2) {
				F893_6402(RTCW(loc5), loc9);
			}
		}
		F501_5378(loc6);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1061,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F893_6383(RTCW(loc5));
	F893_6362(RTCW(Result), ti4_1);
	F552_5431(RTCW(Result));
	loc10 = F893_6376(RTCV(F13_133(Current)));
	for (;;) {
		tb2 = F501_5372(loc10);
		if (tb2) break;
		tb3 = F706_5583(RTCW(loc5));
		if (tb3) break;
		F893_6393(RTCW(loc5));
		for (;;) {
			tb4 = F864_6281(RTCW(loc5));
			if (tb4) break;
			tr1 = F501_5363(loc10);
			tr2 = F893_6367(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4886[Dtype(RTCW(tr1))-1060])(tr1, tr2);
			if (tb5) {
				tr1 = F893_6367(RTCW(loc5));
				F893_6402(RTCW(Result), tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4939[Dtype(RTCW(loc5))-744])(loc5);
			} else {
				F893_6395(RTCW(loc5));
			}
		}
		F501_5378(loc10);
	}
	tb5 = F706_5583(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb5) {
		loc11 = F893_6376(RTCW(loc5));
		for (;;) {
			tb5 = F501_5372(loc11);
			if (tb5) break;
			tr1 = F501_5363(loc11);
			F893_6402(RTCW(Result), tr1);
			F501_5378(loc11);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.quick_installed_package */
EIF_REFERENCE F13_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,arg1);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,tr2);
	RTLR(15,Result);
	RTLIU(16);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1061,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F893_6362(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	F552_5431(RTCW(loc5));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(4951,F401_4951, (RTCW(tr1)));
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1072,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F893_6362(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	loc2 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F86_1276(RTCW(loc2), loc3);
	tr1 = F1073_8646(RTCW(loc1));
	tr1 = F1073_8648(RTCW(tr1));
	F86_1280(RTCW(loc2), tr1);
	loc6 = F893_6376(RTCW(loc3));
	for (;;) {
		tb1 = F501_5372(loc6);
		if (tb1) break;
		tb2 = '\0';
		tr1 = F501_5363(loc6);
		tr1 = F13_141(Current, tr1);
		tr1 = F13_143(Current, tr1);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tb3 = F1048_7727(loc7, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			loc4 = RTLNS(eif_new_type(7, 0x00).id, 7, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = F501_5363(loc6);
			F8_92(RTCW(loc4), tr1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F893_6402(RTCW(loc5), loc8);
			} else {
				tb2 = '\0';
				tr1 = F501_5363(loc6);
				tr1 = F13_141(Current, tr1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tr1 = F13_142(Current, loc9);
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				if (tb2) {
					F893_6402(RTCW(loc5), loc10);
				}
			}
		}
		F501_5378(loc6);
	}
	loc11 = F893_6376(RTCV(F13_133(Current)));
	for (;;) {
		tb2 = F501_5372(loc11);
		if (tb2) break;
		tb3 = '\01';
		tb4 = F706_5583(RTCW(loc5));
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb3) break;
		F893_6393(RTCW(loc5));
		for (;;) {
			tb4 = '\01';
			tb5 = F864_6281(RTCW(loc5));
			if (!tb5) {
				tb4 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb4) break;
			tr1 = F501_5363(loc11);
			tr2 = F893_6367(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4886[Dtype(RTCW(tr1))-1060])(tr1, tr2);
			if (tb5) {
				Result = F893_6367(RTCW(loc5));
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4939[Dtype(RTCW(loc5))-744])(loc5);
			} else {
				F893_6395(RTCW(loc5));
			}
		}
		F501_5378(loc11);
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.file_content */
EIF_REFERENCE F13_141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F772_5647(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F772_5681(RTCW(loc1));
	if (tb2) {
		tb2 = F772_5700(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5071[Dtype(RTCW(loc1))-772])(loc1);
		Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1051_7815(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			tb1 = F580_5448(RTCW(loc1));
			if (tb1) break;
			F772_5795(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O4666[Dtype(loc1)-410]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(Result))-1052])(Result, tr1);
		}
		F772_5733(RTCW(loc1));
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.repo_package_from_json_string */
EIF_REFERENCE F13_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(184, 0x00).id, 184, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F185_2349(RTCW(loc1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.repo_package_identifier_from_json_string */
EIF_REFERENCE F13_143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(184, 0x00).id, 184, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = F185_2351(RTCW(loc1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
