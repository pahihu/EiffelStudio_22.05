
#ifndef _C1_co16_
#define _C1_co16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F16_181(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit16(void);
extern void F403_4971(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
