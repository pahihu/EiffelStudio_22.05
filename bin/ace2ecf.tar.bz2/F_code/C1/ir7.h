
#ifndef _C1_ir7_
#define _C1_ir7_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F7_89(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit7(void);
extern void F188_2395(EIF_REFERENCE, EIF_REFERENCE);
extern void F187_2382(EIF_REFERENCE, EIF_REFERENCE);
extern long O2309[];

#ifdef __cplusplus
}
#endif

#endif
