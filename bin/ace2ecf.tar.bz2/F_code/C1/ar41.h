
#ifndef _C1_ar41_
#define _C1_ar41_

#ifdef __cplusplus
extern "C" {
#endif

extern void F41_444(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F41_447(EIF_REFERENCE);
extern EIF_BOOLEAN F41_449(EIF_REFERENCE);
extern void EIF_Minit41(void);
extern EIF_BOOLEAN F1057_8055(EIF_REFERENCE);
extern void F1048_7685(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
