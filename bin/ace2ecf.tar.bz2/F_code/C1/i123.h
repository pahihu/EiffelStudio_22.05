
#ifndef _C1_i123_
#define _C1_i123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F23_214(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit23(void);
extern void F335_3796(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
