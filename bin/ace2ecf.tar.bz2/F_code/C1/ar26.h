
#ifndef _C1_ar26_
#define _C1_ar26_

#ifdef __cplusplus
extern "C" {
#endif

extern void F26_233(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F26_234(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit26(void);
extern void F893_6362(EIF_REFERENCE, EIF_INTEGER_32);
extern void F905_6430(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4750[])();
extern char *(*R4751[])();
extern char *(*R4752[])();
extern char *(*R4781[])();

#ifdef __cplusplus
}
#endif

#endif
