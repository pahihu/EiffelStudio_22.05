
#ifndef _C1_i118_
#define _C1_i118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F18_186(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit18(void);
extern void F141_1964(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
