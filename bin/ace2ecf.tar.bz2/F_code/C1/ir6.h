
#ifndef _C1_ir6_
#define _C1_ir6_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F6_88(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);
extern void F1300_12306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1063_8249(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1048_7732(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1300_12324(EIF_REFERENCE);
extern void F1061_8190(EIF_REFERENCE, EIF_REFERENCE);
extern void F1063_8247(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
