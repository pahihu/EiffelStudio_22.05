
#ifndef _C1_pc32_
#define _C1_pc32_

#ifdef __cplusplus
extern "C" {
#endif

extern void F32_330(EIF_REFERENCE);
extern void F32_331(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F32_333(EIF_REFERENCE, EIF_INTEGER_32);
extern void F32_334(EIF_REFERENCE, EIF_REFERENCE);
extern void F32_335(EIF_REFERENCE, EIF_INTEGER_32);
extern void F32_336(EIF_REFERENCE, EIF_REFERENCE);
extern void F32_337(EIF_REFERENCE, EIF_REFERENCE);
extern void F32_338(EIF_REFERENCE);
extern void EIF_Minit32(void);
extern void F1111_8722(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R6689[])();
extern long O6713[];

#ifdef __cplusplus
}
#endif

#endif
