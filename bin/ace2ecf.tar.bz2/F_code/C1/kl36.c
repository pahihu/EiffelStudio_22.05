/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F36_413_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (413);
#define Result RTOSR(413)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(965, 0x00).id, 965, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F966_7097(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (413);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_413 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(413,F36_413_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F36_415_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (415);
#define Result RTOSR(415)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(944, 0x00).id, 944, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (415);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_415 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(415,F36_415_body,(Current));
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
