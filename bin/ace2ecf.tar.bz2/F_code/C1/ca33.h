
#ifndef _C1_ca33_
#define _C1_ca33_

#ifdef __cplusplus
extern "C" {
#endif

extern void F33_340(EIF_REFERENCE);
extern void F33_341(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F33_342(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F33_344(EIF_REFERENCE, EIF_INTEGER_32);
extern void F33_345(EIF_REFERENCE);
extern void F33_346(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit33(void);
extern void F1110_8722(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5231[])();
extern long O6713[];

#ifdef __cplusplus
}
#endif

#endif
