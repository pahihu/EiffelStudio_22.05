/*
 * Code for class IRON_PACKAGE_FILE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir7.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_FILE_FACTORY}.new_package_file */
EIF_REFERENCE F7_89 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(187, 0x00).id, 187, _OBJSIZ_5_2_0_0_0_0_0_0_);
	F188_2395(RTCW(loc1), arg1);
	Result = (EIF_REFERENCE) loc1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2309[Dtype(Result)-185]);
	if (tb1) {
		Result = RTLNS(eif_new_type(186, 0x00).id, 186, _OBJSIZ_4_2_0_0_0_0_0_0_);
		F187_2382(RTCW(Result), arg1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2309[Dtype(Result)-185]);
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
