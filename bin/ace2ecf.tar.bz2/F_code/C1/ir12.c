/*
 * Code for class reference IRON_STRING_VARIABLE_EXPANSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir12.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_STRING_VARIABLE_EXPANSER}.expand_string_32 */
void F11_129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,arg2);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) loc1;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		loc1 = F1056_7996(RTCW(arg1), tw1, loc2);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			loc2 = (EIF_INTEGER_32) loc1;
			loc1++;
			tw1 = F1058_8066(RTCW(arg1), loc1);
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
			if ((EIF_BOOLEAN)(tw1 == tw2)) {
				loc1++;
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
				loc3 = F1056_7996(RTCW(arg1), tw1, loc1);
				loc5 = F1058_8146(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			} else {
				tw1 = F1058_8066(RTCW(arg1), loc1);
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
				if ((EIF_BOOLEAN)(tw1 == tw2)) {
					loc1++;
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
					loc3 = F1056_7996(RTCW(arg1), tw1, loc1);
					loc5 = F1058_8146(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				} else {
					tb2 = '\01';
					tw1 = F1058_8066(RTCW(arg1), loc1);
					tr1 = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb3 = F1000_7515(RTCW(tr1));
					if (!tb3) {
						tw1 = F1058_8066(RTCW(arg1), loc1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
						for (;;) {
							tb2 = '\01';
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
							if (!(EIF_BOOLEAN) (loc3 > ti4_1)) {
								tb3 = '\01';
								tw1 = F1058_8066(RTCW(arg1), loc3);
								tr1 = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
								*(EIF_CHARACTER_32 *)tr1 = tw1;
								tb4 = F1000_7523(RTCW(tr1));
								if (!tb4) {
									tw1 = F1058_8066(RTCW(arg1), loc3);
									tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
									tb3 = (EIF_BOOLEAN)(tw1 == tw2);
								}
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							if (tb2) break;
							loc3++;
						}
						loc3--;
						loc5 = F1058_8146(RTCW(arg1), loc1, loc3);
					} else {
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc5 = (EIF_REFERENCE) NULL;
					}
				}
			}
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
				tb3 = '\0';
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,996,1055,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr1 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = loc5;
					RTAR(tr1,loc5);
					tr1 = F1044_7676(RTCW(arg2), tr1);
					loc6 = tr1;
					tb3 = EIF_TEST(loc6);
				}
				if (tb3) {
					F1058_8075(RTCW(arg1), loc6, loc2, loc3);
					loc1 = *(EIF_INTEGER_32 *)(loc6 + O6791[Dtype(loc6)-1055]);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc1);
				} else {
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				}
			}
		}
		loc2 = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
