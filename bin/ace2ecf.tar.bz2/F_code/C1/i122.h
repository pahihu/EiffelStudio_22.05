
#ifndef _C1_i122_
#define _C1_i122_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_209(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F144_1996(EIF_REFERENCE, EIF_REFERENCE);
extern long O1759[];
extern long O1760[];

#ifdef __cplusplus
}
#endif

#endif
