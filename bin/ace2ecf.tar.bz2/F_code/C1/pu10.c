/*
 * Code for class PUNYCODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pu10.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PUNYCODE}.encoded_string */
EIF_REFERENCE F10_112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	F1051_7815(RTCW(Result), ti4_1);
	loc1 = F10_124(Current, arg1, Result);
	RTLE;
	return Result;
}

/* {PUNYCODE}.adapt_bias */
EIF_NATURAL_32 F10_121 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTGC;
	loc2 = (EIF_REAL_64) (arg1);
	if (arg3) {
		tr8_1 = (EIF_REAL_64) (((EIF_NATURAL_32) 700U));
		loc2 /= tr8_1;
	} else {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
		loc2 /= tr8_1;
	}
	tr8_1 = (EIF_REAL_64) (arg2);
	loc2 += (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (tr8_1));
	ti8_1 = (EIF_INTEGER_64) loc2;
	tr8_1 = (EIF_REAL_64) (ti8_1);
	loc2 = (EIF_REAL_64) tr8_1;
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 455L));
		if ((EIF_BOOLEAN) eif_is_less_equal_real_64 (loc2, tr8_1)) break;
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 35L));
		loc2 /= tr8_2;
		ti8_1 = (EIF_INTEGER_64) loc2;
		tr8_2 = (EIF_REAL_64) (ti8_1);
		loc2 = (EIF_REAL_64) tr8_2;
		loc1 += ((EIF_NATURAL_32) 36U);
	}
	tr8_2 = (EIF_REAL_64) (((EIF_NATURAL_32) ((EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - ((EIF_NATURAL_32) 1U)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))));
	tr8_3 = (EIF_REAL_64) (((EIF_NATURAL_32) 38U));
	ti8_1 = (EIF_INTEGER_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (tr8_2 * loc2)) /  (EIF_REAL_64) ((EIF_REAL_64) (loc2 + tr8_3)));
	Result = (EIF_NATURAL_32) ti8_1;
	Result = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc1 + Result);
	return Result;
}

/* {PUNYCODE}.encoded_digit */
EIF_CHARACTER_8 F10_122 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 25L))) {
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 22L));
	} else {
		loc1 = (EIF_NATURAL_32) (EIF_CHARACTER_8) 'a';
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 + loc1);
	}
	tc1 = (EIF_CHARACTER_8) loc1;
	return (EIF_CHARACTER_8) tc1;
}

/* {PUNYCODE}.encode_var_int */
EIF_NATURAL_32 F10_123 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_NATURAL_32) arg2;
	loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 36U);
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if (loc5) break;
		if ((EIF_BOOLEAN) (loc2 <= arg1)) {
			loc4 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 1U);
		} else {
			if ((EIF_BOOLEAN) (loc2 >= (EIF_NATURAL_32) (arg1 + ((EIF_NATURAL_32) 26U)))) {
				loc4 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 26U);
			} else {
				loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc2 - arg1);
			}
		}
		if ((EIF_BOOLEAN) (loc3 < loc4)) {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tc1 = F10_122(Current, (EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc3 - loc4) % (EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - loc4))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(arg3))-1052])(arg3, tc1);
			loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			ti8_1 = (EIF_INTEGER_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_NATURAL_32) (loc3 - loc4)) /  (EIF_REAL_64) ((EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - loc4)));
			tu4_1 = (EIF_NATURAL_32) ti8_1;
			loc3 = (EIF_NATURAL_32) tu4_1;
			loc2 += ((EIF_NATURAL_32) 36U);
		}
	}
	tc1 = F10_122(Current, loc3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(arg3))-1052])(arg3, tc1);
	loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTLE;
	return (EIF_NATURAL_32) loc1;
}

/* {PUNYCODE}.punycode_encode */
EIF_NATURAL_32 F10_124 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc9 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc10 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	loc1 = (EIF_NATURAL_32) ti4_1;
	loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	loc9 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1)) break;
		ti4_1 = (EIF_INTEGER_32) loc8;
		loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		if ((EIF_BOOLEAN) (loc10 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6650[Dtype(RTCW(arg2))-1052])(arg2, loc10);
			loc9 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	loc3 = (EIF_NATURAL_32) loc9;
	loc2 = (EIF_NATURAL_32) loc3;
	if ((EIF_BOOLEAN) (loc9 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(arg2))-1052])(arg2, (EIF_CHARACTER_8) '-');
		loc9 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	loc7 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 128U);
	loc5 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 72U);
	loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1) || loc11)) break;
		loc6 = F10_127(Current);
		loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1)) break;
			ti4_1 = (EIF_INTEGER_32) loc8;
			loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc10 >= loc7) && (EIF_BOOLEAN) (loc10 < loc6))) {
				loc6 = (EIF_NATURAL_32) loc10;
			}
			loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		tr8_1 = (EIF_REAL_64) ((EIF_NATURAL_32) (loc6 - loc7));
		if ((EIF_BOOLEAN) eif_is_greater_real_64 (tr8_1, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_NATURAL_32) (F10_127(Current) - loc4)) /  (EIF_REAL_64) ((EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)))))) {
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc4 += (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 - loc7) * (EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)));
			loc7 = (EIF_NATURAL_32) loc6;
			loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1) || loc11)) break;
				ti4_1 = (EIF_INTEGER_32) loc8;
				loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(arg1))-1051])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN) (loc10 < loc7)) {
					loc4 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					if ((EIF_BOOLEAN)(loc4 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
						loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				} else {
					if ((EIF_BOOLEAN)(loc10 == loc7)) {
						loc9 += F10_123(Current, loc5, loc4, arg2);
						loc5 = F10_121(Current, loc4, (EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), (EIF_BOOLEAN)(loc3 == loc2));
						loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
						loc3 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					}
				}
				if ((EIF_BOOLEAN) !loc11) {
					loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
		if ((EIF_BOOLEAN) !loc11) {
			loc7 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			loc4 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
	}
	if (loc11) {
	}
	RTLE;
	return (EIF_NATURAL_32) loc8;
}

/* {PUNYCODE}.size_max */
EIF_NATURAL_32 F10_127 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_32) ((EIF_NATURAL_32) 4294967295U);
}

void EIF_Minit10 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
