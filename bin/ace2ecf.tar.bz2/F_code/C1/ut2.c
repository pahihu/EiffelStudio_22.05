/*
 * Code for class UTF8_READER_WRITER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut2.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UTF8_READER_WRITER}.file_read_string_32_with_length */
EIF_REFERENCE F2_35 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1048_7685(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4738[Dtype(RTCW(arg1))-772])(arg1, arg2);
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O4666[Dtype(arg1)-410]);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTLNS(eif_new_type(66, 0x00).id, 66, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F67_1025(RTCW(tr1), loc1);
		} else {
			Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1048_7685(RTCW(Result));
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit2 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
