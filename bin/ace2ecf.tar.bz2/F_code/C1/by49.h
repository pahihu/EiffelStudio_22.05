
#ifndef _C1_by49_
#define _C1_by49_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F48_750(EIF_REFERENCE);
extern void EIF_Minit49(void);

#ifdef __cplusplus
}
#endif

#endif
