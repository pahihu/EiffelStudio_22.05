
#ifndef _C17_ar846_
#define _C17_ar846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F530_5401(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F530_5402(EIF_REFERENCE);
extern EIF_REFERENCE F530_5403(EIF_REFERENCE);
extern EIF_REFERENCE F530_5405(EIF_REFERENCE);
extern EIF_INTEGER_32 F530_5406(EIF_REFERENCE);
extern void EIF_Minit846(void);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
