
#ifndef _C17_co813_
#define _C17_co813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F556_5431(EIF_REFERENCE);
extern EIF_INTEGER_32 F556_5434(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit813(void);
extern char *(*R4997[])();
extern char *(*R5232[])();
extern char *(*R5233[])();
extern long O4893[];
extern EIF_TYPE_INDEX Y4782[];
extern EIF_TYPE_INDEX *Y4782_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
