/*
 * Code for class LINEAR [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li827.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F581_5442 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F896_6393(Current);
	if ((EIF_BOOLEAN) !F843_6257(Current)) {
		F896_6399(Current, arg1);
	}
	Result = F581_5448(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F581_5444 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O4893[Dtype(Current)-551])) {
		for (;;) {
			tb1 = '\01';
			if (!F581_5448(Current)) {
				tb1 = (arg1 == F896_6367(Current));
			}
			if (tb1) break;
			F896_6395(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F581_5448(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F896_6367(Current));
			}
			if (tb2) break;
			F896_6395(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F581_5448 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F843_6257(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F581_5450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F711_5583(Current)) {
		Result = F867_6281(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F581_5457 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit827 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
