
#ifndef _C17_co819_
#define _C17_co819_

#ifdef __cplusplus
extern "C" {
#endif

extern void F604_5467(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R4900[])();
extern char *(*R4901[])();
extern char *(*R4914[])();
extern char *(*R4917[])();
extern char *(*R4921[])();
extern char *(*R4897[])();
extern char *(*R4899[])();

#ifdef __cplusplus
}
#endif

#endif
