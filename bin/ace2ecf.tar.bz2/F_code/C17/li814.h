
#ifndef _C17_li814_
#define _C17_li814_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F580_5442(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F580_5444(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_BOOLEAN F580_5448(EIF_REFERENCE);
extern EIF_BOOLEAN F580_5450(EIF_REFERENCE);
extern EIF_REFERENCE F580_5457(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern char *(*R4900[])();
extern char *(*R4901[])();
extern char *(*R4907[])();
extern char *(*R4912[])();
extern char *(*R4914[])();
extern char *(*R4891[])();
extern char *(*R4899[])();
extern long O4893[];

#ifdef __cplusplus
}
#endif

#endif
