
#ifndef _C17_co829_
#define _C17_co829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F557_5431(EIF_REFERENCE);
extern EIF_INTEGER_32 F557_5434(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit829(void);
extern char *(*R4997[])();
extern char *(*R5232[])();
extern char *(*R5233[])();
extern long O4893[];
extern EIF_TYPE_INDEX Y4782[];
extern EIF_TYPE_INDEX *Y4782_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
