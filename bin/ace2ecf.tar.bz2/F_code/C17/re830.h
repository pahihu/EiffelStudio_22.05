
#ifndef _C17_re830_
#define _C17_re830_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F789_6007(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern void F484_5329(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4846[])();
extern EIF_TYPE_INDEX Y4782[];
extern EIF_TYPE_INDEX *Y4782_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
