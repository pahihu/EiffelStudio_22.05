
#ifndef _C17_fi834_
#define _C17_fi834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F711_5583(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern char *(*R4997[])();

#ifdef __cplusplus
}
#endif

#endif
