
#ifndef _C17_ty811_
#define _C17_ty811_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F471_5323(EIF_REFERENCE);
extern void EIF_Minit811(void);
extern char *(*R4834[])();
extern char *(*R4847[])();
extern char *(*R5231[])();

#ifdef __cplusplus
}
#endif

#endif
