
#ifndef _C17_to847_
#define _C17_to847_

#ifdef __cplusplus
extern "C" {
#endif

extern void F382_4730(EIF_REFERENCE, EIF_INTEGER_32);
extern void F382_4731(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F382_4737(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit847(void);
extern void F1112_8722(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4324[];
extern EIF_TYPE_INDEX *Y4324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
