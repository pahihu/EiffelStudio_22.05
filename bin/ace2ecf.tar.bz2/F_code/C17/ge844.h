
#ifndef _C17_ge844_
#define _C17_ge844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F504_5363(EIF_REFERENCE);
extern EIF_INTEGER_32 F504_5365(EIF_REFERENCE);
extern EIF_BOOLEAN F504_5372(EIF_REFERENCE);
extern EIF_BOOLEAN F504_5375(EIF_REFERENCE);
extern EIF_BOOLEAN F504_5376(EIF_REFERENCE);
extern void F504_5377(EIF_REFERENCE);
extern void F504_5378(EIF_REFERENCE);
extern EIF_REFERENCE F504_5379(EIF_REFERENCE);
extern void EIF_Minit844(void);
extern char *(*R4835[])();
extern char *(*R4862[])();
extern long O4861[];
extern long O4863[];

#ifdef __cplusplus
}
#endif

#endif
