
#ifndef _C17_fi820_
#define _C17_fi820_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F710_5583(EIF_REFERENCE);
extern void EIF_Minit820(void);
extern char *(*R4997[])();

#ifdef __cplusplus
}
#endif

#endif
