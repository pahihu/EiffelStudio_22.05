
#ifndef _C17_sp843_
#define _C17_sp843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F542_5407(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F542_5408(EIF_REFERENCE);
extern EIF_REFERENCE F542_5409(EIF_REFERENCE);
extern EIF_INTEGER_32 F542_5410(EIF_REFERENCE);
extern void EIF_Minit843(void);
extern EIF_INTEGER_32 F1112_8733(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
