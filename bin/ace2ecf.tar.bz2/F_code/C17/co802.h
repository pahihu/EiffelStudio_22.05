
#ifndef _C17_co802_
#define _C17_co802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F603_5467(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit802(void);
extern EIF_BOOLEAN F847_6257(EIF_REFERENCE);
extern void F900_6393(EIF_REFERENCE);
extern void F900_6395(EIF_REFERENCE);
extern EIF_CHARACTER_32 F900_6367(EIF_REFERENCE);
extern char *(*R4917[])();
extern char *(*R4921[])();
extern char *(*R4897[])();

#ifdef __cplusplus
}
#endif

#endif
