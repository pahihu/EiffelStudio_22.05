
#ifndef _C17_ty832_
#define _C17_ty832_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F472_5323(EIF_REFERENCE);
extern void EIF_Minit832(void);
extern char *(*R4834[])();
extern char *(*R4847[])();
extern char *(*R5231[])();

#ifdef __cplusplus
}
#endif

#endif
