
#ifndef _C17_co839_
#define _C17_co839_

#ifdef __cplusplus
extern "C" {
#endif

extern void F605_5467(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit839(void);
extern EIF_POINTER F896_6367(EIF_REFERENCE);
extern EIF_BOOLEAN F843_6257(EIF_REFERENCE);
extern void F896_6395(EIF_REFERENCE);
extern void F896_6393(EIF_REFERENCE);
extern char *(*R4917[])();
extern char *(*R4921[])();
extern char *(*R4897[])();

#ifdef __cplusplus
}
#endif

#endif
