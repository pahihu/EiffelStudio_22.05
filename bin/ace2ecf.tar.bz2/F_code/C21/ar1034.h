
#ifndef _C21_ar1034_
#define _C21_ar1034_

#ifdef __cplusplus
extern "C" {
#endif

extern void F520_5383(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F520_5384(EIF_REFERENCE);
extern EIF_REFERENCE F520_5385(EIF_REFERENCE);
extern EIF_REFERENCE F520_5387(EIF_REFERENCE);
extern EIF_INTEGER_32 F520_5388(EIF_REFERENCE);
extern void EIF_Minit1034(void);
extern EIF_INTEGER_32 F900_6385(EIF_REFERENCE);
extern EIF_REFERENCE F900_6366(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
