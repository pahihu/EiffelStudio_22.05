
#ifndef _C21_ar1022_
#define _C21_ar1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F534_5401(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F534_5402(EIF_REFERENCE);
extern EIF_REFERENCE F534_5403(EIF_REFERENCE);
extern EIF_REFERENCE F534_5405(EIF_REFERENCE);
extern EIF_INTEGER_32 F534_5406(EIF_REFERENCE);
extern void EIF_Minit1022(void);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
