
#ifndef _C21_ar1006_
#define _C21_ar1006_

#ifdef __cplusplus
extern "C" {
#endif

extern void F533_5401(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F533_5402(EIF_REFERENCE);
extern EIF_REFERENCE F533_5403(EIF_REFERENCE);
extern EIF_REFERENCE F533_5405(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_5406(EIF_REFERENCE);
extern void EIF_Minit1006(void);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
