
#ifndef _C21_to1023_
#define _C21_to1023_

#ifdef __cplusplus
extern "C" {
#endif

extern void F386_4730(EIF_REFERENCE, EIF_INTEGER_32);
extern void F386_4731(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F386_4737(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1023(void);
extern void F1116_8722(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4324[];
extern EIF_TYPE_INDEX *Y4324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
