
#ifndef _C21_se1036_
#define _C21_se1036_

#ifdef __cplusplus
extern "C" {
#endif

extern void F427_5222(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_CHARACTER_32 F427_5223(EIF_REFERENCE);
extern EIF_BOOLEAN F427_5224(EIF_REFERENCE);
extern void F427_5225(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern EIF_INTEGER_32 F1228_10272(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
