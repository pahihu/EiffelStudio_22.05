
#ifndef _C21_re1024_
#define _C21_re1024_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F737_5589(EIF_REFERENCE);
extern void F737_5591(EIF_REFERENCE);
extern void EIF_Minit1024(void);
extern char *(*R4998[])();
extern char *(*R5004[])();

#ifdef __cplusplus
}
#endif

#endif
