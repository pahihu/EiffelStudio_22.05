
#ifndef _C21_dy1029_
#define _C21_dy1029_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F859_6266(EIF_REFERENCE);
extern void EIF_Minit1029(void);

#ifdef __cplusplus
}
#endif

#endif
