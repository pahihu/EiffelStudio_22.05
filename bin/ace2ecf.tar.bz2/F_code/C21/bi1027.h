
#ifndef _C21_bi1027_
#define _C21_bi1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F595_5461(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1027(void);
extern void F900_6395(EIF_REFERENCE);
extern void F579_5444(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_BOOLEAN F709_5583(EIF_REFERENCE);
extern EIF_BOOLEAN F871_6282(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
