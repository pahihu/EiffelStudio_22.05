
#ifndef _C21_ha1041_
#define _C21_ha1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F497_5357(EIF_REFERENCE);
extern EIF_REFERENCE F497_5358(EIF_REFERENCE);
extern EIF_BOOLEAN F497_5360(EIF_REFERENCE);
extern void F497_5361(EIF_REFERENCE);
extern EIF_REFERENCE F497_5362(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern EIF_INTEGER_32 F800_6056(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F486_5343(EIF_REFERENCE);
extern EIF_INTEGER_32 F800_6057(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R7347[])();
extern char *(*R5231[])();

#ifdef __cplusplus
}
#endif

#endif
