
#ifndef _C21_se1026_
#define _C21_se1026_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F755_5638(EIF_REFERENCE);
extern void F755_5640(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1026(void);
extern EIF_BOOLEAN F847_6257(EIF_REFERENCE);
extern void F900_6403(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
