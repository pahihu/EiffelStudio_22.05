/*
 * Code for class SEARCH_TABLE [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se1015.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEARCH_TABLE}.make */
void F1228_10223 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1228_10225(Current, arg1, NULL);
}

/* {SEARCH_TABLE}.make_map */
void F1228_10224 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1228_10225(Current, arg1, NULL);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {SEARCH_TABLE}.make_with_key_tester */
void F1228_10225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tr1 = RTLNS(eif_new_type(704, 0x00).id, 704, _OBJSIZ_0_1_0_1_0_0_0_0_);
	ti4_1 = F705_5573(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * arg1) / ((EIF_INTEGER_32) 2L)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) < ((EIF_INTEGER_32) 5L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {1115,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4782,Y4782_gen_type,dftype,439);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNSP2(typres0.id,0,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_),sizeof(EIF_CHARACTER_32), EIF_TRUE);
	}
	F1116_8722(RTCW(tr1), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {1110,1007,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_),sizeof(EIF_BOOLEAN), EIF_TRUE);
	}
	F1111_8722(RTCW(tr1), (EIF_BOOLEAN) 0, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_CHARACTER_32) loc1;
	RTLE;
}

/* {SEARCH_TABLE}.item */
EIF_CHARACTER_32 F1228_10226 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1228_10253(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_)));
		/* END INLINED CODE */
		Result = tw2;
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.has */
EIF_BOOLEAN F1228_10227 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) > ((EIF_INTEGER_32) 0L))) {
		F1228_10253(Current, arg1);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) == ((EIF_INTEGER_32) 2L));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {SEARCH_TABLE}.is_empty */
EIF_BOOLEAN F1228_10229 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) == ((EIF_INTEGER_32) 0L));
}

/* {SEARCH_TABLE}.found_item */
EIF_CHARACTER_32 F1228_10232 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_);
}


/* {SEARCH_TABLE}.new_cursor */
EIF_REFERENCE F1228_10235 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {426,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4782,Y4782_gen_type,Dftype(Current),439);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 426, _OBJSIZ_1_0_0_1_0_0_0_0_);
	}
	F427_5222(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.is_equal */
EIF_BOOLEAN F1228_10236 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_1_);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) == ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb1 = RTEQ(*(EIF_REFERENCE *)(Current), tr1);
		}
		if (tb1) {
			loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= loc2) || (EIF_BOOLEAN) !Result)) break;
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc4) + (loc1));
				/* END INLINED CODE */
				loc3 = tw2;
				tb1 = '\0';
				if (EIF_TRUE) {
					tb1 = F1228_10257(Current, loc3);
				}
				if (tb1) {
					Result = F1228_10227(RTCW(arg1), loc3);
				}
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.same_keys */
EIF_BOOLEAN F1228_10238 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_CHARACTER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (RTNA((loc1, arg1, arg2)), ((EIF_BOOLEAN) 0));
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) (arg1 == arg2);
	}/* NOTREACHED */
	
}

/* {SEARCH_TABLE}.put */
void F1228_10239 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1228_10253(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) == ((EIF_INTEGER_32) 2L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	} else {
		if (F1228_10256(Current)) {
			F1228_10254(Current);
			F1228_10253(Current, arg1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_CHARACTER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_))) = arg1;
		/* END INLINED CODE */
		;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))++;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {SEARCH_TABLE}.force */
void F1228_10240 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1228_10253(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) != ((EIF_INTEGER_32) 2L))) {
		if (F1228_10256(Current)) {
			F1228_10254(Current);
			F1228_10253(Current, arg1);
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_CHARACTER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_))) = arg1;
	/* END INLINED CODE */
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {SEARCH_TABLE}.remove */
void F1228_10242 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1228_10253(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1116_8744(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_BOOLEAN *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_))) = (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
		;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))--;
	}
	RTLE;
}

/* {SEARCH_TABLE}.merge */
void F1228_10246 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc7 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc6 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc1);
		loc5 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc2);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc6) * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_)))) {
			loc3 = F1228_10250(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) + loc6)) / ((EIF_INTEGER_32) 2L)));
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 >= loc5)) break;
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc4));
				/* END INLINED CODE */
				loc7 = tw2;
				tb1 = '\0';
				if (EIF_TRUE) {
					tb1 = F1228_10257(Current, loc7);
				}
				if (tb1) {
					F1228_10239(RTCW(loc3), loc7);
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_4_);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ti4_1;
		}
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 >= loc6)) break;
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc1) + (loc4));
			/* END INLINED CODE */
			loc7 = tw2;
			tb1 = '\0';
			if (EIF_TRUE) {
				tb1 = F1228_10257(Current, loc7);
			}
			if (tb1) {
				F1228_10239(Current, loc7);
			}
			loc4++;
		}
	}
	RTLE;
}

/* {SEARCH_TABLE}.resize */
void F1228_10247 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * arg1))) {
		loc3 = F1228_10250(Current, arg1);
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
			tb1 = '\0';
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc4) + (loc1));
			/* END INLINED CODE */
			tw1 = tw2;
			loc5 = tw1;
			if ((EIF_TRUE)) {
				tb1 = F1228_10257(Current, loc5);
			}
			if (tb1) {
				F1228_10239(RTCW(loc3), loc5);
			}
			loc1++;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_4_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {SEARCH_TABLE}.copy */
void F1228_10249 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {SEARCH_TABLE}.empty_duplicate */
EIF_REFERENCE F1228_10250 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(Dftype(Current));
	F1228_10225(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.linear_representation */
EIF_REFERENCE F1228_10251 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {899,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4782,Y4782_gen_type,dftype,439);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		Result = RTLNS(typres0.id, 899, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F900_6362(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_));
	loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tb1 = '\0';
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc3) + (loc1));
		/* END INLINED CODE */
		tw1 = tw2;
		loc4 = tw1;
		if ((EIF_TRUE)) {
			tb1 = F1228_10257(Current, loc4);
		}
		if (tb1) {
			F900_6403(RTCW(Result), loc4);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.internal_search */
void F1228_10253 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc7 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc8 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLIU(3);
	
	RTGC;
	loc10 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc11 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_);
	loc2 = (EIF_INTEGER_32) (arg1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L))));
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc3) - loc1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc9 || (EIF_BOOLEAN) (loc6 >= loc3))) break;
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc1) % loc3);
		loc6++;
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc10) + (loc4));
		/* END INLINED CODE */
		loc7 = tw2;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == loc8) || EIF_FALSE)) {
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
			/* END INLINED CODE */
			tb1 = tb2;
			if ((EIF_BOOLEAN) !tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_INTEGER_32) loc5;
				}
			} else {
				if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) {
					loc5 = (EIF_INTEGER_32) loc4;
				}
			}
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
				if ((EIF_BOOLEAN)(arg1 == loc7)) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				if (F1228_10238(Current, arg1, loc7)) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	if ((EIF_BOOLEAN) !loc9) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
		if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
			loc4 = (EIF_INTEGER_32) loc5;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) loc4;
	RTLE;
}

/* {SEARCH_TABLE}.add_space */
void F1228_10254 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1228_10247(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_)) / ((EIF_INTEGER_32) 2L)));
}

/* {SEARCH_TABLE}.soon_full */
EIF_BOOLEAN F1228_10256 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * ti4_2));
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.valid_key */
EIF_BOOLEAN F1228_10257 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != loc1);
}

/* {SEARCH_TABLE}.start */
void F1228_10270 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F1228_10271(Current);
	RTLE;
}

/* {SEARCH_TABLE}.forth */
void F1228_10271 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1228_10272(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {SEARCH_TABLE}.next_iteration_position */
EIF_INTEGER_32 F1228_10272 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (EIF_INTEGER_32) arg1;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if (loc1) break;
		Result++;
		loc1 = '\01';
		if (!(EIF_BOOLEAN) (Result > loc3)) {
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (Result));
			/* END INLINED CODE */
			tw1 = tw2;
			loc1 = F1228_10257(Current, tw1);
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.after */
EIF_BOOLEAN F1228_10273 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_) > (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) - ((EIF_INTEGER_32) 1L)));
}

/* {SEARCH_TABLE}.item_for_iteration */
EIF_CHARACTER_32 F1228_10275 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	RTCT0("attached content.item (iteration_position) as l_item", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.item) */
	tw2 = *((EIF_CHARACTER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_5_)));
	/* END INLINED CODE */
	tw1 = tw2;
	loc1 = tw1;
	if ((EIF_TRUE)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_CHARACTER_32) loc1;
	RTLE;
	return Result;
}

void EIF_Minit1015 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
