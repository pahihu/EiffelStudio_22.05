
#ifndef _C21_ar1005_
#define _C21_ar1005_

#ifdef __cplusplus
extern "C" {
#endif

extern void F519_5383(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F519_5384(EIF_REFERENCE);
extern EIF_REFERENCE F519_5385(EIF_REFERENCE);
extern EIF_REFERENCE F519_5387(EIF_REFERENCE);
extern EIF_INTEGER_32 F519_5388(EIF_REFERENCE);
extern void EIF_Minit1005(void);
extern EIF_INTEGER_32 F899_6385(EIF_REFERENCE);
extern EIF_REFERENCE F899_6366(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
