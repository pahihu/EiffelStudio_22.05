
#ifndef _C21_ha1049_
#define _C21_ha1049_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F498_5357(EIF_REFERENCE);
extern EIF_REFERENCE F498_5358(EIF_REFERENCE);
extern EIF_BOOLEAN F498_5360(EIF_REFERENCE);
extern void F498_5361(EIF_REFERENCE);
extern EIF_REFERENCE F498_5362(EIF_REFERENCE);
extern void EIF_Minit1049(void);
extern EIF_INTEGER_32 F801_6056(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F481_5343(EIF_REFERENCE);
extern EIF_INTEGER_32 F801_6057(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R7347[])();
extern char *(*R5231[])();

#ifdef __cplusplus
}
#endif

#endif
