
#ifndef _C21_sp1019_
#define _C21_sp1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F546_5407(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F546_5408(EIF_REFERENCE);
extern EIF_REFERENCE F546_5409(EIF_REFERENCE);
extern EIF_INTEGER_32 F546_5410(EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern EIF_INTEGER_32 F1116_8733(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
