
#ifndef _C21_re1003_
#define _C21_re1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F736_5589(EIF_REFERENCE);
extern void F736_5591(EIF_REFERENCE);
extern void EIF_Minit1003(void);
extern char *(*R4998[])();
extern char *(*R5004[])();

#ifdef __cplusplus
}
#endif

#endif
