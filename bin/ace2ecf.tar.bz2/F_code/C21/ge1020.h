
#ifndef _C21_ge1020_
#define _C21_ge1020_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F508_5363(EIF_REFERENCE);
extern EIF_INTEGER_32 F508_5365(EIF_REFERENCE);
extern EIF_BOOLEAN F508_5372(EIF_REFERENCE);
extern EIF_BOOLEAN F508_5375(EIF_REFERENCE);
extern EIF_BOOLEAN F508_5376(EIF_REFERENCE);
extern void F508_5377(EIF_REFERENCE);
extern void F508_5378(EIF_REFERENCE);
extern EIF_REFERENCE F508_5379(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern char *(*R4835[])();
extern char *(*R4862[])();
extern long O4861[];
extern long O4863[];

#ifdef __cplusplus
}
#endif

#endif
