
#ifndef _C3_kl108_
#define _C3_kl108_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1912)
static EIF_REFERENCE F133_1912_body(EIF_REFERENCE);
extern EIF_REFERENCE F133_1912(EIF_REFERENCE);
extern void EIF_Minit108(void);
extern void F965_7082(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
