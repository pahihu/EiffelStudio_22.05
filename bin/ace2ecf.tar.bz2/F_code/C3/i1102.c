/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1102.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F126_1830 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1838,F126_1838, (Current));
	F126_1845(Current, tr1);
	F126_1846(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1840,F126_1840, (Current));
	F126_1847(Current, tr1);
	tr1 = RTOSCF(1841,F126_1841, (Current));
	F126_1848(Current, tr1);
	tr1 = RTOSCF(1844,F126_1844, (Current));
	F126_1851(Current, tr1);
	tr1 = RTOSCF(1842,F126_1842, (Current));
	F126_1849(Current, tr1);
	tr1 = RTOSCF(1843,F126_1843, (Current));
	F126_1850(Current, tr1);
	RTLE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F126_1838_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1838);
#define Result RTOSR(1838)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1838);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1838 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1838,F126_1838_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F126_1840_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1840);
#define Result RTOSR(1840)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1840);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1840 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1840,F126_1840_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F126_1841_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1841);
#define Result RTOSR(1841)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1841);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1841 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1841,F126_1841_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F126_1842_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1842);
#define Result RTOSR(1842)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1842);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1842 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1842,F126_1842_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F126_1843_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1843);
#define Result RTOSR(1843)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1843);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1843 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1843,F126_1843_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F126_1844_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1844);
#define Result RTOSR(1844)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1109,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1110_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1844);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_1844 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1844,F126_1844_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F126_1845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F126_1846 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_4_) = (EIF_INTEGER_32) arg1;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F126_1847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F126_1848 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F126_1849 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F126_1850 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F126_1851 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit102 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
