
#ifndef _C3_do134_
#define _C3_do134_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F159_2107(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F159_2109(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
