/*
 * Code for class SHARED_CHARACTER_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh127.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_CHARACTER_SETS}.default_character_case_mapping */
static EIF_REFERENCE F152_2028_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2028);
#define Result RTOSR(2028)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(32, 0x00).id, 32, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	tr3 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F33_341(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2028);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2028 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2028,F152_2028_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.default_word_set */
static EIF_REFERENCE F152_2029_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2029);
#define Result RTOSR(2029)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_",63,1064094303);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2029);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2029 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2029,F152_2029_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.upper_set */
static EIF_REFERENCE F152_2030_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2030);
#define Result RTOSR(2030)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2030);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2030 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2030,F152_2030_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.lower_set */
static EIF_REFERENCE F152_2031_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2031);
#define Result RTOSR(2031)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2031);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2031 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2031,F152_2031_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alpha_set */
static EIF_REFERENCE F152_2032_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2032);
#define Result RTOSR(2032)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F32_330(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(2031,F152_2031, (Current));
	F32_336(RTCW(Result), tr1);
	tr1 = RTOSCF(2030,F152_2030, (Current));
	F32_336(RTCW(Result), tr1);
	RTOSE (2032);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2032 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2032,F152_2032_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.digit_set */
static EIF_REFERENCE F152_2033_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2033);
#define Result RTOSR(2033)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789",10,593348409);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2033);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2033 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2033,F152_2033_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alnum_set */
static EIF_REFERENCE F152_2034_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2034);
#define Result RTOSR(2034)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F32_330(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(2032,F152_2032, (Current));
	F32_336(RTCW(Result), tr1);
	tr1 = RTOSCF(2033,F152_2033, (Current));
	F32_336(RTCW(Result), tr1);
	RTOSE (2034);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2034 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2034,F152_2034_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.xdigit_set */
static EIF_REFERENCE F152_2035_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2035);
#define Result RTOSR(2035)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefABCDEF",22,1983803462);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2035);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2035 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2035,F152_2035_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.cntrl_set */
static EIF_REFERENCE F152_2036_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2036);
#define Result RTOSR(2036)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F32_330(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 31L))) break;
		F32_335(RTCW(Result), loc1);
		loc1++;
	}
	F32_335(RTCW(Result), ((EIF_INTEGER_32) 127L));
	RTOSE (2036);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2036 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2036,F152_2036_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.graph_set */
static EIF_REFERENCE F152_2037_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2037);
#define Result RTOSR(2037)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",94,554150526);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2037);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2037 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2037,F152_2037_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.print_set */
static EIF_REFERENCE F152_2038_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2038);
#define Result RTOSR(2038)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H(" !\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",95,1652388478);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2038);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2038 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2038,F152_2038_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.punct_set */
static EIF_REFERENCE F152_2039_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2039);
#define Result RTOSR(2039)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./:;<=>\?@[\\]^_`{|}~",32,391924606);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2039);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2039 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2039,F152_2039_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.ascii_set */
static EIF_REFERENCE F152_2040_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2040);
#define Result RTOSR(2040)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F32_330(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 127L))) break;
		F32_335(RTCW(Result), loc1);
		loc1++;
	}
	RTOSE (2040);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2040 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2040,F152_2040_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.space_set */
static EIF_REFERENCE F152_2041_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2041);
#define Result RTOSR(2041)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("\011\012\014\015\013 ",6,219952928);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2041);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2041 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2041,F152_2041_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.meta_set */
static EIF_REFERENCE F152_2042_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2042);
#define Result RTOSR(2042)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*+\?{^.$|()[",11,572368475);
	F32_331(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2042);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2042 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2042,F152_2042_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_names */
static EIF_REFERENCE F152_2043_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (2043);
#define Result RTOSR(2043)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,1052,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("alpha",5,1820051041);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("lower",5,1870925170);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("upper",5,1887312754);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("alnum",5,1819923309);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("ascii",5,1936639849);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("cntrl",5,1853885548);
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("digit",5,1769152884);
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("graph",5,1919779432);
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("print",5,1920372340);
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("punct",5,1971028852);
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("space",5,1886313829);
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("word",4,2003792484);
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("xdigit",6,2005082484);
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2043);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2043 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2043,F152_2043_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_sets */
static EIF_REFERENCE F152_2044_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (2044);
#define Result RTOSR(2044)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,31,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOSCF(2032,F152_2032, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2031,F152_2031, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2030,F152_2030, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2034,F152_2034, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2040,F152_2040, (Current));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2036,F152_2036, (Current));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2033,F152_2033, (Current));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2037,F152_2037, (Current));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2038,F152_2038, (Current));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2039,F152_2039, (Current));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2041,F152_2041, (Current));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2029,F152_2029, (Current));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(2035,F152_2035, (Current));
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2044);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2044 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2044,F152_2044_body,(Current));
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
