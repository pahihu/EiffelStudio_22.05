/*
 * Code for class I18N_DATE_TIME_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1100.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_TIME_INFO}.make */
void F124_1742 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1769,F124_1769, (Current));
	F124_1760(Current, tr1);
	tr1 = RTOSCF(1772,F124_1772, (Current));
	F124_1761(Current, tr1);
	tr1 = RTOSCF(1771,F124_1771, (Current));
	F124_1762(Current, tr1);
	tr1 = RTOSCF(1772,F124_1772, (Current));
	F124_1763(Current, tr1);
	tr1 = RTOSCF(1773,F124_1773, (Current));
	F124_1764(Current, tr1);
	tr1 = RTOSCF(1774,F124_1774, (Current));
	F124_1765(Current, tr1);
	tr1 = RTOSCF(1775,F124_1775, (Current));
	F124_1766(Current, tr1);
	tr1 = RTOSCF(1781,F124_1781, (Current));
	F124_1767(Current, tr1);
	tr1 = RTOSCF(1780,F124_1780, (Current));
	F124_1768(Current, tr1);
	tr1 = RTOSCF(1776,F124_1776, (Current));
	F124_1756(Current, tr1);
	tr1 = RTOSCF(1777,F124_1777, (Current));
	F124_1758(Current, tr1);
	tr1 = RTOSCF(1778,F124_1778, (Current));
	F124_1757(Current, tr1);
	tr1 = RTOSCF(1779,F124_1779, (Current));
	F124_1759(Current, tr1);
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_day_names */
void F124_1756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_day_names */
void F124_1757 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_month_names */
void F124_1758 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_month_names */
void F124_1759 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
}

/* {I18N_DATE_TIME_INFO}.set_date_time_format */
void F124_1760 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_long_date_format */
void F124_1761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_short_date_format */
void F124_1762 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_long_time_format */
void F124_1763 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_short_time_format */
void F124_1764 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_am_suffix */
void F124_1765 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_pm_suffix */
void F124_1766 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_time_separator */
void F124_1767 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.set_date_separator */
void F124_1768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_DATE_TIME_INFO}.default_date_time_format */
static EIF_REFERENCE F124_1769_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1769);
#define Result RTOSR(1769)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1770,F124_1770, (Current));
	F1058_8099(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'T';
	F1058_8113(RTCW(Result), tw1);
	tr1 = RTOSCF(1772,F124_1772, (Current));
	F1058_8099(RTCW(Result), tr1);
	RTOSE (1769);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1769 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1769,F124_1769_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_date_format */
static EIF_REFERENCE F124_1770_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1770);
#define Result RTOSR(1770)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'e';
	F1058_8113(RTCW(Result), tw1);
	RTOSE (1770);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1770 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1770,F124_1770_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_date_format */
static EIF_REFERENCE F124_1771_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1771);
#define Result RTOSR(1771)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1058_8113(RTCW(Result), tw1);
	RTOSE (1771);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1771 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1771,F124_1771_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_time_format */
static EIF_REFERENCE F124_1772_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1772);
#define Result RTOSR(1772)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1773,F124_1773, (Current));
	F1058_8099(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '5';
	F1058_8113(RTCW(Result), tw1);
	RTOSE (1772);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1772 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1772,F124_1772_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_time_format */
static EIF_REFERENCE F124_1773_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1773);
#define Result RTOSR(1773)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'k';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1058_8113(RTCW(Result), tw1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'M';
	F1058_8113(RTCW(Result), tw1);
	RTOSE (1773);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1773 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1773,F124_1773_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_am_suffix */
static EIF_REFERENCE F124_1774_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1774);
#define Result RTOSR(1774)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("a\000\000\000m\000\000\000",2,24941);
	RTOSE (1774);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1774 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1774,F124_1774_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_pm_suffix */
static EIF_REFERENCE F124_1775_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1775);
#define Result RTOSR(1775)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("p\000\000\000m\000\000\000",2,28781);
	RTOSE (1775);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1775 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1775,F124_1775_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_day_names */
static EIF_REFERENCE F124_1776_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1776);
#define Result RTOSR(1776)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1048_7745(RTMS_EX_H("Monday",6,2004312953));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Tuesday",7,1495753593));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Wednesday",9,1804915065));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Thursday",8,844137593));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Friday",6,1906687353));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Saturday",8,1596931193));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Sunday",6,2016155513));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1776);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1776 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1776,F124_1776_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_month_names */
static EIF_REFERENCE F124_1777_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1777);
#define Result RTOSR(1777)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1048_7745(RTMS_EX_H("January",7,751658105));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("February",8,1474449017));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("March",5,1635477864));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("April",5,1887045484));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("June",4,1249209957));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("July",4,1249209465));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("August",6,1864444276));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("September",9,1077346930));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("October",7,1024137842));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("November",8,2119563634));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("December",8,1341698930));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1777);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1777 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1777,F124_1777_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_day_names */
static EIF_REFERENCE F124_1778_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1778);
#define Result RTOSR(1778)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1048_7745(RTMS_EX_H("Mon",3,5074798));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Tue",3,5535077));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Wed",3,5727588));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Thu",3,5531765));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Fri",3,4616809));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Sat",3,5464436));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Sun",3,5469550));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1778);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1778 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1778,F124_1778_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_month_names */
static EIF_REFERENCE F124_1779_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1779);
#define Result RTOSR(1779)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1048_7745(RTMS_EX_H("Jan",3,4874606));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Feb",3,4613474));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Mar",3,5071218));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Apr",3,4288626));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Jun",3,4879726));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Jul",3,4879724));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Aug",3,4289895));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Sep",3,5465456));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Oct",3,5202804));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Nov",3,5140342));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1048_7745(RTMS_EX_H("Dec",3,4482403));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1779);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1779 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1779,F124_1779_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_date_separator */
static EIF_REFERENCE F124_1780_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1780);
#define Result RTOSR(1780)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("/\000\000\000",1,47);
	RTOSE (1780);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1780 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1780,F124_1780_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_time_separator */
static EIF_REFERENCE F124_1781_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1781);
#define Result RTOSR(1781)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(":\000\000\000",1,58);
	RTOSE (1781);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_1781 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1781,F124_1781_body,(Current));
}

void EIF_Minit100 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
