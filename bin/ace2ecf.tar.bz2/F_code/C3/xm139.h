
#ifndef _C3_xm139_
#define _C3_xm139_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 2148)


extern EIF_REFERENCE F166_2148(EIF_REFERENCE);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
