/*
 * Code for class I18N_FILE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1116.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FILE_MANAGER}.make */
void F141_1964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F140_1957(Current, arg1);
	tr1 = RTLNS(eif_new_type(99, 0x00).id, 99, _OBJSIZ_2_1_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(394, 0).id);
	F395_4820(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F141_1974(Current);
	RTLE;
}

/* {I18N_FILE_MANAGER}.dictionary */
EIF_REFERENCE F141_1965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tr1 = F141_1966(Current);
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(RTCW(tr1))-703])(tr1, arg1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F796_6018(RTCW(tr1), arg1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F99_1446(RTCW(tr1), loc2);
	} else {
		tb1 = '\0';
		tr1 = F141_1967(Current);
		tr2 = F1223_10106(RTCW(arg1));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(RTCW(tr1))-703])(tr1, tr2);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1223_10106(RTCW(arg1));
			tr1 = F796_6018(RTCW(tr1), tr2);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc1 = F99_1446(RTCW(tr1), loc3);
		}
	}
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNS(eif_new_type(208, 0x00).id, 208, _OBJSIZ_1_0_0_2_0_0_0_0_);
		F207_2567(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {I18N_FILE_MANAGER}.available_locales */
EIF_REFERENCE F141_1966 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {I18N_FILE_MANAGER}.available_languages */
EIF_REFERENCE F141_1967 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_4_);
}

/* {I18N_FILE_MANAGER}.populate_file_lists */
void F141_1974 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {795,1047,1222,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F796_6012(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1222,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F893_6362(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {795,1047,1214,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F796_6012(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1214,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F893_6362(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F552_5431(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F552_5431(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F552_5431(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F552_5431(RTCW(tr1));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tb2 = F395_4845(RTCW(tr1));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb2 = F395_4846(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F395_4830(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F395_4836(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc4 = F395_4826(RTCW(tr1));
		F893_6393(RTCW(loc1));
		for (;;) {
			tb1 = F864_6281(RTCW(loc1));
			if (tb1) break;
			tb2 = '\0';
			tr1 = F893_6367(RTCW(loc1));
			tb3 = F1073_8633(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb3) {
				tr1 = F893_6367(RTCW(loc1));
				tb3 = F1073_8632(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = F893_6367(RTCW(loc1));
				tr1 = F1073_8655(RTCW(loc4), tr1);
				loc3 = F1073_8666(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				loc2 = F99_1444(RTCW(tr1), loc3);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F796_6058(RTCW(tr1), loc3, loc5);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb2 = F796_6041(RTCW(tr1));
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[Dtype(RTCW(tr1))-703])(tr1, loc5);
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							F796_6058(RTCW(tr1), loc3, loc6);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tb2 = F796_6041(RTCW(tr1));
							if (tb2) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[Dtype(RTCW(tr1))-703])(tr1, loc6);
							}
						}
					}
				}
			}
			F893_6395(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
