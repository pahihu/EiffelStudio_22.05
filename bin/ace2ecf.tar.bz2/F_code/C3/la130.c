/*
 * Code for class LACE_PARSER_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "la130.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LACE_PARSER_ROUTINES}.build_ast */
void F155_2081 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1276, 0x00).id, 1276, _OBJSIZ_6_7_2_4_1_1_2_1_);
	F1277_11697(RTCW(loc1), arg1);
	F1272_11669(RTCW(loc1));
	tb1 = F1272_11662(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
	} else {
		F1310_12698(Current, loc1);
		F1272_11670(RTCW(loc1));
	}
	RTLE;
}

/* {LACE_PARSER_ROUTINES}.parse_file */
void F155_2082 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_87_1_) = (EIF_BOOLEAN) arg2;
	F155_2084(Current, NULL);
	F155_2081(Current, arg1);
	RTLE;
}

/* {LACE_PARSER_ROUTINES}.set_last_syntax_error */
void F155_2084 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(2085,F155_2085, (Current));
	F172_2263(RTCW(tr1), arg1);
	RTLE;
}

/* {LACE_PARSER_ROUTINES}.last_syntax_cell */
static EIF_REFERENCE F155_2085_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2085);
#define Result RTOSR(2085)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {171,1052,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 171, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F172_2263(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2085);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F155_2085 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2085,F155_2085_body,(Current));
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
