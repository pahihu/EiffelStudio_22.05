
#ifndef _C3_co126_
#define _C3_co126_

#ifdef __cplusplus
extern "C" {
#endif

extern void F151_2027(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
