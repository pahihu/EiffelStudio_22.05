
#ifndef _C3_ar123_
#define _C3_ar123_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2012)
static EIF_REFERENCE F148_2012_body(EIF_REFERENCE);
extern EIF_REFERENCE F148_2012(EIF_REFERENCE);
extern void EIF_Minit123(void);
extern EIF_REFERENCE F453_5278(EIF_REFERENCE);
extern void F1073_8627(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5278)

#ifdef __cplusplus
}
#endif

#endif
