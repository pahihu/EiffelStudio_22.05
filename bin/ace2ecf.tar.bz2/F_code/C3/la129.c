/*
 * Code for class LACE_AST_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "la129.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LACE_AST_FACTORY}.new_id_sd */
EIF_REFERENCE F154_2075 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1053, 0x00).id, 1053, _OBJSIZ_1_2_0_3_0_0_0_0_);
	F1054_7981(RTCW(Result), arg1);
	if (arg2) {
		F1054_7983(RTCW(Result));
	}
	RTLE;
	return Result;
}

void EIF_Minit129 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
