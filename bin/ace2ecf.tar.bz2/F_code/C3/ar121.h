
#ifndef _C3_ar121_
#define _C3_ar121_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F146_2003(EIF_REFERENCE);
extern void F146_2007(EIF_REFERENCE, EIF_REFERENCE);
extern void F146_2009(EIF_REFERENCE);
extern void EIF_Minit121(void);
extern void F1048_7685(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
