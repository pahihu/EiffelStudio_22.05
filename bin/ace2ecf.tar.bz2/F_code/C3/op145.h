
#ifndef _C3_op145_
#define _C3_op145_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,2268)
static EIF_CHARACTER_8 F179_2268_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F179_2268(EIF_REFERENCE);
extern EIF_BOOLEAN F179_2270(EIF_REFERENCE);
extern EIF_BOOLEAN F179_2272(EIF_REFERENCE);
extern EIF_CHARACTER_8 F179_2273(EIF_REFERENCE);
extern void EIF_Minit145(void);

#ifdef __cplusplus
}
#endif

#endif
