
#ifndef _C3_la129_
#define _C3_la129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F154_2075(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit129(void);
extern void F1054_7983(EIF_REFERENCE);
extern void F1054_7981(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
