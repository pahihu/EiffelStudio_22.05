/*
 * Code for class CONF_LOCATION_IRON_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co110.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_IRON_MAPPING}.make */
void F135_1917 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {CONF_LOCATION_IRON_MAPPING}.mapped_location */
EIF_REFERENCE F135_1920 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tr1 = F1048_7744(RTMS_EX_H("iron:",5,1920711738));
	tb3 = F1056_8019(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = F1048_7744(RTMS_EX_H("http:",5,1954586682));
		tb3 = F1056_8019(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = F1048_7744(RTMS_EX_H("https:",6,11409978));
		tb2 = F1056_8019(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1056_7986(RTCW(loc1), arg1);
		F135_1925(Current, loc1);
		tr1 = F135_1923(Current);
		tr1 = F404_5007(RTCW(tr1), loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1073_8666(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_LOCATION_IRON_MAPPING}.refresh */
void F135_1922 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F404_4982(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
}

/* {CONF_LOCATION_IRON_MAPPING}.iron_api */
EIF_REFERENCE F135_1923 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F404_4982(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = (EIF_REFERENCE) NULL;
	}
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc2 = RTLNS(eif_new_type(15, 0x00).id, 15, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc1 = F16_181(RTCW(loc2), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_IRON_MAPPING}.update_location_to_uri */
void F135_1925 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1058_8076(RTCW(arg1), tr1, tr2);
	RTLE;
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
