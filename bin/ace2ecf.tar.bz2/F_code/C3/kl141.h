
#ifndef _C3_kl141_
#define _C3_kl141_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2190)
static EIF_REFERENCE F168_2190_body(EIF_REFERENCE);
extern EIF_REFERENCE F168_2190(EIF_REFERENCE);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
