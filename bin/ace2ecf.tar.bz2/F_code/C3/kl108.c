/*
 * Code for class KL_SHARED_STREAMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl108.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STREAMS}.null_input_stream */
static EIF_REFERENCE F133_1912_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1912);
#define Result RTOSR(1912)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(964, 0x00).id, 964, _OBJSIZ_2_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F965_7082(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1912);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F133_1912 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1912,F133_1912_body,(Current));
}

void EIF_Minit108 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
