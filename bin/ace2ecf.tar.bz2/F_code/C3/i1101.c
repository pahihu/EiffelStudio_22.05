/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1101.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F125_1782 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1805,F125_1805, (Current));
	F125_1814(Current, tr1);
	F125_1815(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(1806,F125_1806, (Current));
	F125_1816(Current, tr1);
	F125_1817(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1809,F125_1809, (Current));
	F125_1818(Current, tr1);
	tr1 = RTOSCF(1810,F125_1810, (Current));
	F125_1819(Current, tr1);
	tr1 = RTOSCF(1811,F125_1811, (Current));
	F125_1820(Current, tr1);
	tr1 = RTOSCF(1812,F125_1812, (Current));
	F125_1821(Current, tr1);
	tr1 = RTOSCF(1813,F125_1813, (Current));
	F125_1822(Current, tr1);
	tr1 = RTOSCF(1805,F125_1805, (Current));
	F125_1823(Current, tr1);
	F125_1824(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(1806,F125_1806, (Current));
	F125_1825(Current, tr1);
	F125_1826(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1809,F125_1809, (Current));
	F125_1827(Current, tr1);
	tr1 = RTOSCF(1810,F125_1810, (Current));
	F125_1828(Current, tr1);
	tr1 = RTOSCF(1813,F125_1813, (Current));
	F125_1829(Current, tr1);
	RTLE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F125_1805_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1805);
#define Result RTOSR(1805)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1805);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1805 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1805,F125_1805_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F125_1806_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1806);
#define Result RTOSR(1806)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1806);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1806 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1806,F125_1806_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F125_1809_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1809);
#define Result RTOSR(1809)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1809);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1809 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1809,F125_1809_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F125_1810_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1810);
#define Result RTOSR(1810)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1810);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1810 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1810,F125_1810_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F125_1811_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1811);
#define Result RTOSR(1811)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1811);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1811 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1811,F125_1811_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F125_1812_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1812);
#define Result RTOSR(1812)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1812);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1812 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1812,F125_1812_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F125_1813_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1813);
#define Result RTOSR(1813)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1109,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1110_8730)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1813);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F125_1813 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1813,F125_1813_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F125_1814 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1759[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F125_1815 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1760[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F125_1816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1764[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F125_1817 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1765[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F125_1818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1766[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F125_1819 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1767[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F125_1820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1768[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F125_1821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1769[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F125_1822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1770[Dtype(Current)-124]) = (EIF_REFERENCE) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F125_1823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1771[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F125_1824 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1772[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F125_1825 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1776[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F125_1826 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1777[Dtype(Current)-124]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F125_1827 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1778[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F125_1828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7745(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1779[Dtype(Current)-124]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F125_1829 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1780[Dtype(Current)-124]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
