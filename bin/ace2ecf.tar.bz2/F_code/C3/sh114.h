
#ifndef _C3_sh114_
#define _C3_sh114_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1956)
static EIF_REFERENCE F139_1956_body(EIF_REFERENCE);
extern EIF_REFERENCE F139_1956(EIF_REFERENCE);
extern void EIF_Minit114(void);

#ifdef __cplusplus
}
#endif

#endif
