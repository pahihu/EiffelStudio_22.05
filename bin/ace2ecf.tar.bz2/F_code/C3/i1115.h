
#ifndef _C3_i1115_
#define _C3_i1115_

#ifdef __cplusplus
extern "C" {
#endif

extern void F140_1957(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F140_1961(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F140_1962(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit115(void);
extern EIF_REFERENCE F141_1967(EIF_REFERENCE);
extern void F1058_8060(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F141_1966(EIF_REFERENCE);
extern char *(*R4890[])();

#ifdef __cplusplus
}
#endif

#endif
