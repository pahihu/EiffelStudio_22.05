
#ifndef _C3_i1119_
#define _C3_i1119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F144_1996(EIF_REFERENCE, EIF_REFERENCE);
extern void F144_1997(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit119(void);
extern long O1764[];
extern long O1765[];
extern long O1766[];
extern long O1768[];
extern long O1769[];
extern long O1770[];

#ifdef __cplusplus
}
#endif

#endif
