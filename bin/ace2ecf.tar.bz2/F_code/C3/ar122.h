
#ifndef _C3_ar122_
#define _C3_ar122_

#ifdef __cplusplus
extern "C" {
#endif

extern void F147_2011(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
