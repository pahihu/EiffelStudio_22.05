/*
 * Code for class CODE_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co120.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_SETS}.two_byte_code_pages */
static EIF_REFERENCE F145_1999_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1999);
#define Result RTOSR(1999)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {804,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 804, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F805_6136(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2",5,1130177330);
	tr2 = RTMS_EX_H("ucs-2",5,1669391154);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-2",15,137660722);
	tr2 = RTMS_EX_H("iso-10646-ucs-2",15,932466994);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode",9,1140938597);
	tr2 = RTMS_EX_H("csunicode",9,67227493);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODE-1-1",11,1407647281);
	tr2 = RTMS_EX_H("unicode-1-1",11,366474289);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUnicode11",11,1599950641);
	tr2 = RTMS_EX_H("csunicode11",11,1339907633);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(912,F58_912, (Current));
	tr2 = RTMS_EX_H("utf-16",6,1945159990);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(916,F58_916, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(914,F58_914, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-INTERNAL",14,834453068);
	tr2 = RTMS_EX_H("ucs-2-internal",14,1377880940);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-2-SWAPPED",13,297507908);
	tr2 = RTMS_EX_H("ucs-2-swapped",13,861666404);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("JAVA",4,1245795905);
	tr2 = RTMS_EX_H("java",4,1784772193);
	F796_6058(RTCW(Result), tr1, tr2);
	RTOSE (1999);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F145_1999 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1999,F145_1999_body,(Current));
}

/* {CODE_SETS}.four_byte_code_pages */
static EIF_REFERENCE F145_2000_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2000);
#define Result RTOSR(2000)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {804,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 804, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F805_6136(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-4",5,1130177332);
	tr2 = RTMS_EX_H("ucs-4",5,1669391156);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("ISO-10646-UCS-4",15,137660724);
	tr2 = RTMS_EX_H("iso-10646-ucs-4",15,932466996);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("csUCS4",6,1626000692);
	tr2 = RTMS_EX_H("csucs4",6,17497140);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(913,F58_913, (Current));
	tr2 = RTMS_EX_H("utf-32",6,1945160498);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(917,F58_917, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(915,F58_915, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-INTERNAL",14,968724556);
	tr2 = RTMS_EX_H("ucs-4-internal",14,1512152428);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4-SWAPPED",13,415472708);
	tr2 = RTMS_EX_H("ucs-4-swapped",13,979631204);
	F796_6058(RTCW(Result), tr1, tr2);
	RTOSE (2000);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F145_2000 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2000,F145_2000_body,(Current));
}

/* {CODE_SETS}.little_endian_code_pages */
static EIF_REFERENCE F145_2001_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2001);
#define Result RTOSR(2001)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {804,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 804, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F805_6136(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(914,F58_914, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(915,F58_915, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F796_6058(RTCW(Result), tr1, tr2);
	RTOSE (2001);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F145_2001 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2001,F145_2001_body,(Current));
}

/* {CODE_SETS}.big_endian_code_pages */
static EIF_REFERENCE F145_2002_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (2002);
#define Result RTOSR(2002)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {804,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 804, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F805_6136(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(916,F58_916, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F796_6058(RTCW(Result), tr1, tr2);
	tr1 = RTOSCF(917,F58_917, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F796_6058(RTCW(Result), tr1, tr2);
	RTOSE (2002);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F145_2002 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2002,F145_2002_body,(Current));
}

void EIF_Minit120 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
