
#ifndef _C3_i1103_
#define _C3_i1103_

#ifdef __cplusplus
extern "C" {
#endif

extern void F127_1852(EIF_REFERENCE);
extern void F127_1854(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit103(void);
extern void F124_1742(EIF_REFERENCE);
extern void F1223_10100(EIF_REFERENCE, EIF_REFERENCE);
extern void F125_1782(EIF_REFERENCE);
extern void F126_1830(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
