
#ifndef _C3_i1118_
#define _C3_i1118_

#ifdef __cplusplus
extern "C" {
#endif

extern void F143_1981(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
