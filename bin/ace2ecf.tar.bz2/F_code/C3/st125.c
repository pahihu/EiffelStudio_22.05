/*
 * Code for class STRING_EXPANDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st125.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_EXPANDER}.expand_string_32 */
EIF_REFERENCE F150_2020 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,loc10);
	RTLR(3,Current);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,loc11);
	RTLR(8,loc12);
	RTLIU(9);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	F1056_7984(RTCW(Result), ti4_1);
	{
		static EIF_TYPE_INDEX typarr0[] = {795,1057,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc10 = RTLNS(typres0.id, 795, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F796_6012(RTCW(loc10), ((EIF_INTEGER_32) 13L));
	loc5 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_7984(RTCW(loc5), ((EIF_INTEGER_32) 128L));
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc3)) break;
		loc1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc4);
		tb1 = '\0';
		if ((EIF_BOOLEAN) !loc8) {
			tw1 = (EIF_CHARACTER_32) F150_2023(Current);
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) {
			loc4++;
			if ((EIF_BOOLEAN) (loc4 <= loc3)) {
				loc2 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc4);
				tb1 = '\01';
				tb2 = '\01';
				tr1 = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc2;
				tb3 = F1000_7515(RTCW(tr1));
				if (!tb3) {
					tb2 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_32) 123U);
				}
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_32) 40U);
				}
				if (tb1) {
					tb1 = F709_5583(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						F1058_8099(RTCW(Result), loc5);
						F1058_8128(RTCW(loc5));
					}
					tr1 = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc2;
					loc9 = F1000_7515(RTCW(tr1));
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc9;
					if ((EIF_BOOLEAN) !loc9) {
						F1058_8112(RTCW(loc5), loc2);
					}
					loc4++;
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					for (;;) {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 || (EIF_BOOLEAN) (loc4 > loc3))) break;
						loc1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc4);
						if (loc9) {
							loc7 = '\01';
							tb1 = '\0';
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
							if ((EIF_BOOLEAN)(loc2 == tw1)) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
								tb1 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb1) {
								tb1 = '\0';
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
								if ((EIF_BOOLEAN)(loc2 == tw1)) {
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
									tb1 = (EIF_BOOLEAN)(loc1 == tw1);
								}
								loc7 = tb1;
							}
							loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc7;
						} else {
							loc7 = '\01';
							tb1 = '\01';
							tr1 = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
							*(EIF_CHARACTER_32 *)tr1 = loc1;
							tb2 = F1000_7515(RTCW(tr1));
							if (!tb2) {
								tb2 = EIF_TEST(isdigit(loc1));
								tb1 = tb2;
							}
							if (!tb1) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
								loc7 = (EIF_BOOLEAN)(loc1 == tw1);
							}
						}
						if (loc7) {
							F1058_8112(RTCW(loc5), loc1);
							loc4++;
						} else {
							if ((EIF_BOOLEAN) !loc9) {
								loc4--;
							}
						}
					}
					tb1 = F709_5583(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						loc6 = (EIF_REFERENCE) loc5;
						tb1 = '\0';
						tb2 = F796_6020(RTCW(loc10), loc6);
						if (tb2) {
							tr1 = F796_6018(RTCW(loc10), loc6);
							loc11 = tr1;
							tb1 = EIF_TEST(loc11);
						}
						if (tb1) {
							F1058_8099(RTCW(Result), loc11);
						} else {
							tr1 = F402_4970(Current, loc6);
							loc12 = tr1;
							if (EIF_TEST(loc12)) {
								F1058_8099(RTCW(Result), loc12);
								F796_6058(RTCW(loc10), loc12, loc6);
							} else {
								if (arg2) {
									tw1 = (EIF_CHARACTER_32) F150_2023(Current);
									F1058_8112(RTCW(Result), tw1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
									F1058_8112(RTCW(Result), tw1);
									F1058_8099(RTCW(Result), loc5);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
									F1058_8112(RTCW(Result), tw1);
								}
							}
						}
						F1058_8128(RTCW(loc5));
					}
				} else {
					F1058_8112(RTCW(loc5), loc2);
				}
			} else {
				F1058_8112(RTCW(loc5), loc1);
			}
		} else {
			tw1 = (EIF_CHARACTER_32) F150_2024(Current);
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc8;
				if ((EIF_BOOLEAN) !loc8) {
					F1058_8112(RTCW(loc5), loc1);
				}
			} else {
				F1058_8112(RTCW(loc5), loc1);
			}
		}
		tw1 = (EIF_CHARACTER_32) F150_2024(Current);
		if ((EIF_BOOLEAN)(loc1 != tw1)) {
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		loc4++;
	}
	tb1 = F709_5583(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		F1058_8099(RTCW(Result), loc5);
	}
	RTLE;
	return Result;
}

/* {STRING_EXPANDER}.id_specifier_char */
EIF_CHARACTER_8 F150_2023 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) (EIF_CHARACTER_8) '$';
}

/* {STRING_EXPANDER}.esc_specifier_char */
EIF_CHARACTER_8 F150_2024 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) (EIF_CHARACTER_8) '%';
}

void EIF_Minit125 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
