/*
 * Code for class I18N_LOCALE_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1103.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_INFO}.make */
void F127_1852 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F124_1742(Current);
	F126_1830(Current);
	F125_1782(Current);
	{
		/* INLINED CODE (I18N_CODE_PAGE_INFO.initialize_code_page_info) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1222, 0).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1223_10100(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_LOCALE_INFO}.set_id */
void F127_1854 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit103 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
