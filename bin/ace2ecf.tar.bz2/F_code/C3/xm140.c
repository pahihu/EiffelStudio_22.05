/*
 * Code for class XML_MARKUP_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm140.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_MARKUP_CONSTANTS}.lt_entity */

EIF_REFERENCE F167_2170 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2170,RTMS32_EX_H("&\000\000\000l\000\000\000t\000\000\000;\000\000\000",4,644641851));
}

/* {XML_MARKUP_CONSTANTS}.gt_entity */

EIF_REFERENCE F167_2171 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2171,RTMS32_EX_H("&\000\000\000g\000\000\000t\000\000\000;\000\000\000",4,644314171));
}

/* {XML_MARKUP_CONSTANTS}.amp_entity */

EIF_REFERENCE F167_2172 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2172,RTMS32_EX_H("&\000\000\000a\000\000\000m\000\000\000p\000\000\000;\000\000\000",5,1634853947));
}

/* {XML_MARKUP_CONSTANTS}.quot_entity */

EIF_REFERENCE F167_2173 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2173,RTMS32_EX_H("&\000\000\000q\000\000\000u\000\000\000o\000\000\000t\000\000\000;\000\000\000",6,2045817403));
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
