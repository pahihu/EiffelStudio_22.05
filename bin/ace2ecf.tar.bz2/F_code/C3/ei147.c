/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei147.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F181_2291 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2291,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F181_2294 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2294,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F181_2295 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2295,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F181_2301 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2301,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.config_extension */

EIF_REFERENCE F181_2304 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2304,RTMS_EX_H("ecf",3,6644582));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F181_2309_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2309);
#define Result RTOSR(2309)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F181_2311(Current, ti4_1);
	RTOSE (2309);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F181_2309 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2309,F181_2309_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F181_2310_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2310);
#define Result RTOSR(2310)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F181_2311(Current, ti4_1);
	RTOSE (2310);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F181_2310 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2310,F181_2310_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F181_2311 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1051_7815(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '0');
	}
	F1053_7931(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit147 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
