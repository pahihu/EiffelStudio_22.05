/*
 * Code for class SHARED_I18N_URI_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh114.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_I18N_URI_PARSER}.parser */
static EIF_REFERENCE F139_1956_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1956);
#define Result RTOSR(1956)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(17, 0x00).id, 17, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1956);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F139_1956 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1956,F139_1956_body,(Current));
}

void EIF_Minit114 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
