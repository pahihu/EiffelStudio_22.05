/*
 * Code for class ARGUMENT_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_SOURCE}.application */
static EIF_REFERENCE F148_2012_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2012);
#define Result RTOSR(2012)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(452, 0x00).id, 452, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(5278,F453_5278, (RTCW(tr2)));
	F1073_8627(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2012);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F148_2012 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2012,F148_2012_body,(Current));
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
