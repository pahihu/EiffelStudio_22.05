#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1427_gen_type [2];
EIF_TYPE_INDEX Y1427 [2];
void Y1427_init (void)
{
	egc_routines_types [1427] = Y1427;
	egc_routines_gen_types [1427] = Y1427_gen_type;
	egc_routines_offset [1427] = 98;
	Y1427[0] = 204;
	Y1427[1] = 205;
}

long O1759[3];
void O1759_init () {
	O1759[0] = 0;
	O1759[2] =  + _REFACS_16_;
}

long O1760[3];
void O1760_init () {
	O1760[0] = + _LNGOFF_12_0_0_0_;
	O1760[2] = + _LNGOFF_35_0_0_0_;
}

long O1764[3];
void O1764_init () {
	O1764[0] =  + _REFACS_1_;
	O1764[2] =  + _REFACS_17_;
}

long O1765[3];
void O1765_init () {
	O1765[0] = + _LNGOFF_12_0_0_1_;
	O1765[2] = + _LNGOFF_35_0_0_1_;
}

long O1766[3];
void O1766_init () {
	O1766[0] =  + _REFACS_2_;
	O1766[2] =  + _REFACS_18_;
}

long O1767[3];
void O1767_init () {
	O1767[0] =  + _REFACS_3_;
	O1767[2] =  + _REFACS_19_;
}

long O1768[3];
void O1768_init () {
	O1768[0] =  + _REFACS_4_;
	O1768[2] =  + _REFACS_20_;
}

long O1769[3];
void O1769_init () {
	O1769[0] =  + _REFACS_5_;
	O1769[2] =  + _REFACS_21_;
}

long O1770[3];
void O1770_init () {
	O1770[0] =  + _REFACS_6_;
	O1770[2] =  + _REFACS_22_;
}

long O1771[3];
void O1771_init () {
	O1771[0] =  + _REFACS_7_;
	O1771[2] =  + _REFACS_23_;
}

long O1772[3];
void O1772_init () {
	O1772[0] = + _LNGOFF_12_0_0_2_;
	O1772[2] = + _LNGOFF_35_0_0_2_;
}

long O1776[3];
void O1776_init () {
	O1776[0] =  + _REFACS_8_;
	O1776[2] =  + _REFACS_24_;
}

long O1777[3];
void O1777_init () {
	O1777[0] = + _LNGOFF_12_0_0_3_;
	O1777[2] = + _LNGOFF_35_0_0_3_;
}

long O1778[3];
void O1778_init () {
	O1778[0] =  + _REFACS_9_;
	O1778[2] =  + _REFACS_25_;
}

long O1779[3];
void O1779_init () {
	O1779[0] =  + _REFACS_10_;
	O1779[2] =  + _REFACS_26_;
}

long O1780[3];
void O1780_init () {
	O1780[0] =  + _REFACS_11_;
	O1780[2] =  + _REFACS_27_;
}

long O2210[7];
void O2210_init () {
	O2210[0] = 0;
	{long i; for (i = 1; i < 3; i++) O2210[i] = + _LNGOFF_0_0_0_0_;}
	O2210[3] = + _CHROFF_0_0_;
	O2210[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O2210[5] = 0;
	O2210[6] = + _LNGOFF_1_0_0_0_;
}

long O2214[2];
void O2214_init () {
	O2214[0] =  + _REFACS_1_;
	O2214[1] = 0;
}

long O2309[3];
void O2309_init () {
	O2309[0] = + _CHROFF_3_0_;
	O2309[1] = + _CHROFF_4_0_;
	O2309[2] = + _CHROFF_5_0_;
}

long O2481[3];
void O2481_init () {
	O2481[0] = + _LNGOFF_1_0_0_0_;
	O2481[1] = + _LNGOFF_2_0_0_0_;
	O2481[2] = + _LNGOFF_1_0_0_0_;
}

long O2485[3];
void O2485_init () {
	O2485[0] = + _LNGOFF_1_0_0_1_;
	O2485[1] = + _LNGOFF_2_0_0_1_;
	O2485[2] = + _LNGOFF_1_0_0_1_;
}

long O2839[4];
void O2839_init () {
	O2839[0] = + _CHROFF_2_0_;
	O2839[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O2839[i] = + _CHROFF_2_0_;}
}

long O2840[4];
void O2840_init () {
	O2840[0] = + _CHROFF_2_1_;
	O2840[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O2840[i] = + _CHROFF_2_1_;}
}

long O3117[6];
void O3117_init () {
	{long i; for (i = 0; i < 3; i++) O3117[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O3117[i] = + _LNGOFF_2_4_0_0_;}
	O3117[5] = + _LNGOFF_2_5_0_0_;
}

long O3118[6];
void O3118_init () {
	{long i; for (i = 0; i < 3; i++) O3118[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O3118[i] = + _LNGOFF_2_4_0_1_;}
	O3118[5] = + _LNGOFF_2_5_0_1_;
}

long O3119[6];
void O3119_init () {
	{long i; for (i = 0; i < 3; i++) O3119[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O3119[i] = + _LNGOFF_2_4_0_2_;}
	O3119[5] = + _LNGOFF_2_5_0_2_;
}

long O3120[6];
void O3120_init () {
	{long i; for (i = 0; i < 3; i++) O3120[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O3120[i] = + _LNGOFF_2_4_0_3_;}
	O3120[5] = + _LNGOFF_2_5_0_3_;
}

long O3121[6];
void O3121_init () {
	{long i; for (i = 0; i < 3; i++) O3121[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O3121[i] = + _LNGOFF_2_4_0_4_;}
	O3121[5] = + _LNGOFF_2_5_0_4_;
}

long O3122[6];
void O3122_init () {
	{long i; for (i = 0; i < 3; i++) O3122[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O3122[i] = + _LNGOFF_2_4_0_5_;}
	O3122[5] = + _LNGOFF_2_5_0_5_;
}

long O3123[6];
void O3123_init () {
	{long i; for (i = 0; i < 3; i++) O3123[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O3123[i] = + _CHROFF_2_0_;}
}

long O3128[6];
void O3128_init () {
	{long i; for (i = 0; i < 3; i++) O3128[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O3128[i] = + _CHROFF_2_1_;}
}

long O4154[886];
void O4154_init () {
	O4154[0] = 0;
	{long i; for (i = 1; i < 3; i++) O4154[i] =  + _REFACS_1_;}
	O4154[549] =  + _REFACS_1_;
	O4154[885] = 0;
}

long O4276[763];
void O4276_init () {
	{long i; for (i = 0; i < 11; i++) O4276[i] = 0;}
	{long i; for (i = 753; i < 763; i++) O4276[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y4324_pgtype0[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype1[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype2[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype3[] = {1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype4[] = {1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype5[] = {1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype6[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype7[] = {1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype8[] = {1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype9[] = {1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype10[] = {1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype11[] = {1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype12[] = {1116,1205,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype13[] = {1116,1205,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype14[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype15[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype16[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype17[] = {1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype18[] = {1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype19[] = {1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype20[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype21[] = {1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype22[] = {1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype23[] = {1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype24[] = {1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype25[] = {1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype26[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype27[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype28[] = {1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype29[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype30[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype31[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype32[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype33[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype34[] = {1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype35[] = {1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype36[] = {1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype37[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype38[] = {1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype39[] = {1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype40[] = {1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype41[] = {1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype42[] = {1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype43[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype44[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype45[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype46[] = {1108,1261,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype47[] = {1108,908,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype48[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype49[] = {1112,1004,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype50[] = {1112,1004,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype51[] = {1112,1004,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype52[] = {1115,1001,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype53[] = {1112,1004,0xFFFF};
static EIF_TYPE_INDEX Y4324_pgtype54[] = {1112,1004,0xFFFF};
EIF_TYPE_INDEX *Y4324_gen_type [937];
EIF_TYPE_INDEX Y4324 [937];
void Y4324_init (void)
{
	egc_routines_types [4324] = Y4324;
	egc_routines_gen_types [4324] = Y4324_gen_type;
	egc_routines_offset [4324] = 378;
	Y4324_gen_type [0] = Y4324_pgtype0;
	Y4324_gen_type [1] = Y4324_pgtype1;
	Y4324_gen_type [2] = Y4324_pgtype2;
	Y4324_gen_type [3] = Y4324_pgtype3;
	Y4324_gen_type [4] = Y4324_pgtype4;
	Y4324_gen_type [5] = Y4324_pgtype5;
	Y4324_gen_type [6] = Y4324_pgtype6;
	Y4324_gen_type [7] = Y4324_pgtype7;
	Y4324_gen_type [8] = Y4324_pgtype8;
	Y4324_gen_type [9] = Y4324_pgtype9;
	Y4324_gen_type [10] = Y4324_pgtype10;
	Y4324_gen_type [11] = Y4324_pgtype11;
	Y4324_gen_type [14] = Y4324_pgtype12;
	Y4324_gen_type [15] = Y4324_pgtype13;
	Y4324_gen_type [444] = Y4324_pgtype14;
	Y4324_gen_type [445] = Y4324_pgtype15;
	Y4324_gen_type [446] = Y4324_pgtype16;
	Y4324_gen_type [447] = Y4324_pgtype17;
	Y4324_gen_type [448] = Y4324_pgtype18;
	Y4324_gen_type [449] = Y4324_pgtype19;
	Y4324_gen_type [450] = Y4324_pgtype20;
	Y4324_gen_type [451] = Y4324_pgtype21;
	Y4324_gen_type [452] = Y4324_pgtype22;
	Y4324_gen_type [453] = Y4324_pgtype23;
	Y4324_gen_type [454] = Y4324_pgtype24;
	Y4324_gen_type [455] = Y4324_pgtype25;
	Y4324_gen_type [456] = Y4324_pgtype26;
	Y4324_gen_type [457] = Y4324_pgtype27;
	Y4324_gen_type [458] = Y4324_pgtype28;
	Y4324_gen_type [459] = Y4324_pgtype29;
	Y4324_gen_type [460] = Y4324_pgtype30;
	Y4324_gen_type [514] = Y4324_pgtype31;
	Y4324_gen_type [515] = Y4324_pgtype32;
	Y4324_gen_type [516] = Y4324_pgtype33;
	Y4324_gen_type [517] = Y4324_pgtype34;
	Y4324_gen_type [518] = Y4324_pgtype35;
	Y4324_gen_type [519] = Y4324_pgtype36;
	Y4324_gen_type [520] = Y4324_pgtype37;
	Y4324_gen_type [521] = Y4324_pgtype38;
	Y4324_gen_type [522] = Y4324_pgtype39;
	Y4324_gen_type [523] = Y4324_pgtype40;
	Y4324_gen_type [524] = Y4324_pgtype41;
	Y4324_gen_type [525] = Y4324_pgtype42;
	Y4324_gen_type [526] = Y4324_pgtype43;
	Y4324_gen_type [527] = Y4324_pgtype44;
	Y4324_gen_type [528] = Y4324_pgtype45;
	Y4324_gen_type [529] = Y4324_pgtype46;
	Y4324_gen_type [530] = Y4324_pgtype47;
	Y4324_gen_type [601] = Y4324_pgtype48;
	Y4324_gen_type [674] = Y4324_pgtype49;
	Y4324_gen_type [675] = Y4324_pgtype50;
	Y4324_gen_type [676] = Y4324_pgtype51;
	Y4324_gen_type [679] = Y4324_pgtype52;
	Y4324_gen_type [935] = Y4324_pgtype53;
	Y4324_gen_type [936] = Y4324_pgtype54;
	Y4324[0] = 1108;
	Y4324[1] = 1109;
	Y4324[2] = 1110;
	Y4324[3] = 1111;
	Y4324[4] = 1112;
	Y4324[5] = 1113;
	Y4324[6] = 1114;
	Y4324[7] = 1115;
	Y4324[8] = 1116;
	Y4324[9] = 1117;
	Y4324[10] = 1118;
	Y4324[11] = 1119;
	{long i; for (i = 14; i < 16; i++) Y4324[i] = 1116;};
	Y4324[444] = 1108;
	Y4324[445] = 1109;
	Y4324[446] = 1110;
	Y4324[447] = 1111;
	Y4324[448] = 1112;
	Y4324[449] = 1113;
	Y4324[450] = 1114;
	Y4324[451] = 1115;
	Y4324[452] = 1116;
	Y4324[453] = 1117;
	Y4324[454] = 1118;
	Y4324[455] = 1119;
	Y4324[456] = 1108;
	Y4324[457] = 1110;
	Y4324[458] = 1112;
	Y4324[459] = 1109;
	Y4324[460] = 1114;
	Y4324[514] = 1108;
	Y4324[515] = 1109;
	Y4324[516] = 1110;
	Y4324[517] = 1111;
	Y4324[518] = 1112;
	Y4324[519] = 1113;
	Y4324[520] = 1114;
	Y4324[521] = 1115;
	Y4324[522] = 1116;
	Y4324[523] = 1117;
	Y4324[524] = 1118;
	Y4324[525] = 1119;
	{long i; for (i = 526; i < 528; i++) Y4324[i] = 1108;};
	Y4324[528] = 1109;
	{long i; for (i = 529; i < 531; i++) Y4324[i] = 1108;};
	Y4324[601] = 1108;
	{long i; for (i = 674; i < 677; i++) Y4324[i] = 1112;};
	Y4324[679] = 1115;
	{long i; for (i = 935; i < 937; i++) Y4324[i] = 1112;};
}

long O4665[867];
void O4665_init () {
	O4665[0] = + _CHROFF_1_0_;
	O4665[361] = + _CHROFF_3_0_;
	O4665[362] = + _CHROFF_4_0_;
	O4665[363] = + _CHROFF_5_0_;
	O4665[814] = + _CHROFF_5_0_;
	{long i; for (i = 858; i < 861; i++) O4665[i] = + _CHROFF_5_0_;}
	O4665[862] = + _CHROFF_7_1_;
	{long i; for (i = 863; i < 867; i++) O4665[i] = + _CHROFF_6_1_;}
}

long O4666[867];
void O4666_init () {
	O4666[0] = 0;
	{long i; for (i = 361; i < 364; i++) O4666[i] = 0;}
	O4666[814] = 0;
	{long i; for (i = 858; i < 861; i++) O4666[i] = 0;}
	O4666[862] =  + _REFACS_6_;
	{long i; for (i = 863; i < 867; i++) O4666[i] =  + _REFACS_5_;}
}

long O4667[867];
void O4667_init () {
	O4667[0] = + _LNGOFF_1_3_2_1_;
	O4667[361] = + _LNGOFF_3_6_2_1_;
	O4667[362] = + _LNGOFF_4_6_2_1_;
	O4667[363] = + _LNGOFF_5_7_2_1_;
	O4667[814] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 858; i < 861; i++) O4667[i] = + _LNGOFF_5_6_2_1_;}
	O4667[862] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 863; i < 867; i++) O4667[i] = + _LNGOFF_6_7_2_1_;}
}

long O4676[867];
void O4676_init () {
	O4676[0] = + _CHROFF_1_1_;
	O4676[361] = + _CHROFF_3_4_;
	O4676[362] = + _CHROFF_4_4_;
	O4676[363] = + _CHROFF_5_5_;
	O4676[814] = + _CHROFF_5_5_;
	{long i; for (i = 858; i < 861; i++) O4676[i] = + _CHROFF_5_4_;}
	O4676[862] = + _CHROFF_7_6_;
	{long i; for (i = 863; i < 867; i++) O4676[i] = + _CHROFF_6_5_;}
}

long O4677[867];
void O4677_init () {
	O4677[0] = + _R32OFF_1_3_2_3_0_;
	O4677[361] = + _R32OFF_3_6_2_4_0_;
	O4677[362] = + _R32OFF_4_6_2_4_0_;
	O4677[363] = + _R32OFF_5_7_2_4_0_;
	O4677[814] = + _R32OFF_5_7_2_4_0_;
	{long i; for (i = 858; i < 861; i++) O4677[i] = + _R32OFF_5_6_2_4_0_;}
	O4677[862] = + _R32OFF_7_8_2_4_0_;
	{long i; for (i = 863; i < 867; i++) O4677[i] = + _R32OFF_6_7_2_4_0_;}
}

long O4679[867];
void O4679_init () {
	O4679[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O4679[361] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O4679[362] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O4679[363] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O4679[814] = + _R64OFF_5_7_2_4_1_1_2_0_;
	{long i; for (i = 858; i < 861; i++) O4679[i] = + _R64OFF_5_6_2_4_1_1_2_0_;}
	O4679[862] = + _R64OFF_7_8_2_4_1_1_2_0_;
	{long i; for (i = 863; i < 867; i++) O4679[i] = + _R64OFF_6_7_2_4_1_1_2_0_;}
}

long O4681[867];
void O4681_init () {
	O4681[0] = + _LNGOFF_1_3_2_2_;
	O4681[361] = + _LNGOFF_3_6_2_2_;
	O4681[362] = + _LNGOFF_4_6_2_2_;
	O4681[363] = + _LNGOFF_5_7_2_2_;
	O4681[814] = + _LNGOFF_5_7_2_2_;
	{long i; for (i = 858; i < 861; i++) O4681[i] = + _LNGOFF_5_6_2_2_;}
	O4681[862] = + _LNGOFF_7_8_2_2_;
	{long i; for (i = 863; i < 867; i++) O4681[i] = + _LNGOFF_6_7_2_2_;}
}

long O4850[22];
void O4850_init () {
	{long i; for (i = 0; i < 12; i++) O4850[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 14; i++) O4850[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 14; i < 22; i++) O4850[i] = + _LNGOFF_1_1_0_0_;}
}

long O4854[22];
void O4854_init () {
	{long i; for (i = 0; i < 12; i++) O4854[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 14; i++) O4854[i] = + _CHROFF_2_0_;}
	{long i; for (i = 14; i < 22; i++) O4854[i] = + _CHROFF_1_0_;}
}

long O4855[22];
void O4855_init () {
	{long i; for (i = 0; i < 12; i++) O4855[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 14; i++) O4855[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 14; i < 22; i++) O4855[i] = + _LNGOFF_1_1_0_1_;}
}

long O4856[22];
void O4856_init () {
	{long i; for (i = 0; i < 12; i++) O4856[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 14; i++) O4856[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 14; i < 22; i++) O4856[i] = + _LNGOFF_1_1_0_2_;}
}

long O4857[22];
void O4857_init () {
	{long i; for (i = 0; i < 12; i++) O4857[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 14; i++) O4857[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 14; i < 22; i++) O4857[i] = + _LNGOFF_1_1_0_3_;}
}

long O4858[22];
void O4858_init () {
	{long i; for (i = 0; i < 12; i++) O4858[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 14; i++) O4858[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 14; i < 22; i++) O4858[i] = + _LNGOFF_1_1_0_4_;}
}

long O4861[50];
void O4861_init () {
	{long i; for (i = 0; i < 12; i++) O4861[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O4861[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O4861[i] = + _LNGOFF_1_0_0_0_;}
}

long O4863[50];
void O4863_init () {
	{long i; for (i = 0; i < 12; i++) O4863[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O4863[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O4863[i] = + _LNGOFF_1_0_0_1_;}
}

static EIF_TYPE_INDEX Y4879_pgtype0[] = {439,1061,0xFFFF};
static EIF_TYPE_INDEX Y4879_pgtype1[] = {892,1061,0xFFFF};
static EIF_TYPE_INDEX Y4879_pgtype2[] = {892,1061,0xFFFF};
EIF_TYPE_INDEX *Y4879_gen_type [513];
EIF_TYPE_INDEX Y4879 [513];
void Y4879_init (void)
{
	egc_routines_types [4879] = Y4879;
	egc_routines_gen_types [4879] = Y4879_gen_type;
	egc_routines_offset [4879] = 550;
	Y4879_gen_type [0] = Y4879_pgtype0;
	Y4879_gen_type [510] = Y4879_pgtype1;
	Y4879_gen_type [512] = Y4879_pgtype2;
	Y4879[0] = 439;
	Y4879[510] = 892;
	Y4879[512] = 892;
}

long O4893[764];
void O4893_init () {
	{long i; for (i = 0; i < 193; i++) O4893[i] = + _CHROFF_0_0_;}
	O4893[193] = + _CHROFF_1_0_;
	{long i; for (i = 194; i < 220; i++) O4893[i] = + _CHROFF_0_0_;}
	O4893[220] = + _CHROFF_3_2_;
	O4893[221] = + _CHROFF_4_2_;
	O4893[222] = + _CHROFF_5_2_;
	O4893[244] = + _CHROFF_7_0_;
	O4893[245] = + _CHROFF_6_0_;
	{long i; for (i = 246; i < 250; i++) O4893[i] = + _CHROFF_5_0_;}
	O4893[250] = + _CHROFF_4_0_;
	O4893[251] = + _CHROFF_5_0_;
	O4893[252] = + _CHROFF_9_0_;
	O4893[253] = + _CHROFF_7_0_;
	{long i; for (i = 254; i < 258; i++) O4893[i] = + _CHROFF_5_0_;}
	{long i; for (i = 258; i < 271; i++) O4893[i] = + _CHROFF_0_0_;}
	{long i; for (i = 271; i < 288; i++) O4893[i] = + _CHROFF_1_0_;}
	{long i; for (i = 288; i < 336; i++) O4893[i] = + _CHROFF_0_0_;}
	{long i; for (i = 336; i < 341; i++) O4893[i] = + _CHROFF_2_0_;}
	{long i; for (i = 341; i < 357; i++) O4893[i] = + _CHROFF_1_0_;}
	O4893[357] = + _CHROFF_5_0_;
	O4893[428] = + _CHROFF_1_0_;
	{long i; for (i = 501; i < 504; i++) O4893[i] = + _CHROFF_1_0_;}
	O4893[506] = + _CHROFF_1_0_;
	O4893[673] = + _CHROFF_5_2_;
	{long i; for (i = 717; i < 720; i++) O4893[i] = + _CHROFF_5_2_;}
	O4893[721] = + _CHROFF_7_2_;
	{long i; for (i = 722; i < 726; i++) O4893[i] = + _CHROFF_6_2_;}
	{long i; for (i = 762; i < 764; i++) O4893[i] = + _CHROFF_1_0_;}
}


#ifdef __cplusplus
}
#endif
